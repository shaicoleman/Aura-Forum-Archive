<?php
/**
 * Copyright (C) 2015 Panther (https://www.pantherforum.org)
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

class task_optimise_database
{
		public function __construct($db)
		{
			$this->db = $db;
		}

		public function run()
		{
			$ps = $this->db->run('SHOW TABLE STATUS');
			foreach ($ps as $cur_table)
				$this->db->run('OPTIMIZE TABLE '.$cur_table['Name']);
		}
}