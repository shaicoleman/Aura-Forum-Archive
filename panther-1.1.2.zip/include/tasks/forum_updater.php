<?php
/**
 * Copyright (C) 2015 Panther (https://www.pantherforum.org)
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

class task_forum_updater
{
		public function __construct($db, $panther_config, $updater)
		{
			$this->config = $panther_config;
			$this->updater = $updater;
		}

		public function run()
		{
			if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
				require PANTHER_ROOT.'include/cache.php';

			$panther_updates = generate_update_cache();
			if ($this->config['o_update_type'] == '0')
				return;

			if (version_compare($this->config['o_cur_version'], $this->updater->panther_updates['version'], '<'))	
			{
				if ($this->config['o_update_type'] == '2' || $this->config['o_update_type'] == '3')
					$this->updater->download();

				$file_name = 'panther-update-patch-'.$this->updater->version_friendly($this->updater->panther_updates['version']).'.zip';
				if (file_exists(PANTHER_ROOT.'include/updates/'.$file_name) && ($this->config['o_update_type'] == '1' || $this->config['o_update_type'] == '3'))
					$this->updater->install();
			}
		}
}