<?php
class error_handler
{
	public function __construct($panther_config, $lang, $panther_user, $panther_url)
	{
		$this->config = $panther_config;
		$this->lang = $lang;
		$this->user = $panther_user;
		$this->url = $panther_url;
	}

	public function exception($errno = 0, $errstr = 'Error', $errfile = 'unknown', $errline = 0)
	{
		if (!is_int($errno)) // Make sure set_exception_handler doesn't intefere
		{
			list(, $errstr, $errfile, $errline) = $this->parse_exception($errno);
			$errno = 1;
		}

		// Needed to ensure it doesn't appear after completion on every page
		if ($errno < 1)
			exit;

		$error = error_get_last();
		if (error_reporting() == 0) // If we want to supress errors
			return;

		// Check if we're dealing with a fatal error (again, these have to be handled seperately - with register_shutdown_function)
		if ($error['type'] == E_ERROR)
		{
			$errno = $error['type'];
			$errstr = $error['message'];
			$errfile = $error['file'];
			$errline = $error['line'];
		}

		// Empty all output buffers and stop buffering (only if we've started)
		if (ob_get_level() > 0 && ob_get_length())
			@ob_clean();

		// Don't send HTML
		if (defined('PANTHER_AJAX_REQUEST'))
			exit((($this->config['o_debug_mode'] == '1') ? 'Errno ['.$errno.'] '.$errstr.' in '.$errfile.' on line '.$errline : 'A server error was encountered.'));

		$style_path = (($this->config['o_style_path'] != 'style') ? $this->config['o_style_path'] : PANTHER_ROOT.$this->config['o_style_path']).'/';

		// "Restart" output buffering if we are using ob_gzhandler (since the gzip header is already sent)
		if ($this->config['o_gzip'] && extension_loaded('zlib') && !ob_get_length())
			ob_start('ob_gzhandler');

		// Send no-cache headers
		header('Expires: Thu, 21 Jul 1977 07:30:00 GMT'); // When yours truly first set eyes on this world! :)
		header('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT');
		header('Cache-Control: post-check=0, pre-check=0', false);
		header('Pragma: no-cache'); // For HTTP/1.0 compatibility

		// Send the Content-type header in case the web server is setup to send something else
		header('Content-type: text/html; charset=utf-8');

		// Send headers telling people we're down
		header('HTTP/1.1 503 Service Temporarily Unavailable');
		header('Status: 503 Service Temporarily Unavailable');

		$tpl = load_template('server_error.tpl');
		echo $tpl->render(
			array(
				'panther_config' => $this->config,
				'error_style' => (($this->config['o_style_dir']) != '' ? $this->config['o_style_dir'] : get_base_url().'/style/').(file_exists($style_path.$this->user['style'].'/error.css') ? $this->user['style'] : 'core'),
				'page_title' => generate_page_title(array($this->config['o_board_title'], 'Server Error')),
				'errrno' => $errno,
				'errstr' => $errstr,
				'errfile' => $errfile,
				'errline' => $errline,
				'index' => panther_link($this->url['index']),
			)
		);

		exit;
	}

	private function parse_exception($str)
	{
		if (preg_match("/message '(.*)' in (.*):([0-9]+)/", $str, $matches))
			return $matches;

		return 'unknown exception';
	}
}