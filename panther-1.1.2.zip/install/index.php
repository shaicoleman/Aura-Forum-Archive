<?php
/**
 * Copyright (C) 2015 Panther (https://www.pantherforum.org)
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

define('INSTALL_ROOT', __DIR__.'/');
require INSTALL_ROOT.'include/common.php';

$action = isset($_GET['act']) ? panther_trim($_GET['act']) : '';
if ($action != '' && $section == 'install')
{
	if (!defined('PANTHER_AJAX_REQUEST') && $action != 'generate_config')
		exit;

	require PANTHER_ROOT.'include/database.php';
	$db->start_transaction();

	$installer->load($db, $lang, $data);
	echo $installer->install($action);

	$db->end_transaction();
	exit;
}

$errors = array();
if ($section == 'requirements')
{
	$info = check_requirements($lang);
	$installer->add_progress(5);

	load_header($installer, $lang, $section, $base_url);
	$tpl = $installer->load_template('requirements');
	echo $tpl->render(
		array(
			'lang' => $lang,
			'requirements' => $info['requirements'],
			'optional' => $info['optional'],
			'failed' => $info['failed'],
			'base_url' => $base_url,
			'language' => $data['language'],
			'csrf_token' => $data['csrf_token'],
		)
	);

	serialise_session($data, $installer);
}
else if ($section == 'license')
{
	$installer->add_progress(5);
	load_header($installer, $lang, $section, $base_url);
	$tpl = $installer->load_template('license');
	echo $tpl->render(
		array(
			'lang' => $lang,
			'license' => file_get_contents(PANTHER_ROOT.'license.md'),
			'language' => $data['language'],
			'csrf_token' => $data['csrf_token'],
			'base_url' => $base_url,
		)
	);

	serialise_session($data, $installer);
}
else if ($section == 'database')
{
	if (isset($_POST['form_sent']))
	{
		$config = array(
			'type' => isset($_POST['db_type']) ? panther_trim($_POST['db_type']) : '',
			'host' => isset($_POST['db_host']) ? panther_trim($_POST['db_host']) : '',
			'engine' => isset($_POST['db_engine']) && $_POST['db_type'] == 'mysql' && in_array($_POST['db_engine'], array('myisam', 'innodb')) ? panther_trim($_POST['db_engine']) : '',
			'prefix' => isset($_POST['db_prefix']) ? panther_trim($_POST['db_prefix']) : '',
			'username' => isset($_POST['db_username']) ? panther_trim($_POST['db_username']) : '',
			'password' => isset($_POST['db_password']) ? panther_trim($_POST['db_password']) : '',
			'db_name' => isset($_POST['db_name']) ? panther_trim($_POST['db_name']) : '',
			'p_connect' => false,
		);
	
		if (panther_strlen($config['db_name']) < 1)
			$errors[] = $lang->t('Invalid database name');

		if (strlen($config['prefix']) > 0 && (!preg_match('%^[a-zA-Z_][a-zA-Z0-9_]*$%', $config['prefix']) || strlen($config['prefix']) > 40))
			$errors[] = $lang->t('Invalid prefix');

		if (empty($errors))
		{
			require PANTHER_ROOT.'include/database.php';
			if ($config['type'] == 'mysql')
			{
				$ps = $db->run('SELECT support FROM INFORMATION_SCHEMA.ENGINES WHERE ENGINE=\'InnoDB\'');
				$result = $ps->fetchColumn();

				if (!in_array($result, array('YES', 'DEFAULT')))
					$errors[] = $lang->t('Innodb disabled');

				if ($db->table_exists('users'))
					$errors[] = $lang->t('Existing table error', $config['prefix'], $config['db_name']);
			}

			$mysql_info = $db->get_version();
			if (version_compare($mysql_info['version'], MIN_MYSQL_VERSION, '<'))
				$errors[] = $lang->t('Mysql version problem', $mysql_info['version'], MIN_MYSQL_VERSION);

			if (empty($errors))
			{
				$data['config'] = array_merge($data['config'], $config);

				$installer->add_progress(15); // Add more progress to the tracker and redirect to the next step ...
				serialise_session($data, $installer);
				header('Location: '.$base_url.'install/?section=user&lang='.$data['language'].'&csrf_token='.$data['csrf_token']);
				exit;
			}
		}
	}

	load_header($installer, $lang, $section, $base_url);
	$tpl = $installer->load_template('database');
	echo $tpl->render(
		array(
			'lang' => $lang,
			'language' => $data['language'],
			'csrf_token' => $data['csrf_token'],
			'base_url' => $base_url,
			'drivers' => get_database_drivers($drivers),
			'config' => $data['config'],
			'errors' => $errors,
		)
	);
}
else if ($section == 'user')
{
	$user = array();
	if (isset($_POST['form_sent']))
	{
		$user = array(
			'username' => isset($_POST['username']) ? panther_trim($_POST['username']) : '',
			'email' => isset($_POST['email']) ? strtolower(panther_trim($_POST['email'])) : '',
			'password1' => isset($_POST['password1']) ? panther_trim($_POST['password1']) : '',
			'password2' => isset($_POST['password2']) ? panther_trim($_POST['password2']) : '',
		);

		if (panther_strlen($user['username']) < 2)
			$errors[] = $lang->t('Username 1');
		else if (panther_strlen($user['username']) > 25) // This usually doesn't happen since the form element only accepts 25 characters
			$errors[] = $lang->t('Username 2');
		else if (!strcasecmp($user['username'], 'Guest'))
			$errors[] = $lang->t('Username 3');
		else if (preg_match('%[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}%', $user['username']) || preg_match('%((([0-9A-Fa-f]{1,4}:){7}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){6}:[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){5}:([0-9A-Fa-f]{1,4}:)?[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){4}:([0-9A-Fa-f]{1,4}:){0,2}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){3}:([0-9A-Fa-f]{1,4}:){0,3}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){2}:([0-9A-Fa-f]{1,4}:){0,4}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){6}((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|(([0-9A-Fa-f]{1,4}:){0,5}:((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|(::([0-9A-Fa-f]{1,4}:){0,5}((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|([0-9A-Fa-f]{1,4}::([0-9A-Fa-f]{1,4}:){0,5}[0-9A-Fa-f]{1,4})|(::([0-9A-Fa-f]{1,4}:){0,6}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){1,7}:))%', $user['username']))
			$errors[] = $lang->t('Username 4');
		else if ((strpos($user['username'], '[') !== false || strpos($user['username'], ']') !== false) && strpos($user['username'], '\'') !== false && strpos($user['username'], '"') !== false)
			$errors[] = $lang->t('Username 5');
		else if (preg_match('%(?:\[/?(?:b|u|i|h|colou?r|quote|code|img|url|email|list)\]|\[(?:code|quote|list)=)%i', $user['username']))
			$errors[] = $lang->t('Username 6');

		if (panther_strlen($user['password1']) < 6)
			$errors[] = $lang->t('Short password');
		else if ($user['password1'] != $user['password2'])
			$errors[] = $lang->t('Passwords not match');

		if (!is_valid_email($user['email']))
			$errors[] = $lang->t('Invalid email');

		if (empty($errors))
		{
			$data = array_merge($user, $data);

			$installer->add_progress(15);
			serialise_session($data, $installer);
			header('Location: '.$base_url.'install/?section=settings&lang='.$data['language'].'&csrf_token='.$data['csrf_token']);
			exit;
		}
	}

	load_header($installer, $lang, $section, $base_url);
	$tpl = $installer->load_template('user');
	echo $tpl->render(
		array(
			'lang' => $lang,
			'language' => $data['language'],
			'csrf_token' => $data['csrf_token'],
			'base_url' => $base_url,
			'errors' => $errors,
			'user' => $user,
		)
	);
}
else if ($section == 'settings')
{
	if (isset($_POST['form_sent']))
	{
		$settings = array(
			'title' => isset($_POST['title']) ? panther_trim($_POST['title']) : '',
			'description' => isset($_POST['description']) ? panther_trim($_POST['description']) : '',
			'base_url' => isset($_POST['base_url']) ? panther_trim($_POST['base_url']) : '',
			'default_lang' => isset($_POST['default_lang']) ? panther_trim($_POST['default_lang']) : '',
			'default_style' => isset($_POST['default_style']) ? panther_trim($_POST['default_style']) : '',
			'email_title' => panther_trim(preg_replace('/[^a-zA-Z0-9 ]/', '', panther_trim($_POST['title']))),
		);

		// Make sure base_url doesn't end with a slash
		if (substr($settings['base_url'], -1) == '/')
			$settings['base_url'] = substr($settings['base_url'], 0, -1);

		if ($settings['title'] == '')
			$errors[] = $lang->t('No board title');

		if (!language_handler::language_exists($settings['default_lang']))
			$errors[] = $lang->t('Error default language');

		$styles = forum_list_styles();
		if (!in_array($settings['default_style'], $styles))
			$errors[] = $lang->t('Error default style');

		if ($settings['email_title'] == '')
			$errors[] = $lang->t('Email name problem');

		if (empty($errors))
		{
			$data = array_merge($settings, $data);

			$installer->add_progress(15);
			serialise_session($data, $installer);
			header('Location: '.$base_url.'install/?section=advanced&lang='.$data['language'].'&csrf_token='.$data['csrf_token']);
			exit;
		}
	}

	load_header($installer, $lang, $section, $base_url);
	$tpl = $installer->load_template('settings');
	echo $tpl->render(
		array(
			'lang' => $lang,
			'language' => $data['language'],
			'csrf_token' => $data['csrf_token'],
			'base_url' => $base_url,
			'languages' => language_handler::get_language_list(),
			'default_lang' => $installer->default_lang,
			'default_style' => $installer->default_style,
			'styles' => forum_list_styles(),
			'errors' => $errors,
		)
	);
}
else if ($section == 'advanced')
{
	if (isset($_POST['form_sent']))
	{
		$advanced = array(
			'cookie_name' => isset($_POST['cookie_name']) ? panther_trim($_POST['cookie_name']) : '',
			'cookie_seed' => isset($_POST['cookie_seed']) ? panther_trim($_POST['cookie_seed']) : '',
			'delete_posts' => isset($_POST['delete_posts']) && $_POST['delete_posts'] == '1' ? '1' : '0',
			'gzip' => isset($_POST['gzip']) && $_POST['gzip'] == '1' ? '1' : '0',
			'use_avatars' => isset($_POST['use_avatars']) && $_POST['use_avatars'] == '1' ? '1' : '0',
			'allow_regs' => isset($_POST['allow_regs']) && $_POST['allow_regs'] == '1' ? '1' : '0',
		);

		$data = array_merge($advanced, $data);

		$installer->add_progress(15);
		serialise_session($data, $installer);
		header('Location: '.$base_url.'install/?section=install&lang='.$data['language'].'&csrf_token='.$data['csrf_token']);
		exit;
	}

	load_header($installer, $lang, $section, $base_url);
	$tpl = $installer->load_template('advanced');
	echo $tpl->render(
		array(
			'lang' => $lang,
			'language' => $data['language'],
			'csrf_token' => $data['csrf_token'],
			'base_url' => $base_url,
			'errors' => $errors,
			'cookie_name' => 'panther_cookie_'.random_key(6, false, true),
			'cookie_seed' => random_key(16, false, true),
		)
	);
}
else if ($section == 'install')
{
	load_header($installer, $lang, $section, $base_url);
	$tpl = $installer->load_template('install');
	echo $tpl->render(
		array(
			'lang' => $lang,
			'language' => $data['language'],
			'csrf_token' => $data['csrf_token'],
			'base_url' => $base_url,
		)
	);
}
else
{
	load_header($installer, $lang, $section, $base_url);
	$tpl = $installer->load_template('welcome');
	echo $tpl->render(
		array(
			'lang' => $lang,
			'panther_version' => PANTHER_VERSION,
			'mysql_version' => MIN_MYSQL_VERSION,
			'php_version' => MIN_PHP_VERSION,
			'base_url' => $base_url,
			'csrf_token' => $data['csrf_token'],
			'language' => $data['language'],
		)
	);
}

load_footer($installer, $lang, $section);