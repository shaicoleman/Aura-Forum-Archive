<?php
if (!defined('INSTALL_ROOT'))
	exit;

session_start();
session_regenerate_id();
define('PANTHER_ROOT', __DIR__.'/../../');

// The Panther version this script installs
define('PANTHER_VERSION', '1.1.2');
define('MIN_PHP_VERSION', '5.3.0');
define('MIN_MYSQL_VERSION', '5.0.15');
define('PANTHER_SEARCH_MIN_WORD', 3);
define('PANTHER_SEARCH_MAX_WORD', 20);
define('FORUM_CACHE_DIR', PANTHER_ROOT.'cache/');

// Send the Content-type header in case the web server is setup to send something else
header('Content-type: text/html; charset=utf-8');

// Load the functions script
require PANTHER_ROOT.'include/functions.php';

// Load UTF-8 functions
require PANTHER_ROOT.'include/utf8/utf8.php';

// Strip out "bad" UTF-8 characters
forum_remove_bad_characters();

error_reporting(E_ALL);

// Has Panther already been installed?
if (file_exists(PANTHER_ROOT.'include/config.php'))
	include PANTHER_ROOT.'include/config.php';

if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest')
	define('PANTHER_AJAX_REQUEST', 1);

// If the installation is not corrupt, then abort
if (defined('PANTHER'))
{
	header('Location: '.str_replace('install/', '', get_current_url()));
	exit;
}

// ... Otherwise define it here as we need it for various other things ...
define('PANTHER', 1);

require INSTALL_ROOT.'include/functions.php';
set_exception_handler('exception_handler');

require PANTHER_ROOT.'include/lang.php';
$lang = new language_handler();

$install_lang = isset($_GET['lang']) ? preg_replace('%[\.\\\/]%', '', panther_trim($_GET['lang'])) : 'en';
$lang->set_language($install_lang);
$lang->load('install');

// Force POSIX locale (to prevent functions such as strtolower() from messing up UTF-8 strings)
setlocale(LC_CTYPE, 'C');

// Turn off PHP time limit
@set_time_limit(0);

$panther_config = array('o_style_path' => 'style', 'o_show_queries' => '0');

$base_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') ? 'https://' : 'http://'; // protocol
$base_url .= preg_replace('%:(80|443)$%', '', $_SERVER['HTTP_HOST']); // host[:port]
$base_url .= str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])); // path

if (substr($base_url, -1) == '/')
	$base_url = substr($base_url, 0, -1);

$base_url = str_replace('install', '', $base_url);

require PANTHER_ROOT.'include/lib/Twig/Autoloader.php';

// Register Twig autoloader
Twig_Autoloader::register();

$loader = new Twig_Loader_Filesystem(INSTALL_ROOT.'include/templates');
$loader->addPath(INSTALL_ROOT.'include/templates/', 'install');
$tpl_manager = new Twig_Environment($loader, 
	array(
		'cache' => PANTHER_ROOT.'cache/templates/install/',
		'debug' => true,
	)
);

$section = isset($_GET['section']) ? panther_trim($_GET['section']) : 'welcome';
$drivers = array(
	'mysql' => 'MySQL',
);

require INSTALL_ROOT.'include/installer.php';
$installer = new installer($tpl_manager);

// We only want to create it if it doesn't exist already
if (!isset($_SESSION['install']) && $section == 'welcome')
{
	$data = array(
		'progress' => $installer->progress,
		'csrf_token' => sha1(random_key(16, false, true)),
		'language' => $install_lang,
		'config' => array(
			'type' => 'mysql',
			'host' => 'localhost',
			'engine' => 'innodb',
			'prefix' => 'panther_',
			'username' => 'root',
			'password' => '',
			'db_name' => '',
			'p_connect' => false,
		),
	);

	$_SESSION['install'] = serialize($data);
}
else
{
	$data = unserialize($_SESSION['install']);
	$installer->progress = $data['progress'];
	$config = $data['config'];
}

if ($section != 'welcome' && !isset($_GET['csrf_token']) || isset($_GET['csrf_token']) && $_GET['csrf_token'] != $data['csrf_token'])
{
	$_SESSION = array(); // Reset the session just in case
	header('Location: '.$base_url.'install/');
	exit;
}