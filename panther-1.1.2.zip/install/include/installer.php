<?php
if (!defined('PANTHER'))
	exit;

class installer
{
	public $progress = 0;
	public $default_lang = 'en';
	public $default_style = 'pantherone';
	public function __construct($tpl_manager)
	{
		$this->tpl_manager = $tpl_manager;
	}

	public function load_template($tpl_file)
	{
		return $this->tpl_manager->loadTemplate('@install/'.$tpl_file.'.tpl');
	}

	public function add_progress($amount)
	{
		$this->progress += $amount;
	}

	public function load($db, $lang, $data)
	{
		require INSTALL_ROOT.'include/install.php';
		$this->install = new install($db, $lang, $data, $this);
	}

	public function install($action = '')
	{
		if (!method_exists($this->install, $action) && $action != '')
			throw new Exception('Invalid installation action.');

		$lang = array_values($this->install->ajax_lang);
		$steps = array_values($this->install->steps);
		if ($action == '')
			$action = $steps[0];

		if (is_callable(array($this->install, $action)))
			$response = call_user_func(array($this->install, $action));

		$current_step = array_search($action, $steps);

		// This should never happen if it's using valid steps
		if ($current_step === false)
			return false;

		if ($response == 'failed') // Then we're on the last check and writing the config failed
			return 'failed';

		if (!isset($steps[++$current_step]))
			return 'finish';

		return $steps[$current_step].'||'.$lang[($current_step-1)];
	}
}