<?php
if (!defined('PANTHER'))
	exit;

function exception_handler($error)
{
	header('Content-type: text/plain');
	exit($error);
}

function is_valid_email($email)
{
	if (strlen($email) > 80)
		return false;

	return preg_match('%^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|("[^"]+"))@((\[\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\])|(([a-zA-Z\d\-]+\.)+[a-zA-Z]{2,}))$%', $email);
}

function generate_config_file($config)
{
	return '<?php'."\n\n\$config = ".var_export($config, true).";\n\ndefine('PANTHER', 1);\n";
}

function get_database_drivers($drivers)
{
	$db_extensions = array();
	$db_drivers = PDO::getAvailableDrivers();
	foreach ($db_drivers as $driver)
	{
		if (in_array($driver, array_keys($drivers)))
			$db_extensions[] = array('name' => $driver, 'title' => $drivers[$driver]);
	}

	return $db_extensions;
}

function check_requirements($lang)
{
	$failed = false;
	$errors = array_fill_keys(array('php_version', 'sha512', 'PDO', 'getimagesize', 'json', 'curl', 'url_fopen', 'fopen', 'exec', 'memory', 'uploads', 'cache', 'avatars'), true);
	if (version_compare(PHP_VERSION, MIN_PHP_VERSION, '<'))
	{
		$failed = true;
		$errors['php_version'] = false;
	}

	if (!in_array('sha512', hash_algos()))
	{
		$failed = true;
		$errors['sha512'] = false;
	}
	
	if (!forum_is_writable(FORUM_CACHE_DIR))
	{
		$failed = true;
		$errors['cache'] = false;
	}

	if (!class_exists('PDO'))
	{
		$failed = true;
		$errors['PDO'] = false;
	}

	if (!function_exists('getimagesize'))
	{
		$failed = true;
		$errors['getimagesize'] = false;
	}

	if (!function_exists('json_encode') || !function_exists('json_decode'))
	{
		$failed = true;
		$errors['json'] = false;
	}

	// Optional requirements
	if (!is_callable('curl_init'))
		$errors['curl'] = false;

	if (!@file_get_contents('https://www.pantherforum.org/'))
		$errors['url_fopen'] = false;

	if (!function_exists('fopen'))
		$errors['fopen'] = false;

	if (!function_exists('exec') || strtoupper(substr(PHP_OS, 0, 3)) === 'WIN')
		$errors['exec'] = false;

	if (return_bytes(ini_get('memory_limit')) < 134217728)
		$errors['memory'] = false;

	if (!in_array(strtolower(@ini_get('file_uploads')), array('on', 'true', '1')))
		$errors['uploads'] = false;

	if (!forum_is_writable(PANTHER_ROOT.'assets/images/avatars/'))
	{
		$failed = true;
		$errors['avatars'] = false;
	}

	$requirements = array(
		'php_version' => array('lang' => $lang->t('PHP version test', MIN_PHP_VERSION), 'passed' => $errors['php_version']),
		'sha512' => array('lang' => $lang->t('Sha-512 test'), 'passed' => $errors['sha512']),
		'pdo' => array('lang' => $lang->t('PDO test'), 'passed' => $errors['PDO']),
		'getimagesize' => array('lang' => $lang->t('Getimagesize test'), 'passed' => $errors['getimagesize']),
		'json' => array('lang' => $lang->t('Json test'), 'passed' => $errors['json']),
		'cache' => array('lang' => $lang->t('Cache writable', FORUM_CACHE_DIR), 'passed' => $errors['cache']),
	);

	$optional = array(
		'curl' => array('lang' => $lang->t('Curl test'), 'passed' => $errors['curl']),
		'url_fopen' => array('lang' => $lang->t('Url fopen test'), 'passed' => $errors['url_fopen']),
		'fopen' => array('lang' => $lang->t('Fopen test'), 'passed' => $errors['fopen']),
		'exec' => array('lang' => $lang->t('Exec test'), 'passed' => $errors['exec']),
		'memory' => array('lang' => $lang->t('Memory test'), 'passed' => $errors['memory']),
		'uploads' => array('lang' => $lang->t('File uploads'), 'passed' => $errors['uploads']),
		'avatars' => array('lang' => $lang->t('Avatar writable', PANTHER_ROOT.'assets/images/avatars/'), 'passed' => $errors['avatars']),
	);

	return array('failed' => $failed, 'requirements' => $requirements, 'optional' => $optional);
}

function load_header($installer, $lang, $section, $base_url)
{
	$tpl = $installer->load_template('header');
	echo $tpl->render(
		array(
			'lang' => $lang,
			'title' => $section,
			'base_url' => $base_url,
			'page' => $section,
		)
	);
}

function load_footer($installer, $lang, $section)
{
	$tpl = $installer->load_template('footer');
	echo $tpl->render(
		array(
			'lang' => $lang,
			'page' => $section,
			'progress' => $installer->progress,
		)
	);
}

function serialise_session($data, $installer)
{
	$data['progress'] = $installer->progress;
	$_SESSION['install'] = serialize($data);
}