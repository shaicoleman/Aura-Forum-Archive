<?php

/**
 *
 * This file is part of the Panther Forum Software package.
 *
 * @link      https://www.pantherforum.org/
 * @copyright Copyright (c) Panther <https://www.pantherforum.org/>
 * @license   GNU General Public License (GPL-3.0), Version 3, 29 June 2007 <http://opensource.org/licenses/GPL-3.0>
 *
 * For full information, please see README.md, CHANGELOG.md and LICENSE.md files which are located in the root folder.
 *
 */

// Make sure no one attempts to run this script "directly"
if (!defined('PANTHER'))
	exit;

// Send no-cache headers
header('Expires: Thu, 21 Jul 1977 07:30:00 GMT'); // When yours truly first set eyes on this world! :)
header('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT');
header('Cache-Control: post-check=0, pre-check=0', false);
header('Pragma: no-cache'); // For HTTP/1.0 compatibility

// Send the Content-type header in case the web server is setup to send something else
header('Content-type: text/html; charset=utf-8');

// Prevent site from being embedded in a frame
header('X-Frame-Options: deny');

// Load the template
if (defined('PANTHER_ADMIN_CONSOLE'))
	$tpl_file = 'admin.tpl';
else if (defined('PANTHER_HELP'))
	$tpl_file = 'help.tpl';
else
	$tpl_file = 'main.tpl';

if (file_exists(PANTHER_ROOT.'style/'.$panther_user['style'].'/'.$tpl_file))
{
	$tpl_file = PANTHER_ROOT.'style/'.$panther_user['style'].'/'.$tpl_file;
	$tpl_inc_dir = PANTHER_ROOT.'style/'.$panther_user['style'].'/';
}
else
{
	$tpl_file = PANTHER_ROOT.'include/template/'.$tpl_file;
	$tpl_inc_dir = PANTHER_ROOT.'include/user/';
}

$tpl_main = file_get_contents($tpl_file);

// START SUBST - <panther_include "*">
preg_match_all('%<panther_include "([^"]+)">%i', $tpl_main, $panther_includes, PREG_SET_ORDER);

foreach ($panther_includes as $cur_include)
{
	ob_start();

	$file_info = pathinfo($cur_include[1]);
	
	if (!in_array($file_info['extension'], array('php', 'php4', 'php5', 'inc', 'html', 'txt'))) // Allow some extensions
		error_handler(E_ERROR, sprintf($lang_common['Pun include extension'], panther_htmlspecialchars($cur_include[0]), basename($tpl_file), panther_htmlspecialchars($file_info['extension'])), __FILE__, __LINE__);

	if (strpos($file_info['dirname'], '..') !== false) // Don't allow directory traversal
		error_handler(E_ERROR, sprintf($lang_common['Pun include directory'], panther_htmlspecialchars($cur_include[0]), basename($tpl_file)), __FILE__, __LINE__);

	// Allow for overriding user includes, too.
	if (file_exists($tpl_inc_dir.$cur_include[1]))
		require $tpl_inc_dir.$cur_include[1];
	else if (file_exists(PANTHER_ROOT.'include/user/'.$cur_include[1]))
		require PANTHER_ROOT.'include/user/'.$cur_include[1];
	else
		error_handler(E_ERROR, sprintf($lang_common['Pun include error'], panther_htmlspecialchars($cur_include[0]), basename($tpl_file)), __FILE__, __LINE__);

	$tpl_temp = ob_get_contents();
	$tpl_main = str_replace($cur_include[0], $tpl_temp, $tpl_main);
	ob_end_clean();
}
// END SUBST - <panther_include "*">

// START SUBST - <panther_language>
$tpl_main = str_replace('<panther_language>', $lang_common['lang_identifier'], $tpl_main);
// END SUBST - <panther_language>

// START SUBST - <panther_content_direction>
$tpl_main = str_replace('<panther_content_direction>', $lang_common['lang_direction'], $tpl_main);
// END SUBST - <panther_content_direction>

// START SUBST - <panther_head>
ob_start();

// Define $p if it's not set to avoid a PHP notice
$p = isset($p) ? $p : null;

// Is this a page that we want search index spiders to index?
if (!defined('PANTHER_ALLOW_INDEX'))
	echo '<meta name="robots" content="noindex, follow" />'."\n";

?>
        <title><?php echo generate_page_title($page_title, $p) ?></title>
        <link href="<?php echo (($panther_config['o_style_dir']) != '' ? $panther_config['o_style_dir'] : get_base_url().'/style/').$panther_user['style'].'.css' ?>" rel="stylesheet" />
<?php
if (defined('POSTING') && $panther_user['use_editor'] == '1')
{
	echo "\t".'<link href="'.$panther_config['o_js_dir'].'square.min.css" rel="stylesheet" />'."\n";
}

if (defined('PANTHER_ADMIN_CONSOLE'))
{
	if (file_exists(PANTHER_ROOT.'style/'.$panther_user['style'].'/base_admin.css'))
		echo "\t".'<link href="'.(($panther_config['o_style_dir']) != '' ? $panther_config['o_style_dir'] : get_base_url().'/style/').$panther_user['style'].'/base_admin.css" rel="stylesheet" />'."\n";
	else
		echo "\t".'<link href="'.(($panther_config['o_style_dir']) != '' ? $panther_config['o_style_dir'] : get_base_url().'/style/').'imports/base_admin.css" rel="stylesheet" />'."\n";
}
echo "\t".'<link href="'.$panther_config['o_image_dir'].$panther_config['o_favicon'].'" type="image/x-icon" rel="shortcut icon" />'."\n";
$page_head['colorize_groups'] = "\t".'<style type="text/css">'.$panther_config['o_colourize_groups'].'</style>'; // Pre-cached to save rendering time

if (!empty($page_head))
	echo implode("\n", $page_head)."\n";

if (defined('JQUERY_REQUIRED') || (defined('POSTING') && $panther_user['use_editor'] == '1') || defined('REPUTATION'))
{
	echo "\t".'<script src="//ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>'."\n";
	echo "\t".'<script>var url = new Array("'.get_base_url().'/", "'.(($panther_config['o_smilies_dir'] != '') ? $panther_config['o_smilies_dir'] : get_base_url().'/'.$panther_config['o_smilies_path']).'/", "'.$panther_config['o_js_dir'].'");</script>'."\n";
}

if (defined('REPUTATION'))
	echo "\t".'<script src="'.$panther_config['o_js_dir'].'reputation.js"></script>'."\n";

if (defined('POSTING') && $panther_user['use_editor'] == '1')
{
	echo "\t".'<script src="'.$panther_config['o_js_dir'].'bbcode.js"></script>'."\n";
	echo "\t".'<script src="'.$panther_config['o_js_dir'].'sceditor.js"></script>'."\n";
}

if (basename($_SERVER['PHP_SELF']) == 'admin_index.php')
	echo "\t".'<script src="'.$panther_config['o_js_dir'].'admin_notes.js"></script>'."\n";

if (isset($required_fields))
{
	// Output JavaScript to validate form (make sure required fields are filled out)

?>
        <script>
        /* <![CDATA[ */
        function process_form(the_form)
        {
            var required_fields = {
        <?php
            // Output a JavaScript object with localised field names
            $tpl_temp = count($required_fields);
            foreach ($required_fields as $elem_orig => $elem_trans)
            {
                echo "\t\t\"".$elem_orig.'": "'.addslashes(str_replace('&#160;', ' ', $elem_trans));
                if (--$tpl_temp) echo "\",\n";
                else echo "\"\n\t};\n";
            }
        ?>
            if (document.all || document.getElementById)
            {
                for (var i = 0; i < the_form.length; ++i)
                {
                    var elem = the_form.elements[i];
                    if (elem.name && required_fields[elem.name] && !elem.value && elem.type && (/^(?:text(?:area)?|password|file)$/i.test(elem.type)))
                    {
                        alert('"' + required_fields[elem.name] + '" <?php echo $lang_common['required field'] ?>');
                        elem.focus();
                        return false;
                    }
                }
            }
            return true;
        }
        /* ]]> */
        </script>
<?php

}

$tpl_temp = trim(ob_get_contents());
$tpl_main = str_replace('<panther_head>', $tpl_temp, $tpl_main);
ob_end_clean();
// END SUBST - <panther_head>


// START SUBST - <body>
if (isset($focus_element))
{
	$tpl_main = str_replace('<body onload="', '<body onload="document.getElementById(\''.$focus_element[0].'\').elements[\''.$focus_element[1].'\'].focus();', $tpl_main);
	$tpl_main = str_replace('<body>', '<body onload="document.getElementById(\''.$focus_element[0].'\').elements[\''.$focus_element[1].'\'].focus()">', $tpl_main);
}
// END SUBST - <body>


// START SUBST - <panther_page>
$tpl_main = str_replace('<panther_page>', panther_htmlspecialchars(basename($_SERVER['PHP_SELF'], '.php')), $tpl_main);
// END SUBST - <panther_page>

// START SUBST - <panther_title>
if (!stristr($panther_config['o_board_desc'], '<img src'))
	$tpl_main = str_replace('<panther_title>', '<h1><a href="'.get_link($panther_url['index']).'">'.panther_htmlspecialchars($panther_config['o_board_title']).'</a></h1>', $tpl_main);
else
	$tpl_main = str_replace('<panther_title>', '', $tpl_main);
// END SUBST - <panther_title>


// START SUBST - <panther_desc>
$tpl_main = str_replace('<panther_desc>', '<div id="brddesc">'.$panther_config['o_board_desc'].'</div>', $tpl_main);
// END SUBST - <panther_desc>


// START SUBST - <panther_navlinks>
$links = array();

// Index should always be displayed
$links[] = '<li id="navindex"'.((PANTHER_ACTIVE_PAGE == 'index') ? ' class="isactive"' : '').'><a href="'.get_link($panther_url['index']).'">'.$lang_common['Index'].'</a></li>';

flux_hook('header_link_generation');

if ($panther_user['g_read_board'] == '1' && $panther_user['g_view_users'] == '1')
	$links[] = '<li id="navuserlist"'.((PANTHER_ACTIVE_PAGE == 'userlist') ? ' class="isactive"' : '').'><a href="'.get_link($panther_url['userlist']).'">'.$lang_common['User list'].'</a></li>';

if ($panther_user['g_read_board'] == '1' && $panther_user['g_view_users'] == '1')
	$links[] = '<li id="navuserlist"'.((PANTHER_ACTIVE_PAGE == 'leaders') ? ' class="isactive"' : '').'><a href="'.get_link($panther_url['leaders']).'">'.$lang_common['Moderating Team'].'</a></li>';

if ($panther_user['g_read_board'] == '1' && $panther_user['g_view_users'] == '1' && $panther_config['o_users_online'] == '1')
	$links[] = '<li id="navonline"'.((PANTHER_ACTIVE_PAGE == 'online') ? ' class="isactive"' : '').'><a href="'.get_link($panther_url['online']).'">'.$lang_common['Online'].'</a></li>';

if ($panther_config['o_rules'] == '1' && (!$panther_user['is_guest'] || $panther_user['g_read_board'] == '1' || $panther_config['o_regs_allow'] == '1'))
	$links[] = '<li id="navrules"'.((PANTHER_ACTIVE_PAGE == 'rules') ? ' class="isactive"' : '').'><a href="'.get_link($panther_url['rules']).'">'.$lang_common['Rules'].'</a></li>';

if ($panther_user['g_read_board'] == '1' && $panther_user['g_search'] == '1')
	$links[] = '<li id="navsearch"'.((PANTHER_ACTIVE_PAGE == 'search') ? ' class="isactive"' : '').'><a href="'.get_link($panther_url['search']).'">'.$lang_common['Search'].'</a></li>';

if ($panther_user['is_guest'])
{
	$links[] = '<li id="navregister"'.((PANTHER_ACTIVE_PAGE == 'register') ? ' class="isactive"' : '').'><a href="'.get_link($panther_url['register']).'">'.$lang_common['Register'].'</a></li>';
	$links[] = '<li id="navlogin"'.((PANTHER_ACTIVE_PAGE == 'login') ? ' class="isactive"' : '').'><a href="'.get_link($panther_url['login']).'">'.$lang_common['Login'].'</a></li>';
}
else
{	// To avoid another preg replace, link directly to the essentials section
	$links[] = '<li id="navprofile"'.((PANTHER_ACTIVE_PAGE == 'profile') ? ' class="isactive"' : '').'><a href="'.get_link($panther_url['profile_essentials'], array($panther_user['id'])).'">'.$lang_common['Profile'].'</a></li>';
		
	if ($panther_config['o_private_messaging'] == '1' && $panther_user['g_use_pm'] == '1' && $panther_user['pm_enabled'] == '1')
	{
		$header_data = array(
			':uid'	=>	$panther_user['id'],
		);

		$ps_header = $db->run('SELECT COUNT(c.id) FROM '.$db->prefix.'conversations AS c INNER JOIN '.$db->prefix.'pms_data AS cd ON c.id=cd.topic_id AND cd.user_id=:uid WHERE cd.viewed=0 AND cd.deleted=0', $header_data);
		$num_messages = $ps_header->fetchColumn();

		$pm_lang = ($num_messages) ? sprintf($lang_common['PM amount'], $num_messages) : $lang_common['PM'];
		$links[] = '<li id="navprofile"'.((PANTHER_ACTIVE_PAGE == 'inbox') ? ' class="isactive"' : '').'><a href="'.get_link($panther_url['inbox']).'">'.$pm_lang.'</a></li>';
	}


	if ($panther_user['is_admmod'] && ($panther_user['is_admin'] || $panther_user['g_mod_cp'] == '1'))
		$links[] = '<li id="navadmin"'.((PANTHER_ACTIVE_PAGE == 'admin') ? ' class="isactive"' : '').'><a href="'.get_link($panther_url['admin_index']).'">'.$lang_common['Admin'].'</a></li>';

	$links[] = '<li id="navlogout"><a href="'.get_link($panther_url['logout'], array($panther_user['id'], panther_hash($panther_user['id'].panther_hash(get_remote_address())))).'">'.$lang_common['Logout'].'</a></li>';
}

// Are there any additional navlinks we should insert into the array before imploding it?
if ($panther_user['g_read_board'] == '1' && $panther_config['o_additional_navlinks'] != '')
{
	if (preg_match_all('%([0-9]+)\s*=\s*(.*?)\n%s', $panther_config['o_additional_navlinks']."\n", $extra_links))
	{
		// Insert any additional links into the $links array (at the correct index)
		$num_links = count($extra_links[1]);
		for ($i = 0; $i < $num_links; ++$i)
			array_splice($links, $extra_links[1][$i], 0, array('<li id="navextra'.($i + 1).'">'.$extra_links[2][$i].'</li>'));
	}
}

$tpl_temp = '<div id="brdmenu" class="inbox">'."\n\t\t\t".'<ul>'."\n\t\t\t\t".implode("\n\t\t\t\t", $links)."\n\t\t\t".'</ul>'."\n\t\t".'</div>';
$tpl_main = str_replace('<panther_navlinks>', $tpl_temp, $tpl_main);
// END SUBST - <panther_navlinks>

// START SUBST - <panther_status>
$page_statusinfo = $page_topicsearches = array();

if ($panther_user['is_guest'])
	$page_statusinfo = '<p class="conl">'.$lang_common['Not logged in'].'</p>';
else
{
	$page_statusinfo[] = '<li><span>'.$lang_common['Logged in as'].' <strong>'.colourize_group($panther_user['username'], $panther_user['g_id'], $panther_user['id']).'</strong></span></li>';
	$page_statusinfo[] = '<li><span>'.sprintf($lang_common['Last visit'], format_time($panther_user['last_visit'])).'</span></li>';

	if ($panther_config['o_private_messaging'] == '1' && $panther_user['g_use_pm'] == '1' && $panther_user['pm_enabled'] == '1' && $num_messages)
		$page_statusinfo[] = '<li class="reportlink"><span><strong><a href="'.get_link($panther_url['inbox']).'">'.$lang_common['New PM'].'</a></strong></span></li>';

	if ($panther_user['is_admmod'])
	{
		if ($panther_config['o_report_method'] == '0' || $panther_config['o_report_method'] == '2')
		{
			$ps_header = $db->select('reports', 1, array(), 'zapped IS NULL');

			if ($ps_header->rowCount())
				$page_statusinfo[] = '<li class="reportlink"><span><strong><a href="'.get_link($panther_url['admin_reports']).'">'.$lang_common['New reports'].'</a></strong></span></li>';
		}
		
		$ps_header = $db->select('posts', 1, array(), 'approved=0 AND deleted=0');
		if ($ps_header->rowCount())
			$page_statusinfo[] = '<li class="reportlink"><span><strong><a href="'.get_link($panther_url['admin_posts']).'">'.$lang_common['New unapproved posts'].'</a></strong></span></li>';

		if ($panther_config['o_maintenance'] == '1')
			$page_statusinfo[] = '<li class="maintenancelink"><span><strong><a href="'.get_link($panther_url['admin_options_direct'], array('maintenance')).'">'.$lang_common['Maintenance mode enabled'].'</a></strong></span></li>';
	}

	if ($panther_user['g_read_board'] == '1' && $panther_user['g_search'] == '1')
	{
		$page_topicsearches[] = '<a href="'.get_link($panther_url['search_replies']).'" title="'.$lang_common['Show posted topics'].'">'.$lang_common['Posted topics'].'</a>';
		$page_topicsearches[] = '<a href="'.get_link($panther_url['search_new']).'" title="'.$lang_common['Show new posts'].'">'.$lang_common['New posts header'].'</a>';
	}
}

// Quick searches
if ($panther_user['g_read_board'] == '1' && $panther_user['g_search'] == '1')
{
	$page_topicsearches[] = '<a href="'.get_link($panther_url['search_recent']).'" title="'.$lang_common['Show active topics'].'">'.$lang_common['Active topics'].'</a>';
	$page_topicsearches[] = '<a href="'.get_link($panther_url['search_unanswered']).'" title="'.$lang_common['Show unanswered topics'].'">'.$lang_common['Unanswered topics'].'</a>';
}

// Generate all that jazz
$tpl_temp = '<div id="brdwelcome" class="inbox">';

// The status information
if (is_array($page_statusinfo))
{
	$tpl_temp .= "\n\t\t\t".'<ul class="conl">';
	$tpl_temp .= "\n\t\t\t\t".implode("\n\t\t\t\t", $page_statusinfo);
	$tpl_temp .= "\n\t\t\t".'</ul>';
}
else
	$tpl_temp .= "\n\t\t\t".$page_statusinfo;

// Generate quicklinks
if (!empty($page_topicsearches))
{
	$tpl_temp .= "\n\t\t\t".'<ul class="conr">';
	$tpl_temp .= "\n\t\t\t\t".'<li><span>'.$lang_common['Topic searches'].' '.implode(' | ', $page_topicsearches).'</span></li>';
	$tpl_temp .= "\n\t\t\t".'</ul>';
}

$tpl_temp .= "\n\t\t\t".'<div class="clearer"></div>'."\n\t\t".'</div>';

$tpl_main = str_replace('<panther_status>', $tpl_temp, $tpl_main);
// END SUBST - <panther_status>


// START SUBST - <panther_announcement>
if ($panther_user['g_read_board'] == '1' && $panther_config['o_announcement'] == '1')
{
	ob_start();

?>
<div id="announce" class="block">
	<div class="hd"><h2><span><?php echo $lang_common['Announcement'] ?></span></h2></div>
	<div class="box">
		<div id="announce-block" class="inbox">
			<div class="usercontent"><?php echo $panther_config['o_announcement_message'] ?></div>
		</div>
	</div>
</div>
<?php

	$tpl_temp = trim(ob_get_contents());
	$tpl_main = str_replace('<panther_announcement>', $tpl_temp, $tpl_main);
	ob_end_clean();
}
else
	$tpl_main = str_replace('<panther_announcement>', '', $tpl_main);
// END SUBST - <panther_announcement>


// START SUBST - <panther_main>
ob_start();


define('PANTHER_HEADER', 1);