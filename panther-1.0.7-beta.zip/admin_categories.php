<?php

/**
 *
 * This file is part of the Panther Forum Software package.
 *
 * @link      https://www.pantherforum.org/
 * @copyright Copyright (c) Panther <https://www.pantherforum.org/>
 * @license   GNU General Public License (GPL-3.0), Version 3, 29 June 2007 <http://opensource.org/licenses/GPL-3.0>
 *
 * For full information, please see README.md, CHANGELOG.md and LICENSE.md files which are located in the root folder.
 *
 */

// Tell header.php to use the admin template
define('PANTHER_ADMIN_CONSOLE', 1);

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/');
	require PANTHER_ROOT.'include/common.php';
}
require PANTHER_ROOT.'include/common_admin.php';

if (!$panther_user['is_admin'])
	message($lang_common['No permission'], false, '403 Forbidden');

if ($panther_user['id'] != '2')
{
	if(!is_null($admins[$panther_user['id']]['admin_categories']))
	{
		if ($admins[$panther_user['id']]['admin_categories'] == '0')
			message($lang_common['No permission'], false, '403 Forbidden');
	}
}

check_authentication();

// Load the admin_categories.php language file
require PANTHER_ROOT.'lang/'.$admin_language.'/admin_categories.php';

// Add a new category
if (isset($_POST['add_cat']))
{
	confirm_referrer('admin_categories.php');

	$new_cat_name = panther_trim($_POST['new_cat_name']);
	if ($new_cat_name == '')
		message($lang_admin_categories['Must enter name message']);
	
	$insert = array(
		'cat_name'	=>	$new_cat_name,
	);

	$db->insert('categories', $insert);
	redirect(get_link($panther_url['admin_categories']), $lang_admin_categories['Category added redirect']);
}

// Delete a category
else if (isset($_POST['del_cat']) || isset($_POST['del_cat_comply']))
{
	confirm_referrer('admin_categories.php');

	$cat_to_delete = intval($_POST['cat_to_delete']);
	if ($cat_to_delete < 1)
		message($lang_common['Bad request'], false, '404 Not Found');

	if (isset($_POST['del_cat_comply'])) // Delete a category with all forums and posts
	{
		@set_time_limit(0);
		$data = array(
			':id'	=>	$cat_to_delete,
		);

		$ps = $db->select('forums', 'id', $data, 'cat_id=:id');
		$num_forums = $ps->rowCount();

		for ($i = 0; $i < $num_forums; ++$i)
		{
			$cur_forum = $ps->fetchColumn();

			// Prune all posts and topics
			prune($cur_forum, 1, -1);
			$data = array(
				':id'	=>	$cur_forum,
			);

			// Delete the forum
			$db->delete('forums', 'id=:id', $data);
		}

		// Locate any "orphaned redirect topics" and delete them
		$ps = $db->run('SELECT t1.id FROM '.$db->prefix.'topics AS t1 LEFT JOIN '.$db->prefix.'topics AS t2 ON t1.moved_to=t2.id WHERE t2.id IS NULL AND t1.moved_to IS NOT NULL');
		if ($ps->rowCount())
		{
			$data = $markers = array();
			$ps->setFetchMode(PDO::FETCH_COLUMN, 0);
			foreach ($ps as $orphan)
			{
				$markers[] = '?';
				$data[] = $orphan;
			}
			
			$db->run('DELETE FROM '.$db->prefix.'topics WHERE id IN('.implode(',', $markers).')', $data);
		}
		
		$data = array(
			':id'	=>	$cat_to_delete
		);

		// Delete the category
		$db->delete('categories', 'id=:id', $data);

		// Regenerate the quick jump cache
		if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
			require PANTHER_ROOT.'include/cache.php';

		generate_forums_cache();
		generate_quickjump_cache();
		generate_perms_cache();
		redirect(get_link($panther_url['admin_categories']), $lang_admin_categories['Category deleted redirect']);
	}
	else // If the user hasn't confirmed the delete
	{
		$data = array(
			':id'	=>	$cat_to_delete,
		);
		$ps = $db->select('categories', 'cat_name', $data, 'id=:id');
		$cat_name = $ps->fetchColumn();

		$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_admin_common['Admin'], $lang_admin_common['Categories']);
		define('PANTHER_ACTIVE_PAGE', 'admin');
		require PANTHER_ROOT.'header.php';

		generate_admin_menu('categories');
?>
	<div class="blockform">
		<h2><span><?php echo $lang_admin_categories['Delete category head'] ?></span></h2>
		<div class="box">
			<form method="post" action="<?php echo get_link($panther_url['admin_categories']); ?>">
				<div class="inform">
				<input type="hidden" name="cat_to_delete" value="<?php echo $cat_to_delete ?>" />
				<input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>" />
					<fieldset>
						<legend><?php echo $lang_admin_categories['Confirm delete subhead'] ?></legend>
						<div class="infldset">
							<p><?php printf($lang_admin_categories['Confirm delete info'], panther_htmlspecialchars($cat_name)) ?></p>
							<p class="warntext"><?php echo $lang_admin_categories['Delete category warn'] ?></p>
						</div>
					</fieldset>
				</div>
				<p class="buttons"><input type="submit" name="del_cat_comply" value="<?php echo $lang_admin_common['Delete'] ?>" /><a href="javascript:history.go(-1)"><?php echo $lang_admin_common['Go back'] ?></a></p>
			</form>
		</div>
	</div>
	<div class="clearer"></div>
</div>
<?php
		require PANTHER_ROOT.'footer.php';
	}
}
else if (isset($_POST['update'])) // Change position and name of the categories
{
	confirm_referrer('admin_categories.php');

	$categories = isset($_POST['cat']) && is_array($_POST['cat']) ? $_POST['cat'] : array();
	if (empty($categories))
		message($lang_common['Bad request'], false, '404 Not Found');

	foreach ($categories as $cat_id => $cur_cat)
	{
		$cur_cat['name'] = panther_trim($cur_cat['name']);
		$cur_cat['order'] = panther_trim($cur_cat['order']);

		if ($cur_cat['name'] == '')
			message($lang_admin_categories['Must enter name message']);

		if ($cur_cat['order'] == '' || preg_match('%[^0-9]%', $cur_cat['order']))
			message($lang_admin_categories['Must enter integer message']);
		
		$update = array(
			'cat_name'	=>	$cur_cat['name'],
			'disp_position'	=>	$cur_cat['order'],
		);
		
		$data = array(
			':id'	=>	intval($cat_id),
		);

		$db->update('categories', $update, 'id=:id', $data);
	}

	// Regenerate the quick jump cache
	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PANTHER_ROOT.'include/cache.php';

	generate_quickjump_cache();
	redirect(get_link($panther_url['admin_categories']), $lang_admin_categories['Categories updated redirect']);
}

// Generate an array with all categories
$ps = $db->select('categories', 'id, cat_name, disp_position', array(), '', 'disp_position');
$num_cats = $ps->rowCount();

foreach ($ps as $category)
	$cat_list[] = $category;

$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_admin_common['Admin'], $lang_admin_common['Categories']);
define('PANTHER_ACTIVE_PAGE', 'admin');
require PANTHER_ROOT.'header.php';

generate_admin_menu('categories');
?>
	<div class="blockform">
		<h2><span><?php echo $lang_admin_categories['Add categories head'] ?></span></h2>
		<div class="box">
			<form method="post" action="<?php echo get_link($panther_url['admin_categories']); ?>">
			<input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>" />
				<div class="inform">
					<fieldset>
						<legend><?php echo $lang_admin_categories['Add categories subhead'] ?></legend>
						<div class="infldset">
							<table class="aligntop">
								<tr>
									<th scope="row"><?php echo $lang_admin_categories['Add category label'] ?><div><input type="submit" name="add_cat" value="<?php echo $lang_admin_categories['Add new submit'] ?>" tabindex="2" /></div></th>
									<td>
										<input type="text" name="new_cat_name" size="35" maxlength="80" tabindex="1" />
										<span><?php printf($lang_admin_categories['Add category help'], '<a href="admin_forums.php">'.$lang_admin_common['Forums'].'</a>') ?></span>
									</td>
								</tr>
							</table>
						</div>
					</fieldset>
				</div>
			</form>
		</div>

<?php if ($num_cats): ?>		<h2 class="block2"><span><?php echo $lang_admin_categories['Delete categories head'] ?></span></h2>
		<div class="box">
			<form method="post" action="<?php echo get_link($panther_url['admin_categories']); ?>">
				<input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>" />
				<div class="inform">
					<fieldset>
						<legend><?php echo $lang_admin_categories['Delete categories subhead'] ?></legend>
						<div class="infldset">
							<table class="aligntop">
								<tr>
									<th scope="row"><?php echo $lang_admin_categories['Delete category label'] ?><div><input type="submit" name="del_cat" value="<?php echo $lang_admin_common['Delete'] ?>" tabindex="4" /></div></th>
									<td>
										<select name="cat_to_delete" tabindex="3">
<?php
	foreach ($cat_list as $cur_cat)
		echo "\t\t\t\t\t\t\t\t\t\t\t".'<option value="'.$cur_cat['id'].'">'.panther_htmlspecialchars($cur_cat['cat_name']).'</option>'."\n";
?>
										</select>
										<span><?php echo $lang_admin_categories['Delete category help'] ?></span>
									</td>
								</tr>
							</table>
						</div>
					</fieldset>
				</div>
			</form>
		</div>
<?php endif; ?>

<?php if ($num_cats): ?>		<h2 class="block2"><span><?php echo $lang_admin_categories['Edit categories head'] ?></span></h2>
		<div class="box">
			<form method="post" action="<?php echo get_link($panther_url['admin_categories']); ?>">
				<input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>" />
				<div class="inform">
					<fieldset>
						<legend><?php echo $lang_admin_categories['Edit categories subhead'] ?></legend>
						<div class="infldset">
							<table id="categoryedit">
							<thead>
								<tr>
									<th class="tcl" scope="col"><?php echo $lang_admin_categories['Category name label'] ?></th>
									<th scope="col"><?php echo $lang_admin_categories['Category position label'] ?></th>
								</tr>
							</thead>
							<tbody>
<?php
	foreach ($cat_list as $cur_cat)
	{
?>
								<tr>
									<td class="tcl"><input type="text" name="cat[<?php echo $cur_cat['id'] ?>][name]" value="<?php echo panther_htmlspecialchars($cur_cat['cat_name']) ?>" size="35" maxlength="80" /></td>
									<td><input type="text" name="cat[<?php echo $cur_cat['id'] ?>][order]" value="<?php echo $cur_cat['disp_position'] ?>" size="3" maxlength="3" /></td>
								</tr>
<?php
	}
?>
							</tbody>
							</table>
							<div class="fsetsubmit"><input type="submit" name="update" value="<?php echo $lang_admin_common['Update'] ?>" /></div>
						</div>
					</fieldset>
				</div>
			</form>
		</div>
<?php endif; ?>	</div>
	<div class="clearer"></div>
</div>
<?php
require PANTHER_ROOT.'footer.php';