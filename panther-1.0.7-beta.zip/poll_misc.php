<?php

/**
 *
 * This file is part of the Panther Forum Software package.
 *
 * @link      https://www.pantherforum.org/
 * @copyright Copyright (c) Panther <https://www.pantherforum.org/>
 * @license   GNU General Public License (GPL-3.0), Version 3, 29 June 2007 <http://opensource.org/licenses/GPL-3.0>
 *
 * For full information, please see README.md, CHANGELOG.md and LICENSE.md files which are located in the root folder.
 *
 */

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/');
	require PANTHER_ROOT.'include/common.php';
}

if ($panther_user['g_read_board'] == '0')
	message($lang_common['No view'], false, '403 Forbidden');

$id = ((isset($_GET['edit'])) ? intval($_GET['edit']) : (isset($_GET['delete']) ? intval($_GET['delete']) : 0));
$id = (($id != 0) ? $id : (isset($_GET['reset']) ? intval($_GET['reset']) : 0));

if ($id < 1)
	message($lang_common['Bad request']);
	
require PANTHER_ROOT.'lang/'.$panther_user['language'].'/poll.php';

$data = array(
	':gid'	=>	$panther_user['g_id'],
	':tid'	=>	$id,
);

// Fetch some info about the topic and the forum
$ps = $db->run('SELECT f.moderators, f.password, f.redirect_url, f.id AS fid, t.archived, t.closed, t.subject, t.poster, t.question, p.type, p.options, p.id AS pid FROM '.$db->prefix.'topics AS t INNER JOIN '.$db->prefix.'forums AS f ON f.id=t.forum_id INNER JOIN '.$db->prefix.'polls AS p ON t.id=p.topic_id LEFT JOIN '.$db->prefix.'forum_perms AS fp ON (fp.forum_id=f.id AND fp.group_id=:gid) WHERE (fp.read_forum IS NULL OR fp.read_forum=1) AND t.question!=\'\' AND t.id=:tid', $data);
if (!$ps->rowCount())
	message($lang_common['Bad request']);
	
$cur_topic = $ps->fetch();
	
// Is this a redirect forum? In that case, abort!
if ($cur_topic['redirect_url'] != '' || $cur_topic['question'] == '')
	message($lang_common['Bad request']);
	

if ($cur_topic['password'] != '')
		check_forum_login_cookie($id, $cur_topic['password']);

$mods_array = ($cur_topic['moderators'] != '') ? unserialize($cur_topic['moderators']) : array();
$is_admmod = ($panther_user['is_admin'] || ($panther_user['g_moderator'] == '1' && $panther_user['g_global_moderator'] ||  array_key_exists($panther_user['username'], $mods_array))) ? true : false;

$options = ($cur_topic['options'] != '') ? unserialize($cur_topic['options']) : array();

if ($cur_topic['archived'] == '1')
	message($lang_common['No permission']);
	
if (isset($_GET['edit']))
{
	// Do we have permission to edit this poll?
	if ($cur_topic['poster'] != $panther_user['username'] && $cur_topic['closed'] == '1' && !$is_admmod)
		message($lang_common['No permission']);
		
	if (isset($_POST['form_sent']))
	{
		confirm_referrer('poll_misc.php');

		$question = isset($_POST['req_question']) ? panther_trim($_POST['req_question']) : '';
		$options = isset($_POST['options']) && is_array($_POST['options']) ? array_map('panther_trim', $_POST['options']) : array();

		if ($question == '')
			$errors[] = $lang_poll['No question'];
		else if (panther_strlen($question) > 70)
			$errors[] = $lang_poll['Too long question'];
		else if ($panther_config['p_subject_all_caps'] == '0' && is_all_uppercase($question) && !$panther_user['is_admmod'])
			$errors[] = $lang_poll['All caps question'];
			
		if (empty($options))
			$errors[] = $lang_poll['No options'];

		$option_data = array();
		for ($i = 0; $i <= $panther_config['o_max_poll_fields']; $i++)
		{
			if (!empty($errors))
				break;

			if (panther_strlen($options[$i]) > 55)
				$errors[] = $lang_poll['Too long option'];
			else if ($panther_config['p_subject_all_caps'] == '0' && is_all_uppercase($options[$i]) && !$panther_user['is_admmod'])
				$errors[] = $lang_poll['All caps option'];
			else if ($options[$i] != '')
				$option_data[] = $options[$i];
		}

		if (count($options) < 2)
			$errors[] = $lang_poll['Low options'];

		$now = time();

		if (empty($errors))
		{
			$update = array(
				'question'	=>	$question,
			);

			$data = array(
				':id'	=>	$id,
			);

			$db->update('topics', $update, 'id=:id', $data);
			$update = array(
				'options'	=>	serialize($option_data),
			);

			$data = array(
				':id'	=>	$cur_topic['pid'],
			);
			
			$db->update('polls', $update, 'id=:id', $data);
			redirect(get_link($panther_url['topic'], array($id, url_friendly($cur_topic['subject']))), $lang_poll['Poll updated redirect']);
		}
	}

	$cur_index = 1;

	$inputs = array();
	for ($i = 0; $i <= $panther_config['o_max_poll_fields'] ; $i++)
		$inputs[] = '<label><strong>'.$lang_poll['Option'].'</strong><br /> <input type="text" name="options['.$i.']" value="'.((isset($options[$i])) ? panther_htmlspecialchars($options[$i]) : '').'" size="60" maxlength="55" tabindex="'.$cur_index++.'" /><br /></label>';

	$legend = ($cur_topic['type'] == 1) ? $lang_poll['New poll legend'] : $lang_poll['New poll legend multiselect'];

	$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_poll['Edit poll']);
	define('PANTHER_ACTIVE_PAGE', 'index');
	require PANTHER_ROOT.'header.php';

	// If there are errors, we display them
	if (!empty($errors))
	{
?>
<div id="posterror" class="block">
	<h2><span><?php echo $lang_post['Post errors'] ?></span></h2>
	<div class="box">
		<div class="inbox">
			<p><?php echo $lang_post['Post errors info'] ?></p>
			<ul>
<?php
	foreach ($errors as $cur_error)
		echo "\t\t\t\t".'<li><strong>'.$cur_error.'</strong></li>'."\n";
?>
			</ul>
		</div>
	</div>
</div>
<?php
	}
?>
<div class="blockform">
	<h2><span><?php echo $lang_poll['Edit poll'] ?></span></h2>
	<div class="box">
		<form id="post" method="post" action="<?php echo 'poll_misc.php?edit='.$id; ?>" onsubmit="return process_form(this)">
			<div class="inform">
				<fieldset>
					<legend><?php echo $legend ?></legend>
					<div class="infldset">
						<input type="hidden" name="form_sent" value="1" />
						<input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>" />
						<label><strong><?php echo $lang_poll['Question'] ?></strong><br /><input type="text" name="req_question" value="<?php echo panther_htmlspecialchars($cur_topic['question']); ?>" size="80" maxlength="70" tabindex="<?php echo $cur_index++ ?>" /><br /><br /></label>
						<?php echo implode("\n\t\t\t\t\t\t", $inputs); ?>
					</div>
				</fieldset>
			</div>
			<p class="buttons"><input type="submit" name="submit" value="<?php echo $lang_common['Submit'] ?>" tabindex="<?php echo $cur_index++ ?>" accesskey="s" /></p>
		</form>
	</div>
</div>
<?php
}
else if (isset($_GET['delete']))
{
	// Do we have permission to delete this poll?
	if ($cur_topic['poster'] != $panther_user['username'] && $cur_topic['closed'] == '1' && !$is_admmod)
		message($lang_common['No permission']);

	if (isset($_POST['form_sent']))
	{
		confirm_referrer('poll_misc.php');
		$data = array(
			':id'	=>	$cur_topic['pid'],
		);

		$db->delete('polls', 'id=:id', $data);
		$update = array(
			'question'	=>	'',
		);

		$data = array(
			':id'	=>	$id,
		);

		$db->update('topics', $update, 'id=:id', $data);
		redirect(get_link($panther['topic'], array($id, url_friendly($cur_topic['subject']))), $lang_poll['Poll deleted redirect']);
	}

	$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_poll['Delete poll']);
	define('PANTHER_ACTIVE_PAGE', 'index');
	require PANTHER_ROOT.'header.php';
?>
<div class="blockform">
	<h2><span><?php echo $lang_poll['Delete poll'] ?></span></h2>
	<div class="box blockpost">
		<form method="post" action="poll_misc.php?delete=<?php echo $id ?>">
			<input type="hidden" name="form_sent" value="1" />
			<input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>" />
			<div class="inform">
				<fieldset>
					<legend class="warntext"><?php echo $lang_poll['Confirm delete legend'] ?></legend>
					<div class="infldset">
						<div class="postmsg">
							<p><?php echo $lang_poll['Delete poll comply'] ?></p>
						</div>
					</div>
				</fieldset>
			</div>
			<p class="buttons"><input type="submit" name="delete" value="<?php echo $lang_poll['Delete'] ?>" /><a href="javascript:history.go(-1)"><?php echo $lang_common['Go back'] ?></a></p>
		</form>
	</div>
</div>
<?php
}
else if (isset($_GET['reset']))
{
	if (isset($_POST['form_sent']))
	{
		confirm_referrer('poll_misc.php');
		
		$update = array(
			'voters'	=>	'',
			'votes'		=>	'',
		);
		
		$data = array(
			':id'	=>	$cur_topic['pid'],
		);
		
		$db->update('polls', $update, 'id=:id', $data);
		redirect(get_link($panther_url['topic'], array($id, url_friendly($cur_topic['subject']))), $lang_poll['Poll reset redirect']);
	}
	
	$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_poll['Reset poll']);
	define('PANTHER_ACTIVE_PAGE', 'index');
	require PANTHER_ROOT.'header.php';
?>
<div class="blockform">
	<h2><span><?php echo $lang_poll['Reset poll'] ?></span></h2>
	<div class="box blockpost">
		<form method="post" action="poll_misc.php?reset=<?php echo $id ?>">
			<input type="hidden" name="form_sent" value="1" />
			<input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>" />
			<div class="inform">
				<fieldset>
					<legend class="warntext"><?php echo $lang_poll['Confirm reset legend'] ?></legend>
					<div class="infldset">
						<div class="postmsg">
							<p><?php echo $lang_poll['Reset poll comply'] ?></p>
						</div>
					</div>
				</fieldset>
			</div>
			<p class="buttons"><input type="submit" name="reset" value="<?php echo $lang_poll['Reset'] ?>" /><a href="javascript:history.go(-1)"><?php echo $lang_common['Go back'] ?></a></p>
		</form>
	</div>
</div>
<?php
}
else
	message($lang_common['Bad request']);

require PANTHER_ROOT.'footer.php';