<?php

/**
 *
 * This file is part of the Panther Forum Software package.
 *
 * @link      https://www.pantherforum.org/
 * @copyright Copyright (c) Panther <https://www.pantherforum.org/>
 * @license   GNU General Public License (GPL-3.0), Version 3, 29 June 2007 <http://opensource.org/licenses/GPL-3.0>
 *
 * For full information, please see README.md, CHANGELOG.md and LICENSE.md files which are located in the root folder.
 *
 */

// Tell header.php to use the admin template
define('PANTHER_ADMIN_CONSOLE', 1);

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/');
	require PANTHER_ROOT.'include/common.php';
}
require PANTHER_ROOT.'include/common_admin.php';

if (!$panther_user['is_admin'])
	message($lang_common['No permission'], false, '403 Forbidden');

if ($panther_user['id'] != '2')
{
	if(!is_null($admins[$panther_user['id']]['admin_attachments']))
	{
		if ($admins[$panther_user['id']]['admin_attachments'] == '0')
			message($lang_common['No permission'], false, '403 Forbidden');
	}
}

// Load the admin_attachments.php language file
require PANTHER_ROOT.'lang/'.$admin_language.'/admin_attachments.php';

check_authentication();

if ($panther_config['o_attachments'] == '0')
	message($lang_common['Bad request']);

$action = isset($_GET['action']) ? panther_htmlspecialchars($_GET['action']) : null;

if (isset($_POST['delete_attachment']))
{
	$id = intval(key($_POST['delete_attachment']));

	if (!delete_attachment($id))
		message($lang_admin_attachments['Unable to delete attachment']);

	redirect(get_link($panther_url['admin_attachments']), $lang_admin_attachments['Attachment del redirect']);
}
elseif (isset($_POST['delete_orphans']))
{
	$ps = $db->run('SELECT a.id FROM '.$db->prefix.'attachments AS a LEFT JOIN '.$db->prefix.'posts AS p ON p.id=a.post_id WHERE p.id IS NULL');
	if (!$ps->rowCount())
		message($lang_admin_attachments['No orphans']);

	$i = 0;
	$ps->setFetchMode(PDO::FETCH_COLUMN, 0);
	foreach ($ps as $attachment)
	{
		if (!delete_attachment($attachment))
			continue;
		else
			$i++;
	}

	message(sprintf($lang_admin_attachmetns['X orphans deleted'], array($i)));
}

$start = (isset($_POST['start'])) ? intval($_POST['start']) : 0;
$limit = (isset($_POST['number'])) ? intval($_POST['number']) : 50;
$increase = (isset($_POST['auto_increase']) && $_POST['auto_increase'] == '1') ? $start + $limit : $start;
$direction = (isset($_POST['direction']) && $_POST['direction'] == '1') ? 'ASC' : 'DESC';
$order = isset($_POST['order']) ? intval($_POST['order']) : 0;

switch ($order)
{
	case 1:
		$order = 'a.downloads';
		break;
	case 2:
		$order = 'a.size';
		break;
	case 3:
		$order = 'a.downloads*af.size';
		break;
	case 0:
	default:
		$order = 'a.id';
		break;
}

$data = array(
	':start'	=>	$start,
	':limit'	=>	$limit,
);

$ps = $db->run('SELECT a.id, a.owner, a.post_id, a.filename, a.extension, a.size, a.downloads, u.username, u.group_id FROM '.$db->prefix.'attachments AS a LEFT JOIN '.$db->prefix.'users AS u ON u.id=a.owner ORDER BY '.$order.' '.$direction.' LIMIT :start, :limit', $data);

$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_admin_common['Admin'], $lang_admin_common['Attachments']);
define('PANTHER_ACTIVE_PAGE', 'admin');
require PANTHER_ROOT.'header.php';

generate_admin_menu('attachments');
?>
		<div class="blockform">
			<h2><span><?php echo $lang_admin_attachments['List attachments']; ?></span></h2>
			<div class="box">
				<div class="inbox">
					<div class="inform">
						<form name="list_attachments_form" id="example" method="post" action="<?php echo get_link($panther_url['admin_attachments']); ?>">
						<fieldset>
							<legend><?php echo $lang_admin_attachments['Search options']; ?></legend>
							<div class="infldset">
							<table class="aligntop">
								<tr>
									<th scope="row"><?php echo $lang_admin_attachments['Start at']; ?></th>
									<td>
										<span><input type="text" name="start" size="3" value="<?php echo $increase; ?>" tabindex="1" /> (<?php echo $lang_admin_attachments['Auto increase']; ?> <input type="radio" name="auto_increase" value="1" tabindex="2" <?php echo ($increase != $start) ? 'checked="checked" ' : ''; ?>/><strong><?php echo $lang_admin_common['Yes']; ?></strong> <input type="radio" name="auto_increase" value="0" tabindex="3" <?php echo ($increase != $start)?'':'checked="checked" '; ?>/><strong><?php echo $lang_admin_common['No']; ?></strong>)</span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_attachments['Number of attachments']; ?></th>
									<td>
										<span><input type="text" name="number" size="3" value="<?php echo $limit; ?>"  tabindex="4" /></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_attachments['Order']; ?></th>
									<td>
										<span><input type="radio" name="order" value="0" tabindex="5" <?php echo ($order == 'a.id') ? 'checked="checked" ' : ''; ?>/><?php echo $lang_admin_attachments['ID']; ?> 
										<input type="radio" name="order" value="1" tabindex="6" <?php echo ($order == 'a.downloads') ? 'checked="checked"' : ''; ?>/><?php echo $lang_admin_attachments['Downloads']; ?>
										<input type="radio" name="order" value="2" tabindex="7" <?php echo ($order == 'a.size') ? 'checked="checked" ' : ''; ?>/><?php echo $lang_admin_attachments['Size']; ?> <input type="radio" name="order" value="3" tabindex="8" <?php echo ($order == 'af.downloads*af.size') ? 'checked="checked" ' : ''; ?>/><?php echo $lang_admin_attachments['Total transfer']; ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_attachments['Direction']; ?></th>
									<td>
										<span><input type="radio" name="direction" value="1" tabindex="9" <?php echo ($direction == 'ASC') ? 'checked="checked" ' : ''; ?>/><?php echo $lang_admin_attachments['Ascending']; ?> <input type="radio" name="direction" value="0" tabindex="10" <?php echo ($direction == 'DESC') ? 'checked="checked" ' : ''; ?>/><?php echo $lang_admin_attachments['Descending']; ?></span>
									</td>
								</tr>
							</table>
							<div class="fsetsubmit"><input type="submit" name="submit" value="<?php echo $lang_admin_attachments['List Attachments']; ?>" tabindex="11" /> <input type="submit" name="delete_orphans" value="<?php echo $lang_admin_attachments['Delete Orphans']; ?>" tabindex="11" /></div>
							</div>
						</fieldset>
						</form>
					</div>
				</div>
			</div>
		</div>
<?php
if ($ps->rowCount())
{
?>
		<div class="blockform">
			<h2 class="block2"><span><?php echo $lang_admin_attachments['Attachment list']; ?></span></h2>
			<div class="box">
				<div class="fakeform">
					<div class="inform">
						<fieldset>
							<legend><?php echo $lang_admin_common['Attachments']; ?></legend>
							<div class="infldset">
							<form name="alter_attachment" method="post" action="<?php echo get_link($panther_url['admin_attachments']); ?>">
								<table>
								<thead>
									<tr>
										<th class="tcl"><?php echo $lang_admin_attachments['Filename']; ?></th>
										<th class="tc2"><?php echo $lang_admin_attachments['Post ID']; ?></th>
										<th class="tc2"><?php echo $lang_admin_attachments['Filesize']; ?></th>
										<th class="tc2"><?php echo $lang_admin_attachments['Downloads']; ?></th>
										<th class="tc3"><?php echo $lang_admin_attachments['Total transfer']; ?></th>
										<th class="tcr"><?php echo $lang_admin_common['Delete']; ?></th>
									</tr>
								</thead>
								<tbody>
<?php
	foreach ($ps as $cur_item)
	{
?>
									<tr>
										<td><?php echo attach_icon($cur_item['extension']).' <a href="'.get_link($panther_url['attachment'], array($cur_item['id'])).'">'.panther_htmlspecialchars($cur_item['filename']) ?></a> <?php echo sprintf($lang_admin_attachments['By'], colourize_group($cur_item['username'], $cur_item['group_id'], $cur_item['owner'])); ?></td>
										<td class="tc2"><a href="<?php echo get_link($panther_url['post'], array($cur_item['post_id'])); ?>">#<?php echo $cur_item['post_id'] ?></a></td>
										<td class="tc2"><?php echo file_size($cur_item['size']) ?></td>
										<td class="tc2"><?php echo forum_number_format($cur_item['downloads']) ?></td>
										<td class="tc3"><?php echo file_size($cur_item['size'] * $cur_item['downloads']) ?></td>
										<td class="tcr"><input type="Submit" name="delete_attachment[<?php echo $cur_item['id']; ?>]" value="<?php echo $lang_admin_common['Delete']; ?>" /></td>
									</tr>
<?php
	}
?>
									</tbody>
								</table>
							</form>
							</div>
						</fieldset>
					</div>
				</div>
			</div>
		</div>
<?php
}
?>
	<div class="clearer"></div>
<?php	
require PANTHER_ROOT.'footer.php';