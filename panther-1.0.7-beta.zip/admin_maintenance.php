<?php

/**
 *
 * This file is part of the Panther Forum Software package.
 *
 * @link      https://www.pantherforum.org/
 * @copyright Copyright (c) Panther <https://www.pantherforum.org/>
 * @license   GNU General Public License (GPL-3.0), Version 3, 29 June 2007 <http://opensource.org/licenses/GPL-3.0>
 *
 * For full information, please see README.md, CHANGELOG.md and LICENSE.md files which are located in the root folder.
 *
 */

// Tell header.php to use the admin template
define('PANTHER_ADMIN_CONSOLE', 1);
// Tell common.php that we don't want output buffering
define('PANTHER_DISABLE_BUFFERING', 1);

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/');
	require PANTHER_ROOT.'include/common.php';
}
require PANTHER_ROOT.'include/common_admin.php';

if (!$panther_user['is_admin'])
	message($lang_common['No permission'], false, '403 Forbidden');

if ($panther_user['id'] != '2')
{
	if(!is_null($admins[$panther_user['id']]['admin_permissions']))
	{
		if ($admins[$panther_user['id']]['admin_permissions'] == '0')
			message($lang_common['No permission'], false, '403 Forbidden');
	}
}

check_authentication();

// Load the admin_maintenance.php language file
require PANTHER_ROOT.'lang/'.$admin_language.'/admin_maintenance.php';

$action = isset($_REQUEST['action']) ? panther_trim($_REQUEST['action']) : '';
$uid_merge = isset($_POST['to_merge']) ? intval($_POST['to_merge']) : '0';
$uid_stay = isset($_POST['to_stay']) ? intval($_POST['to_stay']) : '0';

if ($action == 'merge' || $action == 'confirm_merge')
{
	if ($uid_merge == $uid_stay || $uid_merge == '1' || $uid_stay == '1')
		message($lang_common['Bad request']);
	
	if ($action == 'merge')
	{
		@set_time_limit(0);

		$data = array(
			':id'	=>	$uid_merge,
		);
		
		$ps = $db->select('users', 'username, group_id, email, num_posts', $data, 'id=:id');
		if (!$ps->rowCount())
			message($lang_common['Bad request']);
		else
			$user_merge = $ps->fetch();
		
		$data = array(
			':id'	=>	$uid_stay,
		);
		
		$ps = $db->select('users', 'username, group_id, email, num_posts, num_pms', $data, 'id=:id');	
		if (!$ps->rowCount())
			message($lang_common['Bad request']);
		else
			$user_stay = $ps->fetch();
		
		$update = array(
			'owner'	=>	$uid_stay
		);
		
		$data = array(
			':uid'	=>	$uid_merge,
		);
		
		$db->update('attachments', $update, 'owner=:uid', $data);
		
		$update = array(
			'username'	=>	$user_stay['username'],
			'email'		=>	$user_stay['email'],
		);
		
		$data = array(
			':merge_username'	=>	$user_merge['username'],
			':merge_email'	=>	$user_merge['email'],
		);
		
		$db->update('bans', $update, 'username=:merge_username OR :merge_email', $data);
		
		if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
			require PANTHER_ROOT.'include/cache.php';
		
		generate_bans_cache();
		
		$update = array(
			'user_id'	=>	$uid_stay,
		);
		
		$data = array(
			':uid'	=>	$uid_merge,
		);
		
		$db->update('blocks', $update, 'user_id=:uid', $data);
		
		$update = array(
			'block_id'	=>	$uid_stay,
		);
		
		$data = array(
			':uid'	=>	$uid_merge,
		);
		
		$db->update('blocks', $update, 'block_id=:uid', $data);
		
		$update = array(
			'poster'	=>	$user_stay['username'],
		);
		
		$data = array(
			':uid'	=>	$user_merge['username'],
		);
		
		$db->update('conversations', $update, 'poster=:uid', $data);
		
		$update = array(
			'poster_id'	=>	$uid_stay,
		);
		
		$data = array(
			':uid'	=>	$uid_merge,
		);
		
		$db->update('conversations', $update, 'poster_id=:uid', $data);

		$update = array(
			'last_poster'	=>	$user_stay['username'],
		);
		
		$data = array(
			':uid'	=>	$user_merge['username'],
		);
		
		$db->update('conversations', $update, 'last_poster=:uid', $data);

		$update = array(
			'user_id'	=>	$uid_stay,
		);
		
		$data = array(
			':uid'	=>	$uid_merge,
		);
		
		$db->update('folders', $update, 'user_id=:uid', $data);
		
		$update = array(
			'user_id'	=>	$uid_stay,
		);
		
		$data = array(
			':uid'	=>	$uid_merge,
		);
		
		$db->update('folders', $update, 'user_id=:uid', $data);
		
		$update = array(
			'poster_id'	=>	$uid_stay,
			'poster'	=>	$user_stay['username'],
		);
		
		$where = array(
			':pid'	=>	$uid_merge,
		);
		
		$db->update('messages', $update, 'poster_id=:pid', $where);
		$update = array(
			'edited_by'	=>	$user_stay['username'],
		);
		
		$where = array(
			':edited'	=>	$user_merge['username']
		);

		$db->update('messages', $update, 'edited_by=:edited', $where);
		
		$data = array(
			'user_id'	=>	$uid_merge,
		);
		
		// This bit might take a while (depending on how many messages the user has)
		$num_pms = 0;
		$ps = $db->select('pms_data', 'topic_id', $data, 'user_id=:id');
		foreach ($ps as $pm)
		{
			$data = array(
				'user_id'	=>	$uid_stay,
				'topic_id'	=>	$pm['topic_id'],
			);

			// Check if this user has any PMs the same to avoid messing with the composite key of the table
			$ps1 = $db->select('pms_data', 1, $data, 'user_id=:uid AND topic_id=:tid');
			if (!$ps->roCount())
			{
				// Then we just replace the data as we're not in that conversation
				$update = array(
					'user_id'	=>	$uid_stay,
				);
				
				$data = array(
					':id'	=>	$pm['topic_id'],
					':uid'	=>	$uid_merge,
				);

				$db->update('pms_data', $update, 'user_id=:uid AND topic_id=:tid', $data);
				$data = array(
					':id'	=>	$pm['topic_id'],
				);

				$ps2 = $db->select('conversations', 'num_replies', $data, 'topic_id=:id');
				$num_pms = $num_pms + ($ps2->fetchColumn()+1); // Plus one for the topic post (which is not included in 'num_replies')
			}
			else
			{	// We are in that conversation, so we need to delete the old data row and leave ours
				$data = array(
					':id'	=>	$uid_merge,
					':tid'	=>	$pm['topic_id'],
				);

				$db->delete('pms_data', 'user_id=:id AND topic_id=:tid', $data);
			}
		}

		$update = array(
			'user_id'	=>	$user_stay['username'],
		);
		
		$where = array(
			':edited'	=>	$user_merge['username']
		);

		$db->update('messages', $update, 'edited_by=:edited', $where);

		$update = array(
			'edited_by'	=>	$user_stay['username'],
		);
		
		$where = array(
			':edited'	=>	$user_merge['username']
		);
		
		$db->update('posts', $update, 'edited_by=:edited', $where);
		
		$update = array(
			'user_id'	=>	$uid_stay,
		);
		
		$data = array(
			':id'	=>	$uid_merge,
		);
		
		$db->update('forum_subscriptions', $update, 'user_id=:id', $data);
		$update = array(
			'last_poster'	=>	$user_stay['username'],
		);
		
		$data = array(
			':user'	=>	$user_merge['username'],
		);
		
		$db->update('forums', $update, 'last_poster=:user', $data);
		$data = array(
			':username'	=>	$user_merge['username'],
		);
		
		$db->delete('login_queue', 'username=:username', $data);
		
		$update = array(
			'poster_id'	=>	$uid_stay,
			'poster'	=>	$user_stay['username'],
		);
		
		$where = array(
			':pid'	=>	$uid_merge,
		);
		
		$db->update('posts', $update, 'poster_id=:pid', $where);
		$update = array(
			'edited_by'	=>	$user_stay['username'],
		);
		
		$where = array(
			':edited'	=>	$user_merge['username']
		);
		
		$db->update('posts', $update, 'edited_by=:edited', $where);
		$update = array(
			'reported_by'	=>	$uid_stay,
		);
		
		$where = array(
			':by'	=>	$uid_merge,
		);
		
		$db->update('reports', $update, 'reported_by=:by', $where);
		$update = array(
			'given_by'	=>	$uid_stay,
		);
		
		$where = array(
			':by'	=>	$uid_merge,
		);
		
		$db->update('reputation', $update, 'given_by=:by', $where);
		$update = array(
			'ident'	=>	$user_stay['username'],
		);
		
		$where = array(
			':id'	=>	$user_merge['username'],
		);
		
		$db->update('search_cache', $update, 'ident=:id', $where);
		$update = array(
			'poster'	=>	$user_stay['username'],
		);
		
		$where = array(
			':user'	=>	$user_merge['username'],
		);
		
		$db->update('topics', $update, 'poster=:user', $where);
		$update = array(
			'last_poster'	=>	$user_stay['username'],
		);
		
		$where = array(
			':poster'	=>	$user_merge['username'],
		);
		
		$db->update('topics', $update, 'last_poster=:poster', $where);
		$update = array(
			'user_id'	=>	$uid_stay,
		);
		
		$where = array(
			':uid'	=>	$uid_merge,
		);
		
		$db->update('topic_subscriptions', $update, 'user_id=:uid', $where);
		
		$update = array(
			'user_id'	=>	$uid_stay,
		);

		$db->update('warnings', $update, 'user_id=:uid', $where);
		
		$update = array(
			'issued_by'	=>	$uid_stay,
		);

		$db->update('warnings', $update, 'issued_by=:uid', $where);
		
		$data = array(
			':uid'	=>	$uid_merge,
		);
		
		$db->delete('online', 'user_id=:uid', $data);
		
		// If the group IDs are different we go for the newer one
		if ($user_merge['group_id'] != $user_stay['group_id'])
			$user_merge['group_id'] = $user_stay['group_id'];
		
		$new_group_mod = $panther_groups[$user_merge['group_id']]['g_moderator'];
		
		$new_password = random_pass(12);
		$new_salt = random_pass(16);
		
		$update = array(
			'group_id'	=>	$user_merge['group_id'],
			'num_posts'	=>	$user_stay['num_posts']+$user_merge['num_posts'],
			'password'	=>	panther_hash($new_password.$new_salt),
			'salt'		=>	$new_salt,
			'num_pms'	=>	($user_stay['num_pms']+$num_pms) // Add all the new PMs we've just received to the total we already have
		);

		$data = array(
			':id'	=>	$uid_stay,
		);

		$db->update('users', $update, 'id=:id', $data);

		// Sort out admin restriction stuff
		if ($user_merge['group_id'] == PANTHER_ADMIN && $user_stay['group_id'] != PANTHER_ADMIN || $panther_groups[$user_merge['group_id']]['g_admin'] == '1' && $panther_groups[$user_stay['group_id']]['g_admin'] == '1')
		{
			$data = array(
				':id'	=>	$uid_merge,
			);

			$db->delete('restrictions', 'admin_id=:id', $data);
		}
		else
		{
			$data = array(
				':id'	=>	$uid_stay,
			);

			$ps = $db->select('restrictions', 1, $data, 'admin_id=:id');
			if (!$ps->rowCount())
			{
				$update = array(
					'admin_id'	=>	$uid_stay,
				);

				$data = array(
					':id'	=>	$uid_merge,
				);
				
				$db->update('restrictions', $update, 'admin_id=:id', $data);
			}
		}
		
		// So if we're not an admin, are we a moderator? If not, remove them from all the forums they (might) have moderated.
		if ($user_merge['group_id'] != PANTHER_ADMIN && $new_group_mod != '1' || $user_merge['group_id'] != $user_stay['group_id'])
		{
			$ps = $db->select('forums', 'id, moderators');
			foreach ($ps as $cur_forum)
			{
				$cur_moderators = ($cur_forum['moderators'] != '') ? unserialize($cur_forum['moderators']) : array();
				if (in_array($uid_stay, $cur_moderators))
				{
					$data = array(
						':id'	=>	$cur_forum['id'],
					);
					if ($user_merge['group_id'] != PANTHER_ADMIN && $new_group_mod != '1') // Remove ability to moderate any forums they previously did
					{
						$username = array_search($uid_stay, $cur_moderators);
						unset($cur_moderators[$username]);
						unset($cur_moderators['groups'][$uid_stay]);
						
						if (empty($cur_moderators['groups']))
							unset($cur_moderators['groups']);
						
						$cur_moderators = (!empty($cur_moderators)) ? serialize($cur_moderators) : null;
						$update = array(
							'moderators'	=>	$cur_moderators,
						);
					}
					else // Just update the group id
					{
						$cur_moderators['groups'][$id] = $user_merge['group_id'];
						$update = array(
							'moderators'	=>	serialize($cur_moderators),
						);
					}
					
					$db->update('forums', $update, 'id=:id', $data);
				}
			}
		}

		delete_avatar($uid_merge);
		require PANTHER_ROOT.'include/email.php';
		
		// Send out merged emails
		$mail_tpl = trim(file_get_contents(PANTHER_ROOT.'lang/'.$panther_user['language'].'/mail_templates/account_merged_full.tpl'));
		// The first row contains the subject
		$first_crlf = strpos($mail_tpl, "\n");
		$mail_subject = trim(substr($mail_tpl, 8, $first_crlf-8));
		$mail_message = trim(substr($mail_tpl, $first_crlf));

		$mail_message = str_replace('<username>', $user_merge['username'], $mail_message);
		$mail_message = str_replace('<password>', $new_password, $mail_message);
		$mail_message = str_replace('<admin>', $panther_user['username'], $mail_message);
		$mail_message = str_replace('<merged_user>', $user_stay['username'], $mail_message);
		$mail_message = str_replace('<board_mailer>', $panther_config['o_board_title'], $mail_message);
		panther_mail($user_merge['email'], $mail_subject, $mail_message);

		$mail_tpl = trim(file_get_contents(PANTHER_ROOT.'lang/'.$panther_user['language'].'/mail_templates/account_merged.tpl'));
		// The first row contains the subject
		$first_crlf = strpos($mail_tpl, "\n");
		$mail_subject = trim(substr($mail_tpl, 8, $first_crlf-8));
		$mail_message = trim(substr($mail_tpl, $first_crlf));

		$mail_message = str_replace('<username>', $user_stay['username'], $mail_message);
		$mail_message = str_replace('<password>', $new_password, $mail_message);
		$mail_message = str_replace('<admin>', $panther_user['username'], $mail_message);
		$mail_message = str_replace('<merged_user>', $user_merge['username'], $mail_message);
		$mail_message = str_replace('<board_mailer>', $panther_config['o_board_title'], $mail_message);
		panther_mail($user_stay['email'], $mail_subject, $mail_message);
		
		$data = array(
			':id'	=>	$uid_merge,
		);
		
		//Finally, the very last thing we do is delete the old user..
		$db->delete('users', 'id=:id', $data);

		generate_users_info_cache();
		redirect(get_link($panther_url['admin_maintenance']), $lang_admin_maintenance['users merged redirect']);
	}
	
	$data = array(
		':id'	=>	$uid_merge, 
	);

	$ps = $db->select('users', 'username', $data, 'id=:id');
	if ($ps->rowCount())
		$merge_user = panther_htmlspecialchars($ps->fetchColumn());
	else
		message($lang_common['Bad request']);
	
	$data = array(
		':id'	=>	$uid_stay,
	);

	$ps = $db->select('users', 'username', $data, 'id=:id');
	if ($ps->rowCount())
		$stay_user = panther_htmlspecialchars($ps->fetchColumn());
	else
		message($lang_common['Bad request']);
	
	$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_admin_common['Admin'], $lang_admin_common['Maintenance']);
	define('PANTHER_ACTIVE_PAGE', 'admin');
	require PANTHER_ROOT.'header.php';

	generate_admin_menu('maintenance');	
?>
<div id="exampleplugin" class="blockform">
	<h2 class="block2"><span><?php echo $lang_admin_maintenance['confirm merge 2']; ?></span></h2>
	<div class="box">
		<form id="usermerge" method="post" action="<?php echo get_link($panther_url['admin_maintenance']); ?>">
			<div class="inform">
				<input type="hidden" name="form_sent" value="1" />
				<input type="hidden" name="to_merge" value="<?php echo $uid_merge; ?>" />
				<input type="hidden" name="to_stay" value="<?php echo $uid_stay; ?>" />
				<input type="hidden" name="action" value="merge" />
				<fieldset>
					<legend><?php echo $lang_admin_maintenance['merge legend']; ?></legend>
					<div class="infldset">
						<p><?php echo $merge_user; ?></p>
					</div>
				</fieldset>
			</div>
			<div class="inform">
				<fieldset>
					<legend><?php echo $lang_admin_maintenance['merge legend 2']; ?></legend>
					<div class="infldset">
						<p><?php echo $stay_user; ?></p>
					</div>
				</fieldset>
			</div>
			<div class="fsetsubmit"><input type="submit" name="confirm_merge" value="<?php echo $lang_admin_maintenance['merge submit']; ?>" tabindex="3" /></div>
			<p class="topspace"><?php echo $lang_admin_maintenance['merge message']; ?></p>
		</form>
	</div>
	<div class="clearer"></div>
</div>
<?php
	require PANTHER_ROOT.'footer.php';
	exit;
}

if ($action == 'prune_users')
{
	$days = isset($_POST['days']) ? intval($_POST['days']) : 0;
	$posts = isset($_POST['posts']) ? intval($_POST['posts']) : 0;
	
	$data = array($posts, (time() - ($days * 86400)));
	$sql = array();
	$prune = (isset($_POST['prune_by']) && $_POST['prune_by'] == '1') ? 'registered' : 'last_visit';
	
	if (isset($_POST['admmods_delete']) && $_POST['admmods_delete'] == '1')
	{
		$sql[] = 'group_id=?';
		$data[] = PANTHER_UNVERIFIED;
	}
	else
	{
		$groups = array();
		foreach ($panther_groups as $cur_group)
		{
			if ($cur_group['g_moderator'] == '1' || $cur_group['g_id'] == PANTHER_ADMIN)
			{
				$data[] = $cur_group['g_id'];
				$groups[] = '?';
			}
		}
		$sql[] = 'AND group_id NOT IN ('.implode(',', $groups).')';
	}
	
	if (isset($_POST['verified']) && $_POST['verified'] == '0')
	{
		$sql[] = 'group_id>?';
		$data[] = PANTHER_UNVERIFIED;
	}
	else
	{
		$sql[] = 'group_id=?';
		$data[] = PANTHER_UNVERIFIED;
	}
	
	$ps = $db->run('DELETE FROM '.$db->prefix.'users WHERE id>2 AND num_posts<? AND '.$prune.'<? '.implode(' AND ', $sql), $data);
	redirect(get_link($panther_url['admin_maintenance']), sprintf($lang_admin_maintenance['Pruning complete message'], $ps->rowCount()));
}
if ($action == 'rebuild')
{
	$per_page = isset($_GET['i_per_page']) ? intval($_GET['i_per_page']) : 0;
	$start_at = isset($_GET['i_start_at']) ? intval($_GET['i_start_at']) : 0;

	// Check per page is > 0
	if ($per_page < 1)
		message($lang_admin_maintenance['Posts must be integer message']);

	@set_time_limit(0);

	// If this is the first cycle of posts we empty the search index before we proceed
	if (isset($_GET['i_empty_index']))
	{
		// This is the only potentially "dangerous" thing we can do here, so we check the referer
		confirm_referrer('admin_maintenance.php');

		$db->truncate_table('search_matches');
		$db->truncate_table('search_words');

		// Reset the sequence for the search words (not needed for SQLite)
		$ps = $db->run('ALTER TABLE '.$db->prefix.'search_words auto_increment=1');
	}

	$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_admin_maintenance['Rebuilding search index']);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo generate_page_title($page_title) ?></title>
<style type="text/css">
body {
	font: 12px Verdana, Arial, Helvetica, sans-serif;
	color: #333333;
	background-color: #FFFFFF
}

h1 {
	font-size: 16px;
	font-weight: normal;
}
</style>
</head>
<body>

<h1><?php echo $lang_admin_maintenance['Rebuilding index info'] ?></h1>
<hr />

<?php

	$query_str = '';

	require PANTHER_ROOT.'include/search_idx.php';
	
	$data = array(
		':start'	=>	$start_at,
		':limit'	=>	$per_page,
	);

	// Fetch posts to process this cycle
	$ps = $db->run('SELECT p.id, p.message, t.subject, t.first_post_id FROM '.$db->prefix.'posts AS p INNER JOIN '.$db->prefix.'topics AS t ON t.id=p.topic_id WHERE p.id >= :start ORDER BY p.id ASC LIMIT :limit', $data);

	$end_at = 0;
	foreach ($ps as $cur_item)
	{
		echo '<p><span>'.sprintf($lang_admin_maintenance['Processing post'], $cur_item['id']).'</span></p>'."\n";

		if ($cur_item['id'] == $cur_item['first_post_id'])
			update_search_index('post', $cur_item['id'], $cur_item['message'], $cur_item['subject']);
		else
			update_search_index('post', $cur_item['id'], $cur_item['message']);

		$end_at = $cur_item['id'];
	}

	// Check if there is more work to do
	if ($end_at > 0)
	{
		$data = array(
			':id'	=>	$end_at,
		);
		$ps = $db->run('SELECT id FROM '.$db->prefix.'posts WHERE id > :id ORDER BY id ASC LIMIT 1', $data);

		if ($ps->rowCount())
			$query_str = '?action=rebuild&i_per_page='.$per_page.'&i_start_at='.$ps->fetchColumn();
	}

	$db->end_transaction();
	$db->close();

	exit('<script type="text/javascript">window.location="'.get_link($panther_url['admin_maintenance']).$query_str.'"</script><hr /><p>'.sprintf($lang_admin_maintenance['Javascript redirect failed'], '<a href="'.get_link($panther_url['admin_maintenance']).$query_str.'">'.$lang_admin_maintenance['Click here'].'</a>').'</p>');
	exit;
}

if ($action == 'prune')
{
	$prune_from = panther_trim($_POST['prune_from']);
	$prune_sticky = intval($_POST['prune_sticky']);

	if (isset($_POST['prune_comply']))
	{
		confirm_referrer('admin_maintenance.php');

		$prune_days = intval($_POST['prune_days']);
		$prune_date = ($prune_days) ? time() - ($prune_days * 86400) : -1;

		@set_time_limit(0);

		if ($prune_from == 'all')
		{
			$ps = $db->select('forums', 'id');
			$num_forums = $ps->rowCount();

			for ($i = 0; $i < $num_forums; ++$i)
			{
				$fid = $ps->fetchColumn();

				prune($fid, $prune_sticky, $prune_date);
				update_forum($fid);
			}
		}
		else
		{
			$prune_from = intval($prune_from);
			prune($prune_from, $prune_sticky, $prune_date);
			update_forum($prune_from);
		}

		// Locate any "orphaned redirect topics" and delete them
		$ps = $db->run('SELECT t1.id FROM '.$db->prefix.'topics AS t1 LEFT JOIN '.$db->prefix.'topics AS t2 ON t1.moved_to=t2.id WHERE t2.id IS NULL AND t1.moved_to IS NOT NULL');
		$num_orphans = $ps->rowCount();

		if ($num_orphans)
		{
			for ($i = 0; $i < $num_orphans; ++$i)
			{
				$orphans[] = $ps->fetchColumn();
				$markers[] = '?';
			}

			$db->run('DELETE FROM '.$db->prefix.'topics WHERE id IN('.implode(',', $markers).')', $orphans);
		}

		redirect(get_link($panther_url['admin_maintenance']), $lang_admin_maintenance['Posts pruned redirect']);
	}

	$prune_days = panther_trim($_POST['req_prune_days']);
	if ($prune_days == '' || preg_match('%[^0-9]%', $prune_days))
		message($lang_admin_maintenance['Days must be integer message']);

	$prune_date = time() - ($prune_days * 86400);

	// Concatenate together the query for counting number of topics to prune
	$data = array(
		':prune'	=>	$prune_date,
	);

	$sql = 'SELECT COUNT(id) FROM '.$db->prefix.'topics WHERE last_post<:prune AND moved_to IS NULL';

	if ($prune_sticky == '0')
		$sql .= ' AND sticky=0';

	if ($prune_from != 'all')
	{
		$prune_from = intval($prune_from);
		$sql .= ' AND forum_id=:fid';
		$data[':fid'] = $prune_from;
		
		$select = array(
			':id'	=>	$prune_from,
		);

		// Fetch the forum name (just for cosmetic reasons)
		$ps = $db->select('forums', 'forum_name', $select, 'id=:id');
		$forum = '"'.panther_htmlspecialchars($ps->fetchColumn()).'"';
	}
	else
		$forum = $lang_admin_maintenance['All forums'];

	$ps = $db->run($sql, $data);
	$num_topics = $ps->fetchColumn();

	if (!$num_topics)
		message(sprintf($lang_admin_maintenance['No old topics message'], $prune_days));

	$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_admin_common['Admin'], $lang_admin_common['Prune']);
	define('PANTHER_ACTIVE_PAGE', 'admin');
	require PANTHER_ROOT.'header.php';

	generate_admin_menu('maintenance');
?>
	<div class="blockform">
		<h2><span><?php echo $lang_admin_maintenance['Prune head'] ?></span></h2>
		<div class="box">
			<form method="post" action="<?php echo get_link($panther_url['admin_maintenance']); ?>">
				<input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>" />
				<div class="inform">
					<input type="hidden" name="action" value="prune" />
					<input type="hidden" name="prune_days" value="<?php echo $prune_days ?>" />
					<input type="hidden" name="prune_sticky" value="<?php echo $prune_sticky ?>" />
					<input type="hidden" name="prune_from" value="<?php echo $prune_from ?>" />
					<fieldset>
						<legend><?php echo $lang_admin_maintenance['Confirm prune subhead'] ?></legend>
						<div class="infldset">
							<p><?php printf($lang_admin_maintenance['Confirm prune info'], $prune_days, $forum, forum_number_format($num_topics)) ?></p>
							<p class="warntext"><?php echo $lang_admin_maintenance['Confirm prune warn'] ?></p>
						</div>
					</fieldset>
				</div>
				<p class="buttons"><input type="submit" name="prune_comply" value="<?php echo $lang_admin_common['Prune'] ?>" /><a href="javascript:history.go(-1)"><?php echo $lang_admin_common['Go back'] ?></a></p>
			</form>
		</div>
	</div>
	<div class="clearer"></div>
</div>
<?php
	require PANTHER_ROOT.'footer.php';
	exit;
}

if ($action == 'add_user')
{
	$errors = array();

	$username = isset($_POST['username']) ? panther_trim($_POST['username']) : '';
	$random_pass = isset($_POST['random_pass']) && $_POST['random_pass'] == '1' ? 1 : 0;
	$email = strtolower(panther_trim($_POST['email']));
	$password_salt = random_pass(16);
	
	if ($random_pass == '1')
	{
		$password1 = random_pass(12);
		$password2 = $password1;
	}
	else
	{
		$password1 = panther_trim($_POST['password1']);
		$password2 = panther_trim($_POST['password2']);
	}
	
	require PANTHER_ROOT.'lang/'.$panther_user['language'].'/prof_reg.php';
	
	// Validate username and passwords
	check_username($username);

	if (panther_strlen($password1) < 6)
		$errors[] = $lang_prof_reg['Pass too short'];
	else if ($password1 != $password2)
		$errors[] = $lang_prof_reg['Pass not match'];

	// Validate email
	require PANTHER_ROOT.'include/email.php';

	if (!is_valid_email($email))
		$errors[] = $lang_common['Invalid email'];

	// Check if it's a banned email address
	if (is_banned_email($email))
	{
		if ($panther_config['p_allow_banned_email'] == '0')
			$errors[] = $lang_prof_reg['Banned email'];
	}
	
	if ($panther_config['p_allow_dupe_email'] == '0')
	{
		$data = array(
			':email'	=>	$email,
		);

		$ps = $db->select('users', 1, $data, 'email=:email');
		if ($ps->rowCount())
			$errors[] = $lang_prof_reg['Dupe email'];
	}
	
	if (empty($errors))
	{
		// Insert the new user into the database. We do this now to get the last inserted ID for later use
		$now = time();

		$initial_group_id = ($random_pass == 0) ? $panther_config['o_default_user_group'] : PANTHER_UNVERIFIED;
		$password_hash = panther_hash($password1.$password_salt);
		
		// Add the user
		$insert = array(
			'username'	=>	$username,
			'group_id'	=>	$initial_group_id,
			'password'	=>	$password_hash,
			'salt'		=>	$password_salt,
			'email'		=>	$email,
			'email_setting'	=>	$panther_config['o_default_email_setting'],
			'timezone'	=>	$panther_config['o_default_timezone'],
			'dst'		=>	$panther_config['o_default_dst'],
			'language'	=>	$panther_config['o_default_lang'],
			'style'		=>	$panther_config['o_default_style'],
			'registered'	=>	$now,
			'registration_ip'	=>	get_remote_address(),
			'last_visit'	=>	$now,
		);
		
		$db->insert('users', $insert);
		$new_uid = $db->lastInsertId($db->prefix.'users');
		
		if ($random_pass == '1')
		{
			// Load the "welcome" template
			$mail_tpl = trim(file_get_contents(PANTHER_ROOT.'lang/'.$panther_user['language'].'/mail_templates/welcome.tpl'));

			// The first row contains the subject
			$first_crlf = strpos($mail_tpl, "\n");
			$mail_subject = trim(substr($mail_tpl, 8, $first_crlf-8));
			$mail_message = trim(substr($mail_tpl, $first_crlf));

			$mail_subject = str_replace('<board_title>', $panther_config['o_board_title'], $mail_subject);
			$mail_message = str_replace('<base_url>', get_base_url().'/', $mail_message);
			$mail_message = str_replace('<username>', $username, $mail_message);
			$mail_message = str_replace('<password>', $password1, $mail_message);
			$mail_message = str_replace('<login_url>', get_link($panther_url['login']), $mail_message);
			$mail_message = str_replace('<board_mailer>', $panther_config['o_board_title'], $mail_message);

			panther_mail($email, $mail_subject, $mail_message);
		}
		
		// Regenerate the users info cache
		if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
			require PANTHER_ROOT.'include/cache.php';

		generate_users_info_cache();
		redirect(get_link($panther_url['admin_maintenance']), $lang_admin_maintenance['User created message']);
	}
}

// Get the first post ID from the db
$ps = $db->select('posts', 'id', array(), '', 'id ASC LIMIT 1');
if ($ps->rowCount())
	$first_id = $ps->fetchColumn();

$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_admin_common['Admin'], $lang_admin_common['Maintenance']);
define('PANTHER_ACTIVE_PAGE', 'admin');
require PANTHER_ROOT.'header.php';

$ps = $db->run('SELECT c.id AS cid, c.cat_name, f.id AS fid, f.forum_name FROM '.$db->prefix.'categories AS c INNER JOIN '.$db->prefix.'forums AS f ON c.id=f.cat_id WHERE f.redirect_url IS NULL ORDER BY c.disp_position, c.id, f.disp_position');

$ps = $db->run('SELECT u.id, u.username, g.g_title FROM '.$db->prefix.'users AS u INNER JOIN '.$db->prefix.'groups AS g ON u.group_id=g.g_id WHERE u.id!=1 ORDER BY u.id ASC');	
foreach ($ps as $result)
	$options[] = '<option value="'.$result['id'].'">'.panther_htmlspecialchars($result['username'].' <'.panther_htmlspecialchars($result['g_title']).'>').'</option>';
	
generate_admin_menu('maintenance');
?>
	<div class="blockform">
		<h2><span><?php echo $lang_admin_maintenance['Maintenance head'] ?></span></h2>
		<div class="box">
			<form method="get" action="<?php echo get_link($panther_url['admin_maintenance']); ?>">
				<input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>" />
				<div class="inform">
					<input type="hidden" name="action" value="rebuild" />
					<fieldset>
						<legend><?php echo $lang_admin_maintenance['Rebuild index subhead'] ?></legend>
						<div class="infldset">
							<p><?php printf($lang_admin_maintenance['Rebuild index info'], '<a href="'.get_link($panther_url['admin_options']).'">'.$lang_admin_common['Maintenance mode'].'</a>') ?></p>
							<table class="aligntop">
								<tr>
									<th scope="row"><?php echo $lang_admin_maintenance['Posts per cycle label'] ?></th>
									<td>
										<input type="text" name="i_per_page" size="7" maxlength="7" value="300" tabindex="1" />
										<span><?php echo $lang_admin_maintenance['Posts per cycle help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_maintenance['Starting post label'] ?></th>
									<td>
										<input type="text" name="i_start_at" size="7" maxlength="7" value="<?php echo (isset($first_id)) ? $first_id : 0 ?>" tabindex="2" />
										<span><?php echo $lang_admin_maintenance['Starting post help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_maintenance['Empty index label'] ?></th>
									<td class="inputadmin">
										<label><input type="checkbox" name="i_empty_index" value="1" tabindex="3" checked="checked" />&#160;&#160;<?php echo $lang_admin_maintenance['Empty index help'] ?></label>
									</td>
								</tr>
							</table>
							<p class="topspace"><?php echo $lang_admin_maintenance['Rebuild completed info'] ?></p>
							<div class="fsetsubmit"><input type="submit" name="rebuild_index" value="<?php echo $lang_admin_maintenance['Rebuild index'] ?>" tabindex="4" /></div>
						</div>
					</fieldset>
				</div>
			</form>
			<form method="post" action="<?php echo get_link($panther_url['admin_maintenance']); ?>" onsubmit="return process_form(this)">
				<div class="inform">
					<input type="hidden" name="action" value="prune" />
					<fieldset>
						<legend><?php echo $lang_admin_maintenance['Prune subhead'] ?></legend>
						<div class="infldset">
							<table class="aligntop">
								<tr>
									<th scope="row"><?php echo $lang_admin_maintenance['Days old label'] ?></th>
									<td>
										<input type="text" name="req_prune_days" size="3" maxlength="3" tabindex="5" />
										<span><?php echo $lang_admin_maintenance['Days old help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_maintenance['Prune sticky label'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="prune_sticky" value="1" tabindex="6" checked="checked" />&#160;<strong><?php echo $lang_admin_common['Yes'] ?></strong></label>
										<label class="conl"><input type="radio" name="prune_sticky" value="0" />&#160;<strong><?php echo $lang_admin_common['No'] ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_maintenance['Prune sticky help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_maintenance['Prune from label'] ?></th>
									<td>
										<select name="prune_from" tabindex="7">
											<option value="all"><?php echo $lang_admin_maintenance['All forums'] ?></option>
<?php
	$cur_category = 0;
	foreach ($ps as $cur_forum)
	{
		if ($cur_forum['cid'] != $cur_category) // Are we still in the same category?
		{
			if ($cur_category)
				echo "\t\t\t\t\t\t\t\t\t\t\t".'</optgroup>'."\n";

			echo "\t\t\t\t\t\t\t\t\t\t\t".'<optgroup label="'.panther_htmlspecialchars($cur_forum['cat_name']).'">'."\n";
			$cur_category = $cur_forum['cid'];
		}

		echo "\t\t\t\t\t\t\t\t\t\t\t\t".'<option value="'.$cur_forum['fid'].'">'.panther_htmlspecialchars($cur_forum['forum_name']).'</option>'."\n";
	}
?>
											</optgroup>
										</select>
										<span><?php echo $lang_admin_maintenance['Prune from help'] ?></span>
									</td>
								</tr>
							</table>
							<p class="topspace"><?php printf($lang_admin_maintenance['Prune info'], '<a href="'.get_link($panther_url['admin_options']).'">'.$lang_admin_common['Maintenance mode'].'</a>') ?></p>
							<div class="fsetsubmit"><input type="submit" name="prune" value="<?php echo $lang_admin_common['Prune'] ?>" tabindex="8" /></div>
						</div>
					</fieldset>
				</div>
			</form>
		</div>
	</div>
	<div class="blockform">
		<h2 class="block2"><span><?php echo $lang_admin_maintenance['user merge legend'] ?></span></h2>
		<div class="box">
			<form id="usermerge" method="post" action="<?php echo get_link($panther_url['admin_maintenance']); ?>">
			<input type="hidden" name="form_sent" value="1" />
			<input type="hidden" name="action" value="confirm_merge" />
			<div class="inform">
				<fieldset>
					<legend><?php echo $lang_admin_maintenance['user merge legend']; ?></legend>
					<div class="infldset">
						<table class="aligntop" cellspacing="0">
							<tr>
								<td>
									<select name="to_merge" tabindex="3">
									<?php echo implode('', $options); ?>
									</select>
									<span><?php echo $lang_admin_maintenance['merge legend']; ?></span>
								</td>
							</tr>
							<tr>
								<td>
									<select name="to_stay" tabindex="3">
									<?php echo implode('', $options); ?>
									</select>
									<span><?php echo sprintf($lang_admin_maintenance['merge help'], '<a href="'.get_link($panther_url['admin_options']).'">'.$lang_admin_common['Maintenance mode'].'</a>'); ?></span>
								</td>
							</tr>
						</table>
					</div>
				</fieldset>
			</div>
			<div class="fsetsubmit"><input type="submit" name="submit" value="<?php echo $lang_admin_maintenance['continue']; ?>" tabindex="3" /></div>
			</form>
		</div>
	</div>
	<div class="blockform">
		<h2 class="block2"><span><?php echo $lang_admin_maintenance['User prune head'] ?></span></h2>
		<div class="box">
			<form id="example" method="post" action="<?php echo get_link($panther_url['admin_maintenance']); ?>">
				<input name="action" type="hidden" value="prune_users" />
				<div class="inform">
					<fieldset>
						<legend><?php echo $lang_admin_maintenance['Settings subhead'] ?></legend>
						<div class="infldset">
						<table class="aligntop">
							<tr>
								<th scope="row"><?php echo $lang_admin_maintenance['Prune by label'] ?></th>
								<td>
									<input type="radio" name="prune_by" value="1" checked="checked" />&#160;<strong><?php echo $lang_admin_maintenance['Registered date'] ?></strong>&#160;&#160;&#160;<input type="radio" name="prune_by" value="0" />&#160;<strong><?php echo $lang_admin_maintenance['Last login'] ?></strong>
									<span><?php echo $lang_admin_maintenance['Prune help'] ?></span>
								</td>
							</tr>
							<tr>
								<th scope="row"><?php echo $lang_admin_maintenance['Minimum days label'] ?></th>
								<td>
									<input type="text" name="days" value="28" size="3" tabindex="1" />
									<span><?php echo $lang_admin_maintenance['Minimum days help'] ?></span>
								</td>
							</tr>
							<tr>
								<th scope="row"><?php echo $lang_admin_maintenance['Maximum posts label'] ?></th>
								<td>
									<input type="text" name="posts" value="1"  size="7" tabindex="2" />
									<span><?php echo $lang_admin_maintenance['Maximum posts help'] ?></span>
								</td>
							</tr>
							<tr>
								<th scope="row"><?php echo $lang_admin_maintenance['Delete admins and mods label'] ?></th>
								<td>
									<input type="radio" name="admmods_delete" value="1" />&#160;<strong><?php echo $lang_admin_common['Yes'] ?></strong>&#160;&#160;&#160;<input type="radio" name="admmods_delete" value="0" checked="checked" />&#160;<strong><?php echo $lang_admin_common['No'] ?></strong>
									<span><?php echo $lang_admin_maintenance['Delete admins and mods help'] ?></span>
								</td>
							</tr>
							<tr>
								<th scope="row"><?php echo $lang_admin_maintenance['User status label'] ?></th>
								<td>
									<input type="radio" name="verified" value="1" />&#160;<strong><?php echo $lang_admin_maintenance['Delete any'] ?></strong>&#160;&#160;&#160;<input type="radio" name="verified" value="0" />&#160;<strong><?php echo $lang_admin_maintenance['Delete only verified'] ?></strong>&#160;&#160;&#160;<input type="radio" name="verified" value="2" checked="checked" />&#160;<strong><?php echo $lang_admin_maintenance['Delete only unverified'] ?></strong>
									<span><?php echo $lang_admin_maintenance['User status help'] ?></span>
								</td>
							</tr>
						</table>
						</div>
					</fieldset>
				</div>
			<p class="submitend"><input type="submit" name="prune" value="<?php echo $lang_admin_common['Prune'] ?>" tabindex="3" /></p>
			</form>
		</div>
		<h2 class="block2"><span><?php echo $lang_admin_maintenance['Add user head'] ?></span></h2>
		<?php
		if (isset($errors))
		{
			?>
			<div id="posterror" style="border-style:none">
				<div class="box">
					<legend><?php echo $lang_register['Registration errors'] ?></legend>
					<div class="inbox error-info infldset">
						<p><?php echo $lang_register['Registration errors info'] ?></p>
							<ul class="error-list">
							<?php
								foreach ($errors as $cur_error)
									echo "\t\t\t\t".'<li><strong>'.$cur_error.'</strong></li>'."\n";
							?>
							</ul>
					</div>
				</div>
			</div>
			<br />
			<?php
		}
		?>
		<div class="box">
			<form id="example" method="post" action="<?php echo get_link($panther_url['admin_maintenance']); ?>">
				<input name="action" type="hidden" value="add_user" />
				<div class="inform">
					<fieldset>
						<legend><?php echo $lang_admin_maintenance['Settings subhead'] ?></legend>
						<div class="infldset">
						<table class="aligntop">
							<tr>
								<th scope="row"><?php echo $lang_common['Username'] ?></th>
								<td>
									<input type="text" name="username" value="<?php if (isset($_POST['username'])) echo panther_htmlspecialchars($_POST['username']); ?>" size="25" tabindex="4" />
								</td>
							</tr>
							<tr>
								<th scope="row"><?php echo $lang_common['Email'] ?></th>
								<td>
									<input type="text" name="email" value="<?php if (isset($_POST['email'])) echo panther_htmlspecialchars($_POST['email']); ?>" size="50" tabindex="5" />
								</td>
							</tr>
							<tr>
								<th scope="row"><?php echo $lang_admin_maintenance['Generate random password label'] ?></th>
								<td>
									<input type="radio" name="random_pass" value="1"<?php if ($panther_config['o_regs_verify'] == '1') echo ' checked="checked"'; ?>/>&#160;<strong><?php echo $lang_admin_common['Yes'] ?></strong>&#160;&#160;&#160;<input type="radio" name="random_pass" value="0"<?php if ($panther_config['o_regs_verify'] == '0') echo ' checked="checked"'; ?> />&#160;<strong><?php echo $lang_admin_common['No'] ?></strong>
									<span><?php echo $lang_admin_maintenance['Generate random password help'] ?></span>
								</td>
							</tr>
							<tr>
								<th scope="row"><?php echo $lang_common['Password'] ?></th>
								<td>
									<input type="password" name="password1" value="<?php if (isset($_POST['password1'])) echo panther_htmlspecialchars($_POST['password1']); ?>" size="25" tabindex="6" />
									<span><?php echo $lang_admin_maintenance['Password help'] ?></span>
								</td>
							</tr>
							<tr>
								<th scope="row"><?php echo $lang_admin_maintenance['Confirm pass'] ?></th>
								<td>
									<input type="password" name="password2" value="<?php if (isset($_POST['password2'])) echo panther_htmlspecialchars($_POST['password2']); ?>" size="25" tabindex="6" />
									<span><?php echo $lang_admin_maintenance['Pass info'] ?></span>
								</td>
							</tr>
						</table>
						</div>
					</fieldset>
				</div>
				<p class="submitend"><input type="submit" name="add_user" value="<?php echo $lang_admin_common['Add'] ?>" tabindex="7" /></p>
			</form>
		</div>
	</div>
	<div class="clearer"></div>
</div>
<?php
require PANTHER_ROOT.'footer.php';