<?php

/**
 *
 * This file is part of the Panther Forum Software package.
 *
 * @link      https://www.pantherforum.org/
 * @copyright Copyright (c) Panther <https://www.pantherforum.org/>
 * @license   GNU General Public License (GPL-3.0), Version 3, 29 June 2007 <http://opensource.org/licenses/GPL-3.0>
 *
 * For full information, please see README.md, CHANGELOG.md and LICENSE.md files which are located in the root folder.
 *
 */

// Tell header.php to use the admin template
define('PANTHER_ADMIN_CONSOLE', 1);

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/');
	require PANTHER_ROOT.'include/common.php';
}

require PANTHER_ROOT.'include/common_admin.php';

$action = isset($_GET['action']) ? panther_htmlspecialchars($_GET['action']) : null;
$id = isset($_GET['id']) ? intval($_GET['id']) : '0';
$page = (!isset($_GET['p']) || $_GET['p'] <= '1') ? '1' : intval($_GET['p']);

if (($panther_user['is_admmod'] && $panther_user['g_mod_cp'] == '0' && !$panther_user['is_admin']) || !$panther_user['is_admmod'])
	message($lang_common['No permission'], false, '403 Forbidden');

check_authentication();

// Load the admin_announcements.php language file
require PANTHER_ROOT.'lang/'.$admin_language.'/admin_announcements.php';

if (isset($_POST['form_sent']))
{
	confirm_referrer('admin_announcements.php');
	$action = isset($_POST['action']) ? panther_trim($_POST['action']) : '';

	if ($action == 'add' || $action == 'edit')
	{
		$forums = isset($_POST['forums']) && is_array($_POST['forums']) ? array_map('intval', $_POST['forums']) : array();

		if (empty($forums))
			message($lang_common['Bad request']);

		$announcement = isset($_POST['message']) ? panther_trim($_POST['message']) : '';
		$title = isset($_POST['title']) ? panther_trim($_POST['title']) : '';
		$id = isset($_POST['id']) ? intval($_POST['id']) : 0;

		if (strlen($title) > 50)
			message($lang_admin_announcements['title too long']);

		if (strlen($announcement) < 1 || strlen($title) < 1)
			message($lang_common['Bad request']);

		$insert = array(
			'message'	=>	$announcement,
			'forum_id'	=>	implode(',', $forums),
			'user_id'	=>	$panther_user['id'],
			'subject'		=>	$title,
		);

		if ($action == 'add')
		{
			$db->insert('announcements', $insert);
			$id = $db->lastInsertId($db->prefix.'announcements');

			$redirect_msg = $lang_admin_announcements['added redirect'];
		}
		else
		{
			if ($id < 1)
				message($lang_common['Bad request']);

			$data = array(
				':id'	=>	$id,
			);
			
			$db->update('announcements', $insert, 'id=:id', $data);
			$redirect_msg = $lang_admin_announcements['edit redirect'];
		}

		if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
			require PANTHER_ROOT.'include/cache.php';

		generate_announcements_cache();
		redirect(get_link($panther_url['announcement_fid'], array($id, $forums[0], url_friendly($title))), $redirect_msg);
	}
	else if ($action == 'delete')
	{
		$id = isset($_POST['id']) ? intval($_POST['id']) : 0;
		if ($id < 1)
			message($lang_common['Bad request']);
		
		$data = array(
			':id'	=>	$id,
		);
		
		$db->delete('announcements', 'id=:id', $data);
		
		if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
			require PANTHER_ROOT.'include/cache.php';
		
		redirect(get_link($panther_url['admin_announcements']), $lang_admin_announcements['delete redirect']);
	}
	else
		message($lang_common['Bad request']);
}

$ps = $db->select('announcements', 'COUNT(id)');
$total = $ps->fetchColumn();
$num_pages = ceil($total/$panther_config['o_disp_topics_default']);
if ($page > $num_pages) $page = 1;
$start_from = intval($panther_config['o_disp_topics_default'])*($page-1);

$data = array(
	':start'	=>	$start_from,
	':limit'	=>	$panther_config['o_disp_topics_default'],
);

$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_admin_common['Admin'], $lang_admin_common['Announcements']);
define('PANTHER_ACTIVE_PAGE', 'admin');
require PANTHER_ROOT.'header.php';

generate_admin_menu('announcements');

if ($action == 'add' || $action == 'edit' && $id > 0)
{
	if ($action == 'edit')
	{
		$data = array(
			':id'	=>	$id,
		);

		$ps = $db->select('announcements', 'message, forum_id, subject', $data, 'id=:id');
		if (!$ps->rowCount())
			message($lang_common['Bad request']);

		$cur_announcement = $ps->fetch();
	}
	else
	{
		$cur_announcement = array(
			'forum_id'	=>	0,
			'subject'		=>	'',
			'message'	=>	'',
		);
	}

	// Display all the categories and forums
	$select = '';
	$ps = $db->run('SELECT c.id AS cid, c.cat_name, f.id AS fid, f.forum_name FROM '.$db->prefix.'categories AS c INNER JOIN '.$db->prefix.'forums AS f ON c.id=f.cat_id WHERE f.redirect_url IS NULL ORDER BY c.disp_position, c.id, f.disp_position');
	if ($ps->rowCount())
	{
		$count = 0;
		$cur_index = 4;
		$cur_category = 0;
		foreach ($ps as $cur_forum)
		{
			if ($cur_forum['cid'] != $cur_category) // A new category since last iteration?
			{
				$select .= '</optgroup>';
				$select .= "\t\t\t\t\t\t".'<optgroup label="'.panther_htmlspecialchars($cur_forum['cat_name']).'">'."\n";
				$cur_category = $cur_forum['cid'];
			}
				$select .= '<option value="'.$cur_forum['fid'].'"'.((in_array($cur_forum['fid'], explode(',', $cur_announcement['forum_id']))) ? ' selected="selected"' : null).'>'.panther_htmlspecialchars($cur_forum['forum_name']).'</option>'."\n";
		}
			$select .= "\t\t\t\t\t\t".'</optgroup>'."\n\t\t\t\t\t".'</select>'."\n";
	}
?>
	<div class="blockform">
		<h2><span><?php echo $lang_admin_announcements['announcements'] ?></span></h2>
		<div class="box">
			<form id="restrictions2" method="post" action="<?php echo get_link($panther_url['admin_announcements']); ?>">
				<input type="hidden" name="form_sent" value="1" />
				<input name="csrf_token" type="hidden" value="<?php echo generate_csrf_token(); ?>" />
				<input type="hidden" name="action" value="<?php echo $action; ?>" />
				<?php if ($action == 'edit'): ?><input type="hidden" name="id" value="<?php echo $id; ?>" /><?php endif; ?>
				<div class="inform">
					<fieldset>
						<legend><?php echo $lang_admin_announcements['announcements header']; ?></legend>
						<div class="infldset">
							<table class="aligntop">
								<tr>
									<th scope="row"><?php echo $lang_admin_announcements['title'] ?></th>
									<td>
										<input type="text" value="<?php echo panther_htmlspecialchars($cur_announcement['subject']); ?>" name="title" size="45" maxlength="50" tabindex="1" />
										<span><?php echo $lang_admin_announcements['title help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_announcements['forum'] ?></th>
									<td>
										<select multiple="multiple" size="10" name="forums[]">
											<option value="0"<?php if ($cur_announcement['forum_id'] == '0') echo ' selected="selected"'; ?>><?php echo $lang_admin_announcements['all forums'] ?></option>
											<?php echo $select; ?>
											</select>
										<span><?php echo $lang_admin_announcements['forum help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_announcements['announcement'] ?></th>
									<td>
										<textarea rows="20" cols="80" name="message"><?php echo panther_htmlspecialchars($cur_announcement['message']); ?></textarea>
										<span><?php echo $lang_admin_announcements['announcement help'] ?></span>
									</td>
								</tr>
							</table>
						</div>
					</fieldset>
				</div>
				<p class="submitend"><input type="submit" name="submit" value="<?php echo $lang_common['Submit']; ?>" tabindex="43" /></p>
			</form>
		</div>
	</div>
	<div class="clearer"></div>
</div>
</div>
<?php 
}
elseif ($action == 'delete' && $id > 0)
{
?>
	<div class="blockform">
		<h2><span><?php echo $lang_admin_announcements['announcements'] ?></span></h2>
		<div class="box">
			<form id="restrictions2" method="post" action="<?php echo get_link($panther_url['delete_announcement']); ?>">
				<input type="hidden" name="form_sent" value="1" />
				<input name="csrf_token" type="hidden" value="<?php echo generate_csrf_token(); ?>" />
				<input type="hidden" name="action" value="delete" />
				<input type="hidden" name="id" value="<?php echo $id; ?>" />			
				<div class="inform">
						<div class="infldset">
							<div class="forminfo">
								<p><strong><?php echo $lang_admin_announcements['delete announcement']; ?></strong></p>
							</div>		
						</div>
				</div>
				<p class="buttons"><input type="submit" name="delete" value="<?php echo $lang_admin_common['Delete']; ?>" /> <a href="javascript:history.go(-1)"><?php echo $lang_common['Go back']; ?></a></p>
			</form>

		</div>
	</div>
	<div class="clearer"></div>
</div>
</div>
<?php
}
else
{
	$announcements = array();
	$ps = $db->run('SELECT a.subject, a.forum_id, a.user_id, u.username, u.group_id, a.id FROM '.$db->prefix.'announcements AS a INNER JOIN '.$db->prefix.'users AS u ON a.user_id=u.id ORDER BY a.id DESC LIMIT :start, :limit', $data);
	foreach ($ps as $announcement)
	{
		$forum_names = array();
		$ids = explode(',', $announcement['forum_id']);
		foreach ($ids as $id)
		{
			$data = array(
				':id'	=>	$id,
			);

			$ps1 = $db->select('forums', 'forum_name', $data, 'id=:id');
			$forum_names[] = $ps1->fetchColumn();
		}

		$announcements[] = '<tr><th scope="row"><a href="'.get_link($panther_url['edit_announcement'], array($announcement['id'])).'" tabindex="9">'.$lang_admin_announcements['edit announcement'].'</a> | <a href="'.get_link($panther_url['delete_announcement'], array($announcement['id'])).'" tabindex="10">'.$lang_admin_announcements['delete announcement 2'].'</a></th><td><strong>'.panther_htmlspecialchars($announcement['subject']).'</strong><br />'.sprintf($lang_admin_announcements['by'], colourize_group($announcement['username'], $announcement['group_id'], $announcement['user_id'])).'</td></tr>';
	}
?>
<div id="vf" class="blocktable">
	<div class="blockform">
		<h2><span><?php echo $lang_admin_announcements['announcements'] ?></span> <span class="pages-label"><?php echo $lang_common['Pages'].' '.paginate($num_pages, $page, 'admin_announcements.php?') ?></span></h2>
		<div class="box">
<div class="fakeform">
				<div class="inform">
					<fieldset>
						<legend><?php echo $lang_admin_announcements['title']; ?></legend>
						<div class="infldset">
							<table>
								<tr><th scope="row"><a href="<?php echo get_link($panther_url['add_announcement']); ?>" tabindex="1"><?php echo $lang_admin_announcements['add new']; ?></a></th><td><?php echo $lang_admin_announcements['add new label']; ?></td></tr>
<?php echo implode("\n\t\t\t\t\t\t\t\t", $announcements); ?>
							</table>
						</div>
					</fieldset>
				</div>
			</div>
		</div>
	</div>
	<div class="clearer"></div>
</div>
</div>
</div>
<?php
}

require PANTHER_ROOT.'footer.php';