<?php

/**
 *
 * This file is part of the Panther Forum Software package.
 *
 * @link      https://www.pantherforum.org/
 * @copyright Copyright (c) Panther <https://www.pantherforum.org/>
 * @license   GNU General Public License (GPL-3.0), Version 3, 29 June 2007 <http://opensource.org/licenses/GPL-3.0>
 *
 * For full information, please see README.md, CHANGELOG.md and LICENSE.md files which are located in the root folder.
 *
 */

// Tell header.php to use the admin template
define('PANTHER_ADMIN_CONSOLE', 1);

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/');
	require PANTHER_ROOT.'include/common.php';
}

require PANTHER_ROOT.'include/common_admin.php';

if (!$panther_user['is_admin'])
	message($lang_common['No permission'], false, '403 Forbidden');

// Load the admin_addons.php language file
require PANTHER_ROOT.'lang/'.$admin_language.'/admin_addons.php';

check_authentication();

if ($panther_user['id'] != '2')
{
	if(!is_null($admins[$panther_user['id']]['admin_addons']))
	{
		if ($admins[$panther_user['id']]['admin_addons'] == '0')
			message($lang_common['No permission']);
	}
}

if (isset($_POST['delete']))
{
	$addons = is_array($_POST['del_addons']) ? array_map('panther_trim', $_POST['del_addons']) : array();

	if (empty($addons))
		message($lang_admin_addons['No addons']);

	foreach ($addons as $addon)
	{
		// Make sure it doesn't look suspicious
		if (file_exists(PANTHER_ROOT.'addons/'.$addon.'.php') && (preg_match('/^[a-z0-9-_]+$/i', $addon)) && !preg_match('/^[\/\.@[{}]!"£\|<>:]+$/i', $addon))
			unlink(PANTHER_ROOT.'addons/'.$addon.'.php');
	}
	
	redirect(get_link($panther_url['admin_addons']), $lang_admin_addons['Addon removed redirect']);
}

if (isset($_POST['upload_addon']))
{
	if (!isset($_FILES['req_file']))
		message($lang_admin_addons['No file']);
	
	$uploaded_file = $_FILES['req_file'];
	
	// Make sure the upload went smooth
	if (isset($uploaded_file['error']))
	{
		switch ($uploaded_file['error'])
		{
			case 1:	// UPLOAD_ERR_INI_SIZE
			case 2:	// UPLOAD_ERR_FORM_SIZE
				message($lang_admin_addons['Too large ini']);
			break;
			case 3:	// UPLOAD_ERR_PARTIAL
				message($lang_admin_addons['Partial upload']);
			break;
			case 4:	// UPLOAD_ERR_NO_FILE
				message($lang_admin_addons['No file']);
			break;
			case 6:	// UPLOAD_ERR_NO_TMP_DIR
				message($lang_admin_addons['No tmp directory']);
			break;
			default:
				// No error occured, but was something actually uploaded?
				if ($uploaded_file['size'] == 0)
					message($lang_admin_addons['No file']);
			break;
		}
	}
	
	if (is_uploaded_file($uploaded_file['tmp_name']))
	{
		$filename = panther_htmlspecialchars($uploaded_file['name']);
		if (!preg_match('/^[a-z0-9-_]+\.(php)$/i', $uploaded_file['name']))
			message($lang_admin_addons['Bad type']);
	
		// Move the file to the addons directory.
		if (!@move_uploaded_file($uploaded_file['tmp_name'], PANTHER_ROOT.'addons/'.$filename))
			message($lang_admin_addons['Move failed']);

		@chmod(PANTHER_ROOT.'addons/'.$filename, 0644);
	}
	else
		message($lang_admin_addons['Unknown failure']);
	
	redirect(get_link($panther_url['admin_addons']), $lang_admin_addons['Successful Upload']);
}

$addons = array();
$d = dir(PANTHER_ROOT.'addons');
while (($entry = $d->read()) !== false)
{
	if ($entry{0} == '.')
		continue;

	if (substr($entry, -4) == '.php')
		$addons[] = panther_htmlspecialchars(substr($entry, 0, -4));
}
$d->close();

$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_admin_common['Admin'], $lang_admin_common['Addons']);
define('PANTHER_ACTIVE_PAGE', 'admin');
require PANTHER_ROOT.'header.php';
generate_admin_menu('addons');
?>
	<div class="blockform">
		<h2 class="block2"><span><?php echo $lang_admin_addons['Current Addons'] ?></span></h2>
		<div class="box">
			<form method="post" action="<?php echo get_link($panther_url['admin_addons']); ?>">
				<div class="inform">
					<fieldset>
						<legend><?php echo $lang_admin_addons['List Addons'] ?></legend>
						<div class="infldset">
<?php
?>
							<table>
								<thead>
								<tr>
									<th scope="col"><?php echo $lang_admin_addons['Addon filename']; ?></th>
									<th scope="col"><?php echo $lang_admin_addons['Delete']; ?></th>
								</tr>
								</thead>
								<tbody>
<?php
		foreach ($addons as $cur_addon)
		{
?>
									<tr>
										<td scope="row"><strong><?php echo ucwords(str_replace('_', ' ', $cur_addon)) ?></strong></td>
										<td><input name="del_addons[]" type="checkbox" value="<?php echo $cur_addon ?>" /></td>
									</tr>
<?php
		}
?>
								</tbody>
							</table>
						</div>
					</fieldset>
				</div>
				<p class="submitend"><input name="delete" type="submit" value="<?php echo $lang_admin_addons['Delete selected'] ?>" /></p>
			</form>
			<form method="post" enctype="multipart/form-data" action="<?php echo get_link($panther_url['admin_addons']); ?>">
				<div class="inform">
					<fieldset>
						<legend><?php echo $lang_admin_addons['Add Addon'] ?></legend>
						<div class="infldset">
							<label><?php echo $lang_admin_addons['Add Addon'] ?>&nbsp;&nbsp;<input name="req_file" type="file" size="40" /></label>
						</div>
					</fieldset>
				</div>
				<p><span style="font-weight:bold; color: red;"><?php echo $lang_admin_addons['Warning']; ?></span> <?php echo $lang_admin_addons['Addon upload warning']; ?></p>
				<p class="submitend"><input name="upload_addon" type="submit" value="<?php echo $lang_admin_addons['Upload'] ?>" /></p>
			</form>
		</div>
	</div>
	<div class="clearer"></div>
<?php
require PANTHER_ROOT.'footer.php';