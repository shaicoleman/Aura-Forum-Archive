<?php

/**
 *
 * This file is part of the Panther Forum Software package.
 *
 * @link      https://www.pantherforum.org/
 * @copyright Copyright (c) Panther <https://www.pantherforum.org/>
 * @license   GNU General Public License (GPL-3.0), Version 3, 29 June 2007 <http://opensource.org/licenses/GPL-3.0>
 *
 * For full information, please see README.md, CHANGELOG.md and LICENSE.md files which are located in the root folder.
 *
 */

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/');
	require PANTHER_ROOT.'include/common.php';
}

if ($panther_config['o_warnings'] == '0')
	message($lang_warnings['Warning system disabled']);

// Load the warnings.php/post.php language files
require PANTHER_ROOT.'lang/'.$panther_user['language'].'/warnings.php';
require PANTHER_ROOT.'lang/'.$panther_user['language'].'/post.php';

$action = isset($_GET['action']) ? panther_trim($_GET['action']) : '';

$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), panther_htmlspecialchars($lang_warnings['Warning system']));
define('PANTHER_ACTIVE_PAGE', 'index');
require PANTHER_ROOT.'header.php';

$cur_index = 1;
if (isset($_POST['form_sent']))
{
	// Make sure we have a valid token
	confirm_referrer('warnings.php');

	// Are we allowed to issue warnings?
	if ($panther_user['g_mod_warn_users'] == '0' && !$panther_user['is_admin'])
		message($lang_common['No permission']);

	$user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;
	$data = array(
		':id'	=>	$user_id,
	);
	
	if ($user_id == $panther_user['id'] || $user_id < 2 || (in_array($user_id, get_admin_ids())))
		message($lang_common['Bad request']);

	$ps = $db->select('users', 'username, pm_notify, email', $data, 'id=:id');
	if (!$ps->rowCount())
		message($lang_common['Bad request']);

	list($username, $pm_notify, $email) = $ps->fetch(PDO::FETCH_NUM);

	// Check post ID
	$post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;
	if ($post_id < 0)
			message($lang_common['Bad request']);
	else if ($post_id > 0)
	{
		$data = array(
			':uid'	=>	$user_id,
			':id'	=>	$post_id,
		);

		$ps = $db->select('posts', 'poster_id, message', $data, 'id=:id AND poster_id=:uid AND approved=1 AND deleted=0');
		if (!$ps->rowCount())
			message($lang_common['Bad request']);

		list($poster_id, $message) = $ps->fetch(PDO::FETCH_NUM);
	}
	else
	{
		$post_id = 0;
		$message = '';
	}

	// Check whether user has been warned already for this post (users can only receive one warning per post)
	if ($post_id)
	{
		$data = array(
			':id'	=>	$post_id,
		);

		$ps = $db->select('warnings', 'id', $data, 'post_id=:id');
		if ($ps->rowCount())
		{
			$warning_id = $ps->fetchColumn();
			$link = get_link($panther_url['warning_details'], array($warning_id));
			$link = '<a href="'.$link.'">'.$link.'</a>';
			
			message(sprintf($lang_warnings['Already warned'], $link));
		}
	}

	// Check warning type
	$warning_type = isset($_POST['warning_type']) ? intval($_POST['warning_type']) : -1;
	if ($warning_type < 0)
		message($lang_warnings['No warning type']);
	
	$now = time();

	// Make sure this warning type exists (and grab some data while we're at it)
	if ($warning_type != '0')
	{
		$data = array(
			':id'	=>	$warning_type,
		);

		$ps = $db->select('warning_types', 'title, points, expiration_time', $data, 'id=:id');
		if (!$ps->rowCount())
			message($lang_common['Bad request']);

		list ($warning_title, $warning_points, $expiration_time) = $ps->fetch(PDO::FETCH_NUM);
	}
	else // It's a custom warning
	{
		if ($panther_config['o_custom_warnings'] == '0')
			message($lang_warnings['Custom warnings disabled']);

		$warning_title = isset($_POST['custom_title']) ? panther_trim($_POST['custom_title']) : '';
		if ($warning_title == '')
			$errors[] = $lang_warnings['No warning reason'];
		else if (panther_strlen($custom_title) > 120)
			$errors[] = $lang_warnings['Too long warning reason'];

		$warning_points = isset($_POST['custom_points']) ? intval($_POST['custom_points']) : 0;
		if ($warning_points < 0)
			$errors[] = $lang_warnings['No points'];

		$expiration_time = isset($_POST['custom_expiration_time']) ? intval($_POST['custom_expiration_time']) : 0;
		$expiration_unit = isset($_POST['custom_expiration_unit']) ? panther_trim($_POST['custom_expiration_unit']) : '';

		if ($expiration_time < 1 && $expiration_unit != 'never')
			$errors[] = $lang_warnings['No expiration time'];

		$expiration_time = get_expiration_time($expiration_time, $expiration_unit);
	}

	$admin_note = panther_linebreaks(panther_trim($_POST['note_admin']));
	if (strlen($admin_note) > 65535)
		$errors[] = $lang_warnings['Too long admin note'];

	// If private messaging system is enabled (and if so, then send a PM to them)
	if ($panther_config['o_private_messaging'] == '1')
	{
		$link = get_link($panther_url['warning_view'], array($user_id));
		$link = '[url]'.$link.'[/url]';

		// Check message subject
		$pm_subject = isset($_POST['req_subject']) ? panther_trim($_POST['req_subject']) : '';
		
		if ($panther_config['o_censoring'] == '1')
			$censored_subject = panther_trim(censor_words($pm_subject));

		if ($pm_subject == '')
			$errors[] = $lang_warnings['No subject'];
		else if ($panther_config['o_censoring'] == '1' && $censored_subject == '')
			$errors[] = $lang_post['No subject after censoring'];
		else if (panther_strlen($pm_subject) > 70)
			$errors[] = $lang_post['Too long subject'];
		
		$pm_message = panther_linebreaks(panther_trim($_POST['req_message']));
		
		if ($pm_message == '')
			$errors[] = $lang_post['No message'];
		else if (strlen($pm_message) > PANTHER_MAX_POSTSIZE)
			$errors[] = sprintf($lang_post['Too long message'], forum_number_format(PANTHER_MAX_POSTSIZE));
		
		if ($panther_config['p_message_bbcode'] == '1')
		{
			require PANTHER_ROOT.'include/parser.php';
			$pm_message = preparse_bbcode($pm_message, $errors);
		}

		if (empty($errors))
		{
			if ($pm_message == '')
				$errors[] = $lang_post['No message'];
			else if ($panther_config['o_censoring'] == '1')
			{
				// Censor message to see if that causes problems
				$censored_message = panther_trim(censor_words($pm_message));

				if ($censored_message == '')
					$errors[] = $lang_post['No message after censoring'];
			}
		}

		$pm_subject = str_replace('<warning_type>', $warning_title, $pm_subject);
		$pm_subject = str_replace('<warnings_url>', $link, $pm_subject);
		$pm_message = str_replace('<warning_type>', $warning_title, $pm_message);
		$pm_message = str_replace('<warnings_url>', $link, $pm_message);

		// Check note_pm
		$note_pm = 'Subject: '.$pm_subject."\n\n".'Message:'."\n\n".$pm_message;
	}
	else
		$note_pm = '';

	// If there are errors, we display them
	if (!empty($errors))
	{
	?>
	<div id="posterror" class="block">
		<h2><span><?php echo $lang_post['Post errors'] ?></span></h2>
		<div class="box">
			<div class="inbox">
				<p><?php echo $lang_warnings['Post errors info'] ?></p>
				<ul>
<?php
	
		foreach ($errors as $cur_error)
			echo "\t\t\t\t".'<li><strong>'.$cur_error.'</strong></li>'."\n";
?>
				</ul>
				<p><a href="javascript:history.go(-1)"><?php echo $lang_common['Go back'] ?></a></p>
			</div>
		</div>
	</div>
	<?php
	}
	else
	{
		$expiration_time = ($expiration_time != '0') ? ($now + $expiration_time) : 0;
		$insert = array(
			'user_id'	=>	$user_id,
			'type_id'	=>	$warning_type,
			'post_id'	=>	$post_id,
			'title'		=>	(($warning_type != '0') ? $warning_title : ''),
			'points'	=>	$warning_points,
			'date_issued'	=>	$now,
			'date_expire'	=>	$expiration_time,
			'issued_by'	=>	$panther_user['id'],
			'note_admin'	=>	$admin_note,
			'note_post'	=>	$message,
			'note_pm'	=>	$note_pm,
		);
		
		$db->insert('warnings', $insert);

		// If private messaging system is enabled
		if ($panther_config['o_private_messaging'] == '1')
		{
			$insert = array(
				'subject'	=>	$pm_subject,
				'poster'	=>	$panther_user['username'],
				'poster_id'	=>	$panther_user['id'],
				'num_replies'	=>	0,
				'last_post'	=>	$now,
				'last_poster'	=>	$panther_user['username'],
			);

			$db->insert('conversations', $insert);
			$new_tid = $db->lastInsertId($db->prefix.'conversations');

			$insert = array(
				'poster'	=>	$panther_user['username'],
				'poster_id'	=>	$panther_user['id'],
				'poster_ip'	=>	get_remote_address(),
				'message'	=>	$pm_message,
				'hide_smilies'	=>	0,
				'posted'	=>	$now,
				'topic_id'	=>	$new_tid,
			);

			$db->insert('messages', $insert);
			$new_pid = $db->lastInsertId($db->prefix.'messages');
			
			$update = array(
				'first_post_id'	=>	$new_pid,
				'last_post_id'	=>	$new_pid,
			);
			
			$data = array(
				':tid'	=>	$new_tid,
			);
			
			$db->update('conversations', $update, 'id=:tid', $data);
			
			$insert = array(
				'topic_id'	=>	$new_tid,
				'user_id'	=>	$user_id,
			);

			$db->insert('pms_data', $insert);
			
			$insert = array(
				'topic_id'	=>	$new_tid,
				'user_id'	=>	$panther_user['id'],
				'viewed'	=>	1,
				'deleted'	=>	1,
			);

			$db->insert('pms_data', $insert);

			$data = array(
				':id'	=>	$user_id,
			);

			$db->run('UPDATE '.$db->prefix.'users SET num_pms=num_pms+1 WHERE id=:id', $data);

			if ($pm_notify == '1')
			{
				$mail_subject = trim(substr($mail_tpl, 8, $first_crlf-8));
				$mail_message = trim(substr($mail_tpl, $first_crlf));

				$mail_message = str_replace('<username>', panther_htmlspecialchars($username), $mail_message);
				$mail_message = str_replace('<sender>', panther_htmlspecialchars($panther_user['username']), $mail_message);
				$mail_message = str_replace('<message>', $pm_message, $mail_message);
				$mail_message = str_replace('<pm_title>', panther_htmlspecialchars($subject), $mail_message);
				$mail_message = str_replace('<message_url>', get_link($panther_url['pms_topic'], array($new_pid)), $mail_message);
				$mail_message = str_replace('<board_mailer>', panther_htmlspecialchars($panther_config['o_board_title']), $mail_message);

				panther_mail($email, $mail_subject, $mail_message);
			}
			
			$update = array(
				'last_post'	=>	$now,
			);

			$data = array(
				':id'	=>	$panther_user['id'],
			);

			$db->update('users', $update, 'id=:id', $data);

			// Check whether user should be banned according to warning levels
			if ($warning_points > 0)
			{
				$data = array(
					':uid'	=>	$user_id,
					':now'	=>	$now,
				);

				$ps = $db->select('warnings', 'SUM(points)', $data, 'user_id=:uid AND (date_expire>:now OR date_expire=0)');
				$points_active = $ps->fetchColumn();
				
				$data = array(
					':active'	=>	$points_active,
				);
				
				$ps = $db->select('warning_levels', 'message, period', $data, 'points<=:active', 'points DESC LIMIT 1');
				if ($ps->rowCount())
				{
					list($ban_message, $ban_period) = $ps->fetch(PDO::FETCH_NUM);
					$data = array(
						':username'	=>	$username,
					);

					$ps = $db->select('bans', 'expire', $data, 'username=:username', 'expire IS NULL DESC, expire DESC LIMIT 1');
					if ($ps->rowCount())
					{
						$ban_expire = $ps->fetchColumn();
						
						// Only delete user's current bans if new ban is greater than curent ban and current ban is not a permanent ban
						if ((($now + $ban_period) > $ban_expire || $ban_period == '0') && $ban_expire != null)
						{
							$ps = $db->delete('bans', 'username=:username', $data);
							$insert = array(
								'username'	=>	$username,
								'message'	=>	$ban_message,
							);

							if ($ban_period != 0)
								$insert['expire'] = $now + $ban_period;
								
							$db->insert('bans', $insert);
							
						}
					}
					else
					{
						$insert = array(
							'username'	=>	$username,
							'message'	=>	$ban_message,
							'ban_creator'	=>	$panther_user['id'],
						);
						
						if ($ban_period != 0)
							$insert['expire'] = $now + $ban_period;
						
						$db->insert('bans', $insert);
					}
					
					// Regenerate the bans cache
					if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
						require PANTHER_ROOT.'include/cache.php';
					
					generate_bans_cache();
				}
			}

			$redirect_link = ($post_id) ? get_link($panther_url['post'], array($post_id)) : get_link($panther_url['profile'], array($user, url_friendly($username)));
			redirect($redirect_link, $lang_warnings['Warning added redirect']);
		}
	}
}
else if (isset($_GET['warn']))
{
	// Are we allowed to issue warnings?
	if ($panther_user['g_mod_warn_users'] == '0' && !$panther_user['is_admin'])
		message($lang_common['No permission']);

	$user_id = isset($_GET['warn']) ? intval($_GET['warn']) : 0;
	if ($user_id < 1)
		message($lang_common['Bad request']);

	$post_id = isset($_GET['pid']) ? intval($_GET['pid']) : 0;
	if ($post_id < 0)
		message($lang_common['Bad request']);
	
	if ($user_id == $panther_user['id'] || $user_id < 2 || (in_array($user_id, get_admin_ids())))
		message($lang_common['Bad request']);

	// Check whether user has been warned already for this post (users can only receive one warning per post)
	if ($post_id)
	{
		$data = array(
			':id'	=>	$post_id,
		);

		$ps = $db->select('warnings', 'id', $data, 'post_id=:id');
		if ($ps->rowCount())
		{
			$warning_id = $ps->fetchColumn();
			$warning_link = get_link($panther_url['warning_details'], array($warning_id));
			$warning_link = '<a href="'.$warning_link.'">'.$warning_link.'</a>';
			
			message(sprintf($lang_warnings['Already warned'], $warning_link));
		}
	}
	
	$data = array(
		':id'	=>	$user_id,
	);

	$ps = $db->select('users', 'username, group_id', $data, 'id=:id');
	$cur_user = $ps->fetch();
	
	$now = time();
	$data = array(
		':id'	=>	$user_id,
		':time'	=>	$now
	);
	
	$ps = $db->select('warnings', 'COUNT(id)', $data, 'user_id=:id AND (date_expire>:time OR date_expire=0)');
	$num_active = $ps->fetchColumn();
	
	$data = array(
		':id'	=>	$user_id,
		':time'	=>	$now,
	);
	
	$ps = $db->select('warnings', 'COUNT(id)', $data, 'user_id=:id AND date_expire<=:time AND date_expire!=0');
	$num_expired = $ps->fetchColumn();
	
	$ps = $db->select('warnings', 'SUM(points)', $data, 'user_id=:id AND (date_expire>:time OR date_expire=0)');
	$points_active = $ps->fetchColumn();
	
	$ps = $db->select('warnings', 'SUM(points)', $data, 'user_id=:id AND date_expire<=:time AND date_expire!=0');
	$points_expired = $ps->fetchColumn();
	
	$pm_tpl = trim(file_get_contents(PANTHER_ROOT.'lang/'.$panther_user['language'].'/mail_templates/warning_pm.tpl'));

	// Load the "warning pm" template
	$first_crlf = strpos($pm_tpl, "\n");
	$pm_subject = trim(substr($pm_tpl, 8, $first_crlf-8));
	$pm_message = trim(substr($pm_tpl, $first_crlf));
	$pm_message = str_replace('<username>', '[user]'.panther_htmlspecialchars($cur_user['username']).'[/user]', $pm_message);
	$pm_message = str_replace('<board_title>', panther_htmlspecialchars($panther_config['o_board_title']), $pm_message);
?>
<div class="blockform">
	<h2><span><?php echo $lang_warnings['Issue warning'] ?></span></h2>
	<div class="box">
	<form method="post" id="post" action="<?php echo get_link($panther_url['warnings']); ?>" onsubmit="return process_form(this)">
		<div class="inform">
			<fieldset>
				<legend><?php echo $lang_warnings['User details'] ?></legend>
				<div class="infldset">
					<p><?php echo sprintf($lang_warnings['Username'], colourize_group($cur_user['username'], $cur_user['group_id'], $user_id)); ?></p>
					<p><?php echo sprintf($lang_warnings['Active warnings 2'], $num_active, $points_active); ?></p>
					<p><?php echo sprintf($lang_warnings['Expired warnings 2'], $num_expired, $points_expired); ?></p>
				</div>
			</fieldset>
		</div>
		<div class="inform">
		<fieldset>
			<legend><?php echo $lang_warnings['Enter warning details'] ?></legend>
			<div class="infldset txtarea">
				<input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>" />
				<input type="hidden" name="form_sent" value="1" />
				<input type="hidden" name="user_id" value="<?php echo $user_id ?>" />
				<input type="hidden" name="post_id" value="<?php echo $post_id ?>" />
				<input type="hidden" name="topic_redirect" value="<?php echo isset($_GET['tid']) ? intval($_GET['tid']) : '' ?>" />
				<input type="hidden" name="topic_redirect" value="<?php echo isset($_POST['from_profile']) ? intval($_POST['from_profile']) : '' ?>" />
				<input type="hidden" name="form_user" value="<?php echo (!$panther_user['is_guest']) ? panther_htmlspecialchars($panther_user['username']) : $lang_common['Guest']; ?>" />
				<label><strong><?php echo $lang_warnings['Warning type'] ?></strong><br /></label>
<?php
	$ps = $db->select('warning_types', 'id, title, points, expiration_time', array(), '', 'points');
	$warning_count = 1;
	
	if ($ps->rowCount())
	{
		foreach ($ps as $cur_warning)
			echo "\n\t\t\t\t".'<input id="wt'.$warning_count++.'" type="radio" name="warning_type" value="'.$cur_warning['id'].'" tabindex="'.$cur_index++.'" /> '.panther_htmlspecialchars($cur_warning['title']).' ('.sprintf($lang_warnings['No of points'], $cur_warning['points']).' / '.sprintf($lang_warnings['Expires after period'], format_expiration_time($cur_warning['expiration_time'])).')<br />';

		
	}
	else
		echo "\n\t\t\t\t".$lang_warnings['No warning types'].'<br />';

	if ($panther_config['o_custom_warnings'] == '1')
	{
?>
				<label><strong><?php echo $lang_warnings['Custom warning type']; ?></strong><br /></label>
				<input id="wt<?php echo $warning_count++; ?>" type="radio" name="warning_type" value="0" tabindex="<?php echo $cur_index++; ?>" /> <input type="text" name="custom_title" size="20" maxlength="120" tabindex="<?php echo $cur_index++; ?>" /> (<?php echo sprintf($lang_warnings['No of points'], '<input type="text" name="custom_points" size="3" maxlength="3" tabindex="'.$cur_index++.'" />'); ?> / <?php echo sprintf($lang_warnings['Expires after period'], '<input type="text" name="custom_expiration_time" size="3" maxlength="3" value="10" tabindex="'.$cur_index++.'" />'); ?>
				<select name="custom_expiration_unit">
					<option value="hours"><?php echo $lang_warnings['Hours']; ?></option>
					<option value="days" selected="selected"><?php echo $lang_warnings['Days']; ?></option>
					<option value="months"><?php echo $lang_warnings['Months']; ?></option>
					<option value="never"><?php echo $lang_warnings['Never']; ?></option>)
				</select>
<?php
	}
?>
				<br />
				<label><strong><?php echo $lang_warnings['Admin note'] ?></strong><br /><textarea name="note_admin" rows="5" cols="60" tabindex="<?php echo $cur_index++ ?>"></textarea><br /></label>
			</div>
		</fieldset>
		</div>
<?php
	if ($panther_config['o_private_messaging'] == '1')
	{
?>
		<div class="inform">
		<fieldset>
			<legend><?php echo $lang_warnings['Enter private message'] ?></legend>
			<div class="infldset txtarea">
				<label><strong><?php echo $lang_warnings['Subject'] ?></strong><br /><input class="longinput" type="text" name="req_subject" value="<?php echo $pm_subject ?>" size="80" maxlength="70" tabindex="<?php echo $cur_index++ ?>" /><br /></label>
				<label><strong><?php echo $lang_warnings['Message'] ?></strong><br /><textarea name="req_message" rows="10" cols="95" tabindex="<?php echo $cur_index++ ?>"><?php echo $pm_message ?></textarea><br /></label>
			</div>
		</fieldset>
		</div>
<?php
	}
?>
			<p class="buttons"><input type="submit" name="submit" value="<?php echo $lang_common['Submit'] ?>" tabindex="<?php echo $cur_index++ ?>" accesskey="s" /> <a href="javascript:history.go(-1)"><?php echo $lang_common['Go back'] ?></a></p>
		</form>
	</div>
</div>
<?php
}
else if (isset($_GET['view']))
{
	$user_id = isset($_GET['view']) ? intval($_GET['view']) : 0;
	if ($user_id < 1)
		message($lang_common['Bad request']);

	// Normal users can only view their own warnings - and only if they have permission
	if ($panther_user['g_id'] == PANTHER_GUEST || (!$panther_user['is_admmod'] && $panther_user['id'] != $user_id) || (!$panther_user['is_admmod'] && $panther_config['o_warning_status'] == '2'))
		message($lang_common['No permission']);
	
	$now = time();
	
	$data = array(
		':id'	=>	$user_id,
	);

	$ps = $db->select('users', 'username', $data, 'id=:id');
	$username = $ps->fetchColumn();
	
	$url_username = url_friendly($username);

	$data = array(
		':id'	=>	$user_id,
		':time'	=>	$now,
	);
	
	$ps = $db->select('warnings', 'COUNT(id)', $data, 'user_id=:id AND (date_expire>:time OR date_expire=0)');
	$num_active = $ps->fetchColumn();
	
	$ps = $db->select('warnings', 'COUNT(id)', $data, 'user_id=:id AND date_expire<=:time OR date_expire!=0');
	$num_expired = $ps->fetchColumn();

	$ps = $db->select('warnings', 'SUM(points)', $data, 'user_id=:id AND (date_expire>:time OR date_expire=0)');
	$points_active = $ps->fetchColumn();
	
	$ps = $db->select('warnings', 'SUM(points)', $data, 'user_id=:id AND date_expire<=:time AND date_expire!=0');
	$points_expired = $ps->fetchColumn();
	
	$ps = $db->run('SELECT w.id, w.type_id, w.post_id, w.title AS custom_title, w.points, w.date_issued, w.date_expire, w.issued_by, t.title, u.username AS issued_by_username, u.group_id AS issuer_gid FROM '.$db->prefix.'warnings as w LEFT JOIN '.$db->prefix.'warning_types AS t ON t.id=w.type_id LEFT JOIN '.$db->prefix.'users AS u ON u.id = w.issued_by WHERE w.user_id=:id AND (w.date_expire>:time OR w.date_expire=0) ORDER BY w.date_issued DESC', $data);

	$ps1 = $db->run('SELECT w.id, w.type_id, w.post_id, w.title AS custom_title, w.points, w.date_issued, w.date_expire, w.issued_by, t.title, u.username AS issued_by_username, u.group_id AS issuer_gid FROM '.$db->prefix.'warnings as w LEFT JOIN '.$db->prefix.'warning_types AS t ON t.id=w.type_id LEFT JOIN '.$db->prefix.'users AS u ON u.id=w.issued_by WHERE w.user_id=:id AND w.date_expire<=:time AND w.date_expire!=0 ORDER BY w.date_issued DESC', $data);
?>
<div class="linkst">
	<div class="inbox crumbsplus">
		<ul class="crumbs">
			<li><a href="<?php echo get_link($panther_url['profile'], array($user_id, $url_username)); ?>"><?php echo panther_htmlspecialchars($username); ?></a></li>
			<li><span>»&#160;</span><a href="<?php echo get_link($panther_url['warning_view'], array($user_id)); ?>"><strong><?php echo $lang_warnings['Warnings'] ?></strong></a></li>
		</ul>
		<div class="clearer"></div>
	</div>
</div>
<div id="warnings_active" class="blocktable">
	<h2><span><?php echo sprintf($lang_warnings['Active warnings'], panther_htmlspecialchars($username)); ?></span></h2>
	<div class="box">
		<div class="inbox">
		<table>
		<thead>
			<tr>
				<th style="width: 35%" align="left" scope="col"><?php echo $lang_warnings['Warning 2'] ?></th>
				<th style="width: 18%" align="left" scope="col"><?php echo $lang_warnings['Date issued 2'] ?></th>
				<th class="tc3" scope="col"><?php echo $lang_warnings['Points'] ?></th>
				<th style="width: 18%" align="left" scope="col"><?php echo $lang_warnings['Expires'] ?></th>
				<th class="tcr" scope="col"><?php echo $lang_warnings['Issued by 2'] ?></th>
				<th class="tc3" scope="col"><?php echo $lang_warnings['Details'] ?></th>
			</tr>
		</thead>
		<tbody>
<?php
	if ($ps->rowCount())
	{
		foreach ($ps as $active_warnings)
		{
			if ($active_warnings['custom_title'] != '')
				$warning_title = sprintf($lang_warnings['Custom warning'], panther_htmlspecialchars($active_warnings['custom_title']));
			else if ($active_warnings['title'] != '')
				$warning_title = panther_htmlspecialchars($active_warnings['title']);
			else
				$warning_title = ''; // This warning type has been deleted
?>
				<tr>
					<td style="width: 35%" align="left"><?php echo $warning_title ?></td>
					<td style="width: 18%" align="left"><?php echo format_time($active_warnings['date_issued']) ?></td>
					<td class="tc3"><?php echo $active_warnings['points'] ?></td>
					<td style="width: 18%" align="left"><?php echo ($active_warnings['date_expire'] == '0') ? $lang_warnings['Never'] : format_time($active_warnings['date_expire']) ?></td>
					<td class="tcr"><?php echo ($active_warnings['issued_by_username'] != '') ? colourize_group($active_warnings['issued_by_username'], $active_warnings['issuer_gid'], $active_warnings['issued_by']) : '' ?></td>
					<td class="tc3"><a href="<?php echo get_link($panther_url['warning_details'], array($active_warnings['id'])); ?>"><?php echo $lang_warnings['Details'] ?></a></td>
				</tr>
<?php
		}
?>
				<tr>
					<th align="left" scope="col"><?php printf($lang_warnings['No of warnings'], $num_active) ?></th>
					<th align="left" scope="col">&nbsp;</th>
					<th class="tc3" scope="col"><?php echo $points_active ?></th>
					<th align="left" colspan="3" scope="col">&nbsp;</th>
				</tr>
<?php
	}
	else
	{
?>
				<tr>
					<td class="tcl" colspan="6"><?php echo $lang_warnings['No active warnings'] ?></td>
				</tr>
<?php
	}
?>
			</tbody>
			</table>
		</div>
	</div>
</div>
<div id="warnings_expired" class="blocktable">
	<h2><span><?php echo sprintf($lang_warnings['Expired warnings'], panther_htmlspecialchars($username)); ?></span></h2>
	<div class="box">
		<div class="inbox">
		<table>
		<thead>
			<tr>
				<th style="width: 35%" align="left" scope="col"><?php echo $lang_warnings['Warning 2'] ?></th>
				<th style="width: 18%" align="left" scope="col"><?php echo $lang_warnings['Date issued 2'] ?></th>
				<th class="tc3" scope="col"><?php echo $lang_warnings['Points'] ?></th>
				<th style="width: 18%" align="left" scope="col"><?php echo $lang_warnings['Expired'] ?></th>
				<th class="tcr" scope="col"><?php echo $lang_warnings['Issued by 2'] ?></th>
				<th class="tc3" scope="col"><?php echo $lang_warnings['Details'] ?></th>
			</tr>
		</thead>
		<tbody>
<?php
	if ($ps1->rowCount())
	{
		foreach ($ps1 as $expired_warnings)
		{
			// Determine warning type
			if ($expired_warnings['custom_title'] != '')
				$warning_title = sprintf($lang_warnings['Custom warning'], panther_htmlspecialchars($expired_warnings['custom_title']));
			else if ($warnings_expired['title'] != '')
				$warning_title = panther_htmlspecialchars($expired_warnings['title']);
			else
				$warning_title = ''; // This warning type has been deleted 
?>
				<tr>
					<td style="width: 35%" align="left"><?php echo $warning_title ?></td>
					<td style="width: 18%" align="left"><?php echo format_time($expired_warnings['date_issued']) ?></td>
					<td class="tc3"><?php echo $expired_warnings['points'] ?></td>
					<td style="width: 18%" align="left"><?php echo format_time($expired_warnings['date_expire']) ?></td>
					<td class="tcr"><?php echo ($expired_warnings['issued_by_username'] != '') ? colourize_group($expired_warnings['issued_by_username'], $expired_warnings['issuer_gid'], $expired_warnings['issued_by']) : '' ?></td>
					<td class="tc3"><a href="<?php echo get_link($panther_url['warning_details'], array($expired_warnings['id'])); ?>"><?php echo $lang_warnings['Details'] ?></a></td>
				</tr>
<?php
		}
?>
				<tr>
					<th align="left" scope="col"><?php printf($lang_warnings['No of warnings'], $num_expired) ?></th>
					<th align="left" scope="col">&nbsp;</th>
					<th class="tc3" scope="col"><?php echo $points_expired ?></th>
					<th align="left" colspan="3" scope="col">&nbsp;</th>
				</tr>
<?php
	}
	else
	{
?>
				<tr>
					<td class="tcl" colspan="6"><?php echo $lang_warnings['No expired warnings'] ?></td>
				</tr>
<?php
	}
?>
			</tbody>
			</table>
		</div>
	</div>
</div>
<div class="linksb">
	<div class="inbox crumbsplus">
		<ul class="crumbs">
			<li><a href="<?php echo get_link($panther_url['profile'], array($user_id, $url_username)); ?>"><?php echo panther_htmlspecialchars($username); ?></a></li>
			<li><span>»&#160;</span><a href="<?php echo get_link($panther_url['warning_view'], array($user_id)); ?>"><strong><?php echo panther_htmlspecialchars($lang_warnings['Warnings']) ?></strong></a></li>
		</ul>
		<div class="clearer"></div>
	</div>
</div>
<?php
}
else if (isset($_GET['details']))
{
	$warning_id = isset($_GET['details']) ? intval($_GET['details']) : 0;
	if ($warning_id < 1)
		message($lang_common['Bad request']);

	$data = array(
		':id'	=>	$warning_id,
	);

	$ps = $db->run('SELECT w.id, w.user_id, w.type_id, w.post_id, w.title AS custom_title, w.points, w.date_issued, w.date_expire, w.issued_by, w.note_admin, w.note_post, w.note_pm, t.title, u.username AS issued_by_username, u.group_id AS issuer_gid FROM '.$db->prefix.'warnings as w LEFT JOIN '.$db->prefix.'warning_types AS t ON t.id=w.type_id LEFT JOIN '.$db->prefix.'users AS u ON u.id=w.issued_by WHERE w.id=:id', $data);
	if (!$ps->rowCount())
		message($lang_common['Bad request']);

	$warning_details = $ps->fetch();

	// Normal users can only view their own warnings if they have permission
	if ($panther_user['g_id'] == PANTHER_GUEST || (!$panther_user['is_admmod'] && $panther_user['id'] != $warning_details['user_id']) || (!$panther_user['is_admmod'] && $panther_config['o_warning_status'] == '2'))
		message($lang_common['No permission']);

	if ($warning_details['custom_title'] != '')
		$warning_title = sprintf($lang_warnings['Custom warning'], panther_htmlspecialchars($warning_details['custom_title'])).' ('.sprintf($lang_warnings['No of points'], $warning_details['points']).')';
	else if ($warning_details['title'] != '')
		$warning_title = panther_htmlspecialchars($warning_details['title']).' ('.sprintf($lang_warnings['No of points'], $warning_details['points']).')';
	else
		$warning_title = ''; // This warning type has been deleted
	
	$data = array(
		':id'	=>	$warning_details['user_id']
	);

	$ps = $db->select('users', 'username, group_id', $data, 'id=:id');
	list($username, $group_id) = $ps->fetch(PDO::FETCH_NUM);

	if ($warning_details['date_expire'] == '0')
		$warning_expires = $lang_warnings['Expires'].': '.$lang_warnings['Never'];
	else if ($warning_details['date_expire'] > time())
		$warning_expires = $lang_warnings['Expires'].': '.format_time($warning_details['date_expire']);
	else
		$warning_expires = $lang_warnings['Expired'].': '.format_time($warning_details['date_expire']);
	
	require PANTHER_ROOT.'include/parser.php';
	$note_admin = parse_message($warning_details['note_admin'], 0);
	$note_pm = parse_message($warning_details['note_pm'], 0);
	$message = parse_message($warning_details['note_post'], 0);
	
	$url_username = url_friendly($username);
?>
<div class="linkst">
	<div class="inbox crumbsplus">
		<ul class="crumbs">
			<li><a href="<?php echo get_link($panther_url['profile'], array($warning_details['user_id'], $url_username)); ?>"><?php echo panther_htmlspecialchars($username); ?></a></li>
			<li><span>»&#160;</span><a href="<?php echo get_link($panther_url['warning_view'], array($warning_details['user_id'])); ?>"><strong><?php echo panther_htmlspecialchars($lang_warnings['Warnings']) ?></strong></a></li>
			<li><span>»&#160;</span><a href="<?php echo get_link($panther_url['warning_details'], array($warning_id)); ?>"><strong><?php echo panther_htmlspecialchars($lang_warnings['Details']) ?></strong></a></li>
		</ul>
		<div class="clearer"></div>
	</div>
</div>
<div class="blockform">
	<h2><span><?php echo $lang_warnings['Warning details'] ?></span></h2>
	<div class="box">
	<form method="post" id="post" action="<?php echo get_link($panther_url['warnings']); ?>" onsubmit="return process_form(this)">
		<div class="inform">
			<fieldset>
				<legend><?php echo $lang_warnings['Warning info'] ?></legend>
				<div class="infldset">
					<p><?php echo sprintf($lang_warnings['Username'], colourize_group($url_username, $group_id, $warning_details['user_id'])); ?></p>
					<p><?php echo sprintf($lang_warnings['Warning'], $warning_title) ?></p>
					<p><?php echo sprintf($lang_warnings['Date issued'], format_time($warning_details['date_issued'])) ?></p>
					<p><?php echo $warning_expires ?></p>
					<p><?php echo sprintf($lang_warnings['Issued by'], colourize_group($warning_details['issued_by_username'], $warning_details['issuer_gid'], $warning_details['issued_by'])); ?></a></p>
			</div>
			</fieldset>
		</div>
<?php
		if ($panther_user['is_admmod'])
		{
?>
		<div class="inform">
			<fieldset>
				<legend><?php echo $lang_warnings['Admin note'] ?></legend>
				<div class="infldset">
					<?php echo ($note_admin  == '') ? $lang_warnings['No admin note'] : $note_admin  ?>
			</div>
			</fieldset>
		</div>
<?php
		}

		// If private messaging system is enabled
		if ($panther_config['o_private_messaging'] == '1')
		{
?>
		<div class="inform">
			<fieldset>
				<legend><?php echo $lang_warnings['Private message sent'] ?></legend>
				<div class="infldset">
					<?php echo ($note_pm == '') ? $lang_warnings['No message'] : $note_pm ?>
			</div>
			</fieldset>
		</div>
<?php
		}
?>
		<div class="inform">
			<fieldset>
				<legend><?php echo $lang_warnings['Copy of post'] ?></legend>
				<div class="infldset">
<?php
					if ($warning_details['post_id'])
						echo "\t\t".$message."\n\t\t".'<p><a href="'.get_link($panther_url['post'], array($warning_details['post_id'])).'">'.$lang_warnings['Link to post'].'</a></p>';
					else
						echo "\t\t".'<p>'.$lang_warnings['Issued from profile'].'</p>';
?>
			</div>
			</fieldset>
		</div>
<?php
		if ($panther_user['is_admmod'] && ($panther_user['g_mod_warn_users'] == '1' || $panther_user['is_admin']))
		{
?>
		<div class="inform">
		<input type="hidden" name="delete_id" value="<?php echo $warning_id ?>" />
		<input type="hidden" name="user_id" value="<?php echo $warning_details['user_id'] ?>" />
		<input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>" />
			<fieldset>
				<legend><?php echo $lang_warnings['Delete'] ?></legend>
				<div class="infldset">
					<input type="submit" name="delete_warning" value="<?php echo $lang_warnings['Delete warning'] ?>" />
				</div>
			</fieldset>
		</div>
<?php
		}
?>
	</form>
	</div>
</div>
<div class="linksb">
	<div class="inbox crumbsplus">
		<ul class="crumbs">
			<li><a href="<?php echo get_link($panther_url['profile'], array($warning_details['user_id'], $url_username)); ?>"><?php echo panther_htmlspecialchars($username); ?></a></li>
			<li><span>»&#160;</span><a href="<?php echo get_link($panther_url['warning_view'], array($warning_details['user_id'])); ?>"><strong><?php echo panther_htmlspecialchars($lang_warnings['Warnings']) ?></strong></a></li>
			<li><span>»&#160;</span><a href="<?php echo get_link($panther_url['warning_details'], array($warning_id)); ?>"><strong><?php echo panther_htmlspecialchars($lang_warnings['Details']) ?></strong></a></li>
		</ul>
		<div class="clearer"></div>
	</div>
</div>
<?php
}
else if (isset($_POST['delete_id']))
{
	confirm_referrer('warnings.php');
	
	// Are we allowed to delete warnings?
	if (!$panther_user['is_admin'] && (!$panther_user['is_admmod'] || $panther_user['g_mod_warn_users'] == '0'))
		message($lang_common['No permission']);

	$warning_id = isset($_POST['delete_id']) ? intval($_POST['delete_id']) : 0;

	if ($warning_id < 1)
		message($lang_common['Bad request']);
	
	$data = array(
		':id'	=>	$warning_id,
	);

	// Delete the warning
	$db->delete('warnings', 'id=:id', $data);
	$user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;

	redirect(get_link($panther_url['warning_view'], array($user_id)), $lang_warnings['Warning deleted redirect']);
}
else if ($action == 'show_recent')
{
	if (!$panther_user['is_admmod'])
		message($lang_common['No permission']);

	// Fetch warnings count
	$ps = $db->select('warnings', 'COUNT(id)');
	$num_warnings = $ps->fetchColumn();

	// Determine the user offset (based on $_GET['p'])
	$num_pages = ceil($num_warnings / 50);

	$p = (!isset($_GET['p']) || !is_numeric($_GET['p']) || $_GET['p'] <= 1 || $_GET['p'] > $num_pages) ? 1 : $_GET['p'];
	$start_from = 50 * ($p - 1);

	// Generate paging links
	$paging_links = '<span class="pages-label">'.$lang_common['Pages'].' </span>'.paginate($num_pages, $p, $panther_url['warnings_recent']);
	$data = array(
		':start'	=>	$start_from,
	);

	$ps = $db->run('SELECT w.id, w.user_id, w.type_id, w.post_id, w.title AS custom_title, w.points, w.date_issued, w.date_expire, w.issued_by, t.title, u.username AS issued_by_username, u.group_id AS issuer_gid, v.username AS username, v.group_id AS user_gid FROM '.$db->prefix.'warnings as w LEFT JOIN '.$db->prefix.'warning_types AS t ON t.id=w.type_id LEFT JOIN '.$db->prefix.'users AS u ON u.id=w.issued_by LEFT JOIN '.$db->prefix.'users AS v ON v.id=w.user_id ORDER BY w.date_issued DESC LIMIT :start, 50', $data);
?>
<div class="linkst">
	<div class="inbox crumbsplus">
		<div class="pagepost">
			<p class="pagelink conl"><?php echo $paging_links ?></p>
		</div>
		<div class="clearer"></div>
	</div>
</div>
<div id="recent_warnings" class="blocktable">

	<h2><span><?php echo $lang_warnings['Recent warnings'] ?></span></h2>
	<div class="box">
		<div class="inbox">
		<table cellspacing="0">
		<thead>
			<tr>
				<th style="width: 35%" align="left" scope="col"><?php echo $lang_warnings['Warning 2'] ?></th>
				<th style="width: 18%" align="left" scope="col"><?php echo $lang_warnings['Date issued 2'] ?></th>
				<th class="tc3" style="width: 8%" scope="col"><?php echo $lang_warnings['Points'] ?></th>
				<th class="tcr" style="width: 16%" scope="col"><?php echo $lang_warnings['Warned user'] ?></th>
				<th class="tcr" style="width: 16%" scope="col"><?php echo $lang_warnings['Issued by 2'] ?></th>
				<th class="tc3" style="width: 7%" scope="col"><?php echo $lang_warnings['Details'] ?></th>
			</tr>
		</thead>
		<tbody>
<?php
	if ($ps->rowCount())
	{
		foreach ($ps as $active_warnings)
		{
			if ($active_warnings['custom_title'] != '')
				$warning_title = sprintf($lang_warnings['Custom warning'], panther_htmlspecialchars($active_warnings['custom_title']));
			else if ($active_warnings['title'] != '')
				$warning_title = panther_htmlspecialchars($active_warnings['title']);
			else
				$warning_title = '';	
?>
				<tr>
					<td style="width: 35%" align="left"><?php echo $warning_title ?></td>
					<td style="width: 18%" align="left"><?php echo format_time($active_warnings['date_issued']) ?></td>
					<td class="tc3" style="width: 8%"><?php echo $active_warnings['points'] ?></td>
					<td class="tcr" style="width: 17%"><?php echo ($active_warnings['username'] != '') ? colourize_group($active_warnings['username'], $active_warnings['user_gid'], $active_warnings['user_id']) : '' ?></td>
					<td class="tcr" style="width: 17%"><?php echo ($active_warnings['issued_by_username'] != '') ? colourize_group($active_warnings['issued_by_username'], $active_warnings['issuer_gid'], $active_warnings['issued_by']) : '' ?></td>
					<td class="tc3" style="width: 5%"><a href="<?php echo get_link($panther_url['warning_details'], array($active_warnings['id'])); ?>"><?php echo $lang_warnings['Details']; ?></a></td>
				</tr>
<?php
		}
	}
	else
	{
?>
				<tr>
					<td class="tcl" colspan="6"><?php echo $lang_warnings['No warnings'] ?></td>
				</tr>
<?php
	}
?>
			</tbody>
			</table>
		</div>
	</div>
</div>
<div class="postlinksb">
	<div class="inbox crumbsplus">
		<div class="pagepost">
			<p class="pagelink conl"><?php echo $paging_links ?></p>
		</div>
		<div class="clearer"></div>
	</div>
</div>
<?php
}
else
{
	$ps = $db->select('warning_types', 'id, title, description, points, expiration_time', array(), '', 'points, id');
	$ps1 = $db->select('warning_levels', 'id, points, period', array(), '', 'points, id');
	
	// If neither produces a result
	if (!$ps->rowCount() && !$ps1->rowCount())
		message($lang_common['Bad request']);
?>
<div id="warning_types" class="blocktable">
	<h2><span><?php echo $lang_warnings['Warning types'] ?></span></h2>
	<div class="box">
		<div class="inbox">
		<table>
		<thead>
			<tr>
				<th class="tcr" style="width: 30%" scope="col"><?php echo $lang_warnings['Name'] ?></th>
				<th class="tcr" style="width: 60%" scope="col"><?php echo $lang_warnings['Description'] ?></th>
				<th class="tc3" style="width: 10%" scope="col"><?php echo $lang_warnings['Points'] ?></th>
			</tr>
		</thead>
		<tbody>
<?php
	foreach ($ps as $list_types)
	{
?>
				<tr>
					<td class="tcr" style="width: 30%"><strong><?php echo $list_types['title'] ?></strong></td>
					<td class="tcr" style="width: 60%"><?php echo $list_types['description'] ?></td>
					<td class="tc3" style="width: 10%"><?php echo $list_types['points'] ?></td>
				</tr>
<?php
	}
?>
		</tbody>
		</table>
		</div>
	</div>
</div>
<div id="warning_levels" class="blocktable">

	<h2><span><?php echo $lang_warnings['Automatic bans'] ?></span></h2>
	<div class="box">
		<div class="inbox">
		<table>
		<thead>
			<tr>
				<th class="tcr" style="width: 60%" scope="col"><?php echo $lang_warnings['Ban period'] ?></th>
				<th class="tcr" style="width: 40%" scope="col"><?php echo $lang_warnings['Reason'] ?></th>
			</tr>
		</thead>
		<tbody>
<?php	
	foreach ($ps1 as $list_levels)
	{
		if ($list_levels['period'] == '0')
			$ban_title = $lang_warnings['Permanent ban'];
		else
			$ban_title = format_expiration_time($list_levels['period']);
?>
				<tr>
					<td class="tcr" style="width: 60%"><strong><?php echo $ban_title ?></strong></td>
					<td class="tcr" style="width: 40%"><?php printf($lang_warnings['No of points'], $list_levels['points']) ?></td>
				</tr>
<?php
	}
?>
		</tbody>
		</table>
		</div>
	</div>
</div>
<?php
}

$footer_style = 'warnings';
require PANTHER_ROOT.'footer.php';