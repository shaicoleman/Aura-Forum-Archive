<?php

/**
 *
 * This file is part of the Panther Forum Software package.
 *
 * @link      https://www.pantherforum.org/
 * @copyright Copyright (c) Panther <https://www.pantherforum.org/>
 * @license   GNU General Public License (GPL-3.0), Version 3, 29 June 2007 <http://opensource.org/licenses/GPL-3.0>
 *
 * For full information, please see README.md, CHANGELOG.md and LICENSE.md files which are located in the root folder.
 *
 */

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/');
	require PANTHER_ROOT.'include/common.php';
}

// Tell header.php we should use the editor
define('POSTING', 1);

if ($panther_user['g_read_board'] == '0')
	message($lang_common['No view'], false, '403 Forbidden');

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($id < 1)
	message($lang_common['Bad request'], false, '404 Not Found');

if ($panther_user['is_bot'])
	message($lang_common['No permission']);

// Fetch some info about the post, the topic and the forum
$data = array(
	':gid'	=>	$panther_user['g_id'],
	':id'	=>	$id,
);
$ps = $db->run('SELECT f.id AS fid, f.forum_name, f.moderators, f.password, f.redirect_url, f.last_topic_id, fp.post_replies, fp.post_polls, fp.post_topics, fp.upload, fp.delete_files, t.id AS tid, t.subject, t.archived, t.posted, t.first_post_id, t.sticky, t.closed, p.poster, p.posted AS pposted, p.poster_id, p.message, p.edit_reason, p.hide_smilies FROM '.$db->prefix.'posts AS p INNER JOIN '.$db->prefix.'topics AS t ON t.id=p.topic_id INNER JOIN '.$db->prefix.'forums AS f ON f.id=t.forum_id LEFT JOIN '.$db->prefix.'forum_perms AS fp ON (fp.forum_id=f.id AND fp.group_id=:gid) WHERE (fp.read_forum IS NULL OR fp.read_forum=1) AND p.id=:id', $data);
if (!$ps->rowCount())
	message($lang_common['Bad request'], false, '404 Not Found');

$cur_post = $ps->fetch();

// Sort out who the moderators are and if we are currently a moderator (or an admin)
$mods_array = ($cur_post['moderators'] != '') ? unserialize($cur_post['moderators']) : array();
$is_admmod = ($panther_user['is_admin'] || ($panther_user['g_moderator'] == '1' && $panther_user['g_global_moderator'] ||  array_key_exists($panther_user['username'], $mods_array))) ? true : false;

$can_edit_subject = $id == $cur_post['first_post_id'] && $panther_user['g_edit_subject'] == '1';

if ($panther_config['o_censoring'] == '1')
{
	$cur_post['subject'] = censor_words($cur_post['subject']);
	$cur_post['message'] = censor_words($cur_post['message']);
}

// Do we have permission to edit this post?
if (($panther_user['g_edit_posts'] == '0' || $cur_post['poster_id'] != $panther_user['id'] || $cur_post['closed'] == '1' || $panther_user['g_deledit_interval'] != 0 && (time() - $cur_post['pposted']) > $panther_user['g_deledit_interval']) && !$is_admmod)
	message($lang_common['No permission'], false, '403 Forbidden');

if ($is_admmod && (!$panther_user['is_admin'] && (in_array($cur_post['poster_id'], get_admin_ids()) && $panther_user['g_mod_edit_admin_posts'] == '0')))
	message($lang_common['No permission'], false, '403 Forbidden');

// Load the post.php language file
require PANTHER_ROOT.'lang/'.$panther_user['language'].'/post.php';
check_posting_ban();

if ($cur_post['archived'] == '1')
	message($lang_post['Topic archived']);

if ($cur_post['password'] != '')
	check_forum_login_cookie($cur_post['fid'], $cur_post['password']);

// Start with a clean slate
$errors = array();

if (isset($_POST['form_sent']))
{
	// Make sure they got here from the site
	confirm_referrer('edit.php');

	// If it's a topic it must contain a subject
	if ($can_edit_subject)
	{
		$subject = panther_trim($_POST['req_subject']);

		if ($panther_config['o_censoring'] == '1')
			$censored_subject = panther_trim(censor_words($subject));

		if ($subject == '')
			$errors[] = $lang_post['No subject'];
		else if ($panther_config['o_censoring'] == '1' && $censored_subject == '')
			$errors[] = $lang_post['No subject after censoring'];
		else if (panther_strlen($subject) > 70)
			$errors[] = $lang_post['Too long subject'];
		else if ($panther_config['p_subject_all_caps'] == '0' && is_all_uppercase($subject) && !$panther_user['is_admmod'])
			$errors[] = $lang_post['All caps subject'];
	}

	// Clean up message from POST
	$message = panther_linebreaks(panther_trim($_POST['req_message']));

	// Here we use strlen() not panther_strlen() as we want to limit the post to PANTHER_MAX_POSTSIZE bytes, not characters
	if (strlen($message) > PANTHER_MAX_POSTSIZE)
		$errors[] = sprintf($lang_post['Too long message'], forum_number_format(PANTHER_MAX_POSTSIZE));
	else if ($panther_config['p_message_all_caps'] == '0' && is_all_uppercase($message) && !$panther_user['is_admmod'])
		$errors[] = $lang_post['All caps message'];

	// Validate BBCode syntax
	if ($panther_config['p_message_bbcode'] == '1')
	{
		require PANTHER_ROOT.'include/parser.php';
		$message = preparse_bbcode($message, $errors);
	}

	if (empty($errors))
	{
		if ($message == '')
			$errors[] = $lang_post['No message'];
		else if ($panther_config['o_censoring'] == '1')
		{
			// Censor message to see if that causes problems
			$censored_message = panther_trim(censor_words($message));

			if ($censored_message == '')
				$errors[] = $lang_post['No message after censoring'];
		}
	}

	$hide_smilies = isset($_POST['hide_smilies']) ? '1' : '0';
	$stick_topic = isset($_POST['stick_topic']) ? '1' : '0';
	$add_poll = isset($_POST['add_poll']) && $cur_post['post_polls'] != '0' && $panther_user['g_post_polls'] == '1' && $panther_config['o_polls'] == '1' ? '1' : '0';

	if (!$is_admmod)
		$stick_topic = $cur_post['sticky'];

	// Replace four-byte characters (MySQL cannot handle them)
	$message = strip_bad_multibyte_chars($message);

	// Did everything go according to plan?
	if (empty($errors) && !isset($_POST['preview']))
	{
		$edit_reason = (isset($_POST['edit_reason']) && $is_admmod) ? panther_trim($_POST['edit_reason']): $cur_post['edit_reason'];
		require PANTHER_ROOT.'include/search_idx.php';

		if ($can_edit_subject)
		{
			$update = array(
				'subject'	=>	$subject,
				'sticky'	=>	$stick_topic,
			);

			$data = array(
				':id'	=>	$cur_post['tid'],
				':moved'	=>	$cur_post['tid'],
			);

			// Update the topic and any redirect topics
			$db->update('topics', $update, 'id=:id OR moved_to=:moved', $data);

			// We changed the subject, so we need to take that into account when we update the search words
			update_search_index('edit', $id, $message, $subject);

			// If this is the last topic in the forum, and we've changed the subject, we need to update that
			if ($cur_post['last_topic_id'] == $cur_post['tid'] && $subject != $cur_post['subject'])
				update_forum($cur_post['fid']);
		}
		else
			update_search_index('edit', $id, $message);

		$update = array(
			'message'	=>	$message,
			'edit_reason'	=>	$edit_reason,
			'hide_smilies'	=>	$hide_smilies,
		);
		
		if (!isset($_POST['silent']) || !$is_admmod)
		{
			$update['edited'] = time();
			$update['edited_by'] = $panther_user['username'];
		}
		
		$data = array(
			':id'	=>	$id,
		);

		// Update the post
		$db->update('posts', $update, 'id=:id', $data);
		$data = array(
			':id'	=>	$id,
		);

		$ps = $db->select('attachments', 'COUNT(id)', $data, 'post_id=:id');
		if ($ps->rowCount())
		{
			$num_attachments = $ps->fetchColumn();
			for ($i = 0; $i < $num_attachments; $i++)
			{
				if (array_key_exists('attach_delete_'.$i, $_POST))
				{
					$attach_id = intval($_POST['attach_delete_'.$i]);
					$data = array(
						':id'	=>	$attach_id,
					);

					$ps = $db->select('attachments', 'owner', $data, 'id=:id', 1);
					if ($ps->rowCount() || $is_admmod)
					{
						$owner = $ps->fetchColumn();
						$can_delete = false;

						if ($panther_user['is_admin'])
							$can_delete = true;
						else
							$can_delete = (($is_admmod || $panther_user['g_delete_posts'] == '1' && $owner == $panther_user['id']) && ($cur_post['delete_files'] == '1' || $cur_post['delete_files'] == '')) ? true : false;
							
						if($can_delete)
						{
							if (!delete_attachment($attach_id))
									message($lang_post['Can\'t delete']);
						}
						else
							message($lang_post['No delete']);
					}
					else
						message($lang_post['No attachments']);
				}
			}
		}

		if (isset($_FILES['attached_file']))
		{
			if (isset($_FILES['attached_file']['error']) && $_FILES['attached_file']['error'] != 0 && $_FILES['attached_file']['error'] != 4)
				error(file_upload_error_message($_FILES['attached_file']['error']), __FILE__, __LINE__);

			if ($_FILES['attached_file']['size'] != 0 && is_uploaded_file($_FILES['attached_file']['tmp_name']))
			{
				$can_upload = false;
				if ($panther_user['is_admin'])
					$can_upload = true;
				else
				{
					$data = array(
						':id'	=>	$id,
					);

					$ps = $db->select('attachments', 'COUNT(id)', $data, 'post_id=:id GROUP BY post_id', 1);
					$num_attachments = $ps->fetchColumn();

					$can_upload = ($panther_user['g_attach_files'] == '1' && ($cur_post['upload'] == '1' || $cur_post['upload'] == '')) ? true : false;
					
					if ($can_upload && $num_attachments == $panther_user['g_max_attachments'])
						$can_upload = false;

					$max_size = ($panther_user['g_max_size'] == '0' && $panther_user['g_attach_files'] == '1') ? $panther_config['o_max_upload_size'] : $panther_user['g_max_size'];
					if ($can_upload && $_FILES['attached_file']['size'] > $max_size)
						$can_upload = false;

					if (!check_file_extension($_FILES['attached_file']['name']))
						$can_upload = false;
				}

				if($can_upload)
				{
					if (!create_attachment($_FILES['attached_file']['name'], $_FILES['attached_file']['type'], $_FILES['attached_file']['size'], $_FILES['attached_file']['tmp_name'], $id, strlen($message)))
						message($lang_post['Attachment error']);
				}
				else // Remove file as it's either dangerous or they've attempted to URL hack. Either way, there's no need for it.
					unlink($_FILES['attached_file']['tmp_name']);
			}
		}
		
	flux_hook('edit_after_edit');

	if ($add_poll)
		redirect('poll_add.php?id='.$cur_post['tid'], $lang_post['Edit redirect']);
	else
		redirect(get_link($panther_url['post'], array($id)), $lang_post['Edit redirect']);
	}
}

$can_delete = false;
$can_upload = false;
if ($panther_user['is_admin'])
{
	$can_delete = true;
	$can_upload = true;
}
else
{
	$can_delete = (($is_admmod || $panther_user['g_delete_posts'] == '1') && ($cur_post['delete_files'] == '1' || $cur_post['delete_files'] == '')) ? true : false;
	$can_upload = ($panther_user['g_attach_files'] == '1' && ($cur_post['upload'] == '1' || $cur_post['upload'] == '')) ? true : false;
}

if ($can_delete || $can_upload)
{
	$max_size = ($panther_user['g_max_size'] == '0' && $panther_user['g_attach_files'] == '1') ? $panther_config['o_max_upload_size'] : $panther_user['g_max_size'];
	$data = array(
			':id'	=>	$id,
	);

	$ps = $db->select('attachments', 'id, owner, filename, extension, size, downloads', $data, 'post_id=:id');
	if ($ps->rowCount())
	{
		$attachments = array();
		for ($i = 0; $attachment = $ps->fetch(); $i++)
		{
			if ($can_delete)
				$attachments[] = '<input type="checkbox" name="attach_delete_'.$i.'" value="'.$attachment['id'].'" />'.$lang_post['Delete attachment'].' '.attach_icon($attachment['extension']).' <a href="'.get_link($panther_url['attachment'], array($attachment['id'])).'">'.panther_htmlspecialchars($attachment['filename']).'</a>, '.sprintf($lang_post['Attachment size'], file_size($attachment['size'])).', '.sprintf($lang_post['Attachment downloads'], number_format($attachment['downloads']));
			else
				$attachments[] = attach_icon($attachment['extension']).' <a href="'.get_link($panther_url['attachment'], array($attachment['id'])).'">'.panther_htmlspecialchars($attachment['filename']).'</a>, '.sprintf($lang_post['Attachment size'], file_size($attachment['size'])).', '.sprintf($lang_post['Attachment downloads'], number_format($attachment['downloads']));
		}
	}
}

$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_post['Edit post']);
$required_fields = array('req_subject' => $lang_common['Subject'], 'req_message' => $lang_common['Message']);
$focus_element = array('edit', 'req_message');
define('PANTHER_ACTIVE_PAGE', 'index');
require PANTHER_ROOT.'header.php';

$cur_index = 1;
?>
<div class="linkst">
	<div class="inbox">
		<ul class="crumbs">
			<li><a href="<?php echo get_link($panther_url['index']); ?>"><?php echo $lang_common['Index'] ?></a></li>
			<li><span>»&#160;</span><a href="<?php echo get_link($panther_url['forum'], array($cur_post['fid'], url_friendly($cur_post['forum_name']))) ?>"><?php echo panther_htmlspecialchars($cur_post['forum_name']) ?></a></li>
			<li><span>»&#160;</span><a href="<?php echo get_link($panther_url['topic'], array($cur_post['tid'], url_friendly($cur_post['subject']))) ?>"><?php echo panther_htmlspecialchars($cur_post['subject']) ?></a></li>
			<li><span>»&#160;</span><strong><?php echo $lang_post['Edit post'] ?></strong></li>
		</ul>
	</div>
</div>
<?php
// If there are errors, we display them
if (!empty($errors))
{
?>
<div id="posterror" class="block">
	<h2><span><?php echo $lang_post['Post errors'] ?></span></h2>
	<div class="box">
		<div class="inbox error-info">
			<p><?php echo $lang_post['Post errors info'] ?></p>
			<ul class="error-list">
<?php
	foreach ($errors as $cur_error)
		echo "\t\t\t\t".'<li><strong>'.$cur_error.'</strong></li>'."\n";
?>
			</ul>
		</div>
	</div>
</div>
<?php
}
else if (isset($_POST['preview']))
{
	require_once PANTHER_ROOT.'include/parser.php';
	$preview_message = parse_message($message, $hide_smilies);
?>
<div id="postpreview" class="blockpost">
	<h2><span><?php echo $lang_post['Post preview'] ?></span></h2>
	<div class="box">
		<div class="inbox">
			<div class="postbody">
				<div class="postright">
					<div class="postmsg">
						<?php echo $preview_message."\n" ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
}
?>
<div id="editform" class="blockform">
	<h2><span><?php echo $lang_post['Edit post'] ?></span></h2>
	<div class="box">
		<form id="edit" method="post" action="<?php echo get_link($panther_url['edit_edit'], array($id)); ?>" enctype="multipart/form-data" onsubmit="return process_form(this)">
			<input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>" />
			<div class="inform">
				<fieldset>
					<legend><?php echo $lang_post['Edit post legend'] ?></legend>
					<input type="hidden" name="form_sent" value="1" />
					<div class="infldset txtarea">
<?php if ($can_edit_subject): ?>						<label class="required"><strong><?php echo $lang_common['Subject'] ?> <span><?php echo $lang_common['Required'] ?></span></strong><br />
						<input class="longinput" type="text" name="req_subject" size="80" maxlength="70" tabindex="<?php echo $cur_index++ ?>" value="<?php echo panther_htmlspecialchars(isset($_POST['req_subject']) ? $_POST['req_subject'] : $cur_post['subject']) ?>" /><br /></label>
<?php endif; ?>						<label class="required"><strong><?php echo $lang_common['Message'] ?> <span><?php echo $lang_common['Required'] ?></span></strong><br />
						<textarea name="req_message" class="scedit_bbcode" rows="20" cols="95" tabindex="<?php echo $cur_index++ ?>"><?php echo panther_htmlspecialchars(isset($_POST['req_message']) ? $message : $cur_post['message']) ?></textarea><br /></label>
						<ul class="bblinks">
							<li><span><a href="<?php echo get_link($panther_url['help'], array('bbcode')); ?>" onclick="window.open(this.href); return false;"><?php echo $lang_common['BBCode'] ?></a> <?php echo ($panther_config['p_message_bbcode'] == '1') ? $lang_common['on'] : $lang_common['off']; ?></span></li>
							<li><span><a href="<?php echo get_link($panther_url['help'], array('url')); ?>" onclick="window.open(this.href); return false;"><?php echo $lang_common['url tag'] ?></a> <?php echo ($panther_config['p_message_bbcode'] == '1' && $panther_user['g_post_links'] == '1') ? $lang_common['on'] : $lang_common['off']; ?></span></li>
							<li><span><a href="<?php echo get_link($panther_url['help'], array('img')); ?>" onclick="window.open(this.href); return false;"><?php echo $lang_common['img tag'] ?></a> <?php echo ($panther_config['p_message_bbcode'] == '1' && $panther_config['p_message_img_tag'] == '1') ? $lang_common['on'] : $lang_common['off']; ?></span></li>
							<li><span><a href="<?php echo get_link($panther_url['help'], array('smilies')); ?>" onclick="window.open(this.href); return false;"><?php echo $lang_common['Smilies'] ?></a> <?php echo ($panther_config['o_smilies'] == '1') ? $lang_common['on'] : $lang_common['off']; ?></span></li>
						</ul>
					</div>
				</fieldset>
<?php
if ($can_upload || $can_delete)
{
	if ($panther_user['g_max_attachments'] == '0')
		$panther_user['g_max_attachments'] = '<em>unlimited</em>';

	if ($can_upload)
		$attachments[] = sprintf($lang_post['Upload'], $panther_user['g_max_attachments'])."<br />\n".'<input type="hidden" name="MAX_FILE_SIZE" value="'.$max_size.'" /><input type="file" name="attached_file" size="80" />';
?>
			</div>
			<div class="inform">
				<fieldset>
					<legend><?php echo $lang_post['Attachment'] ?></legend>
					<div class="infldset">
					<?php echo (($can_delete) ? $lang_post['Attachment existing delete'] : $lang_post['Attachment existing nodelete']).implode('<br />'."\n", $attachments); ?><br />
						<?php echo $lang_post['Note']; ?>
					</div>
				</fieldset>
<?php
}

$checkboxes = array();
if ($can_edit_subject && $is_admmod)
{
	if (isset($_POST['stick_topic']) || $cur_post['sticky'] == '1')
		$checkboxes[] = '<label><input type="checkbox" name="stick_topic" value="1" checked="checked" tabindex="'.($cur_index++).'" />'.$lang_common['Stick topic'].'<br /></label>';
	else
		$checkboxes[] = '<label><input type="checkbox" name="stick_topic" value="1" tabindex="'.($cur_index++).'" />'.$lang_common['Stick topic'].'<br /></label>';
}

if ($can_edit_subject)
{
	if ($cur_post['post_polls'] != '0' && $panther_user['g_post_polls'] == '1' && $panther_config['o_polls'] == '1')
		$checkboxes[] = '<label><input type="checkbox" name="add_poll" value="1" tabindex="'.($cur_index++).'"'.(isset($_POST['add_poll']) ? ' checked="checked"' : '').' />'.$lang_post['Add poll'].'<br /></label>';
}

if ($panther_config['o_smilies'] == '1')
{
	if (isset($_POST['hide_smilies']) || $cur_post['hide_smilies'] == '1')
		$checkboxes[] = '<label><input type="checkbox" name="hide_smilies" value="1" checked="checked" tabindex="'.($cur_index++).'" />'.$lang_post['Hide smilies'].'<br /></label>';
	else
		$checkboxes[] = '<label><input type="checkbox" name="hide_smilies" value="1" tabindex="'.($cur_index++).'" />'.$lang_post['Hide smilies'].'<br /></label>';
}

if ($is_admmod)
{
	if ((isset($_POST['form_sent']) && isset($_POST['silent'])) || !isset($_POST['form_sent']))
		$checkboxes[] = '<label><input type="checkbox" id="silent_edit" name="silent" value="1" tabindex="'.($cur_index++).'" checked="checked" />'.$lang_post['Silent edit'].'<br /></label>';
	else
		$checkboxes[] = '<label><input type="checkbox" id="silent_edit" name="silent" value="1" tabindex="'.($cur_index++).'" />'.$lang_post['Silent edit'].'<br /></label>';
}

if (!empty($checkboxes))
{
?>
			</div>
			<div class="inform">
				<fieldset>
					<legend><?php echo $lang_common['Options'] ?></legend>
					<div class="infldset">
						<div class="rbox">
							<?php echo implode("\n\t\t\t\t\t\t\t", $checkboxes)."\n" ?>
						</div>
						<?php if ($is_admmod) echo $lang_post['Edit reason'].' <input class="input" type="text" name="edit_reason" size="40" maxlength="50" tabindex="'.($cur_index++).'" onkeyup="if (this.value != \'\') document.getElementById(\'silent_edit\').checked = false;" value="'.(panther_htmlspecialchars(isset($_POST['edit_reason']) ? $_POST['edit_reason'] : $cur_post['edit_reason'])).'" /><br /><br />'; ?>
					</div>
				</fieldset>
<?php
}
?>
			</div>
			<p class="buttons"><input type="submit" id="submit" value="<?php echo $lang_common['Submit'] ?>" tabindex="<?php echo $cur_index++ ?>" accesskey="s" /> <input type="submit" name="preview" value="<?php echo $lang_post['Preview'] ?>" tabindex="<?php echo $cur_index++ ?>" accesskey="p" /> <a href="javascript:history.go(-1)"><?php echo $lang_common['Go back'] ?></a></p>
		</form>
	</div>
</div>
<?php
require PANTHER_ROOT.'footer.php';