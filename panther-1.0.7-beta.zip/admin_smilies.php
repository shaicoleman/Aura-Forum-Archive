<?php

/**
 *
 * This file is part of the Panther Forum Software package.
 *
 * @link      https://www.pantherforum.org/
 * @copyright Copyright (c) Panther <https://www.pantherforum.org/>
 * @license   GNU General Public License (GPL-3.0), Version 3, 29 June 2007 <http://opensource.org/licenses/GPL-3.0>
 *
 * For full information, please see README.md, CHANGELOG.md and LICENSE.md files which are located in the root folder.
 *
 */

// Tell header.php to use the admin template
define('PANTHER_ADMIN_CONSOLE', 1);

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/');
	require PANTHER_ROOT.'include/common.php';
}

require PANTHER_ROOT.'include/common_admin.php';

if (!$panther_user['is_admin'])
	message($lang_common['No permission'], false, '403 Forbidden');

if ($panther_config['o_smilies'] == '0')
	message($lang_common['Bad request']);
	
// Load the admin_smilies.php language file
require PANTHER_ROOT.'lang/'.$admin_language.'/admin_smilies.php';

check_authentication();

if ($panther_user['id'] != '2')
{
	if(!is_null($admins[$panther_user['id']]['admin_smilies']))
	{
		if ($admins[$panther_user['id']]['admin_smilies'] == '0')
			message($lang_common['No permission']);
	}
}


$smiley_path = ($panther_config['o_smilies_dir'] != '') ? $panther_config['o_smilies_path'] : PANTHER_ROOT.$panther_config['o_smilies_path'].'/';
$smiley_dir = ($panther_config['o_smilies_dir'] != '') ? $panther_config['o_smilies_dir'] : panther_htmlspecialchars(get_base_url(true).'/'.$panther_config['o_smilies_path'].'/');

// Retrieve the smiley images
$img_smilies = array();
$d = dir($smiley_path);
while (($entry = $d->read()) !== false)
{
	if ($entry != '.' && $entry != '..' && $entry != 'index.html')
		$img_smilies[] = $entry;
}
$d->close();
@natsort($img_smilies);

if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
	require PANTHER_ROOT.'include/cache.php';

// Change smilies texts, images and positions
if (isset($_POST['reorder']))
{
	$smilies_order = array_map('intval', $_POST['smilies_order']);
	$smilies_img = array_map('panther_trim', $_POST['smilies_img']);
	$smilies_code = array_map('panther_trim', $_POST['smilies_code']);
	
	$smiley_dups = array();
	foreach ($smilies_code as $code)	// Checking smilies codes
	{
		if ($code == '')
			message($lang_admin_smilies['Create Smiley Code None']);
	
		if (in_array($code, $smiley_dups))
			message(sprintf($lang_admin_smilies['Duplicate smilies code'], $code));
		else
			$smiley_dups[] = $code;
	}

	$ps = $db->select('smilies', 'id', array(), '', 'disp_position');
	foreach ($ps as $db_smilies)
	{
		$update = array(
			'code'	=>	$smilies_code[$db_smilies['id']],
			'image'	=>	$smilies_img[$db_smilies['id']],
			'disp_position'	=>	$db_smilies['id'],
		);
		
		$data = array(
			':id'	=>	$smilies_order[$db_smilies['id']],
		);

		$db->update('smilies', $update, 'id=:id', $data);
	}
	
		generate_smilies_cache();
		redirect(get_link($panther_url['admin_smilies']), $lang_admin_smilies['Smilies edited']);
}

if (isset($_POST['remove']))
{
	if (empty($_POST['remove_smilies']) || !is_array($_POST['remove_smilies']))
		message($lang_admin_smilies['No Smileys']);
		
	$smilies = array_map('intval', $_POST['remove_smilies']);
	$markers = $data = array();
	for ($i = 0; $i < count($smilies); $i++)
		$markers[] = '?';
	
	// Delete smilies
	$db->delete('smilies', 'id IN('.implode(', ', $markers).')', array_values($smilies));

	generate_smilies_cache();
	redirect(get_link($panther_url['admin_smilies']), $lang_admin_smilies['Delete Smiley Redirect']);
}

if (isset($_POST['add_smiley']))
{
	$smiley_code = panther_trim($_POST['smiley_code']);
	$smiley_image = panther_trim($_POST['smiley_image']);

	// Checking text code and image
	if ($smiley_code == '')
		message($lang_admin_smilies['Create Smiley Code None']);

	if ($smiley_image == '')
		message($lang_admin_smilies['Create Smiley Image None']);
		
	$insert = array(
		'image'	=>	$smiley_image,
		'code'	=>	$smiley_code,
	);

	// Add the smiley
	$db->insert('smilies', $insert);

	generate_smilies_cache();
	redirect(get_link($panther_url['admin_smilies']), $lang_admin_smilies['Successful Creation']);
}

if (isset($_POST['delete']))
{
	if (empty($_POST['del_smilies']))
		message($lang_admin_smilies['No Images']);
	
	$smilies = array_map('trim', $_POST['del_smilies']);
	$to_delete = $affected = $deleted = array();
	
	// Checking if images to delete are used by some smilies
	$smiley_img = array_unique(array_values($smilies));
	foreach (array_keys($smilies) as $img)
	{
		if (!in_array($img, $smiley_img))
			$to_delete[] = $img;
		else
			$affected[] = $img;
	}
	
	if (!empty($affected))
		message(sprintf($lang_admin_smilies['Images affected'], implode(', ', $affected)));
	else
	{
		foreach ($to_delete as $img)
		{
			if (!@unlink($smiley_path.'/'.$img))
				$deleted[] = $img;
		}
	}
	
	if (!empty($deleted))
		$message = sprintf($lang_admin_smilies['Images not deleted'], implode(', ', $deleted));
	else
		$message = $lang_admin_smilies['Images deleted'];
	
	redirect(get_link($panther_url['admin_smilies']), $message);
}

if (isset($_POST['add_image']))
{
	if (!isset($_FILES['req_file']))
		message($lang_admin_smilies['No file']);
	
	$uploaded_file = $_FILES['req_file'];
	
	// Make sure the upload went smooth
	if (isset($uploaded_file['error']))
	{
		switch ($uploaded_file['error'])
		{
			case 1:	// UPLOAD_ERR_INI_SIZE
			case 2:	// UPLOAD_ERR_FORM_SIZE
				message($lang_admin_smilies['Too large ini']);
			break;
			case 3:	// UPLOAD_ERR_PARTIAL
				message($lang_admin_smilies['Partial upload']);
			break;
			case 4:	// UPLOAD_ERR_NO_FILE
				message($lang_admin_smilies['No file']);
			break;
			case 6:	// UPLOAD_ERR_NO_TMP_DIR
				message($lang_admin_smilies['No tmp directory']);
			break;
			default:
				// No error occured, but was something actually uploaded?
				if ($uploaded_file['size'] == 0)
					message($lang_admin_smilies['No file']);
			break;
		}
	}
	
	if (is_uploaded_file($uploaded_file['tmp_name']))
	{
		$filename = substr($uploaded_file['name'], 0, strpos($uploaded_file['name'], '.'));
	
		// Check types
		$allowed_types = array('image/gif', 'image/jpeg', 'image/pjpeg', 'image/png', 'image/x-png');
		if (!in_array($uploaded_file['type'], $allowed_types))
			message($lang_admin_smilies['Bad type']);
	
		// Make sure the file isn't too big
		if ($uploaded_file['size'] > $panther_config['o_smilies_size'])
			message($lang_admin_smilies['Too large'].' '.$panther_config['o_smilies_size'].' '.$lang_admin_smilies['bytes'].'.');
	
		// Determine type
		$extensions = null;
		if ($uploaded_file['type'] == 'image/gif')
			$extensions = array('.gif', '.jpg', '.png');
		else if ($uploaded_file['type'] == 'image/jpeg' || $uploaded_file['type'] == 'image/pjpeg')
			$extensions = array('.jpg', '.gif', '.png');
		else
			$extensions = array('.png', '.gif', '.jpg');
	
		// Move the file to the avatar directory. We do this before checking the width/height to circumvent open_basedir restrictions.
		if (!@move_uploaded_file($uploaded_file['tmp_name'], $smiley_path.'/'.$filename.'.tmp'))
			message($lang_admin_smilies['Move failed']);
	
		// Now check the width/height
		list($width, $height, $type,) = getimagesize($smiley_path.'/'.$filename.'.tmp');
		if (empty($width) || empty($height) || $width > $panther_config['o_smilies_width'] || $height > $panther_config['o_smilies_height'])
		{
			@unlink($smiley_path.'/'.$filename.'.tmp');
			message($lang_admin_smilies['Too wide or high'].' '.$panther_config['o_smilies_width'].'x'.$panther_config['o_smilies_height'].' '.$lang_admin_smilies['pixels'].'.');
		}
		else if ($type == 1 && $uploaded_file['type'] != 'image/gif')	// Prevent dodgy uploads
		{
			@unlink($smiley_path.'/'.$filename.'.tmp');
			message($lang_admin_smilies['Bad type']);
		}
	
		// Delete any old images and put the new one in place
		@unlink($smiley_path.'/'.$filename.$extensions[0]);
		@unlink($smiley_path.'/'.$filename.$extensions[1]);
		@unlink($smiley_path.'/'.$filename.$extensions[2]);
		@rename($smiley_path.'/'.$filename.'.tmp', $smiley_path.'/'.$filename.$extensions[0]);
		
		compress_image($smiley_path.'/'.$filename.$extensions[0]);
		@chmod($smiley_path.'/'.$filename.$extensions[0], 0644);
	}
	else
		message($lang_admin_smilies['Unknown failure']);
	
	redirect(get_link($panther_url['admin_smilies']), $lang_admin_smilies['Successful Upload']);
}

$ps = $db->select('smilies', 'id, image, code, disp_position', array(), '', 'disp_position');
$smiley_dir = ($smiley_dir != '') ? $smiley_dir : panther_htmlspecialchars(get_base_url(true).'/'.$smiley_path.'/');

$i = 0;
$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_admin_common['Admin'], $lang_admin_common['Smilies']);
define('PANTHER_ACTIVE_PAGE', 'admin');
require PANTHER_ROOT.'header.php';
generate_admin_menu('smilies');
?>
	<div class="blockform">
		<h2 class="block2"><span><?php echo $lang_admin_smilies['Current Smilies'] ?></span></h2>
		<div class="box">
<?php
if ($ps->rowCount())
{
?>
			<form method="post" action="<?php echo get_link($panther_url['admin_smilies']); ?>">
				<div class="inform">
					<fieldset>
						<legend><?php echo $lang_admin_smilies['List Current Smilies'] ?></legend>
						<div class="infldset">
							<table>
								<thead><tr>
									<th scope="col"><?php echo $lang_admin_smilies['Position'] ?></th>
									<th scope="col"><?php echo $lang_admin_smilies['Image Filename'] ?></th>
									<th scope="col"><?php echo $lang_admin_smilies['Code'] ?></th>
									<th scope="col"><?php echo $lang_admin_smilies['Image'] ?></th>
									<th scope="col"><?php echo $lang_admin_smilies['Remove'] ?></th>
								</tr></thead>
								<tbody>
<?php
	foreach ($ps as $db_smilies)
	{
?>
									<tr>
										<th scope="row"><input type="text" name="smilies_order[<?php echo $db_smilies['id'] ?>]" value="<?php echo $db_smilies['disp_position'] ?>" size="3" maxlength="3" /></th>
										<td><select name="smilies_img[<?php echo $db_smilies['id'] ?>]">
<?php
		foreach ($img_smilies as $img)
			echo "\t\t\t\t\t\t\t\t\t\t\t".'<option'.(($img == $db_smilies['image']) ? ' selected="selected"' : '').' value="'.$img.'">'.$img.'</option>'."\n";
?>
										</select></td>
										<td><input type="text" name="smilies_code[<?php echo $db_smilies['id'] ?>]" value="<?php echo panther_htmlspecialchars($db_smilies['code']) ?>" size="5" maxlength="60" /></td>
										<td><img src="<?php echo panther_htmlspecialchars($smiley_dir.$db_smilies['image']) ?>" alt="<?php echo panther_htmlspecialchars($db_smilies['code']) ?>" /></td>
										<td><input name="remove_smilies[<?php echo $i; ?>]" type="checkbox" value="<?php echo $db_smilies['id'] ?>" /></td>
									</tr>
<?php
		$i++;
	}
?>
								</tbody>
							</table>
						</div>
					</fieldset>
				</div>
				<p class="submitend"><input name="reorder" type="submit" value="<?php echo $lang_admin_smilies['Edit smilies'] ?>" /> <input name="remove" type="submit" value="<?php echo $lang_admin_smilies['Remove Selected'] ?>" /></p>
			</form>
<?php
}
else
{
?>
			<div class="fakeform">
				<div class="inbox">
					<p><?php echo $lang_admin_smilies['No smiley'] ?></p>
				</div>
			</div>
<?php
}
?>
			<form method="post" action="<?php echo get_link($panther_url['admin_smilies']); ?>">
				<div class="inform">
					<fieldset>
						<legend><?php echo $lang_admin_smilies['Submit New Smiley'] ?></legend>
						<div class="infldset">
							<table class="aligntop" cellspacing="0">
								<tr>
									<th scope="row"><?php echo $lang_admin_smilies['Smiley Code'] ?></th>
									<td>
										<input type="text" name="smiley_code" size="25" />
										<span><?php echo $lang_admin_smilies['Smiley Code Description'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_smilies['Smiley Image'] ?></th>
									<td>
										<select name="smiley_image">
											<option selected="selected" value=""><?php echo $lang_admin_smilies['Choose Image'] ?></option>
<?php
		foreach ($img_smilies as $img)
			echo "\t\t\t\t\t\t\t\t\t\t\t".'<option value="'.$img.'">'.$img.'</option>'."\n";
?>
										</select>
										<span><?php echo $lang_admin_smilies['Smiley Image Description'] ?></span>
									</td>
								</tr>
							</table>
						</div>
					</fieldset>
				</div>
				<p class="submitend"><input type="submit" name="add_smiley" value="<?php echo $lang_admin_smilies['Submit Smiley'] ?>" /></p>
			</form>
		</div>
		<h2 class="block2"><span><?php echo $lang_admin_smilies['Current Images'] ?></span></h2>
		<div class="box">
			<form method="post" action="<?php echo get_link($panther_url['admin_smilies']); ?>">
				<div class="inform">
					<fieldset>
						<legend><?php echo $lang_admin_smilies['List Images Smilies'] ?></legend>
						<div class="infldset">
<?php
?>
							<table>
								<thead><tr>
									<th scope="col"><?php echo $lang_admin_smilies['Image Filename']; ?></th>
									<th scope="col"><?php echo $lang_admin_smilies['Image']; ?></th>
									<th scope="col"><?php echo $lang_admin_smilies['Delete']; ?></th>
								</tr></thead>
								<tbody>
<?php
		foreach ($img_smilies as $img)
		{
?>
									<tr>
										<th scope="row"><?php echo $img ?></th>
										<td><img src="<?php echo $smiley_dir.$img ?>" alt="" /></td>
										<td><input name="del_smilies[<?php echo $img ?>]" type="checkbox" value="1" /></td>
									</tr>
<?php
		}
?>
								</tbody>
							</table>
						</div>
					</fieldset>
				</div>
				<p class="submitend"><input name="delete" type="submit" value="<?php echo $lang_admin_smilies['Delete Selected'] ?>" /></p>
			</form>
			<form method="post" enctype="multipart/form-data" action="<?php echo get_link($panther_url['admin_smilies']); ?>">
				<div class="inform">
					<fieldset>
						<legend><?php echo $lang_admin_smilies['Add Images Smilies'] ?></legend>
						<div class="infldset">
							<label><?php echo $lang_admin_smilies['Image file'] ?>&nbsp;&nbsp;<input name="req_file" type="file" size="40" /></label>
						</div>
					</fieldset>
				</div>
				<p class="submitend"><input name="add_image" type="submit" value="<?php echo $lang_admin_smilies['Upload'] ?>" /></p>
			</form>
		</div>
	</div>
<?php
require PANTHER_ROOT.'footer.php';