<?php

/**
 *
 * This file is part of the Panther Forum Software package.
 *
 * @link      https://www.pantherforum.org/
 * @copyright Copyright (c) Panther <https://www.pantherforum.org/>
 * @license   GNU General Public License (GPL-3.0), Version 3, 29 June 2007 <http://opensource.org/licenses/GPL-3.0>
 *
 * For full information, please see README.md, CHANGELOG.md and LICENSE.md files which are located in the root folder.
 *
 */

// Language definitions used in admin_index.php
$lang_admin_index = array(
    
    'Running latest version message' => 'You are running the latest version of Panther.',
    'New version available message' => 'A new version of Panther has been released. You can download the latest version at %s.',
    'Deleted install.php redirect' => 'The file was successfully removed. Redirecting …',
    'Delete install.php failed' => 'Could not remove install.php. Please do so by hand.',
    'No restrictions' => 'We have detected one or more administrator accounts with full privileges on the system. These users are not restricted at all and have the ability to modify or delete anything. We recommend you configure restrictions for these users <a href="%s">here</a>.',
    'update downloaded' => 'The patch update for Panther version %s has been downloaded. You can install this patch <a href="%s">here</a>.',
    'Not available' => 'Not available',
    'Forum admin head' => 'Forum administration',
    'NA' => 'N/A',
    'Welcome to admin' => 'Welcome to the Panther administration control panel. From here you can control vital aspects of the board. Depending on whether you are an administrator or a moderator you can:',
    'Welcome 1' => 'Organize categories and forums.',
    'Welcome 2' => 'Set forum-wide options and preferences.',
    'Welcome 3' => 'Control permissions for users and guests.',
    'Welcome 4' => 'View IP statistics for users.',
    'Welcome 5' => 'Restore deleted posts and topics.',
    'Welcome 6' => 'Approve posts and topics.',
    'Welcome 7' => 'Ban users.',
    'Welcome 8' => 'Censor words.',
    'Welcome 9' => 'Set up user groups and promotions.',
    'Welcome 10' => 'Prune old posts.',
    'Welcome 11' => 'Handle post reports.',
    'Welcome 12' => 'Handle topic archiving.',
    'Welcome 13' => 'Issue restrictions.',
    'Welcome 14' => 'Merge user accounts.',
    'Welcome 15' => 'Add, edit or alter user ranks.',
    'Alerts head' => 'Alerts',
    'Notes head' => 'Admin Notes',
    'Install file exists' => 'The file install.php still exists, but should be removed. %s.',
    'New version' => 'Panther version <strong>%s</strong> has been released. You can view more information on this version and install it <a href="%s">here</a>.',
    'Alert avatar' => '<strong>The avatar directory is currently not writable!</strong> If you want users to be able to upload their own avatar images you must see to it that the directory <em>%s</em> is writable by PHP. Use chmod to set the appropriate directory permissions.',
    'Alert smilies' => '<strong>The smilies directory is currently not writable!</strong> If you want to be able to upload your own smiley images you must see to it that the directory <em>%s</em> is writable by PHP. Use chmod to set the appropriate directory permissions.',
    'Alert cache' => '<strong>The cache directory is currently not writable!</strong> In order for Panther to function properly, the directory <em>%s</em> must be writable by PHP. Use chmod to set the appropriate directory permissions.',
    'Delete install file' => 'Delete it',
    'About head' => 'About Panther',
    'Panther version label' => 'Panther version',
    'Check for upgrade' => 'Check for upgrade',
    'Panther version data' => 'v%s - %s',
    'Server statistics label' => 'Server statistics',
    'View server statistics' => 'View server statistics',
    'Support label' => 'Support',
    'Forum label' => 'Forum',
    'admin notes' => 'You can use this section to keep notes for other users who access the Admin CP. It is globally editable by all staff who have access to the dashboard.',
    'save notes' => 'Save Admin Notes',
    
    // Language definitions used in admin_statistics.php
    'PHPinfo disabled message' => 'The PHP function phpinfo() has been disabled on this server.',
    'Server statistics head' => 'Server statistics',
    'Server load label' => 'Server load',
    'Server load data' => '%s - %s user(s) online',
    'Environment label' => 'Environment',
    'Environment data OS' => 'Operating system: %s',
    'Show info' => 'Show info',
    'Environment data version' => 'PHP: %s - %s',
    'Environment data acc' => 'Accelerator: %s',
    'Turck MMCache' => 'Turck MMCache',
    'Turck MMCache link' => 'turck-mmcache.sourceforge.net/',
    'ionCube PHP Accelerator' => 'ionCube PHP Accelerator',
    'ionCube PHP Accelerator link' => 'www.php-accelerator.co.uk/',
    'Alternative PHP Cache (APC)' => 'Alternative PHP Cache (APC)',
    'Alternative PHP Cache (APC) link' => 'www.php.net/apc/',
    'Zend Optimizer' => 'Zend Optimizer',
    'Zend Optimizer link' => 'www.zend.com/products/guard/zend-optimizer/',
    'eAccelerator' => 'eAccelerator',
    'eAccelerator link' => 'www.eaccelerator.net/',
    'XCache' => 'XCache',
    'XCache link' => 'xcache.lighttpd.net/',
    'Database label' => 'Database',
    'Database data rows' => 'Rows: %s',
    'Database data size' => 'Size: %s'
);