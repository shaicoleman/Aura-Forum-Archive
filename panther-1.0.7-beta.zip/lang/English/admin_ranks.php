<?php

/**
 *
 * This file is part of the Panther Forum Software package.
 *
 * @link      https://www.pantherforum.org/
 * @copyright Copyright (c) Panther <https://www.pantherforum.org/>
 * @license   GNU General Public License (GPL-3.0), Version 3, 29 June 2007 <http://opensource.org/licenses/GPL-3.0>
 *
 * For full information, please see README.md, CHANGELOG.md and LICENSE.md files which are located in the root folder.
 *
 */

// Language definitions used in admin_ranks.php
$lang_admin_ranks = array(
    
    'Must be integer message' => 'Minimum posts must be a positive integer value.',
    'Dupe min posts message' => 'There is already a rank with a minimun posts value of %s.',
    'Must enter title message' => 'You must enter a rank title.',
    'Rank added redirect' => 'Rank added. Redirecting …',
    'Rank updated redirect' => 'Rank updated. Redirecting …',
    'Rank removed redirect' => 'Rank removed. Redirecting …',
    'Ranks head' => 'Ranks',
    'Add rank subhead' => 'Add rank',
    'Add rank info' => 'Enter a rank and the minimum number of posts a user must have made to attain the rank. Different ranks cannot have the same value for minimum posts. If a title is set for a user, the title will be displayed instead of any rank.',
    'Ranks enabled' => '<strong>User ranks are enabled in %s.</strong>',
    'Ranks disabled' => '<strong>User ranks are disabled in %s.</strong>',
    'Rank title label' => 'Rank title',
    'Minimum posts label' => 'Minimum posts',
    'Actions label' => 'Actions',
    'Edit remove subhead' => 'Edit/remove ranks',
    'No ranks in list' => 'No ranks in list'
    
);