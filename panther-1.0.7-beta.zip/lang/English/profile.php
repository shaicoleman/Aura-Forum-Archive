<?php

/**
 *
 * This file is part of the Panther Forum Software package.
 *
 * @link      https://www.pantherforum.org/
 * @copyright Copyright (c) Panther <https://www.pantherforum.org/>
 * @license   GNU General Public License (GPL-3.0), Version 3, 29 June 2007 <http://opensource.org/licenses/GPL-3.0>
 *
 * For full information, please see README.md, CHANGELOG.md and LICENSE.md files which are located in the root folder.
 *
 */

// Language definitions used in profile.php
$lang_profile = array(
    
    // Navigation and sections
    'Profile menu' => 'Profile menu',
    'Section essentials' => 'Essentials',
    'Section personal' => 'Personal',
    'Section messaging' => 'Messaging',
    'Section personality' => 'Personality',
    'Section display' => 'Display',
    'Section privacy' => 'Privacy',
    'Section admin' => 'Administration',
    
    // Miscellaneous
    'Username and pass legend' => 'Enter your username and password',
    'Personal details legend' => 'Enter your personal details',
    'Contact details legend' => 'Enter your messaging details',
    'User activity' => 'User activity',
    'Paginate info' => 'Enter the number of topics and posts you wish to view on each page.',
    
    // Password stuff
    'Pass key bad' => 'The specified password activation key was incorrect or has expired. Please re-request a new password. If that fails, contact the forum administrator at',
    'Pass updated' => 'Your password has been updated. You can now login with your new password.',
    'Pass updated redirect' => 'Password updated. Redirecting …',
    'Wrong pass' => 'Wrong old password.',
    'Change pass' => 'Change password',
    'Change pass legend' => 'Enter and confirm your new password',
    'Old pass' => 'Old password',
    'New pass' => 'New password',
    'Confirm new pass' => 'Confirm new password',
    'Pass info' => 'Passwords must be at least 6 characters long. Passwords are case sensitive.',
    
    // Email stuff
    'Email key bad' => 'The specified email activation key was incorrect or has expired. Please re-request change of email address. If that fails, contact the forum administrator at',
    'Email updated' => 'Your email address has been updated.',
    'Activate email sent' => 'An email has been sent to the specified address with instructions on how to activate the new email address. If it doesn\'t arrive you can contact the forum administrator at',
    'Email legend' => 'Enter your new email address',
    'Email instructions' => 'An email will be sent to your new address with an activation link. You must click the link in the email you receive to activate the new address.',
    'Change email' => 'Change email address',
    'New email' => 'New email',
    
    // Avatar upload stuff
    'Avatars disabled' => 'The administrator has disabled avatar support.',
    'Too large ini' => 'The selected file was too large to upload. The server didn\'t allow the upload.',
    'Partial upload' => 'The selected file was only partially uploaded. Please try again.',
    'No tmp directory' => 'PHP was unable to save the uploaded file to a temporary location.',
    'No file' => 'You did not select a file for upload.',
    'Bad type' => 'The file you tried to upload is not of an allowed type. Allowed types are gif, jpeg and png.',
    'Too wide or high' => 'The file you tried to upload is wider and/or higher than the maximum allowed',
    'Too large' => 'The file you tried to upload is larger than the maximum allowed',
    'pixels' => 'pixels',
    'bytes' => 'bytes',
    'Move failed' => 'The server was unable to save the uploaded file. Please contact the forum administrator at',
    'Unknown failure' => 'An unknown error occurred. Please try again.',
    'Avatar upload redirect' => 'Avatar uploaded. Redirecting …',
    'Avatar deleted redirect' => 'Avatar deleted. Redirecting …',
    'Avatar desc' => 'An avatar is a small image that will be displayed under your username in your posts. It must not be any bigger than',
    'Upload avatar' => 'Upload avatar',
    'Use gravatar' => 'Use Gravatar',
    'Disable gravatar' => 'Disable Gravatar',
    'Gravatar disabled redirect' => 'Gravatar disabled. Redirecting …',
    'Gravatar enabled redirect' => 'Gravatar enabled. Redirecting …',
    'Upload avatar legend' => 'Enter an avatar file to upload',
    'Delete avatar' => 'Delete avatar', // only for admins
    'File' => 'File',
    'Upload' => 'Upload', // submit button
    
    // Form validation stuff
    'Forbidden title' => 'The title you entered contains a forbidden word. You must choose a different title.',
    'Profile redirect' => 'Profile updated. Redirecting …',
    
    // Profile display stuff
    'Users profile' => '%s\'s profile',
    'Username info' => 'Username: %s',
    'Email info' => 'Email: %s',
    'Posts info' => 'Posts: %s',
    'Registered info' => 'Registered: %s',
    'Last post info' => 'Last post: %s',
    'Last visit info' => 'Last visit: %s',
    'Show posts' => 'Show all posts',
    'Show topics' => 'Show all topics',
    'Show subscriptions' => 'Show all subscriptions',
    'Realname' => 'Real name',
    'Location' => 'Location',
    'Website' => 'Website',
    'Invalid website URL' => 'The website URL you entered is invalid.',
    'Website not allowed' => 'You are not allowed to add a website to your profile yet.',
    'Facebook' => 'Facebook',
    'Steam' => 'Steam Username',
    'MSN' => 'Microsoft Account',
    'Twitter' => 'Twitter',
    'Google' => 'Google +',
    'Avatar' => 'Avatar',
    'Signature' => 'Signature',
    'Sig max size' => 'Max length: %s characters / Max lines: %s',
    'Avatar legend' => 'Set your avatar display options',
    'Avatar info' => 'An avatar is a small image that will be displayed with all your posts. You can upload an avatar by clicking the link below (if enabled). Another alternative is to use Gravatar to provide a forum avatar. This can be enabled by clicking <strong>Use Gravatar</strong>. You need to be registered at <a href="https://en.gravatar.com/">Gravatar</a> for this feature. Note that by using Gravatar, your current avatar will be deleted.',
    'Change avatar' => 'Change avatar',
    'Signature legend' => 'Compose your signature',
    'Signature info' => 'A signature is a small piece of text that is attached to your posts. In it, you can enter just about anything you like. Perhaps you would like to enter your favourite quote or your star sign. It\'s up to you! In your signature you can use BBCode if it is allowed in this particular forum. You can see the features that are allowed/enabled listed below whenever you edit your signature.',
    'Sig preview' => 'Current signature preview:',
    'No sig' => 'No signature currently stored in profile.',
    'Signature quote/code/list/h' => 'The quote, code, list, and heading BBCodes are not allowed in signatures.',
    'Topics per page' => 'Topics',
    'Posts per page' => 'Posts',
    'Leave blank' => 'Leave blank to use forum default.',
    'Subscription legend' => 'Set your subscription options',
    'Notify full' => 'Include a plain text version of new posts in subscription notification emails.',
    'Auto notify full' => 'Automatically subscribe to every topic you post in.',
    'Private messaging' => 'Private messaging',
    'PM enabled' => 'Enable private messaging',
    'Use editor' => 'Use WYSIWYG editor',
    'PM notify' => 'Private message notification by email',
    'Show smilies' => 'Show smilies as graphic icons.',
    'Show images' => 'Show images in posts.',
    'Show images sigs' => 'Show images in user signatures.',
    'Show avatars' => 'Show user avatars in posts.',
    'Show sigs' => 'Show user signatures.',
    'Style legend' => 'Select your preferred style',
    'Styles' => 'Styles',
    'Admin note' => 'Admin note',
    'Pagination legend' => 'Enter your pagination options',
    'Post display legend' => 'Set your options for viewing posts',
    'Post display info' => 'If you are on a slow connection, disabling these options, particularly showing images in posts and signatures, will make pages load faster.',
    'Instructions' => 'When you update your profile, you will be redirected back to this page.',
    'Last visit' => 'Last visit',
    
    // Reputation stuff
    'No received reputation' => 'No reputation has been given to this user.',
    'No given reputation' => 'This user has not given any reputation.',
    'Reputation' => 'Reputation',
    'User rep link' => '%s - Profile',
    'Rep_received' => 'Reputation Received',
    'Rep_given' => 'Reputation Given',
    'Rep type' => 'Type',
    'Given by' => 'Given By',
    'Given to' => 'Given To',
    'Date rep given' => 'Date Given',
    'Rep post topic' => 'Post/Topic',
    'Remove reputation' => 'Remove Reputation',
    'Deleted user' => 'Deleted User',
    'Deleted post' => 'Deleted Post',
    'Positive' => 'Positive',
    'Negative' => 'Negative',
    
    // Administration stuff
    'restrictions' => 'Posting Restrictions',
    'Update posting ban redirect' => 'Posting permissions updated. Redirecting …',
    'posting ban delete' => 'Check this box to remove the current posting ban',
    'Posting ban' => 'You can restrict this user from posting for a certain amount below, this can be reverted at any time.',
    'posting ban moderator' => 'The user %s is a moderator and cannot be restricted from posting. In order to restrict this user please first demote him/her.',
    'posting ban admin' => 'The user %s is a administrator and cannot be restricted from posting. In order to restrict this user please first demote him/her.',
    'Days' => 'Days',
    'Months' => 'Months',
    'Hours' => 'Hours',
    'Minutes' => 'Minutes',
    'Never' => 'Never',
    'Group membership legend' => 'Choose user group',
    'Save' => 'Save',
    'Set mods legend' => 'Set moderator access',
    'Moderator in info' => 'Choose which forums this user should be allowed to moderate. Note: This only applies to moderators. Administrators always have full permissions in all forums.',
    'Update forums' => 'Update forums',
    'Delete ban legend' => 'Delete (administrators only) or ban user',
    'Delete user' => 'Delete user',
    'Ban user' => 'Ban user',
    'Confirm delete legend' => 'Important: read before deleting user',
    'Confirm delete user' => 'Confirm delete user',
    'Confirmation info' => 'Please confirm that you want to delete the user', // the username will be appended to this string
    'Delete warning' => 'Warning! Deleted users and/or posts cannot be restored. If you choose not to delete the posts made by this user, the posts can only be deleted manually at a later time.',
    'Delete posts' => 'Delete any posts and topics this user has made.',
    'Delete' => 'Delete', // submit button (confirm user delete)
    'User delete redirect' => 'User deleted. Redirecting …',
    'User promote redirect' => 'User promoted. Redirecting …',
    'Group membership redirect' => 'Group membership saved. Redirecting …',
    'Update forums redirect' => 'Forum moderator rights updated. Redirecting …',
    'Ban redirect' => 'Redirecting …',
    'No delete admin message' => 'Administrators cannot be deleted. In order to delete this user, you must first move him/her to a different user group.',
    'current ban' => ' This user is currently being banned, which is due to expire <strong>%s</strong>. Any changes made will replace the current ban.'
);