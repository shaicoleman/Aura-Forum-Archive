<?php

/**
 *
 * This file is part of the Panther Forum Software package.
 *
 * @link      https://www.pantherforum.org/
 * @copyright Copyright (c) Panther <https://www.pantherforum.org/>
 * @license   GNU General Public License (GPL-3.0), Version 3, 29 June 2007 <http://opensource.org/licenses/GPL-3.0>
 *
 * For full information, please see README.md, CHANGELOG.md and LICENSE.md files which are located in the root folder.
 *
 */

// Language definitions used by the Warnings Mod
$lang_warnings = array(
    
    'Warnings disabled' => 'Warnings have been disabled.',
    'No title' => 'You must enter a title for the warning type.',
    'Title too long' => 'Warning titles must be less than 70 characters long.',
    'Must enter description' => 'You must enter a warning description.',
    'Description too long' => 'Descriptions cannot be longer than  %s bytes.',
    'Type updated redirect' => 'Warning type updated. Redirecting …',
    'Type added redirect' => 'Warning type added. Redirecting …',
    'Add new type label' => 'Add new warning type',
    'Add New' => 'Add New',
    'Add' => 'Add',
    'Type details' => 'Enter warning type details',
    'Warning title' => 'Warning title',
    'Points' => 'Points',
    'Expiration' => 'Expiration',
    'Description' => 'Description (HTML)',
    'Edit warning type' => 'Edit warning type',
    'Warning type details' => 'Warning type details',
    'Save changes' => 'Save changes',
    'Type delete redirect' => 'Warning type deleted. Redirecting …',
    'Confirm delete type' => 'Confirm delete warning type',
    'Del type confirm' => 'Are you sure you want to delete the warning type %s?',
    'Del warning type' => 'WARNING! Deleting a warning type will result in any users issued this warning to not have the ability to view this warning title and description.',
    'Important Information' => 'Important Information',
    'Delete' => 'Delete',
    'Add new level label' => 'Add new warning level',
    'Warning level details' => 'Warning level details',
    'Ban message' => 'Ban message',
    'Ban message help' => 'The message displayed to the banned user when they visit the forums.',
    'Ban points help' => 'Number of warning points a user must have for this ban to be automatically issued.',
    'Ban duration' => 'Ban duration',
    'Permanent' => 'Permanent',
    'Edit warning level' => 'Edit warning level',
    'Level del redirect' => 'Warning level deleted. Redirecting …',
    'Confirm delete level' => 'Confirm delete warning level',
    'Delete level' => 'Are you sure you want to delete this warning level?',
    'Level update redirect' => 'Warning level updated. Redirecting …',
    'Level added redirect' => 'Warning level added. Redirecting …',
    'Warning types' => 'Warning types',
    'Modify warning types' => 'Modify warning types',
    'Points 2' => 'Points:  %s ',
    'Edit' => 'Edit',
    'Expires after x' => '(Expires after: %s %s)',
    'Add' => 'Add',
    'Warning levels' => 'Warning levels',
    'Permanent ban' => 'Ban user permanently',
    'Temporary ban' => 'Ban user for %s %s',
    
    // Issue warning
    'Hours' => 'Hours',
    'Months' => 'Months',
    'Days' => 'Days',
    'Never' => 'Never',
    'No of hours' => '%s hours',
    'No of days' => '%s days',
    'No of months' => '%s months'
    
);