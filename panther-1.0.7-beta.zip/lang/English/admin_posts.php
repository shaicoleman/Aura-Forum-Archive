<?php

/**
 *
 * This file is part of the Panther Forum Software package.
 *
 * @link      https://www.pantherforum.org/
 * @copyright Copyright (c) Panther <https://www.pantherforum.org/>
 * @license   GNU General Public License (GPL-3.0), Version 3, 29 June 2007 <http://opensource.org/licenses/GPL-3.0>
 *
 * For full information, please see README.md, CHANGELOG.md and LICENSE.md files which are located in the root folder.
 *
 */

// Language definitions used in admin_posts.php
$lang_admin_posts = array(
    
    'New posts head' => 'New Unapproved Posts',
    'Deleted user' => 'Deleted user',
    'Deleted' => 'Deleted',
    'Post ID' => 'Post #%s',
    'Post subhead' => 'Posted %s',
    'Posted by' => 'Posted by %s',
    'Message' => 'Message',
    'Approve' => 'Approve post',
    'Delete' => 'Delete post',
    'No new posts' => 'There are no new unapproved posts.',
    'Post approved redirect' => 'Post approved successfully. Redirecting …',
    'Post deleted redirect' => 'Post deleted successfully. Redirecting …',
    'Attachment size' => 'Size: %s',
    'Attachment downloads' => 'Downloads: %s',
    'bytes' => 'bytes',
    'Attachments' => 'Attachments: ',
    'Mark as spam' => 'Mark as Spam'
);