<?php

/**
 *
 * This file is part of the Panther Forum Software package.
 *
 * @link      https://www.pantherforum.org/
 * @copyright Copyright (c) Panther <https://www.pantherforum.org/>
 * @license   GNU General Public License (GPL-3.0), Version 3, 29 June 2007 <http://opensource.org/licenses/GPL-3.0>
 *
 * For full information, please see README.md, CHANGELOG.md and LICENSE.md files which are located in the root folder.
 *
 */

// Language definitions used in index.php
$lang_index = array(
    
    'Topics' => 'Topics',
    'Link to' => 'Link to:', // As in "Link to: http://panther.org/"
    'Empty board' => 'Board is empty.',
    'Newest user' => 'Newest registered user: %s',
    'Users online' => 'Registered users online: %s',
    'Guests online' => 'Guests online: %s',
    'No of users' => 'Total number of registered users: %s',
    'No of topics' => 'Total number of topics: %s',
    'No of posts' => 'Total number of posts: %s',
    'Online' => 'Online:', // As in "Online: User A, User B etc."
    'Board info' => 'Board information',
    'Board stats' => 'Board statistics',
    'User info' => 'User information',
    'Bots Online' => 'Bots online:',
    'Bots online 1' => 'Bots online: %s',
    'Legend' => 'Legend',
    'Sub forums' => 'Sub forums: %s'
);