<?php

/**
 *
 * This file is part of the Panther Forum Software package.
 *
 * @link      https://www.pantherforum.org/
 * @copyright Copyright (c) Panther <https://www.pantherforum.org/>
 * @license   GNU General Public License (GPL-3.0), Version 3, 29 June 2007 <http://opensource.org/licenses/GPL-3.0>
 *
 * For full information, please see README.md, CHANGELOG.md and LICENSE.md files which are located in the root folder.
 *
 */

// Language definitions used in private messaging
$lang_pm = array(
    
    // inbox
    'New message' => 'New message',
    'My folders' => 'Folders',
    'Storage' => 'Storage',
    'Amount' => ' (%s)',
    'Inbox percent' => 'Inbox: %s full',
    'Options' => 'Options',
    'PM Inbox' => 'Inbox',
    'My messages' => 'My Conversations',
    'Blocked users' => 'Blocked Users',
    'No messages in folder' => 'You do not have any messages in this box.',
    'Subject' => 'Messages',
    'Sender' => 'Sender',
    'Receiver' => 'Receiver',
    'Replies' => 'Replies',
    'Last post' => 'Last Post',
    'Move button' => 'Move',
    'Delete button' => 'Delete',
    'Select more than one topic' => 'You must select at least one topic.',
    'PM sent redirect' => 'Private message sent. Redirecting …',
    'Delete messages comply' => 'Are you sure you want to delete the selected messages?',
    'Move messages comply' => 'Please select which box to move the messages in:',
    'Messages deleted' => 'Messages deleted. Redirecting …',
    'Messages moved' => 'Messages moved to new folder. Redirecting …',
    'PM Folders' => 'My Folders',
    'No available folders' => 'No folders are available to move messages into',
    
    // pms_send
    'Submit message legend' => 'Write your message and submit',
    'Send to' => 'Send To',
    'Hide smilies' => 'Never show smilies as icons for this post',
    'Preview' => 'Preview',
    'No self messages' => 'You cannot send messages to yourself.',
    'No user x' => 'The user %s does not exist',
    'Inbox full' => 'Your inbox is full.',
    'Receiver inbox full' => 'The user %s has a full inbox.',
    'No PM access' => 'The user %s does not have access to private messaging',
    'Quota label' => 'Quota: %s / %s',
    'No receivers' => 'All receivers have left this conversation other than yourself',
    'User x has left' => '%s has left the conversation',
    
    // pms view
    'Add reply' => 'Post reply',
    'Delete' => 'Delete',
    'Block' => 'Block',
    
    // Folder Management
    'Folder added' => 'Folder added. Redirecting …',
    'My folders 2' => 'My Folders',
    'No messages' => 'You do not have any private messages.',
    'Send message' => 'Send Message',
    'Edit message' => 'Edit Message',
    'Delete message' => 'Delete Message',
    'No folder name' => 'You must enter a folder name.',
    'Folder errors info' => 'The following errors need to be corrected before the folder can be created:',
    'Folder errors' => 'Folder errors',
    'Folder too long' => 'Folder names cannot be longer than 30 characters.',
    'Folder too short' => 'Folder names must be longer than 3 characters.',
    'No folder after censoring' => 'After censoring, no folder name was left',
    'Folder name' => 'Folder name',
    'Actions' => 'Actions',
    'Update' => 'Update',
    'Remove' => 'Remove',
    'Add' => 'Add',
    'Folder del redirect' => 'Folder deleted. Redirecting …',
    'Folder edit redirect' => 'Folder edited. Redirecting …',
    'Folder limit' => 'You can only have %s additional folders at any one time',
    'Add folder' => 'Add folder',
    'Folder name' => 'Folder name',
    'Folder' => 'Folder',
    'User is mod' => 'The user %s is a moderator and cannot be blocked.',
    'User is admin' => 'The user %s is a administrator and cannot be blocked.',
    'No block self' => 'You cannot block yourself',
    'Already blocked' => 'You have already blocked this user',
    'Block added redirect' => 'User blocked. Redirecting …',
    'Block del redirect' => 'User unblocked. Redirecting …',
    'User x has blocked' => 'You have been blocked by %s (or you have blocked them)',
    'Block errors info' => 'The following errors need to be corrected before the user can be blocked:',
    'Block errors' => 'Block errors',
    'My blocked' => 'Blocked users',
    'Add block' => 'Add block',
    'Max receivers' => 'Personal conversations cannot have more than %s receivers',
    
    'Archived messages' => 'Archived',
    
    'Options' => 'Options',
    'disable messenger' => 'Disable PM',
    'blocked user' => 'Blocked users'
);