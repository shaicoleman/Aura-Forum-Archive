<?php

/**
 *
 * This file is part of the Panther Forum Software package.
 *
 * @link      https://www.pantherforum.org/
 * @copyright Copyright (c) Panther <https://www.pantherforum.org/>
 * @license   GNU General Public License (GPL-3.0), Version 3, 29 June 2007 <http://opensource.org/licenses/GPL-3.0>
 *
 * For full information, please see README.md, CHANGELOG.md and LICENSE.md files which are located in the root folder.
 *
 */

$lang_admin_moderate = array(
    
    'title too long' => 'The entered title was longer than the allowed of 50 characters.',
    'added redirect' => 'Multi-moderation action added. Redirecting …',
    'edit redirect' => 'Multi-moderation action edited. Redirecting …',
    'delete redirect' => 'Multi-moderation action deleted. Redirecting …',
    'actions' => 'Multi-moderation',
    'title' => 'Moderation Action Title:',
    'add new' => 'Add New Action',
    'add new label' => 'This will allow you to create a new multi-moderation action.',
    'edit action header' => 'Edit Action',
    'action header' => 'Create New Action',
    'delete action 2' => 'Delete',
    'edit action' => 'Edit',
    'title help' => 'The title of the Moderation action (will be displayed to choose from)',
    'forum' => 'Move to new forum?',
    'forum help' => 'You can move the topic to this forum. You can leave it where it is by selecting the top option.',
    'message' => 'Reply message',
    'message help' => 'Here you can specify a message that will be added onto the end of the topic.',
    'do not move' => '-- Don\'t move topic --',
    'do not alter' => '-- Leave it as it is --',
    'close' => 'Close or open topic?',
    'close help' => 'You can specify whether this topic should be closed, opened or just left the way it was prior here.',
    'stick help' => 'You can specify whether this topic should be stuck, unstuck or just left the way it was prior here.',
    'close topic' => 'Close the topic',
    'open topic' => 'Open the topic',
    'stick' => 'Stick or Unstick topic?',
    'stick topic' => 'Stick the topic',
    'unstick topic' => 'Unstick the topic',
    'leave redirect' => 'Leave a redirect topic?',
    'no redirect' => 'Don\'t leave a redirect topic',
    'do redirect' => 'Leave a redirect topic',
    'redirect help' => 'If you\'re moving the topic to a new forum, you can leave a redirect topic using this option.',
    'add reply post' => 'Add reply message',
    'no reply post' => 'Don\'t add a reply',
    'add reply' => 'Add a reply post?',
    'add reply help' => 'You must select this if you intend to add a reply message below.',
    'must enter title' => 'You must enter the action title',
    'edit link' => 'Edit',
    'no action' => 'No multi-moderation actions have been found for this forum',
    'delete action' => '<span style="color:red">WARNING!</span> You are about to permanently delete this action. Are you sure?',
    'title' => 'Action Title:',
    'add start' => 'Add to <strong>start</strong> of topic subject:',
    'add start help' => 'This will add the phrase specified to the <strong>start</strong> of the topic subject. Note that no spaces will be included unless specified here.',
    'add end' => 'Add to <strong>end</strong> of topic subject:',
    'add end help' => 'This will add the phrase specified to the <strong>end</strong> of the topic subject. Note that no spaces will be included unless specified here.',
    'email' => 'Send email to topic starter',
    'email help' => 'This option will send an email to the topic starter with the latest reply, regardless of whether they are subscribed to the topic or not. For this to happen, you must first add a message below and select the add reply option.',
    'addition too long' => 'Additions to a topic title must be no longer than 50 characters each. Please amend your phrases to add to the start/end of a topic subject and try again.',
    'increment post count' => 'Increment post count',
    'increment help' => 'This option will increment the poster\'s post count as if this was a normal message.'
);