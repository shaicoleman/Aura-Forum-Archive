<?php

/**
 *
 * This file is part of the Panther Forum Software package.
 *
 * @link      https://www.pantherforum.org/
 * @copyright Copyright (c) Panther <https://www.pantherforum.org/>
 * @license   GNU General Public License (GPL-3.0), Version 3, 29 June 2007 <http://opensource.org/licenses/GPL-3.0>
 *
 * For full information, please see README.md, CHANGELOG.md and LICENSE.md files which are located in the root folder.
 *
 */

// Language definitions used in userlist.php
$lang_ul = array(
    
    'User find legend' => 'Find and sort users',
    'User search info' => 'Enter a username to search for and/or a user group to filter by. The username field can be left blank. Use the wildcard character * for partial matches.',
    'User sort info' => 'Sort users by name, date registered or number of posts and in ascending/descending order.',
    'User group' => 'User group',
    'No of posts' => 'Number of posts',
    'All users' => 'All'
    
);