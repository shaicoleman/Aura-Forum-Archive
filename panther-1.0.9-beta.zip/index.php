<?php
/**
 * Copyright (C) 2015 Panther (https://www.pantherforum.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/');
	require PANTHER_ROOT.'include/common.php';
}

if ($panther_user['g_read_board'] == '0')
	message($lang_common['No view'], false, '403 Forbidden');

// Load the index.php language file
require PANTHER_ROOT.'lang/'.$panther_user['language'].'/index.php';

// Get list of forums and topics with new posts since last visit
if (!$panther_user['is_guest'])
{
	$data = array(
		':id'	=> $panther_user['g_id'],
		':last_visit'	=> $panther_user['last_visit'],
	);
	$ps = $db->run('SELECT f.id, f.last_post FROM '.$db->prefix.'forums AS f LEFT JOIN '.$db->prefix.'forum_perms AS fp ON (fp.forum_id=f.id AND fp.group_id=:id) WHERE (fp.read_forum IS NULL OR fp.read_forum=1) AND f.last_post>:last_visit', $data);
	if ($ps->rowCount())
	{
		$forums = $new_topics = array();
		$tracked_topics = get_tracked_topics();
		foreach ($ps as $cur_forum)
		{
			if (!isset($tracked_topics['forums'][$cur_forum['id']]) || $tracked_topics['forums'][$cur_forum['id']] < $cur_forum['last_post'])
				$forums[$cur_forum['id']] = $cur_forum['last_post'];
		}

		if (!empty($forums))
		{
			if (empty($tracked_topics['topics']))
				$new_topics = $forums;
			else
			{
				for ($i = 0; $i < count($forums); $i++)
					$placeholders[] = '?';
				
				$data = array_keys($forums);
				$data[] = $panther_user['last_visit'];
				
				$ps = $db->run('SELECT forum_id, id, last_post FROM '.$db->prefix.'topics WHERE forum_id IN('.implode(',', $placeholders).') AND last_post>? AND moved_to IS NULL', $data);
				foreach ($ps as $cur_topic)
				{
					if (!isset($new_topics[$cur_topic['forum_id']]) && (!isset($tracked_topics['forums'][$cur_topic['forum_id']]) || $tracked_topics['forums'][$cur_topic['forum_id']] < $forums[$cur_topic['forum_id']]) && (!isset($tracked_topics['topics'][$cur_topic['id']]) || $tracked_topics['topics'][$cur_topic['id']] < $cur_topic['last_post']))
						$new_topics[$cur_topic['forum_id']] = $forums[$cur_topic['forum_id']];
				}
			}
		}
	}
}

$page_head['canonical'] = "\t".'<link href="'.panther_link($panther_url['index']).'" rel="canonical" />';

if ($panther_config['o_feed_type'] == '1') 
    $page_head['feed'] = "\t".'<link href="'.panther_link($panther_url['index_rss']).'" type="application/rss+xml" rel="alternate" title="'.$lang_common['RSS active topics feed'].'" />'; 
else if ($panther_config['o_feed_type'] == '2') 
    $page_head['feed'] = "\t".'<link href="'.panther_link($panther_url['index_atom']).'" type="application/atom+xml" rel="alternate" title="'.$lang_common['Atom active topics feed'].'" />';

$sub_forums = array();
$data = array(
	':id'	=>	$panther_user['g_id'],
);

$ps = $db->run('SELECT u.id AS uid, u.email, u.use_gravatar, u.group_id, f.num_topics, f.num_posts, f.last_topic, f.last_topic_id,  f.parent_forum, f.last_post_id, f.show_post_info, f.last_poster, f.last_post, f.id, f.forum_name, f.last_topic FROM '.$db->prefix.'forums AS f LEFT JOIN '.$db->prefix.'forum_perms AS fp ON (fp.forum_id=f.id AND fp.group_id=:id) LEFT JOIN '.$db->prefix.'users AS u ON (f.last_poster=u.username) WHERE (fp.read_forum IS NULL OR fp.read_forum=1) AND f.parent_forum <> 0 ORDER BY f.disp_position', $data);
foreach ($ps as $current)
{
	if (!isset($sub_forums[$current['parent_forum']]))
		$sub_forums[$current['parent_forum']] = array();

	$sub_forums[$current['parent_forum']][] = $current;
}

$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']));
define('PANTHER_ALLOW_INDEX', 1);
define('PANTHER_ACTIVE_PAGE', 'index');
require PANTHER_ROOT.'header.php';

// Print the categories and forums
$ps = $db->run('SELECT c.id AS cid, c.cat_name, f.id AS fid, f.forum_name, f.forum_desc, f.last_topic, f.last_topic_id, f.show_post_info, f.redirect_url, f.moderators, f.num_topics, f.num_posts, f.last_post, f.last_post_id, f.last_poster, f.parent_forum, f.last_topic, u.group_id, u.id AS uid, u.email, u.use_gravatar FROM '.$db->prefix.'categories AS c INNER JOIN '.$db->prefix.'forums AS f ON c.id=f.cat_id LEFT JOIN '.$db->prefix.'forum_perms AS fp ON (fp.forum_id=f.id AND fp.group_id=:id) LEFT JOIN '.$db->prefix.'users AS u ON (f.last_poster=u.username) WHERE (fp.read_forum IS NULL OR fp.read_forum=1) AND (f.parent_forum IS NULL OR f.parent_forum=0) ORDER BY c.disp_position, c.id, f.disp_position', $data);

$cur_category = 0;
$cat_count = 0;
$forum_count = 0;
$category_tpl = array();

// Set some used templates once, to avoid overwriting them in every iteration
$index_tpl = panther_template('index.tpl');
$category_idx_tpl = panther_template('category.tpl');
$subforum_name_tpl = panther_template('subforum_name.tpl');
$subforum_content_tpl = panther_template('subforum_content_index.tpl');
$mod_tpl = panther_template('moderator_list.tpl');
$forum_desc_tpl = panther_template('forum_desc.tpl');
$last_post_tpl = panther_template('last_post.tpl');
$new_post_tpl = panther_template('new_posts.tpl');
$forum_name_tpl = panther_template('forum_name.tpl');
foreach ($ps as $cur_forum)
{
	$moderators = '';
	if ($cur_forum['cid'] != $cur_category) // A new category since last iteration?
	{
		if ($cur_category)
			echo str_replace('{category_forums}', implode("\n", $category_tpl[$cur_category]['forums']), $category_tpl[$cur_category]['template']);

		++$cat_count;
		$forum_count = 0;
		
		$search = array(
			'{cat_count}' => $cat_count,
			'{category_name}' => panther_htmlspecialchars($cur_forum['cat_name']),
			'{forum}' => $lang_common['Forum'],
			'{topics}' => $lang_index['Topics'],
			'{posts}' => $lang_common['Posts'],
			'{last_post}' => $lang_common['Last post'],
		);

		// Replace everything bar '{category_forums}' from this categories' template
		$category_tpl[$cur_forum['cid']]['template'] = str_replace(array_keys($search), array_values($search), $category_idx_tpl);
		$cur_category = $cur_forum['cid'];
	}

	++$forum_count;
	$item_status = ($forum_count % 2 == 0) ? 'roweven' : 'rowodd';
	$forum_field_new = '';
	$icon_type = 'icon';

	// Are there new posts since our last visit?
	if (isset($new_topics[$cur_forum['fid']]))
	{
		$item_status .= ' inew';
		$search = array(
			'{post_link}' => panther_link($panther_url['search_new_results'], array($cur_forum['fid'])),
			'{new_posts}' => $lang_common['New posts'],
		);

		$forum_field_new = str_replace(array_keys($search), array_values($search), $new_post_tpl);
		$icon_type = 'icon icon-new';
	}

	// Is this a redirect forum?
	if ($cur_forum['redirect_url'] != '')
	{
		if (!isset($redir_tpl))
			$redir_tpl = panther_template('redirect_forum.tpl');
		
		$search = array(
			'{link_to}' => $lang_index['Link to'],
			'{redirect_url}' => panther_htmlspecialchars($cur_forum['redirect_url']),
			'{forum_name}' => panther_htmlspecialchars($cur_forum['forum_name']),
		);

		$forum_field = str_replace(array_keys($search), array_values($search), $redir_tpl);
		$num_topics = $num_posts = '-';
		$item_status .= ' iredirect';
		$icon_type = 'icon';
	}
	else
	{
		$search = array(
			'{forum_link}' => panther_link($panther_url['forum'], array($cur_forum['fid'], url_friendly($cur_forum['forum_name']))),
			'{forum_name}' => panther_htmlspecialchars($cur_forum['forum_name']),
			'{new_posts}' => (!empty($forum_field_new) ? ' '.$forum_field_new : ''),
		);

		$forum_field = str_replace(array_keys($search), array_values($search), $forum_name_tpl);
		$num_topics = $cur_forum['num_topics'];
		$num_posts = $cur_forum['num_posts'];
	}

	$subforum_list = array();
	if (isset($sub_forums[$cur_forum['fid']]))
	{
		// There can be more than one sub forum per forum
		foreach ($sub_forums[$cur_forum['fid']] as $cur_subforum)
		{
			$num_topics += $cur_subforum['num_topics'];
			$num_posts += $cur_subforum['num_posts'];
			if ($cur_forum['show_post_info'] == '0')
				$last_post = $lang_common['Protected forum'];
			elseif ($cur_forum['last_post'] < $cur_subforum['last_post'])
			{
				$cur_forum['last_post_id'] = $cur_subforum['last_post_id'];
				$cur_forum['last_poster'] = $cur_subforum['last_poster'];
				$cur_forum['last_post'] = $cur_subforum['last_post'];
				$cur_forum['email'] = $cur_subforum['email'];
				$cur_forum['uid'] = $cur_subforum['uid'];
				$cur_forum['use_gravatar'] = $cur_subforum['use_gravatar'];
				$cur_forum['group_id'] = $cur_subforum['group_id'];
				$cur_forum['last_topic'] = $cur_subforum['last_topic'];
				$cur_forum['last_topic_id'] = $cur_subforum['last_topic_id'];
			}
			
			if (isset($new_topics[$cur_subforum['id']]))
			{
				if (stristr($item_status, 'inew') === false)
				{
					$item_status .= ' inew';
					$search = array(
						'{post_link}' => panther_link($panther_url['search_new_results'], array($cur_forum['fid'])),
						'{new_posts}' => $lang_common['New posts'],
					);

					$forum_field_new = str_replace(array_keys($search), array_values($search), $new_post_tpl);
					$icon_type = 'icon icon-new';
				}
			}
			
			$search = array(
				'{forum_link}' => panther_link($panther_url['forum'], array($cur_subforum['id'], url_friendly($cur_subforum['forum_name']))),
				'{forum_name}' => panther_htmlspecialchars($cur_subforum['forum_name']),
			);

			$subforum_list[] = str_replace(array_keys($search), array_values($search), $subforum_name_tpl);
		}
	}

	if ($cur_forum['forum_desc'] != '')
		$forum_field .= "\n".str_replace('{description}', $cur_forum['forum_desc'], $forum_desc_tpl);

	// If there is a last_post/last_poster
	if ($cur_forum['show_post_info'] == '0')
			$last_post = $lang_common['Protected forum'];
	elseif ($cur_forum['last_post'] != '')
	{
		$username = (isset($cur_forum['group_id'])) ? colourize_group($cur_forum['last_poster'], $cur_forum['group_id'], $cur_forum['uid']) : colourize_group($cur_forum['last_poster'], PANTHER_GUEST);
		$search = array(
			'{user_avatar}' => generate_avatar_markup($cur_forum['uid'], $cur_forum['email'], $cur_forum['use_gravatar'], array(32, 32)),
			'{last_post_id}' => panther_link($panther_url['post'], array($cur_forum['last_post_id'])),
			'{last_post}' => format_time($cur_forum['last_post']),
			'{in}' => $lang_common['In'],
			'{topic_link}' => panther_link($panther_url['topic'], array($cur_forum['last_topic_id'], url_friendly($cur_forum['last_topic']))),
			'{last_topic}' => panther_htmlspecialchars(((panther_strlen($cur_forum['last_topic']) > 30) ? utf8_substr($cur_forum['last_topic'], 0, 30).' …' : $cur_forum['last_topic'])),
			'{by}' => $lang_common['by'],
			'{username}' => $username,
		);

		$last_post = str_replace(array_keys($search), array_values($search), $last_post_tpl);
	}
	else if ($cur_forum['redirect_url'] != '')
		$last_post = '- - -';
	else
		$last_post = $lang_common['Never'];

	if ($cur_forum['moderators'] != '')
	{
		$mods_array = unserialize($cur_forum['moderators']);
		$moderator_groups = array();
		if (isset($mods_array['groups']))
		{
			$moderator_groups = $mods_array['groups'];
			unset($mods_array['groups']);
		}

		if (count($mods_array) > 0)
		{
			$moderators = array();
			foreach ($mods_array as $mod_username => $mod_id)
				$moderators[] = colourize_group($mod_username, $moderator_groups[$mod_id], $mod_id);
				
			$search = array(
				'{moderated_by}' => $lang_common['Moderated by'],
				'{moderators}' => implode(', ', $moderators),
			);

			$moderators = str_replace(array_keys($search), array_values($search), $mod_tpl);
		}
	}
	
	$search = array(
		'{item_status}' => $item_status,
		'{icon_type}' => $icon_type,
		'{forum_count}' => forum_number_format($forum_count),
		'{forum_field}' => $forum_field."\n".$moderators.((count($subforum_list)) ? str_replace('{content}', sprintf($lang_index['Sub forums'], implode(', ', $subforum_list)), $subforum_content_tpl) : ''),
		'{num_topics}' => forum_number_format($num_topics),
		'{num_posts}' => forum_number_format($num_posts),
		'{last_post}' => $last_post,
	);

	// Add this forum to its categories' template
	$category_tpl[$cur_forum['cid']]['forums'][$cur_forum['fid']] = str_replace(array_keys($search), array_values($search), $index_tpl);
}

// Did we output any categories and forums?
if ($cur_category)
	echo str_replace('{category_forums}', implode("\n", $category_tpl[$cur_category]['forums']), $category_tpl[$cur_category]['template']);
else
{
	$forum_tpl = panther_template('no_forums.tpl');
	$search = array(
		'{empty_board}' => $lang_index['Empty board'],
	);
	
	echo str_replace(array_keys($search), array_values($search), $forum_tpl);
}

// Collect some statistics from the database
if (file_exists(FORUM_CACHE_DIR.'cache_users_info.php'))
	include FORUM_CACHE_DIR.'cache_users_info.php';

if (!defined('PANTHER_USERS_INFO_LOADED'))
{
	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PANTHER_ROOT.'include/cache.php';

	generate_users_info_cache();
	require FORUM_CACHE_DIR.'cache_users_info.php';
}

$ps = $db->run('SELECT SUM(num_topics), SUM(num_posts) FROM '.$db->prefix.'forums');
list($stats['total_topics'], $stats['total_posts']) = array_map('intval', $ps->fetch(PDO::FETCH_NUM));

$stats['newest_user'] = colourize_group($stats['last_user']['username'], $stats['last_user']['group_id'], $stats['last_user']['id']);

// Display a "mark all as read" link
if (!$panther_user['is_guest'])
{
	$search = array(
		'{link}' => panther_link($panther_url['mark_read']),
		'{mark_read}' => $lang_common['Mark all as read'],
	);
	
	echo str_replace(array_keys($search), array_values($search), panther_template('index_actions.tpl'));
}

$forum_stats = array();
$clearer_tpl = panther_template('clearer.tpl');
$stats_tpl = panther_template('stats_row.tpl');
if ($panther_config['o_users_online'] == '1')
{
	// Fetch users online info and generate strings for output
	$num_guests = count($online['guests']);
	$num_users = count($online['users']);
	$num_bots = 0;
	$users = $bots = $bots_online = array();
	
	foreach ($online['users'] as $online_id => $details)
		$users[] = "\n\t\t\t\t".colourize_group($details['username'], $details['group_id'], $details['id'], $online_id);

	foreach ($online['guests'] as $details)
	{
		if (strpos($details['ident'], '[Bot]') !== false)
		{
			++$num_bots;
			$name = explode('[Bot]', $details['ident']);
			if (empty($bots[$name[1]]))
				$bots[$name[1]] = 1;
			else
				++$bots[$name[1]];
		}
	}
	foreach ($bots as $online_name => $online_id)
		   $bots_online[] = "\n\t\t\t\t".panther_htmlspecialchars($online_name.' [Bot]'.($online_id > 1 ? ' ('.$online_id.')' : ''));

	$num_guests = $num_guests - $num_bots;
	$online_stats_tpl = panther_template('online_stats.tpl');
	
	$search = array(
		'{users_online}' => sprintf($lang_index['Users online'], '<strong>'.forum_number_format($num_users).'</strong>'),
		'{guests_online}' => sprintf($lang_index['Guests online'], '<strong>'.forum_number_format($num_guests).'</strong>'),
		'{bots_online}' => sprintf($lang_index['Bots online 1'], '<strong>'.forum_number_format($num_bots).'</strong>'),
	);

	$forum_stats[] = str_replace(array_keys($search), array_values($search), $online_stats_tpl);
	if ($num_users > 0)
	{
		$search = array(
			'{heading}' => $lang_index['Online'],
			'{value}' => implode(', ', $users),
		);

		$forum_stats[] = str_replace(array_keys($search), array_values($search), $stats_tpl);
	}

	if ($num_bots > 0)
	{
		$search = array(
			'{heading}' => $lang_index['Bots Online'],
			'{value}' => implode(', ', $bots_online),
		);

		$forum_stats[] = str_replace(array_keys($search), array_values($search), $stats_tpl);
	}

    if ($num_bots + $num_users == 0)
		$forum_stats[] = "\t\t\t".$clearer_tpl."\n";
}
else
	$forum_stats[] = panther_template('closing_online_tag.tpl');

	$groups = array();
	$group_tpl = panther_template('index_group.tpl');
	foreach ($panther_groups as $g_id => $details)
	{
		if (!in_array($g_id, array(PANTHER_GUEST, PANTHER_MEMBER)) && $details['g_colour'] !== '')
		{
			$cur_group = colourize_group($details['g_title'], $g_id);
			if ($panther_user['g_view_users'] == 1)
				$cur_group = '<a href="'.panther_link($panther_url['userlist_group'], array($g_id)).'">'.$cur_group.'</a>';

			$groups[] = str_replace('{group}', $cur_group, $group_tpl);
		}
	}

	if (count($groups) > 0)
	{
		$search = array(
			'{heading}' => $lang_index['Legend'],
			'{value}' => implode(', ', $groups),
		);

		$forum_stats[] = str_replace(array_keys($search), array_values($search), $stats_tpl);
	}

$index_tpl = panther_template('index_stats.tpl');
$search = array(
	'{board_info}' => $lang_index['Board info'],
	'{board_stats}' => $lang_index['Board stats'],
	'{num_users}' => sprintf($lang_index['No of users'], '<strong>'.forum_number_format($stats['total_users']).'</strong>'),
	'{num_topics}' => sprintf($lang_index['No of topics'], '<strong>'.forum_number_format($stats['total_topics']).'</strong>'),
	'{num_posts}' => sprintf($lang_index['No of posts'], '<strong>'.forum_number_format($stats['total_posts']).'</strong>'),
	'{user_info}' => $lang_index['User info'],
	'{newest_user}' => sprintf($lang_index['Newest user'], $stats['newest_user']),
	'{content}' => (count($forum_stats) ? implode("\n", $forum_stats) : ''),
);

echo str_replace(array_keys($search), array_values($search), $index_tpl);

flux_hook('index_after_display');
$footer_style = 'index';
require PANTHER_ROOT.'footer.php';