<?php
/**
 * Copyright (C) 2015 Panther (https://www.pantherforum.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/');
	require PANTHER_ROOT.'include/common.php';
}

if ($panther_user['is_bot'])
	message($lang_common['No permission']);

// Include UTF-8 function
require PANTHER_ROOT.'include/utf8/substr_replace.php';
require PANTHER_ROOT.'include/utf8/ucwords.php'; // utf8_ucwords needs utf8_substr_replace
require PANTHER_ROOT.'include/utf8/strcasecmp.php';

$action = isset($_GET['action']) ? $_GET['action'] : null;
$section = isset($_GET['section']) ? $_GET['section'] : null;
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($id < 2)
	message($lang_common['Bad request'], false, '404 Not Found');

if ($action != 'change_pass' || !isset($_GET['key']))
{
	if ($panther_user['g_read_board'] == '0')
		message($lang_common['No view'], false, '403 Forbidden');
	else if ($panther_user['g_view_users'] == '0' && ($panther_user['is_guest'] || $panther_user['id'] != $id))
		message($lang_common['No permission'], false, '403 Forbidden');
}

// Load the prof_reg.php language file
require PANTHER_ROOT.'lang/'.$panther_user['language'].'/prof_reg.php';

// Load the profile.php language file
require PANTHER_ROOT.'lang/'.$panther_user['language'].'/profile.php';

if ($action == 'change_pass')
{
	if (isset($_GET['key']))
	{
		// If the user is already logged in we shouldn't be here :)
		if (!$panther_user['is_guest'])
		{
			header('Location: '.panther_link($panther_url['index']));
			exit;
		}

		$key = $_GET['key'];

		$data = array(
			':id'	=>	$id,
		);

		$ps = $db->select('users', 'activate_string, activate_key, salt', $data, 'id=:id');
		$cur_user = $ps->fetch();

		if ($key == '' || $key != $cur_user['activate_key'])
			message($lang_profile['Pass key bad'].' <a href="mailto:'.panther_htmlspecialchars($panther_config['o_admin_email']).'">'.panther_htmlspecialchars($panther_config['o_admin_email']).'</a>.');
		else
		{
			$data = array(
				':password'	=>	$cur_user['activate_string'],
				':id'	=>	$id,
			);

			$db->run('UPDATE '.$db->prefix.'users SET password=:password, activate_string=NULL, activate_key=NULL WHERE id=:id', $data);
			message($lang_profile['Pass updated'], true);
		}
	}

	// Make sure we are allowed to change this user's password
	if ($panther_user['id'] != $id)
	{
		if (!$panther_user['is_admmod']) // A regular user trying to change another user's password?
			message($lang_common['No permission'], false, '403 Forbidden');
		else if ($panther_user['g_moderator'] == '1') // A moderator trying to change a user's password?
		{
			$ps = $db->select('SELECT u.group_id, g.g_moderator, g.g_admin FROM '.$db->prefix.'users AS u INNER JOIN '.$db->prefix.'groups AS g ON (g.g_id=u.group_id) WHERE u.id=:id', array(':id'=>$id));
			if (!$ps->rowCount())
				message($lang_common['Bad request'], false, '404 Not Found');

			list($group_id, $is_moderator) = $ps->fetch(PDO::FETCH_NUM);

			if ($panther_user['g_mod_edit_users'] == '0' || $panther_user['g_mod_change_passwords'] == '0' || $group_id == PANTHER_ADMIN || $is_admin == '1' || $is_moderator == '1')
				message($lang_common['No permission'], false, '403 Forbidden');
		}
	}

	if (isset($_POST['form_sent']))
	{
		// Make sure they got here from the site
		confirm_referrer('profile.php');

		$old_password = isset($_POST['req_old_password']) ? panther_trim($_POST['req_old_password']) : '';
		$new_password1 = panther_trim($_POST['req_new_password1']);
		$new_password2 = panther_trim($_POST['req_new_password2']);

		if ($new_password1 != $new_password2)
			message($lang_prof_reg['Pass not match']);
		if (panther_strlen($new_password1) < 6)
			message($lang_prof_reg['Pass too short']);
		
		$data = array(
			':id'	=>	$id,
		);

		$ps = $db->select('users', 'password, salt', $data, 'id=:id');
		$cur_user = $ps->fetch();

		$authorized = false;
		if (!empty($cur_user['password']))
		{
			$old_password_hash = panther_hash($old_password.$cur_user['salt']);
			if ($cur_user['password'] == $old_password_hash || $panther_user['is_admmod'])
				$authorized = true;
		}

		if (!$authorized)
			message($lang_profile['Wrong pass']);

		$new_salt = random_pass(16);
		$new_password_hash = panther_hash($new_password1.$new_salt);

		$update = array(
			'password'	=>	$new_password_hash,
			'salt'		=>	$new_salt,
		);
		
		$data = array(
			':id'	=>	$id,
		);
		
		$db->update('users', $update, 'id=:id', $data);

		if ($panther_user['id'] == $id)
			panther_setcookie($panther_user['id'], $new_password_hash, time() + $panther_config['o_timeout_visit']);

		redirect(panther_link($panther_url['profile_essentials'], array($id)), $lang_profile['Pass updated redirect']);
	}

	$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_common['Profile'], $lang_profile['Change pass']);
	$required_fields = array('req_old_password' => $lang_profile['Old pass'], 'req_new_password1' => $lang_profile['New pass'], 'req_new_password2' => $lang_profile['Confirm new pass']);
	$focus_element = array('change_pass', ((!$panther_user['is_admmod']) ? 'req_old_password' : 'req_new_password1'));
	define('PANTHER_ACTIVE_PAGE', 'profile');
	require PANTHER_ROOT.'header.php';
	
	$change_pass_tpl = panther_template('change_pass.tpl');
	
	$search = array(
		'{change_pass}' => $lang_profile['Change pass'],
		'{form_action}' => panther_link($panther_url['change_password'], array($id)),
		'{csrf_token}' => generate_csrf_token(),
		'{change_pass_legend}' => $lang_profile['Change pass legend'],
		'{old_password_field}' => (!$panther_user['is_admmod']) ? '<label class="required"><strong>'.$lang_profile['Old pass'].'<span>'.$lang_common['Required'].'</span></strong><br />'."\n\t\t\t\t\t\t".'<input type="password" name="req_old_password" size="16" /><br /></label>' : '',
		'{new_pass}' => $lang_profile['New pass'],
		'{required}' => $lang_common['Required'],
		'{confirm_pass}' => $lang_profile['Confirm new pass'],
		'{pass_info}' => $lang_profile['Pass info'],
		'{submit}' => $lang_common['Submit'],
		'{go_back}' => $lang_common['Go back'],
	);
	
	echo str_replace(array_keys($search), array_values($search), $change_pass_tpl);
	require PANTHER_ROOT.'footer.php';
}
else if ($action == 'change_email')
{
	// Make sure we are allowed to change this user's email
	if ($panther_user['id'] != $id)
	{
		if (!$panther_user['is_admmod']) // A regular user trying to change another user's email?
			message($lang_common['No permission'], false, '403 Forbidden');
		else if ($panther_user['g_moderator'] == '1') // A moderator trying to change a user's email?
		{
		    $data = array(
		        ':id' => $id,
            );

			$ps = $db->run('SELECT u.group_id, g.g_moderator, g.g_admin FROM '.$db->prefix.'users AS u INNER JOIN '.$db->prefix.'groups AS g ON (g.g_id=u.group_id) WHERE u.id=:id', $data);
			if (!$ps->rowCount())
				message($lang_common['Bad request'], false, '404 Not Found');

			list($group_id, $is_moderator, $is_admin) = $ps->fetch(PDO::FETCH_NUM);

			if ($panther_user['g_mod_edit_users'] == '0' || $group_id == PANTHER_ADMIN || $is_admin == '1' || $is_moderator == '1')
				message($lang_common['No permission'], false, '403 Forbidden');
		}
	}

	if (isset($_GET['key']))
	{
		$key = $_GET['key'];
		$update = array(
			':id'	=>	$id,
		);
		
		$ps = $db->select('users', 'activate_string, activate_key', $update, 'id=:id');
		list($new_email, $new_email_key) = $ps->fetch(PDO::FETCH_NUM);

		if ($key == '' || $key != $new_email_key)
			message(sprintf($lang_profile['Email key bad'], panther_htmlspecialchars($panther_config['o_admin_email'])));
		else
		{
			$data = array(
				':id'	=>	$id,
			);

			$db->run('UPDATE '.$db->prefix.'users SET email=activate_string, activate_string=NULL, activate_key=NULL WHERE id=:id', $data);
			message($lang_profile['Email updated'], true);
		}
	}
	else if (isset($_POST['form_sent']))
	{
		if (panther_hash($_POST['req_password'].$panther_user['salt']) !== $panther_user['password'])
			message($lang_profile['Wrong pass']);
			
		// Make sure they got here from the site
		confirm_referrer('profile.php');

		require PANTHER_ROOT.'include/email.php';

		// Validate the email address
		$new_email = strtolower(panther_trim($_POST['req_new_email']));
		if (!is_valid_email($new_email))
			message($lang_common['Invalid email']);

		// Check if it's a banned email address
		if (is_banned_email($new_email))
		{
			if ($panther_config['p_allow_banned_email'] == '0')
				message($lang_prof_reg['Banned email']);
			else if ($panther_config['o_mailing_list'] != '')
			{
				// Load the "banned email change" template
				$mail_tpl = trim(file_get_contents(PANTHER_ROOT.'lang/'.$panther_user['language'].'/mail_templates/banned_email_change.tpl'));

				// The first row contains the subject
				$first_crlf = strpos($mail_tpl, "\n");
				$mail_subject = trim(substr($mail_tpl, 8, $first_crlf-8));
				$mail_message = trim(substr($mail_tpl, $first_crlf));

				$mail_message = str_replace('<username>', $panther_user['username'], $mail_message);
				$mail_message = str_replace('<email>', $new_email, $mail_message);
				$mail_message = str_replace('<profile_url>', panther_link($panther_url['profile_essentials'], array($id)), $mail_message);
				$mail_message = str_replace('<board_mailer>', $panther_config['o_board_title'], $mail_message);

				panther_mail($panther_config['o_mailing_list'], $mail_subject, $mail_message);
			}
		}

		// Check if someone else already has registered with that email address
		$data = array(
			':email' => $new_email,
		);

		$ps = $db->select('users', 'id, username', $data, 'email=:email');
		if ($ps->rowCount())
		{
			if ($panther_config['p_allow_dupe_email'] == '0')
				message($lang_prof_reg['Dupe email']);
			else if ($panther_config['o_mailing_list'] != '')
			{
				$ps->setFetchMode(PDO::FETCH_COLUMN, 0);
				foreach ($ps as $cur_dupe)
					$dupe_list[] = $cur_dupe;

				// Load the "dupe email change" template
				$mail_tpl = trim(file_get_contents(PANTHER_ROOT.'lang/'.$panther_user['language'].'/mail_templates/dupe_email_change.tpl'));

				// The first row contains the subject
				$first_crlf = strpos($mail_tpl, "\n");
				$mail_subject = trim(substr($mail_tpl, 8, $first_crlf-8));
				$mail_message = trim(substr($mail_tpl, $first_crlf));

				$mail_message = str_replace('<username>', $panther_user['username'], $mail_message);
				$mail_message = str_replace('<dupe_list>', implode(', ', $dupe_list), $mail_message);
				$mail_message = str_replace('<profile_url>', panther_link($panther_url['profile_essentials'], array($id)), $mail_message);
				$mail_message = str_replace('<board_mailer>', $panther_config['o_board_title'], $mail_message);

				panther_mail($panther_config['o_mailing_list'], $mail_subject, $mail_message);
			}
		}

		$new_email_key = random_pass(8);
		$update = array(
			'activate_string' => $new_email,
			'activate_key' => $new_email_key,
		);
		
		$data = array(
			':id'	=>	$id,
		);
		
		$db->update('users', $update, 'id=:id', $data);

		// Load the "activate email" template
		$mail_tpl = trim(file_get_contents(PANTHER_ROOT.'lang/'.$panther_user['language'].'/mail_templates/activate_email.tpl'));

		// The first row contains the subject
		$first_crlf = strpos($mail_tpl, "\n");
		$mail_subject = trim(substr($mail_tpl, 8, $first_crlf-8));
		$mail_message = trim(substr($mail_tpl, $first_crlf));

		$mail_message = str_replace('<username>', $panther_user['username'], $mail_message);
		$mail_message = str_replace('<base_url>', get_base_url(true), $mail_message);
		$mail_message = str_replace('<activation_url>', panther_link($panther_url['change_email_key'], array($id, $new_email_key)), $mail_message);
		$mail_message = str_replace('<board_mailer>', $panther_config['o_board_title'], $mail_message);

		panther_mail($new_email, $mail_subject, $mail_message);
		message($lang_profile['Activate email sent'].' <a href="mailto:'.panther_htmlspecialchars($panther_config['o_admin_email']).'">'.panther_htmlspecialchars($panther_config['o_admin_email']).'</a>.', true);
	}

	$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_common['Profile'], $lang_profile['Change email']);
	$required_fields = array('req_new_email' => $lang_profile['New email'], 'req_password' => $lang_common['Password']);
	$focus_element = array('change_email', 'req_new_email');
	define('PANTHER_ACTIVE_PAGE', 'profile');
	require PANTHER_ROOT.'header.php';
	
	$change_email_tpl = panther_template('change_email.tpl');
	$search = array(
		'{change_email}' => $lang_profile['Change email'],
		'{form_action}' => panther_link($panther_url['change_email'], array($id)),
		'{email_legend}' => $lang_profile['Email legend'],
		'{csrf_token}' => generate_csrf_token(),
		'{new_email}' => $lang_profile['New email'],
		'{required}' => $lang_common['Required'],
		'{password}' => $lang_common['Password'],
		'{email_instructions}' => $lang_profile['Email instructions'],
		'{submit}' => $lang_common['Submit'],
		'{go_back}' => $lang_common['Go back'],
	);

	echo str_replace(array_keys($search), array_values($search), $change_email_tpl);
	require PANTHER_ROOT.'footer.php';
}
else if ($action == 'use_gravatar')
{
	if ($panther_config['o_avatars'] == '0')
		message($lang_profile['Avatars disabled']);

	if ($panther_user['id'] != $id && !$panther_user['is_admmod'])
		message($lang_common['No permission']);

	confirm_referrer('profile.php');
	$data = array(
		':id'	=>	$id,
	);

	$ps = $db->select('users', 'use_gravatar', $data, 'id=:id');
	$use_gravatar = $ps->fetchColumn();
	
	if (!$use_gravatar)
		delete_avatar($id);

	$redirect_msg = ($use_gravatar) ? $lang_profile['Gravatar disabled redirect'] : $lang_profile['Gravatar enabled redirect'];
	$update = array(
		'use_gravatar'	=>	(($use_gravatar == 0) ? 1 : 0)
	);

	$db->update('users', $update, 'id=:id', $data);
	redirect(panther_link($panther_url['profile_personality'], array($id)), $redirect_msg);
}
else if ($action == 'upload_avatar')
{
	if ($panther_config['o_avatars'] == '0')
		message($lang_profile['Avatars disabled']);
	
	if ($panther_config['o_avatar_upload'] == '0')
		message($lang_profile['Avatars disabled']);

	if ($panther_user['id'] != $id && !$panther_user['is_admmod'])
		message($lang_common['No permission'], false, '403 Forbidden');

	if (isset($_POST['form_sent']))
	{
		if (!isset($_FILES['req_file']))
			message($lang_profile['No file']);
		
		$avatar_path = ($panther_config['o_avatars_dir'] != '') ? $panther_config['o_avatars_path'] : PANTHER_ROOT.$panther_config['o_avatars_path'].'/';
			
		// Make sure they got here from the site
		confirm_referrer('profile.php');

		$uploaded_file = $_FILES['req_file'];

		// Make sure the upload went smooth
		if (isset($uploaded_file['error']))
		{
			switch ($uploaded_file['error'])
			{
				case 1: // UPLOAD_ERR_INI_SIZE
				case 2: // UPLOAD_ERR_FORM_SIZE
					message($lang_profile['Too large ini']);
					break;

				case 3: // UPLOAD_ERR_PARTIAL
					message($lang_profile['Partial upload']);
					break;

				case 4: // UPLOAD_ERR_NO_FILE
					message($lang_profile['No file']);
					break;

				case 6: // UPLOAD_ERR_NO_TMP_DIR
					message($lang_profile['No tmp directory']);
					break;

				default:
					// No error occured, but was something actually uploaded?
					if ($uploaded_file['size'] == 0)
						message($lang_profile['No file']);
					break;
			}
		}

		if (is_uploaded_file($uploaded_file['tmp_name']))
		{
			// Preliminary file check, adequate in most cases
			$allowed_types = array('image/gif', 'image/jpeg', 'image/pjpeg', 'image/png', 'image/x-png');
			if (!in_array($uploaded_file['type'], $allowed_types))
				message($lang_profile['Bad type']);

			// Make sure the file isn't too big
			if ($uploaded_file['size'] > $panther_config['o_avatars_size'])
				message($lang_profile['Too large'].' '.forum_number_format($panther_config['o_avatars_size']).' '.$lang_profile['bytes'].'.');

			// Move the file to the avatar directory. We do this before checking the width/height to circumvent open_basedir restrictions
			if (!@move_uploaded_file($uploaded_file['tmp_name'], $avatar_path.$id.'.tmp'))
				message($lang_profile['Move failed'].' <a href="mailto:'.panther_htmlspecialchars($panther_config['o_admin_email']).'">'.panther_htmlspecialchars($panther_config['o_admin_email']).'</a>.');

			list($width, $height, $type,) = @getimagesize($avatar_path.$id.'.tmp');

			// Determine type
			if ($type == IMAGETYPE_GIF)
				$extension = '.gif';
			else if ($type == IMAGETYPE_JPEG)
				$extension = '.jpg';
			else if ($type == IMAGETYPE_PNG)
				$extension = '.png';
			else
			{
				// Invalid type
				@unlink($avatar_path.$id.'.tmp');
				message($lang_profile['Bad type']);
			}

			// Now check the width/height
			if (empty($width) || empty($height) || $width > $panther_config['o_avatars_width'] || $height > $panther_config['o_avatars_height'])
			{
				@unlink($avatar_path.$id.'.tmp');
				message($lang_profile['Too wide or high'].' '.$panther_config['o_avatars_width'].'x'.$panther_config['o_avatars_height'].' '.$lang_profile['pixels'].'.');
			}

			// Delete any old avatars and put the new one in place
			delete_avatar($id);
			@rename($avatar_path.$id.'.tmp', $avatar_path.$id.$extension);
			compress_image($avatar_path.$id.$extension);
			@chmod($avatar_path.$id.$extension, 0644);

			// Disable Gravatar
			$update = array(
				'use_gravatar'	=>	0,
			);
			
			$data = array(
			':id'	=>	$id,
			);

			$db->update('users', $update, 'id=:id', $data);
		}
		else
			message($lang_profile['Unknown failure']);

		redirect(panther_link($panther_url['profile_personality'], array($id)), $lang_profile['Avatar upload redirect']);
	}

	$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_common['Profile'], $lang_profile['Upload avatar']);
	$required_fields = array('req_file' => $lang_profile['File']);
	$focus_element = array('upload_avatar', 'req_file');
	define('PANTHER_ACTIVE_PAGE', 'profile');
	require PANTHER_ROOT.'header.php';
	
	$csrf_token = generate_csrf_token();
	$upload_avatar_tpl = panther_template('upload_avatar.tpl');
	$search = array(
		'{upload_avatar}' => $lang_profile['Upload avatar'],
		'{form_action}' => panther_link($panther_url['upload_avatar'], array($id, $csrf_token)),
		'{csrf_token}' => $csrf_token,
		'{upload_avatar_legend}' => $lang_profile['Upload avatar legend'],
		'{max_upload_size}' => $panther_config['o_avatars_size'],
		'{file}' => $lang_profile['File'],
		'{required}' => $lang_common['Required'],
		'{description}' => $lang_profile['Avatar desc'].' '.$panther_config['o_avatars_width'].' x '.$panther_config['o_avatars_height'].' '.$lang_profile['pixels'].' '.$lang_common['and'].' '.forum_number_format($panther_config['o_avatars_size']).' '.$lang_profile['bytes'].' ('.file_size($panther_config['o_avatars_size']).').',
		'{upload}' => $lang_profile['Upload'],
		'{go_back}' => $lang_common['Go back'],
	);

	echo str_replace(array_keys($search), array_values($search), $upload_avatar_tpl);
	require PANTHER_ROOT.'footer.php';
}
else if ($action == 'delete_avatar')
{
	if ($panther_user['id'] != $id && !$panther_user['is_admmod'])
		message($lang_common['No permission'], false, '403 Forbidden');

	confirm_referrer('profile.php');

	delete_avatar($id);
	redirect(panther_link($panther_url['profile_personality'], array($id)), $lang_profile['Avatar deleted redirect']);
}

else if (isset($_POST['update_group_membership']))
{
	if (!$panther_user['is_admin'])
		message($lang_common['No permission'], false, '403 Forbidden');

	confirm_referrer('profile.php');
	$new_group_id = intval($_POST['group_id']);
	$select = array(
		':id'	=>	$id,
	);

	$ps = $db->select('users', 'group_id', $select, 'id=:id');
	$old_group_id = $ps->fetchColumn();
	
	$update = array(
		'group_id'	=>	$new_group_id,
	);
	
	$data = array(
		':id'	=>	$id,
	);

	$db->update('users', $update, 'id=:id', $data);

	// Regenerate the users info cache
	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PANTHER_ROOT.'include/cache.php';

	generate_users_info_cache();

    if ($old_group_id !=0 && ($old_group_id == PANTHER_ADMIN || $new_group_id == PANTHER_ADMIN || $panther_groups[$old_group_id]['g_admin'] == '1' || $panther_groups[$new_group_id]['g_admin'] == '1'))
		generate_admins_cache();
	
	$data = array(
		':id'	=>	$new_group_id
	);

	$ps = $db->select('groups', 'g_moderator', $data, 'g_id=:id');
	$new_group_mod = $ps->fetchColumn();

	// If the user was a moderator or an administrator, we remove him/her from the moderator list in all forums as well
	if ($new_group_id != PANTHER_ADMIN && $new_group_mod != '1')
	{
		$ps = $db->select('forums', 'id, moderators');
		foreach ($ps as $cur_forum)
		{
			$cur_moderators = ($cur_forum['moderators'] != '') ? unserialize($cur_forum['moderators']) : array();
			if (in_array($id, $cur_moderators))
			{
				$username = array_search($id, $cur_moderators);
				unset($cur_moderators[$username]);
				unset($cur_moderators['groups'][$id]);
				if (empty($cur_moderators['groups']))
					unset($cur_moderators['groups']);
				$cur_moderators = (!empty($cur_moderators)) ? serialize($cur_moderators) : NULL;
				$update = array(
					'moderators' => $cur_moderators,
				);
				
				$data = array(
					':id' => $cur_forum['id'],
				);

				$db->update('forums', $update, 'id=:id', $data);
			}
		}
	}
	else	// Else update moderator's group_id
	{
		$ps = $db->select('forums', 'id, moderators');
		foreach ($ps as $cur_forum)
		{
			$cur_moderators = ($cur_forum['moderators'] != '') ? unserialize($cur_forum['moderators']) : array();
			if (in_array($id, $cur_moderators))
			{
				$cur_moderators['groups'][$id] = $new_group_id;
				$update = array(
					'moderators' => serialize($cur_moderators),
				);
				
				$data = array(
					':id' => $cur_forum['id'],
				);
				
				$db->update('forums', $update, 'id=:id', $data);
			}
		}
	}
	redirect(panther_link($panther_url['profile_admin'], array($id)), $lang_profile['Group membership redirect']);
}
else if (isset($_POST['update_forums']))
{
	if (!$panther_user['is_admin'])
		message($lang_common['No permission'], false, '403 Forbidden');

	confirm_referrer('profile.php');

	// Get the username of the user we are processing
	$data = array(
		':id'	=>	$id,
	);

	$ps = $db->select('users', 'username, group_id', $data, 'id=:id');
	list($username, $group_id) = $ps->fetch(PDO::FETCH_NUM);
	$moderator_in = (isset($_POST['moderator_in'])) ? array_keys($_POST['moderator_in']) : array();

	// Loop through all forums
	$ps = $db->select('forums', 'id, moderators');
	foreach ($ps as $cur_forum)
	{
		$cur_moderators = ($cur_forum['moderators'] != '') ? unserialize($cur_forum['moderators']) : array();

		if (!isset($cur_moderators['groups']))
			$cur_moderators['groups'] = array();

		$cur_moderators['groups'][$id] = $group_id;

		// If the user should have moderator access (and he/she doesn't already have it)
		if (in_array($cur_forum['id'], $moderator_in) && !in_array($id, $cur_moderators))
		{
			$cur_moderators[$username] = $id;

			uksort($cur_moderators, 'utf8_strcasecmp');

			$update = array(
				'moderators' => serialize($cur_moderators),
			);
			
			$data = array(
				':id' => $cur_forum['id'],
			);

			$db->update('forums', $update, 'id=:id', $data);
		}
		// If the user shouldn't have moderator access (and he/she already has it)
		else if (!in_array($cur_forum['id'], $moderator_in) && in_array($id, $cur_moderators))
		{
			unset($cur_moderators[$username]);
			unset($cur_moderators['groups'][$id]);
			if (empty($cur_moderators['groups']))
					unset($cur_moderators['groups']);

			$cur_moderators = (!empty($cur_moderators)) ? serialize($cur_moderators) : NULL;
			$update = array(
				'moderators' => $cur_moderators,
			);
			
			$data = array(
				':id' => $cur_forum['id'],
			);
			
			$db->update('forums', $update, 'id=:id', $data);
		}
		elseif (in_array($cur_forum['id'], $moderator_in) || in_array($id, $cur_moderators))
		{
			$update = array(
				'moderators' => serialize($cur_moderators),
			);
			
			$data = array(
				':id'	=>	$cur_forum['id'],
			);
			
			$db->update('forums', $update, 'id=:id', $data);
		}
	}

	redirect(panther_link($panther_url['profile_admin'], array($id)), $lang_profile['Update forums redirect']);
}
else if (isset($_POST['update_posting_ban']))
{
	if (!$panther_user['is_admin'])
		message($lang_common['No permission']);

	confirm_referrer('profile.php');
	$data = array(
		':id'	=>	$id,
	);

	$ps = $db->select('users', 'username, group_id', $data, 'id=:id');
	$cur_user = $ps->fetch();

	if ($panther_groups[$cur_user['group_id']]['g_admin'] == '1' || $cur_user['group_id'] == PANTHER_ADMIN)
		message(sprintf($lang_profile['posting ban admin'], panther_htmlspecialchars($user['username'])));

	if ($panther_groups[$cur_user['group_id']]['g_moderator'] == '1')
		message(sprintf($lang_profile['posting ban moderator'], panther_htmlspecialchars($user['username'])));

	$expiration_time = isset($_POST['expiration_time']) ? intval($_POST['expiration_time']) : 0;
	$expiration_unit = isset($_POST['expiration_unit']) ? panther_trim($_POST['expiration_unit']) : $lang_profile['Days'];
	$delete_ban = isset($_POST['remove_ban']) ? '1' : '0';
	$time = ($delete_ban == '1') ? '0' : (time() + get_expiration_time($expiration_time, $expiration_unit)); 

	$update = array(
		'posting_ban' => $time,
	);
	
	$db->update('users', $update, 'id=:id', $data);
	redirect(panther_link($panther_url['profile_admin'], array($id)), $lang_profile['Update posting ban redirect']);
}
else if (isset($_POST['ban']))
{
	if (!$panther_user['is_admin'] && ($panther_user['g_moderator'] != '1' || $panther_user['g_mod_ban_users'] == '0'))
		message($lang_common['No permission'], false, '403 Forbidden');

	// Get the username of the user we are banning
	$data = array(
		':id' => $id,
	);

	$ps = $db->select('users', 'username', $data, 'id=:id');
	$username = $ps->fetchColumn();

	// Check whether user is already banned
	$data = array(
		':username'	=>	$username,
	);
	$ps = $db->select('bans', 'id', $data, 'username=:username', 'expire IS NULL DESC, expire DESC LIMIT 1');
	if ($ps->rowCount())
	{
		$ban_id = $ps->fetchColumn();
		redirect(panther_link($panther_url['edit_ban'], array($ban_id)), $lang_profile['Ban redirect']);
	}
	else
		redirect(panther_link($panther_url['admin_bans_add'], array($id)), $lang_profile['Ban redirect']);
}
else if ($action == 'promote')
{
	if (!$panther_user['is_admin'] && ($panther_user['g_moderator'] != '1' || $panther_user['g_mod_promote_users'] == '0'))
		message($lang_common['No permission']);

	$pid = isset($_GET['pid']) ? intval($_GET['pid']) : 0;
	if ($pid < 1)
		message($lag_common['Bad request']);

	$data = array(
		':id' => $id,
	);

	$ps = $db->run('SELECT g.g_promote_next_group FROM '.$db->prefix.'groups AS g INNER JOIN '.$db->prefix.'users AS u ON u.group_id=g.g_id WHERE u.id=:id AND g.g_promote_next_group>0', $data);

	if (!$ps->rowCount())
		message($lang_common['Bad request'], false, '404 Not Found');

	$update = array(
		'group_id' => $ps->fetchColumn(),
	);
	
	$data = array(
		':id' => $id,
	);

	$db->update('users', $update, 'id=:id', $data);
	redirect(panther_link($panther_url['post'], array($pid)), $lang_profile['User promote redirect']);
}
else if (isset($_POST['delete_user']) || isset($_POST['delete_user_comply']))
{
	if ($panther_user['g_id'] != PANTHER_ADMIN && $panther_user['g_admin'] != '1')
		message($lang_common['No permission'], false, '403 Forbidden');

	confirm_referrer('profile.php');
	
	if (file_exists(FORUM_CACHE_DIR.'cache_restrictions.php'))
		require FORUM_CACHE_DIR.'cache_restrictions.php';
	else
	{
		if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
			require PANTHER_ROOT.'include/cache.php';

		generate_admin_restrictions_cache();
		require FORUM_CACHE_DIR.'cache_restrictions.php';
	}

	if (!isset($admins[$panther_user['id']]) || $panther_user['id'] == '2')
		$admins[$panther_user['id']] = array('admin_users' => '1');	
	
	if ($admins[$panther_user['id']]['admin_users'] == '0')
		message($lang_common['No permission']);

	// Get the username and group of the user we are deleting
	$data = array(
	':id'	=>	$id,
	);

	$ps = $db->select('users', 'group_id, username', $data, 'id=:id');
	list($group_id, $username) = $ps->fetch(PDO::FETCH_NUM);

	if ($group_id == PANTHER_ADMIN || $panther_groups[$group_id]['g_admin'] == '1')
		message($lang_profile['No delete admin message']);

	if (isset($_POST['delete_user_comply']))
	{
		// If the user is a moderator or an administrator, we remove him/her from the moderator list in all forums as well7
		$data = array(
			':id'	=>	$group_id,
		);
		$ps = $db->select('groups', 'g_moderator', $data, 'g_id=:id');
		$group_mod = $ps->fetchColumn();

		if ($group_id == PANTHER_ADMIN || $group_mod == '1')
		{
			$ps = $db->select('forums', 'id, moderators');
			foreach ($ps as $cur_forum)
			{
				$cur_moderators = ($cur_forum['moderators'] != '') ? unserialize($cur_forum['moderators']) : array();
				if (in_array($id, $cur_moderators))
				{
					unset($cur_moderators[$username]);
					$cur_moderators = (!empty($cur_moderators)) ? serialize($cur_moderators) : NULL;
					$update = array(
						'moderators'	=>	$cur_moderators,
					);
					
					$data = array(
						':id'	=>	$cur_forum['id'],
					);
					
					$db->update('forums', $update, 'id=:id', $data);
				}
			}
		}
		
		$data = array(
			':id'	=>	$id,
		);

		// Delete any subscriptions
		$db->delete('topic_subscriptions', 'user_id=:id', $data);
		$db->delete('forum_subscriptions', 'user_id=:id', $data);
		
		// Remove any issued warnings
		$db->delete('warnings', 'user_id=:id', $data);

		// Remove them from the online list (if they happen to be logged in)
		$db->delete('online', 'user_id=:id', $data);

		// Should we delete all posts made by this user?
		if (isset($_POST['delete_posts']))
		{
			require PANTHER_ROOT.'include/search_idx.php';
			@set_time_limit(0);

			// Find all posts made by this user
			$ps = $db->run('SELECT p.id, p.topic_id, t.forum_id FROM '.$db->prefix.'posts AS p INNER JOIN '.$db->prefix.'topics AS t ON t.id=p.topic_id INNER JOIN '.$db->prefix.'forums AS f ON f.id=t.forum_id WHERE p.poster_id=:id', $data);
			if ($ps->rowCount())
			{
				foreach ($ps as $cur_post)
				{
					// Determine whether this post is the "topic post" or not
					$select = array(
						':id'	=>	$cur_post['topic_id'],
					);

					$ps1 = $db->select('posts', 'id', $select, 'topic_id=:id', 'posted LIMIT 1');
					if ($ps1->fetchColumn() == $cur_post['id'])
						delete_topic($cur_post['topic_id']);
					else
						delete_post($cur_post['id'], $cur_post['topic_id']);
					
					$delete = array(
						':id'	=>	$cur_post['id'],
					);
					
					$db->delete('reputation', 'post_id=:id', $delete);

					update_forum($cur_post['forum_id']);
				}
			}
		}
		else	// Set all his/her posts to guest
		{
			$update = array(
				'poster_id'	=>	1,
			);

			$db->update('posts', $update, 'poster_id=:id', $data);
		}

		// Delete user avatar
		delete_avatar($id);

		// Delete the user
		$db->delete('users', 'id=:id', $data);

		// Regenerate the users info cache
		if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
			require PANTHER_ROOT.'include/cache.php';

		generate_users_info_cache();

		if ($group_id == PANTHER_ADMIN || $panther_groups[$group_id]['g_admin'] == '1')
		{
			generate_admins_cache();
			generate_admin_restrictions_cache();
		}

		redirect(panther_link($panther_url['index']), $lang_profile['User delete redirect']);
	}

	$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_common['Profile'], $lang_profile['Confirm delete user']);
	define('PANTHER_ACTIVE_PAGE', 'profile');
	require PANTHER_ROOT.'header.php';

	$del_user_tpl = panther_template('del_user.tpl');
	$search = array(
		'{confirm_deletion}' => $lang_profile['Confirm delete user'],
		'{form_action}' => panther_link($panther_url['profile'], array($id, url_friendly($username))),
		'{confirm_legend}' => $lang_profile['Confirm delete legend'],
		'{confirmation_info}' => $lang_profile['Confirmation info'],
		'{username}' => panther_htmlspecialchars($username),
		'{delete_posts}' => $lang_profile['Delete posts'],
		'{csrf_token}' => generate_csrf_token(),
		'{delete_warning}' => $lang_profile['Delete warning'],
		'{delete}' => $lang_profile['Delete'],
		'{go_back}' => $lang_common['Go back'],
	);

	echo str_replace(array_keys($search), array_values($search), $del_user_tpl);
	require PANTHER_ROOT.'footer.php';
}
else if (isset($_POST['form_sent']))
{
	$data = array(
		':id'	=>	$id,
	);
	
	// Fetch the user group of the user we are editing
	$ps = $db->run('SELECT u.username, u.group_id, g.g_moderator FROM '.$db->prefix.'users AS u LEFT JOIN '.$db->prefix.'groups AS g ON (g.g_id=u.group_id) WHERE u.id=:id', $data);
	if (!$ps->rowCount())
		message($lang_common['Bad request'], false, '404 Not Found');

	list($old_username, $group_id, $is_moderator) = $ps->fetch(PDO::FETCH_NUM);

	if ($panther_user['id'] != $id && !in_array($section, array('rep_received', 'rep_given')) &&																	// If we aren't the user (i.e. editing your own profile) and we aren't viewing what rep they have
		(!$panther_user['is_admmod'] ||																	// and we are not an admin or mod
		(!$panther_user['is_admin'] &&															// or we aren't an admin and ...
		($panther_user['g_mod_edit_users'] == '0' ||													// mods aren't allowed to edit users
		$group_id == PANTHER_ADMIN ||																	// or the user is an admin
		$is_moderator))))																			// or the user is another mod
		message($lang_common['No permission'], false, '403 Forbidden');

	// Make sure they got here from the site
	confirm_referrer('profile.php');

	$username_updated = false;

	// Validate input depending on section
	switch ($section)
	{
		case 'essentials':
		{
			$form = array(
				'timezone'		=> floatval($_POST['form']['timezone']),
				'dst'			=> isset($_POST['form']['dst']) ? '1' : '0',
				'time_format'	=> intval($_POST['form']['time_format']),
				'date_format'	=> intval($_POST['form']['date_format']),
			);

			// Make sure we got a valid language string
			if (isset($_POST['language']))
			{
				$languages = forum_list_langs();
				$form['language'] = panther_trim($_POST['language']);
				if (!in_array($form['language'], $languages))
					message($lang_common['Bad request'], false, '404 Not Found');
			}

			if ($panther_user['is_admmod'])
			{
				$form['admin_note'] = panther_trim($_POST['admin_note']);

				// Are we allowed to change usernames?
				if ($panther_user['is_admin'] || ($panther_user['g_moderator'] == '1' && $panther_user['g_mod_rename_users'] == '1'))
				{
					$form['username'] = panther_trim($_POST['req_username']);

					if ($form['username'] != $old_username)
					{
						// Check username
						require PANTHER_ROOT.'lang/'.$panther_user['language'].'/register.php';

						$errors = array();
						check_username($form['username'], $id);
						if (!empty($errors))
							message($errors[0]);

						$username_updated = true;
					}
				}

				// We only allow administrators to update the post count
				if ($panther_user['is_admin'])
					$form['num_posts'] = intval($_POST['num_posts']);
			}

			if ($panther_config['o_regs_verify'] == '0' || $panther_user['is_admmod'])
			{
				require PANTHER_ROOT.'include/email.php';

				// Validate the email address
				$form['email'] = strtolower(panther_trim($_POST['req_email']));
				if (!is_valid_email($form['email']))
					message($lang_common['Invalid email']);
			}

			break;
		}

		case 'personal':
		{
			$form = array(
				'realname'		=> isset($_POST['form']['realname']) ? panther_trim($_POST['form']['realname']) : '',
				'url'			=> isset($_POST['form']['url']) ? panther_trim($_POST['form']['url']) : '',
				'location'		=> isset($_POST['form']['location']) ? panther_trim($_POST['form']['location']) : '',
			);

			// Add http:// if the URL doesn't contain it already (while allowing https://, too)
			if ($panther_user['g_post_links'] == '1')
			{
				if ($form['url'] != '')
				{
					$url = url_valid($form['url']);

					if ($url === false)
						message($lang_profile['Invalid website URL']);

					$form['url'] = $url['url'];
				}
			}
			else
			{
				if (!empty($form['url']))
					message($lang_profile['Website not allowed']);

				$form['url'] = '';
			}

			if ($panther_user['is_admin'])
				$form['title'] = panther_trim($_POST['title']);
			else if ($panther_user['g_set_title'] == '1')
			{
				$form['title'] = panther_trim($_POST['title']);

				if ($form['title'] != '')
				{
					// A list of words that the title may not contain
					// If the language is English, there will be some duplicates, but it's not the end of the world
					$forbidden = array('member', 'moderator', 'administrator', 'banned', 'guest', utf8_strtolower($lang_common['Member']), utf8_strtolower($lang_common['Moderator']), utf8_strtolower($lang_common['Administrator']), utf8_strtolower($lang_common['Banned']), utf8_strtolower($lang_common['Guest']));

					if (in_array(utf8_strtolower($form['title']), $forbidden))
						message($lang_profile['Forbidden title']);
				}
			}

			break;
		}

		case 'messaging':
		{
			$form = array(
				'facebook'		=> panther_trim($_POST['form']['facebook']),
				'steam'			=> panther_trim($_POST['form']['steam']),
				'msn'			=> panther_trim($_POST['form']['msn']),
				'google'		=> panther_trim($_POST['form']['google']),
				'twitter'		=> panther_trim($_POST['form']['twitter']),
			);

			break;
		}

		case 'personality':
		{
			$form = array();

			// Clean up signature from POST
			if ($panther_config['o_signatures'] == '1')
			{
				$form['signature'] = panther_linebreaks(panther_trim($_POST['signature']));

				// Validate signature
				if (panther_strlen($form['signature']) > $panther_config['p_sig_length'])
					message(sprintf($lang_prof_reg['Sig too long'], $panther_config['p_sig_length'], panther_strlen($form['signature']) - $panther_config['p_sig_length']));
				else if (substr_count($form['signature'], "\n") > ($panther_config['p_sig_lines']-1))
					message(sprintf($lang_prof_reg['Sig too many lines'], $panther_config['p_sig_lines']));
				else if ($form['signature'] && $panther_config['p_sig_all_caps'] == '0' && is_all_uppercase($form['signature']) && !$panther_user['is_admmod'])
					$form['signature'] = utf8_ucwords(utf8_strtolower($form['signature']));

				// Validate BBCode syntax
				if ($panther_config['p_sig_bbcode'] == '1')
				{
					require PANTHER_ROOT.'include/parser.php';

					$errors = array();
					$form['signature'] = preparse_bbcode($form['signature'], $errors, true);

					if(count($errors) > 0)
						message('<ul><li>'.implode('</li><li>', $errors).'</li></ul>');
				}
			}

			break;
		}

		case 'display':
		{
			$form = array(
				'disp_topics'		=> panther_trim($_POST['form']['disp_topics']),
				'disp_posts'		=> panther_trim($_POST['form']['disp_posts']),
				'show_smilies'		=> isset($_POST['form']['show_smilies']) ? '1' : '0',
				'show_img'			=> isset($_POST['form']['show_img']) ? '1' : '0',
				'show_img_sig'		=> isset($_POST['form']['show_img_sig']) ? '1' : '0',
				'show_avatars'		=> isset($_POST['form']['show_avatars']) ? '1' : '0',
				'show_sig'			=> isset($_POST['form']['show_sig']) ? '1' : '0',
				'use_editor'		=> isset($_POST['form']['use_editor']) ? '1' : '0',
			);

			if ($form['disp_topics'] != '')
			{
				$form['disp_topics'] = intval($form['disp_topics']);
				if ($form['disp_topics'] < 3)
					$form['disp_topics'] = 3;
				else if ($form['disp_topics'] > 75)
					$form['disp_topics'] = 75;
			}

			if ($form['disp_posts'] != '')
			{
				$form['disp_posts'] = intval($form['disp_posts']);
				if ($form['disp_posts'] < 3)
					$form['disp_posts'] = 3;
				else if ($form['disp_posts'] > 75)
					$form['disp_posts'] = 75;
			}

			// Make sure we got a valid style string
			if (isset($_POST['form']['style']))
			{
				$styles = forum_list_styles();
				$form['style'] = panther_trim($_POST['form']['style']);
				if (!in_array($form['style'], $styles))
					message($lang_common['Bad request'], false, '404 Not Found');
			}

			break;
		}

		case 'privacy':
		{
			$form = array(
				'email_setting'			=> intval($_POST['form']['email_setting']),
				'notify_with_post'		=> isset($_POST['form']['notify_with_post']) ? '1' : '0',
				'auto_notify'			=> isset($_POST['form']['auto_notify']) ? '1' : '0',
				'pm_enabled'			=> isset($_POST['form']['pm_enabled']) ? '1' : '0',
				'pm_notify'				=> isset($_POST['form']['pm_notify']) ? '1' : '0',
			);

			if ($form['email_setting'] < 0 || $form['email_setting'] > 2)
				$form['email_setting'] = $panther_config['o_default_email_setting'];

			break;
		}

		default:
			message($lang_common['Bad request'], false, '404 Not Found');
	}

	// Single quotes around non-empty values and NULL for empty values
	$temp = $data = array();
	foreach ($form as $key => $input)
	{
		$value = ($input !== '') ? $input : NULL;

		$temp[] = $key.'= ?';
		$data[] = $value;
	}

	if (empty($temp))
		message($lang_common['Bad request'], false, '404 Not Found');

	$data[] = $id;
	$db->run('UPDATE '.$db->prefix.'users SET '.implode(',', $temp).' WHERE id=?', $data);

	// If we changed the username we have to update some stuff
	if ($username_updated)
	{
		$update = array(
			'username'	=>	$form['username'],
		);
		
		$data = array(
			':user'	=>	$old_username,
		);

		$rows = $db->update('bans', $update, 'username=:user', $data);

		// If any bans were updated, we will need to know because the cache will need to be regenerated.
		if ($rows > 0)
			$bans_updated = true;
		
		$update = array(
			'poster'	=>	$form['username'],
		);

		$data = array(
			':id'	=>	$id,
		);
		
		$db->update('posts', $update, 'poster_id=:id', $data);

		$data = array(
			':username'	=>	$old_username,
		);
		
		$db->update('topics', $update, 'poster=:username', $data);

		$update = array(
			'edited_by'	=>	$form['username'],
		);
		
		$db->update('posts', $update, 'edited_by=:username', $data);
		
		$update = array(
			'last_poster'	=>	$form['username'],
		);
		
		$db->update('topics', $update, 'last_poster=:username', $data);
		$db->update('topics', $update, 'last_poster=:username', $data);
		$db->update('forums', $update, 'last_poster=:username', $data);
		
		$update = array(
			'ident'	=>	$form['username'],
		);

		$db->update('online', $update, 'ident=:username', $data);

		// If the user is a moderator or an administrator we have to update the moderator lists
		$data = array(
			':id'	=>	$id,
		);
		$ps = $db->select('users', 'group_id', $data, 'id=:id');
		$group_id = $ps->fetchColumn();

		if ($group_id == PANTHER_ADMIN || $panther_groups[$group_id]['g_moderator'] == '1')
		{
			$ps = $db->select('forums', 'id, moderators');
			foreach ($ps as $cur_forum)
			{
				$cur_moderators = ($cur_forum['moderators'] != '') ? unserialize($cur_forum['moderators']) : array();
				if (in_array($id, $cur_moderators))
				{
					unset($cur_moderators[$old_username]);
					$cur_moderators[$form['username']] = $id;
					uksort($cur_moderators, 'utf8_strcasecmp');

					$update = array(
						'moderators'	=>	serialize($cur_moderators),
					);
					
					$data = array(
						':id'	=>	$cur_forum['id'],
					);
					
					$db->update('forums', $update, 'id=:id', $data);
				}
			}
		}

		// Regenerate the users info cache
		if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
			require PANTHER_ROOT.'include/cache.php';

		generate_users_info_cache();

		// Check if the bans table was updated and regenerate the bans cache when needed
		if (isset($bans_updated))
			generate_bans_cache();
	}

	redirect(panther_link($panther_url['profile_'.strtolower($section)], array($id)), $lang_profile['Profile redirect']);
}

flux_hook('profile_after_form_handling');
$data = array(
	':id'	=>	$id,
);

$ps = $db->run('SELECT u.username, u.email, u.title, u.realname, u.url, u.facebook, u.steam, u.msn, u.google, u.twitter, u.location, u.signature, u.disp_topics, u.disp_posts, u.email_setting, u.notify_with_post, u.auto_notify, u.use_editor, u.pm_enabled, u.pm_notify, u.use_gravatar, u.show_smilies, u.show_img, u.show_img_sig, u.show_avatars, u.show_sig, u.timezone, u.dst, u.language, u.style, u.num_posts, u.last_post, u.last_visit, u.registered, u.registration_ip, u.reputation, u.admin_note, u.date_format, u.time_format, u.last_visit, u.posting_ban, g.g_id, g.g_user_title, g.g_moderator, g.g_use_pm, g.g_admin FROM '.$db->prefix.'users AS u LEFT JOIN '.$db->prefix.'groups AS g ON g.g_id=u.group_id WHERE u.id=:id', $data);
if (!$ps->rowCount())
	message($lang_common['Bad request'], false, '404 Not Found');
else
	$user = $ps->fetch();

$last_post = format_time($user['last_post']);
if ($user['signature'] != '')
{
	require PANTHER_ROOT.'include/parser.php';
	$parsed_signature = parse_signature($user['signature']);
}

// View or edit?
if ($panther_user['id'] != $id && !in_array($section, array('rep_received', 'rep_given', 'view')) && 																	// If we aren't the user (i.e. editing your own profile) and we aren't viewing what rep they have
	(!$panther_user['is_admmod'] ||																	// and we are not an admin or mod
	(!$panther_user['is_admin'] &&															// or we aren't an admin and ...
	($panther_user['g_mod_edit_users'] == '0' ||													// mods aren't allowed to edit users
	$user['g_id'] == PANTHER_ADMIN ||																// or the user is an admin
	$user['g_moderator'] == '1'))) || $section == 'view')																// or the user is another mod
{
	$user_personal = array();

	if ($panther_config['o_users_online'] == '1')
	{
		require PANTHER_ROOT.'lang/'.$panther_user['language'].'/online.php';
		$data = array(
			':id'	=>	$id,
		);
		
		$ps = $db->select('online', 'currently', $data, 'user_id=:id');
		$online = $ps->fetch();
	
		if ($online['currently'] == NULL || $online['currently'] == '')
		{
			$icon = 'status_offline';
			$status = $lang_online['user is offline'];
			$location = $lang_online['not online'];
		}
		else
		{
			$icon = 'status_online';
			$status = $lang_online['user is online'];
			$location = generate_user_location($online['currently']);
		}
	}
	$user_personal[] = '<dt>'.$lang_common['Username'].'</dt>';
	$user_personal[] = '<dd><img src="'.$panther_config['o_image_dir'].$icon.'.png" title="'.$status.'" />'.colourize_group($user['username'], $user['g_id']).'</dd>';

	$user_title_field = get_title($user);
	$user_personal[] = '<dt>'.$lang_common['Title'].'</dt>';
	$user_personal[] = '<dd>'.(($panther_config['o_censoring'] == '1') ? censor_words($user_title_field) : $user_title_field).'</dd>';

	if ($user['realname'] != '')
	{
		$user_personal[] = '<dt>'.$lang_profile['Realname'].'</dt>';
		$user_personal[] = '<dd>'.panther_htmlspecialchars(($panther_config['o_censoring'] == '1') ? censor_words($user['realname']) : $user['realname']).'</dd>';
	}

	if ($user['location'] != '')
	{
		$user_personal[] = '<dt>'.$lang_profile['Location'].'</dt>';
		$user_personal[] = '<dd>'.panther_htmlspecialchars(($panther_config['o_censoring'] == '1') ? censor_words($user['location']) : $user['location']).'</dd>';
	}

	if ($user['url'] != '')
	{
		$user['url'] = panther_htmlspecialchars(($panther_config['o_censoring'] == '1') ? censor_words($user['url']) : $user['url']);
		$user_personal[] = '<dt>'.$lang_profile['Website'].'</dt>';
		$user_personal[] = '<dd><span class="website"><a href="'.$user['url'].'" rel="nofollow">'.panther_htmlspecialchars($user['url']).'</a></span></dd>';
	}

	if ($user['email_setting'] == '0' && !$panther_user['is_guest'] && $panther_user['g_send_email'] == '1')
		$email_field = '<a href="mailto:'.panther_htmlspecialchars($user['email']).'">'.panther_htmlspecialchars($user['email']).'</a>';
	else if ($user['email_setting'] == '1' && !$panther_user['is_guest'] && $panther_user['g_send_email'] == '1')
		$email_field = '<a href="'.panther_link($panther_url['email'], array($id)).'">'.$lang_common['Send email'].'</a>';
	else
		$email_field = '';
	if ($email_field != '')
	{
		$user_personal[] = '<dt>'.$lang_common['Email'].'</dt>';
		$user_personal[] = '<dd><span class="email">'.$email_field.'</span></dd>';
	}

	$user_personal[] = '<dt>'.$lang_online['currently'].'</dt>';
	$user_personal[] = '<dd>'.$location.'</dd>';
	$user_messaging = array();

	if ($user['facebook'] != '')
	{
		$user_messaging[] = '<dt>'.$lang_profile['Facebook'].'</dt>';
		$user_messaging[] = '<dd>'.panther_htmlspecialchars(($panther_config['o_censoring'] == '1') ? censor_words($user['facebook']) : $user['facebook']).'</dd>';
	}

	if ($user['steam'] != '')
	{
		$user_messaging[] = '<dt>'.$lang_profile['Steam'].'</dt>';
		$user_messaging[] = '<dd>'.panther_htmlspecialchars($user['steam']).'</dd>';
	}

	if ($user['msn'] != '')
	{
		$user_messaging[] = '<dt>'.$lang_profile['MSN'].'</dt>';
		$user_messaging[] = '<dd>'.panther_htmlspecialchars(($panther_config['o_censoring'] == '1') ? censor_words($user['msn']) : $user['msn']).'</dd>';
	}

	if ($user['twitter'] != '')
	{
		$user_messaging[] = '<dt>'.$lang_profile['Twitter'].'</dt>';
		$user_messaging[] = '<dd>'.panther_htmlspecialchars(($panther_config['o_censoring'] == '1') ? censor_words($user['twitter']) : $user['twitter']).'</dd>';
	}
	
	if ($user['google'] != '')
	{
		$user_messaging[] = '<dt>'.$lang_profile['Google'].'</dt>';
		$user_messaging[] = '<dd>'.panther_htmlspecialchars(($panther_config['o_censoring'] == '1') ? censor_words($user['google']) : $user['google']).'</dd>';
	}

	$user_personality = array();
	if ($panther_config['o_avatars'] == '1')
	{
		$avatar_field = generate_avatar_markup($id, $user['email'], $user['use_gravatar']);
		if ($avatar_field != '')
		{
			$user_personality[] = '<dt>'.$lang_profile['Avatar'].'</dt>';
			$user_personality[] = '<dd>'.$avatar_field.'</dd>';
		}
	}

	if ($panther_config['o_signatures'] == '1')
	{
		if (isset($parsed_signature))
		{
			$user_personality[] = '<dt>'.$lang_profile['Signature'].'</dt>';
			$user_personality[] = '<dd><div class="postsignature postmsg">'.$parsed_signature.'</div></dd>';
		}
	}

	$user_activity = array();

	$posts_field = '';
	if ($panther_config['o_show_post_count'] == '1' || $panther_user['is_admmod'])
		$posts_field = forum_number_format($user['num_posts']);
	if ($panther_user['g_search'] == '1')
	{
		if ($panther_user['is_admmod'] && $panther_config['o_warnings'] == '1')
		{
			// Load the warnings.php language file
			require PANTHER_ROOT.'lang/'.$panther_user['language'].'/warnings.php';

			// Does the user have active warnings?
			$data = array(
				':id'	=>	$id,
				':time'	=>	time(),
			);

			$ps = $db->select('warnings', 'SUM(points)', $data, 'user_id=:id AND (date_expire>:time OR date_expire=0)');
			$has_active = $ps->fetchColumn();

			if ($has_active)
			{
				$warning_level = '<strong>'.$lang_warnings['Warning level'].'</strong>';
				$points_active = '<strong>'.$has_active.'</strong>';
			}
			else
			{
				$warning_level = $lang_warnings['Warning level'];
				$points_active = '0';
			}
		}


		if (($panther_user['is_admin'] || ($panther_user['is_admmod'] && $panther_user['g_mod_warn_users'] == '1')) && $panther_config['o_warnings'] == '1')
		{
			$user_activity[] = '<dt>'.$warning_level.'</dt>';
			$user_activity[] = '<dd>'.$points_active.' - <a href="'.panther_link($panther_url['warning_view'], array($id)).'">'.$lang_warnings['Show all warnings'].'</a> - <a href="'.panther_link($panther_url['warn_user'], array($id)).'">'.$lang_warnings['Warn user'].'</a>'.'</dd>';
		}
		else if ($panther_user['is_admmod'] && $panther_config['o_warnings'] == '1')
		{
			$user_activity[] = '<dt>'.$warning_level.'</dt>';
			$user_activity[] = '<dd>'.$points_active.'</dd>';
		}

		$quick_searches = array();
		if ($user['num_posts'] > 0)
		{
			$quick_searches[] = '<a href="'.panther_link($panther_url['search_user_topics'], array($id)).'">'.$lang_profile['Show topics'].'</a>';
			$quick_searches[] = '<a href="'.panther_link($panther_url['search_user_posts'], array($id)).'">'.$lang_profile['Show posts'].'</a>';
		}
		if ($panther_user['is_admmod'] && $panther_config['o_topic_subscriptions'] == '1')
			$quick_searches[] = '<a href="'.panther_link($panther_url['search_subscriptions'], array($id)).'">'.$lang_profile['Show subscriptions'].'</a>';

		if (!empty($quick_searches))
			$posts_field .= (($posts_field != '') ? ' - ' : '').implode(' - ', $quick_searches);
	}
	if ($posts_field != '')
	{
		$user_activity[] = '<dt>'.$lang_common['Posts'].'</dt>';
		$user_activity[] = '<dd>'.$posts_field.'</dd>';
	}

	if ($user['num_posts'] > 0)
	{
		$user_activity[] = '<dt>'.$lang_common['Last post'].'</dt>';
		$user_activity[] = '<dd>'.$last_post.'</dd>';
	}

	$user_activity[] = '<dt>'.$lang_profile['Last visit'].'</dt>';
	$user_activity[] = '<dd>'.format_time($user['last_visit']).'</dd>';

	$user_activity[] = '<dt>'.$lang_common['Registered'].'</dt>';
	$user_activity[] = '<dd>'.format_time($user['registered'], true).'</dd>';

	if ($panther_config['o_reputation'] == '1')
	{
		switch(true)
		{
			case $user['reputation'] > '0':
				$type = 'positive';
			break;
			case $user['reputation'] < '0':
				$type = 'negative';
			break;
			default:
				$type = 'zero';
			break;
		}

		$user_reputation = '<span class="reputation '.$type.'">'.$lang_profile['Reputation'].': '.$user['reputation'].'</span><br /><br />';
	}

	$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), sprintf($lang_profile['Users profile'], panther_htmlspecialchars($user['username'])));
	define('PANTHER_ALLOW_INDEX', 1);
	define('PANTHER_ACTIVE_PAGE', 'index');
	require PANTHER_ROOT.'header.php';

	if ($section == 'view' && $panther_user['id'] == $id || $panther_user['is_admmod'] && ($panther_user['is_admin'] || $panther_user['g_mod_edit_users'] == '1'))
		generate_profile_menu('view');

	$template = panther_template('profile_section.tpl');
	if ($panther_config['o_reputation'] == '1')
	{
		$search = array(
			'{section_name}' => $lang_profile['Reputation'],
			'{section_data}' => $user_reputation.'<label><a href="'.panther_link($panther_url['profile_rep_received'], array($id)).'">'.$lang_profile['Rep_received'].'</a><br /></label><label><a href="'.panther_link($panther_url['profile_rep_given'], array($id)).'">'.$lang_profile['Rep_given'].'</a><br /></label>',
		);

		$sections[] = str_replace(array_keys($search), array_values($search), $template);
	}

	if (!empty($user_messaging))
	{
		$search = array(
			'{section_name}' => $lang_profile['Section messaging'],
			'{section_data}' => implode("\n\t\t\t\t\t\t\t", $user_messaging)."\n"
		);

		$sections[] = str_replace(array_keys($search), array_values($search), $template);
	}
	
	if (!empty($user_personality))
	{
		$search = array(
			'{section_name}' => $lang_profile['Section personality'],
			'{section_data}' => implode("\n\t\t\t\t\t\t\t", $user_personality)."\n"
		);

		$sections[] = str_replace(array_keys($search), array_values($search), $template);
	}
	
	$profile_tpl = panther_template('profile_view.tpl');
	$search = array(
		'{profile}' => $lang_common['Profile'],
		'{personal}' => $lang_profile['Section personal'],
		'{user_personal}' => implode("\n\t\t\t\t\t\t\t", $user_personal)."\n",
		'{additional_sections}' => (count($sections) ? implode("\n", $sections) : ''),
		'{activity}' => $lang_profile['User activity'],
		'{user_activity}' =>  implode("\n\t\t\t\t\t\t\t", $user_activity)."\n",
	);

	echo str_replace(array_keys($search), array_values($search), $profile_tpl);
	require PANTHER_ROOT.'footer.php';
}
else
{
	if (!$section || $section == 'essentials')
	{
		if ($panther_user['is_admmod'])
		{
			if ($panther_user['is_admin'] || $panther_user['g_mod_rename_users'] == '1')
				$username_field = '<label class="required"><strong>'.$lang_common['Username'].' <span>'.$lang_common['Required'].'</span></strong><br /><input type="text" name="req_username" value="'.panther_htmlspecialchars($user['username']).'" size="25" maxlength="25" /><br /></label>'."\n";
			else
				$username_field = '<p>'.sprintf($lang_profile['Username info'], panther_htmlspecialchars($user['username'])).'</p>'."\n";

			$email_field = '<label class="required"><strong>'.$lang_common['Email'].' <span>'.$lang_common['Required'].'</span></strong><br /><input type="text" name="req_email" value="'.panther_htmlspecialchars($user['email']).'" size="40" maxlength="80" /><br /></label><p><span class="email"><a href="'.panther_link($panther_url['email'], array($id)).'">'.$lang_common['Send email'].'</a></span></p>'."\n";
		}
		else
		{
			$username_field = '<p>'.$lang_common['Username'].': '.panther_htmlspecialchars($user['username']).'</p>'."\n";

			if ($panther_config['o_regs_verify'] == '1')
				$email_field = '<p>'.sprintf($lang_profile['Email info'], panther_htmlspecialchars($user['email']).' - <a href="'.panther_link($panther_url['change_email'], array($id)).'">'.$lang_profile['Change email'].'</a>').'</p>'."\n";
			else
				$email_field = '<label class="required"><strong>'.$lang_common['Email'].' <span>'.$lang_common['Required'].'</span></strong><br /><input type="text" name="req_email" value="'.$user['email'].'" size="40" maxlength="80" /><br /></label>'."\n";
		}

		$posts_field = '';
		$posts_actions = array();

		if ($panther_user['is_admin'])
			$posts_field .= '<label>'.$lang_common['Posts'].'<br /><input type="text" name="num_posts" value="'.$user['num_posts'].'" size="8" maxlength="8" /><br /></label>';
		else if ($panther_config['o_show_post_count'] == '1' || $panther_user['is_admmod'])
			$posts_actions[] = sprintf($lang_profile['Posts info'], forum_number_format($user['num_posts']));

		if ($panther_user['g_search'] == '1' || $panther_user['is_admin'])
		{
			$posts_actions[] = '<a href="'.panther_link($panther_url['search_user_topics'], array($id)).'">'.$lang_profile['Show topics'].'</a>';
			$posts_actions[] = '<a href="'.panther_link($panther_url['search_user_posts'], array($id)).'">'.$lang_profile['Show posts'].'</a>';

			if ($panther_config['o_topic_subscriptions'] == '1')
				$posts_actions[] = '<a href="'.panther_link($panther_url['search_subscriptions'], array($id)).'">'.$lang_profile['Show subscriptions'].'</a>';
		}

		$posts_field .= (!empty($posts_actions) ? '<p class="actions">'.implode(' - ', $posts_actions).'</p>' : '')."\n";
		require PANTHER_ROOT.'lang/'.$panther_user['language'].'/warnings.php';
		
		// Does the user have active warnings?
		$data = array(
			':id'	=>	$id,
			':time'	=>	time(),
		);

		$ps = $db->select('warnings', 'SUM(points)', $data, 'user_id=:id AND (date_expire>:time OR date_expire=0)');
		$has_active = $ps->fetchColumn();

		if ($has_active)
			$warning_level = '<strong>'.$lang_warnings['Warning level'].': '.$has_active.'</strong>';
		else
			$warning_level = $lang_warnings['Warning level'].': '.$has_active;

		$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_common['Profile'], $lang_profile['Section essentials']);
		$required_fields = array('req_username' => $lang_common['Username'], 'req_email' => $lang_common['Email']);
		define('PANTHER_ACTIVE_PAGE', 'profile');
		require PANTHER_ROOT.'header.php';

		generate_profile_menu('essentials');
		
		$time_formats = $date_formats = array();
		foreach (array_unique($forum_time_formats) as $key => $time_format)
			$time_formats[] = "\t\t\t\t\t\t\t\t".'<option value="'.$key.'"'.(($user['time_format'] == $key) ? ' selected="selected"' : '').'>'.format_time(time(), false, null, $time_format, true, true).(($key == 0) ? ' ('.$lang_prof_reg['Default'].')' : '').'</option>';

		foreach (array_unique($forum_date_formats) as $key => $date_format)
			$date_formats[] = "\t\t\t\t\t\t\t\t".'<option value="'.$key.'"'.(($user['date_format'] == $key) ? ' selected="selected"' : '').'>'.format_time(time(), true, $date_format, null, false, true).(($key == 0) ? ' ('.$lang_prof_reg['Default'].')' : '').'</option>';

		$languages = forum_list_langs();

		$language_options = array();
		if (count($languages) > 1) // Only display the language selection box if there's more than one language available
		{
			foreach ($languages as $temp)
				$language_options[] = "\t\t\t\t\t\t\t\t".'<option value="'.$temp.'" '.(($user['language'] == $temp) ? ' selected="selected"' : '').'>'.$temp.'</option>'."\n";
				
			$language_tpl = '<label>'.$lang_prof_reg['Language']."\n\t\t\t\t\t\t\t".'<br /><select name="language">'."\n\t\t\t\t\t\t\t".implode('', $language_options).'</select>'."\n\t\t\t\t\t\t\t".'<br /></label>';
		}
		else
			$language_tpl = '';
		
		if (($panther_user['is_admin'] || ($panther_user['is_admmod'] && $panther_user['g_mod_warn_users'] == '1')) && $panther_config['o_warnings'] == '1')
			$warning_level = "\t\t\t\t\t\t\t".'<p>'.$warning_level.' - <a href="'.panther_link($panther_url['warning_view'], array($id)).'">'.$lang_warnings['Show all warnings'].'</a> - <a href="'.panther_link($panther_url['warn_user'], array($id)).'">'.$lang_warnings['Warn user'].'</a></p>';
		else if (($panther_config['o_warning_status'] == '0' || $panther_user['is_admmod'] || ($panther_config['o_warning_status'] == '1' && $has_active)) && $panther_config['o_warnings'] == '1')
			$warning_level = "\t\t\t\t\t\t\t".'<p>'.$warning_level.' - <a href="'.panther_link($panther_url['warning_view'], array($id)).'">'.$lang_warnings['Show all warnings'].'</a></p>';
		else
			$warning_level = '';

		$profile_tpl = panther_template('profile_essentials.tpl');
		$search = array(
			'{profile_head}' => panther_htmlspecialchars($user['username']).' - '.$lang_profile['Section essentials'],
			'{form_action}' => panther_link($panther_url['profile_essentials'], array($id)),
			'{username_legend}' => $lang_profile['Username and pass legend'],
			'{csrf_token}' => generate_csrf_token(),
			'{username_field}' => $username_field.(($panther_user['id'] == $id || $panther_user['is_admin'] || ($user['g_moderator'] == '0' && $panther_user['g_mod_change_passwords'] == '1')) ? "\n\t\t\t\t\t\t\t".'<p class="actions"><span><a href="'.panther_link($panther_url['change_password'], array($id)).'">'.$lang_profile['Change pass'].'</a></span></p>' : ''),
			'{email_legend}' => $lang_prof_reg['Email legend'],
			'{email_field}' => $email_field,
			'{localisation_legend}' => $lang_prof_reg['Localisation legend'],
			'{timezone_info}' => $lang_prof_reg['Time zone info'],
			'{timezone}' => $lang_prof_reg['Time zone'],
			'{timezone_-12_select}' => ($user['timezone'] == -12) ? ' selected="selected"' : '',
			'{timezone_-11_select}' => ($user['timezone'] == -11) ? ' selected="selected"' : '',
			'{timezone_-10_select}' => ($user['timezone'] == -10) ? ' selected="selected"' : '',
			'{timezone_-9.5_select}' => ($user['timezone'] == -9.5) ? ' selected="selected"' : '',
			'{timezone_-9_select}' => ($user['timezone'] == -9) ? ' selected="selected"' : '',
			'{timezone_-8.5_select}' => ($user['timezone'] == -8.5) ? ' selected="selected"' : '',
			'{timezone_-8_select}' => ($user['timezone'] == -8) ? ' selected="selected"' : '',
			'{timezone_-7_select}' => ($user['timezone'] == -7) ? ' selected="selected"' : '',
			'{timezone_-6_select}' => ($user['timezone'] == -6) ? ' selected="selected"' : '',
			'{timezone_-5_select}' => ($user['timezone'] == -5) ? ' selected="selected"' : '',
			'{timezone_-4_select}' => ($user['timezone'] == -4) ? ' selected="selected"' : '',
			'{timezone_-3.5_select}' => ($user['timezone'] == -3.5) ? ' selected="selected"' : '',
			'{timezone_-3_select}' => ($user['timezone'] == -3) ? ' selected="selected"' : '',
			'{timezone_-2_select}' => ($user['timezone'] == -2) ? ' selected="selected"' : '',
			'{timezone_-1_select}' => ($user['timezone'] == -1) ? ' selected="selected"' : '',
			'{timezone_0_select}' => ($user['timezone'] == 0) ? ' selected="selected"' : '',
			'{timezone_1_select}' => ($user['timezone'] == 1) ? ' selected="selected"' : '',
			'{timezone_2_select}' => ($user['timezone'] == 2) ? ' selected="selected"' : '',
			'{timezone_3_select}' => ($user['timezone'] == 3) ? ' selected="selected"' : '',
			'{timezone_3.5_select}' => ($user['timezone'] == 3.5) ? ' selected="selected"' : '',
			'{timezone_4_select}' => ($user['timezone'] == 4) ? ' selected="selected"' : '',
			'{timezone_4.5_select}' => ($user['timezone'] == 4.5) ? ' selected="selected"' : '',
			'{timezone_5_select}' => ($user['timezone'] == 5) ? ' selected="selected"' : '',
			'{timezone_5.5_select}' => ($user['timezone'] == 5.5) ? ' selected="selected"' : '',
			'{timezone_5.75_select}' => ($user['timezone'] == 5.75) ? ' selected="selected"' : '',
			'{timezone_6_select}' => ($user['timezone'] == 6) ? ' selected="selected"' : '',
			'{timezone_6.5_select}' => ($user['timezone'] == 6.5) ? ' selected="selected"' : '',
			'{timezone_7_select}' => ($user['timezone'] == 7) ? ' selected="selected"' : '',
			'{timezone_8_select}' => ($user['timezone'] == 8) ? ' selected="selected"' : '',
			'{timezone_8.75_select}' => ($user['timezone'] == 8.75) ? ' selected="selected"' : '',
			'{timezone_9_select}' => ($user['timezone'] == 9) ? ' selected="selected"' : '',
			'{timezone_9.5_select}' => ($user['timezone'] == 9.5) ? ' selected="selected"' : '',
			'{timezone_10_select}' => ($user['timezone'] == 10) ? ' selected="selected"' : '',
			'{timezone_10.5_select}' => ($user['timezone'] == 10.5) ? ' selected="selected"' : '',
			'{timezone_11_select}' => ($user['timezone'] == 11) ? ' selected="selected"' : '',
			'{timezone_11.5_select}' => ($user['timezone'] == 11.5) ? ' selected="selected"' : '',
			'{timezone_12_select}' => ($user['timezone'] == 12) ? ' selected="selected"' : '',
			'{timezone_12.75_select}' => ($user['timezone'] == 12.75) ? ' selected="selected"' : '',
			'{timezone_13_select}' => ($user['timezone'] == 13) ? ' selected="selected"' : '',
			'{timezone_14_select}' => ($user['timezone'] == 14) ? ' selected="selected"' : '',
			'{utc_-12}' => $lang_prof_reg['UTC-12:00'],
			'{utc_-11}' => $lang_prof_reg['UTC-11:00'],
			'{utc_-10}' => $lang_prof_reg['UTC-10:00'],
			'{utc_-9.5}' => $lang_prof_reg['UTC-09:30'],
			'{utc_-9}' => $lang_prof_reg['UTC-09:00'],
			'{utc_-8.5}' => $lang_prof_reg['UTC-08:30'],
			'{utc_-8}' => $lang_prof_reg['UTC-08:00'],
			'{utc_-7}' => $lang_prof_reg['UTC-07:00'],
			'{utc_-6}' => $lang_prof_reg['UTC-06:00'],
			'{utc_-5}' => $lang_prof_reg['UTC-05:00'],
			'{utc_-4}' => $lang_prof_reg['UTC-04:00'],
			'{utc_-3.5}' => $lang_prof_reg['UTC-03:30'],
			'{utc_-3}' => $lang_prof_reg['UTC-03:00'],
			'{utc_-2}' => $lang_prof_reg['UTC-02:00'],
			'{utc_-1}' => $lang_prof_reg['UTC-01:00'],
			'{utc_0}' => $lang_prof_reg['UTC'],
			'{utc_1}' => $lang_prof_reg['UTC+01:00'],
			'{utc_2}' => $lang_prof_reg['UTC+02:00'],
			'{utc_3}' => $lang_prof_reg['UTC+03:00'],
			'{utc_3.5}' => $lang_prof_reg['UTC+03:30'],
			'{utc_4}' => $lang_prof_reg['UTC+04:00'],
			'{utc_4.5}' => $lang_prof_reg['UTC+04:30'],
			'{utc_5}' => $lang_prof_reg['UTC+05:00'],
			'{utc_5.5}' => $lang_prof_reg['UTC+05:30'],
			'{utc_5.75}' => $lang_prof_reg['UTC+05:45'],
			'{utc_6}' => $lang_prof_reg['UTC+06:00'],
			'{utc_6.5}' => $lang_prof_reg['UTC+06:30'],
			'{utc_7}' => $lang_prof_reg['UTC+07:00'],
			'{utc_8}' => $lang_prof_reg['UTC+08:00'],
			'{utc_8.75}' => $lang_prof_reg['UTC+08:45'],
			'{utc_9}' => $lang_prof_reg['UTC+09:00'],
			'{utc_9.5}' => $lang_prof_reg['UTC+09:30'],
			'{utc_10}' => $lang_prof_reg['UTC+10:00'],
			'{utc_10.5}' => $lang_prof_reg['UTC+10:30'],
			'{utc_11}' => $lang_prof_reg['UTC+11:00'],
			'{utc_11.5}' => $lang_prof_reg['UTC+11:30'],
			'{utc_12}' => $lang_prof_reg['UTC+12:00'],
			'{utc_12.75}' => $lang_prof_reg['UTC+12:45'],
			'{utc_13}' => $lang_prof_reg['UTC+13:00'],
			'{utc_14}' => $lang_prof_reg['UTC+14:00'],
			'{dst_checked}' => ($user['dst'] == '1') ? ' checked="checked"' : '',
			'{dst}' => $lang_prof_reg['DST'],
			'{time_format}' => $lang_prof_reg['Time format'],
			'{forum_time_formats}' => implode("\n", $time_formats),
			'{date_format}' => $lang_prof_reg['Date format'],
			'{forum_date_formats}' =>  implode("\n", $date_formats),
			'{languages}' => $language_tpl,
			'{user_activity}' => $lang_profile['User activity'],
			'{registered_info}' => sprintf($lang_profile['Registered info'], format_time($user['registered'], true).(($panther_user['is_admmod']) ? ' (<a href="'.panther_link($panther_url['get_host'], array(panther_htmlspecialchars($user['registration_ip']))).'">'.panther_htmlspecialchars($user['registration_ip']).'</a>)' : '')),
			'{last_post_info}' => sprintf($lang_profile['Last post info'], $last_post),
			'{last_visit_info}' => sprintf($lang_profile['Last visit info'], format_time($user['last_visit'])),
			'{posts_field}' => $posts_field,
			'{warning_level}' => $warning_level,
			'{admin_note}' => ($panther_user['is_admmod']) ? '<label>'.$lang_profile['Admin note'].'<br />'."\n".'<input id="admin_note" type="text" name="admin_note" value="'.panther_htmlspecialchars($user['admin_note']).'" size="30" maxlength="30" /><br /></label>' : '',
			'{submit}' => $lang_common['Submit'],
			'{instructions}' => $lang_profile['Instructions'],
		);

		echo str_replace(array_keys($search), array_values($search), $profile_tpl);
	}
	else if ($section == 'personal')
	{
		$title_field = ($panther_user['g_set_title'] == '1') ? "\n\t\t\t\t\t\t\t".'<label>'.$lang_common['Title'].' <em>('.$lang_profile['Leave blank'].')</em><br /><input type="text" name="title" value="'.panther_htmlspecialchars($user['title']).'" size="30" maxlength="50" /><br /></label>'."\n" : '';

		$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_common['Profile'], $lang_profile['Section personal']);
		define('PANTHER_ACTIVE_PAGE', 'profile');
		require PANTHER_ROOT.'header.php';

		generate_profile_menu('personal');
		$profile_tpl = panther_template('profile_personal.tpl');
		$search = array(
			'{username_section}' => panther_htmlspecialchars($user['username']).' - '.$lang_profile['Section personal'],
			'{form_action}' => panther_link($panther_url['profile_personal'], array($id)),
			'{details_legend}' => $lang_profile['Personal details legend'],
			'{csrf_token}' => generate_csrf_token(),
			'{realname}' => $lang_profile['Realname'],
			'{realname_value}' => panther_htmlspecialchars($user['realname']),
			'{title_field}' => $title_field,
			'{location}' => $lang_profile['Location'],
			'{location_value}' => panther_htmlspecialchars($user['location']),
			'{link_field}' => ($panther_user['g_post_links'] == '1' || $panther_user['is_admin']) ? "\n\t\t\t\t\t\t\t".'<label>'.$lang_profile['Website'].'<br /><input type="text" name="form[url]" value="'.panther_htmlspecialchars($user['url']).'" size="50" maxlength="80" /><br /></label>' : '',
			'{submit}' => $lang_common['Submit'],
			'{instructions}' => $lang_profile['Instructions'],
		);

		echo str_replace(array_keys($search), array_values($search), $profile_tpl);
	}
	else if ($section == 'messaging')
	{
		$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_common['Profile'], $lang_profile['Section messaging']);
		define('PANTHER_ACTIVE_PAGE', 'profile');
		require PANTHER_ROOT.'header.php';

		generate_profile_menu('messaging');
		$profile_tpl = panther_template('profile_messaging.tpl');
		$search = array(
			'{username_messaging}' => panther_htmlspecialchars($user['username']).' - '.$lang_profile['Section messaging'],
			'{form_action}' => panther_link($panther_url['profile_messaging'], array($id)),
			'{contact_legend}' => $lang_profile['Contact details legend'],
			'{csrf_token}' => generate_csrf_token(),
			'{facebook}' => $lang_profile['Facebook'],
			'{facebook_value}' => panther_htmlspecialchars($user['facebook']),
			'{steam}' => $lang_profile['Steam'],
			'{steam_value}' => panther_htmlspecialchars($user['steam']),
			'{msn}' => $lang_profile['MSN'],
			'{msn_value}' => panther_htmlspecialchars($user['msn']),
			'{twitter}' => $lang_profile['Twitter'],
			'{twitter_value}' => panther_htmlspecialchars($user['twitter']),
			'{google}' => $lang_profile['Google'],
			'{google_value}' => panther_htmlspecialchars($user['google']),
			'{submit}' => $lang_common['Submit'],
			'{instructions}' => $lang_profile['Instructions'],
		);

		echo str_replace(array_keys($search), array_values($search), $profile_tpl);
	}
	else if ($section == 'personality')
	{
		if ($panther_config['o_avatars'] == '0' && $panther_config['o_signatures'] == '0')
			message($lang_common['Bad request'], false, '404 Not Found');

		if ($panther_config['o_avatar_upload'] == '1')
			$avatar_field = '<span><a href="'.panther_link($panther_url['upload_avatar'], array($id, generate_csrf_token())).'">'.$lang_profile['Change avatar'].'</a></span>';
		else
			$avatar_field = '';

		$user_avatar = generate_avatar_markup($id, $user['email'], $user['use_gravatar']);
		if (stristr($user_avatar, '1.'.$panther_config['o_avatar']) === false && $user['use_gravatar'] == '0')
			$avatar_field .= ' <span><a href="'.panther_link($panther_url['delete_avatar'], array($id, generate_csrf_token())).'">'.$lang_profile['Delete avatar'].'</a></span>';
		else
		{
			if ($panther_config['o_avatar_upload'] == '1')
				$avatar_field = '<span><a href="'.panther_link($panther_url['upload_avatar'], array($id, generate_csrf_token())).'">'.$lang_profile['Upload avatar'].'</a></span>';
		}

		$avatar_field .= '<span><a href="'.panther_link($panther_url['use_gravatar'], array($id, generate_csrf_token())).'">'.(($user['use_gravatar'] == '1') ? $lang_profile['Disable gravatar'] : $lang_profile['Use gravatar']).'</a></span>';

		if ($user['signature'] != '')
			$signature_preview = '<p>'.$lang_profile['Sig preview'].'</p>'."\n\t\t\t\t\t\t\t".'<div class="postsignature postmsg">'."\n\t\t\t\t\t\t\t\t".'<hr />'."\n\t\t\t\t\t\t\t\t".$parsed_signature."\n\t\t\t\t\t\t\t".'</div>'."\n";
		else
			$signature_preview = '<p>'.$lang_profile['No sig'].'</p>'."\n";

		$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_common['Profile'], $lang_profile['Section personality']);
		define('POSTING', 1);
		define('PANTHER_ACTIVE_PAGE', 'profile');
		require PANTHER_ROOT.'header.php';

		generate_profile_menu('personality');
		$profile_tpl = panther_template('profile_personality.tpl');
		
		if ($panther_config['o_avatars'] == '1')
		{
			$avatar_tpl = panther_template('profile_avatars.tpl');
			
			$search = array(
				'{avatar_legend}' => $lang_profile['Avatar legend'],
				'{avatar}' => ($user_avatar) ? "\n\t\t\t\t\t\t".'<div class="useravatar">'.$user_avatar.'</div>' : '',
				'{avatar_info}' => $lang_profile['Avatar info'],
				'{avatar_field}' => $avatar_field,
			);
			
			$avatar_tpl = "\n".str_replace(array_keys($search), array_values($search), $avatar_tpl);
		}
		else
			$avatar_tpl = '';
		
		if ($panther_config['o_signatures'] == '1')
		{
			$signatures_tpl = panther_template('profile_signatures.tpl');
			
			$search = array(
				'{signature_legend}' => $lang_profile['Signature legend'],
				'{signature_info}' => $lang_profile['Signature info'],
				'{signature_rules}' => sprintf($lang_profile['Sig max size'], forum_number_format($panther_config['p_sig_length']), $panther_config['p_sig_lines']),
				'{signature}' => panther_htmlspecialchars($user['signature']),
				'{bbcode_help}' => panther_link($panther_url['help'], array('bbcode')),
				'{bbcode}' => $lang_common['BBCode'],
				'{bbcode_onoff}' => ($panther_config['p_sig_bbcode'] == '1') ? $lang_common['on'] : $lang_common['off'],
				'{url_help}' => panther_link($panther_url['help'], array('url')),
				'{url}' => $lang_common['url tag'],
				'{url_onoff}' => ($panther_config['p_sig_bbcode'] == '1' && $panther_user['g_post_links'] == '1') ? $lang_common['on'] : $lang_common['off'],
				'{img_help}' => panther_link($panther_url['help'], array('img')),
				'{img}' => $lang_common['img tag'],
				'{img_onoff}' => ($panther_config['p_sig_bbcode'] == '1' && $panther_config['p_sig_img_tag'] == '1') ? $lang_common['on'] : $lang_common['off'],
				'{smilies_help}' => panther_link($panther_url['help'], array('smilies')),
				'{smilies}' => $lang_common['Smilies'],
				'{smilies_onoff}' => ($panther_config['o_smilies_sig'] == '1') ? $lang_common['on'] : $lang_common['off'],
				'{signature_preview}' => $signature_preview,
			);

			$signatures_tpl = "\n".str_replace(array_keys($search), array_values($search), $signatures_tpl);
		}
		else
			$signatures_tpl = '';

		$search = array(
			'{username_personality}' => panther_htmlspecialchars($user['username']).' - '.$lang_profile['Section personality'],
			'{form_action}' => panther_link($panther_url['profile_personality'], array($id)),
			'{csrf_token}' => generate_csrf_token(),
			'{avatars}' => $avatar_tpl,
			'{signatures}' => $signatures_tpl,
			'{submit}' => $lang_common['Submit'],
			'{instructions}' => $lang_profile['Instructions'],
		);

		echo str_replace(array_keys($search), array_values($search), $profile_tpl);
	}
	else if ($section == 'display')
	{
		$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_common['Profile'], $lang_profile['Section display']);
		define('PANTHER_ACTIVE_PAGE', 'profile');
		require PANTHER_ROOT.'header.php';

		generate_profile_menu('display');
		
		$styles = forum_list_styles();
		if (count($styles) > 1)
		{
			foreach ($styles as $temp)
				$options[] = "\t\t\t\t\t\t\t\t".'<option value="'.$temp.'"'.(($user['style'] == $temp) ? ' selected="selected"' : '').'>'.str_replace('_', ' ', $temp).'</option>';

			$style_tpl = panther_template('profile_styles.tpl');
			$search = array(
				'{style_legend}' => $lang_profile['Style legend'],
				'{styles}' => $lang_profile['Styles'],
				'{style_options}' => implode("\n", $options),
			);
			
			$style_tpl = str_replace(array_keys($search), array_values($search), $style_tpl);
		}
		else
			$style_tpl = "\t\t\t".'<div><input type="hidden" name="form[style]" value="'.$styles[0].'" /></div>';
		
		$checkboxes = array();
		if ($panther_config['o_smilies'] == '1' || $panther_config['o_smilies_sig'] == '1')
			$checkboxes[] = '<label><input type="checkbox" name="form[show_smilies]" value="1"'.(($user['show_smilies'] == '1') ? ' checked="checked"' : '').' />'.$lang_profile['Show smilies'].'<br /></label>';

		if ($panther_config['o_signatures'] == '1')
			$checkboxes[] = '<label><input type="checkbox" name="form[show_sig]" value="1"'.(($user['show_sig'] == '1') ? ' checked="checked"' : '').' />'.$lang_profile['Show sigs'].'<br /></label>';

		if ($panther_config['o_avatars'] == '1')
			$checkboxes[] = '<label><input type="checkbox" name="form[show_avatars]" value="1"'.(($user['show_avatars'] == '1') ? ' checked="checked"' : '').' />'.$lang_profile['Show avatars'].'<br /></label>';

		if ($panther_config['p_message_bbcode'] == '1' && $panther_config['p_message_img_tag'] == '1')
			$checkboxes[] = '<label><input type="checkbox" name="form[show_img]" value="1"'.(($user['show_img'] == '1') ? ' checked="checked"' : '').' />'.$lang_profile['Show images'].'<br /></label>';

		if ($panther_config['o_signatures'] == '1' && $panther_config['p_sig_bbcode'] == '1' && $panther_config['p_sig_img_tag'] == '1')
			$checkboxes[] = '<label><input type="checkbox" name="form[show_img_sig]" value="1"'.(($user['show_img_sig'] == '1') ? ' checked="checked"' : '').' />'.$lang_profile['Show images sigs'].'<br /></label>';

		$checkboxes[] = '<label><input type="checkbox" name="form[use_editor]" value="1"'.(($user['use_editor'] == '1') ? ' checked="checked"' : '').' />'.$lang_profile['Use editor'].'<br /></label>';

		if ($panther_config['o_reputation'] == '1')
		{
			switch(true)
			{
				case $user['reputation'] > '0':
					$type = 'positive';
				break;
				case $user['reputation'] < '0':
					$type = 'negative';
				break;
				default:
					$type = 'zero';
				break;
			}

			$user_reputation = '<span class="reputation '.$type.'">'.$lang_profile['Reputation'].': '.$user['reputation'].'</span><br /><br />';
			$rep_tpl = panther_template('profile_rep.tpl');
			
			$search = array(
				'{reputation}' => $lang_profile['Reputation'],
				'{user_reputation}' => $user_reputation,
				'{received_link}' => panther_link($panther_url['profile_rep_received'], array($id)),
				'{given_link}' => panther_link($panther_url['profile_rep_given'], array($id)),
				'{rep_received}' => $lang_profile['Rep_received'],
				'{rep_given}' => $lang_profile['Rep_given'],
			);
			
			$rep_tpl = str_replace(array_keys($search), array_values($search), $rep_tpl);
		}
		else
			$rep_tpl = '';
	
		$profile_tpl = panther_template('profile_display.tpl');
		$search = array(
			'{section_display}' => panther_htmlspecialchars($user['username']).' - '.$lang_profile['Section display'],
			'{form_action}' => panther_link($panther_url['profile_display'], array($id)),
			'{csrf_token}' => generate_csrf_token(),
			'{styles}' => $style_tpl,
			'{post_display}' => $lang_profile['Post display legend'],
			'{post_display_info}' => $lang_profile['Post display info'],
			'{checkboxes}' => count($checkboxes) ? implode("\t\t\t\t\t\t\t\t\n", $checkboxes) : '',
			'{pagination_legend}' => $lang_profile['Pagination legend'],
			'{topics_per_page}' => $lang_profile['Topics per page'],
			'{posts_per_page}' => $lang_profile['Posts per page'],
			'{disp_topics}' => $user['disp_topics'],
			'{disp_posts}' => $user['disp_posts'],
			'{paginate_info}' => $lang_profile['Paginate info'],
			'{leave_blank}' => $lang_profile['Leave blank'],
			'{reputation}' => $rep_tpl,
			'{submit}' => $lang_common['Submit'],
			'{instructions}' => $lang_profile['Instructions'],
		);

		echo str_replace(array_keys($search), array_values($search), $profile_tpl);
	}
	elseif ($section == 'rep_received' || $section == 'rep_given')
	{
		if ($panther_config['o_reputation'] == '0')
			message($lang_common['Bad request']);

		define('REPUTATION', 1);
		$page = (!isset($_GET['p']) || $_GET['p'] <= '1') ? '1' : intval($_GET['p']);
		$data = array(
			':id'	=>	$id,
		);

		if ($section == 'rep_received')
			$sql = "SELECT COUNT(r.id) FROM ".$db->prefix."reputation AS r LEFT JOIN ".$db->prefix."posts AS p ON r.post_id=p.id WHERE p.poster_id=:id";
		else
			$sql = "SELECT COUNT(id) FROM ".$db->prefix."reputation WHERE given_by=:id";

		$ps = $db->run($sql, $data);
		$total = $ps->fetchColumn();

		//What page are we on?
		$num_pages = ceil($total/$panther_config['o_disp_topics_default']);
		if ($page > $num_pages) $page = 1;
		$start_from = intval($panther_config['o_disp_topics_default'])*($page-1);
		$limit = $start_from.','.$panther_config['o_disp_topics_default'];

		switch ($section)
		{
			case 'rep_received':
				$data[':id1'] = $id;
			
				$sql = "SELECT r.id, r.given_by, u.group_id, u.username, r.time_given, r.post_id, r.vote, p.topic_id, t.subject, :id1 AS given_to FROM ".$db->prefix."reputation AS r LEFT JOIN ".$db->prefix."users AS u ON u.id = r.given_by LEFT JOIN ".$db->prefix."posts AS p ON p.id = r.post_id LEFT JOIN ".$db->prefix."topics AS t ON t.id = p.topic_id WHERE p.poster_id=:id ORDER BY r.id DESC LIMIT ".$limit;
				$ps = $db->run($sql, $data);
				
				if (!$ps->rowCount())
					message($lang_profile['No received reputation']);
			break;
			default:
				$sql = "SELECT r.id, p.poster_id AS given_to, u.group_id, r.given_by, r.time_given, r.post_id, r.vote, u.username, p.topic_id, t.subject FROM ".$db->prefix."reputation AS r LEFT JOIN ".$db->prefix."posts AS p ON p.id = r.post_id LEFT JOIN ".$db->prefix."users AS u ON u.id = p.poster_id LEFT JOIN ".$db->prefix."topics AS t ON t.id = p.topic_id WHERE r.given_by=:id ORDER BY r.id DESC LIMIT ".$limit;
				$ps = $db->run($sql, $data); 
				
				if (!$ps->rowCount())
					message($lang_profile['No given reputation']);
			break;
		}

		define('PANTHER_ACTIVE_PAGE', 'profile');
		$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_common['Profile'], panther_htmlspecialchars($user['username']), $lang_profile['Reputation']);
		require PANTHER_ROOT.'header.php';
		$rep_count = '0';

		$rep_row_tpl = array();
		foreach ($ps as $reputation)
		{
			$rep_row_tpl[$reputation['id']] = panther_template('rep_row.tpl');
			if ($reputation['username'] == '')
			{
				$reputation['username'] = $lang_profile['Deleted user'];
				$reputation['group_id'] = PANTHER_GUEST;
			}

			if ($reputation['given_by'] == '')
				$reputation['given_by'] = PANTHER_GUEST;
				
			if ($reputation['given_to'] == '')
				$reputation['given_to'] = PANTHER_GUEST;

			if ($reputation['subject'] == '')
				$subject = $lang_profile['Deleted post'];
			else
				$subject = '<a href="'.panther_link($panther_url['post'], array($reputation['post_id'])).'">'.panther_htmlspecialchars($reputation['subject']).'</a>';

			if ($panther_user['g_view_users'] == '0')
				$profile_link = colourize_group($reputation['username'], $reputation['group_id']);
			else
			{
				if ($section == 'rep_received')
						$profile_link = colourize_group($reputation['username'], $reputation['group_id'], $reputation['given_by']);
				else
						$profile_link = colourize_group($reputation['username'], $reputation['group_id'], $reputation['given_to']);
			}
			
			$search = array(
				'{rep_count}' => ($rep_count % 2 == 0) ? 'roweven' : 'rowodd',
				'{image_url}' => $panther_config['o_image_dir'].(($reputation['vote'] == '1') ? 'plus' : 'minus'),
				'{rep_type}' => (($reputation['vote'] == '1') ? $lang_profile['Positive'] : $lang_profile['Negative']),
				'{profile_link}' => $profile_link,
				'{rep_given}' => format_time($reputation['time_given']),
				'{subject}' => $subject,
				'{remove}' => ($panther_user['is_admmod'] && ($panther_user['g_mod_edit_users'] == '1' || $panther_user['is_admin'])) ? "\n\t\t\t\t\t".'<td class="tc3"><a href="javascript:remove_reputation('.$reputation['id'].', '.$id.', '.$page.', \''.$section.'\');">'.$lang_profile['Remove reputation'].'</a></td>' : '',
			);
			
			$rep_row_tpl[$reputation['id']] = str_replace(array_keys($search), array_values($search), $rep_row_tpl[$reputation['id']]);
		}
		
		$profile_tpl = panther_template('profile_reputation.tpl');
		$search = array(
			'{index_link}' => panther_link($panther_url['index']),
			'{index}' => $lang_common['Index'],
			'{profile_link}' => panther_link($panther_url['profile'], array($id)),
			'{profile}' => sprintf($lang_profile['User rep link'], panther_htmlspecialchars($user['username'])),
			'{rep_section}' => $lang_profile[ucfirst($section)],
			'{pagination}' => $lang_common['Pages'].' '.paginate($num_pages, $page, $panther_url['profile_'.strtolower($section)], array($id)),
			'{rep_type}' => $lang_profile['Rep type'],
			'{rep_given}' => (($section == 'rep_received') ? $lang_profile['Given by'] : $lang_profile['Given to']),
			'{date}' => $lang_profile['Date rep given'],
			'{post}' => $lang_profile['Rep post topic'],
			'{remove_header}' => ($panther_user['is_admmod'] && ($panther_user['g_mod_edit_users'] == '1' || $panther_user['is_admin'])) ? "\n\t\t\t\t\t".'<th class="tc3" scope="col">'.$lang_profile['Remove reputation'].'</th>' : '',
			'{reputation_rows}' => count($rep_row_tpl) ? implode("\n", $rep_row_tpl) : '',
		);
		
		echo str_replace(array_keys($search), array_values($search), $profile_tpl);
	}
	else if ($section == 'privacy')
	{
		$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_common['Profile'], $lang_profile['Section privacy']);
		define('PANTHER_ACTIVE_PAGE', 'profile');
		require PANTHER_ROOT.'header.php';

		generate_profile_menu('privacy');
		
		if ($panther_config['o_forum_subscriptions'] == '1' || $panther_config['o_topic_subscriptions'] == '1')
		{
			$subscription_tpl = "\n".panther_template('profile_subscriptions.tpl');
			$search = array(
				'{subscription_legend}' => $lang_profile['Subscription legend'],
				'{notify_with_post}' => ($user['notify_with_post'] == '1') ? ' checked="checked"' : '',
				'{notify_full}' => $lang_profile['Notify full'],
				'{auto_notify}' => ($panther_config['o_topic_subscriptions'] == '1') ? "\n\t\t\t\t\t\t\t\t".'<label><input type="checkbox" name="form[auto_notify]" value="1"'.(($user['auto_notify'] == '1') ? ' checked="checked"' : '').' />'.$lang_profile['Auto notify full'].'<br /></label>' : '',
			);
			
			$subscription_tpl = str_replace(array_keys($search), array_values($search), $subscription_tpl);
		}
		else
			$subscription_tpl = '';
		
		if ($panther_config['o_private_messaging'] == '1' && $user['g_use_pm'] == '1')
		{
			$pm_tpl = "\n".panther_template('profile_pm.tpl');
			$search = array(
				'{private_messaging}' => $lang_profile['Private messaging'],
				'{csrf_token}' => generate_csrf_token(),
				'{pm_enabled_checked}' => ($user['pm_enabled'] == '1') ? ' checked="checked"' : '',
				'{pm_enabled}' => $lang_profile['PM enabled'],
				'{pm_notify_checked}' => ($user['pm_notify'] == '1') ? ' checked="checked"' : '',
				'{pm_notify}' => $lang_profile['PM notify'],
			);
			
			$pm_tpl = str_replace(array_keys($search), array_values($search), $pm_tpl);
		}
		else
			$pm_tpl = '';
		
		$profile_tpl = panther_template('profile_privacy.tpl');
		$search = array(
			'{user_privacy}' => panther_htmlspecialchars($user['username']).' - '.$lang_profile['Section privacy'],
			'{form_action}' => panther_link($panther_url['profile_privacy'], array($id)),
			'{privacy_legend}' => $lang_prof_reg['Privacy options legend'],
			'{csrf_token}' => generate_csrf_token(),
			'{email_setting}' => $lang_prof_reg['Email setting info'],
			'{email_setting_0}' => ($user['email_setting'] == '0') ? ' checked="checked"' : '',
			'{email_setting_1}' => ($user['email_setting'] == '1') ? ' checked="checked"' : '',
			'{email_setting_2}' => ($user['email_setting'] == '2') ? ' checked="checked"' : '',
			'{setting_1}' => $lang_prof_reg['Email setting 1'],
			'{setting_2}' => $lang_prof_reg['Email setting 2'],
			'{setting_3}' => $lang_prof_reg['Email setting 3'],
			'{subscriptions}' => $subscription_tpl,
			'{private_messaging}' => $pm_tpl,
			'{submit}' => $lang_common['Submit'],
			'{instructions}' => $lang_profile['Instructions'],
		);
		
		echo str_replace(array_keys($search), array_values($search), $profile_tpl);
	}
	else if ($section == 'admin')
	{
		if (!$panther_user['is_admmod'] || ($panther_user['g_moderator'] == '1' && $panther_user['g_mod_ban_users'] == '0'))
			message($lang_common['Bad request'], false, '403 Forbidden');

		$posting_ban = format_posting_ban_expiration(($user['posting_ban'] - time()), $lang_profile);
		$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_common['Profile'], $lang_profile['Section admin']);

		flux_hook('profile_admin_before_header');

		define('PANTHER_ACTIVE_PAGE', 'profile');
		require PANTHER_ROOT.'header.php';

		generate_profile_menu('admin');
		
		// If we're staff, we can't have a posting ban
		if ($user['g_moderator'] == '0' && $user['g_id'] != PANTHER_ADMIN && $user['g_admin'] == '0' && ($panther_user['is_admin'] == '1'))
		{
			$ban_tpl = "\n".panther_template('profile_posting_ban.tpl');
			$search = array(
				'{restrictions}' => $lang_profile['restrictions'],
				'{posting_ban_label}' => $lang_profile['Posting ban'].(($posting_ban[2] != $lang_profile['Never']) ? sprintf($lang_profile['current ban'], format_time($user['posting_ban'])) : ''),
				'{del_ban}' => $lang_profile['posting ban delete'],
				'{ban_value}' => $posting_ban[0],
				'{ban_minutes_selected}' => ($posting_ban[2] == $lang_profile['Minutes']) ? ' selected="selected"' : '',
				'{ban_hours_selected}' => ($posting_ban[2] == $lang_profile['Hours']) ? ' selected="selected"' : '',
				'{ban_days_selected}' => ($posting_ban[2] == $lang_profile['Days'] || $posting_ban[2] == $lang_profile['Never']) ? ' selected="selected"' : '',
				'{ban_months_selected}' => ($posting_ban[2] == $lang_profile['Months']) ? ' selected="selected"' : '',
				'{minutes}' => $lang_profile['Minutes'],
				'{hours}' => $lang_profile['Hours'],
				'{days}' => $lang_profile['Days'],
				'{months}' => $lang_profile['Months'],
				'{submit}' => $lang_profile['Save'],
			);

			$ban_tpl = str_replace(array_keys($search), array_values($search), $ban_tpl);
		}
		else
			$ban_tpl = '';
		
		// If we're just a moderator
		if ($panther_user['g_moderator'] == '1' && $panther_user['g_admin'] == '0' && $user['g_id'] != PANTHER_ADMIN)
		{
			$del_tpl = panther_template('profile_ban.tpl');
			$search = array(
				'{del_ban_legend}' => $lang_profile['Delete ban legend'],
				'{ban_user}' => $lang_profile['Ban user'],
			);
			
			$del_tpl = str_replace(array_keys($search), array_values($search), $del_tpl);
		}
		else // We're an admin, check the permissions
		{
			$del_tpl = '';
			if (file_exists(FORUM_CACHE_DIR.'cache_restrictions.php'))
				require FORUM_CACHE_DIR.'cache_restrictions.php';
			else
			{
				if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
					require PANTHER_ROOT.'include/cache.php';

				generate_admin_restrictions_cache();
				require FORUM_CACHE_DIR.'cache_restrictions.php';
			}

			if (!isset($admins[$panther_user['id']]) || $panther_user['id'] == '2')
				$admins[$panther_user['id']] = array('admin_users' => '1');
			
			if ($panther_user['id'] != $id && $admins[$panther_user['id']]['admin_users'] == '1')
			{
				$group_tpl = panther_template('profile_groups.tpl');
				$options = array();
				foreach ($panther_groups as $cur_group)
					if ($cur_group['g_id'] != PANTHER_GUEST)
						$options[] = "\t\t\t\t\t\t\t\t".'<option value="'.$cur_group['g_id'].'"'.(($cur_group['g_id'] == $user['g_id'] || ($cur_group['g_id'] == $panther_config['o_default_user_group'] && $user['g_id'] == '') ? ' selected="selected"' : '')).'>'.panther_htmlspecialchars($cur_group['g_title']).'</option>';
			
				$search = array(
					'{group_membership}' => $lang_profile['Group membership legend'],
					'{group_options}' => count($options) ? implode("\n", $options) : '',
					'{submit}' => $lang_profile['Save'],
				);

				$del_tpl .= "\n".str_replace(array_keys($search), array_values($search), $group_tpl);
			}
			
			$admin_tpl = panther_template('profile_admin_delban.tpl');
			$search = array(
				'{del_ban_legend}' => $lang_profile['Delete ban legend'],
				'{del_button}' => ($admins[$panther_user['id']]['admin_users'] == '1') ? '<input type="submit" name="delete_user" value="'.$lang_profile['Delete user'].'" /> ' : '',
				'{ban_user}' => $lang_profile['Ban user'],
			);

			$del_tpl .= "\n".str_replace(array_keys($search), array_values($search), $admin_tpl);
			if ($user['g_moderator'] == '1' || $user['g_id'] == PANTHER_ADMIN)
			{
				$forum_tpl = panther_template('profile_forums.tpl');

				$cur_category = 0;
				$category_tpl = $forums = array();
				$ps = $db->run('SELECT c.id AS cid, c.cat_name, f.id AS fid, f.forum_name, f.moderators FROM '.$db->prefix.'categories AS c INNER JOIN '.$db->prefix.'forums AS f ON c.id=f.cat_id WHERE f.redirect_url IS NULL ORDER BY c.disp_position, c.id, f.disp_position');
				foreach ($ps as $cur_forum)
				{
					// Grab the forum template
					$category_tpl[$cur_forum['cid']]['forums'][$cur_forum['fid']] = panther_template('profile_forum.tpl');

					if ($cur_forum['cid'] != $cur_category) // A new category since last iteration?
					{
						// Grab the category template
						$category_tpl[$cur_forum['cid']]['template'] = panther_template('profile_category.tpl');
						if ($cur_category)
						{
							$search = array(
								'{category_forums}' => implode("\n", $category_tpl[$cur_category]['forums']),
							);

							$forums[] = str_replace(array_keys($search), array_values($search), $category_tpl[$cur_category]['template']);
						}
						
						$search = array(
							'{category_name}' => panther_htmlspecialchars($cur_forum['cat_name']),
						);

						// Replace everything bar '{category_forums}' from this categories' template
						$category_tpl[$cur_forum['cid']]['template'] = str_replace(array_keys($search), array_values($search), $category_tpl[$cur_forum['cid']]['template']);
						$cur_category = $cur_forum['cid'];
					}

					$moderators = ($cur_forum['moderators'] != '') ? unserialize($cur_forum['moderators']) : array();
					$search = array(
						'{forum_id}' => $cur_forum['fid'],
						'{forum_checked}' => ((in_array($id, $moderators)) ? ' checked="checked"' : ''),
						'{forum_name}' => panther_htmlspecialchars($cur_forum['forum_name']),
					);

					// Add this forum to its categories' template
					$category_tpl[$cur_forum['cid']]['forums'][$cur_forum['fid']] = str_replace(array_keys($search), array_values($search), $category_tpl[$cur_forum['cid']]['forums'][$cur_forum['fid']]);
				}

				if ($cur_category)
				{
					$search = array(
						'{category_forums}' => implode("\n", $category_tpl[$cur_category]['forums']),
					);

					$forums[] = str_replace(array_keys($search), array_values($search), $category_tpl[$cur_category]['template']);
				}
				$search = array(
					'{set_mod_legend}' => $lang_profile['Set mods legend'],
					'{moderator_info}' => $lang_profile['Moderator in info'],
					'{update_forums}' => $lang_profile['Update forums'] ,
					'{forums}' => count($forums) ? implode("\n", $forums) : '',
				);
				
				$del_tpl .= "\n".str_replace(array_keys($search), array_values($search), $forum_tpl);
			}
		}

		$profile_tpl = panther_template('profile_admin.tpl');
		$search = array(
			'{user_admin}' => panther_htmlspecialchars($user['username']).' - '.$lang_profile['Section admin'],
			'{form_action}' => panther_link($panther_url['profile_admin'], array($id)),
			'{csrf_token}' => generate_csrf_token(),
			'{posting_ban}' => $ban_tpl,
			'{admin_mod_template}' => $del_tpl,
			'{hook_admin_after_form}' => flux_hook('profile_admin_after_form'),
		);
		
		echo str_replace(array_keys($search), array_values($search), $profile_tpl);
	}
	else
		message($lang_common['Bad request'], false, '404 Not Found');

	require PANTHER_ROOT.'footer.php';
}