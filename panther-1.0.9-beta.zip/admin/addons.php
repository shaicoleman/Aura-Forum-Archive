<?php
/**
 * Copyright (C) 2015 Panther (https://www.pantherforum.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

// Tell header.php to use the admin template
define('PANTHER_ADMIN_CONSOLE', 1);

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/../');
	require PANTHER_ROOT.'include/common.php';
}

require PANTHER_ROOT.'include/common_admin.php';

if (!$panther_user['is_admin'])
	message($lang_common['No permission'], false, '403 Forbidden');

// Load the admin_addons.php language file
require PANTHER_ROOT.'lang/'.$admin_language.'/admin_addons.php';

check_authentication();

if ($panther_user['id'] != '2')
{
	if(!is_null($admins[$panther_user['id']]['admin_addons']))
	{
		if ($admins[$panther_user['id']]['admin_addons'] == '0')
			message($lang_common['No permission']);
	}
}

if (isset($_POST['delete_addon']))
{
	confirm_referrer(PANTHER_ADMIN_DIR.'/addons.php');
	$addons = isset($_POST['del_addons']) && is_array($_POST['del_addons']) ? array_map('panther_trim', $_POST['del_addons']) : array();

	if (empty($addons))
		message($lang_admin_addons['No addons']);

	foreach ($addons as $addon)
	{
		// Make sure it doesn't look suspicious
		if (file_exists(PANTHER_ROOT.PANTHER_ADMIN_DIR.'/extensions/'.$addon.'.php') && (preg_match('/^[a-z0-9-_]+$/i', $addon)) && !preg_match('/^[\/\.@[{}]!"£\|<>:]+$/i', $addon))
			unlink(PANTHER_ROOT.PANTHER_ADMIN_DIR.'/extensions/'.$addon.'.php');
	}

	redirect(panther_link($panther_url['admin_addons']), $lang_admin_addons['Addon removed redirect']);
}

if (isset($_POST['upload_addon']))
{
	confirm_referrer(PANTHER_ADMIN_DIR.'/addons.php');
	if (!isset($_FILES['req_file']))
		message($lang_admin_addons['No file']);
	
	$uploaded_file = $_FILES['req_file'];
	
	// Make sure the upload went smooth
	if (isset($uploaded_file['error']))
	{
		switch ($uploaded_file['error'])
		{
			case 1:	// UPLOAD_ERR_INI_SIZE
			case 2:	// UPLOAD_ERR_FORM_SIZE
				message($lang_admin_addons['Too large ini']);
			break;
			case 3:	// UPLOAD_ERR_PARTIAL
				message($lang_admin_addons['Partial upload']);
			break;
			case 4:	// UPLOAD_ERR_NO_FILE
				message($lang_admin_addons['No file']);
			break;
			case 6:	// UPLOAD_ERR_NO_TMP_DIR
				message($lang_admin_addons['No tmp directory']);
			break;
			default:
				// No error occured, but was something actually uploaded?
				if ($uploaded_file['size'] == 0)
					message($lang_admin_addons['No file']);
			break;
		}
	}
	
	if (is_uploaded_file($uploaded_file['tmp_name']))
	{
		$filename = panther_htmlspecialchars($uploaded_file['name']);
		if (!preg_match('/^[a-z0-9-_]+\.(php)$/i', $uploaded_file['name']))
			message($lang_admin_addons['Bad type']);
		
		// Make sure there is no file already under this name
		if (file_exists(PANTHER_ROOT.PANTHER_ADMIN_DIR.'/extensions/'.$filename))
			message(sprintf($lang_admin_addons['Addon exists'], panther_htmlspecialchars($filename)));
	
		// Move the file to the addons directory.
		if (!@move_uploaded_file($uploaded_file['tmp_name'], PANTHER_ROOT.PANTHER_ADMIN_DIR.'/extensions/'.$filename))
			message($lang_admin_addons['Move failed']);

		@chmod(PANTHER_ROOT.PANTHER_ADMIN_DIR.'/extensions/'.$filename, 0644);
	}
	else
		message($lang_admin_addons['Unknown failure']);
	
	redirect(panther_link($panther_url['admin_addons']), $lang_admin_addons['Successful Upload Addon']);
}

if (isset($_POST['delete_plugin']))
{
	confirm_referrer(PANTHER_ADMIN_DIR.'/addons.php');
	$plugins = isset($_POST['del_addons']) && is_array($_POST['del_addons']) ? array_map('panther_trim', $_POST['del_addons']) : array();

	if (empty($plugins))
		message($lang_admin_addons['No plugins']);

	foreach ($plugins as $plugin)
	{
		// Make sure it doesn't look suspicious
		if (file_exists(PANTHER_ROOT.PANTHER_ADMIN_DIR.'/plugins/'.$plugin.'.php') && (preg_match('/^[a-zA-Z0-9-_]+$/i', $plugin)) && !preg_match('/^[\/\.@[{}]!"£\|<>:]+$/i', $plugin))
			unlink(PANTHER_ROOT.PANTHER_ADMIN_DIR.'/plugins/'.$plugin.'.php');
	}

	redirect(panther_link($panther_url['admin_addons']), $lang_admin_addons['Plugin removed redirect']);
}

if (isset($_POST['upload_plugin']))
{
	confirm_referrer(PANTHER_ADMIN_DIR.'/addons.php');
	if (!isset($_FILES['req_file']))
		message($lang_admin_addons['No file']);
	
	$uploaded_file = $_FILES['req_file'];
	
	// Make sure the upload went smooth
	if (isset($uploaded_file['error']))
	{
		switch ($uploaded_file['error'])
		{
			case 1:	// UPLOAD_ERR_INI_SIZE
			case 2:	// UPLOAD_ERR_FORM_SIZE
				message($lang_admin_addons['Too large ini']);
			break;
			case 3:	// UPLOAD_ERR_PARTIAL
				message($lang_admin_addons['Partial upload']);
			break;
			case 4:	// UPLOAD_ERR_NO_FILE
				message($lang_admin_addons['No file']);
			break;
			case 6:	// UPLOAD_ERR_NO_TMP_DIR
				message($lang_admin_addons['No tmp directory']);
			break;
			default:
				// No error occured, but was something actually uploaded?
				if ($uploaded_file['size'] == 0)
					message($lang_admin_addons['No file']);
			break;
		}
	}
	
	if (is_uploaded_file($uploaded_file['tmp_name']))
	{
		$filename = panther_htmlspecialchars($uploaded_file['name']);
		if (!preg_match('/^[a-z0-9-_]+\.(php)$/i', $uploaded_file['name']))
			message($lang_admin_addons['Bad type']);
		
		if (!preg_match('%^AM?P_(\w*?)\.php$%i', $uploaded_file['name']))
			message($lang_admin_addons['Plugin not valid']);
		
		// Make sure there is no file already under this name
		if (file_exists(PANTHER_ROOT.PANTHER_ADMIN_DIR.'/plugins/'.$filename))
			message(sprintf($lang_admin_addons['Plugin exists'], panther_htmlspecialchars($filename)));

		// Move the file to the addons directory.
		if (!@move_uploaded_file($uploaded_file['tmp_name'], PANTHER_ROOT.PANTHER_ADMIN_DIR.'/plugins/'.$filename))
			message($lang_admin_addons['Move failed']);

		@chmod(PANTHER_ROOT.PANTHER_ADMIN_DIR.'/plugins/'.$filename, 0644);
	}
	else
		message($lang_admin_addons['Unknown failure']);
	
	redirect(panther_link($panther_url['admin_addons']), $lang_admin_addons['Successful Upload Plugin']);
}

$addon_row_tpl = $plugin_row_tpl = array();
$addon_tpl = panther_template('addon_row.tpl');

$files = array_diff(scandir(PANTHER_ROOT.PANTHER_ADMIN_DIR.'/extensions'), array('.', '..'));
foreach ($files as $entry)
{
	if (substr($entry, -4) == '.php')
	{
		$entry = panther_htmlspecialchars(substr($entry, 0, -4));
		$search = array(
			'{display_name}' => ucwords(str_replace('_', ' ', $entry)),
			'{addon_name}' => $entry,
		);

		$addon_row_tpl[] = str_replace(array_keys($search), array_values($search), $addon_tpl);
	}
}

$files = array_diff(scandir(PANTHER_ROOT.PANTHER_ADMIN_DIR.'/plugins'), array('.', '..'));
foreach ($files as $entry)
{
	if (substr($entry, -4) == '.php' && preg_match('%^AM?P_(\w*?)\.php$%i', $entry))
	{
		$entry = panther_htmlspecialchars(substr($entry, 0, -4));
		$search = array(
			'{display_name}' => ucwords(str_replace('_', ' ', $entry)),
			'{addon_name}' => $entry,
		);

		$plugin_row_tpl[] = str_replace(array_keys($search), array_values($search), $addon_tpl);
	}
}

$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_admin_common['Admin'], $lang_admin_common['Addons']);
define('PANTHER_ACTIVE_PAGE', 'admin');
require PANTHER_ROOT.'header.php';
generate_admin_menu('addons');

$admin_tpl = panther_template('admin_addons.tpl');
$search = array(
	'{current_addons}' => $lang_admin_addons['Current Addons'],
	'{form_action}' => panther_link($panther_url['admin_addons']),
	'{list_addons}' => $lang_admin_addons['List Addons'],
	'{addon_filename}' => $lang_admin_addons['Addon filename'],
	'{delete_addon}' => $lang_admin_addons['Delete'],
	'{addon_rows}' => implode("\n", $addon_row_tpl),
	'{delete_selected}' => $lang_admin_addons['Delete selected'],
	'{add_addon}' => $lang_admin_addons['Add Addon'],
	'{warning}' => $lang_admin_addons['Warning'],
	'{addon_warning}' => $lang_admin_addons['Addon upload warning'],
	'{upload}' => $lang_admin_addons['Upload'],
	'{csrf_token}' => generate_csrf_token(PANTHER_ADMIN_DIR.'/addons.php'),
	'{current_plugins}' => $lang_admin_addons['Current Plugins'],
	'{list_plugins}' => $lang_admin_addons['List Plugins'],
	'{plugin_rows}' => implode("\n", $plugin_row_tpl),
	'{plugin_filename}' => $lang_admin_addons['Plugin filename'],
	'{add_plugin}' => $lang_admin_addons['Add Plugin'],
	'{plugin_warning}' => $lang_admin_addons['Plugin upload warning'],
);

echo str_replace(array_keys($search), array_values($search), $admin_tpl);
require PANTHER_ROOT.'footer.php';