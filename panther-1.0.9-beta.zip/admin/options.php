<?php
/**
 * Copyright (C) 2015 Panther (https://www.pantherforum.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

// Tell header.php to use the admin template
define('PANTHER_ADMIN_CONSOLE', 1);

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/../');
	require PANTHER_ROOT.'include/common.php';
}
require PANTHER_ROOT.'include/common_admin.php';

if (!$panther_user['is_admin'])
	message($lang_common['No permission'], false, '403 Forbidden');

if ($panther_user['id'] != '2')
{
	if(!is_null($admins[$panther_user['id']]['admin_options']))
	{
		if ($admins[$panther_user['id']]['admin_options'] == '0')
			message($lang_common['No permission'], false, '403 Forbidden');
	}
}

check_authentication();

// Load the admin_options.php language file
require PANTHER_ROOT.'lang/'.$admin_language.'/admin_options.php';
$max_file_size = str_replace('M', '', @ini_get('upload_max_filesize')) * pow(1024,2);

if (isset($_POST['form_sent']))
{
	confirm_referrer(PANTHER_ADMIN_DIR.'/options.php');

	$form = array(
		'board_title'			=> panther_trim($_POST['form']['board_title']),
		'board_desc'			=> panther_trim($_POST['form']['board_desc']),
		'base_url'				=> panther_trim($_POST['form']['base_url']),
		'default_timezone'		=> floatval($_POST['form']['default_timezone']),
		'default_dst'			=> $_POST['form']['default_dst'] != '1' ? '0' : '1',
		'default_lang'			=> panther_trim($_POST['form']['default_lang']),
		'default_style'			=> panther_trim($_POST['form']['default_style']),
		'time_format'			=> panther_trim($_POST['form']['time_format']),
		'date_format'			=> panther_trim($_POST['form']['date_format']),
		'timeout_visit'			=> (intval($_POST['form']['timeout_visit']) > 0) ? intval($_POST['form']['timeout_visit']) : 1,
		'timeout_online'		=> (intval($_POST['form']['timeout_online']) > 0) ? intval($_POST['form']['timeout_online']) : 1,
		'redirect_delay'		=> (intval($_POST['form']['redirect_delay']) >= 0) ? intval($_POST['form']['redirect_delay']) : 0,
		'user_tags_max'			=> (intval($_POST['form']['user_tags_max']) > 0) ? intval($_POST['form']['user_tags_max']) : 5,
		'cookie_secure'			=> $_POST['form']['cookie_secure'] != '1' ? '0' : '1',
		'force_ssl'				=> $_POST['form']['force_ssl'] != '1' ? '0' : '1',
		'cookie_name'			=> panther_trim($_POST['form']['cookie_name']),
		'cookie_seed'			=> panther_trim($_POST['form']['cookie_seed']),
		'cookie_domain'			=> panther_trim($_POST['form']['cookie_domain']),
		'cookie_path'			=> panther_trim($_POST['form']['cookie_path']),
		'debug_mode'			=> $_POST['form']['debug_mode'] != '1' ? '0' : '1',
		'archiving'				=> $_POST['form']['archive'] != '1' ? '0' : '1',
		'update_type'			=> (in_array($_POST['form']['update_type'], array(0, 1, 2, 3))) ? intval($_POST['form']['update_type']) : 3,
		'show_queries'			=> $_POST['form']['show_queries'] != '1' ? '0' : '1',
		'login_queue'			=> $_POST['form']['login_queue'] != '1' ? '0' : '1',
		'queue_size'			=> (intval($_POST['form']['queue_size']) > 5) ? intval($_POST['form']['queue_size']) : 30,
		'max_attempts'			=> (intval($_POST['form']['max_attempts']) > 1) ? intval($_POST['form']['max_attempts']) : 5,
		'show_version'			=> $_POST['form']['show_version'] != '1' ? '0' : '1',
		'show_user_info'		=> $_POST['form']['show_user_info'] != '1' ? '0' : '1',
		'show_post_count'		=> $_POST['form']['show_post_count'] != '1' ? '0' : '1',
		'smilies'				=> $_POST['form']['smilies'] != '1' ? '0' : '1',
		'smilies_width'			=> intval($_POST['form']['smilies_width']),
		'smilies_height'		=> intval($_POST['form']['smilies_height']),
		'smilies_size'			=> intval($_POST['form']['smilies_size']),
		'private_messaging'		=> intval($_POST['form']['private_messaging']),
		'smilies_sig'			=> $_POST['form']['smilies_sig'] != '1' ? '0' : '1',
		'make_links'			=> $_POST['form']['make_links'] != '1' ? '0' : '1',
		'topic_review'			=> (intval($_POST['form']['topic_review']) >= 0) ? intval($_POST['form']['topic_review']) : 0,
		'disp_topics_default'	=> intval($_POST['form']['disp_topics_default']),
		'disp_posts_default'	=> intval($_POST['form']['disp_posts_default']),
		'indent_num_spaces'		=> (intval($_POST['form']['indent_num_spaces']) >= 0) ? intval($_POST['form']['indent_num_spaces']) : 0,
		'quote_depth'			=> (intval($_POST['form']['quote_depth']) > 0) ? intval($_POST['form']['quote_depth']) : 1,
		'quickpost'				=> $_POST['form']['quickpost'] != '1' ? '0' : '1',
		'attachments'			=> $_POST['form']['attachments'] != '1' ? '0' : '1',
		'create_orphans'		=> $_POST['form']['create_orphans'] != '1' ? '0' : '1',
		'max_upload_size'		=> intval($_POST['form']['max_upload_size']) ? intval($_POST['form']['max_upload_size']) : 10485760,
		'attachment_images'		=> panther_trim($_POST['form']['attachment_images']),
		'attachment_extensions'	=> panther_trim($_POST['form']['attachment_extensions']),
		'sfs_api'				=> panther_trim($_POST['form']['sfs_api']),
		'tinypng_api'			=> panther_trim($_POST['form']['tinypng_api']),
		'cloudflare_api'		=> panther_trim($_POST['form']['cloudflare_api']),
		'cloudflare_email'		=> panther_trim($_POST['form']['cloudflare_email']),
		'cloudflare_domain'		=> panther_trim($_POST['form']['cloudflare_domain']),
		'http_authentication'	=> $_POST['form']['http_authentication'] != '1' ? '0' : '1',
		'popular_topics'		=> (intval($_POST['form']['popular_topics']) > 0) ? intval($_POST['form']['popular_topics']) : 25,
		'max_pm_receivers'		=> (intval($_POST['form']['max_pm_receivers']) > 0) ? intval($_POST['form']['max_pm_receivers']) : 15,
		'url_type'				=> panther_trim($_POST['form']['url_type']),
		'always_deny'			=> panther_trim($_POST['form']['always_deny']),
		'users_online'			=> $_POST['form']['users_online'] != '1' ? '0' : '1',
		'delete_full'			=> $_POST['form']['delete_full'] != '1' ? '0' : '1',
		'attachments_dir'		=> panther_trim($_POST['form']['attachments_dir']),
		'warnings'				=> $_POST['form']['warnings'] != '1' ? '0' : '1',
		'custom_warnings'		=> $_POST['form']['custom_warnings'] != '1' ? '0' : '1',
		'warning_status'		=> (in_array($_POST['form']['warning_status'], array(0, 1, 2))) ? intval($_POST['form']['warning_status']) : 1,
		'censoring'				=> $_POST['form']['censoring'] != '1' ? '0' : '1',
		'signatures'			=> $_POST['form']['signatures'] != '1' ? '0' : '1',
		'polls'					=> $_POST['form']['polls'] != '1' ? '0' : '1',
		'ranks'					=> $_POST['form']['ranks'] != '1' ? '0' : '1',
		'reputation'			=> $_POST['form']['reputation'] != '1' ? '0' : '1',
		'rep_abuse'				=> (intval($_POST['form']['rep_abuse']) > 0) ? intval($_POST['form']['rep_abuse']) : 5,
		'max_poll_fields'		=> (intval($_POST['form']['max_poll_fields']) > 0) ? intval($_POST['form']['max_poll_fields']) : 20,
		'show_dot'				=> $_POST['form']['show_dot'] != '1' ? '0' : '1',
		'rep_type'				=> (in_array($_POST['form']['rep_type'], array(1, 2, 3))) ? intval($_POST['form']['rep_type']) : 1,
		'topic_views'			=> $_POST['form']['topic_views'] != '1' ? '0' : '1',
		'ban_email'				=> $_POST['form']['ban_email'] != '1' ? '0' : '1',
		'quickjump'				=> $_POST['form']['quickjump'] != '1' ? '0' : '1',
		'gzip'					=> $_POST['form']['gzip'] != '1' ? '0' : '1',
		'search_all_forums'		=> $_POST['form']['search_all_forums'] != '1' ? '0' : '1',
		'additional_navlinks'	=> panther_trim($_POST['form']['additional_navlinks']),
		'feed_type'				=> intval($_POST['form']['feed_type']),
		'feed_ttl'				=> intval($_POST['form']['feed_ttl']),
		'report_method'			=> intval($_POST['form']['report_method']),
		'mailing_list'			=> panther_trim($_POST['form']['mailing_list']),
		'avatars'				=> $_POST['form']['avatars'] != '1' ? '0' : '1',
		'avatar_upload'			=> $_POST['form']['avatar_upload'] != '1' ? '0' : '1',
		'task_type'				=> $_POST['form']['task_type'] == '1' && function_exists('exec') ? '1' : '0',
		'avatars_dir'			=> panther_trim($_POST['form']['avatars_dir']),
		'avatars_path'			=> panther_trim($_POST['form']['avatars_path']),
		'image_dir'				=> panther_trim($_POST['form']['image_dir']),
		'image_path'			=> panther_trim($_POST['form']['image_path']),
		'js_dir'				=> panther_trim($_POST['form']['js_dir']),
		'smilies_dir'			=> panther_trim($_POST['form']['smilies_dir']),
		'smilies_path'			=> panther_trim($_POST['form']['smilies_path']),
		'image_group_width'		=> (intval($_POST['form']['image_group_width']) > 0) ? intval($_POST['form']['image_group_width']) : 1,
		'image_group_height'	=> (intval($_POST['form']['image_group_height']) > 0) ? intval($_POST['form']['image_group_height']) : 1,
		'image_group_size'		=> (intval($_POST['form']['image_group_size']) > 0) ? intval($_POST['form']['image_group_size']) : 1,
		'image_group_dir'		=> panther_trim($_POST['form']['image_group_dir']),
		'image_group_path'		=> panther_trim($_POST['form']['image_group_path']),
		'avatars_width'			=> (intval($_POST['form']['avatars_width']) > 0) ? intval($_POST['form']['avatars_width']) : 1,
		'avatars_height'		=> (intval($_POST['form']['avatars_height']) > 0) ? intval($_POST['form']['avatars_height']) : 1,
		'avatars_size'			=> (intval($_POST['form']['avatars_size']) > 0) ? intval($_POST['form']['avatars_size']) : 1,
		'attachment_icon_dir'	=> panther_trim($_POST['form']['attachment_icon_dir']),
		'attachment_icon_path'	=> panther_trim($_POST['form']['attachment_icon_path']),
		'style_path'			=> panther_trim($_POST['form']['style_path']),
		'style_dir'				=> panther_trim($_POST['form']['style_dir']),
		'attachment_icons'		=> $_POST['form']['attachment_icons'] != '1' ? '0' : '1',
		'email_name'			=> panther_trim($_POST['form']['email_name']),
		'admin_email'			=> strtolower(panther_trim($_POST['form']['admin_email'])),
		'webmaster_email'		=> strtolower(panther_trim($_POST['form']['webmaster_email'])),
		'forum_subscriptions'	=> $_POST['form']['forum_subscriptions'] != '1' ? '0' : '1',
		'topic_subscriptions'	=> $_POST['form']['topic_subscriptions'] != '1' ? '0' : '1',
		'smtp_host'				=> panther_trim($_POST['form']['smtp_host']),
		'smtp_user'				=> panther_trim($_POST['form']['smtp_user']),
		'smtp_ssl'				=> $_POST['form']['smtp_ssl'] != '1' ? '0' : '1',
		'regs_allow'			=> $_POST['form']['regs_allow'] != '1' ? '0' : '1',
		'regs_verify'			=> $_POST['form']['regs_verify'] != '1' ? '0' : '1',
		'regs_report'			=> $_POST['form']['regs_report'] != '1' ? '0' : '1',
		'rules'					=> $_POST['form']['rules'] != '1' ? '0' : '1',
		'rules_message'			=> panther_trim($_POST['form']['rules_message']),
		'default_email_setting'	=> intval($_POST['form']['default_email_setting']),
		'announcement'			=> $_POST['form']['announcement'] != '1' ? '0' : '1',
		'announcement_message'	=> panther_trim($_POST['form']['announcement_message']),
		'maintenance'			=> $_POST['form']['maintenance'] != '1' ? '0' : '1',
		'maintenance_message'	=> panther_trim($_POST['form']['maintenance_message']),
	);

	if ($form['board_title'] == '')
		message($lang_admin_options['Must enter title message']);

	// Make sure base_url doesn't end with a slash
	if (substr($form['base_url'], -1) == '/')
		$form['base_url'] = substr($form['base_url'], 0, -1);
	
	// Make sure cloudflare domain ends with a trailing slash
	if (substr($form['cloudflare_domain'], -1) != '/' && $form['cloudflare_domain'] != '')
		$form['cloudflare_domain'] .= '/';
	
	$form['email_name'] = panther_trim(preg_replace('/[^a-zA-Z0-9 ]/', '', $form['email_name']));
	if ($form['email_name'] == '')
		message($lang_admin_options['Email name problem']);
	
	if ($form['image_dir'] != '')
	{
		// Make sure this ends with a trailing slash if it's set
		if (substr($form['image_dir'], -1) != '/')
			$form['image_dir'] .= '/';
	}
	else
		$form['image_dir'] = $form['base_url'].'/assets/images/';
	
	if ($form['js_dir'] != '')
	{
		if (substr($form['js_dir'], -1) != '/')
			$form['js_dir'] .= '/';
	}
	else
		$form['js_dir'] = $form['base_url'].'/assets/js/';
	
	if (isset($_FILES['favicon']))
	{
		$favicon = $_FILES['favicon'];
		$favicon_dir = ($panther_config['o_image_dir'] != $panther_config['o_base_url'].'/assets/images/') ? $panther_config['o_image_path'] : PANTHER_ROOT.$panther_config['o_image_path'].'/';

		switch ($favicon['error'])
		{
			case 1:	// UPLOAD_ERR_INI_SIZE
			case 2:	// UPLOAD_ERR_FORM_SIZE
				message($lang_admin_options['Too large ini']);
				break;

			case 3:	// UPLOAD_ERR_PARTIAL
				message($lang_admin_options['Partial upload']);
				break;

			case 4:	// UPLOAD_ERR_NO_FILE
				break;
			case 6:	// UPLOAD_ERR_NO_TMP_DIR
				message($lang_admin_options['No tmp directory']);
				break;

			default:
				break;
		}
		
		if (is_uploaded_file($favicon['tmp_name']))
		{
			$allowed_types = array('image/x-icon', 'image/ico', 'image/png', 'image/jpg', 'image/jpeg', 'image/pjpeg', 'image/gif');
			if (!in_array($favicon['type'], $allowed_types))
				message($lang_admin_options['Bad type']);

			if (!@move_uploaded_file($favicon['tmp_name'], $favicon_dir.'favicon.ico'))
				message($lang_admin_options['Move failed'].' <a href="mailto:'.panther_htmlspecialchars($panther_config['o_admin_email']).'">'.panther_htmlspecialchars($panther_config['o_admin_email']).'</a>.');

			$form['favicon'] = $favicon['name'];
		}
	}

	if (isset($_FILES['avatar']))
	{
		$avatar = $_FILES['avatar'];
		switch ($avatar['error'])
		{
			case 1:	// UPLOAD_ERR_INI_SIZE
			case 2:	// UPLOAD_ERR_FORM_SIZE
				message($lang_admin_options['Too large ini']);
				break;

			case 3:	// UPLOAD_ERR_PARTIAL
				message($lang_admin_options['Partial upload']);
				break;

			case 4:	// UPLOAD_ERR_NO_FILE
				break;
			case 6:	// UPLOAD_ERR_NO_TMP_DIR
				message($lang_admin_options['No tmp directory']);
				break;

			default:
				break;
		}

		if (is_uploaded_file($avatar['tmp_name']))
		{
			$allowed_types = array('image/gif', 'image/jpeg', 'image/pjpeg', 'image/png', 'image/x-png');
			if (!in_array($avatar['type'], $allowed_types))
				message($lang_admin_options['Bad type']);
			
			if ($avatar['size'] > $panther_config['o_avatars_size'])
				message(sprintf($lang_admin_options['Too large'], forum_number_format($panther_config['o_avatars_size'])));
			
			$avatar_dir = ($panther_config['o_avatars_dir'] != '') ? $panther_config['o_avatars_path'] : PANTHER_ROOT.$panther_config['o_avatars_path'].'/';

			// Move the file to the avatar directory. We do this before checking the width/height to circumvent open_basedir restrictions
			if (!@move_uploaded_file($avatar['tmp_name'], $avatar_dir.'1.tmp'))
				message($lang_admin_options['Move failed'].' <a href="mailto:'.panther_htmlspecialchars($panther_config['o_admin_email']).'">'.panther_htmlspecialchars($panther_config['o_admin_email']).'</a>.');

			list($width, $height, $type,) = @getimagesize($avatar_dir.'1.tmp');

			// Determine type
			if ($type == IMAGETYPE_GIF)
				$extension = 'gif';
			else if ($type == IMAGETYPE_JPEG)
				$extension = 'jpg';
			else if ($type == IMAGETYPE_PNG)
				$extension = 'png';
			else
			{
				// Invalid type
				@unlink($avatar_dir.'1.tmp');
				message($lang_admin_options['Bad type']);
			}

			// Now check the width/height
			if (empty($width) || empty($height) || $width > $panther_config['o_avatars_width'] || $height > $panther_config['o_avatars_height'])
			{
				@unlink($avatar_dir.'1.tmp');
				message(sprintf($lang_admin_options['Too wide or high'], $panther_config['o_avatars_width'], $panther_config['o_avatars_height']));
			}

			// Delete the old default avatar
			@unlink($avatar_dir.'1.'.$panther_config['o_avatar']);
			@rename($avatar_dir.'1.tmp', $avatar_dir.'1.'.$extension);
			compress_image($avatar_dir.'1.'.$extension);
			@chmod($avatar_dir.'1.'.$extension, 0644);

			$form['avatar'] = $extension;
		}
	}

	// Convert IDN to Punycode if needed
	if (preg_match('/[^\x00-\x7F]/', $form['base_url']))
	{
		if (!function_exists('idn_to_ascii'))
			message($lang_admin_options['Base URL problem']);
		else
			$form['base_url'] = idn_to_ascii($form['base_url']);
	}

	$max_file_size = return_bytes(@ini_get('upload_max_filesize'));
	$max_post_size = return_bytes(@ini_get('post_max_size'));

	$comparison = ($max_file_size > $max_post_size) ? $max_post_size : $max_file_size;
	if ($form['max_upload_size'] > $comparison)
		$form['max_upload_size'] = $comparison;

	$languages = forum_list_langs();
	if (!in_array($form['default_lang'], $languages))
		message($lang_common['Bad request'], false, '404 Not Found');

	$styles = forum_list_styles();
	if (!in_array($form['default_style'], $styles))
		message($lang_common['Bad request'], false, '404 Not Found');

	$schemes = get_url_schemes();
	if (!in_array($form['url_type'], $schemes))
		message($lang_common['Bad request'], false, '404 Not Found');		

	if ($form['time_format'] == '')
		$form['time_format'] = 'H:i:s';

	if ($form['date_format'] == '')
		$form['date_format'] = 'd-m-Y';

	require PANTHER_ROOT.'include/email.php';

	if (!is_valid_email($form['admin_email']))
		message($lang_admin_options['Invalid e-mail message']);

	if (!is_valid_email($form['webmaster_email']))
		message($lang_admin_options['Invalid webmaster e-mail message']);
	
	if (!is_valid_email($form['cloudflare_email']) && $form['cloudflare_email'] != '')
		message($lang_admin_options['Invalid cloudflare e-mail message']);

	if ($form['mailing_list'] != '')
		$form['mailing_list'] = strtolower(preg_replace('%\s%S', '', $form['mailing_list']));

	// Make sure avatars_path ends with a slash
	if (substr($form['avatars_path'], -1) != '/' && $form['avatars_path'] != '')
		$form['avatars_path'] .= '/';

	// Make sure avatars_dir ends with a slash
	if (substr($form['avatars_dir'], -1) != '/' && $form['avatars_dir'] != '')
		$form['avatars_dir'] .= '/';
	
	// Make sure style_path doesn't end with a slash
	if (substr($form['style_path'], -1) == '/')
		$form['style_path'] = substr($form['style_path'], 0, -1);

	// Make sure style_dir ends with a slash
	if (substr($form['style_dir'], -1) != '/' && $form['style_dir'] != '')
		$form['style_dir'] .= '/';

	// Make sure smilies_path doesn't end with a slash
	if (substr($form['smilies_path'], -1) == '/')
		$form['smilies_path'] = substr($form['smilies_path'], 0, -1);

	// Make sure smilies_dir ends with a slash
	if (substr($form['smilies_dir'], -1) != '/' && $form['smilies_dir'] != '')
		$form['smilies_dir'] .= '/';
	
	// Make sure image_group_path ends with a slash
	if (substr($form['image_group_path'], -1) != '/' && $form['image_group_path'] != '')
		$form['image_group_path'] .= '/';

	// Make sure image_group_dir ends with a slash
	if (substr($form['image_group_dir'], -1) != '/' && $form['image_group_dir'] != '')
		$form['image_group_dir'] .= '/';
	
	// Make sure image_path doesn't end with a slash
	if (substr($form['image_path'], -1) == '/')
		$form['image_path'] = substr($form['image_path'], 0, -1);

	// Make sure attachment_icon_path doesn't end with a slash
	if (substr($form['attachment_icon_path'], -1) == '/')
		$form['attachment_icon_path'] = substr($form['attachment_icon_path'], 0, -1);

	// Make sure attachment_icon_dir ends with a slash
	if (substr($form['attachment_icon_dir'], -1) != '/' && $form['attachment_icon_dir'] != '')
		$form['attachment_icon_dir'] .= '/';

	if ($form['additional_navlinks'] != '')
		$form['additional_navlinks'] = panther_trim(panther_linebreaks($form['additional_navlinks']));

	// Change or enter a SMTP password
	if (isset($_POST['form']['smtp_change_pass']))
	{
		$smtp_pass1 = isset($_POST['form']['smtp_pass1']) ? panther_trim($_POST['form']['smtp_pass1']) : '';
		$smtp_pass2 = isset($_POST['form']['smtp_pass2']) ? panther_trim($_POST['form']['smtp_pass2']) : '';

		if ($smtp_pass1 == $smtp_pass2)
			$form['smtp_pass'] = $smtp_pass1;
		else
			message($lang_admin_options['SMTP passwords did not match']);
	}

	if ($form['announcement_message'] != '')
		$form['announcement_message'] = panther_linebreaks($form['announcement_message']);
	else
	{
		$form['announcement_message'] = $lang_admin_options['Enter announcement here'];
		$form['announcement'] = '0';
	}

	if ($form['rules_message'] != '')
		$form['rules_message'] = panther_linebreaks($form['rules_message']);
	else
	{
		$form['rules_message'] = $lang_admin_options['Enter rules here'];
		$form['rules'] = '0';
	}

	if ($form['maintenance_message'] != '')
		$form['maintenance_message'] = panther_linebreaks($form['maintenance_message']);
	else
	{
		$form['maintenance_message'] = $lang_admin_options['Default maintenance message'];
		$form['maintenance'] = '0';
	}

	// Make sure the number of displayed topics and posts is between 3 and 75
	if ($form['disp_topics_default'] < 3)
		$form['disp_topics_default'] = 3;
	else if ($form['disp_topics_default'] > 75)
		$form['disp_topics_default'] = 75;

	if ($form['disp_posts_default'] < 3)
		$form['disp_posts_default'] = 3;
	else if ($form['disp_posts_default'] > 75)
		$form['disp_posts_default'] = 75;

	if ($form['feed_type'] < 0 || $form['feed_type'] > 2)
		message($lang_common['Bad request'], false, '404 Not Found');

	if ($form['feed_ttl'] < 0)
		message($lang_common['Bad request'], false, '404 Not Found');

	if ($form['report_method'] < 0 || $form['report_method'] > 2)
		message($lang_common['Bad request'], false, '404 Not Found');

	if ($form['default_email_setting'] < 0 || $form['default_email_setting'] > 2)
		message($lang_common['Bad request'], false, '404 Not Found');

	if ($form['timeout_online'] >= $form['timeout_visit'])
		message($lang_admin_options['Timeout error message']);

	if ($form['archiving'] == 0 && $panther_config['o_archiving'] != $form['archiving'])	// If we've disabled archiving then we need to unarchive every topic
	{
		$update = array(
			'archived'	=>	0,
		);

		$db->update('topics', $update);
	}

	foreach ($form as $key => $input)
	{
		// Only update values that have changed
		if (array_key_exists('o_'.$key, $panther_config) && $panther_config['o_'.$key] != $input)
		{
			if ($input != '' || is_int($input))
				$value = $input;
			else
				$value = null;
			
			$update = array(
				'conf_value'	=>	$value,
			);

			$data = array(
				':conf_name'	=>	'o_'.$key,
			);

			$db->update('config', $update, 'conf_name=:conf_name', $data);
		}
	}

	// Regenerate the config cache
	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PANTHER_ROOT.'include/cache.php';

	generate_config_cache();
	clear_feed_cache();
	
	if ($form['url_type'] != $panther_config['o_url_type'])
	{
		//Load new URL pack to avoid 404 error after redirecting
		if (file_exists(PANTHER_ROOT.'include/url/'.$form['url_type'].'.php'))
			require PANTHER_ROOT.'include/url/'.$form['url_type'].'.php';
		else
			require PANTHER_ROOT.'include/url/default.php';
		
		generate_quickjump_cache();
	}

	redirect(panther_link($panther_url['admin_options']), $lang_admin_options['Options updated redirect']);
}

$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_admin_common['Admin'], $lang_admin_common['Options']);
define('PANTHER_ACTIVE_PAGE', 'admin');
require PANTHER_ROOT.'header.php';

generate_admin_menu('options');

$languages = forum_list_langs();
foreach ($languages as $temp)
	$language_options[] = "\t\t\t\t\t\t\t\t\t\t\t".'<option value="'.$temp.'" '.(($panther_config['o_default_lang'] == $temp ? ' selected="selected"' : '')).'>'.$temp.'</option>';

$styles = forum_list_styles();

$style_options = array();
foreach ($styles as $temp)
	$style_options[] = "\t\t\t\t\t\t\t\t\t\t\t".'<option value="'.$temp.'" '.(($panther_config['o_default_style'] == $temp ? ' selected="selected"' : '')).'>'.$temp.'</option>';

$diff = ($panther_user['timezone'] + $panther_user['dst']) * 3600;
$timestamp = time() + $diff;

$times = array(5, 15, 30, 60);
$feed_options = array();
foreach ($times as $time)
	$feed_options[] = "\t\t\t\t\t\t\t\t\t\t\t".'<option value="'.$temp.'" '.(($panther_config['o_feed_ttl'] == $temp ? ' selected="selected"' : '')).'>'.$temp.'</option>';

$schemes = get_url_schemes();
$scheme_options = array();
foreach ($schemes as $scheme)
	$scheme_options[] = "\t\t\t\t\t\t\t\t\t\t\t".'<option value="'.$scheme.'"'.(($panther_config['o_url_type'] == $scheme ? ' selected="selected"' : '')).'>'.substr(ucwords(str_replace('_', ' ', $scheme)), 0, -4).'</option>';

$smtp_pass = !empty($panther_config['o_smtp_pass']) ? random_key(panther_strlen($panther_config['o_smtp_pass']), true) : '';
$admin_tpl = panther_template('admin_options.tpl');

$search = array(
	'{options_head}' => $lang_admin_options['Options head'],
	'{admin_options}' => panther_link($panther_url['admin_options']),
	'{save_changes}' => $lang_admin_common['Save changes'],
	'{generate_csrf_token}' => generate_csrf_token(PANTHER_ADMIN_DIR.'/options.php'),
	'{essentials_subhead}' => $lang_admin_options['Essentials subhead'],
	'{board_title_label}' => $lang_admin_options['Board title label'],
	'{o_board_title}' => panther_htmlspecialchars($panther_config['o_board_title']),
	'{board_title_help}' => $lang_admin_options['Board title help'],
	'{board_desc_label}' => $lang_admin_options['Board desc label'],
	'{o_board_desc}' => panther_htmlspecialchars($panther_config['o_board_desc']),
	'{board_desc_help}' => $lang_admin_options['Board desc help'],
	'{favicon_label}' => $lang_admin_options['Favicon label'],
	'{max_file_size}' => $max_file_size,
	'{favicon_help}' => $lang_admin_options['Favicon help'],
	'{default_avatar_label}' => $lang_admin_options['Default avatar label'],
	'{default_avatar_help}' => $lang_admin_options['Default avatar help'],
	'{base_url_label}' => $lang_admin_options['Base URL label'],
	'{o_base_url}' => panther_htmlspecialchars($panther_config['o_base_url']),
	'{base_url_help}' => $lang_admin_options['Base URL help'],
	'{timezone_label}' => $lang_admin_options['Timezone label'],
	'{timezone_-12_select}' => ($panther_config['o_default_timezone'] == -12) ? ' selected="selected"' : '',
	'{timezone_-11_select}' => ($panther_config['o_default_timezone'] == -11) ? ' selected="selected"' : '',
	'{timezone_-10_select}' => ($panther_config['o_default_timezone'] == -10) ? ' selected="selected"' : '',
	'{timezone_-9.5_select}' => ($panther_config['o_default_timezone'] == -9.5) ? ' selected="selected"' : '',
	'{timezone_-9_select}' => ($panther_config['o_default_timezone'] == -9) ? ' selected="selected"' : '',
	'{timezone_-8.5_select}' => ($panther_config['o_default_timezone'] == -8.5) ? ' selected="selected"' : '',
	'{timezone_-8_select}' => ($panther_config['o_default_timezone'] == -8) ? ' selected="selected"' : '',
	'{timezone_-7_select}' => ($panther_config['o_default_timezone'] == -7) ? ' selected="selected"' : '',
	'{timezone_-6_select}' => ($panther_config['o_default_timezone'] == -6) ? ' selected="selected"' : '',
	'{timezone_-5_select}' => ($panther_config['o_default_timezone'] == -5) ? ' selected="selected"' : '',
	'{timezone_-4_select}' => ($panther_config['o_default_timezone'] == -4) ? ' selected="selected"' : '',
	'{timezone_-3.5_select}' => ($panther_config['o_default_timezone'] == -3.5) ? ' selected="selected"' : '',
	'{timezone_-3_select}' => ($panther_config['o_default_timezone'] == -3) ? ' selected="selected"' : '',
	'{timezone_-2_select}' => ($panther_config['o_default_timezone'] == -2) ? ' selected="selected"' : '',
	'{timezone_-1_select}' => ($panther_config['o_default_timezone'] == -1) ? ' selected="selected"' : '',
	'{timezone_0_select}' => ($panther_config['o_default_timezone'] == 0) ? ' selected="selected"' : '',
	'{timezone_1_select}' => ($panther_config['o_default_timezone'] == 1) ? ' selected="selected"' : '',
	'{timezone_2_select}' => ($panther_config['o_default_timezone'] == 2) ? ' selected="selected"' : '',
	'{timezone_3_select}' => ($panther_config['o_default_timezone'] == 3) ? ' selected="selected"' : '',
	'{timezone_3.5_select}' => ($panther_config['o_default_timezone'] == 3.5) ? ' selected="selected"' : '',
	'{timezone_4_select}' => ($panther_config['o_default_timezone'] == 4) ? ' selected="selected"' : '',
	'{timezone_4.5_select}' => ($panther_config['o_default_timezone'] == 4.5) ? ' selected="selected"' : '',
	'{timezone_5_select}' => ($panther_config['o_default_timezone'] == 5) ? ' selected="selected"' : '',
	'{timezone_5.5_select}' => ($panther_config['o_default_timezone'] == 5.5) ? ' selected="selected"' : '',
	'{timezone_5.75_select}' => ($panther_config['o_default_timezone'] == 5.75) ? ' selected="selected"' : '',
	'{timezone_6_select}' => ($panther_config['o_default_timezone'] == 6) ? ' selected="selected"' : '',
	'{timezone_6.5_select}' => ($panther_config['o_default_timezone'] == 6.5) ? ' selected="selected"' : '',
	'{timezone_7_select}' => ($panther_config['o_default_timezone'] == 7) ? ' selected="selected"' : '',
	'{timezone_8_select}' => ($panther_config['o_default_timezone'] == 8) ? ' selected="selected"' : '',
	'{timezone_8.75_select}' => ($panther_config['o_default_timezone'] == 8.75) ? ' selected="selected"' : '',
	'{timezone_9_select}' => ($panther_config['o_default_timezone'] == 9) ? ' selected="selected"' : '',
	'{timezone_9.5_select}' => ($panther_config['o_default_timezone'] == 9.5) ? ' selected="selected"' : '',
	'{timezone_10_select}' => ($panther_config['o_default_timezone'] == 10) ? ' selected="selected"' : '',
	'{timezone_10.5_select}' => ($panther_config['o_default_timezone'] == 10.5) ? ' selected="selected"' : '',
	'{timezone_11_select}' => ($panther_config['o_default_timezone'] == 11) ? ' selected="selected"' : '',
	'{timezone_11.5_select}' => ($panther_config['o_default_timezone'] == 11.5) ? ' selected="selected"' : '',
	'{timezone_12_select}' => ($panther_config['o_default_timezone'] == 12) ? ' selected="selected"' : '',
	'{timezone_12.75_select}' => ($panther_config['o_default_timezone'] == 12.75) ? ' selected="selected"' : '',
	'{timezone_13_select}' => ($panther_config['o_default_timezone'] == 13) ? ' selected="selected"' : '',
	'{timezone_14_select}' => ($panther_config['o_default_timezone'] == 14) ? ' selected="selected"' : '',
	'{utc_-12}' => $lang_admin_options['UTC-12:00'],
	'{utc_-11}' => $lang_admin_options['UTC-11:00'],
	'{utc_-10}' => $lang_admin_options['UTC-10:00'],
	'{utc_-9.5}' => $lang_admin_options['UTC-09:30'],
	'{utc_-9}' => $lang_admin_options['UTC-09:00'],
	'{utc_-8.5}' => $lang_admin_options['UTC-08:30'],
	'{utc_-8}' => $lang_admin_options['UTC-08:00'],
	'{utc_-7}' => $lang_admin_options['UTC-07:00'],
	'{utc_-6}' => $lang_admin_options['UTC-06:00'],
	'{utc_-5}' => $lang_admin_options['UTC-05:00'],
	'{utc_-4}' => $lang_admin_options['UTC-04:00'],
	'{utc_-3.5}' => $lang_admin_options['UTC-03:30'],
	'{utc_-3}' => $lang_admin_options['UTC-03:00'],
	'{utc_-2}' => $lang_admin_options['UTC-02:00'],
	'{utc_-1}' => $lang_admin_options['UTC-01:00'],
	'{utc_0}' => $lang_admin_options['UTC'],
	'{utc_1}' => $lang_admin_options['UTC+01:00'],
	'{utc_2}' => $lang_admin_options['UTC+02:00'],
	'{utc_3}' => $lang_admin_options['UTC+03:00'],
	'{utc_3.5}' => $lang_admin_options['UTC+03:30'],
	'{utc_4}' => $lang_admin_options['UTC+04:00'],
	'{utc_4.5}' => $lang_admin_options['UTC+04:30'],
	'{utc_5}' => $lang_admin_options['UTC+05:00'],
	'{utc_5.5}' => $lang_admin_options['UTC+05:30'],
	'{utc_5.75}' => $lang_admin_options['UTC+05:45'],
	'{utc_6}' => $lang_admin_options['UTC+06:00'],
	'{utc_6.5}' => $lang_admin_options['UTC+06:30'],
	'{utc_7}' => $lang_admin_options['UTC+07:00'],
	'{utc_8}' => $lang_admin_options['UTC+08:00'],
	'{utc_8.75}' => $lang_admin_options['UTC+08:45'],
	'{utc_9}' => $lang_admin_options['UTC+09:00'],
	'{utc_9.5}' => $lang_admin_options['UTC+09:30'],
	'{utc_10}' => $lang_admin_options['UTC+10:00'],
	'{utc_10.5}' => $lang_admin_options['UTC+10:30'],
	'{utc_11}' => $lang_admin_options['UTC+11:00'],
	'{utc_11.5}' => $lang_admin_options['UTC+11:30'],
	'{utc_12}' => $lang_admin_options['UTC+12:00'],
	'{utc_12.75}' => $lang_admin_options['UTC+12:45'],
	'{utc_13}' => $lang_admin_options['UTC+13:00'],
	'{utc_14}' => $lang_admin_options['UTC+14:00'],
	'{timezone_help}' => $lang_admin_options['Timezone help'],
	'{dst_label}' => $lang_admin_options['DST label'],
	'{o_default_dst_1_checked}' => ($panther_config['o_default_dst'] == '1') ? ' checked="checked"' : '',
	'{yes}' => $lang_admin_common['Yes'],
	'{o_default_dst_0_checked}' => ($panther_config['o_default_dst'] == '0') ? ' checked="checked"' : '',
	'{no}' => $lang_admin_common['No'],
	'{dst_help}' => $lang_admin_options['DST help'],
	'{url_type_label}' => $lang_admin_options['URL type label'],
	'{scheme_options}' => implode("\n", $scheme_options),
	'{url_type_help}' => $lang_admin_options['URL type help'],
	'{language_label}' => $lang_admin_options['Language label'],
	'{o_default_lang}' => count($language_options) ? implode("\n", $language_options) : '',
	'{language_help}' => $lang_admin_options['Language help'],
	'{default_style_label}' => $lang_admin_options['Default style label'],
	'{o_default_style}' => count($style_options) ? implode("\n", $style_options) : '',
	'{default_style_help}' => $lang_admin_options['Default style help'],
	'{ban_email_label}' => $lang_admin_options['Ban email label'],
	'{o_ban_email_1_checked}' => ($panther_config['o_ban_email'] == '1') ? ' checked="checked"' : '',
	'{o_ban_email_0_checked}' => ($panther_config['o_ban_email'] == '0') ? ' checked="checked"' : '',
	'{ban_email_help}' => $lang_admin_options['Ban email help'],
	'{img_patch_label}' => $lang_admin_options['Img path label'],
	'{o_image_path}' => panther_htmlspecialchars($panther_config['o_image_path']),
	'{img_patch_help}' => $lang_admin_options['Img path help'],
	'{img_directory_label}' => $lang_admin_options['Img directory label'],
	'{o_image_dir}' => ($panther_config['o_image_dir'] != $panther_config['o_base_url'].'/assets/images/') ? panther_htmlspecialchars($panther_config['o_image_dir']) : '',
	'{img_directory_help}' => $lang_admin_options['Img directory help'],
	'{js_directory_label}' => $lang_admin_options['JS directory label'],
	'{o_js_dir}' => ($panther_config['o_js_dir'] != $panther_config['o_base_url'].'/assets/js/') ? panther_htmlspecialchars($panther_config['o_js_dir']) : '',
	'{js_directory_help}' => $lang_admin_options['JS directory help'],
	'{style_path_label}' => $lang_admin_options['Style path label'],
	'{o_style_path}' => panther_htmlspecialchars($panther_config['o_style_path']),
	'{style_path_help}' => $lang_admin_options['Style path help'],
	'{style_directory_label}' => $lang_admin_options['Style directory label'],
	'{o_style_dir}' => panther_htmlspecialchars($panther_config['o_style_dir']),
	'{style_directory_help}' => $lang_admin_options['Style directory help'],
	'{cookie_subhead}' => $lang_admin_options['Cookie subhead'],
	'{cookie_name_label}' => $lang_admin_options['Cookie name label'],
	'{o_cookie_name}' => panther_htmlspecialchars($panther_config['o_cookie_name']),
	'{cookie_name_help}' => $lang_admin_options['Cookie name help'],
	'{cookie_domain_label}' => $lang_admin_options['Cookie domain label'],
	'{o_cookie_domain}' => panther_htmlspecialchars($panther_config['o_cookie_domain']),
	'{cookie_domain_help}' => $lang_admin_options['Cookie domain help'],
	'{cookie_seed_label}' => $lang_admin_options['Cookie seed label'],
	'{o_cookie_seed}' => panther_htmlspecialchars($panther_config['o_cookie_seed']),
	'{cookie_seed_help}' => $lang_admin_options['Cookie seed help'],
	'{cookie_secure_label}' => $lang_admin_options['Cookie secure label'],
	'{o_cookie_secure_1_checked}' => ($panther_config['o_cookie_secure'] == '1') ? ' checked="checked"' : '',
	'{o_cookie_secure_0_checked}' => ($panther_config['o_cookie_secure'] == '0') ? ' checked="checked"' : '',
	'{cookie_secure_help}' => $lang_admin_options['Cookie secure help'],
	'{cookie_path_label}' => $lang_admin_options['Cookie path label'],
	'{o_cookie_path}' => panther_htmlspecialchars($panther_config['o_cookie_path']),
	'{cookie_path_help}' => $lang_admin_options['Cookie path help'],
	'{force_ssl_label}' => $lang_admin_options['Force ssl label'],
	'{o_force_ssl_1_checked}' => ($panther_config['o_force_ssl'] == '1') ? ' checked="checked"' : '',
	'{o_force_ssl_0_checked}' => ($panther_config['o_force_ssl'] == '0') ? ' checked="checked"' : '',
	'{force_ssl_help}' => $lang_admin_options['Force ssl help'],
	'{timeout_subhead}' => $lang_admin_options['Timeouts subhead'],
	'{time_format_label}' => $lang_admin_options['Time format label'],
	'{o_time_format}' => panther_htmlspecialchars($panther_config['o_time_format']),
	'{time_format_help}' => sprintf($lang_admin_options['Time format help'], gmdate($panther_config['o_time_format'], $timestamp), '<a href="http://www.php.net/manual/en/function.date.php">'.$lang_admin_options['PHP manual'].'</a>'),
	'{date_format_label}' => $lang_admin_options['Date format label'],
	'{o_date_format}' => panther_htmlspecialchars($panther_config['o_date_format']),
	'{date_format_help}' => sprintf($lang_admin_options['Date format help'], gmdate($panther_config['o_date_format'], $timestamp), '<a href="http://www.php.net/manual/en/function.date.php">'.$lang_admin_options['PHP manual'].'</a>'),
	'{visit_timeout_label}' => $lang_admin_options['Visit timeout label'],
	'{o_timeout_visit}' => $panther_config['o_timeout_visit'],
	'{visit_timeout_help}' => $lang_admin_options['Visit timeout help'],
	'{online_timeout_label}' => $lang_admin_options['Online timeout label'],
	'{o_timeout_online}' => $panther_config['o_timeout_online'],
	'{online_timeout_help}' => $lang_admin_options['Online timeout help'],
	'{redirect_time_label}' => $lang_admin_options['Redirect time label'],
	'{o_redirect_delay}' => $panther_config['o_redirect_delay'],
	'{redirect_time_help}' => $lang_admin_options['Redirect time help'],
	'{display_subhead}' => $lang_admin_options['Display subhead'],
	'{version_number_label}' => $lang_admin_options['Version number label'],
	'{o_show_version_1_checked}' => ($panther_config['o_show_version'] == '1') ? ' checked="checked"' : '',
	'{o_show_version_0_checked}' => ($panther_config['o_show_version'] == '0') ? ' checked="checked"' : '',
	'{version_number_help}' => $lang_admin_options['Version number help'],
	'{info_in_posts_label}' => $lang_admin_options['Info in posts label'],
	'{o_show_user_info_1_checked}' => ($panther_config['o_show_user_info'] == '1') ? ' checked="checked"' : '',
	'{o_show_user_info_0_checked}' => ($panther_config['o_show_user_info'] == '0') ? ' checked="checked"' : '',
	'{info_in_posts_help}' => $lang_admin_options['Info in posts help'],
	'{post_count_label}' => $lang_admin_options['Post count label'],
	'{o_show_post_count_1_checked}' => ($panther_config['o_show_post_count'] == '1') ? ' checked="checked"' : '',
	'{o_show_post_count_0_checked}' => ($panther_config['o_show_post_count'] == '0') ? ' checked="checked"' : '',
	'{post_count_help}' => $lang_admin_options['Post count help'],
	'{smilies_label}' => $lang_admin_options['Smilies label'],
	'{o_smilies_1_checked}' => ($panther_config['o_smilies'] == '1') ? ' checked="checked"' : '',
	'{o_smilies_0_checked}' => ($panther_config['o_smilies'] == '0') ? ' checked="checked"' : '',
	'{smilies_help}' => $lang_admin_options['Smilies help'],
	'{smilies_path_label}' => $lang_admin_options['Smilies path label'],
	'{o_smilies_path}' => panther_htmlspecialchars($panther_config['o_smilies_path']),
	'{smilies_path_help}' => $lang_admin_options['Smilies path help'],
	'{smilies_directory_label}' => $lang_admin_options['Smilies directory label'],
	'{o_smilies_dir}' => panther_htmlspecialchars($panther_config['o_smilies_dir']),
	'{smilies_directory_help}' => $lang_admin_options['Smilies directory help'],
	'{max_width_smilies_label}' => $lang_admin_options['Max width smilies label'],
	'{o_smilies_width}' => $panther_config['o_smilies_width'],
	'{max_width_smilies_help}' => $lang_admin_options['Max width smilies help'],
	'{max_height_smilies_label}' => $lang_admin_options['Max height smilies label'],
	'{o_smilies_height}' => $panther_config['o_smilies_height'],
	'{max_height_smilies_help}' => $lang_admin_options['Max height smilies help'],
	'{max_size_smilies_label}' => $lang_admin_options['Max size smilies label'],
	'{o_smilies_size}' => $panther_config['o_smilies_size'],
	'{max_size_smilies_help}' => $lang_admin_options['Max size smilies help'],
	'{smilies_sigs_label}' => $lang_admin_options['Smilies sigs label'],
	'{o_smilies_sig_1_checked}' => ($panther_config['o_smilies_sig'] == '1') ? ' checked="checked"' : '',
	'{o_smilies_sig_0_checked}' => ($panther_config['o_smilies_sig'] == '0') ? ' checked="checked"' : '',
	'{smilies_sigs_help}' => $lang_admin_options['Smilies sigs help'],
	'{clickable_links_label}' => $lang_admin_options['Clickable links label'],
	'{o_make_links_1_checked}' => ($panther_config['o_make_links'] == '1') ? ' checked="checked"' : '',
	'{o_make_links_0_checked}' => ($panther_config['o_make_links'] == '0') ? ' checked="checked"' : '',
	'{clickable_links_help}' => $lang_admin_options['Clickable links help'],
	'{topic_review_label}' => $lang_admin_options['Topic review label'],
	'{o_topic_review}' => $panther_config['o_topic_review'],
	'{topic_review_help}' => $lang_admin_options['Topic review help'],
	'{topics_per_page_label}' => $lang_admin_options['Topics per page label'],
	'{o_disp_topics_default}' => $panther_config['o_disp_topics_default'],
	'{topics_per_page_help}' => $lang_admin_options['Topics per page help'],
	'{posts_per_page_label}' => $lang_admin_options['Posts per page label'],
	'{o_disp_posts_default}' => $panther_config['o_disp_posts_default'],
	'{posts_per_page_help}' => $lang_admin_options['Posts per page help'],
	'{indent_label}' => $lang_admin_options['Indent label'],
	'{o_indent_num_spaces}' => $panther_config['o_indent_num_spaces'],
	'{indent_help}' => $lang_admin_options['Indent help'],
	'{quote_depth_label}' => $lang_admin_options['Quote depth label'],
	'{o_quote_depth}' => $panther_config['o_quote_depth'],
	'{quote_depth_help}' => $lang_admin_options['Quote depth help'],
	'{user_tags_label}' => $lang_admin_options['User tags label'],
	'{o_user_tags_max}' => $panther_config['o_user_tags_max'],
	'{user_tags_help}' => $lang_admin_options['User tags help'],
	'{image_group_path_label}' => $lang_admin_options['Image group path label'],
	'{o_image_group_path}' => panther_htmlspecialchars($panther_config['o_image_group_path']),
	'{image_group_path_hep}' => $lang_admin_options['Image group path help'],
	'{image_group_dir_label}' => $lang_admin_options['Image group dir label'],
	'{o_image_group_dir}' => panther_htmlspecialchars($panther_config['o_image_group_dir']),
	'{image_group_dir_hep}' => $lang_admin_options['Image group dir help'],
	'{max_width_label}' => $lang_admin_options['Max width label'],
	'{o_image_group_width}' => $panther_config['o_image_group_width'],
	'{max_width_group_help}' => $lang_admin_options['Max width group help'],
	'{max_height_label}' => $lang_admin_options['Max height label'],
	'{o_image_group_height}' => $panther_config['o_image_group_height'],
	'{max_height_group_help}' => $lang_admin_options['Max height group help'],
	'{max_size_label}' => $lang_admin_options['Max size label'],
	'{o_image_group_size}' => $panther_config['o_image_group_size'],
	'{max_size_group_help}' => $lang_admin_options['Max size group help'],
	'{features_subhead}' => $lang_admin_options['Features subhead'],
	'{quick_post_label}' => $lang_admin_options['Quick post label'],
	'{o_quickpost_1_checked}' => ($panther_config['o_quickpost'] == '1') ? ' checked="checked"' : '',
	'{o_quickpost_0_checked}' => ($panther_config['o_quickpost'] == '0') ? ' checked="checked"' : '',
	'{quick_post_help}' => $lang_admin_options['Quick post help'],
	'{users_online_label}' => $lang_admin_options['Users online label'],
	'{o_users_online_1_checked}' => ($panther_config['o_users_online'] == '1') ? ' checked="checked"' : '',
	'{o_users_online_0_checked}' => ($panther_config['o_users_online'] == '0') ? ' checked="checked"' : '',
	'{users_online_help}' => $lang_admin_options['Users online help'],
	'{popular_topic_label}' => $lang_admin_options['Popular topic label'],
	'{o_popular_topics}' => $panther_config['o_popular_topics'],
	'{popular_topic_help}' => $lang_admin_options['Popular topic help'],
	'{http_authentication_label}' => $lang_admin_options['http authentication label'],
	'{o_http_authentication_1_checked}' => ($panther_config['o_http_authentication'] == '1') ? ' checked="checked"' : '',
	'{o_http_authentication_0_checked}' => ($panther_config['o_http_authentication'] == '0') ? ' checked="checked"' : '',
	'{http_authentication_help}' => $lang_admin_options['http authentication help'],
	'{censor_words_label}' => $lang_admin_options['Censor words label'],
	'{o_censoring_1_checked}' => ($panther_config['o_censoring'] == '1') ? ' checked="checked"' : '',
	'{o_censoring_0_checked}' => ($panther_config['o_censoring'] == '0') ? ' checked="checked"' : '',
	'{censor_words_help}' => sprintf($lang_admin_options['Censor words help'], '<a href="'.panther_link($panther_url['admin_censoring']).'">'.$lang_admin_common['Censoring'].'</a>'),
	'{archive_label}' => $lang_admin_options['Archive label'],
	'{o_archiving_1_checked}' => ($panther_config['o_archiving'] == '1') ? ' checked="checked"' : '',
	'{o_archiving_0_checked}' => ($panther_config['o_archiving'] == '0') ? ' checked="checked"' : '',
	'{archive_help}' => sprintf($lang_admin_options['Archive help'], panther_link($panther_url['admin_archive'])),
	'{warning_label}' => $lang_admin_options['Warning label'],
	'{o_warnings_1_checked}' => ($panther_config['o_warnings'] == '1') ? ' checked="checked"' : '',
	'{o_warnings_0_checked}' => ($panther_config['o_warnings'] == '0') ? ' checked="checked"' : '',
	'{warning_help}' => $lang_admin_options['Warning help'],
	'{warning_custom_label}' => $lang_admin_options['Warning custom label'],
	'{o_custom_warnings_1_checked}' => ($panther_config['o_custom_warnings'] == '1') ? ' checked="checked"' : '',
	'{o_custom_warnings_0_checked}' => ($panther_config['o_custom_warnings'] == '0') ? ' checked="checked"' : '',
	'{warning_status_label}' => $lang_admin_options['Warning status label'],
	'{o_warning_status_0_selected}' => ($panther_config['o_warning_status'] == '0') ? ' selected="selected"' : '',
	'{all_users}' => $lang_admin_options['All users'],
	'{o_warning_status_1_selected}' => ($panther_config['o_warning_status'] == '1') ? ' selected="selected"' : '',
	'{moderators_and_warned}' => $lang_admin_options['Moderators and warned'],
	'{o_warning_status_2_selected}' => ($panther_config['o_warning_status'] == '2') ? ' selected="selected"' : '',
	'{moderators_only}' => $lang_admin_options['Moderators only'],
	'{warning_status_help}' => $lang_admin_options['Warning status help'],
	'{delete_full_label}' => $lang_admin_options['delete full label'],
	'{o_delete_full_1_checked}' => ($panther_config['o_delete_full'] == '1') ? ' checked="checked"' : '',
	'{o_delete_full_0_checked}' => ($panther_config['o_delete_full'] == '0') ? ' checked="checked"' : '',
	'{delete_full_help}' => $lang_admin_options['delete full help'],
	'{signatures_label}' => $lang_admin_options['Signatures label'],
	'{o_signatures_1_checked}' => ($panther_config['o_signatures'] == '1') ? ' checked="checked"' : '',
	'{o_signatures_0_checked}' => ($panther_config['o_signatures'] == '0') ? ' checked="checked"' : '',
	'{signatures_help}' => $lang_admin_options['Signatures help'],
	'{attachments_label}' => $lang_admin_options['Attachments label'],
	'{o_attachments_1_checked}' => ($panther_config['o_attachments'] == '1') ? ' checked="checked"' : '',
	'{o_attachments_0_checked}' => ($panther_config['o_attachments'] == '0') ? ' checked="checked"' : '',
	'{attachments_help}' => $lang_admin_options['Attachments help'],
	'{attachments_orphans_label}' => $lang_admin_options['Attachments orphans label'],
	'{o_create_orphans_1_checked}' => ($panther_config['o_create_orphans'] == '1') ? ' checked="checked"' : '',
	'{o_create_orphans_0_checked}' => ($panther_config['o_create_orphans'] == '0') ? ' checked="checked"' : '',
	'{attachments_orphans_help}' => $lang_admin_options['Attachments orphans help'],
	'{attachment_deny_label}' => $lang_admin_options['Attachment deny label'],
	'{o_always_deny}' => panther_htmlspecialchars($panther_config['o_always_deny']),
	'{attachment_deny_help}' => $lang_admin_options['Attachment deny help'],
	'{attachment_icons_label}' => $lang_admin_options['Attachment icons label'],
	'{o_attachment_icons_1_checked}' => ($panther_config['o_attachment_icons'] == '1') ? ' checked="checked"' : '',
	'{o_attachment_icons_0_checked}' => ($panther_config['o_attachment_icons'] == '0') ? ' checked="checked"' : '',
	'{attachment_icons_help}' => $lang_admin_options['Attachment icons help'],
	'{attach_basefolder_label}' => $lang_admin_options['Attach basefolder label'],
	'{o_attachments_dir}' => panther_htmlspecialchars($panther_config['o_attachments_dir']),
	'{attach_basefolder_help}' => $lang_admin_options['Attach basefolder help'],
	'{file_extensions_label}' => $lang_admin_options['File extensions label'],
	'{o_attachment_extensions}' => panther_htmlspecialchars($panther_config['o_attachment_extensions']),
	'{extensions}' => $lang_admin_options['Extensions'],
	'{o_attachment_images}' => panther_htmlspecialchars($panther_config['o_attachment_images']),
	'{icons}' => $lang_admin_options['Icons'],
	'{icon_options}' => $lang_admin_options['Icon options'],
	'{attachment_icon_folder_label}' => $lang_admin_options['Attachment icon folder label'],
	'{o_attachment_icon_path}' => panther_htmlspecialchars($panther_config['o_attachment_icon_path']),
	'{attachment_icon_folder_help}' => $lang_admin_options['Attachment icon folder help'],
	'{attachment_icon_dir_label}' => $lang_admin_options['Attachment icon dir label'],
	'{o_attachment_icon_dir}' => panther_htmlspecialchars($panther_config['o_attachment_icon_dir']),
	'{attachment_icon_dir_help}' => $lang_admin_options['Attachment icon dir help'],
	'{max_attachments_label}' => $lang_admin_options['Max attachments label'],
	'{o_max_upload_size}' => $panther_config['o_max_upload_size'],
	'{max_attachments_help}' => $lang_admin_options['Max attachments help'],
	'{user_ranks_label}' => $lang_admin_options['User ranks label'],
	'{o_ranks_1_checked}' => ($panther_config['o_ranks'] == '1') ? ' checked="checked"' : '',
	'{o_ranks_0_checked}' => ($panther_config['o_ranks'] == '0') ? ' checked="checked"' : '',
	'{user_ranks_help}' => sprintf($lang_admin_options['User ranks help'], '<a href="'.panther_link($panther_url['admin_ranks']).'">'.$lang_admin_common['Ranks'].'</a>'),
	'{polls_label}' => $lang_admin_options['Polls label'],
	'{o_polls_1_checked}' => ($panther_config['o_polls'] == '1') ? ' checked="checked"' : '',
	'{o_polls_0_checked}' => ($panther_config['o_polls'] == '0') ? ' checked="checked"' : '',
	'{polls_help}' => $lang_admin_options['Polls help'],
	'{polls_max_label}' => $lang_admin_options['Polls max label'],
	'{o_max_poll_fields}' => $panther_config['o_max_poll_fields'],
	'{polls_max_help}' => $lang_admin_options['Polls max help'],
	'{reputation_label}' => $lang_admin_options['Reputation label'],
	'{o_reputation_1_checked}' => ($panther_config['o_reputation'] == '1') ? ' checked="checked"' : '',
	'{o_reputation_0_checked}' => ($panther_config['o_reputation'] == '0') ? ' checked="checked"' : '',
	'{reputation_help}' => $lang_admin_options['Reputation help'],
	'{rep_type_label}' => $lang_admin_options['Rep type label'],
	'{o_rep_type_1_selected}' => ($panther_config['o_rep_type'] == '1') ? ' selected="selected"' : '',
	'{positive_and_negative}' => $lang_admin_options['Positive and negative'],
	'{o_rep_type_2_selected}' => ($panther_config['o_rep_type'] == '2') ? ' selected="selected"' : '',
	'{positive_only}' => $lang_admin_options['Positive only'],
	'{o_rep_type_3_selected}' => ($panther_config['o_rep_type'] == '3') ? ' selected="selected"' : '',
	'{negative_only}' => $lang_admin_options['Negative only'],
	'{rep_type_help}' => $lang_admin_options['Rep type help'],
	'{rep_abuse_label}' => $lang_admin_options['Rep abuse label'],
	'{o_rep_abuse}' => $panther_config['o_rep_abuse'],
	'{rep_abuse_help}' => $lang_admin_options['Rep abuse help'],
	'{pm_label}' => $lang_admin_options['PM label'],
	'{o_private_messaging_1_checked}' => ($panther_config['o_private_messaging'] == '1') ? ' checked="checked"' : '',
	'{o_private_messaging_0_checked}' => ($panther_config['o_private_messaging'] == '0') ? ' checked="checked"' : '',
	'{pm_help}' => $lang_admin_options['PM help'],
	'{pm_receiver_label}' => $lang_admin_options['PM receiver label'],
	'{o_max_pm_receivers}' => $panther_config['o_max_pm_receivers'],
	'{pm_receiver_help}' => $lang_admin_options['PM receiver help'],
	'{user_has_posted_label}' => $lang_admin_options['User has posted label'],
	'{o_show_dot_1_checked}' => ($panther_config['o_show_dot'] == '1') ? ' checked="checked"' : '',
	'{o_show_dot_0_checked}' => ($panther_config['o_show_dot'] == '0') ? ' checked="checked"' : '',
	'{user_has_posted_help}' => $lang_admin_options['User has posted help'],
	'{login_queue_label}' => $lang_admin_options['Login queue label'],
	'{o_login_queue_1_checked}' => ($panther_config['o_login_queue'] == '1') ? ' checked="checked"' : '',
	'{o_login_queue_0_checked}' => ($panther_config['o_login_queue'] == '0') ? ' checked="checked"' : '',
	'{login_queue_help}' => $lang_admin_options['Login queue help'],
	'{queue_size_label}' => $lang_admin_options['Queue size label'],
	'{o_queue_size}' => $panther_config['o_queue_size'],
	'{queue_size_help}' => $lang_admin_options['Queue size help'],
	'{max_attempts_label}' => $lang_admin_options['Max attempts label'],
	'{o_max_attempts}' => $panther_config['o_max_attempts'],
	'{max_attempts_help}' => $lang_admin_options['Max attempts help'],
	'{update_type_label}' => $lang_admin_options['Update type label'],
	'{neither}' => $lang_admin_options['Neither'],
	'{install_only}' => $lang_admin_options['Install only'],
	'{download_only}' => $lang_admin_options['Download only'],
	'{download_and_install}' => $lang_admin_options['Download and install'],
	'{neither}' => $lang_admin_options['Neither'],
	'{neither}' => $lang_admin_options['Neither'],
	'{o_update_type_0_selected}' => ($panther_config['o_update_type'] == '0') ? ' selected="selected"' : '',
	'{o_update_type_1_selected}' => ($panther_config['o_update_type'] == '1') ? ' selected="selected"' : '',
	'{o_update_type_2_selected}' => ($panther_config['o_update_type'] == '2') ? ' selected="selected"' : '',
	'{o_update_type_3_selected}' => ($panther_config['o_update_type'] == '3') ? ' selected="selected"' : '',
	'{update_type_help}' => $lang_admin_options['Update type help'],
	'{debug_mode_label}' => $lang_admin_options['Debug mode label'],
	'{o_debug_mode_1_checked}' => ($panther_config['o_debug_mode'] == '1') ? ' checked="checked"' : '',
	'{o_debug_mode_0_checked}' => ($panther_config['o_debug_mode'] == '0') ? ' checked="checked"' : '',
	'{debug_mode_help}' => $lang_admin_options['Debug mode help'],
	'{show_queries_label}' => $lang_admin_options['Show queries label'],
	'{o_show_queries_1_checked}' => ($panther_config['o_show_queries'] == '1') ? ' checked="checked"' : '',
	'{o_show_queries_0_checked}' => ($panther_config['o_show_queries'] == '0') ? ' checked="checked"' : '',
	'{show_queries_help}' => $lang_admin_options['Show queries help'],
	'{topic_views_label}' => $lang_admin_options['Topic views label'],
	'{o_topic_views_1_checked}' => ($panther_config['o_topic_views'] == '1') ? ' checked="checked"' : '',
	'{o_topic_views_0_checked}' => ($panther_config['o_topic_views'] == '0') ? ' checked="checked"' : '',
	'{topic_views_help}' => $lang_admin_options['Topic views help'],
	'{quick_jump_label}' => $lang_admin_options['Quick jump label'],
	'{o_quickjump_1_checked}' => ($panther_config['o_quickjump'] == '1') ? ' checked="checked"' : '',
	'{o_quickjump_0_checked}' => ($panther_config['o_quickjump'] == '0') ? ' checked="checked"' : '',
	'{quick_jump_help}' => $lang_admin_options['Quick jump help'],
	'{gzip_label}' => $lang_admin_options['GZip label'],
	'{o_gzip_1_checked}' => ($panther_config['o_gzip'] == '1') ? ' checked="checked"' : '',
	'{o_gzip_0_checked}' => ($panther_config['o_gzip'] == '0') ? ' checked="checked"' : '',
	'{gzip_help}' => $lang_admin_options['GZip help'],
	'{search_all_label}' => $lang_admin_options['Search all label'],
	'{o_search_all_forums_1_checked}' => ($panther_config['o_search_all_forums'] == '1') ? ' checked="checked"' : '',
	'{o_search_all_forums_0_checked}' => ($panther_config['o_search_all_forums'] == '0') ? ' checked="checked"' : '',
	'{search_all_help}' => $lang_admin_options['Search all help'],
	'{task_type_label}' => $lang_admin_options['Task type label'],
	'{o_task_type_1_checked}' => ($panther_config['o_task_type'] == '1') ? ' checked="checked"' : '',
	'{o_task_type_0_checked}' => ($panther_config['o_task_type'] == '0') ? ' checked="checked"' : '',
	'{task_type_help}' => sprintf($lang_admin_options['Task type help'], panther_link($panther_url['admin_tasks'])),
	'{sfs_api_key}' => $lang_admin_options['SFS api key'],
	'{o_sfs_api}' => panther_htmlspecialchars($panther_config['o_sfs_api']),
	'{sfs_api_key_help}' => $lang_admin_options['SFS api key help'],
	'{tinypng_api}' => $lang_admin_options['Tinypng api'],
	'{o_tinypng_api}' => panther_htmlspecialchars($panther_config['o_tinypng_api']),
	'{tinypng_api_help}' => $lang_admin_options['Tinypng api help'],
	'{cloudflare_api}' => $lang_admin_options['Cloudflare api'],
	'{o_cloudflare_api}' => panther_htmlspecialchars($panther_config['o_cloudflare_api']),
	'{cloudflare_api_help}' => $lang_admin_options['Cloudflare api help'],
	'{cloudflare_email_label}' => $lang_admin_options['Cloudflare email label'],
	'{o_cloudflare_email}' => panther_htmlspecialchars($panther_config['o_cloudflare_email']),
	'{cloudflare_email_help}' => $lang_admin_options['Cloudflare email help'],
	'{cloudflare_domain_label}' => $lang_admin_options['Cloudflare domain label'],
	'{o_cloudflare_domain}' => panther_htmlspecialchars($panther_config['o_cloudflare_domain']),
	'{cloudflare_domain_help}' => $lang_admin_options['Cloudflare domain help'],
	'{menu_items_label}' => $lang_admin_options['Menu items label'],
	'{o_additional_navlinks}' => panther_htmlspecialchars($panther_config['o_additional_navlinks']),
	'{menu_items_help}' => $lang_admin_options['Menu items help'],
	'{feed_subhead}' => $lang_admin_options['Feed subhead'],
	'{default_feed_label}' => $lang_admin_options['Default feed label'],
	'{o_feed_type_0_checked}' => ($panther_config['o_feed_type'] == '0') ? ' checked="checked"' : '',
	'{none}' => $lang_admin_options['None'],
	'{o_feed_type_1_checked}' => ($panther_config['o_feed_type'] == '1') ? ' checked="checked"' : '',
	'{rss}' => $lang_admin_options['RSS'],
	'{o_feed_type_2_checked}' => ($panther_config['o_feed_type'] == '2') ? ' checked="checked"' : '',
	'{atom}' => $lang_admin_options['Atom'],
	'{default_feed_help}' => $lang_admin_options['Default feed help'],
	'{feed_ttl_label}' => $lang_admin_options['Feed TTL label'],
	'{o_feed_ttl_0_selected}' => ($panther_config['o_feed_ttl'] == '0') ? ' selected="selected"' : '',
	'{no_cache}' => $lang_admin_options['No cache'],
	'{o_feed_ttl}' => count($feed_options) ? implode("\n", $feed_options) : '',
	'{feed_ttl_help}' => $lang_admin_options['Feed TTL help'],
	'{reports_subhead}' => $lang_admin_options['Reports subhead'],
	'{reporting_method_label}' => $lang_admin_options['Reporting method label'],
	'{o_report_method_0_checked}' => ($panther_config['o_report_method'] == '0') ? ' checked="checked"' : '',
	'{internal}' => $lang_admin_options['Internal'],
	'{o_report_method_1_checked}' => ($panther_config['o_report_method'] == '1') ? ' checked="checked"' : '',
	'{by_email}' => $lang_admin_options['By e-mail'],
	'{o_report_method_2_checked}' => ($panther_config['o_report_method'] == '2') ? ' checked="checked"' : '',
	'{both}' => $lang_admin_options['Both'],
	'{reporting_method_help}' => $lang_admin_options['Reporting method help'],
	'{mailing_list_label}' => $lang_admin_options['Mailing list label'],
	'{o_mailing_list}' => panther_htmlspecialchars($panther_config['o_mailing_list']),
	'{mailing_list_help}' => $lang_admin_options['Mailing list help'],
	'{avatars_subhead}' => $lang_admin_options['Avatars subhead'],
	'{use_avatars_label}' => $lang_admin_options['Use avatars label'],
	'{o_avatars_1_checked}' => ($panther_config['o_avatars'] == '1') ? ' checked="checked"' : '',
	'{o_avatars_0_checked}' => ($panther_config['o_avatars'] == '0') ? ' checked="checked"' : '',
	'{use_avatars_help}' => $lang_admin_options['Use avatars help'],
	'{avatar_upload_label}' => $lang_admin_options['Avatar upload label'],
	'{o_avatar_upload_1_checked}' => ($panther_config['o_avatar_upload'] == '1') ? ' checked="checked"' : '',
	'{o_avatar_upload_0_checked}' => ($panther_config['o_avatar_upload'] == '0') ? ' checked="checked"' : '',
	'{avatar_upload_help}' => $lang_admin_options['Avatar upload help'],
	'{avatars_path_label}' => $lang_admin_options['Avatars path label'],
	'{o_avatars_path}' => panther_htmlspecialchars($panther_config['o_avatars_path']),
	'{avatars_pat_help}' => $lang_admin_options['Avatars path help'],
	'{upload_directory_label}' => $lang_admin_options['Upload directory label'],
	'{o_avatars_dir}' => panther_htmlspecialchars($panther_config['o_avatars_dir']),
	'{upload_directory_help}' => $lang_admin_options['Upload directory help'],
	'{o_avatars_width}' => $panther_config['o_avatars_width'],
	'{max_width_help}' => $lang_admin_options['Max width help'],
	'{o_avatars_height}' => $panther_config['o_avatars_height'],
	'{max_height_help}' => $lang_admin_options['Max height help'],
	'{o_avatars_size}' => $panther_config['o_avatars_size'],
	'{max_size_help}' => $lang_admin_options['Max size help'],
	'{email_subhead}' => $lang_admin_options['E-mail subhead'],
	'{email_name_label}' => $lang_admin_options['E-mail name label'],
	'{o_email_name}' => panther_htmlspecialchars($panther_config['o_email_name']),
	'{email_name_help}' => $lang_admin_options['E-mail name help'],
	'{admin_email_label}' => $lang_admin_options['Admin e-mail label'],
	'{o_admin_email}' => panther_htmlspecialchars($panther_config['o_admin_email']),
	'{admin_email_help}' => $lang_admin_options['Admin e-mail help'],
	'{webmaster_email_label}' => $lang_admin_options['Webmaster e-mail label'],
	'{o_webmaster_email}' => panther_htmlspecialchars($panther_config['o_webmaster_email']),
	'{webmaster_email_help}' => $lang_admin_options['Webmaster e-mail help'],
	'{forum_subscriptions_label}' => $lang_admin_options['Forum subscriptions label'],
	'{o_forum_subscriptions_1_checked}' => ($panther_config['o_forum_subscriptions'] == '1') ? ' checked="checked"' : '',
	'{o_forum_subscriptions_0_checked}' => ($panther_config['o_forum_subscriptions'] == '0') ? ' checked="checked"' : '',
	'{forum_subscriptions_help}' => $lang_admin_options['Forum subscriptions help'],
	'{topic_subscriptions_label}' => $lang_admin_options['Topic subscriptions label'],
	'{o_topic_subscriptions_1_checked}' => ($panther_config['o_topic_subscriptions'] == '1') ? ' checked="checked"' : '',
	'{o_topic_subscriptions_0_checked}' => ($panther_config['o_topic_subscriptions'] == '0') ? ' checked="checked"' : '',
	'{topic_subscriptions_help}' => $lang_admin_options['Topic subscriptions help'],
	'{smtp_address_label}' => $lang_admin_options['SMTP address label'],
	'{o_smtp_host}' => panther_htmlspecialchars($panther_config['o_smtp_host']),
	'{smtp_address_help}' => $lang_admin_options['SMTP address help'],
	'{smtp_username_label}' => $lang_admin_options['SMTP username label'],
	'{o_smtp_user}' => panther_htmlspecialchars($panther_config['o_smtp_user']),
	'{smtp_username_help}' => $lang_admin_options['SMTP username help'],
	'{smtp_password_label}' => $lang_admin_options['SMTP password label'],
	'{smtp_change_password_help}' => $lang_admin_options['SMTP change password help'],
	'{smtp_pass}' => $smtp_pass,
 	'{smtp_password_help}' => $lang_admin_options['SMTP password help'],
	'{smtp_ssl_label}' => $lang_admin_options['SMTP SSL label'],
	'{o_smtp_ssl_1_checked}' => ($panther_config['o_smtp_ssl'] == '1') ? ' checked="checked"' : '',
	'{o_smtp_ssl_0_checked}' => ($panther_config['o_smtp_ssl'] == '0') ? ' checked="checked"' : '',
	'{smtp_ssl_help}' => $lang_admin_options['SMTP SSL help'],
	'{registration_subhead}' => $lang_admin_options['Registration subhead'],
	'{allow_new_label}' => $lang_admin_options['Allow new label'],
	'{o_regs_allow_1_checked}' => ($panther_config['o_regs_allow'] == '1') ? ' checked="checked"' : '',
	'{o_regs_allow_0_checked}' => ($panther_config['o_regs_allow'] == '0') ? ' checked="checked"' : '',
	'{allow_new_help}' => $lang_admin_options['Allow new help'],
	'{verify_label}' => $lang_admin_options['Verify label'],
	'{o_regs_verify_1_checked}' => ($panther_config['o_regs_verify'] == '1') ? ' checked="checked"' : '',
	'{o_regs_verify_0_checked}' => ($panther_config['o_regs_verify'] == '0') ? ' checked="checked"' : '',
	'{verify_help}' => $lang_admin_options['Verify help'],
	'{report_new_label}' => $lang_admin_options['Report new label'],
	'{o_regs_report_1_checked}' => ($panther_config['o_regs_report'] == '1') ? ' checked="checked"' : '',
	'{o_regs_report_0_checked}' => ($panther_config['o_regs_report'] == '0') ? ' checked="checked"' : '',
	'{report_new_help}' => $lang_admin_options['Report new help'],
	'{use_rules_label}' => $lang_admin_options['Use rules label'],
	'{o_rules_1_checked}' => ($panther_config['o_rules'] == '1') ? ' checked="checked"' : '',
	'{o_rules_0_checked}' => ($panther_config['o_rules'] == '0') ? ' checked="checked"' : '',
	'{use_rules_help}' => $lang_admin_options['Use rules help'],
	'{rules_label}' => $lang_admin_options['Rules label'],
	'{o_rules_message}' => panther_htmlspecialchars($panther_config['o_rules_message']),
	'{rules_help}' => $lang_admin_options['Rules help'],
	'{email_default_label}' => $lang_admin_options['E-mail default label'],
	'{email_default_help}' => $lang_admin_options['E-mail default help'],
	'{o_default_email_setting_0_checked}' => ($panther_config['o_default_email_setting'] == '0') ? ' checked="checked"' : '',
	'{default_email_label}' => $lang_admin_options['Display e-mail label'],
	'{o_default_email_setting_1_checked}' => ($panther_config['o_default_email_setting'] == '1') ? ' checked="checked"' : '',
	'{hide_allow_form_label}' => $lang_admin_options['Hide allow form label'],
	'{o_default_email_setting_2_checked}' => ($panther_config['o_default_email_setting'] == '2') ? ' checked="checked"' : '',
	'{hide_both_label}' => $lang_admin_options['Hide both label'],
	'{announcement_subhead}' => $lang_admin_options['Announcement subhead'],
	'{display_announcement_label}' => $lang_admin_options['Display announcement label'],
	'{o_announcement_1_checked}' => ($panther_config['o_announcement'] == '1') ? ' checked="checked"' : '',
	'{o_announcement_0_checked}' => ($panther_config['o_announcement'] == '0') ? ' checked="checked"' : '',
	'{display_announcement_help}' => $lang_admin_options['Display announcement help'],
	'{announcement_message_label}' => $lang_admin_options['Announcement message label'],
	'{o_announcement_message}' => panther_htmlspecialchars($panther_config['o_announcement_message']),
	'{announcement_message_help}' => $lang_admin_options['Announcement message help'],
	'{maintenance_subhead}' => $lang_admin_options['Maintenance subhead'],
	'{maintenance_mode_label}' => $lang_admin_options['Maintenance mode label'],
	'{o_maintenance_1_checked}' => ($panther_config['o_maintenance'] == '1') ? ' checked="checked"' : '',
	'{o_maintenance_0_checked}' => ($panther_config['o_maintenance'] == '0') ? ' checked="checked"' : '',
	'{maintenance_mode_help}' => $lang_admin_options['Maintenance mode help'],
	'{maintenance_message_label}' => $lang_admin_options['Maintenance message label'],
	'{o_maintenance_message}' => panther_htmlspecialchars($panther_config['o_maintenance_message']),
	'{maintenance_message_help}' => $lang_admin_options['Maintenance message help']
);

echo str_replace(array_keys($search), array_values($search), $admin_tpl);
require PANTHER_ROOT.'footer.php';