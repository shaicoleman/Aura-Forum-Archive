<?php
/**
 * Copyright (C) 2015 Panther (https://www.pantherforum.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

// Tell header.php to use the admin template
define('PANTHER_ADMIN_CONSOLE', 1);

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/../');
	require PANTHER_ROOT.'include/common.php';
}
require PANTHER_ROOT.'include/common_admin.php';

if (!$panther_user['is_admin'])
	message($lang_common['No permission'], false, '403 Forbidden');

if ($panther_user['id'] != '2')
{
	if(!is_null($admins[$panther_user['id']]['admin_ranks']))
	{
		if ($admins[$panther_user['id']]['admin_ranks'] == '0')
			message($lang_common['No permission'], false, '403 Forbidden');
	}
}

check_authentication();

// Load the admin_ranks.php language file
require PANTHER_ROOT.'lang/'.$admin_language.'/admin_ranks.php';

// Add a rank
if (isset($_POST['add_rank']))
{
	confirm_referrer(PANTHER_ADMIN_DIR.'/ranks.php');

	$rank = panther_trim($_POST['new_rank']);
	$min_posts = panther_trim($_POST['new_min_posts']);

	if ($rank == '')
		message($lang_admin_ranks['Must enter title message']);

	if ($min_posts == '' || preg_match('%[^0-9]%', $min_posts))
		message($lang_admin_ranks['Must be integer message']);

	// Make sure there isn't already a rank with the same min_posts value
	$data = array(
		':posts'	=>	$min_posts,
	);
	$ps = $db->select('ranks', 1, $data, 'min_posts=:posts');
	if ($ps->rowCount())
		message(sprintf($lang_admin_ranks['Dupe min posts message'], $min_posts));
	
	$insert = array(
		'rank'	=>	$rank,
		'min_posts'	=>	$min_posts,
	);

	$db->insert('ranks', $insert);

	// Regenerate the ranks cache
	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PANTHER_ROOT.'include/cache.php';

	generate_ranks_cache();
	redirect(panther_link($panther_url['admin_ranks']), $lang_admin_ranks['Rank added redirect']);
}

// Update a rank
else if (isset($_POST['update']))
{
	confirm_referrer(PANTHER_ADMIN_DIR.'/ranks.php');

	$id = intval(key($_POST['update']));

	$rank = panther_trim($_POST['rank'][$id]);
	$min_posts = panther_trim($_POST['min_posts'][$id]);

	if ($rank == '')
		message($lang_admin_ranks['Must enter title message']);

	if ($min_posts == '' || preg_match('%[^0-9]%', $min_posts))
		message($lang_admin_ranks['Must be integer message']);

	// Make sure there isn't already a rank with the same min_posts value
	$data = array(
		':id'	=>	$id,
		':posts'	=>	$min_posts,
	);

	$ps = $db->select('ranks', 1, $data, 'id!=:id AND min_posts=:posts');
	if ($ps->rowCount())
		message(sprintf($lang_admin_ranks['Dupe min posts message'], $min_posts));

	$update = array(
		'rank'	=>	$rank,
		'min_posts'	=>	$min_posts,
	);
	
	$data = array(
		':id'	=>	$id,
	);

	$db->update('ranks', $update, 'id=:id', $data);

	// Regenerate the ranks cache
	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PANTHER_ROOT.'include/cache.php';

	generate_ranks_cache();
	redirect(panther_link($panther_url['admin_ranks']), $lang_admin_ranks['Rank updated redirect']);
}

// Remove a rank
else if (isset($_POST['remove']))
{
	confirm_referrer(PANTHER_ADMIN_DIR.'/ranks.php');

	$id = intval(key($_POST['remove']));
	$data = array(
		':id'	=>	$id,
	);

	$db->delete('ranks', 'id=:id', $data);

	// Regenerate the ranks cache
	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PANTHER_ROOT.'include/cache.php';

	generate_ranks_cache();
	redirect(panther_link($panther_url['admin_ranks']), $lang_admin_ranks['Rank removed redirect']);
}

$ps = $db->select('ranks', 'id, rank, min_posts', array(), '', 'min_posts');

$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_admin_common['Admin'], $lang_admin_common['Ranks']);
$focus_element = array('ranks', 'new_rank');
define('PANTHER_ACTIVE_PAGE', 'admin');
require PANTHER_ROOT.'header.php';

generate_admin_menu('ranks');
if ($ps->rowCount())
{
	$ranks = array();
	$ranks_list_tpl = panther_template('ranks_row.tpl');
	foreach ($ps as $cur_rank)
	{
		$search = array(
			'{rank_id}' => $cur_rank['id'],
			'{rank}' => panther_htmlspecialchars($cur_rank['rank']),
			'{min_posts}' => $cur_rank['min_posts'],
			'{update}' => $lang_admin_common['Update'],
			'{remove}' => $lang_admin_common['Remove'],
		);

		$ranks[] = str_replace(array_keys($search), array_values($search), $ranks_list_tpl);
	}

	$ranks_tpl = panther_template('censoring_results.tpl');
	$search = array(
		'{censored_word}' => $lang_admin_ranks['Rank title label'],
		'{replacement_word}' => $lang_admin_ranks['Minimum posts label'],
		'{censoring_results}' => implode("\n", $ranks),
		'{action_label}' => $lang_admin_ranks['Actions label'],
	);

	$ranks_list_tpl = str_replace(array_keys($search), array_values($search), $ranks_tpl);
}
else
	$ranks_list_tpl = "\t\t\t\t\t\t\t".'<p>'.$lang_admin_ranks['No ranks in list'].'</p>'."\n";

// Re-use the admin_censoring template (it's the same design anyway)
$admin_tpl = panther_template('admin_censoring.tpl');
$search = array(
	'{censoring_head}' => $lang_admin_ranks['Ranks head'],
	'{form_action}' => panther_link($panther_url['admin_ranks']),
	'{csrf_token}' => generate_csrf_token(PANTHER_ADMIN_DIR.'/ranks.php'),
	'{add_word_subhead}' => $lang_admin_ranks['Add rank subhead'],
	'{censoring_info}' => $lang_admin_ranks['Add rank info'].' '.($panther_config['o_ranks'] == '1' ? sprintf($lang_admin_ranks['Ranks enabled'], '<a href="'.panther_link($panther_url['admin_options']).'">'.$lang_admin_common['Options'].'</a>') : sprintf($lang_admin_ranks['Ranks disabled'], '<a href="'.panther_link($panther_url['admin_options']).'">'.$lang_admin_common['Options'].'</a>')),
	'{censored_word}' => $lang_admin_ranks['Rank title label'],
	'{replacement_word}' => $lang_admin_ranks['Minimum posts label'],
	'{action_label}' => $lang_admin_ranks['Actions label'],
	'{add_word}' => $lang_admin_common['Add'],
	'{edit_remove_subhead}' => $lang_admin_ranks['Edit remove subhead'],
	'{censoring_list}' => $ranks_list_tpl,
	'{new_search_for}' => 'new_rank',
	'{new_replace_with}' => 'new_min_posts',
	'{add_word_field}' => 'add_rank',
);

echo str_replace(array_keys($search), array_values($search), $admin_tpl);
require PANTHER_ROOT.'footer.php';