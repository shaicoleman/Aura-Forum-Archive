<?php
/**
 * Copyright (C) 2015 Panther (https://www.pantherforum.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

// Tell header.php to use the admin template
define('PANTHER_ADMIN_CONSOLE', 1);

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/../');
	require PANTHER_ROOT.'include/common.php';
}
require PANTHER_ROOT.'include/common_admin.php';

if (!$panther_user['is_admin'])
	message($lang_common['No permission'], false, '403 Forbidden');

if ($panther_user['id'] != '2')
{
	if(!is_null($admins[$panther_user['id']]['admin_archive']))
	{
		if ($admins[$panther_user['id']]['admin_archive'] == '0')
			message($lang_common['No permission'], false, '403 Forbidden');
	}
}

check_authentication();

// Load the admin_ranks.php language file
require PANTHER_ROOT.'lang/'.$admin_language.'/admin_archive.php';

$ps = $db->select('topics', 'COUNT(id)', array(), 'deleted=0 AND approved=1');
$total = $ps->fetchColumn();

$ps = $db->select('topics', 'COUNT(id)', array(), 'archived=1 AND deleted=0 AND approved=1');
$archived = $ps->fetchColumn();

if (isset($_POST['form_sent']))
{
	confirm_referrer(PANTHER_ADMIN_DIR.'/archive.php');
	$units = array($lang_common['Days'], $lang_common['Months'], $lang_common['Years']);	// Set an array of valid time expiration strings

	$time = isset($_POST['time']) ? intval($_POST['time']) : 0;
	$unit = isset($_POST['unit']) && in_array($_POST['unit'], $units) ? panther_trim($_POST['unit']) : $lang_common['Days'];
	$closed = isset($_POST['closed']) ? intval($_POST['closed']) : 0;
	$sticky = isset($_POST['sticky']) ? intval($_POST['sticky']) : 0;
	$forums = isset($_POST['forums']) && is_array($_POST['forums']) ? array_map('intval', $_POST['forums']) : array(0);

	if (in_array(0, $forums) && count($forums) > 1)
		message($lang_admin_archive['All forums message']);

	if ($sticky > 2 || $sticky < 0 || $closed > 2 || $closed < 0)
		message($lang_admin_archive['Open/close message']);
	
	if ($time < 1)
		message(sprintf($lang_admin_archive['Invalid time value'], strtolower($unit)));

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PANTHER_ROOT.'include/cache.php';

	$rules = array(
		'closed'	=>	$closed,
		'sticky'	=>	$sticky,
		'time'		=>	$time,
		'unit'		=>	$unit,
		'forums'	=>	$forums,
	);

	$topics = check_archive_rules($rules);
	$percentage = 0;
	if ($topics['count'] != 0 && $panther_config['o_archiving'] == '1')
	{
		$markers = $data = array();
		for ($i = 0; $i < count($topics['topics']); $i++)
		{
			$markers[] = '?';
			$data[] = $topics['topics'][$i];
		}

		$db->run('UPDATE '.$db->prefix.'topics SET archived=1 WHERE id IN ('.implode(',', $markers).')', $data);
		$percentage = round(($topics['count']/$total)*100, 2);
	}

	$update = array(
		'conf_value'	=>	serialize($rules),
	);

	$data = array(
		':conf_name'	=>	'o_archive_rules',
	);

	$db->update('config', $update, 'conf_name=:conf_name', $data);
	generate_config_cache();

	$redirect_lang ($panther_config['o_archiving'] == '1') ? sprintf($lang_admin_archive['Archive rules updated'], $topics['count'], $total, $percentage.'%') : $lang_admin_archive['Updated redirect'];
	redirect(panther_link($panther_url['admin_archive']), $redirect_lang);
}

$archive_rules = ($panther_config['o_archive_rules'] != '') ? unserialize($panther_config['o_archive_rules']) : array('closed'	=>	0, 'sticky'	=>	0, 'time'	=>	0, 'unit'	=>	$lang_admin_archive['Days'], 'forums'	=>	array(0));
$percentage = ($ps->rowCount() != 0) ? round(($archived/$total)*100, 2) : 0;

$select = '';
$ps = $db->run('SELECT c.id AS cid, c.cat_name, f.id AS fid, f.forum_name FROM '.$db->prefix.'categories AS c INNER JOIN '.$db->prefix.'forums AS f ON c.id=f.cat_id WHERE f.redirect_url IS NULL ORDER BY c.disp_position, c.id, f.disp_position');
if ($ps->rowCount())
{
	$count = 0;
	$cur_index = 4;
	$cur_category = 0;
	foreach ($ps as $cur_forum)
	{
		if ($cur_forum['cid'] != $cur_category) // A new category since last iteration?
		{
			$select .= '</optgroup>';
			$select .= "\t\t\t\t\t\t".'<optgroup label="'.panther_htmlspecialchars($cur_forum['cat_name']).'">'."\n";
			$cur_category = $cur_forum['cid'];
		}
			$select .= '<option value="'.$cur_forum['fid'].'"'.((in_array($cur_forum['fid'], $archive_rules['forums'])) ? ' selected="selected"' : null).'>'.panther_htmlspecialchars($cur_forum['forum_name']).'</option>'."\n";
	}
		$select .= "\t\t\t\t\t\t".'</optgroup>'."\n\t\t\t\t\t".'</select>'."\n";
}
	
$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_admin_common['Admin'], $lang_admin_common['Archive']);
$focus_element = array('ranks', 'new_rank');
define('PANTHER_ACTIVE_PAGE', 'admin');
require PANTHER_ROOT.'header.php';

generate_admin_menu('archive');

$archive_tpl = panther_template('admin_archive.tpl');
$search = array(
	'{options}' => $lang_admin_archive['Options'],
	'{form_action}' => panther_link($panther_url['admin_archive']),
	'{csrf_token}' => generate_csrf_token(PANTHER_ADMIN_DIR.'/archive.php'),
	'{archive_overview}' => $lang_admin_archive['Archive overview'],
	'{archive_available}' => sprintf($lang_admin_archive['Archive available'], ($panther_config['o_archiving'] == '1' ? $lang_admin_archive['Archive enabled'] : $lang_admin_archive['Archive disabled']), panther_link($panther_url['admin_options'])),
	'{archive_info}' => sprintf($lang_admin_archive['Archive info'], $archived, $percentage.'%'),
	'{closed_topics}' => $lang_admin_archive['Closed topics'],
	'{closed_open_selected}' => ($archive_rules['closed'] == '2') ? ' selected="selected"' : '',
	'{closed_open}' => $lang_admin_archive['Closed or open'],
	'{closed_selected}' => ($archive_rules['closed'] == '1') ? ' selected="selected"' : '',
	'{closed}' => $lang_admin_archive['Closed'],
	'{open_selected}' => ($archive_rules['closed'] == '0') ? ' selected="selected"' : '',
	'{open}' => $lang_admin_archive['Open'],
	'{closed_topics_help}' => $lang_admin_archive['Closed topics help'],
	'{sticky_topics}' => $lang_admin_archive['Sticky topics'],
	'{sticky_unsticky_selected}' => ($archive_rules['sticky'] == '2') ? ' selected="selected"' : '',
	'{sticky_unsticky}' => $lang_admin_archive['Sticky or unsticky'],
	'{sticky_selected}' => ($archive_rules['sticky'] == '1') ? ' selected="selected"' : '',
	'{sticky}' => $lang_admin_archive['Sticky'],
	'{unsticky_selected}' => ($archive_rules['sticky'] == '0') ? ' selected="selected"' : '',
	'{unsticky}' => $lang_admin_archive['Unsticky'],
	'{sticky_help}' => $lang_admin_archive['Sticky topics help'],
	'{forums}' => $lang_admin_archive['Forums'],
	'{all_forums_selected}' => ($archive_rules['forums'][0] == '0') ? ' selected="selected"' : '',
	'{all_forums}' => $lang_admin_archive['All forums'],
	'{forum_options}' => $select,
	'{forum_help}' => $lang_admin_archive['Forums help'],
	'{archive_unit}' => $lang_admin_archive['Archive unit'],
	'{archive_time}' => $archive_rules['time'],
	'{days}' => $lang_common['Days'],
	'{months}' => $lang_common['Months'],
	'{years}' => $lang_common['Years'],
	'{days_selected}' => ($archive_rules['unit'] == $lang_common['Days']) ? ' selected="selected"' : '',
	'{months_selected}' => ($archive_rules['unit'] == $lang_common['Months']) ? 'selected="selected" ' : '',
	'{years_selected}' => ($archive_rules['unit'] == $lang_common['Years']) ? 'selected="selected" ' : '',
	'{save_changes}' => $lang_admin_common['Save changes'],
);

echo str_replace(array_keys($search), array_values($search), $archive_tpl);
require PANTHER_ROOT.'footer.php';