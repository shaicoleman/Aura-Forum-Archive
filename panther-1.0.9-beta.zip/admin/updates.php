<?php
/**
 * Copyright (C) 2015 Panther (https://www.pantherforum.org)
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

// Tell header.php to use the admin template
define('PANTHER_ADMIN_CONSOLE', 1);
define('JQUERY_REQUIRED', 1);

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/../');
	require PANTHER_ROOT.'include/common.php';
}
require PANTHER_ROOT.'include/common_admin.php';

if (!$panther_user['is_admin'])
	message($lang_common['No permission'], false, '403 Forbidden');

if ($panther_user['id'] != '2')
{
	if(!is_null($admins[$panther_user['id']]['admin_updates']))
	{
		if ($admins[$panther_user['id']]['admin_updates'] == '0')
			message($lang_common['No permission'], false, '403 Forbidden');
	}
}

check_authentication();

// Load the admin_update.php language file
require PANTHER_ROOT.'lang/'.$admin_language.'/admin_update.php';

if (version_compare($panther_config['o_cur_version'], $updater->panther_updates['version'], '>='))
	message($lang_admin_update['no updates']);

$action = isset($_GET['action']) ? panther_htmlspecialchars($_GET['action']) : '';
if ($action == 'install_update')
{
	$updater->download(false);
	$updater->install();
	exit;
}

$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_admin_common['Admin'], $lang_admin_common['Update']);
define('PANTHER_ACTIVE_PAGE', 'admin');
require PANTHER_ROOT.'header.php';

generate_admin_menu('updates');
?>
<script>
$(document).ready(function()
{
	$("#ajax_submit").click(function()
	{
		$.ajaxSetup({
			cache: false
		});

		$("#ajax_submit").html('<br /><img src="<?php echo $panther_config['o_image_dir']; ?>preloader.gif" width="40" height="40">');
		$.get("<?php echo panther_link($panther_url['admin_updates']); ?>",
		{
			action: 'install_update'
		},
		function(data, status)
		{
			if (data != '')
			{
				$("#ajax_response").css("color", "red");
				$("#ajax_response").html(data);
				$("#ajax_response").slideDown();
				
			}
			else
			{
				$("#ajax_response").css("color", "green");
				$("#ajax_result").html(data);
				$("#ajax_response").slideDown();
			}
			
			$("#ajax_submit").html('');
			$("#release_notes").slideUp();
		});
	});
	$("#view_changelog").click(function()
	{
		$("#changelog").slideToggle();
		
		var text = $('#changelog_text').text();
		$('#changelog_text').text(
        text == "<?php echo $lang_admin_update['View release notes']; ?>" ? "<?php echo $lang_admin_update['Hide release notes']; ?>" : "<?php echo $lang_admin_update['View release notes']; ?>");
	});
});
</script>
<?php
$admin_tpl = panther_template('admin_updates.tpl');
$search = array(
	'{admin_updates}' => $lang_admin_update['Admin updates'],
	'{information}' => $lang_admin_update['Information'],
	'{update_panther}' => $lang_admin_update['update panther'],
	'{update_succesful}' => $lang_admin_update['Update successful'],
	'{patch}' => $lang_admin_update['Patch'],
	'{version}' => $panther_updates['version'],
	'{release}' => $lang_admin_update['Release'],
	'{released}' => format_time($updater->panther_updates['released']),
	'{changelog}' => $lang_admin_update['Changelog'],
	'{release_notes}' => $lang_admin_update['View release notes'],
	'{version_changelog}' => nl2br($updater->panther_updates['changelog']),
	'{disclaimer}' => $lang_admin_update['Disclaimer'],
	'{install_update}' => $lang_admin_update['Install update'],
);

echo str_replace(array_keys($search), array_values($search), $admin_tpl);
require PANTHER_ROOT.'footer.php';