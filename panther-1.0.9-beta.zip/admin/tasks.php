<?php
/**
 * Copyright (C) 2015 Panther (https://www.pantherforum.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

// Tell header.php to use the admin template
define('PANTHER_ADMIN_CONSOLE', 1);

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/../');
	require PANTHER_ROOT.'include/common.php';
}
require PANTHER_ROOT.'include/common_admin.php';

if (!$panther_user['is_admin'])
	message($lang_common['No permission'], false, '403 Forbidden');

if ($panther_user['id'] != '2')
{
	if(!is_null($admins[$panther_user['id']]['admin_tasks']))
	{
		if ($admins[$panther_user['id']]['admin_tasks'] == '0')
			message($lang_common['No permission'], false, '403 Forbidden');
	}
}

check_authentication();

// Load the admin_tasks.php language file
require PANTHER_ROOT.'lang/'.$admin_language.'/admin_tasks.php';

// Add a task
if (isset($_POST['add_task']))
{
	confirm_referrer(PANTHER_ADMIN_DIR.'/tasks.php');

	$title = isset($_POST['new_task_title']) ? panther_trim($_POST['new_task_title']) : '';
	$minute = isset($_POST['minute']) && $_POST['minute'] != '*' && $_POST['minute'] >= 0 && $_POST['minute'] <= 59 ? intval($_POST['minute']) : '*';
	$hour = isset($_POST['hour']) && $_POST['hour'] != '*' && $_POST['hour'] >= 0 && $_POST['hour'] <= 23 ? intval($_POST['hour']) : '*';
	$day = isset($_POST['day']) && $_POST['day'] != '*' && $_POST['day'] >= 1 && $_POST['day'] <= 31 ? intval($_POST['day']) : '*';
	$month = isset($_POST['month']) && $_POST['month'] != '*' && $_POST['month'] >= 1 && $_POST['month'] <= 12 ? intval($_POST['month']) : '*';
	$week_day = isset($_POST['week_day']) && $_POST['week_day'] != '*' && $_POST['week_day'] >= 0 && $_POST['week_day'] <= 6 ? intval($_POST['week_day']) : '*';
	$script = isset($_POST['script']) ? panther_trim($_POST['script']) : '';

	if (!file_exists(PANTHER_ROOT.'/include/tasks/'.$script.'.php') || !preg_match('/^[a-z-_0-9]+$/i', $script))
		message(sprintf($lang_admin_tasks['Not valid task'], panther_htmlspecialchars($script)));

	if (strlen($title) < 5)
		message($lang_admin_tasks['Too short title']);

	$insert = array(
		'title'	=>	$title,
		'next_run' => $tasks->get_next_run($minute, $hour, $day, $month, $week_day),
		'script' => $script,
		'minute' => $minute,
		'hour' => $hour,
		'day' => $day,
		'month' => $month,
		'week_day' => $week_day,
	);

	$db->insert('tasks', $insert);

	// If we're using proper cron jobs, then set it up
	if ($panther_config['o_task_type'] == '1' && function_exists('exec'))
		exec('echo -e "`crontab -l`\n'.$minute.' '.$hour.' '.$day.' '.$month.' '.$week_day.' '.PANTHER_ROOT.'/include/cron.php'.'" | crontab -');

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PANTHER_ROOT.'include/cache.php';
	
	generate_task_cache();
	redirect(panther_link($panther_url['admin_tasks']), $lang_admin_tasks['Task added redirect']);
}

// Update a task
else if (isset($_POST['update']))
{
	confirm_referrer(PANTHER_ADMIN_DIR.'/tasks.php');
	$id = isset($_POST['id']) ? intval($_POST['id']) : '';

	$title = isset($_POST['task_title']) ? panther_trim($_POST['task_title']) : '';
	$minute = isset($_POST['minute']) && $_POST['minute'] != '*' && $_POST['minute'] >= 0 && $_POST['minute'] <= 59 ? intval($_POST['minute']) : '*';
	$hour = isset($_POST['hour']) && $_POST['hour'] != '*' && $_POST['hour'] >= 0 && $_POST['hour'] <= 23 ? intval($_POST['hour']) : '*';
	$day = isset($_POST['day']) && $_POST['day'] != '*' && $_POST['day'] >= 1 && $_POST['day'] <= 31 ? intval($_POST['day']) : '*';
	$month = isset($_POST['month']) && $_POST['month'] != '*' && $_POST['month'] >= 1 && $_POST['month'] <= 12 ? intval($_POST['month']) : '*';
	$week_day = isset($_POST['week_day']) && $_POST['week_day'] != '*' && $_POST['week_day'] >= 0 && $_POST['week_day'] <= 6 ? intval($_POST['week_day']) : '*';
	$script = isset($_POST['script']) ? panther_trim($_POST['script']) : '';

	if (!file_exists(PANTHER_ROOT.'/include/tasks/'.$script.'.php') || !preg_match('/^[a-z-_0-9]+$/i', $script))
		message(sprintf($lang_admin_tasks['Not valid task'], panther_htmlspecialchars($script)));

	if (strlen($title) < 5)
		message($lang_admin_tasks['Too short title']);

	$data = array(
		':id'	=>	$id,
	);

	$ps = $db->select('tasks', 'minute, hour, day, month, week_day, script', $data, 'id=:id');
	$cur_task = $ps->fetch();

	$update = array(
		'title'	=>	$title,
		'next_run' => $tasks->get_next_run($minute, $hour, $day, $month, $week_day),
		'script' => $script,
		'minute' => $minute,
		'hour' => $hour,
		'day' => $day,
		'month' => $month,
		'week_day' => $week_day,
	);

	$db->update('tasks', $update, 'id=:id', $data);
	if ($panther_config['o_task_type'] == '1' && function_exists('exec'))
	{
		$delete = $cur_task['minute']. ' '.$cur_task['hour'].' '.$cur_task['day'].' '.$cur_task['month'].' '.$cur_task['week_day'].' '.PANTHER_ROOT.'/include/cron.php';
		exec('crontab -l', $cron_jobs);
		$cron = array_search($delete, $cron_jobs);
		if ($cron === false)
			message($lang_admin_tasks['Unable to remove old task']);
		else
		{
			exec('crontab -r');
			unset($cron_jobs[$cron]);
		}

		foreach ($cron_jobs as $cur_job) // We can only remove all cron jobs. So we now need to re-create them all ...
			exec('echo -e "`crontab -l`\n'.$cur_job.'" | crontab -');

		exec('echo -e "`crontab -l`\n'.$minute.' '.$hour.' '.$day.' '.$month.' '.$week_day.' '.PANTHER_ROOT.'/include/cron.php'.'" | crontab -');
	}

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PANTHER_ROOT.'include/cache.php';

	generate_task_cache();
	redirect(panther_link($panther_url['admin_tasks']), $lang_admin_tasks['Task updated redirect']);
}

// Remove a task
else if (isset($_POST['remove']))
{
	confirm_referrer(PANTHER_ADMIN_DIR.'/tasks.php');
	$id = isset($_POST['id']) ? intval($_POST['id']) : '';
	$data = array(
		':id'	=>	$id,
	);

	$ps = $db->select('tasks', 'minute, hour, day, month, week_day, script', $data, 'id=:id');
	$cur_task = $ps->fetch();

	$db->delete('tasks', 'id=:id', $data);
	if ($panther_config['o_task_type'] == '1' && function_exists('exec'))
	{
		$delete = $cur_task['minute']. ' '.$cur_task['hour'].' '.$cur_task['day'].' '.$cur_task['month'].' '.$cur_task['week_day'].' '.PANTHER_ROOT.'/include/cron.php';

		exec('crontab -l', $cron_jobs);
		$cron = array_search($delete, $cron_jobs);
		if ($cron === false)
			message($lang_admin_tasks['Unable to remove']);
		else
		{
			exec('crontab -r');
			unset($cron_jobs[$cron]);
		}

		foreach ($cron_jobs as $cur_job)
			exec('echo -e "`crontab -l`\n'.$cur_job.'" | crontab -');
	}

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PANTHER_ROOT.'include/cache.php';

	generate_task_cache();
	redirect(panther_link($panther_url['admin_tasks']),  $lang_admin_tasks['Task removed redirect']);
}
// Upload a task
else if (isset($_POST['upload_task']))
{
	confirm_referrer(PANTHER_ADMIN_DIR.'/tasks.php');
	if (!isset($_FILES['req_file']))
		message($lang_admin_tasks['No file']);
	
	$uploaded_file = $_FILES['req_file'];
	
	// Make sure the upload went smooth
	if (isset($uploaded_file['error']))
	{
		switch ($uploaded_file['error'])
		{
			case 1:	// UPLOAD_ERR_INI_SIZE
			case 2:	// UPLOAD_ERR_FORM_SIZE
				message($lang_admin_tasks['Too large ini']);
			break;
			case 3:	// UPLOAD_ERR_PARTIAL
				message($lang_admin_tasks['Partial upload']);
			break;
			case 4:	// UPLOAD_ERR_NO_FILE
				message($lang_admin_tasks['No file']);
			break;
			case 6:	// UPLOAD_ERR_NO_TMP_DIR
				message($lang_admin_tasks['No tmp directory']);
			break;
			default:
				// No error occured, but was something actually uploaded?
				if ($uploaded_file['size'] == 0)
					message($lang_admin_tasks['No file']);
			break;
		}
	}
	
	if (is_uploaded_file($uploaded_file['tmp_name']))
	{
		$filename = panther_htmlspecialchars($uploaded_file['name']);
		if (!preg_match('/^[a-z0-9-_]+\.(php)$/i', $uploaded_file['name']))
			message($lang_admin_tasks['Bad type']);
		
		// Make sure there is no file already under this name
		if (file_exists(PANTHER_ROOT.'include/tasks/'.$filename))
			message(sprintf($lang_admin_tasks['Task exists'], panther_htmlspecialchars($filename)));
	
		// Move the file to the addons directory.
		if (!@move_uploaded_file($uploaded_file['tmp_name'], PANTHER_ROOT.'include/tasks/'.$filename))
			message($lang_admin_tasks['Move failed']);

		@chmod(PANTHER_ROOT.'include/tasks/'.$filename, 0644);
	}
	else
		message($lang_admin_tasks['Unknown failure']);
	
	redirect(panther_link($panther_url['admin_tasks']), $lang_admin_tasks['Successful Upload Task']);
}

else if (isset($_POST['delete_task']))
{
	confirm_referrer(PANTHER_ADMIN_DIR.'/tasks.php');
	$tasks = isset($_POST['del_tasks']) && is_array($_POST['del_tasks']) ? array_map('panther_trim', $_POST['del_tasks']) : array();

	if (empty($tasks))
		message($lang_admin_tasks['No tasks']);

	foreach ($tasks as $task)
	{
		// Make sure it doesn't look suspicious
		if (file_exists(PANTHER_ROOT.'include/tasks/'.$task.'.php') && (preg_match('/^[a-z0-9-_]+$/i', $task)) && !preg_match('/^[\/\.@[{}]!"£\|<>:]+$/i', $task))
			unlink(PANTHER_ROOT.'include/tasks/'.$task.'.php');
	}

	redirect(panther_link($panther_url['admin_tasks']), $lang_admin_tasks['Task removed redirect']);
}

$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_admin_common['Admin'], $lang_admin_common['Tasks']);
define('PANTHER_ACTIVE_PAGE', 'admin');
require PANTHER_ROOT.'header.php';

if (isset($_GET['edit']))
{
	$id = intval($_GET['edit']);
	$data = array(
		':id' => $id,
	);

	$ps = $db->select('tasks', 'title, minute, hour, day, month, week_day, script', $data, 'id=:id');
	if (!$ps->rowCount())
		message($lang_common['Bad request']);

	$cur_task = $ps->fetch();

	$options = array();
	$tasks = array_diff(scandir(PANTHER_ROOT.'include/tasks'), array('.', '..'));
	foreach ($tasks as $cur_file)
		$options[] = '<option value="'.panther_htmlspecialchars(substr($cur_file, 0, -4)).'"'.((panther_htmlspecialchars(substr($cur_file, 0, -4)) == $cur_task['script']) ? ' selected="selected"' : '').'>'.panther_htmlspecialchars(ucwords(str_replace('_', ' ', substr($cur_file, 0, -4)))).'</option>';
	
	$admin_tpl = panther_template('edit_task.tpl');
	$search = array(
		'{form_action}' => panther_link($panther_url['admin_tasks']),
		'{csrf_token}' => generate_csrf_token(PANTHER_ADMIN_DIR.'/tasks.php'),
		'{edit_task}' => $lang_admin_tasks['Edit task'],
		'{task_info}' => $lang_admin_tasks['Edit task info'],
		'{task_title}' => $lang_admin_tasks['Task label'],
		'{id}' => $id,
		'{go_back}' => $lang_common['Go back'],
		'{every_minute}' => $lang_admin_tasks['Every minute'],
		'{every_hour}' => $lang_admin_tasks['Every hour'],
		'{every_day}' => $lang_admin_tasks['Every day'],
		'{every_month}' => $lang_admin_tasks['Every month'],
		'{every_week_day}' => $lang_admin_tasks['Every week day'],
		'{0_minute_option}' => $lang_admin_tasks['Zero minutes'],
		'{15_minute_option}' => $lang_admin_tasks['Fifteen minutes'],
		'{30_minute_option}' => $lang_admin_tasks['Thirty minutes'],
		'{45_minute_option}' => $lang_admin_tasks['Fourty five minutes'],
		'{0_hour_option}' => $lang_admin_tasks['Zero hours'],
		'{1_hour_option}' => $lang_admin_tasks['One hours'],
		'{2_hour_option}' => $lang_admin_tasks['Two hours'],
		'{3_hour_option}' => $lang_admin_tasks['Three hours'],
		'{4_hour_option}' => $lang_admin_tasks['Four hours'],
		'{5_hour_option}' => $lang_admin_tasks['Five hours'],
		'{6_hour_option}' => $lang_admin_tasks['Six hours'],
		'{7_hour_option}' => $lang_admin_tasks['Seven hours'],
		'{8_hour_option}' => $lang_admin_tasks['Eight hours'],
		'{9_hour_option}' => $lang_admin_tasks['Nine hours'],
		'{10_hour_option}' => $lang_admin_tasks['Ten hours'],
		'{11_hour_option}' => $lang_admin_tasks['Eleven hours'],
		'{12_hour_option}' => $lang_admin_tasks['Twelve hours'],
		'{13_hour_option}' => $lang_admin_tasks['Thirteen hours'],
		'{14_hour_option}' => $lang_admin_tasks['Fourteen hours'],
		'{15_hour_option}' => $lang_admin_tasks['Fifteen hours'],
		'{16_hour_option}' => $lang_admin_tasks['Sixteen hours'],
		'{17_hour_option}' => $lang_admin_tasks['Seventeen hours'],
		'{18_hour_option}' => $lang_admin_tasks['Eighteen hours'],
		'{19_hour_option}' => $lang_admin_tasks['Nineteen hours'],
		'{20_hour_option}' => $lang_admin_tasks['Twenty hours'],
		'{21_hour_option}' => $lang_admin_tasks['Twenty one hours'],
		'{22_hour_option}' => $lang_admin_tasks['Twenty two hours'],
		'{23_hour_option}' => $lang_admin_tasks['Twenty three hours'],
		'{1_day_option}' => $lang_admin_tasks['One days'],
		'{2_day_option}' => $lang_admin_tasks['Two days'],
		'{3_day_option}' => $lang_admin_tasks['Three days'],
		'{4_day_option}' => $lang_admin_tasks['Four days'],
		'{5_day_option}' => $lang_admin_tasks['Five days'],
		'{6_day_option}' => $lang_admin_tasks['Six days'],
		'{7_day_option}' => $lang_admin_tasks['Seven days'],
		'{8_day_option}' => $lang_admin_tasks['Eight days'],
		'{9_day_option}' => $lang_admin_tasks['Nine days'],
		'{10_day_option}' => $lang_admin_tasks['Ten days'],
		'{11_day_option}' => $lang_admin_tasks['Eleven days'],
		'{12_day_option}' => $lang_admin_tasks['Twelve days'],
		'{13_day_option}' => $lang_admin_tasks['Thirteen days'],
		'{14_day_option}' => $lang_admin_tasks['Fourteen days'],
		'{15_day_option}' => $lang_admin_tasks['Fifteen days'],
		'{16_day_option}' => $lang_admin_tasks['Sixteen days'],
		'{17_day_option}' => $lang_admin_tasks['Seventeen days'],
		'{18_day_option}' => $lang_admin_tasks['Eighteen days'],
		'{19_day_option}' => $lang_admin_tasks['Nineteen days'],
		'{20_day_option}' => $lang_admin_tasks['Twenty days'],
		'{21_day_option}' => $lang_admin_tasks['Twenty one days'],
		'{22_day_option}' => $lang_admin_tasks['Twenty two days'],
		'{23_day_option}' => $lang_admin_tasks['Twenty three days'],
		'{24_day_option}' => $lang_admin_tasks['Twenty four days'],
		'{25_day_option}' => $lang_admin_tasks['Twenty five days'],
		'{26_day_option}' => $lang_admin_tasks['Twenty six days'],
		'{27_day_option}' => $lang_admin_tasks['Twenty seven days'],
		'{28_day_option}' => $lang_admin_tasks['Twenty eight days'],
		'{29_day_option}' => $lang_admin_tasks['Twenty nine days'],
		'{30_day_option}' => $lang_admin_tasks['Thirty days'],
		'{31_day_option}' => $lang_admin_tasks['Thirty one days'],
		'{1_month_option}' => $lang_admin_tasks['One months'],
		'{2_month_option}' => $lang_admin_tasks['Two months'],
		'{3_month_option}' => $lang_admin_tasks['Three months'],
		'{4_month_option}' => $lang_admin_tasks['Four months'],
		'{5_month_option}' => $lang_admin_tasks['Five months'],
		'{6_month_option}' => $lang_admin_tasks['Six months'],
		'{7_month_option}' => $lang_admin_tasks['Seven months'],
		'{8_month_option}' => $lang_admin_tasks['Eight months'],
		'{9_month_option}' => $lang_admin_tasks['Nine months'],
		'{10_month_option}' => $lang_admin_tasks['Ten months'],
		'{11_month_option}' => $lang_admin_tasks['Eleven months'],
		'{12_month_option}' => $lang_admin_tasks['Twelve months'],
		'{1_week_day_option}' => $lang_admin_tasks['One week days'],
		'{2_week_day_option}' => $lang_admin_tasks['Two week days'],
		'{3_week_day_option}' => $lang_admin_tasks['Three week days'],
		'{4_week_day_option}' => $lang_admin_tasks['Four week days'],
		'{5_week_day_option}' => $lang_admin_tasks['Five week days'],
		'{6_week_day_option}' => $lang_admin_tasks['Six week days'],
		'{7_week_day_option}' => $lang_admin_tasks['Seven week days'],
		'{task_title_help}' => $lang_admin_tasks['Task title help'],
		'{task_script}' => $lang_admin_tasks['Task script'],
		'{task_script_help}' => $lang_admin_tasks['Task script help'],
		'{minute_label}' => $lang_admin_tasks['Minutes label'],
		'{minute_help}' => $lang_admin_tasks['Minutes help'],
		'{hour_label}' => $lang_admin_tasks['Hour label'],
		'{day_label}' => $lang_admin_tasks['Day label'],
		'{hour_help}' => $lang_admin_tasks['Hour help'],
		'{day_help}' => $lang_admin_tasks['Day help'],
		'{month_label}' => $lang_admin_tasks['Month label'],
		'{month_help}' => $lang_admin_tasks['Month help'],
		'{week_day_label}' => $lang_admin_tasks['Week day label'],
		'{week_day_help}' => $lang_admin_tasks['Week day help'],
		'{task_options}' => count($options) ? implode("\n", $options) : '',
		'{title_value}' => panther_htmlspecialchars($cur_task['title']),
		'{submit}' => $lang_common['Submit'],
		'{every_minute_selected}' => ($cur_task['minute'] == '*') ? ' selected="selected"' : '',
		'{0_minute_selected}' => ($cur_task['minute'] == '0') ? ' selected="selected"' : '',
		'{1_minute_selected}' => ($cur_task['minute'] == '1') ? ' selected="selected"' : '',
		'{2_minute_selected}' => ($cur_task['minute'] == '2') ? ' selected="selected"' : '',
		'{3_minute_selected}' => ($cur_task['minute'] == '3') ? ' selected="selected"' : '',
		'{4_minute_selected}' => ($cur_task['minute'] == '4') ? ' selected="selected"' : '',
		'{5_minute_selected}' => ($cur_task['minute'] == '5') ? ' selected="selected"' : '',
		'{6_minute_selected}' => ($cur_task['minute'] == '6') ? ' selected="selected"' : '',
		'{7_minute_selected}' => ($cur_task['minute'] == '7') ? ' selected="selected"' : '',
		'{8_minute_selected}' => ($cur_task['minute'] == '8') ? ' selected="selected"' : '',
		'{9_minute_selected}' => ($cur_task['minute'] == '9') ? ' selected="selected"' : '',
		'{10_minute_selected}' => ($cur_task['minute'] == '10') ? ' selected="selected"' : '',
		'{11_minute_selected}' => ($cur_task['minute'] == '11') ? ' selected="selected"' : '',
		'{12_minute_selected}' => ($cur_task['minute'] == '12') ? ' selected="selected"' : '',
		'{13_minute_selected}' => ($cur_task['minute'] == '13') ? ' selected="selected"' : '',
		'{14_minute_selected}' => ($cur_task['minute'] == '14') ? ' selected="selected"' : '',
		'{15_minute_selected}' => ($cur_task['minute'] == '15') ? ' selected="selected"' : '',
		'{16_minute_selected}' => ($cur_task['minute'] == '16') ? ' selected="selected"' : '',
		'{17_minute_selected}' => ($cur_task['minute'] == '17') ? ' selected="selected"' : '',
		'{18_minute_selected}' => ($cur_task['minute'] == '18') ? ' selected="selected"' : '',
		'{19_minute_selected}' => ($cur_task['minute'] == '19') ? ' selected="selected"' : '',
		'{20_minute_selected}' => ($cur_task['minute'] == '20') ? ' selected="selected"' : '',
		'{21_minute_selected}' => ($cur_task['minute'] == '21') ? ' selected="selected"' : '',
		'{22_minute_selected}' => ($cur_task['minute'] == '22') ? ' selected="selected"' : '',
		'{23_minute_selected}' => ($cur_task['minute'] == '23') ? ' selected="selected"' : '',
		'{24_minute_selected}' => ($cur_task['minute'] == '24') ? ' selected="selected"' : '',
		'{25_minute_selected}' => ($cur_task['minute'] == '25') ? ' selected="selected"' : '',
		'{26_minute_selected}' => ($cur_task['minute'] == '26') ? ' selected="selected"' : '',
		'{27_minute_selected}' => ($cur_task['minute'] == '27') ? ' selected="selected"' : '',
		'{28_minute_selected}' => ($cur_task['minute'] == '28') ? ' selected="selected"' : '',
		'{29_minute_selected}' => ($cur_task['minute'] == '29') ? ' selected="selected"' : '',
		'{30_minute_selected}' => ($cur_task['minute'] == '30') ? ' selected="selected"' : '',
		'{31_minute_selected}' => ($cur_task['minute'] == '31') ? ' selected="selected"' : '',
		'{32_minute_selected}' => ($cur_task['minute'] == '32') ? ' selected="selected"' : '',
		'{33_minute_selected}' => ($cur_task['minute'] == '33') ? ' selected="selected"' : '',
		'{34_minute_selected}' => ($cur_task['minute'] == '34') ? ' selected="selected"' : '',
		'{35_minute_selected}' => ($cur_task['minute'] == '35') ? ' selected="selected"' : '',
		'{36_minute_selected}' => ($cur_task['minute'] == '36') ? ' selected="selected"' : '',
		'{37_minute_selected}' => ($cur_task['minute'] == '37') ? ' selected="selected"' : '',
		'{38_minute_selected}' => ($cur_task['minute'] == '38') ? ' selected="selected"' : '',
		'{39_minute_selected}' => ($cur_task['minute'] == '39') ? ' selected="selected"' : '',
		'{40_minute_selected}' => ($cur_task['minute'] == '40') ? ' selected="selected"' : '',
		'{41_minute_selected}' => ($cur_task['minute'] == '41') ? ' selected="selected"' : '',
		'{42_minute_selected}' => ($cur_task['minute'] == '42') ? ' selected="selected"' : '',
		'{43_minute_selected}' => ($cur_task['minute'] == '43') ? ' selected="selected"' : '',
		'{44_minute_selected}' => ($cur_task['minute'] == '44') ? ' selected="selected"' : '',
		'{45_minute_selected}' => ($cur_task['minute'] == '45') ? ' selected="selected"' : '',
		'{46_minute_selected}' => ($cur_task['minute'] == '46') ? ' selected="selected"' : '',
		'{47_minute_selected}' => ($cur_task['minute'] == '47') ? ' selected="selected"' : '',
		'{48_minute_selected}' => ($cur_task['minute'] == '48') ? ' selected="selected"' : '',
		'{49_minute_selected}' => ($cur_task['minute'] == '49') ? ' selected="selected"' : '',
		'{50_minute_selected}' => ($cur_task['minute'] == '50') ? ' selected="selected"' : '',
		'{51_minute_selected}' => ($cur_task['minute'] == '51') ? ' selected="selected"' : '',
		'{52_minute_selected}' => ($cur_task['minute'] == '52') ? ' selected="selected"' : '',
		'{53_minute_selected}' => ($cur_task['minute'] == '53') ? ' selected="selected"' : '',
		'{54_minute_selected}' => ($cur_task['minute'] == '54') ? ' selected="selected"' : '',
		'{55_minute_selected}' => ($cur_task['minute'] == '55') ? ' selected="selected"' : '',
		'{56_minute_selected}' => ($cur_task['minute'] == '56') ? ' selected="selected"' : '',
		'{57_minute_selected}' => ($cur_task['minute'] == '57') ? ' selected="selected"' : '',
		'{58_minute_selected}' => ($cur_task['minute'] == '58') ? ' selected="selected"' : '',
		'{59_minute_selected}' => ($cur_task['minute'] == '59') ? ' selected="selected"' : '',
		'{every_hour_selected}' => ($cur_task['hour'] == '*') ? ' selected="selected"' : '',
		'{0_hour_selected}' => ($cur_task['hour'] == '0') ? ' selected="selected"' : '',
		'{1_hour_selected}' => ($cur_task['hour'] == '1') ? ' selected="selected"' : '',
		'{2_hour_selected}' => ($cur_task['hour'] == '2') ? ' selected="selected"' : '',
		'{3_hour_selected}' => ($cur_task['hour'] == '3') ? ' selected="selected"' : '',
		'{4_hour_selected}' => ($cur_task['hour'] == '4') ? ' selected="selected"' : '',
		'{5_hour_selected}' => ($cur_task['hour'] == '5') ? ' selected="selected"' : '',
		'{6_hour_selected}' => ($cur_task['hour'] == '6') ? ' selected="selected"' : '',
		'{7_hour_selected}' => ($cur_task['hour'] == '7') ? ' selected="selected"' : '',
		'{8_hour_selected}' => ($cur_task['hour'] == '8') ? ' selected="selected"' : '',
		'{9_hour_selected}' => ($cur_task['hour'] == '9') ? ' selected="selected"' : '',
		'{10_hour_selected}' => ($cur_task['hour'] == '10') ? ' selected="selected"' : '',
		'{11_hour_selected}' => ($cur_task['hour'] == '11') ? ' selected="selected"' : '',
		'{12_hour_selected}' => ($cur_task['hour'] == '12') ? ' selected="selected"' : '',
		'{13_hour_selected}' => ($cur_task['hour'] == '13') ? ' selected="selected"' : '',
		'{14_hour_selected}' => ($cur_task['hour'] == '14') ? ' selected="selected"' : '',
		'{15_hour_selected}' => ($cur_task['hour'] == '15') ? ' selected="selected"' : '',
		'{16_hour_selected}' => ($cur_task['hour'] == '16') ? ' selected="selected"' : '',
		'{17_hour_selected}' => ($cur_task['hour'] == '17') ? ' selected="selected"' : '',
		'{18_hour_selected}' => ($cur_task['hour'] == '18') ? ' selected="selected"' : '',
		'{19_hour_selected}' => ($cur_task['hour'] == '19') ? ' selected="selected"' : '',
		'{20_hour_selected}' => ($cur_task['hour'] == '20') ? ' selected="selected"' : '',
		'{21_hour_selected}' => ($cur_task['hour'] == '21') ? ' selected="selected"' : '',
		'{22_hour_selected}' => ($cur_task['hour'] == '22') ? ' selected="selected"' : '',
		'{23_hour_selected}' => ($cur_task['hour'] == '23') ? ' selected="selected"' : '',
		'{every_day_selected}' => ($cur_task['day'] == '*') ? ' selected="selected"' : '',
		'{1_day_selected}' => ($cur_task['day'] == '1') ? ' selected="selected"' : '',
		'{2_day_selected}' => ($cur_task['day'] == '2') ? ' selected="selected"' : '',
		'{3_day_selected}' => ($cur_task['day'] == '3') ? ' selected="selected"' : '',
		'{4_day_selected}' => ($cur_task['day'] == '4') ? ' selected="selected"' : '',
		'{5_day_selected}' => ($cur_task['day'] == '5') ? ' selected="selected"' : '',
		'{6_day_selected}' => ($cur_task['day'] == '6') ? ' selected="selected"' : '',
		'{7_day_selected}' => ($cur_task['day'] == '7') ? ' selected="selected"' : '',
		'{8_day_selected}' => ($cur_task['day'] == '8') ? ' selected="selected"' : '',
		'{9_day_selected}' => ($cur_task['day'] == '9') ? ' selected="selected"' : '',
		'{10_day_selected}' => ($cur_task['day'] == '10') ? ' selected="selected"' : '',
		'{11_day_selected}' => ($cur_task['day'] == '11') ? ' selected="selected"' : '',
		'{12_day_selected}' => ($cur_task['day'] == '12') ? ' selected="selected"' : '',
		'{13_day_selected}' => ($cur_task['day'] == '13') ? ' selected="selected"' : '',
		'{14_day_selected}' => ($cur_task['day'] == '14') ? ' selected="selected"' : '',
		'{15_day_selected}' => ($cur_task['day'] == '15') ? ' selected="selected"' : '',
		'{16_day_selected}' => ($cur_task['day'] == '16') ? ' selected="selected"' : '',
		'{17_day_selected}' => ($cur_task['day'] == '17') ? ' selected="selected"' : '',
		'{18_day_selected}' => ($cur_task['day'] == '18') ? ' selected="selected"' : '',
		'{19_day_selected}' => ($cur_task['day'] == '19') ? ' selected="selected"' : '',
		'{20_day_selected}' => ($cur_task['day'] == '20') ? ' selected="selected"' : '',
		'{21_day_selected}' => ($cur_task['day'] == '21') ? ' selected="selected"' : '',
		'{22_day_selected}' => ($cur_task['day'] == '22') ? ' selected="selected"' : '',
		'{23_day_selected}' => ($cur_task['day'] == '23') ? ' selected="selected"' : '',
		'{24_day_selected}' => ($cur_task['day'] == '24') ? ' selected="selected"' : '',
		'{25_day_selected}' => ($cur_task['day'] == '25') ? ' selected="selected"' : '',
		'{26_day_selected}' => ($cur_task['day'] == '26') ? ' selected="selected"' : '',
		'{27_day_selected}' => ($cur_task['day'] == '27') ? ' selected="selected"' : '',
		'{28_day_selected}' => ($cur_task['day'] == '28') ? ' selected="selected"' : '',
		'{29_day_selected}' => ($cur_task['day'] == '29') ? ' selected="selected"' : '',
		'{30_day_selected}' => ($cur_task['day'] == '30') ? ' selected="selected"' : '',
		'{31_day_selected}' => ($cur_task['day'] == '31') ? ' selected="selected"' : '',
		'{every_month_selected}' => ($cur_task['month'] == '*') ? ' selected="selected"' : '',
		'{1_month_selected}' => ($cur_task['month'] == '1') ? ' selected="selected"' : '',
		'{2_month_selected}' => ($cur_task['month'] == '2') ? ' selected="selected"' : '',
		'{3_month_selected}' => ($cur_task['month'] == '3') ? ' selected="selected"' : '',
		'{4_month_selected}' => ($cur_task['month'] == '4') ? ' selected="selected"' : '',
		'{5_month_selected}' => ($cur_task['month'] == '5') ? ' selected="selected"' : '',
		'{6_month_selected}' => ($cur_task['month'] == '6') ? ' selected="selected"' : '',
		'{7_month_selected}' => ($cur_task['month'] == '7') ? ' selected="selected"' : '',
		'{8_month_selected}' => ($cur_task['month'] == '8') ? ' selected="selected"' : '',
		'{9_month_selected}' => ($cur_task['month'] == '9') ? ' selected="selected"' : '',
		'{10_month_selected}' => ($cur_task['month'] == '10') ? ' selected="selected"' : '',
		'{11_month_selected}' => ($cur_task['month'] == '11') ? ' selected="selected"' : '',
		'{12_month_selected}' => ($cur_task['month'] == '12') ? ' selected="selected"' : '',
		'{every_week_selected}' => ($cur_task['week_day'] == '*') ? ' selected="selected"' : '',
		'{0_week_selected}' => ($cur_task['week_day'] == '0') ? ' selected="selected"' : '',
		'{1_week_selected}' => ($cur_task['week_day'] == '1') ? ' selected="selected"' : '',
		'{2_week_selected}' => ($cur_task['week_day'] == '2') ? ' selected="selected"' : '',
		'{3_week_selected}' => ($cur_task['week_day'] == '3') ? ' selected="selected"' : '',
		'{4_week_selected}' => ($cur_task['week_day'] == '4') ? ' selected="selected"' : '',
		'{5_week_selected}' => ($cur_task['week_day'] == '5') ? ' selected="selected"' : '',
		'{6_week_selected}' => ($cur_task['week_day'] == '6') ? ' selected="selected"' : '',
		'{1_week_day_option}' => $lang_admin_tasks['One week days'],
		'{2_week_day_option}' => $lang_admin_tasks['Two week days'],
		'{3_week_day_option}' => $lang_admin_tasks['Three week days'],
		'{4_week_day_option}' => $lang_admin_tasks['Four week days'],
		'{5_week_day_option}' => $lang_admin_tasks['Five week days'],
		'{6_week_day_option}' => $lang_admin_tasks['Six week days'],
		'{7_week_day_option}' => $lang_admin_tasks['Seven week days'],
	);
}
else if (isset($_GET['delete']))
{
	$id = intval($_GET['delete']);
	$data = array(
		':id' => $id,
	);

	$ps = $db->select('tasks', 1, $data, 'id=:id');
	if (!$ps->rowCount())
		message($lang_common['Bad request']);
	
	$admin_tpl = panther_template('delete_task.tpl');
	$search = array(
		'{form_action}' => panther_link($panther_url['admin_tasks']),
		'{csrf_token}' => generate_csrf_token(PANTHER_ADMIN_DIR.'/tasks.php'),
		'{id}' => $id,
		'{confirm_delete}' => $lang_admin_tasks['Confirm delete'],
		'{delete}' => $lang_admin_tasks['Delete'],
		'{go_back}' => $lang_common['Go back'],
		'{important_information}' => $lang_admin_tasks['Important information'],
		'{delete_task}' => $lang_admin_tasks['Delete info'],
	);
}
else
{
	$ps = $db->select('tasks', 'id, title, minute, hour, day, month, week_day, script, next_run', array(), '', 'id');
	$configured_tasks = array();
	if ($ps->rowCount())
	{
		$tasks_list_tpl = panther_template('tasks_row.tpl');
		foreach ($ps as $cur_task)
		{
			$search = array(
				'{name}' => $lang_admin_tasks['Name'],
				'{task_title}' => panther_htmlspecialchars($cur_task['title']),
				'{edit_task}' => panther_link($panther_url['edit_task'], array($cur_task['id'])),
				'{delete_task}' => panther_link($panther_url['delete_task'], array($cur_task['id'])),
				'{minute}' => $cur_task['minute'],
				'{hour}' => $cur_task['hour'],
				'{day}' => $cur_task['day'],
				'{month}' => $cur_task['month'],
				'{week_day}' => $cur_task['week_day'],
				'{edit}' => $lang_admin_tasks['Edit'],
				'{delete}' => $lang_admin_tasks['Delete'],
				'{next_run_lang}' => $lang_admin_tasks['Next run'],
				'{next_run}' => format_time($cur_task['next_run']),
			);

			$configured_tasks[] = str_replace(array_keys($search), array_values($search), $tasks_list_tpl);
		}
	}
	else
		$configured_tasks[] = str_replace('{no_tasks}', $lang_admin_tasks['No tasks'], panther_template('no_tasks.tpl'));

	$options = $task_row = array();
	$task_row_tpl = panther_template('task_del_row.tpl');
	$tasks = array_diff(scandir(PANTHER_ROOT.'include/tasks'), array('.', '..'));
	foreach ($tasks as $cur_task)
	{
		$options[] = '<option value="'.panther_htmlspecialchars(substr($cur_task, 0, -4)).'">'.panther_htmlspecialchars(ucwords(str_replace('_', ' ', substr($cur_task, 0, -4)))).'</option>';
		$search = array(
			'{display_name}' => panther_htmlspecialchars(ucwords(str_replace('_', ' ', substr($cur_task, 0, -4)))),
			'{task_name}' => panther_htmlspecialchars(substr($cur_task, 0, -4)),
		);

		$task_row[] = str_replace(array_keys($search), array_values($search), $task_row_tpl);
	}

	$admin_tpl = panther_template('admin_tasks.tpl');
	$search = array(
		'{form_action}' => panther_link($panther_url['admin_tasks']),
		'{csrf_token}' => generate_csrf_token(PANTHER_ADMIN_DIR.'/tasks.php'),
		'{task_title}' => $lang_admin_tasks['Task label'],
		'{every_minute}' => $lang_admin_tasks['Every minute'],
		'{every_hour}' => $lang_admin_tasks['Every hour'],
		'{every_day}' => $lang_admin_tasks['Every day'],
		'{every_month}' => $lang_admin_tasks['Every month'],
		'{every_week_day}' => $lang_admin_tasks['Every week day'],
		'{0_minute_option}' => $lang_admin_tasks['Zero minutes'],
		'{15_minute_option}' => $lang_admin_tasks['Fifteen minutes'],
		'{30_minute_option}' => $lang_admin_tasks['Thirty minutes'],
		'{45_minute_option}' => $lang_admin_tasks['Fourty five minutes'],
		'{0_hour_option}' => $lang_admin_tasks['Zero hours'],
		'{1_hour_option}' => $lang_admin_tasks['One hours'],
		'{2_hour_option}' => $lang_admin_tasks['Two hours'],
		'{3_hour_option}' => $lang_admin_tasks['Three hours'],
		'{4_hour_option}' => $lang_admin_tasks['Four hours'],
		'{5_hour_option}' => $lang_admin_tasks['Five hours'],
		'{6_hour_option}' => $lang_admin_tasks['Six hours'],
		'{7_hour_option}' => $lang_admin_tasks['Seven hours'],
		'{8_hour_option}' => $lang_admin_tasks['Eight hours'],
		'{9_hour_option}' => $lang_admin_tasks['Nine hours'],
		'{10_hour_option}' => $lang_admin_tasks['Ten hours'],
		'{11_hour_option}' => $lang_admin_tasks['Eleven hours'],
		'{12_hour_option}' => $lang_admin_tasks['Twelve hours'],
		'{13_hour_option}' => $lang_admin_tasks['Thirteen hours'],
		'{14_hour_option}' => $lang_admin_tasks['Fourteen hours'],
		'{15_hour_option}' => $lang_admin_tasks['Fifteen hours'],
		'{16_hour_option}' => $lang_admin_tasks['Sixteen hours'],
		'{17_hour_option}' => $lang_admin_tasks['Seventeen hours'],
		'{18_hour_option}' => $lang_admin_tasks['Eighteen hours'],
		'{19_hour_option}' => $lang_admin_tasks['Nineteen hours'],
		'{20_hour_option}' => $lang_admin_tasks['Twenty hours'],
		'{21_hour_option}' => $lang_admin_tasks['Twenty one hours'],
		'{22_hour_option}' => $lang_admin_tasks['Twenty two hours'],
		'{23_hour_option}' => $lang_admin_tasks['Twenty three hours'],
		'{1_day_option}' => $lang_admin_tasks['One days'],
		'{2_day_option}' => $lang_admin_tasks['Two days'],
		'{3_day_option}' => $lang_admin_tasks['Three days'],
		'{4_day_option}' => $lang_admin_tasks['Four days'],
		'{5_day_option}' => $lang_admin_tasks['Five days'],
		'{6_day_option}' => $lang_admin_tasks['Six days'],
		'{7_day_option}' => $lang_admin_tasks['Seven days'],
		'{8_day_option}' => $lang_admin_tasks['Eight days'],
		'{9_day_option}' => $lang_admin_tasks['Nine days'],
		'{10_day_option}' => $lang_admin_tasks['Ten days'],
		'{11_day_option}' => $lang_admin_tasks['Eleven days'],
		'{12_day_option}' => $lang_admin_tasks['Twelve days'],
		'{13_day_option}' => $lang_admin_tasks['Thirteen days'],
		'{14_day_option}' => $lang_admin_tasks['Fourteen days'],
		'{15_day_option}' => $lang_admin_tasks['Fifteen days'],
		'{16_day_option}' => $lang_admin_tasks['Sixteen days'],
		'{17_day_option}' => $lang_admin_tasks['Seventeen days'],
		'{18_day_option}' => $lang_admin_tasks['Eighteen days'],
		'{19_day_option}' => $lang_admin_tasks['Nineteen days'],
		'{20_day_option}' => $lang_admin_tasks['Twenty days'],
		'{21_day_option}' => $lang_admin_tasks['Twenty one days'],
		'{22_day_option}' => $lang_admin_tasks['Twenty two days'],
		'{23_day_option}' => $lang_admin_tasks['Twenty three days'],
		'{24_day_option}' => $lang_admin_tasks['Twenty four days'],
		'{25_day_option}' => $lang_admin_tasks['Twenty five days'],
		'{26_day_option}' => $lang_admin_tasks['Twenty six days'],
		'{27_day_option}' => $lang_admin_tasks['Twenty seven days'],
		'{28_day_option}' => $lang_admin_tasks['Twenty eight days'],
		'{29_day_option}' => $lang_admin_tasks['Twenty nine days'],
		'{30_day_option}' => $lang_admin_tasks['Thirty days'],
		'{31_day_option}' => $lang_admin_tasks['Thirty one days'],
		'{1_month_option}' => $lang_admin_tasks['One months'],
		'{2_month_option}' => $lang_admin_tasks['Two months'],
		'{3_month_option}' => $lang_admin_tasks['Three months'],
		'{4_month_option}' => $lang_admin_tasks['Four months'],
		'{5_month_option}' => $lang_admin_tasks['Five months'],
		'{6_month_option}' => $lang_admin_tasks['Six months'],
		'{7_month_option}' => $lang_admin_tasks['Seven months'],
		'{8_month_option}' => $lang_admin_tasks['Eight months'],
		'{9_month_option}' => $lang_admin_tasks['Nine months'],
		'{10_month_option}' => $lang_admin_tasks['Ten months'],
		'{11_month_option}' => $lang_admin_tasks['Eleven months'],
		'{12_month_option}' => $lang_admin_tasks['Twelve months'],
		'{1_week_day_option}' => $lang_admin_tasks['One week days'],
		'{2_week_day_option}' => $lang_admin_tasks['Two week days'],
		'{3_week_day_option}' => $lang_admin_tasks['Three week days'],
		'{4_week_day_option}' => $lang_admin_tasks['Four week days'],
		'{5_week_day_option}' => $lang_admin_tasks['Five week days'],
		'{6_week_day_option}' => $lang_admin_tasks['Six week days'],
		'{7_week_day_option}' => $lang_admin_tasks['Seven week days'],
		'{task_label}' => $lang_admin_tasks['Task'],
		'{task_options}' => count($options) ? implode("\n", $options) : '',
		'{upload_task}' => $lang_admin_tasks['Upload task'],
		'{upload_new_task}' => $lang_admin_tasks['Upload new task'],
		'{upload}' => $lang_admin_tasks['Upload'],
		'{upload_task_warning}' => $lang_admin_tasks['Upload task warning'],
		'{create_new}' => $lang_admin_tasks['Create new'],
		'{submit}' => $lang_admin_common['Add'],
		'{task_info}' => $lang_admin_tasks['Task info'],
		'{task_title_help}' => $lang_admin_tasks['Task title help'],
		'{task_script}' => $lang_admin_tasks['Task script'],
		'{task_script_help}' => $lang_admin_tasks['Task script help'],
		'{minute_label}' => $lang_admin_tasks['Minutes label'],
		'{minute_help}' => $lang_admin_tasks['Minutes help'],
		'{hour_label}' => $lang_admin_tasks['Hour label'],
		'{day_label}' => $lang_admin_tasks['Day label'],
		'{hour_help}' => $lang_admin_tasks['Hour help'],
		'{day_help}' => $lang_admin_tasks['Day help'],
		'{month_label}' => $lang_admin_tasks['Month label'],
		'{month_help}' => $lang_admin_tasks['Month help'],
		'{week_day_label}' => $lang_admin_tasks['Week day label'],
		'{week_day_help}' => $lang_admin_tasks['Week day help'],
		'{current_tasks}' => $lang_admin_tasks['Current tasks'],
		'{list_tasks}' => $lang_admin_tasks['List tasks'],
		'{filename}' => $lang_admin_tasks['Filename'],
		'{delete}' => $lang_admin_tasks['Delete'],
		'{display_tasks}' => count($task_row) ? implode("\n", $task_row) : '',
		'{configured_tasks}' => $lang_admin_tasks['Configured tasks'],
		'{tasks_configured}' => $lang_admin_tasks['Configured tasks info'],
		'{task_rows}' => count($configured_tasks) ? implode("\n", $configured_tasks) : '',
	);
}

generate_admin_menu('tasks');
echo str_replace(array_keys($search), array_values($search), $admin_tpl);
require PANTHER_ROOT.'footer.php';