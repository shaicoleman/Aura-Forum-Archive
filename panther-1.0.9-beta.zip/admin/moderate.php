<?php
/**
 * Copyright (C) 2015 Panther (https://www.pantherforum.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

// Tell header.php to use the admin template
define('PANTHER_ADMIN_CONSOLE', 1);

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/../');
	require PANTHER_ROOT.'include/common.php';
}
require PANTHER_ROOT.'include/common_admin.php';
$action = isset($_GET['action']) ? panther_htmlspecialchars($_GET['action']) : null;
$id = isset($_GET['id']) ? intval($_GET['id']) : '0';
$page = (!isset($_GET['p']) || $_GET['p'] <= '1') ? '1' : intval($_GET['p']);

if (!$panther_user['is_admin'])
	message($lang_common['No permission'], false, '403 Forbidden');

if ($panther_user['id'] != '2')
{
	if(!is_null($admins[$panther_user['id']]['admin_moderate']))
	{
		if ($admins[$panther_user['id']]['admin_moderate'] == '0')
			message($lang_common['No permission'], false, '403 Forbidden');
	}
}

check_authentication();

// Load the admin_moderate.php language file
require PANTHER_ROOT.'lang/'.$admin_language.'/admin_moderate.php';

if (isset($_POST['form_sent']))
{
	if ($action == 'add')
	{
		$message = isset($_POST['message']) ? panther_trim($_POST['message']) : null;
		$title = isset($_POST['title']) ? panther_trim($_POST['title']) : null;
		$add_start = isset($_POST['add_start']) ? utf8_ltrim($_POST['add_start']) : null;
		$add_end = isset($_POST['add_end']) ? utf8_rtrim($_POST['add_end']) : null;
		$increment = isset($_POST['increment']) ? intval($_POST['increment']) : '0';
		$send_email = isset($_POST['send_email']) ? intval($_POST['send_email']) : '0';
		
		if (strlen($title) > 50)
			message($lang_admin_moderate['title too long']);
			
		if (strlen($add_start) > 50 || strlen($add_end) > 50)
			message($lang_admin_moderate['addition too long']);

		if (strlen($title) < 1)
			message($lang_common['Bad request']);
	
		$close = isset($_POST['close']) ? intval($_POST['close']) : '2';
		$stick = isset($_POST['stick']) ? intval($_POST['stick']) : '2';
		$archive = isset($_POST['archive']) ? intval($_POST['archive']) : '2';
		$move = isset($_POST['forum']) ? intval($_POST['forum']) : '0';
		$leave_redirect = isset($_POST['redirect']) ? intval($_POST['redirect']) : '0';
		$reply = isset($_POST['reply']) ? intval($_POST['reply']) : '0';
	
		$insert = array(
			'title'	=>	$title,
			'close'	=>	$close,
			'stick'	=>	$stick,
			'archive' => $archive,
			'move'	=>	$move,
			'leave_redirect'	=>	$leave_redirect,
			'add_reply'	=>	$reply,
			'reply_message'	=>	$message,
			'add_start'	=>	$add_start,
			'add_end'	=>	$add_end,
			'send_email'	=>	$send_email,
			'increment_posts'	=>	$increment,
		);

		$db->insert('multi_moderation', $insert);
		redirect(panther_link($panther_url['admin_moderate']), $lang_admin_moderate['added redirect']);
	}
	elseif ($action == 'edit' && $id > '0')
	{
		
		$message = isset($_POST['message']) ? panther_trim($_POST['message']) : null;
		$title = isset($_POST['title']) ? panther_trim($_POST['title']) : null;
		$add_start = isset($_POST['add_start']) ? utf8_ltrim($_POST['add_start']) : null;
		$add_end = isset($_POST['add_end']) ? utf8_rtrim($_POST['add_end']) : null;

		if (strlen($title) > 50)
			message($lang_admin_moderate['title too long']);
			
		if (strlen($add_start) > 50 || strlen($add_end) > 50)
			message($lang_admin_moderate['addition too long']);
	
		if (strlen($title) < 1)
			message($lang_common['Bad request']);
	
		$close = isset($_POST['close']) ? intval($_POST['close']) : '2';
		$stick = isset($_POST['stick']) ? intval($_POST['stick']) : '2';
		$archive = isset($_POST['archive']) ? intval($_POST['archive']) : '2';
		$move = isset($_POST['forum']) ? intval($_POST['forum']) : '0';
		$leave_redirect = isset($_POST['redirect']) ? intval($_POST['redirect']) : '0';
		$reply = isset($_POST['reply']) ? intval($_POST['reply']) : '0';
		$increment = isset($_POST['increment']) ? intval($_POST['increment']) : '0';
		$send_email = isset($_POST['send_email']) ? intval($_POST['send_email']) : '0';
		
		$update = array(
			'title'	=>	$title,
			'close'	=>	$close,
			'stick'	=>	$stick,
			'archive' => $archive,
			'move'	=>	$move,
			'leave_redirect'	=>	$leave_redirect,
			'add_reply'	=>	$reply,
			'reply_message'	=>	$message,
			'add_start'	=>	$add_start,
			'add_end'	=>	$add_end,
			'send_email'	=>	$send_email,
			'increment_posts'	=>	$increment,
		);
		
		$data = array(
			':id'	=>	$id,
		);

		$db->update('multi_moderation', $update, 'id=:id', $data);
		redirect('admin_moderate.php', $lang_admin_moderate['edit redirect']);
	}
	elseif ($action == 'delete' && $id > '0')
	{
		$data = array(
			':id'	=>	$id,
		);

		$rows = $db->delete('multi_moderation', 'id=:id', $data);
		if (!$rows)
			message($lang_common['Bad request']);	// If there are no rows returned we've either attempted to URL hack or something is wrong with the database (which will be displayed)

		redirect(panther_link($panther_url['admin_moderate']), $lang_admin_moderate['delete redirect']);
	}
}

$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_admin_common['Admin'], $lang_admin_common['Moderate']);
define('PANTHER_ACTIVE_PAGE', 'admin');
require PANTHER_ROOT.'header.php';
	
generate_admin_menu('moderate'); 

if ($action == 'add')
{
	// Display all the categories and forums
	$ps = $db->run('SELECT c.id AS cid, c.cat_name, f.id AS fid, f.forum_name FROM '.$db->prefix.'categories AS c INNER JOIN '.$db->prefix.'forums AS f ON c.id = f.cat_id WHERE f.redirect_url IS NULL ORDER BY c.disp_position, c.id, f.disp_position');
	if ($ps->rowCount())
	{
		$count = 0;
		$cur_index = 4;
		$cur_category = 0;
		$select = null;
		foreach ($ps as $cur_forum)
		{
			if ($cur_forum['cid'] != $cur_category) // A new category since last iteration?
			{
				$select .= '</optgroup>';
				$select .= "\t\t\t\t\t\t".'<optgroup label="'.panther_htmlspecialchars($cur_forum['cat_name']).'">'."\n";
				$cur_category = $cur_forum['cid'];
			}
				$select .= '<option value="'.$cur_forum['fid'].'">'.panther_htmlspecialchars($cur_forum['forum_name']).'</option>'."\n";
		}
			$select .= "\t\t\t\t\t\t".'</optgroup>'."\n\t\t\t\t\t".'</select>'."\n";
	}

	$admin_tpl = panther_template('admin_moderate_add.tpl');
	$search = array(
		'{actions}' => $lang_admin_moderate['actions'],
		'{admin_moderate_add}' => panther_link($panther_url['admin_moderate_add']),
		'{action_header}' => $lang_admin_moderate['action header'],
		'{title}' => $lang_admin_moderate['title'],
		'{title_help}' => $lang_admin_moderate['title help'],
		'{add_start}' => $lang_admin_moderate['add start'],
		'{add_start_help}' => $lang_admin_moderate['add start help'],
		'{add_end}' => $lang_admin_moderate['add end'],
		'{add_end_help}' => $lang_admin_moderate['add end help'],
		'{forum}' => $lang_admin_moderate['forum'],
		'{do_not_move}' => $lang_admin_moderate['do not move'],
		'{select}' => $select,
		'{forum_help}' => $lang_admin_moderate['forum help'],
		'{leave_redirect}' => $lang_admin_moderate['leave redirect'],
		'{no_redirect}' => $lang_admin_moderate['no redirect'],
		'{do_redirect}' => $lang_admin_moderate['do redirect'],
		'{redirect_help}' => $lang_admin_moderate['redirect help'],
		'{close}' => $lang_admin_moderate['close'],
		'{do_not_alter}' => $lang_admin_moderate['do not alter'],
		'{close_topic}' => $lang_admin_moderate['close topic'],
		'{open_topic}' => $lang_admin_moderate['open topic'],
		'{close_help}' => $lang_admin_moderate['close help'],
		'{stick}' => $lang_admin_moderate['stick'],
		'{stick_topic}' => $lang_admin_moderate['stick topic'],
		'{unstick_topic}' => $lang_admin_moderate['unstick topic'],
		'{stick_help}' => $lang_admin_moderate['stick help'],
		'{archive}' => $lang_admin_moderate['archive'],
		'{archive_topic}' => $lang_admin_moderate['archive topic'],
		'{unarchive_topic}' => $lang_admin_moderate['unarchive topic'],
		'{archive_help}' => $lang_admin_moderate['archive help'],
		'{increment_post_count}' => $lang_admin_moderate['increment post count'],
		'{yes}' => $lang_admin_common['Yes'],
		'{no}' => $lang_admin_common['No'],
		'{increment_help}' => $lang_admin_moderate['increment help'],
		'{email}' => $lang_admin_moderate['email'],
		'{email_help}' => $lang_admin_moderate['email help'],
		'{add_reply}' => $lang_admin_moderate['add reply'],
		'{add_reply_post}' => $lang_admin_moderate['add reply post'],
		'{no_reply_post}' => $lang_admin_moderate['no reply post'],
		'{add_reply_help}' => $lang_admin_moderate['add reply help'],
		'{message}' => $lang_admin_moderate['message'],
		'{message_help}' => $lang_admin_moderate['message help'],
		'{submit}' => $lang_common['Submit']
	);

	echo str_replace(array_keys($search), array_values($search), $admin_tpl);
}
else if($action == 'edit' && $id > '0')
{
	$data = array(
		':id'	=>	$id,
	);

	$ps = $db->select('multi_moderation', 'close, stick, archive, move, leave_redirect, add_reply, reply_message, title, add_start, add_end, send_email, increment_posts', $data, 'id=:id');
	$cur_action = $ps->fetch();

	$ps = $db->run('SELECT c.id AS cid, c.cat_name, f.id AS fid, f.forum_name FROM '.$db->prefix.'categories AS c INNER JOIN '.$db->prefix.'forums AS f ON c.id = f.cat_id WHERE f.redirect_url IS NULL ORDER BY c.disp_position, c.id, f.disp_position');
	if ($ps->rowCount())
	{
		$count = 0;
		$cur_index = 4;
		$cur_category = 0;
		$select = '';
		foreach ($ps as $cur_forum)
		{
			if ($cur_forum['cid'] != $cur_category) // A new category since last iteration?
			{
				$select .= '</optgroup>';
				$select .= "\t\t\t\t\t\t".'<optgroup label="'.panther_htmlspecialchars($cur_forum['cat_name']).'">'."\n";
				$cur_category = $cur_forum['cid'];
			}
				$select .= '<option value="'.$cur_forum['fid'].'"'.(($cur_forum['fid'] == $cur_action['move']) ? ' selected="selected"' : null).'>'.panther_htmlspecialchars($cur_forum['forum_name']).'</option>'."\n";
		}
			$select .= "\t\t\t\t\t\t".'</optgroup>'."\n\t\t\t\t\t".'</select>'."\n";
	}

	$admin_tpl = panther_template('admin_moderate_edit.tpl');
	$search = array(
		'{actions}' => $lang_admin_moderate['actions'],
		'{admin_moderate_edit}' => panther_link($panther_url['admin_moderate_edit'], array($id)),
		'{action_header}' => $lang_admin_moderate['action header'],
		'{title}' => $lang_admin_moderate['title'],
		'{title_2}' => panther_htmlspecialchars($cur_action['title']),
		'{title_help}' => $lang_admin_moderate['title help'],
		'{add_start}' => $lang_admin_moderate['add start'],
		'{add_start_2}' => $cur_action['add_start'],
		'{add_start_help}' => $lang_admin_moderate['add start help'],
		'{add_end}' => $lang_admin_moderate['add end'],
		'{add_end_2}' => $cur_action['add_end'],
		'{add_end_help}' => $lang_admin_moderate['add end help'],
		'{forum}' => $lang_admin_moderate['forum'],
		'{do_not_move}' => $lang_admin_moderate['do not move'],
		'{select}' => $select,
		'{forum_help}' => $lang_admin_moderate['forum help'],
		'{leave_redirect}' => $lang_admin_moderate['leave redirect'],
		'{leave_redirect_0_select}' => ($cur_action['leave_redirect'] == 0) ? ' selected="selected"' : '',
		'{no_redirect}' => $lang_admin_moderate['no redirect'],
		'{leave_redirect_1_select}' => ($cur_action['leave_redirect'] == 1) ? ' selected="selected"' : '',
		'{do_redirect}' => $lang_admin_moderate['do redirect'],
		'{redirect_help}' => $lang_admin_moderate['redirect help'],
		'{close}' => $lang_admin_moderate['close'],
		'{close_2_select}' => ($cur_action['close'] == 2) ? ' selected="selected"' : '',
		'{do_not_alter}' => $lang_admin_moderate['do not alter'],
		'{close_1_select}' => ($cur_action['close'] == 1) ? ' selected="selected"' : '',
		'{close_topic}' => $lang_admin_moderate['close topic'],
		'{close_0_select}' => ($cur_action['close'] == 0) ? ' selected="selected"' : '',
		'{open_topic}' => $lang_admin_moderate['open topic'],
		'{close_help}' => $lang_admin_moderate['close help'],
		'{stick}' => $lang_admin_moderate['stick'],
		'{stick_2_select}' => ($cur_action['stick'] == 2) ? ' selected="selected"' : '',
		'{stick_1_select}' => ($cur_action['stick'] == 1) ? ' selected="selected"' : '',
		'{stick_topic}' => $lang_admin_moderate['stick topic'],
		'{stick_0_select}' => ($cur_action['stick'] == 0) ? ' selected="selected"' : '',
		'{unstick_topic}' => $lang_admin_moderate['unstick topic'],
		'{stick_help}' => $lang_admin_moderate['stick help'],
		'{archive}' => $lang_admin_moderate['archive'],
		'{archive_2_select}' => ($cur_action['archive'] == 2) ? ' selected="selected"' : '',
		'{archive_1_select}' => ($cur_action['archive'] == 1) ? ' selected="selected"' : '',
		'{archive_topic}' => $lang_admin_moderate['archive topic'],
		'{archive_0_select}' => ($cur_action['archive'] == 0) ? ' selected="selected"' : '',
		'{unarchive_topic}' => $lang_admin_moderate['unarchive topic'],
		'{archive_help}' => $lang_admin_moderate['archive help'],
		'{increment_post_count}' => $lang_admin_moderate['increment post count'],
		'{increment_posts_1_checked}' => ($cur_action['increment_posts'] == 1) ? ' checked="checked"' : '',
		'{yes}' => $lang_admin_common['Yes'],
		'{increment_posts_0_checked}' => ($cur_action['increment_posts'] == 0) ? ' checked="checked"' : '',
		'{no}' => $lang_admin_common['No'],
		'{increment_help}' => $lang_admin_moderate['increment help'],
		'{email}' => $lang_admin_moderate['email'],
		'{send_email_1_checked}' => ($cur_action['send_email'] == 1) ? ' checked="checked"' : '',
		'{send_email_0_checked}' => ($cur_action['send_email'] == 0) ? ' checked="checked"' : '',
		'{email_help}' => $lang_admin_moderate['email help'],
		'{add_reply}' => $lang_admin_moderate['add reply'],
		'{add_reply_1_select}' => ($cur_action['add_reply'] == 1) ? ' selected="selected"' : '',
		'{add_reply_post}' => $lang_admin_moderate['add reply post'],
		'{add_reply_0_select}' => ($cur_action['add_reply'] == 0) ? ' selected="selected"' : '',
		'{no_reply_post}' => $lang_admin_moderate['no reply post'],
		'{add_reply_help}' => $lang_admin_moderate['add reply help'],
		'{message}' => $lang_admin_moderate['message'],
		'{reply_message}' => $cur_action['reply_message'],
		'{message_help}' => $lang_admin_moderate['message help'],
		'{submit}' => $lang_common['Submit']
	);

	echo str_replace(array_keys($search), array_values($search), $admin_tpl);
}
else if ($action == 'delete' && $id > '0')
{
	$admin_tpl = panther_template('admin_moderate_delete.tpl');
	$search = array(
		'{actions}' => $lang_admin_moderate['actions'],
		'{admin_moderate_delete}' => panther_link($panther_url['admin_moderate_delete'], array($id)),
		'{delete_action}' => $lang_admin_moderate['delete action'],
		'{delete}' => $lang_admin_common['Delete'],
		'{go_back}' => $lang_common['Go back']
	);

	echo str_replace(array_keys($search), array_values($search), $admin_tpl);
}
else
{
	$ps = $db->select('multi_moderation', 'COUNT(id)');
	$total = $ps->fetchColumn();
	
	$num_pages = ceil($total/15);
	if ($page > $num_pages) $page = 1;
	$start_from = 15*($page-1);
	
	$ps = $db->select('multi_moderation', 'title, id', array(), '', 'id DESC LIMIT '.$start_from.', '.$panther_config['o_disp_topics_default']);

	$moderate = array();
	$moderate_row_tpl = panther_template('admin_moderate_row.tpl');
	foreach ($ps as $action)
	{
		$search = array(
			'{admin_moderate_edit}' => panther_link($panther_url['admin_moderate_edit'], array($action['id'])),
			'{edit_action}' => $lang_admin_moderate['edit action'],
			'{admin_moderate_delete}' => panther_link($panther_url['admin_moderate_delete'], array($action['id'])),
			'{delete_action_2}' => $lang_admin_moderate['delete action 2'],
			'{title}' => $action['title']
		);

		$moderate[] = str_replace(array_keys($search), array_values($search), $moderate_row_tpl);
	}

	$admin_tpl = panther_template('admin_moderate.tpl');
	$search = array(
		'{actions}' => $lang_admin_moderate['actions'],
		'{pages}' => $lang_common['Pages'].' '.paginate($num_pages, $page, $panther_url['admin_moderate'].'?'),
		'{title}' => $lang_admin_moderate['title'],
		'{admin_moderate_add}' => panther_link($panther_url['admin_moderate_add']),
		'{add_new}' => $lang_admin_moderate['add new'],
		'{add_new_label}' => $lang_admin_moderate['add new label'],
		'{moderate_rows}' => count($moderate) ? implode("\n", $moderate) : '',
	);

	echo str_replace(array_keys($search), array_values($search), $admin_tpl);
}
require PANTHER_ROOT.'footer.php';