<?php
/**
 * Copyright (C) 2015 Panther (https://www.pantherforum.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

// Tell header.php to use the help template
define('PANTHER_HELP', 1);

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/');
	require PANTHER_ROOT.'include/common.php';
}

if ($panther_user['g_read_board'] == '0')
	message($lang_common['No view'], false, '403 Forbidden');

// Load the help.php language file
require PANTHER_ROOT.'lang/'.$panther_user['language'].'/help.php';

$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_help['Help']);
define('PANTHER_ACTIVE_PAGE', 'help');
require PANTHER_ROOT.'header.php';

// Display the smiley set
require PANTHER_ROOT.'include/parser.php';

$smiley_groups = array();
foreach ($smilies as $smiley_text => $smiley_img)
	$smiley_groups[$smiley_img][] = $smiley_text;
	
$smiley_path = (($panther_config['o_smilies_dir'] != '') ? $panther_config['o_smilies_dir'] : get_base_url().'/'.$panther_config['o_smilies_path'].'/');

$smiley_groups_array = array();
foreach ($smiley_groups as $smiley_img => $smiley_texts)
	$smiley_groups_array[] = "\t\t".'<p><code>'.implode('</code> '.$lang_common['and'].' <code>', $smiley_texts).'</code> <span>'.$lang_help['produces'].'</span> <samp><img src="'.$smiley_path.$smiley_img.'" width="15" height="15" alt="'.$smiley_texts[0].'" /></samp></p>'."\n";

flux_hook('help_before_display');
$admin_tpl = panther_template('help_content.tpl');

$search = array(
	'{bbcode}' => $lang_help['BBCode'],
	'{bbcode_info_1}' => $lang_help['BBCode info 1'],
	'{bbcode_info_2}' => $lang_help['BBCode info 2'],
	'{text_style}' => $lang_help['Text style'],
	'{text_style_info}' => $lang_help['Text style info'],
	'{bold_text}' => $lang_help['Bold text'],
	'{produces}' => $lang_help['produces'],
	'{underlined_text}' => $lang_help['Underlined text'],
	'{italic_text}' => $lang_help['Italic text'],
	'{strike_through_text}' => $lang_help['Strike-through text'],
	'{deleted_text}' => $lang_help['Deleted text'],
	'{inserted_text}' => $lang_help['Inserted text'],
	'{emphasised_text}' => $lang_help['Emphasised text'],
	'{red_text}' => $lang_help['Red text'],
	'{blue_text}' => $lang_help['Blue text'],
	'{heading_text}' => $lang_help['Heading text'],
	'{links_and_images}' => $lang_help['Links and images'],
	'{links_info}' => $lang_help['Links info'],
	'{/}' => panther_htmlspecialchars(get_base_url(true).'/'),
	'{o_board_title}' => panther_htmlspecialchars($panther_config['o_board_title']),
	'{this_help_page}' => $lang_help['This help page'],
	'{/help.php}' => panther_htmlspecialchars(get_base_url(true).'/help.php'),
	'{my_email_address}' => $lang_help['My email address'],
	'{test_topic}' => $lang_help['Test topic'],
	'{/viewtopic.php?id=1}' => panther_htmlspecialchars(get_base_url(true).'/viewtopic.php?id=1'),
	'{test_post}' => $lang_help['Test post'],
	'{viewtopic.php?pid=1#p1}' => panther_htmlspecialchars(get_base_url(true).'/viewtopic.php?pid=1#p1'),
	'{test_forum}' => $lang_help['Test forum'],
	'{viewforum.php?id=1}' => panther_htmlspecialchars(get_base_url(true).'/viewforum.php?id=1'),
	'{test_user}' => $lang_help['Test user'],
	'{profile.php?id=2}' => panther_htmlspecialchars(get_base_url(true).'/profile.php?id=2'),
	'{images_info}' => $lang_help['Images info'],
	'{panther_bbcode_test}' => $lang_help['Panther bbcode test'],
	'{o_image_dir}' => $panther_config['o_image_dir'],
	'{quotes}' => $lang_help['Quotes'],
	'{quotes_info}' => $lang_help['Quotes info'],
	'{quote_text}' => $lang_help['Quote text'],
	'{produces_quote_box}' => $lang_help['produces quote box'],
	'{wrote}' => $lang_common['wrote'],
	'{quotes_info_2}' => $lang_help['Quotes info 2'],
	'{quote_note}' => $lang_help['quote note'],
	'{code}' => $lang_help['Code'],
	'{code_info}' => $lang_help['Code info'],
	'{code_text}' => $lang_help['Code text'],
	'{produces_code_box}' => $lang_help['produces code box'],
	'{lists}' => $lang_help['Lists'],
	'{list_info}' => $lang_help['List info'],
	'{list_text_1}' => $lang_help['List text 1'],
	'{list_text_2}' => $lang_help['List text 2'],
	'{list_text_3}' => $lang_help['List text 3'],
	'{produces_list}' =>  $lang_help['produces list'],
	'{produces_decimal_list}' => $lang_help['produces decimal list'],
	'{produces_alpha_list}' => $lang_help['produces alpha list'],
	'{nested_tags}' => $lang_help['Nested tags'],
	'{nested_tags_info}' => $lang_help['Nested tags info'],
	'{bold_underlined_text}' => $lang_help['Bold, underlined text'],
	'{smilies}' => $lang_help['Smilies'],
	'{smilies_info}' => $lang_help['Smilies info'],
	'{smiley_groups}' => count($smiley_groups_array) ? implode("\n", $smiley_groups_array) : ''
);

echo str_replace(array_keys($search), array_values($search), $admin_tpl);

require PANTHER_ROOT.'footer.php';