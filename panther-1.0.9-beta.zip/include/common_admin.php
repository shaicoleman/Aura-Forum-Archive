<?php
/**
 * Copyright (C) 2015 Panther (https://www.pantherforum.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

// Make sure no one attempts to run this script "directly"
if (!defined('PANTHER'))
	exit;

// Make sure we have a usable language pack for admin.
if (file_exists(PANTHER_ROOT.'lang/'.$panther_user['language'].'/admin_common.php'))
	$admin_language = $panther_user['language'];
else if (file_exists(PANTHER_ROOT.'lang/'.$panther_config['o_default_lang'].'/admin_common.php'))
	$admin_language = $panther_config['o_default_lang'];
else
	$admin_language = 'English';

if (file_exists(FORUM_CACHE_DIR.'cache_restrictions.php'))
	require FORUM_CACHE_DIR.'cache_restrictions.php';
else
{
	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PANTHER_ROOT.'include/cache.php';
   
	generate_admin_restrictions_cache();
	require FORUM_CACHE_DIR.'cache_restrictions.php';
}

if (!isset($admins[$panther_user['id']]) || $panther_user['id'] == '2')
	$admins[$panther_user['id']] = array(
		'admin_options' => 1,
		'admin_permissions' => 1,
		'admin_categories' => 1,
		'admin_forums' => 1,
		'admin_groups' => 1,
		'admin_censoring' => 1,
		'admin_maintenance' => 1,
		'admin_plugins' => 1,
		'admin_restrictions' => 1,
		'admin_users' => 1,
		'admin_moderate' => 1,
		'admin_ranks' => 1,
		'admin_updates' => 1,
		'admin_archive' => 1,
		'admin_smilies' => 1,
		'admin_warnings' => 1,
		'admin_attachments' => 1,
		'admin_robots' => 1,
		'admin_addons' => 1,
		'admin_tasks' => 1,
	);

// Attempt to load the admin_common language file
require PANTHER_ROOT.'lang/'.$admin_language.'/admin_common.php';

//
// Display the admin navigation menu
//
function generate_admin_menu($page = '')
{
	global $panther_config, $panther_user, $lang_admin_common, $admins, $panther_url, $panther_updates;

	$admin_menu = array();

	if ($admins[$panther_user['id']]['admin_options'] == '1')
		$admin_menu[] = '<li'.(($page == 'options') ? ' class="isactive"' : '').'><a href="'.panther_link($panther_url['admin_options']).'">'.$lang_admin_common['Options'].'</a></li>';

	if ($admins[$panther_user['id']]['admin_archive'] == '1')
		$admin_menu[] = '<li'.(($page == 'archive') ? ' class="isactive"' : '').'><a href="'.panther_link($panther_url['admin_archive']).'">'.$lang_admin_common['Archive'].'</a></li>';

	if ($admins[$panther_user['id']]['admin_permissions'] == '1')
		$admin_menu[] = '<li'.(($page == 'permissions') ? ' class="isactive"' : '').'><a href="'.panther_link($panther_url['admin_permissions']).'">'.$lang_admin_common['Permissions'].'</a></li>';

	if ($admins[$panther_user['id']]['admin_categories'] == '1')
		$admin_menu[] = '<li'.(($page == 'categories') ? ' class="isactive"' : '').'><a href="'.panther_link($panther_url['admin_categories']).'">'.$lang_admin_common['Categories'].'</a></li>';

	if ($admins[$panther_user['id']]['admin_forums'] == '1')
		$admin_menu[] = '<li'.(($page == 'forums') ? ' class="isactive"' : '').'><a href="'.panther_link($panther_url['admin_forums']).'">'.$lang_admin_common['Forums'].'</a></li>';
		
	if ($admins[$panther_user['id']]['admin_groups'] == '1')
		$admin_menu[] = '<li'.(($page == 'groups') ? ' class="isactive"' : '').'><a href="'.panther_link($panther_url['admin_groups']).'">'.$lang_admin_common['User groups'].'</a></li>';
		
	if ($admins[$panther_user['id']]['admin_censoring'] == '1')
		$admin_menu[] = '<li'.(($page == 'censoring') ? ' class="isactive"' : '').'><a href="'.panther_link($panther_url['admin_censoring']).'">'.$lang_admin_common['Censoring'].'</a></li>';

    if ($admins[$panther_user['id']]['admin_ranks'] == '1') 
        $admin_menu[] = '<li'.(($page == 'ranks') ? ' class="isactive"' : '').'><a href="'.panther_link($panther_url['admin_ranks']).'">'.$lang_admin_common['Ranks'].'</a></li>'; 

	if ($admins[$panther_user['id']]['admin_robots'] == '1')
		$admin_menu[] = '<li'.(($page == 'robots') ? ' class="isactive"' : '').'><a href="'.panther_link($panther_url['admin_robots']).'">'.$lang_admin_common['Robots'].'</a></li>';

	if ($admins[$panther_user['id']]['admin_smilies'] == '1' && $panther_config['o_smilies'] == '1')
		$admin_menu[] = '<li'.(($page == 'smilies') ? ' class="isactive"' : '').'><a href="'.panther_link($panther_url['admin_smilies']).'">'.$lang_admin_common['Smilies'].'</a></li>';
		
	if ($admins[$panther_user['id']]['admin_warnings'] == '1' && $panther_config['o_warnings'] == '1')
		$admin_menu[] = '<li'.(($page == 'warnings') ? ' class="isactive"' : '').'><a href="'.panther_link($panther_url['admin_warnings']).'">'.$lang_admin_common['Warnings'].'</a></li>';

	if ($admins[$panther_user['id']]['admin_moderate'] == '1')
		$admin_menu[] = '<li'.(($page == 'moderate') ? ' class="isactive"' : '').'><a href="'.panther_link($panther_url['admin_moderate']).'">'.$lang_admin_common['Moderate'].'</a></li>';

	if ($admins[$panther_user['id']]['admin_attachments'] == '1' && $panther_config['o_attachments'] == '1')
		$admin_menu[] = '<li'.(($page == 'attachments') ? ' class="isactive"' : '').'><a href="'.panther_link($panther_url['admin_attachments']).'">'.$lang_admin_common['Attachments'].'</a></li>';

	if ($admins[$panther_user['id']]['admin_restrictions'] == '1')
		$admin_menu[] = '<li'.(($page == 'restrictions') ? ' class="isactive"' : '').'><a href="'.panther_link($panther_url['admin_restrictions']).'">'.$lang_admin_common['Restrictions'].'</a></li>';

	if ($admins[$panther_user['id']]['admin_tasks'] == '1')
		$admin_menu[] = '<li'.(($page == 'tasks') ? ' class="isactive"' : '').'><a href="'.panther_link($panther_url['admin_tasks']).'">'.$lang_admin_common['Tasks'].'</a></li>';

	if ($admins[$panther_user['id']]['admin_addons'] == '1')
		$admin_menu[] = '<li'.(($page == 'addons') ? ' class="isactive"' : '').'><a href="'.panther_link($panther_url['admin_addons']).'">'.$lang_admin_common['Addons'].'</a></li>';

	if ($admins[$panther_user['id']]['admin_maintenance'] == '1')
		$admin_menu[] = '<li'.(($page == 'maintenance') ? ' class="isactive"' : '').'><a href="'.panther_link($panther_url['admin_maintenance']).'">'.$lang_admin_common['Maintenance'].'</a></li>';

	if ($admins[$panther_user['id']]['admin_updates'] == '1' && version_compare($panther_config['o_cur_version'], $panther_updates['version'], '<') && $panther_config['o_download_updates'] == '1')
		$admin_menu[] = '<li'.(($page == 'updates') ? ' class="isactive"' : '').'><a href="'.panther_link($panther_url['admin_updates']).'">'.$lang_admin_common['Updates'].'</a></li>';

	$menu_tpl = panther_template('admin_menu.tpl');
	if ($panther_user['is_admin'] && count($admin_menu))
	{
		$search = array(
			'{menu}' => $lang_admin_common['Admin menu'],
			'{menu_items}' => implode("\n\t\t\t\t\t", $admin_menu),
		);

		$admin_menu_tpl = str_replace(array_keys($search), array_values($search), $menu_tpl);
	}
	else
		$admin_menu_tpl = '';

	// See if there are any plugins
	$plugins = forum_list_plugins($panther_user['is_admin']);

	// Did we find any plugins?
	if (!empty($plugins) && ($admins[$panther_user['id']]['admin_plugins'] == '1'))
	{
		$plugin_files = array();
		foreach ($plugins as $plugin_name => $plugin)
			$plugin_files[] = "\t\t\t\t\t".'<li'.(($page == $plugin_name) ? ' class="isactive"' : '').'><a href="'.panther_link($panther_url['admin_loader'], array($plugin_name)).'">'.str_replace('_', ' ', $plugin).'</a></li>'."\n";

		$search = array(
			'{menu}' => $lang_admin_common['Plugins menu'],
			'{menu_items}' => implode("\n\t\t\t\t\t", $plugin_files)."\n",
		);

		$plugin_tpl = str_replace(array_keys($search), array_values($search), $menu_tpl);
	}
	else
		$plugin_tpl = '';

	$sidebar_tpl = panther_template('admin_sidebar.tpl');
	$search = array(
		'{moderator_menu}' => $lang_admin_common['Moderator menu'],
		'{index_active}' => ($page == 'index') ? ' class="isactive"' : '',
		'{index_link}' => panther_link($panther_url['admin_index']),
		'{index}' => $lang_admin_common['Index'],
		'{users_link}' => panther_link($panther_url['admin_users']),
		'{users}' => $lang_admin_common['Users'],
		'{users_active}' => ($page == 'users') ? ' class="isactive"' : '',
		'{announcements_active}' => (($page == 'announcements') ? ' class="isactive"' : ''),
		'{announcements_link}' => panther_link($panther_url['admin_announcements']),
		'{announcements}' => $lang_admin_common['Announcements'],
		'{posts_active}' => (($page == 'posts') ? ' class="isactive"' : ''),
		'{posts_link}' => panther_link($panther_url['admin_posts']),
		'{posts}' => $lang_admin_common['Posts'],
		'{ban_option}' => ($panther_user['is_admin'] || $panther_user['g_mod_ban_users'] == '1') ? "\n".'<li'.(($page == 'bans') ? ' class="isactive"' : '').'><a href="'.panther_link($panther_url['admin_bans']).'">'.$lang_admin_common['Bans'].'</a></li>' : '',
		'{report_option}' => ($panther_user['is_admin'] || $panther_config['o_report_method'] == '0' || $panther_config['o_report_method'] == '2') ? "\n".'<li'.(($page == 'reports') ? ' class="isactive"' : '').'><a href="'.panther_link($panther_url['admin_reports']).'">'.$lang_admin_common['Reports'].'</a></li>' : '',
		'{deleted_option}' => ($panther_config['o_delete_full'] == '0') ? "\n".'<li'.(($page == 'deleted') ? ' class="isactive"' : '').'><a href="'.panther_link($panther_url['admin_deleted']).'">'.$lang_admin_common['Deleted'].'</a></li>' : '',
		'{admin_menu}' => $admin_menu_tpl,
		'{plugin_menu}' => $plugin_tpl,
	);
	
	echo str_replace(array_keys($search), array_values($search), $sidebar_tpl);
}

//
// Delete topics from $forum_id that are "older than" $prune_date (if $prune_sticky is 1, sticky topics will also be deleted)
//
function prune($forum_id, $prune_sticky, $prune_date)
{
	global $db;
	
	$data = array(
		':id'	=>	$forum_id,
	);

	$where_cond = 'forum_id=:id';
	if ($prune_date != -1)
	{
		$where_cond .= ' And last_post<:last_post';
		$data[':last_post'] = $prune_date;
	}

	if (!$prune_sticky)
		$where_cond .= ' AND sticky=0';

	// Fetch topics to prune
	$ps = $db->select('topics', 'id', $data, $where_cond);

	$topic_ids = array();
	foreach ($ps as $cur_topic)
	{
		$topic_ids[] = $cur_topic['id'];
		$placeholders[] = '?';
	}

	if (!empty($topic_ids))
	{
		// Fetch posts to prune
		$ps = $db->run('SELECT id FROM '.$db->prefix.'posts WHERE topic_id IN('.implode(',', $placeholders).')', $topic_ids);

		$post_ids = array();
		foreach ($ps as $cur_post)
		{
			$markers[] = '?';
			$post_ids[] = $cur_post['id'];
		}

		if ($post_ids != '')
		{
			$db->run('DELETE FROM '.$db->prefix.'topics WHERE id IN('.implode(',', $placeholders).')', $topic_ids);
			$db->run('DELETE FROM '.$db->prefix.'topic_subscriptions WHERE topic_id IN('.implode(',', $placeholders).')', $topic_ids);
			$db->run('DELETE FROM '.$db->prefix.'posts WHERE id IN('.implode(',', $markers).')', $post_ids);

			// We removed a bunch of posts, so now we have to update the search index
			require_once PANTHER_ROOT.'include/search_idx.php';
			strip_search_index($post_ids);
		}
	}
}

//
// Fetch a list of available admin plugins
//
function forum_list_plugins($is_admin)
{
	$plugins = array();
	$files = array_diff(scandir(PANTHER_ROOT.PANTHER_ADMIN_DIR.'/plugins'), array('.', '..'));
	foreach ($files as $entry)
	{
		$prefix = substr($entry, 0, strpos($entry, '_'));
		$suffix = substr($entry, strlen($entry) - 4);

		if ($suffix == '.php' && ((!$is_admin && $prefix == 'AMP') || ($is_admin && ($prefix == 'AP' || $prefix == 'AMP'))))
			$plugins[$entry] = substr($entry, strpos($entry, '_') + 1, -4);
	}

	natcasesort($plugins);
	return $plugins;
}