<?php
/**
 * Copyright (C) 2015 Panther (https://www.pantherforum.org)
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

// Make sure no one attempts to run this script "directly"
if (!defined('PANTHER'))
	exit;

class panther_updater
{
	var $panther_updates;
	public function __construct($db, $panther_config, $lang_common)
	{
		$this->db = $db;
		$this->panther_config = $panther_config;
		$this->lang = $lang_common;

		if (file_exists(FORUM_CACHE_DIR.'cache_updates.php'))
			require FORUM_CACHE_DIR.'cache_updates.php';
		else
		{
			if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
				require PANTHER_ROOT.'include/cache.php';

			generate_update_cache();
			require FORUM_CACHE_DIR.'cache_updates.php';
		}
	}

	public function download($background = true)
	{
		$this->file_name = 'panther-update-patch-'.$this->version_friendly($this->panther_updates['version']).'.zip';
		if (file_exists(PANTHER_ROOT.'include/updates/'.$this->file_name))
			return;

		if ($this->panther_config['o_download_updates'] == '1' && version_compare($this->panther_config['o_cur_version'], $this->panther_updates['version'], '<') && !file_exists(PANTHER_ROOT.'include/updates/'.$this->file_name))
		{
			if (is_callable('curl_init'))
			{
				$ch = curl_init();
				curl_setopt($ch, CURLOPT_URL, 'https://www.pantherforum.org/get_patch.php');
				curl_setopt($ch, CURLOPT_HEADER, false);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($ch, CURLOPT_POST, true);
				curl_setopt($ch, CURLOPT_POSTFIELDS, array(
					'version' => $this->panther_updates['version'],
				));

				$result = curl_exec($ch);
				curl_close($ch);

				file_put_contents(PANTHER_ROOT.'include/updates/'.$this->file_name, $result);
				if (!file_exists(PANTHER_ROOT.'include/updates/'.$this->file_name))
				{
					if (!$background)
						exit($this->lang['update failed']);
				}
			}
			else
			{
				if (!$background)
					exit($this->lang['curl disabled']);
			}
		}
	}

	public function install()
	{
		if (class_exists('ZipArchive'))
		{
			$zip = new ZipArchive();
			if ($zip->open(PANTHER_ROOT.'include/updates/'.$this->file_name))
			{
				if (!is_dir(PANTHER_ROOT.'include/updates/'.$this->version_friendly($this->panther_updates['version'])))
					mkdir(PANTHER_ROOT.'include/updates/'.$this->version_friendly($this->panther_updates['version']));

				$zip->extractTo(PANTHER_ROOT.'include/updates/'.$this->version_friendly($this->panther_updates['version']));
				$zip->close();

				unlink(PANTHER_ROOT.'include/updates/'.$this->file_name);
				if (file_exists(PANTHER_ROOT.'include/updates/'.$this->version_friendly($this->panther_updates['version']).'/panther_database.php'))
					require PANTHER_ROOT.'include/updates/'.$this->version_friendly($this->panther_updates['version']).'/panther_database.php';

				if (!defined('PANTHER_REQUIRED_MYSQL') || !defined('PANTHER_REQUIRED_PHP') || !defined('PANTHER_NEW_VERSION'))
					exit($this->lang['Invalid update patch']);

				$mysql = $db->get_version();
				$php_version = phpversion();

				if (PANTHER_REQUIRED_MYSQL > $mysql['version'] || PANTHER_REQUIRED_PHP > $php_version)
					exit(sprintf($this->lang['Hosting environment does not support Panther x'], panther_htmlspecialchars(PANTHER_NEW_VERSION), panther_htmlspecialchars(PANTHER_REQUIRED_MYSQL), panther_htmlspecialchars(PANTHER_REQUIRED_PHP), $mysql['version'], $php_version));

				if (isset($this->database)) // There are updates to perform for the Panther database
				{
					if (isset($this->database['alter']) && count($this->database['alter']) > 0)
					{
						foreach ($this->database['alter'] as $table => $query)
							$db->run('ALTER TABLE '.$db->prefix.$table.$query);
					}

					if (isset($this->database['drop']) && count($this->database['drop']) > 0)
					{
						foreach ($this->database['drop'] as $table => $query)
							$db->drop_table($table);
					}

					if (isset($this->database['create']) && count($this->database['create']) > 0)
					{
						foreach ($this->database['create'] as $table => $schema)
							$db->create_table($table, $schema);
					}

					if (isset($this->database['rename']) && count($this->database['rename']) > 0)
					{
						foreach ($this->database['rename'] as $old_name => $new_name)
							$db->rename_table($old_name, $new_name);
					}

					if (isset($this->database['drop_field']) && count($this->database['drop_field']) > 0)
					{
						foreach ($this->database['drop_field'] as $table => $field)
							$db->drop_field($table, $field);
					}

					if (isset($this->database['query']) && count($this->database['query']) > 0)
					{
						foreach ($this->database['query'] as $table => $query)
						{
							$query = str_replace($table, $db->prefix.$table, $query); // Make sure a valid database prefix is present.
							$db->run($query);
						}
					}

					$db->end_transaction();
					$db->close();
				}

				if (file_exists(PANTHER_ROOT.'include/updates/'.$this->version_friendly($this->panther_updates['version']).'/panther_updates.php'))
				{
					require PANTHER_ROOT.'include/updates/'.$this->version_friendly($this->panther_updates['version']).'/panther_updates.php';
					if (isset($this->updates['replace_file']))
					{
						foreach ($this->updates['replace_file'] as $file => $replace)
						{
							if (file_exists(PANTHER_ROOT.$file))
								unlink(PANTHER_ROOT.$file);

							rename(PANTHER_ROOT.'include/updates/'.$this->version_friendly($this->panther_updates['version']).'/'.$replace, PANTHER_ROOT.$file);
						}
					}

					if (isset($this->updates['add_file']))
					{
						foreach ($this->updates['add_file'] as $file => $replace)
							rename(PANTHER_ROOT.'include/updates/'.$this->version_friendly($this->panther_updates['version']).'/'.$replace, PANTHER_ROOT.$file);
					}

					if (isset($this->updates['remove_file']))
					{
						foreach ($this->updates['remove_file'] as $file => $replace)
							unlink(PANTHER_ROOT.$file);
					}
				}

				$files = array_diff(scandir(PANTHER_ROOT.'include/updates/'.$this->version_friendly($this->panther_updates['version'])), array('.', '..'));
				foreach ($files as $file)
					unlink(PANTHER_ROOT.'include/updates/'.$this->version_friendly($this->panther_updates['version']).'/'.$file);

				rmdir(PANTHER_ROOT.'include/updates/'.$this->version_friendly($this->panther_updates['version']));
				forum_clear_cache();
			}
			else
				exit(sprintf($this->lang['Unable to open archive'], $this->file_name));
		}
		else
			exit(sprintf($this->lang['ZipArchive not supported'], $panther_updates['version']));	
	}

	public function version_friendly($str)
	{
		$str = strtolower(utf8_decode($str));
		$str = panther_trim(preg_replace(array('/[^a-z0-9\s.]/', '/[\s]+/'), array('', '-'), $str), '-');

		return $str;
	}
}