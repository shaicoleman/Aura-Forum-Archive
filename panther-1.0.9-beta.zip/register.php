<?php
/**
 * Copyright (C) 2015 Panther (https://www.pantherforum.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/');
	require PANTHER_ROOT.'include/common.php';
}

if ($panther_user['is_bot'])
	message($lang_common['No permission']);

// If we are logged in, we shouldn't be here
if (!$panther_user['is_guest'])
{
	header('Location: '.panther_link($panther_url['index']));
	exit;
}

// Load the register.php language file
require PANTHER_ROOT.'lang/'.$panther_user['language'].'/register.php';

// Load the register.php/profile.php language file
require PANTHER_ROOT.'lang/'.$panther_user['language'].'/prof_reg.php';

if (file_exists(FORUM_CACHE_DIR.'cache_robots.php'))
	include FORUM_CACHE_DIR.'cache_robots.php';

if (!defined('PANTHER_ROBOTS_LOADED'))
{
	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PANTHER_ROOT.'include/cache.php';

	generate_robots_cache();
	require FORUM_CACHE_DIR.'cache_robots.php';
}

if ($panther_config['o_regs_allow'] == '0')
	message($lang_register['No new regs']);

// User pressed the cancel button
if (isset($_GET['cancel']))
	redirect(panther_link($panther_url['index']), $lang_register['Reg cancel redirect']);

else if ($panther_config['o_rules'] == '1' && !isset($_GET['agree']) && !isset($_POST['form_sent']))
{
	$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_register['Register'], $lang_register['Forum rules']);
	define('PANTHER_ACTIVE_PAGE', 'register');
	require PANTHER_ROOT.'header.php';

	$rules_tpl = panther_template('register_rules.tpl');
	$search = array(
		'{forum_rules}' => $lang_register['Forum rules'],
		'{form_action}' => panther_link($panther_url['register']),
		'{rules_legend}' => $lang_register['Rules legend'],
		'{rules_message}' => $panther_config['o_rules_message'],
		'{agree}' => $lang_register['Agree'],
		'{cancel}' => $lang_register['Cancel'],
	);

	echo str_replace(array_keys($search), array_values($search), $rules_tpl);
	require PANTHER_ROOT.'footer.php';
}

// Start with a clean slate
$errors = array();
if (isset($_POST['form_sent']))
{
	flux_hook('register_before_validation');
	confirm_referrer('register.php');

	// Check that someone from this IP didn't register a user within the last hour (DoS prevention)
	$data = array(
		':remote_address'	=>	get_remote_address(),
		':registered'		=>	(time() - 7200),
	);

	$ps = $db->select('users', 1, $data, 'registration_ip=:remote_address AND registered>:registered');
	if ($ps->rowCount())
		$errors[] = $lang_register['Registration flood'];
	
	if (!empty($panther_robots))
	{
		$id = isset($_POST['id']) ? intval($_POST['id']) : 0;
		$answer = isset($_POST['answer']) ? panther_trim($_POST['answer']) : '';

		if (!isset($panther_robots[$id]) || $answer != $panther_robots[$id]['answer'])
			$errors[] = $lang_common['Robot test fail'];
	}

	$username = isset($_POST['req_user']) ? panther_trim($_POST['req_user']) : '';
	$email1 = isset($_POST['req_email1']) ? strtolower(panther_trim($_POST['req_email1'])) : '';
	$password_salt = random_pass(16);
	
	if ($panther_config['o_regs_verify'] == '1')
	{
		$email2 = isset($_POST['req_email2']) ? strtolower(panther_trim($_POST['req_email2'])) : '';

		$password1 = random_pass(12);
		$password2 = $password1;
	}
	else
	{
		$password1 = isset($_POST['req_password1']) ? panther_trim($_POST['req_password1']) : '';
		$password2 = isset($_POST['req_password2']) ? panther_trim($_POST['req_password2']) : '';
	}

	// Validate username and passwords
	check_username($username);

	if (panther_strlen($password1) < 6)
		$errors[] = $lang_prof_reg['Pass too short'];
	else if ($password1 != $password2)
		$errors[] = $lang_prof_reg['Pass not match'];

	// Validate email
	require PANTHER_ROOT.'include/email.php';

	if (!is_valid_email($email1))
		$errors[] = $lang_common['Invalid email'];
	else if ($panther_config['o_regs_verify'] == '1' && $email1 != $email2)
		$errors[] = $lang_register['Email not match'];

	// Check if it's a banned email address
	if (is_banned_email($email1))
	{
		if ($panther_config['p_allow_banned_email'] == '0')
			$errors[] = $lang_prof_reg['Banned email'];

		$banned_email = true; // Used later when we send an alert email
	}
	else
		$banned_email = false;

	// Check if someone else already has registered with that email address
	$dupe_list = array();
	$data = array(
		':email'	=>	$email1
	);
	$ps = $db->select('users', 'username', $data, 'email=:email');
	if ($ps->rowCount())
	{
		if ($panther_config['p_allow_dupe_email'] == '0')
			$errors[] = $lang_prof_reg['Dupe email'];

		$ps->setFetchMode(PDO::FETCH_COLUMN, 0);
		foreach ($ps as $cur_dupe)
			$dupe_list[] = $cur_dupe;
	}

	// Make sure we got a valid language string
	if (isset($_POST['language']))
	{
		$language = preg_replace('%[\.\\\/]%', '', $_POST['language']);
		if (!file_exists(PANTHER_ROOT.'lang/'.$language.'/common.php'))
			message($lang_common['Bad request'], false, '404 Not Found');
	}
	else
		$language = $panther_config['o_default_lang'];

	$timezone = isset($_POST['timezone']) ? round($_POST['timezone'], 1) : '';

	$dst = isset($_POST['dst']) ? 1 : 0;

	$email_setting = intval($_POST['email_setting']);
	if ($email_setting < 0 || $email_setting > 2)
		$email_setting = $panther_config['o_default_email_setting'];

	flux_hook('register_after_validation');
	$url_username = url_friendly($username);

	// Did everything go according to plan?
	if (empty($errors))
	{
		// Insert the new user into the database. We do this now to get the last inserted ID for later use
		$now = time();

		$initial_group_id = ($panther_config['o_regs_verify'] == '0') ? $panther_config['o_default_user_group'] : PANTHER_UNVERIFIED;
		$password_hash = panther_hash($password1.$password_salt);

		// Add the user
		$insert = array(
			'username'	=>	$username,
			'group_id'	=>	$initial_group_id,
			'password'	=>	$password_hash,
			'salt'		=>	$password_salt,
			'email'		=>	$email1,
			'email_setting'	=>	$email_setting,
			'timezone'	=>	$timezone,
			'dst'		=>	$dst,
			'language'	=>	$language,
			'style'		=>	$panther_config['o_default_style'],
			'registered'	=>	$now,
			'registration_ip'	=>	get_remote_address(),
			'last_visit'	=>	$now,
		);

		$db->insert('users', $insert);
		$new_uid = $db->lastInsertId($db->prefix.'users');
		$login_key = generate_login_key($new_uid);

		if ($panther_config['o_regs_verify'] == '0')
		{
			// Regenerate the users info cache
			if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
				require PANTHER_ROOT.'include/cache.php';

			generate_users_info_cache();
		}

		// If the mailing list isn't empty, we may need to send out some alerts
		if ($panther_config['o_mailing_list'] != '')
		{
			// If we previously found out that the email was banned
			if ($banned_email)
			{
				// Load the "banned email register" template
				$mail_tpl = trim(file_get_contents(PANTHER_ROOT.'lang/'.$panther_user['language'].'/mail_templates/banned_email_register.tpl'));

				// The first row contains the subject
				$first_crlf = strpos($mail_tpl, "\n");
				$mail_subject = trim(substr($mail_tpl, 8, $first_crlf-8));
				$mail_message = trim(substr($mail_tpl, $first_crlf));

				$mail_message = str_replace('<username>', $username, $mail_message);
				$mail_message = str_replace('<email>', $email1, $mail_message);
				$mail_message = str_replace('<profile_url>', panther_link($panther_url['profile'], array($new_uid, $url_username)), $mail_message);
				$mail_message = str_replace('<board_mailer>', $panther_config['o_board_title'], $mail_message);

				panther_mail($panther_config['o_mailing_list'], $mail_subject, $mail_message);
			}

			// If we previously found out that the email was a dupe
			if (!empty($dupe_list))
			{
				// Load the "dupe email register" template
				$mail_tpl = trim(file_get_contents(PANTHER_ROOT.'lang/'.$panther_user['language'].'/mail_templates/dupe_email_register.tpl'));

				// The first row contains the subject
				$first_crlf = strpos($mail_tpl, "\n");
				$mail_subject = trim(substr($mail_tpl, 8, $first_crlf-8));
				$mail_message = trim(substr($mail_tpl, $first_crlf));

				$mail_message = str_replace('<username>', $username, $mail_message);
				$mail_message = str_replace('<dupe_list>', implode(', ', $dupe_list), $mail_message);
				$mail_message = str_replace('<profile_url>', panther_link($panther_url['profile'], array($new_uid, $url_username)), $mail_message);
				$mail_message = str_replace('<board_mailer>', $panther_config['o_board_title'], $mail_message);

				panther_mail($panther_config['o_mailing_list'], $mail_subject, $mail_message);
			}

			// Should we alert people on the admin mailing list that a new user has registered?
			if ($panther_config['o_regs_report'] == '1')
			{
				// Load the "new user" template
				$mail_tpl = trim(file_get_contents(PANTHER_ROOT.'lang/'.$panther_user['language'].'/mail_templates/new_user.tpl'));

				// The first row contains the subject
				$first_crlf = strpos($mail_tpl, "\n");
				$mail_subject = trim(substr($mail_tpl, 8, $first_crlf-8));
				$mail_message = trim(substr($mail_tpl, $first_crlf));

				$mail_message = str_replace('<username>', $username, $mail_message);
				$mail_message = str_replace('<base_url>', get_base_url().'/', $mail_message);
				$mail_message = str_replace('<profile_url>', panther_link($panther_url['profile'], array($new_uid, $url_username)), $mail_message);
				$mail_message = str_replace('<admin_url>', panther_link($panther_url['profile_admin'], array($new_uid)), $mail_message);
				$mail_message = str_replace('<board_mailer>', $panther_config['o_board_title'], $mail_message);

				panther_mail($panther_config['o_mailing_list'], $mail_subject, $mail_message);
			}
		}

		// Must the user verify the registration or do we log him/her in right now?
		if ($panther_config['o_regs_verify'] == '1')
		{
			// Load the "welcome" template
			$mail_tpl = trim(file_get_contents(PANTHER_ROOT.'lang/'.$panther_user['language'].'/mail_templates/welcome.tpl'));

			// The first row contains the subject
			$first_crlf = strpos($mail_tpl, "\n");
			$mail_subject = trim(substr($mail_tpl, 8, $first_crlf-8));
			$mail_message = trim(substr($mail_tpl, $first_crlf));

			$mail_subject = str_replace('<board_title>', $panther_config['o_board_title'], $mail_subject);
			$mail_message = str_replace('<base_url>', get_base_url().'/', $mail_message);
			$mail_message = str_replace('<username>', $username, $mail_message);
			$mail_message = str_replace('<password>', $password1, $mail_message);
			$mail_message = str_replace('<login_url>', panther_link($panther_url['login']), $mail_message);
			$mail_message = str_replace('<board_mailer>', $panther_config['o_board_title'], $mail_message);

			panther_mail($email1, $mail_subject, $mail_message);

			message(sprintf($lang_register['Reg email'], ' <a href="mailto:'.panther_htmlspecialchars($panther_config['o_admin_email']).'">'.panther_htmlspecialchars($panther_config['o_admin_email']).'</a>.'), true);
		}

		panther_setcookie($new_uid, $login_key, time() + $panther_config['o_timeout_visit']);
		redirect(panther_link($panther_url['index']), $lang_register['Reg complete']);
	}
}

$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_register['Register']);
$required_fields = array('req_user' => $lang_common['Username'], 'req_password1' => $lang_common['Password'], 'req_password2' => $lang_prof_reg['Confirm pass'], 'req_email1' => $lang_common['Email'], 'req_email2' => $lang_common['Email'].' 2');
$focus_element = array('register', 'req_user');

if (!empty($panther_robots))
	$required_fields['answer'] = $lang_common['Robot title'];

flux_hook('register_before_header');

define('PANTHER_ACTIVE_PAGE', 'register');
require PANTHER_ROOT.'header.php';

$timezone = isset($timezone) ? $timezone : $panther_config['o_default_timezone'];
$dst = isset($dst) ? $dst : $panther_config['o_default_dst'];
$email_setting = isset($email_setting) ? $email_setting : $panther_config['o_default_email_setting'];

// If there are errors, we display them
if (!empty($errors))
{
    $form_errors = array();
	foreach ($errors as $cur_error)
		$form_errors[] = "\t\t\t\t".'<li><strong>'.$cur_error.'</strong></li>';

    $error_tpl = panther_template('inline_errors.tpl');
    $search = array(
        '{errors}' => $lang_register['Registration errors'],
        '{errors_info}' => $lang_register['Registration errors info'],
        '{error_list}' => implode("\n", $form_errors),
    );

    echo str_replace(array_keys($search), array_values($search), $error_tpl);
}

$register_tpl = panther_template('register.tpl');
if (!empty($panther_robots))
{
	$robot_tpl = panther_template('robot_tests.tpl');
	
	$id = array_rand($panther_robots);
	$test = $panther_robots[$id];

	$search = array(
		'{robot_title}' => $lang_common['Robot title'],
		'{robot_info}' => $lang_common['Robot info'],
		'{robot_question}' => panther_htmlspecialchars($test['question']),
		'{required}' => $lang_common['Required'],
		'{answer}' => $id,
	);

	$robot_tpl = "\n".str_replace(array_keys($search), array_values($search), $robot_tpl);
}
else
	$robot_tpl = '';

if ($panther_config['o_regs_verify'] == '0')
{
	$password_tpl = panther_template('register_password_field.tpl');
	$search = array(
		'{password_legend}' => $lang_register['Pass legend'],
		'{password}' => $lang_common['Password'],
		'{password1_value}' => (isset($_POST['req_password1'])) ? panther_htmlspecialchars($_POST['req_password1']) : '',
		'{password2_value}' => (isset($_POST['req_password2'])) ? panther_htmlspecialchars($_POST['req_password2']) : '',
		'{confirm_pass}' => $lang_prof_reg['Confirm pass'],
		'{password_info}' => $lang_register['Pass info'],
	);
	
	$password_tpl = "\n".str_replace(array_keys($search), array_values($search), $password_tpl);
}
else
	$password_tpl = '';

$options = array();
$languages = forum_list_langs();
	
// Only display the language selection box if there's more than one language available
if (count($languages) > 1)
{
	foreach ($languages as $temp)
		$options[] = "\t\t\t\t\t\t\t\t".'<option value="'.$temp.'"'.(($panther_config['o_default_lang'] == $temp) ? 'selected="selected"' : '').'>'.$temp.'</option>'."\n";

	$language_tpl = '<label>'.$lang_prof_reg['Language']."\n\t\t\t\t\t\t\t".'<br /><select name="language">'."\n\t\t\t\t\t\t\t".implode('', $options).'</select>'."\n\t\t\t\t\t\t\t".'<br /></label>';
}
else
	$language_tpl = '';

$search = array(
	'{register}' => $lang_register['Register'],
	'{form_action}' => panther_link($panther_url['register_register']),
	'{important}' => $lang_common['Important information'],
	'{description_1}' => $lang_register['Desc 1'],
	'{description_2}' => $lang_register['Desc 2'],
	'{username_legend}' => $lang_register['Username legend'],
	'{csrf_token}' => generate_csrf_token(),
	'{username}' => $lang_common['Username'],
	'{required}' => $lang_common['Required'],
	'{username_value}' => (isset($_POST['req_user'])) ? panther_htmlspecialchars($_POST['req_user']) : '',
	'{password_fields}' => $password_tpl,
	'{email_legend}' => ($panther_config['o_regs_verify'] == '1') ? $lang_prof_reg['Email legend 2'] : $lang_prof_reg['Email legend'],
	'{email_info}' => ($panther_config['o_regs_verify'] == '1') ? "\n\t\t\t\t\t\t".'<p>'.$lang_register['Email info'].'</p>' : '',
	'{email}' => $lang_common['Email'],
	'{email_value1}' => (isset($_POST['req_email1'])) ? panther_htmlspecialchars($_POST['req_email1']) : '',
	'{email_input2}' => ($panther_config['o_regs_verify'] == '1') ? "\n\t\t\t\t\t\t".'<label class="required"><strong>'.$lang_register['Confirm email'].' <span>'.$lang_common['Required'].'</span></strong><br />'."\n\t\t\t\t\t\t".'<input type="text" name="req_email2" value="'.((isset($_POST['req_email2'])) ? panther_htmlspecialchars($_POST['req_email2']) : '').'" size="50" maxlength="80" /><br /></label>' : '',
	'{localisation}' => $lang_prof_reg['Localisation legend'],
	'{timezone_info}' => $lang_prof_reg['Time zone info'],
	'{timezone}' => $lang_prof_reg['Time zone'],
	'{timezone_-12_select}' => ($timezone == -12) ? ' selected="selected"' : '',
	'{timezone_-11_select}' => ($timezone == -11) ? ' selected="selected"' : '',
	'{timezone_-10_select}' => ($timezone == -10) ? ' selected="selected"' : '',
	'{timezone_-9.5_select}' => ($timezone == -9.5) ? ' selected="selected"' : '',
	'{timezone_-9_select}' => ($timezone == -9) ? ' selected="selected"' : '',
	'{timezone_-8.5_select}' => ($timezone == -8.5) ? ' selected="selected"' : '',
	'{timezone_-8_select}' => ($timezone == -8) ? ' selected="selected"' : '',
	'{timezone_-7_select}' => ($timezone == -7) ? ' selected="selected"' : '',
	'{timezone_-6_select}' => ($timezone == -6) ? ' selected="selected"' : '',
	'{timezone_-5_select}' => ($timezone == -5) ? ' selected="selected"' : '',
	'{timezone_-4_select}' => ($timezone == -4) ? ' selected="selected"' : '',
	'{timezone_-3.5_select}' => ($timezone == -3.5) ? ' selected="selected"' : '',
	'{timezone_-3_select}' => ($timezone == -3) ? ' selected="selected"' : '',
	'{timezone_-2_select}' => ($timezone == -2) ? ' selected="selected"' : '',
	'{timezone_-1_select}' => ($timezone == -1) ? ' selected="selected"' : '',
	'{timezone_0_select}' => ($timezone == 0) ? ' selected="selected"' : '',
	'{timezone_1_select}' => ($timezone == 1) ? ' selected="selected"' : '',
	'{timezone_2_select}' => ($timezone == 2) ? ' selected="selected"' : '',
	'{timezone_3_select}' => ($timezone == 3) ? ' selected="selected"' : '',
	'{timezone_3.5_select}' => ($timezone == 3.5) ? ' selected="selected"' : '',
	'{timezone_4_select}' => ($timezone == 4) ? ' selected="selected"' : '',
	'{timezone_4.5_select}' => ($timezone == 4.5) ? ' selected="selected"' : '',
	'{timezone_5_select}' => ($timezone == 5) ? ' selected="selected"' : '',
	'{timezone_5.5_select}' => ($timezone == 5.5) ? ' selected="selected"' : '',
	'{timezone_5.75_select}' => ($timezone == 5.75) ? ' selected="selected"' : '',
	'{timezone_6_select}' => ($timezone == 6) ? ' selected="selected"' : '',
	'{timezone_6.5_select}' => ($timezone == 6.5) ? ' selected="selected"' : '',
	'{timezone_7_select}' => ($timezone == 7) ? ' selected="selected"' : '',
	'{timezone_8_select}' => ($timezone == 8) ? ' selected="selected"' : '',
	'{timezone_8.75_select}' => ($timezone == 8.75) ? ' selected="selected"' : '',
	'{timezone_9_select}' => ($timezone == 9) ? ' selected="selected"' : '',
	'{timezone_9.5_select}' => ($timezone == 9.5) ? ' selected="selected"' : '',
	'{timezone_10_select}' => ($timezone == 10) ? ' selected="selected"' : '',
	'{timezone_10.5_select}' => ($timezone == 10.5) ? ' selected="selected"' : '',
	'{timezone_11_select}' => ($timezone == 11) ? ' selected="selected"' : '',
	'{timezone_11.5_select}' => ($timezone == 11.5) ? ' selected="selected"' : '',
	'{timezone_12_select}' => ($timezone == 12) ? ' selected="selected"' : '',
	'{timezone_12.75_select}' => ($timezone == 12.75) ? ' selected="selected"' : '',
	'{timezone_13_select}' => ($timezone == 13) ? ' selected="selected"' : '',
	'{timezone_14_select}' => ($timezone == 14) ? ' selected="selected"' : '',
	'{utc_-12}' => $lang_prof_reg['UTC-12:00'],
	'{utc_-11}' => $lang_prof_reg['UTC-11:00'],
	'{utc_-10}' => $lang_prof_reg['UTC-10:00'],
	'{utc_-9.5}' => $lang_prof_reg['UTC-09:30'],
	'{utc_-9}' => $lang_prof_reg['UTC-09:00'],
	'{utc_-8.5}' => $lang_prof_reg['UTC-08:30'],
	'{utc_-8}' => $lang_prof_reg['UTC-08:00'],
	'{utc_-7}' => $lang_prof_reg['UTC-07:00'],
	'{utc_-6}' => $lang_prof_reg['UTC-06:00'],
	'{utc_-5}' => $lang_prof_reg['UTC-05:00'],
	'{utc_-4}' => $lang_prof_reg['UTC-04:00'],
	'{utc_-3.5}' => $lang_prof_reg['UTC-03:30'],
	'{utc_-3}' => $lang_prof_reg['UTC-03:00'],
	'{utc_-2}' => $lang_prof_reg['UTC-02:00'],
	'{utc_-1}' => $lang_prof_reg['UTC-01:00'],
	'{utc_0}' => $lang_prof_reg['UTC'],
	'{utc_1}' => $lang_prof_reg['UTC+01:00'],
	'{utc_2}' => $lang_prof_reg['UTC+02:00'],
	'{utc_3}' => $lang_prof_reg['UTC+03:00'],
	'{utc_3.5}' => $lang_prof_reg['UTC+03:30'],
	'{utc_4}' => $lang_prof_reg['UTC+04:00'],
	'{utc_4.5}' => $lang_prof_reg['UTC+04:30'],
	'{utc_5}' => $lang_prof_reg['UTC+05:00'],
	'{utc_5.5}' => $lang_prof_reg['UTC+05:30'],
	'{utc_5.75}' => $lang_prof_reg['UTC+05:45'],
	'{utc_6}' => $lang_prof_reg['UTC+06:00'],
	'{utc_6.5}' => $lang_prof_reg['UTC+06:30'],
	'{utc_7}' => $lang_prof_reg['UTC+07:00'],
	'{utc_8}' => $lang_prof_reg['UTC+08:00'],
	'{utc_8.75}' => $lang_prof_reg['UTC+08:45'],
	'{utc_9}' => $lang_prof_reg['UTC+09:00'],
	'{utc_9.5}' => $lang_prof_reg['UTC+09:30'],
	'{utc_10}' => $lang_prof_reg['UTC+10:00'],
	'{utc_10.5}' => $lang_prof_reg['UTC+10:30'],
	'{utc_11}' => $lang_prof_reg['UTC+11:00'],
	'{utc_11.5}' => $lang_prof_reg['UTC+11:30'],
	'{utc_12}' => $lang_prof_reg['UTC+12:00'],
	'{utc_12.75}' => $lang_prof_reg['UTC+12:45'],
	'{utc_13}' => $lang_prof_reg['UTC+13:00'],
	'{utc_14}' => $lang_prof_reg['UTC+14:00'],
	'{dst_checked}' => ($dst == '1') ? ' checked="checked"' : '',
	'{dst}' => $lang_prof_reg['DST'],
	'{languages}' => $language_tpl,
	'{privacy_options}' => $lang_prof_reg['Privacy options legend'],
	'{email_setting_info}' => $lang_prof_reg['Email setting info'],
	'{email_setting1}' => $lang_prof_reg['Email setting 1'],
	'{email_setting2}' => $lang_prof_reg['Email setting 2'],
	'{email_setting3}' => $lang_prof_reg['Email setting 3'],
	'{privacy_1}' => ($email_setting == '0') ? ' checked="checked"' : '',
	'{privacy_2}' => ($email_setting == '1') ? ' checked="checked"' : '',
	'{privacy_3}' => ($email_setting == '2') ? ' checked="checked"' : '',
	'{robot_test}' => $robot_tpl,
	'{register_hook}' => flux_hook('register_before_submit'),
);

echo str_replace(array_keys($search), array_values($search), $register_tpl);
require PANTHER_ROOT.'footer.php';