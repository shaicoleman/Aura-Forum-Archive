<?php

// Language definitions used in viewforum.php
$lang_forum = array(
    
    'Post topic' => 'Post new topic',
    'Views' => 'Views',
    'Moved' => 'Moved:',
    'Sticky' => 'Sticky:',
    'Closed' => 'Closed:',
    'Empty forum' => 'No topics were found. This is because this forum is empty or you don\'t have permission to view other topics in this forum.',
    'Mod controls' => 'Moderator controls',
    'Is subscribed' => 'You are currently subscribed to this forum',
    'Unsubscribe' => 'Unsubscribe',
    'Subscribe' => 'Subscribe to this forum',
    'Sub forums' => 'Sub forums',
    'Poll' => 'Poll: %s',
    'Forum announcements' => 'Forum announcements'
    
);