<?php

// Language definitions used in admin_posts.php
$lang_admin_posts = array(
    
    'New posts head' => 'New Unapproved Posts',
    'Deleted user' => 'Deleted user',
    'Deleted' => 'Deleted',
    'Post ID' => 'Post #%s',
    'Post subhead' => 'Posted %s',
    'Posted by' => 'Posted by %s',
    'Message' => 'Message',
    'Approve' => 'Approve post',
    'Delete' => 'Delete post',
    'No new posts' => 'There are no new unapproved posts.',
    'Post approved redirect' => 'Post approved successfully. Redirecting …',
    'Post deleted redirect' => 'Post deleted successfully. Redirecting …',
    'Attachment size' => 'Size: %s',
    'Attachment downloads' => 'Downloads: %s',
    'bytes' => 'bytes',
    'Attachments' => 'Attachments: ',
    'Mark as spam' => 'Mark as Spam'
    
);