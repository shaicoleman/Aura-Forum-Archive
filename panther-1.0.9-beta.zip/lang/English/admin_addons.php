<?php

// Language definitions used in admin_addons.php
$lang_admin_addons = array(
    'No plugins' => 'You must select at least one plugin to remove.', 
    'Plugin removed redirect' => 'Plugin removed. Redirecting …',
    'Successful Upload Plugin' => 'Plugin uploaded. Redirecting …',
    'Current Plugins' => 'Current Plugins',
    'List Plugins' => 'Plugin list',
    'Add Plugin' => 'Upload Plugin',
    'Plugin upload warning' => 'Like extensions, the code inside plugins is executed on the server, posing a security risk. Only upload plugins you know are secure. Plugins have a prefix of either "AP_" or "AMP_".',
    'Plugin filename' => 'Plugin Name',
	'Plugin not valid' => 'This plugin does not appear to be valid. Plugins must be prefixed with "AP" or "AMP", and meet other plugin criteria.',
	'Plugin exists' => 'The file "%s" already exists in the plugin directory. Please specify a new name, or rename the existing file first.',
	
    'No addons' => 'You must select at least one extension to remove.',
    'Addon removed redirect' => 'Extension removed. Redirecting …',
    'No file' => 'You did not select a file for upload.',
    'Bad type' => 'The file you tried to upload is not of an allowed type. Allowed types are php.',
    'Move failed' => 'The server was unable to save the uploaded file.',
    'Unknown failure' => 'An unknown error occurred. Please try again.',
    'Too large ini' => 'The selected file was too large to upload. The server didn\'t allow the upload.',
    'Partial upload' => 'The selected file was only partially uploaded. Please try again.',
    'No tmp directory' => 'PHP was unable to save the uploaded file to a temporary location.',
    'Successful Upload Addon' => 'Extension uploaded. Redirecting …',
    'Current Addons' => 'Current Extensions',
    'List Addons' => 'Extensions list',
    'Addon filename' => 'Extension Name',
    'Delete' => 'Delete',
    'Add Addon' => 'Upload Extension',
    'Addon upload warning' => 'Uploading extensions poses an extreme security risk to your forum. The code present in extensions will be executed on the server like a standard file. Only upload extensions you know are completely secure.',
    'Warning' => 'Warning:',
    'Upload' => 'Upload',
    'Delete selected' => 'Delete selected extensions',
	'Addon exists' => 'The file "%s" already exists in the extensions directory. Please specify a new name, or rename the existing file first.',

);