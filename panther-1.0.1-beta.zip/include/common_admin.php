<?php

/**
 * Copyright (C) 2015 Panther (http://panther.strongholdnation.co.uk/)
 * based on code by Rickard Andersson copyright (C) 2002-2008 PunBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

// Make sure no one attempts to run this script "directly"
if (!defined('PANTHER'))
	exit;

// Make sure we have a usable language pack for admin.
if (file_exists(PANTHER_ROOT.'lang/'.$panther_user['language'].'/admin_common.php'))
	$admin_language = $panther_user['language'];
else if (file_exists(PANTHER_ROOT.'lang/'.$panther_config['o_default_lang'].'/admin_common.php'))
	$admin_language = $panther_config['o_default_lang'];
else
	$admin_language = 'English';

if (file_exists(FORUM_CACHE_DIR.'cache_admin.php'))
	require FORUM_CACHE_DIR.'cache_admin.php';
else
{
	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PANTHER_ROOT.'include/cache.php';

	generate_admin_restrictions_cache();
	require FORUM_CACHE_DIR.'cache_admin.php';
}

// Attempt to load the admin_common language file
require PANTHER_ROOT.'lang/'.$admin_language.'/admin_common.php';

if (file_exists(FORUM_CACHE_DIR.'cache_updates.php'))
{
	require FORUM_CACHE_DIR.'cache_updates.php';
	
	// re-cache automatically every 21 days 
	if ($panther_updates['cached'] < (time() - 1814400))
	{
		if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
			require PANTHER_ROOT.'include/cache.php';

		$panther_updates = generate_update_cache();
	}
}
else
{
	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
			require PANTHER_ROOT.'include/cache.php';
	
	generate_update_cache();
	require FORUM_CACHE_DIR.'cache_updates.php';
}

download_update();

//
// Display the admin navigation menu
//
function generate_admin_menu($page = '')
{
	global $panther_config, $panther_user, $lang_admin_common, $admins, $panther_url, $panther_updates;

	$output = array();
	$is_admin = $panther_user['g_id'] == PANTHER_ADMIN ? true : false;
	if (!isset($admins[$panther_user['id']]) || $panther_user['id'] == '2')
		$admins[$panther_user['id']] = array('admin_options' => '1', 'admin_permissions' => '1', 'admin_categories' => '1', 'admin_forums' => '1', 'admin_groups' => '1', 'admin_users' => '1', 'admin_censoring' => '1', 'admin_moderate' => '1', 'admin_maintenance' => '1', 'admin_plugins' => '1', 'admin_restrictions' => '1', 'admin_ranks' => '1', 'admin_updates' => '1');
 	
	if ($admins[$panther_user['id']]['admin_options'] == '1')
		$output[] = ($page == 'options') ? '<li class="isactive"><a href="'.get_link($panther_url['admin_options']).'">'.$lang_admin_common['Options'].'</a></li>' : '<li><a href="'.get_link($panther_url['admin_options']).'">'.$lang_admin_common['Options'].'</a></li>';

	if ($admins[$panther_user['id']]['admin_permissions'] == '1')
		$output[] = ($page == 'permissions') ? '<li class="isactive"><a href="'.get_link($panther_url['admin_permissions']).'">'.$lang_admin_common['Permissions'].'</a></li>' : '<li><a href="'.get_link($panther_url['admin_permissions']).'">'.$lang_admin_common['Permissions'].'</a></li>';

	if ($admins[$panther_user['id']]['admin_categories'] == '1')
		$output[] = ($page == 'categories') ? '<li class="isactive"><a href="'.get_link($panther_url['admin_categories']).'">'.$lang_admin_common['Categories'].'</a></li>' : '<li><a href="'.get_link($panther_url['admin_categories']).'">'.$lang_admin_common['Categories'].'</a></li>';
		
	if ($admins[$panther_user['id']]['admin_forums'] == '1')
		$output[] = ($page == 'forums') ? '<li class="isactive"><a href="'.get_link($panther_url['admin_forums']).'">'.$lang_admin_common['Forums'].'</a></li>' : '<li><a href="'.get_link($panther_url['admin_forums']).'">'.$lang_admin_common['Forums'].'</a></li>';
		
	if ($admins[$panther_user['id']]['admin_groups'] == '1')
		$output[] = ($page == 'groups') ? '<li class="isactive"><a href="'.get_link($panther_url['admin_groups']).'">'.$lang_admin_common['User groups'].'</a></li>' : '<li><a href="'.get_link($panther_url['admin_groups']).'">'.$lang_admin_common['User groups'].'</a></li>';
		
	if ($admins[$panther_user['id']]['admin_censoring'] == '1')
		$output[] = ($page == 'censoring') ? '<li class="isactive"><a href="'.get_link($panther_url['admin_censoring']).'">'.$lang_admin_common['Censoring'].'</a></li>' : '<li><a href="'.get_link($panther_url['admin_censoring']).'">'.$lang_admin_common['Censoring'].'</a></li>';

	if ($admins[$panther_user['id']]['admin_ranks'] == '1')
		$output[] = ($page == 'ranks') ? '<li class="isactive"><a href="'.get_link($panther_url['admin_ranks']).'">'.$lang_admin_common['Ranks'].'</a></li>' : '<li><a href="'.get_link($panther_url['admin_ranks']).'">'.$lang_admin_common['Ranks'].'</a></li>';

	if ($admins[$panther_user['id']]['admin_moderate'] == '1')
		$output[] = ($page == 'moderate') ? '<li class="isactive"><a href="'.get_link($panther_url['admin_moderate']).'">'.$lang_admin_common['Moderate'].'</a></li>' : '<li><a href="'.get_link($panther_url['admin_moderate']).'">'.$lang_admin_common['Moderate'].'</a></li>';

	if ($admins[$panther_user['id']]['admin_restrictions'] == '1')
		$output[] = ($page == 'restrictions') ? '<li class="isactive"><a href="'.get_link($panther_url['admin_restrictions']).'">'.$lang_admin_common['Restrictions'].'</a></li>' : '<li><a href="'.get_link($panther_url['admin_restrictions']).'">'.$lang_admin_common['Restrictions'].'</a></li>';
	
	if ($admins[$panther_user['id']]['admin_maintenance'] == '1')
		$output[] = ($page == 'maintenance') ? '<li class="isactive"><a href="'.get_link($panther_url['admin_maintenance']).'">'.$lang_admin_common['Maintenance'].'</a></li>' : '<li><a href="'.get_link($panther_url['admin_maintenance']).'">'.$lang_admin_common['Maintenance'].'</a></li>';

	if ($admins[$panther_user['id']]['admin_updates'] == '1' && version_compare($panther_config['o_cur_version'], $panther_updates['version'], '<'))
		$output[] = ($page == 'updates') ? '<li class="isactive"><a href="'.get_link($panther_url['admin_updates']).'">'.$lang_admin_common['Updates'].'</a></li>' : '<li><a href="'.get_link($panther_url['admin_updates']).'">'.$lang_admin_common['Updates'].'</a></li>';

	$is_admin = $panther_user['g_id'] == PANTHER_ADMIN ? true : false;
?>
<div id="adminconsole" class="block2col">
	<div id="adminmenu" class="blockmenu">
		<h2><span><?php echo $lang_admin_common['Moderator menu'] ?></span></h2>
		<div class="box">
			<div class="inbox">
				<ul>
					<li<?php if ($page == 'index') echo ' class="isactive"'; ?>><a href="<?php echo get_link($panther_url['admin_index']); ?>"><?php echo $lang_admin_common['Index'] ?></a></li>
					<li<?php if ($page == 'users') echo ' class="isactive"'; ?>><a href="<?php echo get_link($panther_url['admin_users']); ?>"><?php echo $lang_admin_common['Users'] ?></a></li>
<?php if ($is_admin || $panther_user['g_mod_ban_users'] == '1'): ?>					<li<?php if ($page == 'bans') echo ' class="isactive"'; ?>><a href="<?php echo get_link($panther_url['admin_bans']); ?>"><?php echo $lang_admin_common['Bans'] ?></a></li>
<?php endif; if ($is_admin || $panther_config['o_report_method'] == '0' || $panther_config['o_report_method'] == '2'): ?>					<li<?php if ($page == 'reports') echo ' class="isactive"'; ?>><a href="<?php echo get_link($panther_url['admin_reports']); ?>"><?php echo $lang_admin_common['Reports'] ?></a></li>
<?php endif; ?>
					<li<?php if ($page == 'posts') echo ' class="isactive"'; ?>><a href="<?php echo get_link($panther_url['admin_posts']); ?>"><?php echo $lang_admin_common['Posts'] ?></a></li>
				</ul>
			</div>
		</div>
<?php

	if ($is_admin && count($output))
	{

?>
		<h2 class="block2"><span><?php echo $lang_admin_common['Admin menu'] ?></span></h2>
		<div class="box">
			<div class="inbox">
				<ul>
					<?php echo implode("\t\t\t\t\t", $output); ?>
				</ul>
			</div>
		</div>
<?php

	}

	// See if there are any plugins
	$plugins = forum_list_plugins($is_admin);

	// Did we find any plugins?
	if (!empty($plugins) && ($admins[$panther_user['id']]['admin_plugins'] == '1'))
	{
?>
		<h2 class="block2"><span><?php echo $lang_admin_common['Plugins menu'] ?></span></h2>
		<div class="box">
			<div class="inbox">
				<ul>
<?php
		foreach ($plugins as $plugin_name => $plugin)
			echo "\t\t\t\t\t".'<li'.(($page == $plugin_name) ? ' class="isactive"' : '').'><a href="'.get_link($panther_url['admin_loader'], array($plugin_name)).'">'.str_replace('_', ' ', $plugin).'</a></li>'."\n";
?>
				</ul>
			</div>
		</div>
<?php
	}
?>
	</div>

<?php
}

//
// Delete topics from $forum_id that are "older than" $prune_date (if $prune_sticky is 1, sticky topics will also be deleted)
//
function prune($forum_id, $prune_sticky, $prune_date)
{
	global $db;

	$extra_sql = ($prune_date != -1) ? ' AND last_post<'.$prune_date : '';

	if (!$prune_sticky)
		$extra_sql .= ' AND sticky=\'0\'';

	// Fetch topics to prune
	$result = $db->query('SELECT id FROM '.$db->prefix.'topics WHERE forum_id='.$forum_id.$extra_sql, true) or error('Unable to fetch topics', __FILE__, __LINE__, $db->error());

	$topic_ids = '';
	while ($row = $db->fetch_row($result))
		$topic_ids .= (($topic_ids != '') ? ',' : '').$row[0];

	if ($topic_ids != '')
	{
		// Fetch posts to prune
		$result = $db->query('SELECT id FROM '.$db->prefix.'posts WHERE topic_id IN('.$topic_ids.')', true) or error('Unable to fetch posts', __FILE__, __LINE__, $db->error());

		$post_ids = '';
		while ($row = $db->fetch_row($result))
			$post_ids .= (($post_ids != '') ? ',' : '').$row[0];

		if ($post_ids != '')
		{
			// Delete topics
			$db->query('DELETE FROM '.$db->prefix.'topics WHERE id IN('.$topic_ids.')') or error('Unable to prune topics', __FILE__, __LINE__, $db->error());
			// Delete subscriptions
			$db->query('DELETE FROM '.$db->prefix.'topic_subscriptions WHERE topic_id IN('.$topic_ids.')') or error('Unable to prune subscriptions', __FILE__, __LINE__, $db->error());
			// Delete posts
			$db->query('DELETE FROM '.$db->prefix.'posts WHERE id IN('.$post_ids.')') or error('Unable to prune posts', __FILE__, __LINE__, $db->error());

			// We removed a bunch of posts, so now we have to update the search index
			require_once PANTHER_ROOT.'include/search_idx.php';
			strip_search_index($post_ids);
		}
	}
}

//
// Fetch a list of available admin plugins
//
function forum_list_plugins($is_admin)
{
	$plugins = array();

	$d = dir(PANTHER_ROOT.'plugins');
	while (($entry = $d->read()) !== false)
	{
		if ($entry{0} == '.')
			continue;

		$prefix = substr($entry, 0, strpos($entry, '_'));
		$suffix = substr($entry, strlen($entry) - 4);

		if ($suffix == '.php' && ((!$is_admin && $prefix == 'AMP') || ($is_admin && ($prefix == 'AP' || $prefix == 'AMP'))))
			$plugins[$entry] = substr($entry, strpos($entry, '_') + 1, -4);
	}
	$d->close();

	natcasesort($plugins);

	return $plugins;
}