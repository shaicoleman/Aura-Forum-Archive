<?php
/**
 * Copyright (C) 2015 Panther (http://panther.strongholdnation.co.uk/)
 * based on code by Rickard Andersson copyright (C) 2002-2008 pantherBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

// Tell header.php to use the admin template
define('PANTHER_ADMIN_CONSOLE', 1);

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/');
	require PANTHER_ROOT.'include/common.php';
}
require PANTHER_ROOT.'include/common_admin.php';

if ($panther_user['g_id'] != PANTHER_ADMIN)
	message($lang_common['No permission'], false, '403 Forbidden');

if ($panther_user['id'] != '2')
{
	if(!is_null($admins[$panther_user['id']]['admin_updates']))
	{
		if ($admins[$panther_user['id']]['admin_updates'] == '0')
			message($lang_common['No permission'], false, '403 Forbidden');
	}
}

check_authentication();

// Load the admin_update.php language file
require PANTHER_ROOT.'lang/'.$admin_language.'/admin_update.php';

if (version_compare($panther_config['o_cur_version'], $panther_updates['version'], '>='))
	message($lang_admin_update['no updates']);

$action = isset($_GET['action']) ? panther_htmlspecialchars($_GET['action']) : '';
if ($action == 'install_update')
{
	$file_name = 'panther-update-patch-'.$panther_updates['version'].'.zip';
	if (!file_exists(PANTHER_ROOT.'include/updates/'.$file_name))
		download_update(false);
	
	if (class_exists('ZipArchive'))
	{
		$zip = new ZipArchive();
		if ($zip->open(PANTHER_ROOT.'include/updates/'.$file_name))
		{
			if (!is_dir(PANTHER_ROOT.'include/updates/'.$panther_updates['version']))
				mkdir(PANTHER_ROOT.'include/updates/'.$panther_updates['version']);
			
			$zip->extractTo(PANTHER_ROOT.'include/updates/'.$panther_updates['version']);
			$zip->close();

			unlink(PANTHER_ROOT.'include/updates/'.$file_name);
			if (file_exists(PANTHER_ROOT.'include/updates/'.$panther_updates['version'].'/panther_database.php'))
				require PANTHER_ROOT.'include/updates/'.$panther_updates['version'].'/panther_database.php';

			if (isset($database)) // There are updates to perform for the Panther database
			{
				if (isset($database['alter']) && count($database['alter']) > 0)
				{
					foreach ($database['alter'] as $table => $query)
						$db->query('ALTER TABLE '.$db->prefix.$table.$query) or error('Unable to alter table '.$db->prefix.$table, __FILE__, __LINE__, $db->error());
				}

				if (isset($database['drop']) && count($database['drop']) > 0)
				{
					foreach ($database['drop'] as $table => $query)
						$db->drop_table($table) or error('Unable to drop table '.$db->prefix.$table, __FILE__, __LINE__, $db->error());
				}

				if (isset($database['create']) && count($database['create']) > 0)
				{
					foreach ($database['create'] as $table => $schema)
						$db->create_table($table, $schema) or error('Unable to add table '.$db->prefix.$table, __FILE__, __LINE__, $db->error());
				}

				if (isset($database['rename']) && count($database['rename']) > 0)
				{
					foreach ($database['rename'] as $old_name => $new_name)
						$db->rename_table($old_name, $new_name) or error('Unable to rename table '.$db->prefix.$table, __FILE__, __LINE__, $db->error());
				}
				
				if (isset($database['drop_field']) && count($database['drop_field']) > 0)
				{
					foreach ($database['drop_field'] as $table => $field)
						$db->drop_field($table, $field) or error('Unable to drop field '.$field.' from table '.$db->prefix.$table, __FILE__, __LINE__, $db->error());
				}
				
				if (isset($database['query']) && count($database['query']) > 0)
				{
					foreach ($database['query'] as $table => $field)
					{
						$query = str_replace($table, $db->prefix.$table, $query); // Make sure a valid database prefix is present.
						$db->query($query) or error('Unable to query table '.$db->prefix.$table, __FILE__, __LINE__, $db->error());
					}
				}
			}
			
			if (file_exists(PANTHER_ROOT.'include/updates/'.$panther_updates['version'].'/panther_updates.php'))
			{
				require PANTHER_ROOT.'include/updates/'.$panther_updates['version'].'/panther_updates.php';

				$files = array();
				if (isset($updates['add_after']) && isset($updates['add_after']['search']) && isset($updates['add_after']['add']))
				{
					if (count($updates['add_after']['search']) == count($updates['add_after']['add']))
					{
						$i = 0;
						$search = $replace = $files = $file_content = array();
						foreach ($updates['add_after']['search'] as $file => $to_find)
						{
							preg_match('/^([a-z\/_]+)(|[-]([0-9])+)/', $file, $result);
							$real_file = (isset($result[0])) ? $result[0] : $file;

							$files[$i] = $real_file;
							$file_content[$i] = file_get_contents($real_file.'.php');
							$search[$i] = $updates['add_after']['search'][$file];
							$replace[$i] = $updates['add_after']['search'][$file].$updates['add_after']['add'][$file];
							$i++;
						}

						$file_content = str_replace($search, $replace, $file_content);
					}
				}

				foreach ($files as $key => $file)
				{
					$fp = fopen ($file.'.php', 'wb');
					fwrite ($fp, $file_content[$key]);
					fclose ($fp);
				}

				$files = array();
				if (isset($updates['add_before']) && isset($updates['add_before']['search']) && isset($updates['add_before']['add']))
				{
					if (count($updates['add_before']['search']) == count($updates['add_before']['add']))
					{
						$i = 0;
						$search = $replace = $files = $file_content = array();
						foreach ($updates['add_before']['search'] as $file => $to_find)
						{
							preg_match('/^([a-z\/_]+)(|[-]([0-9])+)/', $file, $result);
							$real_file = (isset($result[0])) ? $result[0] : $file;

							$files[$i] = $real_file;
							$file_content[$i] = file_get_contents($real_file.'.php');
							$search[$i] = $updates['add_before']['search'][$file];
							$replace[$i] = $updates['add_before']['add'][$file].$updates['add_before']['search'][$file];
							$i++;
						}

						$file_content = str_replace($search, $replace, $file_content);
					}
				}

				foreach ($files as $key => $file)
				{
					$fp = fopen ($file.'.php', 'wb');
					fwrite ($fp, $file_content[$key]);
					fclose ($fp);
				}

				$files = array();
				if (isset($updates['replace']) && isset($updates['replace']['search']) && isset($updates['replace']['replace']))
				{
					if (count($updates['replace']['search']) == count($updates['replace']['replace']))
					{
						$i = 0;
						$search = $replace = $files = $file_content = array();
						foreach ($updates['replace']['search'] as $file => $to_find)
						{
							preg_match('/^([a-z\/_]+)(|[-]([0-9])+)/', $file, $result);
							$real_file = (isset($result[0])) ? $result[0] : $file;

							$files[$i] = $real_file;
							$file_content[$i] = file_get_contents(PANTHER_ROOT.$real_file.'.php');
							$search[$i] = $updates['replace']['search'][$file];
							$replace[$i] = $updates['replace']['replace'][$file];
							$i++;
						}

						$file_content = str_replace($search, $replace, $file_content);
					}
				}

				foreach ($files as $key => $file)
				{
					$fp = fopen ($file.'.php', 'wb');
					fwrite ($fp, $file_content[$key]);
					fclose ($fp);
				}

				if (isset($updates['replace_file']))
				{
					$i = 0;
					$search = $replace = array();
					foreach ($updates['replace_file'] as $file => $replace)
					{
						if (file_exists(PANTHER_ROOT.$file.'.php'))
							unlink(PANTHER_ROOT.$file.'.php');
						
						rename(PANTHER_ROOT.'include/updates/'.$panther_updates['version'].'/'.$replace.'.php', PANTHER_ROOT.$file.'.php');
					}
				}
			}
			
			$files = opendir(PANTHER_ROOT.'include/updates/'.$panther_updates['version']);
			while(($file = readdir($files)) !== false)
			{
				if ($file != '.' && $file != '..')
					unlink(PANTHER_ROOT.'include/updates/'.$panther_updates['version'].'/'.$file);
			}
			
			rmdir(PANTHER_ROOT.'include/updates/'.$panther_updates['version']);
			
				// Re-generate updates cache, and make sure that we're now running the latest version.
			if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
				require PANTHER_ROOT.'include/cache.php';
		
			forum_clear_cache();
			exit;
		}
		else
			exit(sprintf($lang_admin_update['Unable to open archive'], $file_name));
	}
	else
		exit(sprintf($lang_admin_update['ZipArchive not supported'],$panther_updates['version']));	
}

$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_admin_common['Admin'], $lang_admin_common['Update']);
define('PANTHER_ACTIVE_PAGE', 'admin');
require PANTHER_ROOT.'header.php';

generate_admin_menu('updates');
?>
<style>
#changelog{
	height: 300px;
	border: 1px solid #76774C;
	background-color: #FDFDD3;
	padding: 8px;
	overflow: auto;
	margin-bottom: 6px;
	display: none;
}
</style>
<script>
$(document).ready(function()
{
	$("#ajax_submit").click(function()
	{
		$.ajaxSetup({
			cache: false
		});

		$("#ajax_submit").html('<br /><img src="<?php echo get_base_url(true); ?>/img/preloader.gif" width="40" height="40">');
		$.get("<?php echo get_link($panther_url['admin_updates']); ?>",
		{
			action: 'install_update'
		},
		function(data, status)
		{
			if (data != '')
			{
				$("#ajax_response").css("color", "red");
				$("#ajax_response").html(data);
				$("#ajax_response").slideDown();
				
			}
			else
			{
				$("#ajax_response").css("color", "green");
				$("#ajax_result").html(data);
				$("#ajax_response").slideDown();
			}
			
			$("#ajax_submit").html('');
			$("#release_notes").slideUp();
		});
	});
	$("#view_changelog").click(function()
	{
		$("#changelog").slideToggle();
		
		var text = $('#changelog_text').text();
		$('#changelog_text').text(
        text == "<?php echo $lang_admin_update['View release notes']; ?>" ? "<?php echo $lang_admin_update['Hide release notes']; ?>" : "<?php echo $lang_admin_update['View release notes']; ?>");
	});
});
</script>
		<div id="plugin_mod" class="plugin blockform">
			<h2 class="block2"><span><?php echo $lang_admin_update['Admin updates']; ?></span></h2>
			<div class="box">
					<div class="inform">
						<fieldset>
							<legend><?php echo $lang_admin_update['Information']; ?></legend>
							<div class="infldset">
							<p><?php echo $lang_admin_update['update panther']; ?></p>
							<p><span id="ajax_response" style="color:green; font-weight: bold; display: none;"><?php echo $lang_admin_update['Update successful']; ?></span></p>
							<div id="release_notes">
							<ul>
								<li><?php echo $lang_admin_update['Patch']; ?> <span style="color:#3ADF00; font-weight:bold;"><?php echo $panther_updates['version']; ?></span><br /></li>
								<li><?php echo $lang_admin_update['Release']; ?> <span style="color:#BF00FF; font-weight:bold;"><?php echo format_time($panther_updates['released']); ?></span><br /></li>
								<li><?php echo $lang_admin_update['Developer notes']; ?> <span style="color:#0080FF; font-weight:bold;"><?php echo $panther_updates['message']; ?></span><br /></li>
								<li><?php echo $lang_admin_update['Changelog']; ?> <span id="view_changelog" style="color:#FE642E; font-weight:bold;"><a style="cursor:pointer;" id="changelog_text"><?php echo $lang_admin_update['View release notes']; ?></a></span></li>
							</ul>
							<div id="changelog"><?php echo nl2br($panther_updates['changelog']); ?></div>
							<p style="color:#00f"><?php echo $lang_admin_update['Disclaimer']; ?></p>
							</div>
							<div id="ajax_submit"><button type="button"><?php echo $lang_admin_update['Install update']; ?></button></div>
							</div>
						</fieldset>
					</div>
			</div>
		</div>
	<div class="clearer"></div>
<?php require PANTHER_ROOT.'footer.php'; ?>