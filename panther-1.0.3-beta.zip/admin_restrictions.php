<?php

/**
 * Copyright (C) 2014 StrongholdNation (http://www.strongholdnation.co.uk)
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

// Tell header.php to use the admin template
define('PANTHER_ADMIN_CONSOLE', 1);

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/');
	require PANTHER_ROOT.'include/common.php';
}
require PANTHER_ROOT.'include/cache.php';
require PANTHER_ROOT.'include/common_admin.php';

if ($panther_user['g_id'] != PANTHER_ADMIN)
	message($lang_common['No permission'], false, '403 Forbidden');

// Load the admin_restrictions.php language file
require PANTHER_ROOT.'lang/'.$admin_language.'/admin_restrictions.php';

if ($panther_user['id'] != '2')
{
	if(!is_null($admins[$panther_user['id']]['admin_restrictions']))
	{
		if ($admins[$panther_user['id']]['admin_restrictions'] == '0')
			message($lang_common['No permission'], false, '403 Forbidden');
	}
}

check_authentication();

$action = isset($_GET['action']) ? panther_htmlspecialchars($_GET['action']) : null;
$stage = isset($_GET['stage']) ? intval($_GET['stage']) : null;

if ($action == 'add' && isset($_POST['form_sent']) && $stage == '3')
{
	//Stage 3: Add restrictions
	$user = isset($_POST['admin_id']) ? intval($_POST['admin_id']) : null;
	$board_config = isset($_POST['board_config']) ? intval($_POST['board_config']) : '1';
	$board_perms = isset($_POST['board_perms']) ? intval($_POST['board_perms']) : '1';	
	$board_cats = isset($_POST['board_cats']) ? intval($_POST['board_cats']) : '1';
	$board_forums = isset($_POST['board_forums']) ? intval($_POST['board_forums']) : '1';	
	$board_groups = isset($_POST['board_groups']) ? intval($_POST['board_groups']) : '1';
	$board_users = isset($_POST['board_users']) ? intval($_POST['board_users']) : '1';
	$board_censoring = isset($_POST['board_censoring']) ? intval($_POST['board_censoring']) : '1';
	$board_ranks = isset($_POST['board_ranks']) ? intval($_POST['board_ranks']) : '1';
	$board_moderate = isset($_POST['board_moderate']) ? intval($_POST['board_moderate']) : '1';
	$board_maintenance = isset($_POST['board_maintenance']) ? intval($_POST['board_maintenance']) : '0';
	$board_plugins = isset($_POST['board_plugins']) ? intval($_POST['board_plugins']) : '1';
	$board_restrictions = isset($_POST['board_restrictions']) ? intval($_POST['board_restrictions']) : '0';
	$board_updates = isset($_POST['board_updates']) ? intval($_POST['board_updates']) : '0';

	$result = $db->query('SELECT group_id FROM '.$db->prefix.'users WHERE id = \''.$db->escape($user).'\'') or error('Unable to fetch user info', __FILE__, __LINE__, $db->error());
	$gid = $db->result($result);

	if (!$user || $gid != PANTHER_ADMIN)
		message($lang_admin_restrictions['no user']);
		
	$result = $db->query('SELECT COUNT(id) FROM '.$db->prefix.'admin_restrictions WHERE admin_id = \''.$db->escape($user).'\'') or error('Unable to fetch user info', __FILE__, __LINE__, $db->error());
	$count = $db->result($result);
		
	if ($count > 0)
		message($lang_admin_restrictions['already restrictions']);

	$db->query('INSERT INTO '.$db->prefix.'admin_restrictions (admin_id, admin_opt, admin_perms, admin_cats, admin_forums, admin_groups, admin_censoring, admin_maintenance, admin_plugins, admin_rest, admin_users, admin_moderate, admin_ranks, admin_updates) VALUES('.$user.', '.$board_config.', '.$board_perms.', '.$board_cats.', '.$board_forums.', '.$board_groups.', '.$board_censoring.', '.$board_maintenance.', '.$board_plugins.', '.$board_restrictions.', '.$board_users.', '.$board_moderate.', '.$board_ranks.', '.$board_updates.')') or error('Unable to add restrictions', __FILE__, __LINE__, $db->error());
	
	generate_admin_restrictions_cache();
	redirect('admin_restrictions.php', $lang_admin_restrictions['added redirect']);
}
else if ($action == 'edit' && isset($_POST['form_sent']) && $stage == '3')
{
	//Stage 3: Add restrictions
	$user = isset($_POST['admin_id']) ? intval($_POST['admin_id']) : null;
	$board_config = isset($_POST['board_config']) ? intval($_POST['board_config']) : '1';
	$board_perms = isset($_POST['board_perms']) ? intval($_POST['board_perms']) : '1';	
	$board_cats = isset($_POST['board_cats']) ? intval($_POST['board_cats']) : '1';
	$board_forums = isset($_POST['board_forums']) ? intval($_POST['board_forums']) : '1';	
	$board_groups = isset($_POST['board_groups']) ? intval($_POST['board_groups']) : '1';
	$board_users = isset($_POST['board_users']) ? intval($_POST['board_users']) : '1';
	$board_censoring = isset($_POST['board_censoring']) ? intval($_POST['board_censoring']) : '1';
	$board_ranks = isset($_POST['board_ranks']) ? intval($_POST['board_ranks']) : '1';
	$board_moderate = isset($_POST['board_moderate']) ? intval($_POST['board_moderate']) : '1';
	$board_maintenance = isset($_POST['board_maintenance']) ? intval($_POST['board_maintenance']) : '0';
	$board_plugins = isset($_POST['board_plugins']) ? intval($_POST['board_plugins']) : '1';
	$board_restrictions = isset($_POST['board_restrictions']) ? intval($_POST['board_restrictions']) : '0';
	$board_updates = isset($_POST['board_updates']) ? intval($_POST['board_updates']) : '0';

	$result = $db->query('SELECT group_id FROM '.$db->prefix.'users WHERE id = \''.$db->escape($user).'\'') or error('Unable to fetch user info', __FILE__, __LINE__, $db->error());
	$gid = $db->result($result);

	if (!$user || $gid != PANTHER_ADMIN)
		message($lang_admin_restrictions['no user']);
		
	$result = $db->query('SELECT COUNT(id) FROM '.$db->prefix.'admin_restrictions WHERE admin_id = \''.$db->escape($user).'\'') or error('Unable to fetch user info', __FILE__, __LINE__, $db->error());
	$count = $db->result($result);
		
	if ($count != '1')
		message($lang_admin_restrictions['no restrictions']);

	$db->query('UPDATE '.$db->prefix.'admin_restrictions SET admin_opt = '.$board_config.', admin_perms = '.$board_perms.', admin_cats = '.$board_cats.', admin_forums = '.$board_forums.', admin_groups = '.$board_groups.', admin_censoring = '.$board_censoring.', admin_maintenance = '.$board_maintenance.', admin_plugins = '.$board_plugins.', admin_rest = '.$board_restrictions.', admin_users = '.$board_users.', admin_moderate = '.$board_moderate.', admin_ranks = '.$board_ranks.', admin_updates='.$board_updates.' WHERE admin_id = '.$user) or error('Unable to edit restrictions', __FILE__, __LINE__, $db->error());
	generate_admin_restrictions_cache();
	redirect('admin_restrictions.php', $lang_admin_restrictions['edited redirect']);
}
else if ($action == 'delete' && isset($_POST['form_sent']) && $stage == '3')
{
	//Stage 3: Remove restrictions
	$user = isset($_POST['admin_id']) ? intval($_POST['admin_id']) : null;

	$result = $db->query('SELECT group_id FROM '.$db->prefix.'users WHERE id = \''.$db->escape($user).'\'') or error('Unable to fetch user info', __FILE__, __LINE__, $db->error());
	$gid = $db->result($result);

	if (!$user || $gid != PANTHER_ADMIN)
		message($lang_admin_restrictions['no user']);
		
	$result = $db->query('SELECT COUNT(id) FROM '.$db->prefix.'admin_restrictions WHERE admin_id = \''.$db->escape($user).'\'') or error('Unable to fetch user info', __FILE__, __LINE__, $db->error());
	$count = $db->result($result);
		
	if ($count != '1')
		message($lang_admin_restrictions['no restrictions']);

	$db->query('DELETE FROM '.$db->prefix.'admin_restrictions WHERE admin_id = '.$user) or error('Unable to remove restrictions', __FILE__, __LINE__, $db->error());
	generate_admin_restrictions_cache();
	redirect(get_link($panther_url['admin_restrictions']), $lang_admin_restrictions['removed redirect']);
}

$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_admin_common['Admin'], $lang_admin_common['Restrictions']);
define('PANTHER_ACTIVE_PAGE', 'admin');
require PANTHER_ROOT.'header.php';

generate_admin_menu('restrictions');

if ($action == 'delete' && isset($_POST['form_sent']) && $stage == '2')
{
	//Stage 2: Confirm Removal of existing restrictions
	$user = isset($_POST['user']) ? intval($_POST['user']) : null;

	$result = $db->query('SELECT COUNT(id) FROM '.$db->prefix.'admin_restrictions WHERE admin_id = \''.$db->escape($user).'\'') or error('Unable to fetch user info', __FILE__, __LINE__, $db->error());
	$count = $db->result($result);
	
	$result = $db->query('SELECT group_id, username FROM '.$db->prefix.'users WHERE id = \''.$db->escape($user).'\'') or error('Unable to fetch user info', __FILE__, __LINE__, $db->error());
	$valid = $db->fetch_assoc($result);

	//Changing input value of previous HTML form
	if ($valid['group_id'] != PANTHER_ADMIN || $count == '0')
		message($lang_admin_restrictions['no user']);
?>
	<div class="blockform">
		<h2><span><?php echo $lang_admin_restrictions['restrictions head']; ?></span></h2>
		<div class="box">
			<form id="restrictions2" method="post" action="<?php echo get_link($panther_url['admin_restrictions_query'], array('action=delete&stage=3')); ?>">
				<input type="hidden" name="form_sent" value="1" />
				<div class="inform">
					<input type="hidden" name="admin_id" value="<?php echo $user; ?>" />
						<div class="infldset">
							<div class="forminfo">
								<p><strong><?php echo sprintf($lang_admin_restrictions['delete label'], $valid['username']); ?></strong></p>
							</div>		
						</div>
				</div>
				<p class="buttons"><input type="submit" name="delete" value="<?php echo $lang_admin_restrictions['delete']; ?>" /> <a href="javascript:history.go(-1)"><?php echo $lang_admin_restrictions['back']; ?></a></p>
			</form>
		</div>
	</div>
	<div class="clearer"></div>
</div>
</div>
<?php
}
else if($action == 'edit' && isset($_POST['form_sent']) && $stage == '2')
{
	//Stage 2: Edit existing restrictions
	$user = isset($_POST['user']) ? intval($_POST['user']) : null;

	$result = $db->query('SELECT COUNT(id) FROM '.$db->prefix.'admin_restrictions WHERE admin_id = \''.$db->escape($user).'\'') or error('Unable to fetch user info', __FILE__, __LINE__, $db->error());
	$count = $db->result($result);
	
	$result = $db->query('SELECT group_id, username FROM '.$db->prefix.'users WHERE id = \''.$db->escape($user).'\'') or error('Unable to fetch user info', __FILE__, __LINE__, $db->error());
	$valid = $db->fetch_assoc($result);

	//Changing input value of previous HTML form
	if ($valid['group_id'] != PANTHER_ADMIN || $count == '0')
		message($lang_admin_restrictions['no user']);

	$result = $db->query('SELECT admin_opt AS opt, admin_perms AS perms, admin_cats AS cats, admin_forums AS forums, admin_groups AS groups, admin_censoring AS censoring, admin_maintenance AS maintenance, admin_plugins AS plugins, admin_rest AS rest, admin_users AS users, admin_moderate AS moderate, admin_ranks AS ranks, admin_updates AS updates FROM '.$db->prefix.'admin_restrictions WHERE admin_id = '.$user) or error('Unable to fetch user\'s current restrictions', __FILE__, __LINE__, $db->error());
	$admin = $db->fetch_assoc($result);
?>
	<div class="blockform">
		<h2><span><?php echo $lang_admin_restrictions['restrictions head']; ?></span></h2>
		<div class="box">
			<form id="restrictions2" method="post" action="<?php echo get_link($panther_url['admin_restrictions_query'], array('action=edit&stage=3')); ?>">
				<input type="hidden" name="form_sent" value="1" />
				<p class="submittop"><input tabindex="1" type="submit" name="submit" value="<?php echo $lang_common['Submit']; ?>" /></p>
				<div class="inform">
					<input type="hidden" name="admin_id" value="<?php echo $user; ?>" />
					<fieldset>
						<legend><?php echo sprintf($lang_admin_restrictions['restrictions for user x'], $valid['username']); ?></legend>
						<div class="infldset">
							<p><?php echo $lang_admin_restrictions['admin restrictions']; ?></p>
							<table class="aligntop" cellspacing="0">
								<tr>
									<th scope="row"><?php echo $lang_admin_restrictions['board config']; ?></th>
									<td>
										<label class="conl"><input type="radio" name="board_config" value="1"<?php if ($admin['opt'] == '1') echo ' checked="checked"'; ?> tabindex="2" />&#160;<strong><?php echo $lang_admin_common['Yes']; ?></strong></label>
										<label class="conl"><input type="radio" name="board_config" value="0"<?php if ($admin['opt'] == '0') echo ' checked="checked"'; ?> tabindex="3" />&#160;<strong><?php echo $lang_admin_common['No']; ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_restrictions['change config label']; ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_restrictions['board perms']; ?></th>
									<td>
										<label class="conl"><input type="radio" name="board_perms" value="1"<?php if ($admin['perms'] == '1') echo ' checked="checked"'; ?> tabindex="4" />&#160;<strong><?php echo $lang_admin_common['Yes']; ?></strong></label>
										<label class="conl"><input type="radio" name="board_perms" value="0"<?php if ($admin['perms'] == '0') echo ' checked="checked"'; ?> tabindex="5" />&#160;<strong><?php echo $lang_admin_common['No']; ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_restrictions['change perms label']; ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_restrictions['board cats']; ?></th>
									<td>
										<label class="conl"><input type="radio" name="board_cats" value="1"<?php if ($admin['cats'] == '1') echo ' checked="checked"'; ?> tabindex="6" />&#160;<strong><?php echo $lang_admin_common['Yes']; ?></strong></label>
										<label class="conl"><input type="radio" name="board_cats" value="0"<?php if ($admin['cats'] == '0') echo ' checked="checked"'; ?> tabindex="7" />&#160;<strong><?php echo $lang_admin_common['No']; ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_restrictions['change cats label']; ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_restrictions['board forums']; ?></th>
									<td>
										<label class="conl"><input type="radio" name="board_forums" value="1"<?php if ($admin['forums'] == '1') echo ' checked="checked"'; ?> tabindex="8" />&#160;<strong><?php echo $lang_admin_common['Yes']; ?></strong></label>
										<label class="conl"><input type="radio" name="board_forums" value="0"<?php if ($admin['forums'] == '0') echo ' checked="checked"'; ?> tabindex="9" />&#160;<strong><?php echo $lang_admin_common['No']; ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_restrictions['change forums label']; ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_restrictions['board groups']; ?></th>
									<td>
										<label class="conl"><input type="radio" name="board_groups" value="1"<?php if ($admin['groups'] == '1') echo ' checked="checked"'; ?> tabindex="10" />&#160;<strong><?php echo $lang_admin_common['Yes']; ?></strong></label>
										<label class="conl"><input type="radio" name="board_groups" value="0"<?php if ($admin['groups'] == '0') echo ' checked="checked"'; ?> tabindex="11" />&#160;<strong><?php echo $lang_admin_common['No']; ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_restrictions['change groups label']; ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_restrictions['board users']; ?></th>
									<td>
										<label class="conl"><input type="radio" name="board_users" value="1"<?php if ($admin['users'] == '1') echo ' checked="checked"'; ?> tabindex="10" />&#160;<strong><?php echo $lang_admin_common['Yes']; ?></strong></label>
										<label class="conl"><input type="radio" name="board_users" value="0"<?php if ($admin['users'] == '0') echo ' checked="checked"'; ?> tabindex="11" />&#160;<strong><?php echo $lang_admin_common['No']; ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_restrictions['change users label']; ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_restrictions['board censoring']; ?></th>
									<td>
										<label class="conl"><input type="radio" name="board_censoring" value="1"<?php if ($admin['censoring'] == '1') echo ' checked="checked"'; ?> tabindex="10" />&#160;<strong><?php echo $lang_admin_common['Yes']; ?></strong></label>
										<label class="conl"><input type="radio" name="board_censoring" value="0"<?php if ($admin['censoring'] == '0') echo ' checked="checked"'; ?> tabindex="11" />&#160;<strong><?php echo $lang_admin_common['No']; ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_restrictions['change censoring label']; ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_restrictions['board moderate']; ?></th>
									<td>
										<label class="conl"><input type="radio" name="board_moderate" value="1"<?php if ($admin['moderate'] == '1') echo ' checked="checked"'; ?> tabindex="10" />&#160;<strong><?php echo $lang_admin_common['Yes']; ?></strong></label>
										<label class="conl"><input type="radio" name="board_moderate" value="0"<?php if ($admin['moderate'] == '0') echo ' checked="checked"'; ?> tabindex="11" />&#160;<strong><?php echo $lang_admin_common['No']; ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_restrictions['change moderate label']; ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_restrictions['board ranks']; ?></th>
									<td>
										<label class="conl"><input type="radio" name="board_ranks" value="1"<?php if ($admin['ranks'] == '1') echo ' checked="checked"'; ?> tabindex="10" />&#160;<strong><?php echo $lang_admin_common['Yes']; ?></strong></label>
										<label class="conl"><input type="radio" name="board_ranks" value="0"<?php if ($admin['ranks'] == '0') echo ' checked="checked"'; ?> tabindex="11" />&#160;<strong><?php echo $lang_admin_common['No']; ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_restrictions['change ranks label']; ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_restrictions['board maintenance']; ?></th>
									<td>
										<label class="conl"><input type="radio" name="board_maintenance" value="1"<?php if ($admin['maintenance'] == '1') echo ' checked="checked"'; ?> tabindex="10" />&#160;<strong><?php echo $lang_admin_common['Yes']; ?></strong></label>
										<label class="conl"><input type="radio" name="board_maintenance" value="0"<?php if ($admin['maintenance'] == '0') echo ' checked="checked"'; ?> tabindex="11" />&#160;<strong><?php echo $lang_admin_common['No']; ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_restrictions['change maintenance label']; ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_restrictions['board plugins']; ?></th>
									<td>
										<label class="conl"><input type="radio" name="board_plugins" value="1"<?php if ($admin['plugins'] == '1') echo ' checked="checked"'; ?> tabindex="10" />&#160;<strong><?php echo $lang_admin_common['Yes']; ?></strong></label>
										<label class="conl"><input type="radio" name="board_plugins" value="0"<?php if ($admin['plugins'] == '0') echo ' checked="checked"'; ?> tabindex="11" />&#160;<strong><?php echo $lang_admin_common['No']; ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_restrictions['change plugins label']; ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_restrictions['board updates']; ?></th>
									<td>
										<label class="conl"><input type="radio" name="board_updates" value="1"<?php if ($admin['updates'] == '1') echo ' checked="checked"'; ?> tabindex="10" />&#160;<strong><?php echo $lang_admin_common['Yes']; ?></strong></label>
										<label class="conl"><input type="radio" name="board_updates" value="0"<?php if ($admin['updates'] == '0') echo ' checked="checked"'; ?> tabindex="11" />&#160;<strong><?php echo $lang_admin_common['No']; ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_restrictions['install updates label']; ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_restrictions['board restrictions']; ?></th>
									<td>
										<label class="conl"><input type="radio" name="board_restrictions" value="1"<?php if ($admin['rest'] == '1') echo ' checked="checked"'; ?> tabindex="10" />&#160;<strong><?php echo $lang_admin_common['Yes']; ?></strong></label>
										<label class="conl"><input type="radio" name="board_restrictions" value="0"<?php if ($admin['rest'] == '0') echo ' checked="checked"'; ?> tabindex="11" />&#160;<strong><?php echo $lang_admin_common['No']; ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_restrictions['change restrictions label']; ?></span>
									</td>
								</tr>
							</table>
						</div>
					</fieldset>
				</div>
				<p class="submitend"><input type="submit" name="submit" value="<?php echo $lang_common['Submit']; ?>" tabindex="43" /></p>
			</form>
		</div>
	</div>
	<div class="clearer"></div>
</div>
</div>
<?php
}
else if($action == 'add' && isset($_POST['form_sent']) && $stage == '2')
{
	//Stage 2: add restrictions for a specific admin
	$user = isset($_POST['user']) ? intval($_POST['user']) : null;

$result = $db->query('SELECT group_id, username FROM '.$db->prefix.'users WHERE id = \''.$db->escape($user).'\'') or error('Unable to fetch user info', __FILE__, __LINE__, $db->error());
$valid = $db->fetch_assoc($result);

	//Changing input value of previous HTML form
if ($valid['group_id'] != PANTHER_ADMIN)
	message($lang_admin_restrictions['user not admin']);
?>
	<div class="blockform">
		<h2><span><?php echo $lang_admin_restrictions['restrictions head']; ?></span></h2>
		<div class="box">
			<form id="restrictions2" method="post" action="<?php echo get_link($panther_url['admin_restrictions_query'], array('action=add&stage=3')); ?>">
				<input type="hidden" name="form_sent" value="1" />
				<p class="submittop"><input tabindex="1" type="submit" name="submit" value="<?php echo $lang_common['Submit']; ?>" /></p>
				<div class="inform">
					<input type="hidden" name="admin_id" value="<?php echo $user; ?>" />
					<fieldset>
						<legend><?php echo sprintf($lang_admin_restrictions['restrictions for user x'], $valid['username']); ?></legend>
						<div class="infldset">
							<p><?php echo $lang_admin_restrictions['admin restrictions']; ?></p>
							<table class="aligntop" cellspacing="0">
								<tr>
									<th scope="row"><?php echo $lang_admin_restrictions['board config']; ?></th>
									<td>
										<label class="conl"><input type="radio" name="board_config" value="1" checked="checked" tabindex="2" />&#160;<strong><?php echo $lang_admin_common['Yes']; ?></strong></label>
										<label class="conl"><input type="radio" name="board_config" value="0" tabindex="3" />&#160;<strong><?php echo $lang_admin_common['No']; ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_restrictions['change config label']; ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_restrictions['board perms']; ?></th>
									<td>
										<label class="conl"><input type="radio" name="board_perms" value="1" checked="checked" tabindex="4" />&#160;<strong><?php echo $lang_admin_common['Yes']; ?></strong></label>
										<label class="conl"><input type="radio" name="board_perms" value="0" tabindex="5" />&#160;<strong><?php echo $lang_admin_common['No']; ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_restrictions['change perms label']; ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_restrictions['board cats']; ?></th>
									<td>
										<label class="conl"><input type="radio" name="board_cats" value="1" checked="checked" tabindex="6" />&#160;<strong><?php echo $lang_admin_common['Yes']; ?></strong></label>
										<label class="conl"><input type="radio" name="board_cats" value="0" tabindex="7" />&#160;<strong><?php echo $lang_admin_common['No']; ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_restrictions['change cats label']; ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_restrictions['board forums']; ?></th>
									<td>
										<label class="conl"><input type="radio" name="board_forums" value="1" checked="checked" tabindex="8" />&#160;<strong><?php echo $lang_admin_common['Yes']; ?></strong></label>
										<label class="conl"><input type="radio" name="board_forums" value="0" tabindex="9" />&#160;<strong><?php echo $lang_admin_common['No']; ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_restrictions['change forums label']; ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_restrictions['board groups']; ?></th>
									<td>
										<label class="conl"><input type="radio" name="board_groups" value="1" checked="checked" tabindex="10" />&#160;<strong><?php echo $lang_admin_common['Yes']; ?></strong></label>
										<label class="conl"><input type="radio" name="board_groups" value="0" tabindex="11" />&#160;<strong><?php echo $lang_admin_common['No']; ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_restrictions['change groups label']; ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_restrictions['board users']; ?></th>
									<td>
										<label class="conl"><input type="radio" name="board_users" value="1" checked="checked" tabindex="10" />&#160;<strong><?php echo $lang_admin_common['Yes']; ?></strong></label>
										<label class="conl"><input type="radio" name="board_users" value="0" tabindex="11" />&#160;<strong><?php echo $lang_admin_common['No']; ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_restrictions['change users label']; ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_restrictions['board censoring']; ?></th>
									<td>
										<label class="conl"><input type="radio" name="board_censoring" value="1" checked="checked" tabindex="10" />&#160;<strong><?php echo $lang_admin_common['Yes']; ?></strong></label>
										<label class="conl"><input type="radio" name="board_censoring" value="0" tabindex="11" />&#160;<strong><?php echo $lang_admin_common['No']; ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_restrictions['change censoring label']; ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_restrictions['board moderate']; ?></th>
									<td>
										<label class="conl"><input type="radio" name="board_moderate" value="1" checked="checked" tabindex="10" />&#160;<strong><?php echo $lang_admin_common['Yes']; ?></strong></label>
										<label class="conl"><input type="radio" name="board_moderate" value="0" tabindex="11" />&#160;<strong><?php echo $lang_admin_common['No']; ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_restrictions['change moderate label']; ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_restrictions['board ranks']; ?></th>
									<td>
										<label class="conl"><input type="radio" name="board_ranks" value="1" checked="checked" tabindex="10" />&#160;<strong><?php echo $lang_admin_common['Yes']; ?></strong></label>
										<label class="conl"><input type="radio" name="board_ranks" value="0" tabindex="11" />&#160;<strong><?php echo $lang_admin_common['No']; ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_restrictions['change ranks label']; ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_restrictions['board maintenance']; ?></th>
									<td>
										<label class="conl"><input type="radio" name="board_maintenance" value="1" checked="checked" tabindex="10" />&#160;<strong><?php echo $lang_admin_common['Yes']; ?></strong></label>
										<label class="conl"><input type="radio" name="board_maintenance" value="0" tabindex="11" />&#160;<strong><?php echo $lang_admin_common['No']; ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_restrictions['change maintenance label']; ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_restrictions['board plugins']; ?></th>
									<td>
										<label class="conl"><input type="radio" name="board_plugins" value="1" checked="checked" tabindex="10" />&#160;<strong><?php echo $lang_admin_common['Yes']; ?></strong></label>
										<label class="conl"><input type="radio" name="board_plugins" value="0" tabindex="11" />&#160;<strong><?php echo $lang_admin_common['No']; ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_restrictions['change plugins label']; ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_restrictions['board updates']; ?></th>
									<td>
										<label class="conl"><input type="radio" name="board_updates" value="1" checked="checked" tabindex="10" />&#160;<strong><?php echo $lang_admin_common['Yes']; ?></strong></label>
										<label class="conl"><input type="radio" name="board_updates" value="0" tabindex="11" />&#160;<strong><?php echo $lang_admin_common['No']; ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_restrictions['install updates label']; ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_restrictions['board restrictions']; ?></th>
									<td>
										<label class="conl"><input type="radio" name="board_restrictions" value="1" checked="checked" tabindex="10" />&#160;<strong><?php echo $lang_admin_common['Yes']; ?></strong></label>
										<label class="conl"><input type="radio" name="board_restrictions" value="0" tabindex="11" />&#160;<strong><?php echo $lang_admin_common['No']; ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_restrictions['change restrictions label']; ?></span>
									</td>
								</tr>
							</table>
						</div>
					</fieldset>
				</div>
				<p class="submitend"><input type="submit" name="submit" value="<?php echo $lang_common['Submit']; ?>" tabindex="43" /></p>
			</form>
		</div>
	</div>
	<div class="clearer"></div>
</div>
</div>
<?php
}
else
{
	//Stage 1: Select admin to impose restrictions upon
	$admins = $restrictions = array();
	$result = $db->query('SELECT u.username, u.id FROM '.$db->prefix.'users AS u LEFT JOIN '.$db->prefix.'admin_restrictions AS ar ON u.id = ar.admin_id WHERE u.group_id = '.PANTHER_ADMIN.' AND u.id != \'2\' AND ar.admin_id IS NULL ORDER BY u.id ASC') or error('Unable to fetch user info', __FILE__, __LINE__, $db->error());
	while ($admin = $db->fetch_assoc($result))
		$admins[] = '<option value="'.$admin['id'].'">'.panther_htmlspecialchars($admin['username']).'</option>';
		
	$result = $db->query('SELECT u.username, u.id FROM '.$db->prefix.'users AS u LEFT JOIN '.$db->prefix.'admin_restrictions AS ar ON u.id = ar.admin_id WHERE u.group_id = '.PANTHER_ADMIN.' AND u.id != \'2\' AND ar.admin_id IS NOT NULL ORDER BY u.id ASC') or error('Unable to fetch user info', __FILE__, __LINE__, $db->error());
	while ($admin = $db->fetch_assoc($result))
		$restrictions[] = '<option value="'.$admin['id'].'">'.panther_htmlspecialchars($admin['username']).'</option>';

	if (count($admins) < '1')
		$admins[] = '<optgroup label="'.$lang_admin_restrictions['no other admins'].'"></optgroup>';

	if (count($restrictions) < '1')
		$restrictions[] = '<optgroup label="'.$lang_admin_restrictions['no other admins'].'"></optgroup>';
?>
	<div class="blockform">
		<h2><span><?php echo $lang_admin_restrictions['restrictions head']; ?></span></h2>
		<div class="box">
			<form id="restrictions2" method="post" action="<?php echo get_link($panther_url['admin_restrictions_query'], array('action=add&stage=2')); ?>">
				<input type="hidden" name="form_sent" value="1" />
				<div class="inform">
					<fieldset>
						<legend><?php echo $lang_admin_restrictions['restriction information']; ?></legend>
						<div class="infldset">
							<br />
								<select name="user">
								<?php echo implode("\n\t\t\t\t\t\t", $admins)."\n"; ?>
								</select>				
							<input type="submit" name="submit" value="<?php echo $lang_common['Submit']; ?>" tabindex="43" />
						<br /><br />
						</div>
					</fieldset>
				</div>
			</form>
			<form id="restrictions2" method="post" action="<?php echo get_link($panther_url['admin_restrictions_query'], array('action=edit&stage=2')); ?>">
				<input type="hidden" name="form_sent" value="1" />
				<div class="inform">
					<fieldset>
						<legend><?php echo $lang_admin_restrictions['restriction information 2']; ?></legend>
						<div class="infldset">
							<br />
								<select name="user">
								<?php echo implode("\n\t\t\t\t\t\t", $restrictions)."\n"; ?>
								</select>				
							<input type="submit" name="submit" value="<?php echo $lang_common['Submit']; ?>" tabindex="43" />
						<br /><br />
						</div>
					</fieldset>
				</div>
			</form>
			<form id="restrictions2" method="post" action="<?php echo get_link($panther_url['admin_restrictions_query'], array('action=delete&stage=2')); ?>">
				<input type="hidden" name="form_sent" value="1" />
				<div class="inform">
					<fieldset>
						<legend><?php echo $lang_admin_restrictions['restriction information 3']; ?></legend>
						<div class="infldset">
							<br />
								<select name="user">
								<?php echo implode("\n\t\t\t\t\t\t", $restrictions)."\n"; ?>
								</select>				
							<input type="submit" name="submit" value="<?php echo $lang_admin_restrictions['delete']; ?>" tabindex="43" />
						<br /><br />
						</div>
					</fieldset>
				</div>
			</form>

		</div>
	</div>
	<div class="clearer"></div>
</div>
</div>
<?php
}
require PANTHER_ROOT.'footer.php'; ?>