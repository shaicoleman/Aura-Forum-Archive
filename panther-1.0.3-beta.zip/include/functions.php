<?php

/**
 * Copyright (C) 2015 Panther (http://panther.strongholdnation.co.uk/)
 * based on code by Rickard Andersson copyright (C) 2002-2008 PunBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

//
// Return current timestamp (with microseconds) as a float
//
function get_microtime()
{
	list($usec, $sec) = explode(' ', microtime());
	return ((float)$usec + (float)$sec);
}

//
// Cookie stuff!
//
function check_cookie(&$panther_user)
{
	global $db, $db_type, $panther_config;

	$now = time();

	// If the cookie is set and it matches the correct pattern, then read the values from it
	if (isset($_COOKIE[$panther_config['o_cookie_name']]) && preg_match('%^(\d+)\|([0-9a-fA-F]+)\|(\d+)\|([0-9a-fA-F]+)$%', $_COOKIE[$panther_config['o_cookie_name']], $matches))
	{
		$cookie = array(
			'user_id'			=> intval($matches[1]),
			'password_hash' 	=> $matches[2],
			'expiration_time'	=> intval($matches[3]),
			'cookie_hash'		=> $matches[4],
		);
	}

	// If it has a non-guest user, and hasn't expired
	if (isset($cookie) && $cookie['user_id'] > 0 && $cookie['expiration_time'] > $now)
	{
		// If the cookie has been tampered with
		if (forum_hmac($cookie['user_id'].'|'.$cookie['expiration_time'], $panther_config['o_cookie_seed'].'_cookie_hash') != $cookie['cookie_hash'])
		{
			$expire = $now + 31536000; // The cookie expires after a year
			panther_setcookie(1, panther_hash(uniqid(rand(), true)), $expire);
			set_default_user();

			return;
		}

		// Check if there's a user with the user ID and password hash from the cookie
		$result = $db->query('SELECT u.*, g.*, o.logged, o.idle FROM '.$db->prefix.'users AS u INNER JOIN '.$db->prefix.'groups AS g ON u.group_id=g.g_id LEFT JOIN '.$db->prefix.'online AS o ON o.user_id=u.id WHERE u.id='.intval($cookie['user_id'])) or error('Unable to fetch user information', __FILE__, __LINE__, $db->error());
		$panther_user = $db->fetch_assoc($result);

		// If user authorisation failed
		if (!isset($panther_user['id']) || forum_hmac($panther_user['password'], $panther_config['o_cookie_seed'].'_password_hash') !== $cookie['password_hash'])
		{
			$expire = $now + 31536000; // The cookie expires after a year
			panther_setcookie(1, panther_hash(uniqid(rand(), true)), $expire);
			set_default_user();

			return;
		}

		// Send a new, updated cookie with a new expiration timestamp
		$expire = ($cookie['expiration_time'] > $now + $panther_config['o_timeout_visit']) ? $now + 1209600 : $now + $panther_config['o_timeout_visit'];
		panther_setcookie($panther_user['id'], $panther_user['password'], $expire);

		// Set a default language if the user selected language no longer exists
		if (!file_exists(PANTHER_ROOT.'lang/'.$panther_user['language']))
			$panther_user['language'] = $panther_config['o_default_lang'];

		// Set a default style if the user selected style no longer exists
		if (!file_exists(PANTHER_ROOT.'style/'.$panther_user['style'].'.css'))
			$panther_user['style'] = $panther_config['o_default_style'];

		if (!$panther_user['disp_topics'])
			$panther_user['disp_topics'] = $panther_config['o_disp_topics_default'];
		if (!$panther_user['disp_posts'])
			$panther_user['disp_posts'] = $panther_config['o_disp_posts_default'];

		// Define this if you want this visit to affect the online list and the users last visit data
		if (!defined('PANTHER_QUIET_VISIT'))
		{
			// Update the online list
			if (!$panther_user['logged'])
			{
				$panther_user['logged'] = $now;

				// With MySQL/MySQLi/SQLite, REPLACE INTO avoids a user having two rows in the online table
				switch ($db_type)
				{
					case 'mysql':
					case 'mysqli':
					case 'mysql_innodb':
					case 'mysqli_innodb':
					case 'sqlite':
						$db->query('REPLACE INTO '.$db->prefix.'online (user_id, ident, logged) VALUES('.$panther_user['id'].', \''.$db->escape($panther_user['username']).'\', '.$panther_user['logged'].')') or error('Unable to insert into online list', __FILE__, __LINE__, $db->error());
						break;

					default:
						$db->query('INSERT INTO '.$db->prefix.'online (user_id, ident, logged) SELECT '.$panther_user['id'].', \''.$db->escape($panther_user['username']).'\', '.$panther_user['logged'].' WHERE NOT EXISTS (SELECT 1 FROM '.$db->prefix.'online WHERE user_id='.$panther_user['id'].')') or error('Unable to insert into online list', __FILE__, __LINE__, $db->error());
						break;
				}

				// Reset tracked topics
				set_tracked_topics(null);
			}
			else
			{
				// Special case: We've timed out, but no other user has browsed the forums since we timed out
				if ($panther_user['logged'] < ($now-$panther_config['o_timeout_visit']))
				{
					$db->query('UPDATE '.$db->prefix.'users SET last_visit='.$panther_user['logged'].' WHERE id='.$panther_user['id']) or error('Unable to update user visit data', __FILE__, __LINE__, $db->error());
					$panther_user['last_visit'] = $panther_user['logged'];
				}

				$idle_sql = ($panther_user['idle'] == '1') ? ', idle=0' : '';
				$db->query('UPDATE '.$db->prefix.'online SET logged='.$now.$idle_sql.' WHERE user_id='.$panther_user['id']) or error('Unable to update online list', __FILE__, __LINE__, $db->error());

				// Update tracked topics with the current expire time
				if (isset($_COOKIE[$panther_config['o_cookie_name'].'_track']))
					forum_setcookie($panther_config['o_cookie_name'].'_track', $_COOKIE[$panther_config['o_cookie_name'].'_track'], $now + $panther_config['o_timeout_visit']);
			}
		}
		else
		{
			if (!$panther_user['logged'])
				$panther_user['logged'] = $panther_user['last_visit'];
		}

		$panther_user['is_guest'] = false;
		$panther_user['is_admmod'] = $panther_user['g_id'] == PANTHER_ADMIN || $panther_user['g_moderator'] == '1';
		$panther_user['is_bot'] = false;
	}
	else
		set_default_user();
}

//
// Converts the CDATA end sequence ]]> into ]]&gt;
//
function escape_cdata($str)
{
	return str_replace(']]>', ']]&gt;', $str);
}

//
// Authenticates the provided username and password against the user database
// $user can be either a user ID (integer) or a username (string)
// $password can be either a plaintext password or a password hash including salt ($password_is_hash must be set accordingly)
//
function authenticate_user($user, $password, $password_is_hash = false)
{
	global $db, $panther_user;

	// Check if there's a user matching $user and $password
	$result = $db->query('SELECT u.*, g.*, o.logged, o.idle FROM '.$db->prefix.'users AS u INNER JOIN '.$db->prefix.'groups AS g ON g.g_id=u.group_id LEFT JOIN '.$db->prefix.'online AS o ON o.user_id=u.id WHERE '.(is_int($user) ? 'u.id='.intval($user) : 'u.username=\''.$db->escape($user).'\'')) or error('Unable to fetch user info', __FILE__, __LINE__, $db->error());
	$panther_user = $db->fetch_assoc($result);

	if (!isset($panther_user['id']) ||
		($password_is_hash && $password != $panther_user['password']) ||
		(!$password_is_hash && panther_hash($password) != $panther_user['password']))
		set_default_user();
	else
		$panther_user['is_guest'] = false;
}


//
// Try to determine the current URL
//
function get_current_url($max_length = 0)
{
	$protocol = get_current_protocol();
	$port = (isset($_SERVER['SERVER_PORT']) && (($_SERVER['SERVER_PORT'] != '80' && $protocol == 'http') || ($_SERVER['SERVER_PORT'] != '443' && $protocol == 'https')) && strpos($_SERVER['HTTP_HOST'], ':') === false) ? ':'.$_SERVER['SERVER_PORT'] : '';

	$url = urldecode($protocol.'://'.$_SERVER['HTTP_HOST'].$port.$_SERVER['REQUEST_URI']);

	if (strlen($url) <= $max_length || $max_length == 0)
		return $url;

	// We can't find a short enough url
	return null;
}


//
// Fetch the current protocol in use - http or https
//
function get_current_protocol()
{
	$protocol = 'http';

	// Check if the server is claiming to using HTTPS
	if (!empty($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS']) != 'off')
		$protocol = 'https';

	// If we are behind a reverse proxy try to decide which protocol it is using
	if (defined('FORUM_BEHIND_REVERSE_PROXY'))
	{
		// Check if we are behind a Microsoft based reverse proxy
		if (!empty($_SERVER['HTTP_FRONT_END_HTTPS']) && strtolower($_SERVER['HTTP_FRONT_END_HTTPS']) != 'off')
			$protocol = 'https';

		// Check if we're behind a "proper" reverse proxy, and what protocol it's using
		if (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']))
			$protocol = strtolower($_SERVER['HTTP_X_FORWARDED_PROTO']);
	}

	return $protocol;
}

function check_ssl_state()
{
	global $panther_config;

	if ($panther_config['o_force_ssl'] == '1' && get_current_protocol() == 'http')
	{
		header('Location: '.str_replace('http://', 'https://', get_current_url()));
		exit;
	}
}

//
// Fetch the base_url, optionally support HTTPS and HTTP
//
function get_base_url($support_https = false)
{
	global $panther_config;
	static $base_url;

	if (!$support_https)
		return $panther_config['o_base_url'];

	if (!isset($base_url))
	{
		// Make sure we are using the correct protocol
		$base_url = str_replace(array('http://', 'https://'), get_current_protocol().'://', $panther_config['o_base_url']);
	}

	return $base_url;
}

//
// Fetch admin IDs
//
function get_admin_ids()
{
	if (file_exists(FORUM_CACHE_DIR.'cache_admins.php'))
		include FORUM_CACHE_DIR.'cache_admins.php';

	if (!defined('PANTHER_ADMINS_LOADED'))
	{
		if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
			require PANTHER_ROOT.'include/cache.php';

		generate_admins_cache();
		require FORUM_CACHE_DIR.'cache_admins.php';
	}

	return $panther_admins;
}

//
// Fill $panther_user with default values (for guests)
//
function set_default_user()
{
	global $db, $db_type, $panther_user, $panther_config;

	$remote_addr = get_remote_address();
	$remote_addr = isbotex($remote_addr);

	// Fetch guest user
	$result = $db->query('SELECT u.*, g.*, o.logged, o.last_post, o.last_search FROM '.$db->prefix.'users AS u INNER JOIN '.$db->prefix.'groups AS g ON u.group_id=g.g_id LEFT JOIN '.$db->prefix.'online AS o ON o.ident=\''.$db->escape($remote_addr).'\' WHERE u.id=1') or error('Unable to fetch guest information', __FILE__, __LINE__, $db->error());
	if (!$db->num_rows($result))
		exit('Unable to fetch guest information. Your database must contain both a guest user and a guest user group.');

	$panther_user = $db->fetch_assoc($result);

	// Update online list
	if (!$panther_user['logged'])
	{
		$panther_user['logged'] = time();

		// With MySQL/MySQLi/SQLite, REPLACE INTO avoids a user having two rows in the online table
		switch ($db_type)
		{
			case 'mysql':
			case 'mysqli':
			case 'mysql_innodb':
			case 'mysqli_innodb':
			case 'sqlite':
				$db->query('REPLACE INTO '.$db->prefix.'online (user_id, ident, logged) VALUES(1, \''.$db->escape($remote_addr).'\', '.$panther_user['logged'].')') or error('Unable to insert into online list', __FILE__, __LINE__, $db->error());
				break;

			default:
				$db->query('INSERT INTO '.$db->prefix.'online (user_id, ident, logged) SELECT 1, \''.$db->escape($remote_addr).'\', '.$panther_user['logged'].' WHERE NOT EXISTS (SELECT 1 FROM '.$db->prefix.'online WHERE ident=\''.$db->escape($remote_addr).'\')') or error('Unable to insert into online list', __FILE__, __LINE__, $db->error());
				break;
		}
	}
	else
		$db->query('UPDATE '.$db->prefix.'online SET logged='.time().' WHERE ident=\''.$db->escape($remote_addr).'\'') or error('Unable to update online list', __FILE__, __LINE__, $db->error());

	$panther_user['disp_topics'] = $panther_config['o_disp_topics_default'];
	$panther_user['disp_posts'] = $panther_config['o_disp_posts_default'];
	$panther_user['timezone'] = $panther_config['o_default_timezone'];
	$panther_user['dst'] = $panther_config['o_default_dst'];
	$panther_user['language'] = $panther_config['o_default_lang'];
	$panther_user['style'] = $panther_config['o_default_style'];
	$panther_user['is_guest'] = true;
	$panther_user['is_admmod'] = false;
	$panther_user['is_bot'] = (strpos($remote_addr, '[Bot]') !== false);
}

//
// SHA512 HMAC with PHP 4 fallback
//
function forum_hmac($data, $key, $raw_output = false)
{
	if (function_exists('hash_hmac'))
		return hash_hmac('sha512', $data, $key, $raw_output);

	// If key size more than blocksize then we hash it once
	if (strlen($key) > 64)
		$key = pack('H*', panther_hash($key)); // we have to use raw output here to match the standard

	// Ensure we're padded to exactly one block boundary
	$key = str_pad($key, 64, chr(0x00));

	$hmac_opad = str_repeat(chr(0x5C), 64);
	$hmac_ipad = str_repeat(chr(0x36), 64);

	// Do inner and outer padding
	for ($i = 0;$i < 64;$i++) {
		$hmac_opad[$i] = $hmac_opad[$i] ^ $key[$i];
		$hmac_ipad[$i] = $hmac_ipad[$i] ^ $key[$i];
	}

	// Finally, calculate the HMAC
	$hash = panther_hash($hmac_opad.pack('H*', panther_hash($hmac_ipad.$data)));

	// If we want raw output then we need to pack the final result
	if ($raw_output)
		$hash = pack('H*', $hash);

	return $hash;
}

//
// Set a cookie, Panther style!
// Wrapper for forum_setcookie
//
function panther_setcookie($user_id, $password_hash, $expire)
{
	global $panther_config;

	forum_setcookie($panther_config['o_cookie_name'], $user_id.'|'.forum_hmac($password_hash, $panther_config['o_cookie_seed'].'_password_hash').'|'.$expire.'|'.forum_hmac($user_id.'|'.$expire, $panther_config['o_cookie_seed'].'_cookie_hash'), $expire);
}


//
// Set a cookie, Panther style!
//
function forum_setcookie($name, $value, $expire)
{
	global $panther_config;

	if ($expire - time() - $panther_config['o_timeout_visit'] < 1)
		$expire = 0;

	// Enable sending of a P3P header
	header('P3P: CP="CUR ADM"');

	if (version_compare(PHP_VERSION, '5.2.0', '>='))
		setcookie($name, $value, $expire, $panther_config['o_cookie_path'], $panther_config['o_cookie_domain'], $panther_config['o_cookie_secure'], true);
	else
		setcookie($name, $value, $expire, $panther_config['o_cookie_path'].'; HttpOnly', $panther_config['o_cookie_domain'], $panther_config['o_cookie_secure']);
}


//
// Check whether the connecting user is banned (and delete any expired bans while we're at it)
//
function check_bans()
{
	global $db, $panther_config, $lang_common, $panther_user, $panther_bans;

	// Admins and moderators aren't affected
	if ($panther_user['is_admmod'] || !$panther_bans)
		return;

	// Add a dot or a colon (depending on IPv4/IPv6) at the end of the IP address to prevent banned address
	// 192.168.0.5 from matching e.g. 192.168.0.50
	$user_ip = get_remote_address();
	$user_ip .= (strpos($user_ip, '.') !== false) ? '.' : ':';

	$bans_altered = false;
	$is_banned = false;

	foreach ($panther_bans as $cur_ban)
	{
		// Has this ban expired?
		if ($cur_ban['expire'] != '' && $cur_ban['expire'] <= time())
		{
			$db->query('DELETE FROM '.$db->prefix.'bans WHERE id='.$cur_ban['id']) or error('Unable to delete expired ban', __FILE__, __LINE__, $db->error());
			$bans_altered = true;
			continue;
		}

		if ($cur_ban['username'] != '' && utf8_strtolower($panther_user['username']) == utf8_strtolower($cur_ban['username']))
			$is_banned = true;

		if ($cur_ban['ip'] != '')
		{
			$cur_ban_ips = explode(' ', $cur_ban['ip']);

			$num_ips = count($cur_ban_ips);
			for ($i = 0; $i < $num_ips; ++$i)
			{
				// Add the proper ending to the ban
				if (strpos($user_ip, '.') !== false)
					$cur_ban_ips[$i] = $cur_ban_ips[$i].'.';
				else
					$cur_ban_ips[$i] = $cur_ban_ips[$i].':';

				if (substr($user_ip, 0, strlen($cur_ban_ips[$i])) == $cur_ban_ips[$i])
				{
					$is_banned = true;
					break;
				}
			}
		}

		if ($is_banned)
		{
			$db->query('DELETE FROM '.$db->prefix.'online WHERE ident=\''.$db->escape($panther_user['username']).'\'') or error('Unable to delete from online list', __FILE__, __LINE__, $db->error());
			message($lang_common['Ban message'].' '.(($cur_ban['expire'] != '') ? $lang_common['Ban message 2'].' '.strtolower(format_time($cur_ban['expire'], true)).'. ' : '').(($cur_ban['message'] != '') ? $lang_common['Ban message 3'].'<br /><br /><strong>'.panther_htmlspecialchars($cur_ban['message']).'</strong><br /><br />' : '<br /><br />').$lang_common['Ban message 4'].' <a href="mailto:'.panther_htmlspecialchars($panther_config['o_admin_email']).'">'.panther_htmlspecialchars($panther_config['o_admin_email']).'</a>.', true);
		}
	}

	// If we removed any expired bans during our run-through, we need to regenerate the bans cache
	if ($bans_altered)
	{
		if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
			require PANTHER_ROOT.'include/cache.php';

		generate_bans_cache();
	}
}

//
// Check username
//
function check_username($username, $exclude_id = null)
{
	global $db, $panther_config, $errors, $lang_prof_reg, $lang_register, $lang_common, $panther_bans;

	// Include UTF-8 function
	require_once PANTHER_ROOT.'include/utf8/strcasecmp.php';

	// Convert multiple whitespace characters into one (to prevent people from registering with indistinguishable usernames)
	$username = preg_replace('%\s+%s', ' ', $username);

	// Validate username
	if (panther_strlen($username) < 2)
		$errors[] = $lang_prof_reg['Username too short'];
	else if (panther_strlen($username) > 25) // This usually doesn't happen since the form element only accepts 25 characters
		$errors[] = $lang_prof_reg['Username too long'];
	else if (!strcasecmp($username, 'Guest') || !utf8_strcasecmp($username, $lang_common['Guest']))
		$errors[] = $lang_prof_reg['Username guest'];
	else if (preg_match('%[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}%', $username) || preg_match('%((([0-9A-Fa-f]{1,4}:){7}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){6}:[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){5}:([0-9A-Fa-f]{1,4}:)?[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){4}:([0-9A-Fa-f]{1,4}:){0,2}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){3}:([0-9A-Fa-f]{1,4}:){0,3}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){2}:([0-9A-Fa-f]{1,4}:){0,4}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){6}((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|(([0-9A-Fa-f]{1,4}:){0,5}:((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|(::([0-9A-Fa-f]{1,4}:){0,5}((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|([0-9A-Fa-f]{1,4}::([0-9A-Fa-f]{1,4}:){0,5}[0-9A-Fa-f]{1,4})|(::([0-9A-Fa-f]{1,4}:){0,6}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){1,7}:))%', $username))
		$errors[] = $lang_prof_reg['Username IP'];
	else if ((strpos($username, '[') !== false || strpos($username, ']') !== false) && strpos($username, '\'') !== false && strpos($username, '"') !== false)
		$errors[] = $lang_prof_reg['Username reserved chars'];
	else if (preg_match('%(?:\[/?(?:b|u|s|ins|del|em|i|h|colou?r|quote|code|img|url|email|list|\*|topic|post|forum|user)\]|\[(?:img|url|quote|list)=)%i', $username))
		$errors[] = $lang_prof_reg['Username BBCode'];

	// Check username for any censored words
	if ($panther_config['o_censoring'] == '1' && censor_words($username) != $username)
		$errors[] = $lang_register['Username censor'];

	// Check that the username (or a too similar username) is not already registered
	$query = (!is_null($exclude_id)) ? ' AND id!='.$exclude_id : '';

	$result = $db->query('SELECT username FROM '.$db->prefix.'users WHERE (UPPER(username)=UPPER(\''.$db->escape($username).'\') OR UPPER(username)=UPPER(\''.$db->escape(ucp_preg_replace('%[^\p{L}\p{N}]%u', '', $username)).'\')) AND id>1'.$query) or error('Unable to fetch user info', __FILE__, __LINE__, $db->error());

	if ($db->num_rows($result))
	{
		$busy = $db->result($result);
		$errors[] = $lang_register['Username dupe 1'].' '.panther_htmlspecialchars($busy).'. '.$lang_register['Username dupe 2'];
	}

	// Check username for any banned usernames
	foreach ($panther_bans as $cur_ban)
	{
		if ($cur_ban['username'] != '' && utf8_strtolower($username) == utf8_strtolower($cur_ban['username']))
		{
			$errors[] = $lang_prof_reg['Banned username'];
			break;
		}
	}
}

//
// Update "Users online"
//
function update_users_online()
{
	global $db, $panther_config, $panther_user;

	$cur_position = substr($_SERVER['REQUEST_URI'], 1);
	$server_base = dirname($_SERVER['PHP_SELF']);

	if ($server_base !== '/')
		$cur_position = substr($cur_position, strlen($server_base));

	if ($cur_position == '') 
		$cur_position = 'index.php';

	$now = time();
	$timeout = $now - $panther_config['o_timeout_online'];
	$online['users'] = $online['guests'] = array();

	// Fetch all online list entries that are older than "o_timeout_online"
	$result = $db->query('SELECT o.user_id, o.ident, o.logged, o.idle, u.group_id FROM '.$db->prefix.'online AS o LEFT JOIN '.$db->prefix.'users AS u ON o.user_id=u.id') or error('Unable to fetch old entries from online list', __FILE__, __LINE__, $db->error());
	while ($cur_user = $db->fetch_assoc($result))
	{	
	
		if ($cur_user['logged'] < $timeout)
		{
			// If the entry is a guest, delete it
			if ($cur_user['user_id'] == '0')
				$db->query('DELETE FROM '.$db->prefix.'online WHERE ident=\''.$db->escape($cur_user['ident']).'\'') or error('Unable to delete from online list', __FILE__, __LINE__, $db->error());
			else
			{
				// If the entry is older than "o_timeout_visit", update last_visit for the user in question, then delete him/her from the online list
				if ($cur_user['logged'] < ($now - $panther_config['o_timeout_visit']))
				{
					$db->query('UPDATE '.$db->prefix.'users SET last_visit='.$cur_user['logged'].' WHERE id='.$cur_user['user_id']) or error('Unable to update user visit data', __FILE__, __LINE__, $db->error());
					$db->query('DELETE FROM '.$db->prefix.'online WHERE user_id='.$cur_user['user_id']) or error('Unable to delete from online list', __FILE__, __LINE__, $db->error());
				}
				else if ($cur_user['idle'] == '0')
					$db->query('UPDATE '.$db->prefix.'online SET idle=1 WHERE user_id='.$cur_user['user_id']) or error('Unable to insert into online list', __FILE__, __LINE__, $db->error());
			}
		}
		else
		{
			if ($cur_user['user_id'] == 1)
				$online['guests'][] = array('ident' => $cur_user['ident'], 'group_id' => PANTHER_GUEST);
			else
				$online['users'][$cur_user['user_id']] = array('username' => $cur_user['ident'], 'group_id' => $cur_user['group_id'], 'id' => $cur_user['user_id']);
		}
	}
	
	if (!$panther_user['is_bot'])
	{
		if ($panther_user['is_guest'])
			$db->query('UPDATE '.$db->prefix.'online SET currently = \''.$db->escape($cur_position).'\' WHERE ident=\''.$db->escape(get_remote_address()).'\'') or error('Unable to update user position in the online list1', __FILE__, __LINE__, $db->error());
		else	
			$db->query('UPDATE '.$db->prefix.'online SET currently= \''.$db->escape($cur_position).'\' WHERE user_id='.$panther_user['id']) or error('Unable to update user position in the online list2', __FILE__, __LINE__, $db->error());
	}
	return $online;
}

//
// Display the profile navigation menu
//
function generate_profile_menu($page = '')
{
	global $lang_profile, $panther_config, $panther_user, $id, $panther_url;
?>
<div id="profile" class="block2col">
	<div class="blockmenu">
		<h2><span><?php echo $lang_profile['Profile menu'] ?></span></h2>
		<div class="box">
			<div class="inbox">
				<ul>
					<li<?php if ($page == 'essentials') echo ' class="isactive"'; ?>><a href="<?php echo get_link($panther_url['profile_essentials'], array($id)) ?>"><?php echo $lang_profile['Section essentials'] ?></a></li>
					<li<?php if ($page == 'personal') echo ' class="isactive"'; ?>><a href="<?php echo get_link($panther_url['profile_personal'], array($id)) ?>"><?php echo $lang_profile['Section personal'] ?></a></li>
					<li<?php if ($page == 'messaging') echo ' class="isactive"'; ?>><a href="<?php echo get_link($panther_url['profile_messaging'], array($id)) ?>"><?php echo $lang_profile['Section messaging'] ?></a></li>
<?php if ($panther_config['o_avatars'] == '1' || $panther_config['o_signatures'] == '1'): ?>					<li<?php if ($page == 'personality') echo ' class="isactive"'; ?>><a href="<?php echo get_link($panther_url['profile_personality'], array($id)) ?>"><?php echo $lang_profile['Section personality'] ?></a></li>
<?php endif; ?>					<li<?php if ($page == 'display') echo ' class="isactive"'; ?>><a href="<?php echo get_link($panther_url['profile_display'], array($id)) ?>"><?php echo $lang_profile['Section display'] ?></a></li>
					<li<?php if ($page == 'privacy') echo ' class="isactive"'; ?>><a href="<?php echo get_link($panther_url['profile_privacy'], array($id)) ?>"><?php echo $lang_profile['Section privacy'] ?></a></li>
<?php if ($panther_user['g_id'] == PANTHER_ADMIN || ($panther_user['g_moderator'] == '1' && $panther_user['g_mod_ban_users'] == '1')): ?>					<li<?php if ($page == 'admin') echo ' class="isactive"'; ?>><a href="<?php echo get_link($panther_url['profile_admin'], array($id)) ?>"><?php echo $lang_profile['Section admin'] ?></a></li>
<?php endif; ?>				</ul>
			</div>
		</div>
	</div>
<?php
}

//
// Outputs markup to display a user's avatar
//
function generate_avatar_markup($user_id, $size = array())
{
	global $panther_config;
	static $user_avatar_cache = array();

	if (!isset($user_avatar_cache[$user_id]))
	{
		$filetypes = array('jpg', 'gif', 'png');
		foreach ($filetypes as $cur_type)
		{
			$path = $panther_config['o_avatars_dir'].'/'.$user_id.'.'.$cur_type;
			if (file_exists(PANTHER_ROOT.$path) && $img_size = getimagesize(PANTHER_ROOT.$path))
			{
				$size = (count($size) == 2 ? 'width="'.$size[0].'" height="'.$size[1].'"' : $img_size[3]);
				$user_avatar_cache[$user_id] = '<img src="'.panther_htmlspecialchars(get_base_url(true).'/'.$path.'?m='.filemtime(PANTHER_ROOT.$path)).'" '.$size.' alt="" />';
				break;
			}
		}

		// If there's no avatar set, we mustn't have one uploaded. Set the default!
		if (!isset($user_avatar_cache[$user_id]))
		{
			$path = $panther_config['o_avatars_dir'].'/1.jpg';
			$img_size = getimagesize(PANTHER_ROOT.$path);
			$size = (count($size) == 2 ? 'width="'.$size[0].'" height="'.$size[1].'"' : $img_size[3]);
			$user_avatar_cache[$user_id] = '<img src="'.panther_htmlspecialchars(get_base_url(true).'/'.$path).'?m='.filemtime(PANTHER_ROOT.$path).'" '.$size.' alt="" />';
		}
	}

	return $user_avatar_cache[$user_id];
}

//
// Generate browser's title
//
function generate_page_title($page_title, $p = null)
{
	global $lang_common;

	if (!is_array($page_title))
		$page_title = array($page_title);

	$page_title = array_reverse($page_title);

	if ($p > 1)
		$page_title[0] .= ' ('.sprintf($lang_common['Page'], forum_number_format($p)).')';

	$crumbs = implode($lang_common['Title separator'], $page_title);

	return $crumbs;
}

//
// Save array of tracked topics in cookie
//
function set_tracked_topics($tracked_topics)
{
	global $panther_config;

	$cookie_data = '';
	if (!empty($tracked_topics))
	{
		// Sort the arrays (latest read first)
		arsort($tracked_topics['topics'], SORT_NUMERIC);
		arsort($tracked_topics['forums'], SORT_NUMERIC);

		// Homebrew serialization (to avoid having to run unserialize() on cookie data)
		foreach ($tracked_topics['topics'] as $id => $timestamp)
			$cookie_data .= 't'.$id.'='.$timestamp.';';
		foreach ($tracked_topics['forums'] as $id => $timestamp)
			$cookie_data .= 'f'.$id.'='.$timestamp.';';

		// Enforce a byte size limit (4096 minus some space for the cookie name - defaults to 4048)
		if (strlen($cookie_data) > FORUM_MAX_COOKIE_SIZE)
		{
			$cookie_data = substr($cookie_data, 0, FORUM_MAX_COOKIE_SIZE);
			$cookie_data = substr($cookie_data, 0, strrpos($cookie_data, ';')).';';
		}
	}

	forum_setcookie($panther_config['o_cookie_name'].'_track', $cookie_data, time() + $panther_config['o_timeout_visit']);
	$_COOKIE[$panther_config['o_cookie_name'].'_track'] = $cookie_data; // Set it directly in $_COOKIE as well
}

//
// Extract array of tracked topics from cookie
//
function get_tracked_topics()
{
	global $panther_config;

	$cookie_data = isset($_COOKIE[$panther_config['o_cookie_name'].'_track']) ? $_COOKIE[$panther_config['o_cookie_name'].'_track'] : false;
	if (!$cookie_data)
		return array('topics' => array(), 'forums' => array());

	if (strlen($cookie_data) > FORUM_MAX_COOKIE_SIZE)
		return array('topics' => array(), 'forums' => array());

	// Unserialize data from cookie
	$tracked_topics = array('topics' => array(), 'forums' => array());
	$temp = explode(';', $cookie_data);
	foreach ($temp as $t)
	{
		$type = substr($t, 0, 1) == 'f' ? 'forums' : 'topics';
		$id = intval(substr($t, 1));
		$timestamp = intval(substr($t, strpos($t, '=') + 1));
		if ($id > 0 && $timestamp > 0)
			$tracked_topics[$type][$id] = $timestamp;
	}

	return $tracked_topics;
}

//
// Shortcut method for executing all callbacks registered with the addon manager for the given hook
//
function flux_hook($name)
{
	global $flux_addons;

	$flux_addons->hook($name);
}

//
// Update posts, topics, last_post, last_post_id and last_poster for a forum
//
function update_forum($forum_id)
{
	global $db;

	$result = $db->query('SELECT COUNT(id), SUM(num_replies) FROM '.$db->prefix.'topics WHERE forum_id='.$forum_id) or error('Unable to fetch forum topic count', __FILE__, __LINE__, $db->error());
	list($num_topics, $num_posts) = $db->fetch_row($result);

	$num_posts = $num_posts + $num_topics; // $num_posts is only the sum of all replies (we have to add the topic posts)

	$result = $db->query('SELECT last_post, last_post_id, last_poster FROM '.$db->prefix.'topics WHERE forum_id='.$forum_id.' AND moved_to IS NULL ORDER BY last_post DESC LIMIT 1') or error('Unable to fetch last_post/last_post_id/last_poster', __FILE__, __LINE__, $db->error());
	if ($db->num_rows($result)) // There are topics in the forum
	{
		list($last_post, $last_post_id, $last_poster) = $db->fetch_row($result);

		$db->query('UPDATE '.$db->prefix.'forums SET num_topics='.$num_topics.', num_posts='.$num_posts.', last_post='.$last_post.', last_post_id='.$last_post_id.', last_poster=\''.$db->escape($last_poster).'\' WHERE id='.$forum_id) or error('Unable to update last_post/last_post_id/last_poster', __FILE__, __LINE__, $db->error());
	}
	else // There are no topics
		$db->query('UPDATE '.$db->prefix.'forums SET num_topics='.$num_topics.', num_posts='.$num_posts.', last_post=NULL, last_post_id=NULL, last_poster=NULL WHERE id='.$forum_id) or error('Unable to update last_post/last_post_id/last_poster', __FILE__, __LINE__, $db->error());
}

//
// Deletes any avatars owned by the specified user ID
//
function delete_avatar($user_id)
{
	global $panther_config;

	$filetypes = array('jpg', 'gif', 'png');

	// Delete user avatar
	foreach ($filetypes as $cur_type)
	{
		if (file_exists(PANTHER_ROOT.$panther_config['o_avatars_dir'].'/'.$user_id.'.'.$cur_type))
			@unlink(PANTHER_ROOT.$panther_config['o_avatars_dir'].'/'.$user_id.'.'.$cur_type);
	}
}

//
// Delete a topic and all of its posts
//
function delete_topic($topic_id)
{
	global $db;

	// Delete the topic and any redirect topics
	attach_delete_thread($topic_id);
	$db->query('DELETE FROM '.$db->prefix.'topics WHERE id='.$topic_id.' OR moved_to='.$topic_id) or error('Unable to delete topic', __FILE__, __LINE__, $db->error());

	// Create a list of the post IDs in this topic
	$post_ids = '';
	$result = $db->query('SELECT id FROM '.$db->prefix.'posts WHERE topic_id='.$topic_id) or error('Unable to fetch posts', __FILE__, __LINE__, $db->error());
	while ($row = $db->fetch_row($result))
		$post_ids .= ($post_ids != '') ? ','.$row[0] : $row[0];

	// Make sure we have a list of post IDs
	if ($post_ids != '')
	{
		strip_search_index($post_ids);

		// Delete posts in topic
		$db->query('DELETE FROM '.$db->prefix.'posts WHERE topic_id='.$topic_id) or error('Unable to delete posts', __FILE__, __LINE__, $db->error());
	}

	// Delete any subscriptions for this topic
	$db->query('DELETE FROM '.$db->prefix.'topic_subscriptions WHERE topic_id='.$topic_id) or error('Unable to delete subscriptions', __FILE__, __LINE__, $db->error());
}

//
// Delete a single post
//
function delete_post($post_id, $topic_id)
{
	global $db;

	$result = $db->query('SELECT id, poster, posted FROM '.$db->prefix.'posts WHERE topic_id='.$topic_id.' AND approved=1 ORDER BY id DESC LIMIT 2') or error('Unable to fetch post info', __FILE__, __LINE__, $db->error());
	list($last_id, ,) = $db->fetch_row($result);
	list($second_last_id, $second_poster, $second_posted) = $db->fetch_row($result);

	// Delete the post
	attach_delete_post($post_id);
	$db->query('DELETE FROM '.$db->prefix.'posts WHERE id='.$post_id) or error('Unable to delete post', __FILE__, __LINE__, $db->error());

	strip_search_index($post_id);

	// Count number of replies in the topic
	$result = $db->query('SELECT COUNT(id) FROM '.$db->prefix.'posts WHERE topic_id='.$topic_id.' AND approved=1') or error('Unable to fetch post count for topic', __FILE__, __LINE__, $db->error());
	$num_replies = $db->result($result, 0) - 1;

	// If the message we deleted is the most recent in the topic (at the end of the topic)
	if ($last_id == $post_id)
	{
		// If there is a $second_last_id there is more than 1 reply to the topic
		if (!empty($second_last_id))
			$db->query('UPDATE '.$db->prefix.'topics SET last_post='.$second_posted.', last_post_id='.$second_last_id.', last_poster=\''.$db->escape($second_poster).'\', num_replies='.$num_replies.' WHERE id='.$topic_id) or error('Unable to update topic', __FILE__, __LINE__, $db->error());
		else
			// We deleted the only reply, so now last_post/last_post_id/last_poster is posted/id/poster from the topic itself
			$db->query('UPDATE '.$db->prefix.'topics SET last_post=posted, last_post_id=id, last_poster=poster, num_replies='.$num_replies.' WHERE id='.$topic_id) or error('Unable to update topic', __FILE__, __LINE__, $db->error());
	}
	else
		// Otherwise we just decrement the reply counter
		$db->query('UPDATE '.$db->prefix.'topics SET num_replies='.$num_replies.' WHERE id='.$topic_id) or error('Unable to update topic', __FILE__, __LINE__, $db->error());
}

//
// Delete every .php file in the forum's cache directory
//
function forum_clear_cache()
{
	$d = dir(FORUM_CACHE_DIR);
	while (($entry = $d->read()) !== false)
	{
		if (substr($entry, -4) == '.php')
			@unlink(FORUM_CACHE_DIR.$entry);
	}
	$d->close();
}

//
// Replace censored words in $text
//
function censor_words($text)
{
	global $db;
	static $search_for, $replace_with;

	// If not already built in a previous call, build an array of censor words and their replacement text
	if (!isset($search_for))
	{
		if (file_exists(FORUM_CACHE_DIR.'cache_censoring.php'))
			include FORUM_CACHE_DIR.'cache_censoring.php';

		if (!defined('PANTHER_CENSOR_LOADED'))
		{
			if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
				require PANTHER_ROOT.'include/cache.php';

			generate_censoring_cache();
			require FORUM_CACHE_DIR.'cache_censoring.php';
		}
	}

	if (!empty($search_for))
		$text = substr(ucp_preg_replace($search_for, $replace_with, ' '.$text.' '), 1, -1);

	return $text;
}

//
// Determines the correct title for $user
// $user must contain the elements 'username', 'title', 'posts', 'g_id' and 'g_user_title'
//
function get_title($user)
{
	global $panther_bans, $lang_common, $panther_config;
	static $ban_list, $panther_ranks;

	// If not already built in a previous call, build an array of lowercase banned usernames
	if (empty($ban_list))
	{
		$ban_list = array();

		foreach ($panther_bans as $cur_ban)
			$ban_list[] = utf8_strtolower($cur_ban['username']);
	}

	// If not already loaded in a previous call, load the cached ranks
	if ($panther_config['o_ranks'] == '1' && !defined('PANTHER_RANKS_LOADED'))
	{
		if (file_exists(FORUM_CACHE_DIR.'cache_ranks.php'))
			include FORUM_CACHE_DIR.'cache_ranks.php';

		if (!defined('PANTHER_RANKS_LOADED'))
		{
			if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
				require PANTHER_ROOT.'include/cache.php';

			generate_ranks_cache();
			require FORUM_CACHE_DIR.'cache_ranks.php';
		}
	}
	// If the user has a custom title
	if ($user['title'] != '')
		$user_title = panther_htmlspecialchars($user['title']);
	// If the user is banned
	else if (in_array(utf8_strtolower($user['username']), $ban_list))
		$user_title = $lang_common['Banned'];
	// If the user group has a default user title
	else if ($user['g_user_title'] != '')
		$user_title = panther_htmlspecialchars($user['g_user_title']);
	// If the user is a guest
	else if ($user['g_id'] == PANTHER_GUEST)
		$user_title = $lang_common['Guest'];
	// If nothing else helps, we assign the default
	else
	{
		// Are there any ranks?
		if ($panther_config['o_ranks'] == '1' && !empty($panther_ranks))
		{
			foreach ($panther_ranks as $cur_rank)
			{
				if ($user['num_posts'] >= $cur_rank['min_posts'])
					$user_title = panther_htmlspecialchars($cur_rank['rank']);
			}
		}

		// If the user didn't "reach" any rank (or if ranks are disabled), we assign the default
		if (!isset($user_title))
		  $user_title = $lang_common['Member'];
	}

	return $user_title;
}

//
// Generate a string with numbered links (for multipage scripts)
//
function paginate($num_pages, $cur_page, $link, $args = null)
{
	global $lang_common, $panther_config, $panther_url;

	if ($panther_config['o_url_type'] != '1')
		$url_page = $panther_url['page'];
	else
		$url_page = '&amp;p=$1';

	$pages = array();
	$link_to_all = false;

	// If $cur_page == -1, we link to all pages (used in viewforum.php)
	if ($cur_page == -1)
	{
		$cur_page = 1;
		$link_to_all = true;
	}

	if ($num_pages <= 1)
		$pages = array('<strong class="item1">1</strong>');
	else
	{
		// Add a previous page link
		if ($num_pages > 1 && $cur_page > 1)
			$pages[] = '<a rel="prev"'.(empty($pages) ? ' class="item1"' : '').' href="'.get_sublink($link, $url_page, ($cur_page - 1), $args).'">'.$lang_common['Previous'].'</a>';

		if ($cur_page > 3)
		{
			$pages[] = '<a'.(empty($pages) ? ' class="item1"' : '').' href="'.$link.'">1</a>';

			if ($cur_page > 5)
				$pages[] = '<span class="spacer">'.$lang_common['Spacer'].'</span>';
		}

		// Don't ask me how the following works. It just does, OK? :-)
		for ($current = ($cur_page == 5) ? $cur_page - 3 : $cur_page - 2, $stop = ($cur_page + 4 == $num_pages) ? $cur_page + 4 : $cur_page + 3; $current < $stop; ++$current)
		{
			if ($current < 1 || $current > $num_pages)
				continue;
			else if ($current != $cur_page || $link_to_all)
				$pages[] = '<a'.(empty($pages) ? ' class="item1"' : '').' href="'.str_replace('#', '', get_sublink($link, $url_page, $current, $args)).'">'.forum_number_format($current).'</a>';
			else
				$pages[] = '<strong'.(empty($pages) ? ' class="item1"' : '').'>'.forum_number_format($current).'</strong>';
		}

		if ($cur_page <= ($num_pages-3))
		{
			if ($cur_page != ($num_pages-3) && $cur_page != ($num_pages-4))
				$pages[] = '<span class="spacer">'.$lang_common['Spacer'].'</span>';

			$pages[] = '<a'.(empty($pages) ? ' class="item1"' : '').' href="'.get_sublink($link, $url_page, $num_pages, $args).'">'.forum_number_format($num_pages).'</a>';
		}

		// Add a next page link
		if ($num_pages > 1 && !$link_to_all && $cur_page < $num_pages)
			$pages[] = '<a rel="next"'.(empty($pages) ? ' class="item1"' : '').' href="'.get_sublink($link, $url_page, ($cur_page + 1), $args).'">'.$lang_common['Next'].'</a>';
	}

	return implode(' ', $pages);
}


//
// Display a message
//
function message($message, $no_back_link = false, $http_status = null)
{
	global $db, $lang_common, $panther_config, $panther_start, $tpl_main, $panther_user, $panther_url;

	// Did we receive a custom header?
	if(!is_null($http_status)) {
		header('HTTP/1.1 ' . $http_status);
	}

	if (!defined('PANTHER_HEADER'))
	{
		$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_common['Info']);
		define('PANTHER_ACTIVE_PAGE', 'index');
		require PANTHER_ROOT.'header.php';
	}

?>

<div id="msg" class="block">
	<h2><span><?php echo $lang_common['Info'] ?></span></h2>
	<div class="box">
		<div class="inbox">
			<p><?php echo $message ?></p>
<?php if (!$no_back_link): ?>			<p><a href="javascript: history.go(-1)"><?php echo $lang_common['Go back'] ?></a></p>
<?php endif; ?>		</div>
	</div>
</div>
<?php

	require PANTHER_ROOT.'footer.php';
}


//
// Format a time string according to $time_format and time zones
//
function format_time($timestamp, $date_only = false, $date_format = null, $time_format = null, $time_only = false, $no_text = false)
{
	global $lang_common, $panther_user, $forum_date_formats, $forum_time_formats;

	if ($timestamp == '')
		return $lang_common['Never'];

	$diff = ($panther_user['timezone'] + $panther_user['dst']) * 3600;
	$timestamp += $diff;
	$now = time();

	if(is_null($date_format))
		$date_format = $forum_date_formats[$panther_user['date_format']];

	if(is_null($time_format))
		$time_format = $forum_time_formats[$panther_user['time_format']];

	$date = gmdate($date_format, $timestamp);
	$today = gmdate($date_format, $now+$diff);
	$yesterday = gmdate($date_format, $now+$diff-86400);

	if(!$no_text)
	{
		if ($date == $today)
			$date = $lang_common['Today'];
		else if ($date == $yesterday)
			$date = $lang_common['Yesterday'];
	}

	if ($date_only)
		return $date;
	else if ($time_only)
		return gmdate($time_format, $timestamp);
	else
		return $date.' '.gmdate($time_format, $timestamp);
}


//
// A wrapper for PHP's number_format function
//
function forum_number_format($number, $decimals = 0)
{
	global $lang_common;

	return is_numeric($number) ? number_format($number, $decimals, $lang_common['lang_decimal_point'], $lang_common['lang_thousands_sep']) : $number;
}


//
// Generate a random key of length $len
//
function random_key($len, $readable = false, $hash = false)
{
	if (!function_exists('secure_random_bytes'))
		include PANTHER_ROOT.'include/srand.php';

	$key = secure_random_bytes($len);

	if ($hash)
		return substr(bin2hex($key), 0, $len);
	else if ($readable)
	{
		$chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';

		$result = '';
		for ($i = 0; $i < $len; ++$i)
			$result .= substr($chars, (ord($key[$i]) % strlen($chars)), 1);

		return $result;
	}

	return $key;
}

//
// Make sure that user is using a valid token
// 
function confirm_referrer($script, $error_msg = false)
{
	global $lang_common, $panther_user;

	// Yeah, pretty complex ternary =)
	$actual_hash = ((isset($_POST['csrf_token'])) ? panther_trim($_POST['csrf_token']) : (isset($_GET['csrf_token']) ? panther_trim($_GET['csrf_token']) : ''));
	$real_hash = panther_hash($script.get_remote_address().$panther_user['id']);

	if ($actual_hash != $real_hash)
		message($error_msg ? $error_msg : $lang_common['Bad referrer']);
}

//
// Generate a csrf token
//
function generate_csrf_token($script = 'nothing')
{
	global $panther_user;

	$script = ($script != 'nothing') ? $script : panther_trim(basename($_SERVER['SCRIPT_NAME']));
	return panther_hash($script.get_remote_address().$panther_user['id']);
}

//
// Validate the given redirect URL, use the fallback otherwise
//
function validate_redirect($redirect_url, $fallback_url)
{
	$referrer = parse_url(strtolower($redirect_url));

	// Make sure the host component exists
	if (!isset($referrer['host']))
		$referrer['host'] = '';

	// Remove www subdomain if it exists
	if (strpos($referrer['host'], 'www.') === 0)
		$referrer['host'] = substr($referrer['host'], 4);

	// Make sure the path component exists
	if (!isset($referrer['path']))
		$referrer['path'] = '';

	$valid = parse_url(strtolower(get_base_url()));

	// Remove www subdomain if it exists
	if (strpos($valid['host'], 'www.') === 0)
		$valid['host'] = substr($valid['host'], 4);

	// Make sure the path component exists
	if (!isset($valid['path']))
		$valid['path'] = '';

	if ($referrer['host'] == $valid['host'] && preg_match('%^'.preg_quote($valid['path'], '%').'/(.*?)\.php%i', $referrer['path']))
		return $redirect_url;
	else
		return $fallback_url;
}


//
// Generate a random password of length $len
// Compatibility wrapper for random_key
//
function random_pass($len)
{
	return random_key($len, true);
}


//
// Compute a hash of $str
//
function panther_hash($str)
{
	return hash('sha512', $str);
}


//
// Try to determine the correct remote IP-address
//
function get_remote_address()
{
	$remote_addr = $_SERVER['REMOTE_ADDR'];

	// If we are behind a reverse proxy try to find the real users IP
	if (defined('FORUM_BEHIND_REVERSE_PROXY'))
	{
		if (isset($_SERVER['HTTP_X_FORWARDED_FOR']))
		{
			// The general format of the field is:
			// X-Forwarded-For: client1, proxy1, proxy2
			// where the value is a comma+space separated list of IP addresses, the left-most being the farthest downstream client,
			// and each successive proxy that passed the request adding the IP address where it received the request from.
			$forwarded_for = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
			$forwarded_for = trim($forwarded_for[0]);

			if (@preg_match('%^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$%', $forwarded_for) || @preg_match('%^((([0-9A-Fa-f]{1,4}:){7}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){6}:[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){5}:([0-9A-Fa-f]{1,4}:)?[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){4}:([0-9A-Fa-f]{1,4}:){0,2}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){3}:([0-9A-Fa-f]{1,4}:){0,3}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){2}:([0-9A-Fa-f]{1,4}:){0,4}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){6}((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|(([0-9A-Fa-f]{1,4}:){0,5}:((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|(::([0-9A-Fa-f]{1,4}:){0,5}((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|([0-9A-Fa-f]{1,4}::([0-9A-Fa-f]{1,4}:){0,5}[0-9A-Fa-f]{1,4})|(::([0-9A-Fa-f]{1,4}:){0,6}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){1,7}:))$%', $forwarded_for))
				$remote_addr = $forwarded_for;
		}
	}

	return $remote_addr;
}

//
// Calls htmlspecialchars with a few options already set
//
function panther_htmlspecialchars($str)
{
	return htmlspecialchars($str, ENT_QUOTES, 'UTF-8');
}

//
// Calls htmlspecialchars_decode with a few options already set
//
function panther_htmlspecialchars_decode($str)
{
	if (function_exists('htmlspecialchars_decode'))
		return htmlspecialchars_decode($str, ENT_QUOTES);

	static $translations;
	if (!isset($translations))
	{
		$translations = get_html_translation_table(HTML_SPECIALCHARS, ENT_QUOTES);
		$translations['&#039;'] = '\''; // get_html_translation_table doesn't include &#039; which is what htmlspecialchars translates ' to, but apparently that is okay?! http://bugs.php.net/bug.php?id=25927
		$translations = array_flip($translations);
	}

	return strtr($str, $translations);
}

//
// A wrapper for utf8_strlen for compatibility
//
function panther_strlen($str)
{
	return utf8_strlen($str);
}

//
// Convert \r\n and \r to \n
//
function panther_linebreaks($str)
{
	return str_replace(array("\r\n", "\r"), "\n", $str);
}

//
// A wrapper for utf8_trim for compatibility
//
function panther_trim($str, $charlist = false)
{
	return is_string($str) ? utf8_trim($str, $charlist) : '';
}

//
// Checks if a string is in all uppercase
//
function is_all_uppercase($string)
{
	return utf8_strtoupper($string) == $string && utf8_strtolower($string) != $string;
}

//
// Inserts $element into $input at $offset
// $offset can be either a numerical offset to insert at (eg: 0 inserts at the beginning of the array)
// or a string, which is the key that the new element should be inserted before
// $key is optional: it's used when inserting a new key/value pair into an associative array
//
function array_insert(&$input, $offset, $element, $key = null)
{
	if (is_null($key))
		$key = $offset;

	// Determine the proper offset if we're using a string
	if (!is_int($offset))
		$offset = array_search($offset, array_keys($input), true);

	// Out of bounds checks
	if ($offset > count($input))
		$offset = count($input);
	else if ($offset < 0)
		$offset = 0;

	$input = array_merge(array_slice($input, 0, $offset), array($key => $element), array_slice($input, $offset));
}

//
// Display a message when board is in maintenance mode
//
function maintenance_message()
{
	global $db, $panther_config, $lang_common, $panther_user;

	// Send no-cache headers
	header('Expires: Thu, 21 Jul 1977 07:30:00 GMT'); // When yours truly first set eyes on this world! :)
	header('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT');
	header('Cache-Control: post-check=0, pre-check=0', false);
	header('Pragma: no-cache'); // For HTTP/1.0 compatibility

	// Send the Content-type header in case the web server is setup to send something else
	header('Content-type: text/html; charset=utf-8');

	// Deal with newlines, tabs and multiple spaces
	$pattern = array("\t", '  ', '  ');
	$replace = array('&#160; &#160; ', '&#160; ', ' &#160;');
	$message = str_replace($pattern, $replace, $panther_config['o_maintenance_message']);

	if (file_exists(PANTHER_ROOT.'style/'.$panther_user['style'].'/maintenance.tpl'))
	{
		$tpl_file = PANTHER_ROOT.'style/'.$panther_user['style'].'/maintenance.tpl';
		$tpl_inc_dir = PANTHER_ROOT.'style/'.$panther_user['style'].'/';
	}
	else
	{
		$tpl_file = PANTHER_ROOT.'include/template/maintenance.tpl';
		$tpl_inc_dir = PANTHER_ROOT.'include/user/';
	}

	$tpl_maint = file_get_contents($tpl_file);

	// START SUBST - <panther_include "*">
	preg_match_all('%<panther_include "([^/\\\\]*?)\.(php[45]?|inc|html?|txt)">%i', $tpl_maint, $panther_includes, PREG_SET_ORDER);

	foreach ($panther_includes as $cur_include)
	{
		ob_start();

		// Allow for overriding user includes, too.
		if (file_exists($tpl_inc_dir.$cur_include[1].'.'.$cur_include[2]))
			require $tpl_inc_dir.$cur_include[1].'.'.$cur_include[2];
		else if (file_exists(PANTHER_ROOT.'include/user/'.$cur_include[1].'.'.$cur_include[2]))
			require PANTHER_ROOT.'include/user/'.$cur_include[1].'.'.$cur_include[2];
		else
			error(sprintf($lang_common['Pun include error'], htmlspecialchars($cur_include[0]), basename($tpl_file)));

		$tpl_temp = ob_get_contents();
		$tpl_maint = str_replace($cur_include[0], $tpl_temp, $tpl_maint);
		ob_end_clean();
	}
	// END SUBST - <panther_include "*">


	// START SUBST - <panther_language>
	$tpl_maint = str_replace('<panther_language>', $lang_common['lang_identifier'], $tpl_maint);
	// END SUBST - <panther_language>


	// START SUBST - <panther_content_direction>
	$tpl_maint = str_replace('<panther_content_direction>', $lang_common['lang_direction'], $tpl_maint);
	// END SUBST - <panther_content_direction>


	// START SUBST - <panther_head>
	ob_start();

	$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_common['Maintenance']);

?>
<title><?php echo generate_page_title($page_title) ?></title>
<link rel="stylesheet" type="text/css" href="style/<?php echo $panther_user['style'].'.css' ?>" />
<?php

	$tpl_temp = trim(ob_get_contents());
	$tpl_maint = str_replace('<panther_head>', $tpl_temp, $tpl_maint);
	ob_end_clean();
	// END SUBST - <panther_head>


	// START SUBST - <panther_maint_main>
	ob_start();

?>
<div class="block">
	<h2><?php echo $lang_common['Maintenance'] ?></h2>
	<div class="box">
		<div class="inbox">
			<p><?php echo $message ?></p>
		</div>
	</div>
</div>
<?php
	$tpl_temp = trim(ob_get_contents());
	$tpl_maint = str_replace('<panther_maint_main>', $tpl_temp, $tpl_maint);
	ob_end_clean();
	// END SUBST - <panther_maint_main>


	// End the transaction
	$db->end_transaction();


	// Close the db connection (and free up any result data)
	$db->close();

	exit($tpl_maint);
}

//
// Display $message and redirect user to $destination_url
//
function redirect($destination_url, $message)
{
	global $db, $panther_config, $lang_common, $panther_user;

	// Prefix with base_url (unless there's already a valid URI)
	if (strpos($destination_url, 'http://') !== 0 && strpos($destination_url, 'https://') !== 0 && strpos($destination_url, '/') !== 0)
		$destination_url = get_base_url(true).'/'.$destination_url;

	// Do a little spring cleaning
	$destination_url = preg_replace('%([\r\n])|(\%0[ad])|(;\s*data\s*:)%i', '', $destination_url);

	// If the delay is 0 seconds, we might as well skip the redirect all together
	if ($panther_config['o_redirect_delay'] == '0')
	{
		$db->end_transaction();
		$db->close();

		header('Location: '.str_replace('&amp;', '&', $destination_url));
		exit;
	}

	// Send no-cache headers
	header('Expires: Thu, 21 Jul 1977 07:30:00 GMT'); // When yours truly first set eyes on this world! :)
	header('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT');
	header('Cache-Control: post-check=0, pre-check=0', false);
	header('Pragma: no-cache'); // For HTTP/1.0 compatibility

	// Send the Content-type header in case the web server is setup to send something else
	header('Content-type: text/html; charset=utf-8');

	if (file_exists(PANTHER_ROOT.'style/'.$panther_user['style'].'/redirect.tpl'))
	{
		$tpl_file = PANTHER_ROOT.'style/'.$panther_user['style'].'/redirect.tpl';
		$tpl_inc_dir = PANTHER_ROOT.'style/'.$panther_user['style'].'/';
	}
	else
	{
		$tpl_file = PANTHER_ROOT.'include/template/redirect.tpl';
		$tpl_inc_dir = PANTHER_ROOT.'include/user/';
	}

	$tpl_redir = file_get_contents($tpl_file);

	// START SUBST - <panther_include "*">
	preg_match_all('%<panther_include "([^/\\\\]*?)\.(php[45]?|inc|html?|txt)">%i', $tpl_redir, $panther_includes, PREG_SET_ORDER);

	foreach ($panther_includes as $cur_include)
	{
		ob_start();

		// Allow for overriding user includes, too.
		if (file_exists($tpl_inc_dir.$cur_include[1].'.'.$cur_include[2]))
			require $tpl_inc_dir.$cur_include[1].'.'.$cur_include[2];
		else if (file_exists(PANTHER_ROOT.'include/user/'.$cur_include[1].'.'.$cur_include[2]))
			require PANTHER_ROOT.'include/user/'.$cur_include[1].'.'.$cur_include[2];
		else
			error(sprintf($lang_common['Pun include error'], htmlspecialchars($cur_include[0]), basename($tpl_file)));

		$tpl_temp = ob_get_contents();
		$tpl_redir = str_replace($cur_include[0], $tpl_temp, $tpl_redir);
		ob_end_clean();
	}
	// END SUBST - <panther_include "*">


	// START SUBST - <panther_language>
	$tpl_redir = str_replace('<panther_language>', $lang_common['lang_identifier'], $tpl_redir);
	// END SUBST - <panther_language>


	// START SUBST - <panther_content_direction>
	$tpl_redir = str_replace('<panther_content_direction>', $lang_common['lang_direction'], $tpl_redir);
	// END SUBST - <panther_content_direction>


	// START SUBST - <panther_head>
	ob_start();

	$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_common['Redirecting']);
?>
<meta http-equiv="refresh" content="<?php echo $panther_config['o_redirect_delay'] ?>;URL=<?php echo $destination_url ?>" />
<title><?php echo generate_page_title($page_title) ?></title>
<link rel="stylesheet" type="text/css" href="<?php echo get_base_url(true); ?>/style/<?php echo $panther_user['style'].'.css' ?>" />
<?php
	$tpl_temp = trim(ob_get_contents());
	$tpl_redir = str_replace('<panther_head>', $tpl_temp, $tpl_redir);
	ob_end_clean();
	// END SUBST - <panther_head>


	// START SUBST - <panther_redir_main>
	ob_start();
?>
<div class="block">
	<h2><?php echo $lang_common['Redirecting'] ?></h2>
	<div class="box">
		<div class="inbox">
			<p><?php echo $message.'<br /><br /><a href="'.$destination_url.'">'.$lang_common['Click redirect'].'</a>' ?></p>
		</div>
	</div>
</div>
<?php
	$tpl_temp = trim(ob_get_contents());
	$tpl_redir = str_replace('<panther_redir_main>', $tpl_temp, $tpl_redir);
	ob_end_clean();
	// END SUBST - <panther_redir_main>

	// START SUBST - <panther_footer>
	ob_start();

	// End the transaction
	$db->end_transaction();

	// Display executed queries (if enabled)
	if ($panther_config['o_show_queries'] == '1')
		display_saved_queries();

	$tpl_temp = trim(ob_get_contents());
	$tpl_redir = str_replace('<panther_footer>', $tpl_temp, $tpl_redir);
	ob_end_clean();
	// END SUBST - <panther_footer>

	// Close the db connection (and free up any result data)
	$db->close();

	exit($tpl_redir);
}

//
// Display a simple error message
//
function error($message, $file = null, $line = null, $db_error = false)
{
	global $panther_config, $lang_common;

	// Set some default settings if the script failed before $panther_config could be populated
	if (empty($panther_config))
	{
		$panther_config = array(
			'o_board_title'	=> 'Panther',
			'o_gzip'		=> '0',
			'o_debug_mode'	=>	'1',
		);
	}

	// Set some default translations if the script failed before $lang_common could be populated
	if (empty($lang_common))
	{
		$lang_common = array(
			'Title separator'	=> ' / ',
			'Page'				=> 'Page %s'
		);
	}

	// Empty all output buffers and stop buffering
	while (@ob_end_clean());

	// "Restart" output buffering if we are using ob_gzhandler (since the gzip header is already sent)
	if ($panther_config['o_gzip'] && extension_loaded('zlib'))
		ob_start('ob_gzhandler');

	// Send no-cache headers
	header('Expires: Thu, 21 Jul 1977 07:30:00 GMT'); // When yours truly first set eyes on this world! :)
	header('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT');
	header('Cache-Control: post-check=0, pre-check=0', false);
	header('Pragma: no-cache'); // For HTTP/1.0 compatibility

	// Send the Content-type header in case the web server is setup to send something else
	header('Content-type: text/html; charset=utf-8');

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php $page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), 'Error') ?>
<title><?php echo generate_page_title($page_title) ?></title>
<style type="text/css">
<!--
BODY {MARGIN: 10% 20% auto 20%; font: 10px Verdana, Arial, Helvetica, sans-serif}
#errorbox {BORDER: 1px solid #B84623}
H2 {MARGIN: 0; COLOR: #FFFFFF; BACKGROUND-COLOR: #B84623; FONT-SIZE: 1.1em; PADDING: 5px 4px}
#errorbox DIV {PADDING: 6px 5px; BACKGROUND-COLOR: #F1F1F1}
-->
</style>
</head>
<body>

<div id="errorbox">
	<h2>An error was encountered</h2>
	<div>
<?php

	if ($panther_config['o_debug_mode'] == '1' && !is_null($file) && !is_null($line))
	{
		echo "\t\t".'<strong>File:</strong> '.$file.'<br />'."\n\t\t".'<strong>Line:</strong> '.$line.'<br /><br />'."\n\t\t".'<strong>Panther reported</strong>: '.$message."\n";

		if ($db_error)
		{
			echo "\t\t".'<br /><br /><strong>Database reported:</strong> '.panther_htmlspecialchars($db_error['error_msg']).(($db_error['error_no']) ? ' (Errno: '.$db_error['error_no'].')' : '')."\n";

			if ($db_error['error_sql'] != '')
				echo "\t\t".'<br /><br /><strong>Failed query:</strong> '.panther_htmlspecialchars($db_error['error_sql'])."\n";
		}
	}
	else
		echo "\t\t".'Error: <strong>'.$message.'.</strong>'."\n";

?>
	</div>
</div>

</body>
</html>
<?php

	// If a database connection was established (before this error) we close it
	if ($db_error)
		$GLOBALS['db']->close();

	exit;
}

//
// Unset any variables instantiated as a result of register_globals being enabled
//
function forum_unregister_globals()
{
	$register_globals = ini_get('register_globals');
	if ($register_globals === '' || $register_globals === '0' || strtolower($register_globals) === 'off')
		return;

	// Prevent script.php?GLOBALS[foo]=bar
	if (isset($_REQUEST['GLOBALS']) || isset($_FILES['GLOBALS']))
		exit('I\'ll have a steak sandwich and... a steak sandwich.');

	// Variables that shouldn't be unset
	$no_unset = array('GLOBALS', '_GET', '_POST', '_COOKIE', '_REQUEST', '_SERVER', '_ENV', '_FILES');

	// Remove elements in $GLOBALS that are present in any of the superglobals
	$input = array_merge($_GET, $_POST, $_COOKIE, $_SERVER, $_ENV, $_FILES, isset($_SESSION) && is_array($_SESSION) ? $_SESSION : array());
	foreach ($input as $k => $v)
	{
		if (!in_array($k, $no_unset) && isset($GLOBALS[$k]))
		{
			unset($GLOBALS[$k]);
			unset($GLOBALS[$k]); // Double unset to circumvent the zend_hash_del_key_or_index hole in PHP <4.4.3 and <5.1.4
		}
	}
}


//
// Removes any "bad" characters (characters which mess with the display of a page, are invisible, etc) from user input
//
function forum_remove_bad_characters()
{
	$_GET = remove_bad_characters($_GET);
	$_POST = remove_bad_characters($_POST);
	$_COOKIE = remove_bad_characters($_COOKIE);
	$_REQUEST = remove_bad_characters($_REQUEST);
}

//
// Removes any "bad" characters (characters which mess with the display of a page, are invisible, etc) from the given string
// See: http://kb.mozillazine.org/Network.IDN.blacklist_chars
//
function remove_bad_characters($array)
{
	static $bad_utf8_chars;

	if (!isset($bad_utf8_chars))
	{
		$bad_utf8_chars = array(
			"\xcc\xb7"		=> '',		// COMBINING SHORT SOLIDUS OVERLAY		0337	*
			"\xcc\xb8"		=> '',		// COMBINING LONG SOLIDUS OVERLAY		0338	*
			"\xe1\x85\x9F"	=> '',		// HANGUL CHOSEONG FILLER				115F	*
			"\xe1\x85\xA0"	=> '',		// HANGUL JUNGSEONG FILLER				1160	*
			"\xe2\x80\x8b"	=> '',		// ZERO WIDTH SPACE						200B	*
			"\xe2\x80\x8c"	=> '',		// ZERO WIDTH NON-JOINER				200C
			"\xe2\x80\x8d"	=> '',		// ZERO WIDTH JOINER					200D
			"\xe2\x80\x8e"	=> '',		// LEFT-TO-RIGHT MARK					200E
			"\xe2\x80\x8f"	=> '',		// RIGHT-TO-LEFT MARK					200F
			"\xe2\x80\xaa"	=> '',		// LEFT-TO-RIGHT EMBEDDING				202A
			"\xe2\x80\xab"	=> '',		// RIGHT-TO-LEFT EMBEDDING				202B
			"\xe2\x80\xac"	=> '', 		// POP DIRECTIONAL FORMATTING			202C
			"\xe2\x80\xad"	=> '',		// LEFT-TO-RIGHT OVERRIDE				202D
			"\xe2\x80\xae"	=> '',		// RIGHT-TO-LEFT OVERRIDE				202E
			"\xe2\x80\xaf"	=> '',		// NARROW NO-BREAK SPACE				202F	*
			"\xe2\x81\x9f"	=> '',		// MEDIUM MATHEMATICAL SPACE			205F	*
			"\xe2\x81\xa0"	=> '',		// WORD JOINER							2060
			"\xe3\x85\xa4"	=> '',		// HANGUL FILLER						3164	*
			"\xef\xbb\xbf"	=> '',		// ZERO WIDTH NO-BREAK SPACE			FEFF
			"\xef\xbe\xa0"	=> '',		// HALFWIDTH HANGUL FILLER				FFA0	*
			"\xef\xbf\xb9"	=> '',		// INTERLINEAR ANNOTATION ANCHOR		FFF9	*
			"\xef\xbf\xba"	=> '',		// INTERLINEAR ANNOTATION SEPARATOR		FFFA	*
			"\xef\xbf\xbb"	=> '',		// INTERLINEAR ANNOTATION TERMINATOR	FFFB	*
			"\xef\xbf\xbc"	=> '',		// OBJECT REPLACEMENT CHARACTER			FFFC	*
			"\xef\xbf\xbd"	=> '',		// REPLACEMENT CHARACTER				FFFD	*
			"\xe2\x80\x80"	=> ' ',		// EN QUAD								2000	*
			"\xe2\x80\x81"	=> ' ',		// EM QUAD								2001	*
			"\xe2\x80\x82"	=> ' ',		// EN SPACE								2002	*
			"\xe2\x80\x83"	=> ' ',		// EM SPACE								2003	*
			"\xe2\x80\x84"	=> ' ',		// THREE-PER-EM SPACE					2004	*
			"\xe2\x80\x85"	=> ' ',		// FOUR-PER-EM SPACE					2005	*
			"\xe2\x80\x86"	=> ' ',		// SIX-PER-EM SPACE						2006	*
			"\xe2\x80\x87"	=> ' ',		// FIGURE SPACE							2007	*
			"\xe2\x80\x88"	=> ' ',		// PANTHERCTUATION SPACE					2008	*
			"\xe2\x80\x89"	=> ' ',		// THIN SPACE							2009	*
			"\xe2\x80\x8a"	=> ' ',		// HAIR SPACE							200A	*
			"\xE3\x80\x80"	=> ' ',		// IDEOGRAPHIC SPACE					3000	*
		);
	}

	if (is_array($array))
		return array_map('remove_bad_characters', $array);

	// Strip out any invalid characters
	$array = utf8_bad_strip($array);

	// Remove control characters
	$array = preg_replace('%[\x00-\x08\x0b-\x0c\x0e-\x1f]%', '', $array);

	// Replace some "bad" characters
	$array = str_replace(array_keys($bad_utf8_chars), array_values($bad_utf8_chars), $array);

	return $array;
}


//
// Converts the file size in bytes to a human readable file size
//
function file_size($size)
{
	global $lang_common;

	$units = array('B', 'KiB', 'MiB', 'GiB', 'TiB', 'PiB', 'EiB');

	for ($i = 0; $size > 1024; $i++)
		$size /= 1024;

	return sprintf($lang_common['Size unit '.$units[$i]], round($size, 2));
}


//
// Fetch a list of available styles
//
function forum_list_styles()
{
	$styles = array();

	$d = dir(PANTHER_ROOT.'style');
	while (($entry = $d->read()) !== false)
	{
		if ($entry{0} == '.')
			continue;

		if (substr($entry, -4) == '.css')
			$styles[] = substr($entry, 0, -4);
	}
	$d->close();

	natcasesort($styles);

	return $styles;
}


//
// Fetch a list of available language packs
//
function forum_list_langs()
{
	$languages = array();

	$d = dir(PANTHER_ROOT.'lang');
	while (($entry = $d->read()) !== false)
	{
		if ($entry{0} == '.')
			continue;

		if (is_dir(PANTHER_ROOT.'lang/'.$entry) && file_exists(PANTHER_ROOT.'lang/'.$entry.'/common.php'))
			$languages[] = $entry;
	}
	$d->close();

	natcasesort($languages);

	return $languages;
}


//
// Generate a cache ID based on the last modification time for all stopwords files
//
function generate_stopwords_cache_id()
{
	$files = glob(PANTHER_ROOT.'lang/*/stopwords.txt');
	if ($files === false)
		return 'cache_id_error';

	$hash = array();

	foreach ($files as $file)
	{
		$hash[] = $file;
		$hash[] = filemtime($file);
	}

	return panther_hash(implode('|', $hash));
}

//
// Split text into chunks ($inside contains all text inside $start and $end, and $outside contains all text outside)
//
function split_text($text, $start, $end, $retab = true)
{
	global $panther_config;

	$result = array(0 => array(), 1 => array()); // 0 = inside, 1 = outside

	// split the text into parts
	$parts = preg_split('%'.preg_quote($start, '%').'(.*)'.preg_quote($end, '%').'%Us', $text, -1, PREG_SPLIT_DELIM_CAPTURE);
	$num_parts = count($parts);

	// preg_split results in outside parts having even indices, inside parts having odd
	for ($i = 0;$i < $num_parts;$i++)
		$result[1 - ($i % 2)][] = $parts[$i];

	if ($panther_config['o_indent_num_spaces'] != 8 && $retab)
	{
		$spaces = str_repeat(' ', $panther_config['o_indent_num_spaces']);
		$result[1] = str_replace("\t", $spaces, $result[1]);
	}

	return $result;
}

function extract_blocks($text, $start, $end, $retab = true)
{
	global $panther_config;

	$code = array();
	$start_len = strlen($start);
	$end_len = strlen($end);
	$regex = '%(?:'.preg_quote($start, '%').'|'.preg_quote($end, '%').')%';
	$matches = array();

	if (preg_match_all($regex, $text, $matches))
	{
		$counter = $offset = 0;
		$start_pos = $end_pos = false;

		foreach ($matches[0] as $match)
		{
			if ($match == $start)
			{
				if ($counter == 0)
					$start_pos = strpos($text, $start);
				$counter++;
			}
			elseif ($match == $end)
			{
				$counter--;
				if ($counter == 0)
					$end_pos = strpos($text, $end, $offset + 1);
				$offset = strpos($text, $end, $offset + 1);
			}

			if ($start_pos !== false && $end_pos !== false)
			{
				$code[] = substr($text, $start_pos + $start_len,
					$end_pos - $start_pos - $start_len);
				$text = substr_replace($text, "\1", $start_pos,
					$end_pos - $start_pos + $end_len);
				$start_pos = $end_pos = false;
				$offset = 0;
			}
		}
	}

	if ($panther_config['o_indent_num_spaces'] != 8 && $retab)
	{
		$spaces = str_repeat(' ', $panther_config['o_indent_num_spaces']);
		$text = str_replace("\t", $spaces, $text);
	}

	return array($code, $text);
}

function url_valid($url)
{
	if (strpos($url, 'www.') === 0) $url = 'http://'. $url;
	if (strpos($url, 'ftp.') === 0) $url = 'ftp://'. $url;
	if (!preg_match('/# Valid absolute URI having a non-empty, valid DNS host.
		^
		(?P<scheme>[A-Za-z][A-Za-z0-9+\-.]*):\/\/
		(?P<authority>
		  (?:(?P<userinfo>(?:[A-Za-z0-9\-._~!$&\'()*+,;=:]|%[0-9A-Fa-f]{2})*)@)?
		  (?P<host>
			(?P<IP_literal>
			  \[
			  (?:
				(?P<IPV6address>
				  (?:												 (?:[0-9A-Fa-f]{1,4}:){6}
				  |												   ::(?:[0-9A-Fa-f]{1,4}:){5}
				  | (?:							 [0-9A-Fa-f]{1,4})?::(?:[0-9A-Fa-f]{1,4}:){4}
				  | (?:(?:[0-9A-Fa-f]{1,4}:){0,1}[0-9A-Fa-f]{1,4})?::(?:[0-9A-Fa-f]{1,4}:){3}
				  | (?:(?:[0-9A-Fa-f]{1,4}:){0,2}[0-9A-Fa-f]{1,4})?::(?:[0-9A-Fa-f]{1,4}:){2}
				  | (?:(?:[0-9A-Fa-f]{1,4}:){0,3}[0-9A-Fa-f]{1,4})?::	[0-9A-Fa-f]{1,4}:
				  | (?:(?:[0-9A-Fa-f]{1,4}:){0,4}[0-9A-Fa-f]{1,4})?::
				  )
				  (?P<ls32>[0-9A-Fa-f]{1,4}:[0-9A-Fa-f]{1,4}
				  | (?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}
					   (?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)
				  )
				|	(?:(?:[0-9A-Fa-f]{1,4}:){0,5}[0-9A-Fa-f]{1,4})?::	[0-9A-Fa-f]{1,4}
				|	(?:(?:[0-9A-Fa-f]{1,4}:){0,6}[0-9A-Fa-f]{1,4})?::
				)
			  | (?P<IPvFuture>[Vv][0-9A-Fa-f]+\.[A-Za-z0-9\-._~!$&\'()*+,;=:]+)
			  )
			  \]
			)
		  | (?P<IPv4address>(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}
							   (?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?))
		  | (?P<regname>(?:[A-Za-z0-9\-._~!$&\'()*+,;=]|%[0-9A-Fa-f]{2})+)
		  )
		  (?::(?P<port>[0-9]*))?
		)
		(?P<path_abempty>(?:\/(?:[A-Za-z0-9\-._~!$&\'()*+,;=:@]|%[0-9A-Fa-f]{2})*)*)
		(?:\?(?P<query>		  (?:[A-Za-z0-9\-._~!$&\'()*+,;=:@\\/?]|%[0-9A-Fa-f]{2})*))?
		(?:\#(?P<fragment>	  (?:[A-Za-z0-9\-._~!$&\'()*+,;=:@\\/?]|%[0-9A-Fa-f]{2})*))?
		$
		/mx', $url, $m)) return FALSE;
	switch ($m['scheme'])
	{
	case 'https':
	case 'http':
		if ($m['userinfo']) return FALSE; // HTTP scheme does not allow userinfo.
		break;
	case 'ftps':
	case 'ftp':
		break;
	default:
		return FALSE;	// Unrecognised URI scheme. Default to FALSE.
	}
	// Validate host name conforms to DNS "dot-separated-parts".
	if ($m{'regname'}) // If host regname specified, check for DNS conformance.
	{
		if (!preg_match('/# HTTP DNS host name.
			^					   # Anchor to beginning of string.
			(?!.{256})			   # Overall host length is less than 256 chars.
			(?:					   # Group dot separated host part alternatives.
			  [0-9A-Za-z]\.		   # Either a single alphanum followed by dot
			|					   # or... part has more than one char (63 chars max).
			  [0-9A-Za-z]		   # Part first char is alphanum (no dash).
			  [\-0-9A-Za-z]{0,61}  # Internal chars are alphanum plus dash.
			  [0-9A-Za-z]		   # Part last char is alphanum (no dash).
			  \.				   # Each part followed by literal dot.
			)*					   # One or more parts before top level domain.
			(?:					   # Top level domains
			  [A-Za-z]{2,63}|	   # Country codes are exactly two alpha chars.
			  xn--[0-9A-Za-z]{4,59})		   # Internationalized Domain Name (IDN)
			$					   # Anchor to end of string.
			/ix', $m['host'])) return FALSE;
	}
	$m['url'] = $url;
	for ($i = 0; isset($m[$i]); ++$i) unset($m[$i]);
	return $m; // return TRUE == array of useful named $matches plus the valid $url.
}

//
// Replace string matching regular expression
//
// This function takes care of possibly disabled unicode properties in PCRE builds
//
function ucp_preg_replace($pattern, $replace, $subject, $callback = false)
{
	if($callback) 
		$replaced = preg_replace_callback($pattern, create_function('$matches', 'return '.$replace.';'), $subject);
	else
		$replaced = preg_replace($pattern, $replace, $subject);

	// If preg_replace() returns false, this probably means unicode support is not built-in, so we need to modify the pattern a little
	if ($replaced === false)
	{
		if (is_array($pattern))
		{
			foreach ($pattern as $cur_key => $cur_pattern)
				$pattern[$cur_key] = str_replace('\p{L}\p{N}', '\w', $cur_pattern);

			$replaced = preg_replace($pattern, $replace, $subject);
		}
		else
			$replaced = preg_replace(str_replace('\p{L}\p{N}', '\w', $pattern), $replace, $subject);
	}

	return $replaced;
}

//
// A wrapper for ucp_preg_replace
//
function ucp_preg_replace_callback($pattern, $replace, $subject)
{
	return ucp_preg_replace($pattern, $replace, $subject, true);
}

//
// Replace four-byte characters with a question mark
//
// As MySQL cannot properly handle four-byte characters with the default utf-8
// charset up until version 5.5.3 (where a special charset has to be used), they
// need to be replaced, by question marks in this case.
//
function strip_bad_multibyte_chars($str)
{
	$result = '';
	$length = strlen($str);

	for ($i = 0; $i < $length; $i++)
	{
		// Replace four-byte characters (11110www 10zzzzzz 10yyyyyy 10xxxxxx)
		$ord = ord($str[$i]);
		if ($ord >= 240 && $ord <= 244)
		{
			$result .= '?';
			$i += 3;
		}
		else
		{
			$result .= $str[$i];
		}
	}

	return $result;
}

//
// Check whether a file/folder is writable.
//
// This function also works on Windows Server where ACLs seem to be ignored.
//
function forum_is_writable($path)
{
	if (is_dir($path))
	{
		$path = rtrim($path, '/').'/';
		return forum_is_writable($path.uniqid(mt_rand()).'.tmp');
	}

	// Check temporary file for read/write capabilities
	$rm = file_exists($path);
	$f = @fopen($path, 'a');

	if ($f === false)
		return false;

	fclose($f);

	if (!$rm)
		@unlink($path);

	return true;
}


// DEBUG FUNCTIONS BELOW

//
// Display executed queries (if enabled)
//
function display_saved_queries()
{
	global $db, $lang_common;

	// Get the queries so that we can print them out
	$saved_queries = $db->get_saved_queries();

?>
<div id="debug" class="blocktable">
	<h2><span><?php echo $lang_common['Debug table'] ?></span></h2>
	<div class="box">
		<div class="inbox">
			<table>
			<thead>
				<tr>
					<th class="tcl" scope="col"><?php echo $lang_common['Query times'] ?></th>
					<th class="tcr" scope="col"><?php echo $lang_common['Query'] ?></th>
				</tr>
			</thead>
			<tbody>
<?php
	$query_time_total = 0.0;
	foreach ($saved_queries as $cur_query)
	{
		$query_time_total += $cur_query[1];
?>
				<tr>
					<td class="tcl"><?php echo ($cur_query[1] != 0) ? $cur_query[1] : '&#160;' ?></td>
					<td class="tcr"><?php echo panther_htmlspecialchars($cur_query[0]) ?></td>
				</tr>
<?php
	}
?>
				<tr>
					<td class="tcl" colspan="2"><?php printf($lang_common['Total query time'], $query_time_total.' s') ?></td>
				</tr>
			</tbody>
			</table>
		</div>
	</div>
</div>
<?php
}

//
// Dump contents of variable(s)
//
function dump()
{
	echo '<pre>';

	$num_args = func_num_args();

	for ($i = 0; $i < $num_args; ++$i)
	{
		print_r(func_get_arg($i));
		echo "\n\n";
	}

	echo '</pre>';
	exit;
}

function check_queue($form_username, $attempt, $db)
{
	$result = $db->query('SELECT id FROM '.$db->prefix.'login_queue WHERE last_checked > NOW() - INTERVAL '.(TIMEOUT * 1000).' MICROSECOND AND username = \''.$db->escape($form_username).'\' ORDER BY id ASC LIMIT 1') or error('Unable to get login attempt data', __FILE__, __LINE__, $db->error()); 
	$id = $db->result($result);

	$db->query('UPDATE '.$db->prefix.'login_queue SET last_checked = CURRENT_TIMESTAMP WHERE id = '.$attempt.' LIMIT 1') or error('Unable to update queue', __FILE__, __LINE__, $db->error()); 
	return ($id == $attempt) ? true : false;
}

function isbot($ua)
{
	if ('' == panther_trim($ua)) return false;

	$ual = strtolower($ua);
	if (strstr($ual, 'bot') || strstr($ual, 'spider') || strstr($ual, 'crawler')) return true;

	if (strstr($ua, 'Mozilla/'))
	{
		if (strstr($ua, 'Gecko')) return false;
		if (strstr($ua, '(compatible; MSIE ') && strstr($ua, 'Windows')) return false;
	}
	else if (strstr($ua, 'Opera/'))
	{
		if (strstr($ua, 'Presto/')) return false;
	}

	return true;
}

function isbotex($ra)
{
	$ua = getenv('HTTP_USER_AGENT');

	if (!isbot($ua)) return $ra;

	$pat = array(
		'%(https?://|www\.).*%i',
		'%.*compatible[^\s]*%i',
		'%[\w\.-]+@[\w\.-]+.*%',
		'%.*?([^\s]+(bot|spider|crawler)[^\s]*).*%i',
		'%(?<=[\s_-])(bot|spider|crawler).*%i',
		'%(Mozilla|Gecko|Firefox|AppleWebKit)[^\s]*%i',
//		'%(MSIE|Windows|\.NET|Linux)[^;]+%i',
//		'%[^\s]*\.(com|html)[^\s]*%i',
		'%\/[v\d]+.*%',
		'%[^0-9a-z\.]+%i'
	);
	$rep = array(
		' ',
		' ',
		' ',
		'$1',
		' ',
		' ',
//		' ',
//		' ',
		' ',
		' '
	);
	$ua = panther_trim(preg_replace($pat, $rep, $ua));

	if (empty($ua)) return $ra.'[Bot]Unknown';

	$a = explode(' ', $ua);
	$ua = $a[0];
	if (strlen($ua) < 20 && !empty($a[1])) $ua.= ' '.$a[1];
	if (strlen($ua) > 25) $ua = 'Unknown';

	return $ra.'[Bot]'.$ua;
}

function generate_user_location($url)
{
	global $db, $panther_user, $lang_online, $perms, $panther_url;

	if (!defined('PANTHER_FP_LOADED'))
	{
		$perms = array();
		if (file_exists(FORUM_CACHE_DIR.'cache_perms.php'))
			require FORUM_CACHE_DIR.'cache_perms.php';
		else
		{
			if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
				require PANTHER_ROOT.'include/cache.php';

			generate_perms_cache();
			require FORUM_CACHE_DIR.'cache_perms.php';
		}
	}

	switch ($url)
	{
		case null:
			$location = $lang_online['bot'];
		break;
		case 'index.php':
			$location = $lang_online['viewing index'];
		break;
		case stristr($url, 'userlist.php'):	
			$location = $lang_online['viewing userlist'];
		break;
		case 'online.php':
			$location = $lang_online['viewing online'];
		break;
		case 'misc.php?action=rules':
			$location = $lang_online['viewing rules'];
		break;
		case stristr($url, 'search'):
			$location = $lang_online['searching'];
		break;
		case stristr($url, 'help'):	
			$location = $lang_online['bbcode help'];
		break;
		case stristr($url, 'profile'):
			$id = intval(filter_var($url, FILTER_SANITIZE_NUMBER_INT)); // FILTER VAR can leave ' in the URL, so we have to be extra cautious and use intval on top of it
			$result = $db->query('SELECT username, group_id FROM '.$db->prefix.'users WHERE id='.$id) or error('Unable to get user location from profile', __FILE__, __LINE__, $db->error());
			$user = $db->fetch_assoc($result);

			$username = colourize_group($user['username'], $user['group_id'], $id);
			$location = sprintf($lang_online['viewing profile'], $username);
		break;
		case stristr($url, 'pms_'):
			$location = $lang_online['private messaging'];
		break;
		case stristr($url, 'admin'):
			$location = $lang_online['administration'];
		break;
		case stristr($url, 'login'):	
			$location = $lang_online['login'];
		break;
		case stristr($url, 'viewforum.php'):

			if (strpos($url, '&p=')!== false)
			{
				preg_match('~&p=(.*)~', $url, $replace);
				$url = str_replace($replace[0], '', $url);
			}
			$id = filter_var($url, FILTER_SANITIZE_NUMBER_INT);
			$result = $db->query('SELECT forum_name FROM '.$db->prefix.'forums WHERE id = \''.$db->escape($id).'\'', true) or error('Unable to get user location from viewforum', __FILE__, __LINE__, $db->error());
			$forum_name = $db->result($result);

			if (!isset($perms[$panther_user['g_id'].'_'.$id]))
				$perms[$panther_user['g_id'].'_'.$id] = $perms['_'];
			
			if ($perms[$panther_user['g_id'].'_'.$id]['read_forum'] == '1' || is_null($perms[$panther_user['g_id'].'_'.$id]['read_forum']))
			{
				$forum = '<a href="'.get_link($panther_url['forum'], array($id, url_friendly($forum_name))).'">'.panther_htmlspecialchars($forum_name).'</a>';
				$location = sprintf($lang_online['viewing forum'], $forum);
			}
			else
				$location = $lang_online['in hidden forum'];
		break;
		case stristr($url, 'viewtopic.php?pid'):
			//Now for the nasty part =)
			$pid = filter_var($url, FILTER_SANITIZE_NUMBER_INT);
		
			$result = $db->query('SELECT t.subject, t.forum_id AS fid FROM '.$db->prefix.'posts AS p INNER JOIN '.$db->prefix.'topics AS t ON p.topic_id = t.id WHERE p.id = \''.$db->escape($pid).'\'', true) or error('Unable to get user\'s current location from viewtopic.php', __FILE__, __LINE__, $db->error());
			$info = $db->fetch_assoc($result);
			
			if (!isset($perms[$panther_user['g_id'].'_'.$info['fid']]))
				$perms[$panther_user['g_id'].'_'.$info['fid']] = $perms['_'];
			
			if ($perms[$panther_user['g_id'].'_'.$info['fid']]['read_forum'] == '1' || is_null($perms[$panther_user['g_id'].'_'.$info['fid']]['read_forum']))
			{
				$topic = '<a href="'.get_link($panther_url['post'], array($pid)).'">'.panther_htmlspecialchars($info['subject']).'</a>';
				$location = sprintf($lang_online['viewing topic'], $topic);
			}
			else
				$location = $lang_online['in hidden forum'];
		break;
		case stristr($url, 'viewtopic.php?id'):	
		
			if (strpos($url, '&p=')!== false)
			{
				preg_match('~&p=(.*)~', $url, $replace);
				$url = str_replace($replace[0], '', $url);
			}
			$id = filter_var($url, FILTER_SANITIZE_NUMBER_INT);
			$result = $db->query('SELECT subject, forum_id AS fid FROM '.$db->prefix.'topics WHERE id = \''.$db->escape($id).'\'', true) or error('Unable to get user\'s current location from viewtopic.php', __FILE__, __LINE__, $db->error());
			$info = $db->fetch_assoc($result);

			if (!isset($perms[$panther_user['g_id'].'_'.$info['fid']]))
				$perms[$panther_user['g_id'].'_'.$info['fid']] = $perms['_'];
			
			if ($perms[$panther_user['g_id'].'_'.$info['fid']]['read_forum'] == '1' || is_null($perms[$panther_user['g_id'].'_'.$info['fid']]['read_forum']))
			{			
				$topic = '<a href="'.get_link($panther_url['topic'], array($id, url_friendly($info['subject']))).'">'.panther_htmlspecialchars($info['subject']).'</a>';
				$location = sprintf($lang_online['viewing topic'], $topic);
			}
			else
				$location = $lang_online['in hidden forum'];
		break;
		case stristr($url, 'post.php?action=post'):
			$location = $lang_online['posting'];
		break;
		case stristr($url, 'post.php?fid'):	
			$fid = filter_var($url, FILTER_SANITIZE_NUMBER_INT);
			$result = $db->query('SELECT forum_name FROM '.$db->prefix.'forums WHERE id = \''.$db->escape($fid).'\'', true) or error('Unable to get user\'s current location from post.php', __FILE__, __LINE__, $db->error());
			$forum_name = $db->result($result);

			if (!isset($perms[$panther_user['g_id'].'_'.$fid]))
				$perms[$panther_user['g_id'].'_'.$fid] = $perms['_'];
			
			if ($perms[$panther_user['g_id'].'_'.$fid]['read_forum'] == '1' || is_null($perms[$panther_user['g_id'].'_'.$fid]['read_forum']))
			{			
				$forum = '<a href="'.get_link($panther_url['forum'], array($fid, url_friendly($forum_name))).'">'.panther_htmlspecialchars($forum_name).'</a>';
				$location = sprintf($lang_online['posting topic'], $forum);
			}
			else
				$location = $lang_online['in hidden forum'];
		break;
		case stristr($url, 'post.php?tid'):
	
			$tid = filter_var($url, FILTER_SANITIZE_NUMBER_INT);
			$result = $db->query('SELECT subject, forum_id AS fid FROM '.$db->prefix.'topics WHERE id = \''.$db->escape($tid).'\'', true) or error('Unable to get user\'s current location from post.php', __FILE__, __LINE__, $db->error());
			$info = $db->fetch_assoc($result);	

			if (!isset($perms[$panther_user['g_id'].'_'.$info['fid']]))
				$perms[$panther_user['g_id'].'_'.$info['fid']] = $perms['_'];
			
			if ($perms[$panther_user['g_id'].'_'.$info['fid']]['read_forum'] == '1' || is_null($perms[$panther_user['g_id'].'_'.$info['fid']]['read_forum']))
			{			
				$topic = '<a href="'.get_link($panther_url['topic'], array($tid, url_friendly($info['subject']))).'">'.panther_htmlspecialchars($info['subject']).'</a>';
				$location = sprintf($lang_online['replying to topic'], $topic);
			}
			else
				$location = $lang_online['in hidden forum'];
		break;
		case stristr($url, 'edit.php?id'):
		
			$id = filter_var($url, FILTER_SANITIZE_NUMBER_INT);
		
			$result = $db->query('SELECT t.subject, t.forum_id AS fid FROM '.$db->prefix.'posts AS p INNER JOIN '.$db->prefix.'topics AS t ON p.topic_id = t.id WHERE p.id = \''.$db->escape($id).'\'', true) or error('Unable to get user\'s current location from post.php', __FILE__, __LINE__, $db->error());
			$info = $db->fetch_assoc($result);

			if (!isset($perms[$panther_user['g_id'].'_'.$info['fid']]))
				$perms[$panther_user['g_id'].'_'.$info['fid']] = $perms['_'];
			
			if ($perms[$panther_user['g_id'].'_'.$info['fid']]['read_forum'] == '1' || is_null($perms[$panther_user['g_id'].'_'.$info['fid']]['read_forum']))
			{
				$topic = '<a href="'.get_link($panther_url['post'], array($id)).'">'.panther_htmlspecialchars($info['subject']).'</a>';
				$location = sprintf($lang_online['editing topic'], $topic);
			}
			else
				$location = $lang_online['in hidden forum'];
		break;
		case stristr($url, 'delete.php?id'):

			$id = filter_var($url, FILTER_SANITIZE_NUMBER_INT);
			$result = $db->query('SELECT t.subject, t.forum_id AS fid FROM '.$db->prefix.'posts AS p INNER JOIN '.$db->prefix.'topics AS t ON p.topic_id = t.id WHERE p.id = \''.$db->escape($id).'\'', true) or error('Unable to get user\'s current location from delete.php', __FILE__, __LINE__, $db->error());
			$info = $db->fetch_assoc($result);

			if (!isset($perms[$panther_user['g_id'].'_'.$info['fid']]))
				$perms[$panther_user['g_id'].'_'.$info['fid']] = $perms['_'];
			
			if ($perms[$panther_user['g_id'].'_'.$info['fid']]['read_forum'] == '1' || is_null($perms[$panther_user['g_id'].'_'.$info['fid']]['read_forum']))
			{
				$post = '<a href="'.get_link($panther_url['post'], array($id)).'">'.panther_htmlspecialchars($info['subject']).'</a>'; 
				$location = sprintf($lang_online['deleting post'], $post);
			}
			else
				$location = $lang_online['in hidden forum'];
		break;
		case stristr($url, 'moderate.php'):
			$location = $lang_online['moderating'];
		break;
		case stristr($url, 'register.php'):	
			$location = $lang_online['register'];
		break;
		case stristr($url, 'misc.php?action=leaders'):
			$location = $lang_online['viewing team'];
		break;
		case '-':
			$location = $lang_online['not online'];
		break;
		default:
			$location = $url;
		break;
	}
	return $location;
}

function format_time_difference($logged, $lang_online)
{ 
	$difference = time() - $logged;
	$intervals = array('minute'=> 60); 
	if ($difference < 60)
	{
		if ($difference == '1')
			$difference = sprintf($lang_online['second ago'], $difference);
		else
			$difference = sprintf($lang_online['seconds ago'], $difference);
	}        

	if ($difference >= 60)
	{
		$difference = floor($difference/$intervals['minute']);
		if ($difference == '1')
			$difference = sprintf($lang_online['minute ago'], $difference);
		else
			$difference = sprintf($lang_online['minutes ago'], $difference);
	}  
	return $difference;
}

function colourize_group($username, $gid, $user_id = 1, $htmlencode = true)
{
	global $panther_user, $panther_url;
	static $colourize_cache = array();

	if (!array_key_exists($username, $colourize_cache))
	{
		if ($htmlencode)
			$name = panther_htmlspecialchars($username);
		else
			$name = $username; // A bit pointless, but we need to get the original variable later for either true or false. This may be re-thought later.
	
		$name = '<span class="gid'.$gid.'">'.$name.'</span>';
	
		if ($panther_user['g_view_users'] == 1 && $user_id > 1)
			$colourize_cache[$username] = '<a href="'.get_link($panther_url['profile'], array($user_id, url_friendly($username))).'">'.$name.'</a>';
		else
			$colourize_cache[$username] = $name;
	}

	return $colourize_cache[$username];
}

function attach_delete_thread($id = 0)
{
	global $db, $panther_config;

	// Should we orhpan any attachments
	if ($panther_config['o_create_orphans'] == 0)
	{
		$result = $db->query('SELECT a.id FROM '.$db->prefix.'attachments AS a LEFT JOIN '.$db->prefix.'posts AS p ON a.post_id=p.id WHERE p.topic_id='.$id) or error('Unable to select attachments from topic',__FILE__,__LINE__);
		if ($db->num_rows($result))
		{
			while ($attach_id = $db->result($result))
			{
				if (!delete_attachment($attach_id))
					continue;
			}
		}
	}
}


function attach_delete_post($id = 0)
{
	global $db;

	$result = $db->query('SELECT a.id FROM '.$db->prefix.'attachments AS a WHERE a.post_id='.$id) or error('Unable to get attachments for post',__FILE__,__LINE__);
	if ($db->num_rows($result))
	{
		while ($attach_id = $db->result($result))
		{
				if (!delete_attachment($attach_id))
					continue;
		}
	}
}

function delete_attachment($item = 0)
{
	global $db, $panther_user, $panther_config;
	
	// Make sure the item actually exists
	$can_delete = false;
	$result = $db->query('SELECT a.owner, a.location FROM '.$db->prefix.'attachments AS a LEFT JOIN '.$db->prefix.'posts AS p ON a.post_id=p.id LEFT JOIN '.$db->prefix.'topics AS t ON p.topic_id=t.id LEFT JOIN '.$db->prefix.'forum_perms AS fp ON t.forum_id=fp.forum_id AND fp.group_id='.$panther_user['g_id'].' WHERE a.id='.$item.' LIMIT 1')or error('Unable to fetch attachment for deletion', __FILE__, __LINE__, $db->error());
	if (!$db->num_rows($result))
		message($lang_common['Bad request']);
	else
		$attachment = $db->fetch_assoc($result);

	$db->query('DELETE FROM '.$db->prefix.'attachments WHERE id='.$item) or error('Unable to delete attachment', __FILE__, __LINE__, $db->error());
	if ($panther_config['o_create_orphans'] == '0')
		@unlink($panther_config['o_attachments_dir'].$attachment['location']);

	return true;
}

function file_upload_error_message($code) 
{
	switch ($code) 
	{ 
		case UPLOAD_ERR_INI_SIZE: 
			return 'The uploaded file exceeds the upload_max_filesize configuration setting in php.ini'; 
		case UPLOAD_ERR_FORM_SIZE: 
			return 'The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form'; 
		case UPLOAD_ERR_PARTIAL: 
			return 'The uploaded file was only partially uploaded'; 
		case UPLOAD_ERR_NO_FILE: 
			return 'No file was uploaded'; 
		case UPLOAD_ERR_NO_TMP_DIR: 
			return 'Missing a temporary folder'; 
		case UPLOAD_ERR_CANT_WRITE: 
			return 'Failed to write file to disk'; 
		case UPLOAD_ERR_EXTENSION: 
			return 'File upload stopped by extension'; 
		default: 
			return 'An unknown upload error was encountered'; 
	} 
}

function create_attachment($name = '', $mime = '', $size = 0, $tmp_name = '', $post_id = 0, $message = 0)
{
		global $db, $panther_user, $panther_config;

		$unique_name = attach_generate_filename($panther_config['o_attachments_dir'], $message, $size);
		if (!move_uploaded_file($tmp_name, $panther_config['o_attachments_dir'].$unique_name))
			error('Unable to move file from: '.$tmp_name.' to '.$panther_config['o_attachments_dir'].$unique_name.'', __FILE__, __LINE__);

		if (strlen($mime) < 1)
			$mime = attach_create_mime(attach_find_extention($name));
		
		$result = $db->query('INSERT INTO '.$db->prefix.'attachments (owner, post_id, filename, extension, mime, location, size) VALUES ('.$panther_user['id'].', '.$post_id.', \''.$db->escape($name).'\', \''.$db->escape(attach_get_extension($name)).'\', \''.$db->escape($mime).'\', \''.$db->escape($unique_name).'\', '.$size.')') or error('Unable to add attachment',__FILE__,__LINE__,$db->error());
		return true;
}

function attach_generate_filename($storagepath, $messagelength = 0, $size = 0)
{
	$not_unique = true;
	while ($not_unique)
	{
		$newfile = md5(attach_generate_pathname().$messagelength.$size.'Some more salt keyworbs, change if you want to').'.attach';
		if (!is_file($storagepath.$newfile))
			return $newfile;
	}	
}

function attach_generate_pathname($storagepath = '')
{
	if(strlen($storagepath) != 0)
	{
		$not_unique = true;
		while ($not_unique)
		{
			$newdir = attach_generate_pathname();
			if(!is_dir($storagepath.$newdir))
				return $newdir;
		}
	}
	else
		return substr(md5(time().'Salt keyword, replace if you want to'), 0, 32);
}

function attach_create_mime($extension = '')
{
	// Some of these may well no longer exist.
	$mimes = array (
		'diff'			=> 		'text/x-diff',
		'patch'			=> 		'text/x-diff',
		'rtf' 			=>		'text/richtext',
		'html'			=>		'text/html',
		'htm'			=>		'text/html',
		'aiff'			=>		'audio/x-aiff',
		'iff'			=>		'audio/x-aiff',
		'basic'			=>		'audio/basic',
		'wav'			=>		'audio/wav',
		'gif'			=>		'image/gif',
		'jpg'			=>		'image/jpeg',
		'jpeg'			=>		'image/pjpeg',
		'tif'			=>		'image/tiff',
		'png'			=>		'image/x-png',
		'xbm'			=>		'image/x-xbitmap',
		'bmp'			=>		'image/bmp',
		'xjg'			=>		'image/x-jg',
		'emf'			=>		'image/x-emf',
		'wmf'			=>		'image/x-wmf',
		'avi'			=>		'video/avi',
		'mpg'			=>		'video/mpeg',
		'mpeg'			=>		'video/mpeg',
		'ps'			=>		'application/postscript',
		'b64'			=>		'application/base64',
		'macbinhex'		=>		'application/macbinhex40',
		'pdf'			=>		'application/pdf',
		'xzip'			=>		'application/x-compressed',
		'zip'			=>		'application/x-zip-compressed',
		'gzip'			=>		'application/x-gzip-compressed',
		'java'			=>		'application/java',
		'msdownload'	=>		'application/x-msdownload'
	);

	foreach ($mimes as $type => $mime)
	{
		if ($extention == $type)
			return $mime;
	}
	return 'application/octet-stream';
}

function attach_get_extension($filename = '')
{
	if (strlen($filename) < 1)
		return '';

	return strtolower(ltrim(strrchr($filename, "."), "."));
}

function check_file_extension($file_name)
{
	global $panther_config;

	$actual_extension = attach_get_extension($file_name);
	$always_deny = explode(',', $panther_config['o_always_deny']);
	foreach ($always_deny as $ext)
	{
		if ($ext == $actual_extension)
			return false;
	}
	
	return true;
}

function attach_icon($extension)
{
	global $panther_config, $panther_user;
	static $base_url, $attach_icons;

	if ($panther_user['show_img'] == 0 || $panther_config['o_attachment_icons'] == 0)
		return '';

	$base_url = (!isset($base_url)) ? get_base_url(true) : $base_url;

	if (!isset($attach_icons))
	{
		$attach_icons = array();
		$extensions = explode(',', $panther_config['o_attachment_extensions']);
		$icons = explode(',', $panther_config['o_attachment_images']);

		for($i = 0; $i < count($extensions); $i++)
			$attach_icons[$extensions[$i]] = $icons[$i];
	}

	if (array_key_exists($extension, $attach_icons))
		$icon_url = $panther_config['o_attachment_icon_dir'].$attach_icons[$extension];
	else
		$icon_url = $panther_config['o_attachment_icon_dir'].'unknown.png';

	return '<img src="'.get_base_url(true).'/'.$icon_url.'" width="15" height="15" alt="'.panther_htmlspecialchars($extension).'" />';
}

function return_bytes($val)
{
    $last = strtolower($val[strlen($val)-1]);
    switch($last)
	{
        // The 'G' modifier is available since PHP 5.1.0
        case 'g':
            $val *= 1024;
        case 'm':
            $val *= 1024;
        case 'k':
            $val *= 1024;
    }

    return $val;
}

function check_authentication()
{
	global $lang_admin_common, $db, $db_type, $panther_config, $panther_user;
	
	function send_authentication()
	{
		global $lang_admin_common;

		header('WWW-Authenticate: Basic realm="Panther Admin CP"');
		header('HTTP/1.1 401 Unauthorized');
		exit($lang_admin_common['Unauthorised']);		
	}

	if ($panther_config['o_http_authentication'] == '1')
	{
		if (!isset($_SERVER['PHP_AUTH_USER']) && !isset($_SERVER['PHP_AUTH_PW']))
			send_authentication();
		else if (isset($_SERVER['PHP_AUTH_USER']) && isset($_SERVER['PHP_AUTH_PW']))
		{
			$form_username = panther_trim($_SERVER['PHP_AUTH_USER']);
			$form_password = panther_trim($_SERVER['PHP_AUTH_PW']);

			$username_sql = ($db_type == 'mysql' || $db_type == 'mysqli' || $db_type == 'mysql_innodb' || $db_type == 'mysqli_innodb') ? 'username=\''.$db->escape($form_username).'\'' : 'LOWER(username)=LOWER(\''.$db->escape($form_username).'\')';
			$result = $db->query('SELECT password, salt FROM '.$db->prefix.'users WHERE '.$username_sql.' AND id='.$panther_user['id']) or error('Unable to query database', __FILE__, __LINE__, $db->error());
			if (!$db->num_rows($result))
				send_authentication();
			else
			{
				$cur_user = $db->fetch_assoc($result);
				if (panther_hash($form_password.$cur_user['salt']) != $cur_user['password'])
					send_authentication();
			}
		}
	}
}

// Generate link to another page on the forum
function get_link($link, $args = null)
{
	global $panther_config;

	$gen_link = $link;
	if ($args == null)
		$gen_link = $panther_config['o_base_url'].'/'.$link;
	else if (!is_array($args))
		$gen_link = $panther_config['o_base_url'].'/'.str_replace('$1', $args, $link);
	else
	{
		for ($i = 0; isset($args[$i]); ++$i)
			$gen_link = str_replace('$'.($i + 1), $args[$i], $gen_link);
		$gen_link = $panther_config['o_base_url'].'/'.$gen_link;
	}

	return $gen_link;
}

// Generate a hyperlink with parameters and anchor and a subsection such as a subpage
function get_sublink($link, $sublink, $subarg, $args = null)
{
	global $panther_config, $panther_url;

	if ($sublink == $panther_url['page'] && $subarg == 1)
		return get_link($link, $args);

	$gen_link = $link;
	if (!is_array($args) && $args != null)
		$gen_link = str_replace('$1', $args, $link);
	else
	{
		for ($i = 0; isset($args[$i]); ++$i)
			$gen_link = str_replace('$'.($i + 1), $args[$i], $gen_link);
	}

	if (isset($panther_url['insertion_find']))
		$gen_link = $panther_config['o_base_url'].'/'.str_replace($panther_url['insertion_find'], str_replace('$1', str_replace('$1', $subarg, $sublink), $panther_url['insertion_replace']), $gen_link);
	else
		$gen_link = $panther_config['o_base_url'].'/'.$gen_link.str_replace('$1', $subarg, $sublink);

	return $gen_link;
}

// Make a string safe to use in a URL
function url_friendly($str)
{
	global $panther_config, $panther_user;
	static $lang_url_replace;

	if (!isset($lang_url_replace))
		require PANTHER_ROOT.'include/url_replace.php';

	$str = strtr($str, $lang_url_replace);
	$str = strtolower(utf8_decode($str));
	$str = panther_trim(preg_replace(array('/[^a-z0-9\s]/', '/[\s]+/'), array('', '-'), $str), '-');

	return $str;
}

function version_friendly($str)
{
	$str = strtolower(utf8_decode($str));
	$str = panther_trim(preg_replace(array('/[^a-z0-9\s.]/', '/[\s]+/'), array('', '-'), $str), '-');

	return $str;
}

function download_update($is_background_process = true)
{
	global $panther_updates, $panther_config;
	
	if (!isset($panther_updates))
		$panther_updates = generate_update_cache();
	
	$file_name = 'panther-update-patch-'.version_friendly($panther_updates['version']).'.zip';
	if ($panther_config['o_download_updates'] == '1' && version_compare($panther_config['o_cur_version'], $panther_updates['version'], '<') && !file_exists(PANTHER_ROOT.'include/updates/'.$file_name))
	{
		if (is_callable('curl_init'))
		{
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, 'http://panther.strongholdnation.co.uk/get_patch.php');
			curl_setopt($ch, CURLOPT_HEADER, false);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS, array(
				'version' => $panther_updates['version'],
			));
			$result = curl_exec($ch);
			curl_close($ch);

			file_put_contents(PANTHER_ROOT.'include/updates/'.$file_name, $result);
			if (!file_exists(PANTHER_ROOT.'include/updates/'.$file_name))
			{
				if (!$is_background_process)
					exit($lang_admin_update['update failed']);
			}
		}
		else
		{
			if (!$is_background_process)
				exit($lang_admin_update['curl disabled']);
		}
	}
}