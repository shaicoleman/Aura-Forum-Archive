<?php

/**
 * Copyright (C) 2015 Panther (http://panther.strongholdnation.co.uk/)
 * based on code by Rickard Andersson copyright (C) 2002-2008 PunBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

// Make sure no one attempts to run this script "directly"
if (!defined('PANTHER'))
	exit;

// Send no-cache headers
header('Expires: Thu, 21 Jul 1977 07:30:00 GMT'); // When yours truly first set eyes on this world! :)
header('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT');
header('Cache-Control: post-check=0, pre-check=0', false);
header('Pragma: no-cache'); // For HTTP/1.0 compatibility

// Send the Content-type header in case the web server is setup to send something else
header('Content-type: text/html; charset=utf-8');

// Prevent site from being embedded in a frame
header('X-Frame-Options: deny');

// Load the template
if (defined('PANTHER_ADMIN_CONSOLE'))
	$tpl_file = 'admin.tpl';
else if (defined('PANTHER_HELP'))
	$tpl_file = 'help.tpl';
else
	$tpl_file = 'main.tpl';

if (file_exists(PANTHER_ROOT.'style/'.$panther_user['style'].'/'.$tpl_file))
{
	$tpl_file = PANTHER_ROOT.'style/'.$panther_user['style'].'/'.$tpl_file;
	$tpl_inc_dir = PANTHER_ROOT.'style/'.$panther_user['style'].'/';
}
else
{
	$tpl_file = PANTHER_ROOT.'include/template/'.$tpl_file;
	$tpl_inc_dir = PANTHER_ROOT.'include/user/';
}

$tpl_main = file_get_contents($tpl_file);

// START SUBST - <panther_include "*">
preg_match_all('%<panther_include "([^"]+)">%i', $tpl_main, $panther_includes, PREG_SET_ORDER);

foreach ($panther_includes as $cur_include)
{
	ob_start();

	$file_info = pathinfo($cur_include[1]);
	
	if (!in_array($file_info['extension'], array('php', 'php4', 'php5', 'inc', 'html', 'txt'))) // Allow some extensions
		error(sprintf($lang_common['Pun include extension'], panther_htmlspecialchars($cur_include[0]), basename($tpl_file), panther_htmlspecialchars($file_info['extension'])));
		
	if (strpos($file_info['dirname'], '..') !== false) // Don't allow directory traversal
		error(sprintf($lang_common['Pun include directory'], panther_htmlspecialchars($cur_include[0]), basename($tpl_file)));

	// Allow for overriding user includes, too.
	if (file_exists($tpl_inc_dir.$cur_include[1]))
		require $tpl_inc_dir.$cur_include[1];
	else if (file_exists(PANTHER_ROOT.'include/user/'.$cur_include[1]))
		require PANTHER_ROOT.'include/user/'.$cur_include[1];
	else
		error(sprintf($lang_common['Pun include error'], panther_htmlspecialchars($cur_include[0]), basename($tpl_file)));

	$tpl_temp = ob_get_contents();
	$tpl_main = str_replace($cur_include[0], $tpl_temp, $tpl_main);
	ob_end_clean();
}
// END SUBST - <panther_include "*">

// START SUBST - <panther_language>
$tpl_main = str_replace('<panther_language>', $lang_common['lang_identifier'], $tpl_main);
// END SUBST - <panther_language>

// START SUBST - <panther_content_direction>
$tpl_main = str_replace('<panther_content_direction>', $lang_common['lang_direction'], $tpl_main);
// END SUBST - <panther_content_direction>

// START SUBST - <panther_head>
ob_start();

// Define $p if it's not set to avoid a PHP notice
$p = isset($p) ? $p : null;

if (file_exists(PANTHER_ROOT.'img/'.$panther_config['o_favicon']))
	echo '<link rel="icon" type="image/png" href="'.get_base_url(true).'/img/'.$panther_config['o_favicon'].'" sizes="16x16">';
else
	echo '<link rel="icon" type="image/png" href="'.get_base_url(true).'/img/default.ico" sizes="16x16">';

// Is this a page that we want search index spiders to index?
if (!defined('PANTHER_ALLOW_INDEX'))
	echo '<meta name="ROBOTS" content="NOINDEX, FOLLOW" />'."\n";

?>
<title><?php echo generate_page_title($page_title, $p) ?></title>
<link rel="stylesheet" type="text/css" href="<?php echo get_base_url(true); ?>/style/<?php echo $panther_user['style'].'.css' ?>" />
<?php
if (defined('REPUTATION'))
{
	echo '<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>';
	echo '<script type="text/javascript" src="'.get_base_url(true).'/include/reputation.js"></script>';
}

if (basename($_SERVER['PHP_SELF']) == 'admin_index.php')
{
	echo '<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>';
	echo '<script type="text/javascript" src="'.get_base_url(true).'/include/admin_notes.js"></script>';
}

if (basename($_SERVER['PHP_SELF']) == 'admin_updates.php')
	echo '<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>';

if (defined('PANTHER_ADMIN_CONSOLE'))
{
	if (file_exists(PANTHER_ROOT.'style/'.$panther_user['style'].'/base_admin.css'))
		echo '<link rel="stylesheet" type="text/css" href="'.get_base_url(true).'/style/'.$panther_user['style'].'/base_admin.css" />'."\n";
	else
		echo '<link rel="stylesheet" type="text/css" href="'.get_base_url(true).'/style/imports/base_admin.css" />'."\n";
}

if (isset($required_fields))
{
	// Output JavaScript to validate form (make sure required fields are filled out)

?>
<script type="text/javascript">
/* <![CDATA[ */
function process_form(the_form)
{
	var required_fields = {
<?php
	// Output a JavaScript object with localised field names
	$tpl_temp = count($required_fields);
	foreach ($required_fields as $elem_orig => $elem_trans)
	{
		echo "\t\t\"".$elem_orig.'": "'.addslashes(str_replace('&#160;', ' ', $elem_trans));
		if (--$tpl_temp) echo "\",\n";
		else echo "\"\n\t};\n";
	}
?>
	if (document.all || document.getElementById)
	{
		for (var i = 0; i < the_form.length; ++i)
		{
			var elem = the_form.elements[i];
			if (elem.name && required_fields[elem.name] && !elem.value && elem.type && (/^(?:text(?:area)?|password|file)$/i.test(elem.type)))
			{
				alert('"' + required_fields[elem.name] + '" <?php echo $lang_common['required field'] ?>');
				elem.focus();
				return false;
			}
		}
	}
	return true;
}
/* ]]> */
</script>
<?php

}

$page_head['colorize_groups'] = '<style type="text/css">'.$panther_config['o_colourize_groups'].'</style>'; // Pre-cached to save rendering time

if (!empty($page_head))
	echo implode("\n", $page_head)."\n";

$tpl_temp = trim(ob_get_contents());
$tpl_main = str_replace('<panther_head>', $tpl_temp, $tpl_main);
ob_end_clean();
// END SUBST - <panther_head>


// START SUBST - <body>
if (isset($focus_element))
{
	$tpl_main = str_replace('<body onload="', '<body onload="document.getElementById(\''.$focus_element[0].'\').elements[\''.$focus_element[1].'\'].focus();', $tpl_main);
	$tpl_main = str_replace('<body>', '<body onload="document.getElementById(\''.$focus_element[0].'\').elements[\''.$focus_element[1].'\'].focus()">', $tpl_main);
}
// END SUBST - <body>


// START SUBST - <panther_page>
$tpl_main = str_replace('<panther_page>', panther_htmlspecialchars(basename($_SERVER['PHP_SELF'], '.php')), $tpl_main);
// END SUBST - <panther_page>


// START SUBST - <panther_title>
$tpl_main = str_replace('<panther_title>', '<h1><a href="'.get_link($panther_url['index']).'">'.panther_htmlspecialchars($panther_config['o_board_title']).'</a></h1>', $tpl_main);
// END SUBST - <panther_title>


// START SUBST - <panther_desc>
$tpl_main = str_replace('<panther_desc>', '<div id="brddesc">'.$panther_config['o_board_desc'].'</div>', $tpl_main);
// END SUBST - <panther_desc>


// START SUBST - <panther_navlinks>
$links = array();

// Index should always be displayed
$links[] = '<li id="navindex"'.((PANTHER_ACTIVE_PAGE == 'index') ? ' class="isactive"' : '').'><a href="'.get_link($panther_url['index']).'">'.$lang_common['Index'].'</a></li>';

if ($panther_user['g_read_board'] == '1' && $panther_user['g_view_users'] == '1')
	$links[] = '<li id="navuserlist"'.((PANTHER_ACTIVE_PAGE == 'userlist') ? ' class="isactive"' : '').'><a href="'.get_link($panther_url['userlist']).'">'.$lang_common['User list'].'</a></li>';

if ($panther_user['g_read_board'] == '1' && $panther_user['g_view_users'] == '1')
	$links[] = '<li id="navuserlist"'.((PANTHER_ACTIVE_PAGE == 'leaders') ? ' class="isactive"' : '').'><a href="'.get_link($panther_url['leaders']).'">'.$lang_common['Moderating Team'].'</a></li>';

if ($panther_user['g_read_board'] == '1' && $panther_user['g_view_users'] == '1' && $panther_config['o_users_online'] == '1')
	$links[] = '<li id="navonline"'.((PANTHER_ACTIVE_PAGE == 'online') ? ' class="isactive"' : '').'><a href="'.get_link($panther_url['online']).'">'.$lang_common['Online'].'</a></li>';

if ($panther_config['o_rules'] == '1' && (!$panther_user['is_guest'] || $panther_user['g_read_board'] == '1' || $panther_config['o_regs_allow'] == '1'))
	$links[] = '<li id="navrules"'.((PANTHER_ACTIVE_PAGE == 'rules') ? ' class="isactive"' : '').'><a href="'.get_link($panther_url['rules']).'">'.$lang_common['Rules'].'</a></li>';

if ($panther_user['g_read_board'] == '1' && $panther_user['g_search'] == '1')
	$links[] = '<li id="navsearch"'.((PANTHER_ACTIVE_PAGE == 'search') ? ' class="isactive"' : '').'><a href="'.get_link($panther_url['search']).'">'.$lang_common['Search'].'</a></li>';

if ($panther_user['is_guest'])
{
	$links[] = '<li id="navregister"'.((PANTHER_ACTIVE_PAGE == 'register') ? ' class="isactive"' : '').'><a href="'.get_link($panther_url['register']).'">'.$lang_common['Register'].'</a></li>';
	$links[] = '<li id="navlogin"'.((PANTHER_ACTIVE_PAGE == 'login') ? ' class="isactive"' : '').'><a href="'.get_link($panther_url['login']).'">'.$lang_common['Login'].'</a></li>';
}
else
{	// To avoid another preg replace link directly to the essentials section
	$links[] = '<li id="navprofile"'.((PANTHER_ACTIVE_PAGE == 'profile') ? ' class="isactive"' : '').'><a href="'.get_link($panther_url['profile_essentials'], array($panther_user['id'])).'">'.$lang_common['Profile'].'</a></li>';

	if ($panther_user['is_admmod'])
		$links[] = '<li id="navadmin"'.((PANTHER_ACTIVE_PAGE == 'admin') ? ' class="isactive"' : '').'><a href="'.get_link($panther_url['admin_index']).'">'.$lang_common['Admin'].'</a></li>';

	$links[] = '<li id="navlogout"><a href="'.get_link($panther_url['logout'], array($panther_user['id'], panther_hash($panther_user['id'].panther_hash(get_remote_address())))).'">'.$lang_common['Logout'].'</a></li>';
}

// Are there any additional navlinks we should insert into the array before imploding it?
if ($panther_user['g_read_board'] == '1' && $panther_config['o_additional_navlinks'] != '')
{
	if (preg_match_all('%([0-9]+)\s*=\s*(.*?)\n%s', $panther_config['o_additional_navlinks']."\n", $extra_links))
	{
		// Insert any additional links into the $links array (at the correct index)
		$num_links = count($extra_links[1]);
		for ($i = 0; $i < $num_links; ++$i)
			array_splice($links, $extra_links[1][$i], 0, array('<li id="navextra'.($i + 1).'">'.$extra_links[2][$i].'</li>'));
	}
}

$tpl_temp = '<div id="brdmenu" class="inbox">'."\n\t\t\t".'<ul>'."\n\t\t\t\t".implode("\n\t\t\t\t", $links)."\n\t\t\t".'</ul>'."\n\t\t".'</div>';
$tpl_main = str_replace('<panther_navlinks>', $tpl_temp, $tpl_main);
// END SUBST - <panther_navlinks>

// START SUBST - <panther_status>
$page_statusinfo = $page_topicsearches = array();

if ($panther_user['is_guest'])
	$page_statusinfo = '<p class="conl">'.$lang_common['Not logged in'].'</p>';
else
{
	$page_statusinfo[] = '<li><span>'.$lang_common['Logged in as'].' <strong>'.colourize_group($panther_user['username'], $panther_user['g_id'], $panther_user['id']).'</strong></span></li>';
	$page_statusinfo[] = '<li><span>'.sprintf($lang_common['Last visit'], format_time($panther_user['last_visit'])).'</span></li>';

	if ($panther_user['is_admmod'])
	{
		if ($panther_config['o_report_method'] == '0' || $panther_config['o_report_method'] == '2')
		{
			$result_header = $db->query('SELECT 1 FROM '.$db->prefix.'reports WHERE zapped IS NULL') or error('Unable to fetch reports info', __FILE__, __LINE__, $db->error());

			if ($db->result($result_header))
				$page_statusinfo[] = '<li class="reportlink"><span><strong><a href="'.get_link($panther_url['admin_reports']).'">'.$lang_common['New reports'].'</a></strong></span></li>';
		}
		
		$result_header = $db->query('SELECT 1 FROM '.$db->prefix.'posts WHERE approved=0') or error('Unable to fetch unapproved posts info', __FILE__, __LINE__, $db->error());
		if ($db->result($result_header))
			$page_statusinfo[] = '<li class="reportlink"><span><strong><a href="'.get_link($panther_url['admin_posts']).'">'.$lang_common['New unapproved posts'].'</a></strong></span></li>';

		if ($panther_config['o_maintenance'] == '1')
			$page_statusinfo[] = '<li class="maintenancelink"><span><strong><a href="'.get_link($panther_url['admin_options_direct'], array('maintenance')).'">'.$lang_common['Maintenance mode enabled'].'</a></strong></span></li>';
	}

	if ($panther_user['g_read_board'] == '1' && $panther_user['g_search'] == '1')
	{
		$page_topicsearches[] = '<a href="'.get_link($panther_url['search_replies']).'" title="'.$lang_common['Show posted topics'].'">'.$lang_common['Posted topics'].'</a>';
		$page_topicsearches[] = '<a href="'.get_link($panther_url['search_new']).'" title="'.$lang_common['Show new posts'].'">'.$lang_common['New posts header'].'</a>';
	}
}

// Quick searches
if ($panther_user['g_read_board'] == '1' && $panther_user['g_search'] == '1')
{
	$page_topicsearches[] = '<a href="'.get_link($panther_url['search_recent']).'" title="'.$lang_common['Show active topics'].'">'.$lang_common['Active topics'].'</a>';
	$page_topicsearches[] = '<a href="'.get_link($panther_url['search_unanswered']).'" title="'.$lang_common['Show unanswered topics'].'">'.$lang_common['Unanswered topics'].'</a>';
}

// Generate all that jazz
$tpl_temp = '<div id="brdwelcome" class="inbox">';

// The status information
if (is_array($page_statusinfo))
{
	$tpl_temp .= "\n\t\t\t".'<ul class="conl">';
	$tpl_temp .= "\n\t\t\t\t".implode("\n\t\t\t\t", $page_statusinfo);
	$tpl_temp .= "\n\t\t\t".'</ul>';
}
else
	$tpl_temp .= "\n\t\t\t".$page_statusinfo;

// Generate quicklinks
if (!empty($page_topicsearches))
{
	$tpl_temp .= "\n\t\t\t".'<ul class="conr">';
	$tpl_temp .= "\n\t\t\t\t".'<li><span>'.$lang_common['Topic searches'].' '.implode(' | ', $page_topicsearches).'</span></li>';
	$tpl_temp .= "\n\t\t\t".'</ul>';
}

$tpl_temp .= "\n\t\t\t".'<div class="clearer"></div>'."\n\t\t".'</div>';

$tpl_main = str_replace('<panther_status>', $tpl_temp, $tpl_main);
// END SUBST - <panther_status>


// START SUBST - <panther_announcement>
if ($panther_user['g_read_board'] == '1' && $panther_config['o_announcement'] == '1')
{
	ob_start();

?>
<div id="announce" class="block">
	<div class="hd"><h2><span><?php echo $lang_common['Announcement'] ?></span></h2></div>
	<div class="box">
		<div id="announce-block" class="inbox">
			<div class="usercontent"><?php echo $panther_config['o_announcement_message'] ?></div>
		</div>
	</div>
</div>
<?php

	$tpl_temp = trim(ob_get_contents());
	$tpl_main = str_replace('<panther_announcement>', $tpl_temp, $tpl_main);
	ob_end_clean();
}
else
	$tpl_main = str_replace('<panther_announcement>', '', $tpl_main);
// END SUBST - <panther_announcement>


// START SUBST - <panther_main>
ob_start();


define('PANTHER_HEADER', 1);