<?php
/**
 * Copyright (C) 2017 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

if (isset($_GET['action']))
	define('AURA_QUIET_VISIT', 1);

if (!defined('AURA'))
{
	define('AURA_ROOT', __DIR__.'/');
	require AURA_ROOT.'include/common.php';
}

if ($aura_user['is_bot']) // I can't think of one valid reason why bots should be able to attempt to login
	message($lang->t('No permission'));

// Load the login language file
$lang->load('login');

$action = isset($_GET['action']) ? $_GET['action'] : null;

$errors = array();
$password_expired = false;
if (isset($_POST['form_sent']) && $action == 'in')
{
	($hook = get_extensions('login_before_validation')) ? eval($hook) : null;

	$form_username = isset($_POST['req_username']) ? aura_trim($_POST['req_username']) : '';
	$form_password = isset($_POST['req_password']) ? aura_trim($_POST['req_password']) : '';
	$save_pass = isset($_POST['save_pass']);

	if ($aura_config['o_login_queue'] == '1')
	{
		$data = array(
			':username'	=>	$form_username,
			':timeout'	=>	(TIMEOUT * 1000),
		);

		$ps = $db->select('login_queue', 'COUNT(*) AS overall, COUNT(IF(username = :username, TRUE, NULL)) AS user', $data, 'last_checked > NOW() - INTERVAL :timeout MICROSECOND');
		$count = $ps->fetch();

		if (!$count)
			message($lang->t('Unable to query size'));
		else if ($count['overall'] >= $aura_config['o_queue_size'] || $count['user'] >= $aura_config['o_max_attempts'])
			message($lang->t('Login queue exceeded'));	

		$insert = array(
			'ip_address' => get_remote_address(),
			'username' => $form_username,
		);

		$db->insert('login_queue', $insert) or message($lang->t('IP address in queue'));
		$attempt = $db->lastInsertId($db->prefix.'login_queue');

		// This time, while() is actually in our favour. Yes, I know!
		while (!check_queue($form_username, $attempt, $db))
			usleep(250 * 1000);

		//Force delay between logins, remove dead attempts
		usleep(ATTEMPT_DELAY * 1000);

		$data = array(
			':id'	=>	$attempt,
			':timeout'	=>	(TIMEOUT * 1000),
		);

		$db->delete('login_queue', 'id=:id OR last_checked < NOW() - INTERVAL :timeout MICROSECOND', $data);
	}

	$data = array(
		':username' => $form_username,
	);

	$ps = $db->select('users', 'password, salt, group_id, id, login_key, password_changed', $data, 'username=:username');
	$cur_user = $ps->fetch();

	if (!aura_hash_equals($cur_user['password'], aura_hash($form_password.$cur_user['salt'])))
		$errors[] = $lang->t('Wrong user/pass', ' <a href="'.aura_link($aura_url['request_password']).'">'.$lang->t('Forgotten pass').'</a>');
	else if ($aura_config['o_password_expires'])
	{
		$expired = $cur_user['password_changed'] + ($aura_config['o_password_expires'] * 86400);
		if (CURRENT_TIMESTAMP > $expired)
		{
			$password_expired = true;
			$lang->load('prof_reg');
			$password1 = isset($_POST['password1']) ? utf8_trim($_POST['password1']) : '';
			$password2 = isset($_POST['password2']) ? utf8_trim($_POST['password2']) : '';

			if ($password1)
			{
				$errors = validate_password($password1, $password2);
				if (empty($errors))
				{
					$salt = random_pass(16);
					$cur_user['login_key'] = random_pass(60);

					$data = array(
						':id' => $cur_user['id'],
					);

					$update = array(
						'password' => aura_hash($password1.$salt),
						'salt' => $salt,
						'login_key' => $cur_user['login_key'],
						'password_changed' => CURRENT_TIMESTAMP,
					);

					$db->update('users', $update, 'id=:id', $data);
				}
			}
			else
				$errors[] = $lang->t('Password expired');
		}
	}

	($hook = get_extensions('login_after_validation')) ? eval($hook) : null;

	if (empty($errors))
	{
		// Update the status if this is the first time the user logged in
		if ($cur_user['group_id'] == AURA_UNVERIFIED)
		{
			$update = array(
				'group_id' => $aura_config['o_default_user_group'],
			);

			$data = array(
				':id' => $cur_user['id'],
			);

			$db->update('users', $update, 'id=:id', $data);
			$cache->generate('stats');
		}

		// Remove this user's guest entry from the online list
		$data = array(
			':ident' => get_remote_address(),
		);

		$db->delete('online', 'ident=:ident', $data);

		$expire = ($save_pass == '1') ? CURRENT_TIMESTAMP + 1209600 : CURRENT_TIMESTAMP + $aura_config['o_timeout_visit'];
		aura_setcookie($cur_user['id'], $cur_user['login_key'], $expire);

		// Reset tracked topics
		set_tracked_topics(null);

		// Try to determine if the data in redirect_url is valid (if not, we redirect to index.php after login)
		$redirect_url = validate_redirect($_POST['redirect_url'], aura_link($aura_url['index']));
		redirect($redirect_url, $lang->t('Login redirect'));
	}
}
else if ($action == 'out')
{
	if ($aura_user['is_guest'] || !isset($_GET['id']) || $_GET['id'] != $aura_user['id'])
	{
		header('Location: '.aura_link($aura_url['index']));
		exit;
	}
	
	confirm_referrer('login.php');
	$data = array(
		':id' => $aura_user['id'],
	);

	// Remove user from "users online" list
	$db->delete('online', 'user_id=:id', $data);
	generate_login_key();

	// Update last_visit (make sure there's something to update it with)
	if (isset($aura_user['logged']))
	{
		$update = array(
			'last_visit' => $aura_user['logged'],
		);

		$data = array(
			':id' => $aura_user['id'],
		);
		
		$db->update('users', $update, 'id=:id', $data);
	}

	aura_setcookie(1, aura_hash(uniqid(rand(), true)), CURRENT_TIMESTAMP + 31536000);
	redirect(aura_link($aura_url['index']), $lang->t('Logout redirect'));
}
else if ($action == 'forget')
{
	if (!$aura_user['is_guest'])
	{
		header('Location: '.aura_link($aura_url['index']));
		exit;
	}

	if (isset($_POST['form_sent']))
	{
		confirm_referrer('login.php');
		($hook = get_extensions('forget_password_before_validation')) ? eval($hook) : null;

		// Start with a clean slate
		$errors = array();

		// Validate the email address
		$email = isset($_POST['req_email']) ? strtolower(aura_trim($_POST['req_email'])) : '';
		if (!email::is_valid_email($email))
			$errors[] = $lang->t('Invalid email');

		($hook = get_extensions('forget_password_after_validation')) ? eval($hook) : null;

		// Did everything go according to plan?
		if (empty($errors))
		{
			$data = array(
				':email' => $email,
			);

			$mail = new email($aura_config);
			$ps = $db->select('users', 'id, username, last_email_sent', $data, 'email=:email');
			if ($ps->rowCount())
			{
				// Loop through users we found
				foreach ($ps as $cur_hit)
				{
					if ($cur_hit['last_email_sent'] != '' && (CURRENT_TIMESTAMP - $cur_hit['last_email_sent']) < 3600 && (CURRENT_TIMESTAMP - $cur_hit['last_email_sent']) >= 0)
						message($lang->t('Email flood', intval((3600 - (CURRENT_TIMESTAMP - $cur_hit['last_email_sent'])) / 60)), true);

					// Generate a new password and a new password activation code
					$new_password = random_pass(12);
					$new_salt = random_pass(16);
					$new_password_key = random_pass(8);
					
					$update = array(
						'activate_string' => aura_hash($new_password.$new_salt),
						'salt' => $new_salt,
						'activate_key' => $new_password_key,
						'last_email_sent' => CURRENT_TIMESTAMP,
					);
					
					$data = array(
						':id' => $cur_hit['id'],
					);

					$db->update('users', $update, 'id=:id', $data);

					$info = array(
						'message' => array(
							'<base_url>' => get_base_url(),
							'<username>' => $cur_hit['username'],
							'<activation_url>' => aura_link($aura_url['change_password_key'], array($cur_hit['id'], $new_password_key)),
							'<new_password>' => $new_password,
						)
					);

					$mail_tpl = parse_email('activate_password', $aura_user['language'], $info);
					$mail->send($email, $mail_tpl['subject'], $mail_tpl['message']);
				}

				message($lang->t('Forget mail').' '.$aura_config['o_admin_email'], true);
			}
			else
				$errors[] = $lang->t('No email match').' '.$email.'.';
			}
		}

	$page_title = array($aura_config['o_board_title'], $lang->t('Request pass'));
	$required_fields = array('req_email' => $lang->t('Email'));
	$focus_element = array('request_pass', 'req_email');

	($hook = get_extensions('forgot_password_before_header')) ? eval($hook) : null;

	define ('AURA_ACTIVE_PAGE', 'login');
	require AURA_ROOT.'header.php';

	$tpl = load_template('forgot_password.tpl');
	echo $tpl->render(
		array (
			'lang' => $lang,
			'form_url' => aura_link($aura_url['request_password']),
			'csrf_token' => generate_csrf_token(),
			'errors' => $errors
		)
	);

	require AURA_ROOT.'footer.php';
}

if (!$aura_user['is_guest'])
{
	header('Location: '.aura_link($aura_url['index']));
	exit;
}

// Try to determine if the data in HTTP_REFERER is valid (if not, we redirect to index.php after login)
if (!empty($_SERVER['HTTP_REFERER']))
	$redirect_url = validate_redirect($_SERVER['HTTP_REFERER'], null);

if (!isset($redirect_url))
	$redirect_url = aura_link($aura_url['index']);
else if (preg_match('%viewtopic\.php\?pid=(\d+)$%', $redirect_url, $matches))
	$redirect_url .= '#p'.$matches[1];

$page_title = array($aura_config['o_board_title'], $lang->t('Login'));
$required_fields = array('req_username' => $lang->t('Username'), 'req_password' => $lang->t('Password'));
$focus_element = array('login', 'req_username');

($hook = get_extensions('login_before_header')) ? eval($hook) : null;

define('AURA_ACTIVE_PAGE', 'login');
require AURA_ROOT.'header.php';

$tpl = load_template('login.tpl');
echo $tpl->render(
	array (
		'lang' => $lang,
		'password_expired' => $password_expired,
		'aura_config' => $aura_config,
		'POST' => $_POST,
		'form_action' => aura_link($aura_url['login_in']),
		'redirect_url' => $redirect_url,
		'register' => aura_link($aura_url['register']),
		'request_password' => aura_link($aura_url['request_password']),
		'errors' => $errors,
	)
);

require AURA_ROOT.'footer.php';