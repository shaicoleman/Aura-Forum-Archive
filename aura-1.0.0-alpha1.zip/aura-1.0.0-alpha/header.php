<?php
/**
 * Copyright (C) 2017 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

// Make sure no one attempts to run this script "directly"
if (!defined('AURA'))
	exit;

// Send no-cache headers
header('Expires: Thu, 21 Jul 1977 07:30:00 GMT'); // When yours truly first set eyes on this world! :)
header('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT');
header('Cache-Control: post-check=0, pre-check=0', false);
header('Pragma: no-cache'); // For HTTP/1.0 compatibility

// Send the Content-type header in case the web server is setup to send something else
header('Content-type: text/html; charset=utf-8');

// Prevent site from being embedded in a frame
header('X-Frame-Options: '.(defined('AURA_XFRAME_OPTIONS') ? AURA_XFRAME_OPTIONS : 'deny'));

($hook = get_extensions('header_after_headers')) ? eval($hook) : null;

$p = isset($p) ? $p : null;
$links = array();

// Index should always be displayed
$links[] = array('id' => 'navindex', 'class' => ((AURA_ACTIVE_PAGE == 'index') ? 'active' : ''), 'page' => aura_link($aura_url['index']), 'title' => $lang->t('Index'));

if ($aura_user['g_read_board'] == '1' && $aura_user['g_view_users'] == '1')
	$links[] = array('id' => 'navuserlist', 'class' => ((AURA_ACTIVE_PAGE == 'userlist') ? 'active' : ''), 'page' => aura_link($aura_url['userlist']), 'title' => $lang->t('User list'));

if ($aura_user['g_read_board'] == '1' && $aura_user['g_view_users'] == '1')
	$links[] = array('id' => 'navleaders', 'class' => ((AURA_ACTIVE_PAGE == 'leaders') ? 'active' : ''), 'page' => aura_link($aura_url['leaders']), 'title' => $lang->t('Moderating Team'));

if ($aura_user['g_read_board'] == '1' && $aura_user['g_view_users'] == '1' && $aura_config['o_users_online'] == '1')
	$links[] = array('id' => 'navonline', 'class' => ((AURA_ACTIVE_PAGE == 'online') ? 'active' : ''), 'page' => aura_link($aura_url['online']), 'title' => $lang->t('Online'));

if ($aura_config['o_rules'] == '1' && (!$aura_user['is_guest'] || $aura_user['g_read_board'] == '1' || $aura_config['o_regs_allow'] == '1'))
	$links[] = array('id' => 'navrules', 'class' => ((AURA_ACTIVE_PAGE == 'rules') ? 'active' : ''), 'page' => aura_link($aura_url['rules']), 'title' => $lang->t('Rules'));

if ($aura_user['g_read_board'] == '1' && $aura_user['g_search'] == '1')
	$links[] = array('id' => 'navsearch', 'class' => ((AURA_ACTIVE_PAGE == 'search') ? 'active' : ''), 'page' => aura_link($aura_url['search']), 'title' => $lang->t('Search'));

if ($aura_user['is_guest'])
{
	$links[] = array('id' => 'navregister', 'class' => ((AURA_ACTIVE_PAGE == 'register') ? 'active' : ''), 'page' => aura_link($aura_url['register']), 'title' => $lang->t('Register'));
	$links[] = array('id' => 'navlogin', 'class' => ((AURA_ACTIVE_PAGE == 'login') ? 'active' : ''), 'page' => aura_link($aura_url['login']), 'title' => $lang->t('Login'));
}
else
{	// To avoid another preg replace, link directly to the essentials section
	$links[] = array('id' => 'navprofile', 'class' => ((AURA_ACTIVE_PAGE == 'profile') ? 'active' : ''), 'page' => aura_link($aura_url['profile_essentials'], array($aura_user['id'])), 'title' => $lang->t('Profile'));

	if ($aura_config['o_private_messaging'] == '1' && $aura_user['g_use_pm'] == '1' && $aura_user['pm_enabled'] == '1')
	{
		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'pms_data',
				'as' => 'cd',
				'on' => 'c.id=cd.topic_id AND cd.user_id=:uid',
			),
		);

		$header_data = array(
			':uid' => $aura_user['id'],
		);

		$ps_header = $db->join('conversations', 'c', $join, 'COUNT(c.id)', $header_data, 'cd.viewed=0 AND cd.deleted=0');
		$num_messages = $ps_header->fetchColumn();

		$pm_lang = ($num_messages) ? $lang->t('PM amount', $num_messages) : $lang->t('PM');
		$links[] = array('id' => 'navpm', 'class' => ((AURA_ACTIVE_PAGE == 'pm') ? 'active' : ''), 'page' => aura_link($aura_url['inbox']), 'title' => $pm_lang);
	}

	if ($aura_user['is_admmod'] && ($aura_user['is_admin'] || $aura_user['g_mod_cp'] == '1'))
		$links[] = array('id' => 'navadmin', 'class' => ((AURA_ACTIVE_PAGE == 'admin') ? 'active' : ''), 'page' => aura_link($aura_url['admin_index']), 'title' => $lang->t('Admin'));

    $links[] = array('id' => 'navlogout', 'class' => '', 'page' => aura_link($aura_url['logout'], array($aura_user['id'], generate_csrf_token('login.php'))), 'title' => $lang->t('Logout'));
}

// Are there any additional navlinks we should insert into the array before imploding it?
if ($aura_user['g_read_board'] == '1' && $aura_config['o_additional_navlinks'] != '')
{
	if (preg_match_all('%([0-9]+)\s*=\s*(.*?)\n%s', $aura_config['o_additional_navlinks']."\n", $extra_links))
	{
		// Insert any additional links into the $links array (at the correct index)
		$num_links = count($extra_links[1]);
		for ($i = 0; $i < $num_links; ++$i)
		{
			$link = explode('|', $extra_links[2][$i]);
			array_splice($links, $extra_links[1][$i], 0, array(array('id' => 'navextra'.($i + 1), 'class' => '', 'page' => $link[0], 'title' => $link[1])));
		}
	}
}

if (defined('AURA_ADMIN_CONSOLE'))
{
	if (file_exists(AURA_ROOT.'styles/'.$aura_user['style'].'/base_admin.css'))
		$style_root = (($aura_config['o_style_dir']) != '' ? $aura_config['o_style_dir'] : get_base_url().'/styles/').$aura_user['style'];
	else
		$style_root = (($aura_config['o_style_dir']) != '' ? $aura_config['o_style_dir'] : get_base_url().'/styles/').'core';
}
else
	$style_root = '';

$reports = array();
if ($aura_user['is_admmod'])
{
	if ($aura_config['o_report_method'] == '0' || $aura_config['o_report_method'] == '2')
	{
		$ps_header = $db->select('reports', 1, array(), 'zapped IS NULL');
		if ($ps_header->rowCount())
			$reports[] = array('link' => aura_link($aura_url['admin_reports']), 'title' => $lang->t('New reports'));
	}

	$ps_header = $db->select('posts', 1, array(), 'approved=0 AND deleted=0');
	if ($ps_header->rowCount())
		$reports[] = array('link' => aura_link($aura_url['admin_posts']), 'title' => $lang->t('New unapproved posts'));
}

$status_info = array();
if ($aura_user['g_read_board'] == '1' && $aura_user['g_search'] == '1')
{
	if (!$aura_user['is_guest'])
	{
		$status_info[] = array('link' => aura_link($aura_url['search_replies']), 'title' => $lang->t('Show posted topics'), 'display' => $lang->t('Posted topics'));
		$status_info[] = array('link' => aura_link($aura_url['search_new']), 'title' => $lang->t('Show new posts'), 'display' => $lang->t('New posts header'));
	}

	$status_info[] = array('link' => aura_link($aura_url['search_recent']), 'title' => $lang->t('Show active topics'), 'display' => $lang->t('Active topics'));
	$status_info[] = array('link' => aura_link($aura_url['search_unanswered']), 'title' => $lang->t('Show unanswered topics'), 'display' => $lang->t('Unanswered topics'));
}

if (isset($required_fields))
{
	$element = '';
	$tpl_temp = count($required_fields);
	foreach ($required_fields as $elem_orig => $elem_trans)
	{
		$element .= "\t\t\"".$elem_orig.'": "'.addslashes(str_replace('&#160;', ' ', $elem_trans));
		if (--$tpl_temp) $element .= "\",\n";
		else $element .= "\"\n\t};\n";
	}
}
else
	$element = '';

ob_start();
($hook = get_extensions('header_before_output')) ? eval($hook) : null;

$style_path = (($aura_config['o_style_path'] != 'styles') ? $aura_config['o_style_path'] : AURA_ROOT.$aura_config['o_style_path']).'/'.$aura_user['style'].'/templates/';
$tpl = (defined('AURA_ADMIN_CONSOLE') && (file_exists($style_path.'admin_header.tpl') || $aura_user['style'] == $aura_config['o_default_style'] && !file_exists($style_path)) ? 'admin_header.tpl' : 'header.tpl');
$tpl = load_template($tpl);
echo $tpl->render(
	array(
		'aura_config' => $aura_config,
		'aura_user' => $aura_user,
		'username' => colourise_group($aura_user['username'], $aura_user['group_id'], $aura_user['id']),
		'last_visit' => format_time($aura_user['last_visit']),
		'lang' => $lang,
		'num_messages' => isset($num_messages) ? $num_messages : '',
		'page_title' => generate_page_title($page_title, $p),
		'stylesheet' => (($aura_config['o_style_dir']) != '' ? $aura_config['o_style_dir'] : get_base_url().'/styles/').$aura_user['style'],
		'core_css' => (($aura_config['o_style_dir']) != '' ? $aura_config['o_style_dir'] : get_base_url().'/styles/').(file_exists((($aura_config['o_style_path'] != 'styles') ? $aura_config['o_style_path'] : AURA_ROOT.$aura_config['o_style_path'].'/').$aura_user['style'].'/normalize.css') ? $aura_user['style'] : 'core'),
		'core_editor' => (($aura_config['o_style_dir']) != '' ? $aura_config['o_style_dir'] : get_base_url().'/styles/').(file_exists((($aura_config['o_style_path'] != 'styles') ? $aura_config['o_style_path'] : AURA_ROOT.$aura_config['o_style_path'].'/').$aura_user['style'].'/editor.css') ? $aura_user['style'] : 'core'),
		'favicon' => $aura_config['o_image_dir'].$aura_config['o_favicon'],
		'page' => basename($_SERVER['PHP_SELF'], '.php'),
		'index_url' => aura_link($aura_url['index']),
		'links' => $links,
		'inbox_link' => aura_link($aura_url['inbox']),
		'maintenance_link' => aura_link($aura_url['admin_options_direct'], array('maintenance')),
		'status_info' => $status_info,
		'reports' => $reports,
		'admin_style' => $style_root,
		'smiley_path' => (($aura_config['o_smilies_dir'] != '') ? $aura_config['o_smilies_dir'] : get_base_url().'/'.$aura_config['o_smilies_path'].'/'),
		'jquery' => (defined('JQUERY_REQUIRED') || (defined('POSTING') && $aura_config['o_use_editor'] == '1' && $aura_user['use_editor'] == '1') || defined('REPUTATION'))?  '1' : '0',
		'reputation' => defined('REPUTATION') ? '1' : '0',
		'posting' => defined('POSTING') && $aura_config['o_use_editor'] != '0' && $aura_user['use_editor'] == '1' ? '1' : '0',
		'admin_index' => defined('ADMIN_INDEX') ? '1' : '0',
		'required_fields' => $element,
		'focus_element' => isset($focus_element) ? $focus_element : array(),
		'page_head' => !empty($page_head) ? $page_head : array(),
		'allow_index' => defined('AURA_ALLOW_INDEX') ? '1' : '0',
		'common' => defined('COMMON_JAVASCRIPT') ? true : false,
	)
);

($hook = get_extensions('header_after_output')) ? eval($hook) : null;

define('AURA_HEADER', 1);
