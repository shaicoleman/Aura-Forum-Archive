<?php
/**
 * Copyright (C) 2017 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

if (isset($_GET['action']))
	define('AURA_QUIET_VISIT', 1);

if (!defined('AURA_ROOT'))
{
	define('AURA_ROOT', __DIR__.'/');
	require AURA_ROOT.'include/common.php';
}

// Load the miscellaneous language file
$lang->load('misc');
$action = isset($_GET['action']) ? $_GET['action'] : null;

if ($action == 'rules')
{
	if ($aura_config['o_rules'] == '0' || ($aura_user['is_guest'] && $aura_user['g_read_board'] == '0' && $aura_config['o_regs_allow'] == '0'))
		message($lang->t('Bad request'), false, '404 Not Found');

	// Load the register language file
	$lang->load('register');

	$page_title = array($aura_config['o_board_title'], $lang->t('Forum rules'));
	define('AURA_ACTIVE_PAGE', 'rules');
	require AURA_ROOT.'header.php';
	
	$tpl = load_template('forum_rules.tpl');
	echo $tpl->render(
		array(
			'lang' => $lang,
			'aura_config' => $aura_config,
		)
	);

	require AURA_ROOT.'footer.php';
}
else if ($action == 'markread')
{
    confirm_referrer('index.php');
	if ($aura_user['is_guest'])
		message($lang->t('No permission'), false, '403 Forbidden');

	$update = array(
		'last_visit' => $aura_user['logged'],
	);

	$data = array(
		':id' => $aura_user['id'],
	);

	$db->update('users', $update, 'id=:id', $data);

	// Reset tracked topics
	set_tracked_topics(null);
	redirect(aura_link($aura_url['index']), $lang->t('Mark read redirect'));
}

// Mark the topics/posts in a forum as read?
else if ($action == 'markforumread')
{
    confirm_referrer('viewforum.php');
	if ($aura_user['is_guest'])
		message($lang->t('No permission'), false, '403 Forbidden');

	$fid = isset($_GET['fid']) ? intval($_GET['fid']) : 0;
	if ($fid < 1)
		message($lang->t('Bad request'), false, '404 Not Found');
	
	$data = array(
		':id' => $fid,
	);
	
	$ps = $db->select('forums', 'forum_name', $data, 'id=:id');
	$forum_name = url_friendly($ps->fetchColumn());

	$tracked_topics = get_tracked_topics();
	$tracked_topics['forums'][$fid] = CURRENT_TIMESTAMP;
	set_tracked_topics($tracked_topics);
	redirect(aura_link($aura_url['forum'], array($fid, $forum_name)), $lang->t('Mark forum read redirect'));
}
else if (isset($_GET['email']))
{
	if ($aura_user['is_guest'] || $aura_user['g_send_email'] == '0')
		message($lang->t('No permission'), false, '403 Forbidden');

	$recipient_id = intval($_GET['email']);
	if ($recipient_id < 2)
		message($lang->t('Bad request'), false, '404 Not Found');

	$data = array(
		':id' => $recipient_id,
	);

	$ps = $db->select('users', 'username, email, email_setting', $data, 'id=:id');
	if (!$ps->rowCount())
		message($lang->t('Bad request'), false, '404 Not Found');

	list($recipient, $recipient_email, $email_setting) = $ps->fetch(PDO::FETCH_NUM);

	if ($email_setting == 2 && !$aura_user['is_admmod'])
		message($lang->t('Form email disabled'));

	$errors = array();
	if (isset($_POST['form_sent']))
	{
		confirm_referrer('misc.php');

		// Clean up message and subject from POST
		$subject = isset($_POST['req_subject']) ? aura_trim($_POST['req_subject']) : '';
		$message = isset($_POST['req_message']) ? aura_trim($_POST['req_message']) : '';

		if ($subject == '')
			$errors[] = $lang->t('No email subject');
		else if ($message == '')
			$errors[] = $lang->t('No email message');
		// Here we use strlen() not aura_strlen() as we want to limit the post to AURA_MAX_POSTSIZE bytes, not characters
		else if (strlen($message) > AURA_MAX_POSTSIZE)
			$errors[] = $lang->t('Too long email message');

		if ($aura_user['last_email_sent'] != '' && (CURRENT_TIMESTAMP - $aura_user['last_email_sent']) < $aura_user['g_email_flood'] && (CURRENT_TIMESTAMP - $aura_user['last_email_sent']) >= 0)
			$errors[] = $lang->t('Email flood', $aura_user['g_email_flood'], $aura_user['g_email_flood'] - (CURRENT_TIMESTAMP - $aura_user['last_email_sent']));
		
		($hook = get_extensions('send_email_after_validation')) ? eval($hook) : null;

		if (empty($errors))
		{
			$email = new email($aura_config);
			$info = array(
				'subject' => array(
					'<mail_subject>' => $subject,
				),
				'message' => array(
					'<sender>' => $aura_user['username'],
					'<board_title>' => $aura_config['o_board_title'],
					'<mail_message>' => $message,
				)
			);

			$mail_tpl = parse_email('form_email', $aura_user['language'], $info);
			$email->send($recipient_email, $mail_tpl['subject'], $mail_tpl['message'], $aura_user['email'], $aura_user['username']);

			$update = array(
				'last_email_sent' => CURRENT_TIMESTAMP,
			);

			$data = array(
				':id' => $aura_user['id'],
			);

			$db->update('users', $update, 'id=:id', $data);

			// Try to determine if the data in redirect_url is valid (if not, we redirect to index.php after the email is sent)
			$redirect_url = validate_redirect($_POST['redirect_url'], aura_link($aura_url['index']));
			redirect($redirect_url, $lang->t('Email sent redirect'));
		}
	}

	// Try to determine if the data in HTTP_REFERER is valid (if not, we redirect to the user's profile after the email is sent)
	if (!empty($_SERVER['HTTP_REFERER']))
		$redirect_url = validate_redirect($_SERVER['HTTP_REFERER'], null);

	if (!isset($redirect_url))
		$redirect_url = aura_link($aura_url['profile'], array($recipient_id));
	else if (preg_match('%viewtopic\.php\?pid=(\d+)$%', $redirect_url, $matches))
		$redirect_url .= '#p'.$matches[1];

	$page_title = array($aura_config['o_board_title'], $lang->t('Send email to', $recipient));
	$required_fields = array('req_subject' => $lang->t('Email subject'), 'req_message' => $lang->t('Email message'));
	$focus_element = array('email', 'req_subject');
	define('AURA_ACTIVE_PAGE', 'index');
	require AURA_ROOT.'header.php';

	$tpl = load_template('send_email.tpl');
	echo $tpl->render(
		array(
			'lang' => $lang,
			'recipient' => $recipient,
			'form_action' => aura_link($aura_url['email'], array($recipient_id)),
			'csrf_token' => generate_csrf_token(),
			'redirect_url' => $redirect_url,
			'errors' => $errors,
			'subject' => isset($subject) ? $subject : '',
			'message' => isset($message) ? $message : ''
		)
	);

	require AURA_ROOT.'footer.php';
}
else if (isset($_GET['report']))
{
	if ($aura_user['is_guest'])
		message($lang->t('No permission'), false, '403 Forbidden');

	$post_id = intval($_GET['report']);
	if ($post_id < 1)
		message($lang->t('Bad request'), false, '404 Not Found');

	$errors = array();
	if (isset($_POST['form_sent']))
	{
		// Make sure they got here from the site
		confirm_referrer('misc.php');

		// Clean up reason from POST
		$reason = isset($_POST['req_reason']) ? aura_linebreaks(aura_trim($_POST['req_reason'])) : '';
		if ($reason == '')
			$errors[] = $lang->t('No reason');
		else if (strlen($reason) > 65535) // TEXT field can only hold 65535 bytes
			$errors[] = $lang->t('Reason too long');

		if ($aura_user['last_report_sent'] != '' && (CURRENT_TIMESTAMP - $aura_user['last_report_sent']) < $aura_user['g_report_flood'] && (CURRENT_TIMESTAMP - $aura_user['last_report_sent']) >= 0)
			$errors[] = $lang->t('Report flood', $aura_user['g_report_flood'], $aura_user['g_report_flood'] - (CURRENT_TIMESTAMP - $aura_user['last_report_sent']));

		($hook = get_extensions('report_after_validation')) ? eval($hook) : null;

		if (empty($errors))
		{
			// Get the topic ID
			$data = array(
				':id' => $post_id,
			);

			$ps = $db->select('posts', 'topic_id', $data, 'id=:id');
			if (!$ps->rowCount())
				message($lang->t('Bad request'), false, '404 Not Found');

			$topic_id = $ps->fetchColumn();
			$data = array(
				':id' => $topic_id,
			);

			// Get the subject and forum ID
			$join = array(
				array(
					'type' => 'INNER',
					'table' => 'forums',
					'as' => 'f',
					'on' => 't.forum_id=f.id',
				),
			);

			$ps = $db->join('topics', 't', $join, 't.subject, t.forum_id, f.forum_name, f.password', $data, 't.id=:id');
			if (!$ps->rowCount())
				message($lang->t('Bad request'), false, '404 Not Found');

			list($subject, $forum_id, $forum_name, $forum_password) = $ps->fetch(PDO::FETCH_NUM);

			if ($forum_password != '')
				check_forum_login_cookie($forum_id, $forum_password);

			// Should we use the internal report handling?
			if ($aura_config['o_report_method'] == '0' || $aura_config['o_report_method'] == '2')
			{
				$insert = array(
					'post_id'	=>	$post_id,
					'topic_id'	=>	$topic_id,
					'forum_id'	=>	$forum_id,
					'reported_by'	=>	$aura_user['id'],
					'created'	=>	CURRENT_TIMESTAMP,
					'message'	=>	$reason,
				);
				
				$db->insert('reports', $insert);
			}

			// Should we email the report?
			if ($aura_config['o_report_method'] == '1' || $aura_config['o_report_method'] == '2')
			{
				// We send it to the complete mailing-list in one swoop
				if ($aura_config['o_mailing_list'] != '')
				{
					$email = new email($aura_config);
					$info = array(
						'subject' => array(
							'<forum_id>' => $forum_id,
							'<topic_subject>' => $subject,
						),
						'message' => array(
							'<username>' => $aura_user['username'],
							'<post_url>' => aura_link($aura_url['post'], array($post_id)),
							'<reason>' => $reason,
						)
					);

					$mail_tpl = parse_email('new_report', $aura_user['language'], $info);
					$email->send($aura_config['o_mailing_list'], $mail_tpl['subject'], $mail_tpl['message']);
				}
			}
			
			$update = array(
				'last_report_sent' => CURRENT_TIMESTAMP,
			);
			
			$data = array(
				':id' => $aura_user['id'],
			);

			$db->update('users', $update, 'id=:id', $data);
			redirect(aura_link($aura_url['forum'], array($forum_id, url_friendly($forum_name))), $lang->t('Report redirect'));
		}
	}

	// Fetch some info about the post, the topic and the forum
	$data = array(
		':gid' => $aura_user['g_id'],
		':pid' => $post_id,
	);

	$join = array(
		array(
			'type' => 'INNER',
			'table' => 'topics',
			'as' => 't',
			'on' => 't.id=p.topic_id',
		),
		array(
			'type' => 'INNER',
			'table' => 'forums',
			'as' => 'f',
			'on' => 'f.id=t.forum_id',
		),
		array(
			'type' => 'LEFT',
			'table' => 'forum_perms',
			'as' => 'fp',
			'on' => '(fp.forum_id=f.id AND fp.group_id=:gid)',
		),
	);

	$ps = $db->join('posts', 'p', $join, 'f.id AS fid, f.forum_name, f.password, f.protected, t.id AS tid, t.subject, t.archived, p.poster_id', $data, '(fp.read_forum IS NULL OR fp.read_forum=1) AND p.id=:pid');
	if (!$ps->rowCount())
		message($lang->t('Bad request'), false, '404 Not Found');

	$cur_post = $ps->fetch();

	if ($cur_post['password'] != '')
		check_forum_login_cookie($cur_post['fid'], $cur_post['password']);

	$moderators = $cache->get('moderators');
	if ($cur_post['protected'] == '1' && $aura_user['id'] != $cur_post['poster_id'] && $aura_user['g_global_moderator'] != 1 && !$aura_user['is_admin'] && !isset($moderators[$cur_post['fid']]['u'.$aura_user['id']]) && !isset($moderators[$cur_post['fid']]['g'.$aura_user['g_id']]))
		message($lang->t('Bad request'), false, '404 Not Found');

	if ($aura_config['o_censoring'] == '1')
		$cur_post['subject'] = censor_words($cur_post['subject']);

	if ($cur_post['archived'] == '1')
		message($lang->t('Topic archived'));

	$page_title = array($aura_config['o_board_title'], $lang->t('Report post'));
	$required_fields = array('req_reason' => $lang->t('Reason'));
	$focus_element = array('report', 'req_reason');
	define('AURA_ACTIVE_PAGE', 'index');
	require AURA_ROOT.'header.php';

	$tpl = load_template('report.tpl');
	echo $tpl->render(
		array(
			'lang' => $lang,
			'index_link' => aura_link($aura_url['index']),
			'cur_post' => $cur_post,
			'forum_link' => aura_link($aura_url['forum'], array($cur_post['fid'], url_friendly($cur_post['forum_name']))),
			'post_link' => aura_link($aura_url['post'], array($post_id)),
			'form_action' => aura_link($aura_url['report'], array($post_id)),
			'csrf_token' => generate_csrf_token(),
			'errors' => $errors,
			'message' => isset($_POST['req_reason']) ? $_POST['req_reason'] : '',
		)
	);

	require AURA_ROOT.'footer.php';
}
else if ($action == 'subscribe')
{
	confirm_referrer('viewforum.php');
	if ($aura_user['is_guest'])
		message($lang->t('No permission'), false, '403 Forbidden');

	$topic_id = isset($_GET['tid']) ? intval($_GET['tid']) : 0;
	$forum_id = isset($_GET['fid']) ? intval($_GET['fid']) : 0;
	if ($topic_id < 1 && $forum_id < 1)
		message($lang->t('Bad request'), false, '404 Not Found');

	if ($topic_id)
	{
		if ($aura_config['o_topic_subscriptions'] != '1')
			message($lang->t('No permission'), false, '403 Forbidden');

		// Make sure the user can view the topic
		$data = array(
			':gid' => $aura_user['g_id'],
			':tid' => $topic_id,
		);

		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'forums',
				'as' => 'f',
				'on' => 't.forum_id=f.id',
			),
			array(
				'type' => 'LEFT',
				'table' => 'forum_perms',
				'as' => 'fp',
				'on' => '(fp.forum_id=t.forum_id AND fp.group_id=:gid)',
			),
		);

		$ps = $db->join('topics', 't', $join, 't.subject, t.poster, f.password, f.protected, f.id AS fid', $data, '(fp.read_forum IS NULL OR fp.read_forum=1) AND t.id=:tid AND t.moved_to IS NULL');
		if (!$ps->rowCount())
			message($lang->t('Bad request'), false, '404 Not Found');
		else
			$cur_topic = $ps->fetch();

		if ($cur_topic['password'] != '')
			check_forum_login_cookie($cur_topic['fid'], $cur_topic['password']);

		$moderators = $cache->get('moderators');
		if ($cur_topic['protected'] == '1' && $aura_user['username'] != $cur_topic['poster'] && $aura_user['g_global_moderator'] != 1 && !$aura_user['is_admin'] && !isset($moderators[$cur_post['fid']]['u'.$aura_user['id']]) && !isset($moderators[$cur_post['fid']]['g'.$aura_user['g_id']]))
			message($lang->t('Bad request'), false, '404 Not Found');

		$data = array(
			':id'	=>	$aura_user['id'],
			':tid'	=>	$topic_id,
		);

		$ps = $db->select('topic_subscriptions', 1, $data, 'user_id=:id AND topic_id=:tid');
		if ($ps->rowCount())
			message($lang->t('Already subscribed topic'));

		$insert = array(
			'user_id'	=>	$aura_user['id'],
			'topic_id'	=>	$topic_id,
		);

		$db->insert('topic_subscriptions', $insert);
		redirect(aura_link($aura_url['topic'], array($topic_id, url_friendly($cur_topic['subject']))), $lang->t('Subscribe redirect'));
	}

	if ($forum_id)
	{
		if ($aura_config['o_forum_subscriptions'] != '1')
			message($lang->t('No permission'), false, '403 Forbidden');

		// Make sure the user can view the forum (and if a password is present, they know that too)
		$data = array(
			':gid' => $aura_user['g_id'],
			':fid' => $forum_id,
		);

		$join = array(
			array(
				'type' => 'LEFT',
				'table' => 'forum_perms',
				'as' => 'fp',
				'on' => '(fp.forum_id=f.id AND fp.group_id=:gid)',
			),
		);

		$ps = $db->join('forums', 'f', $join, 'f.forum_name, f.password', $data, '(fp.read_forum IS NULL OR fp.read_forum=1) AND f.id=:fid');
		if (!$ps->rowCount())
			message($lang->t('Bad request'), false, '404 Not Found');
		else
			$cur_forum = $ps->fetch();

		if ($cur_forum['password'] != '')
			check_forum_login_cookie($forum_id, $cur_forum['password']);

		$data = array(
			':id' => $aura_user['id'],
			':fid' => $forum_id,
		);

		$ps = $db->select('forum_subscriptions', 1, $data, 'user_id=:id AND forum_id=:fid');
		if ($ps->rowCount())
			message($lang->t('Already subscribed forum'));

		$insert = array(
			'user_id' => $aura_user['id'],
			'forum_id' => $forum_id,
		);

		$db->insert('forum_subscriptions', $insert);
		redirect(aura_link($aura_url['forum'], array($forum_id, url_friendly($cur_forum['forum_name']))), $lang->t('Subscribe redirect'));
	}
}
else if ($action == 'unsubscribe')
{
	confirm_referrer('viewforum.php', false);
	if ($aura_user['is_guest'])
		message($lang->t('No permission'), false, '403 Forbidden');

	$topic_id = isset($_GET['tid']) ? intval($_GET['tid']) : 0;
	$forum_id = isset($_GET['fid']) ? intval($_GET['fid']) : 0;
	if ($topic_id < 1 && $forum_id < 1)
		message($lang->t('Bad request'), false, '404 Not Found');

	if ($topic_id)
	{
		if ($aura_config['o_topic_subscriptions'] != '1')
			message($lang->t('No permission'), false, '403 Forbidden');

		$data = array(
			':id' => $topic_id,
		);

		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'forums',
				'as' => 'f',
				'on' => 't.forum_id=f.id',
			),
		);

		$ps = $db->join('topics', 't', $join, 't.subject, f.password, f.id AS fid', $data, 't.id=:id');
		if (!$ps->rowCount())
			message($lang->t('Bad request'));
		else
			$cur_topic = $ps->fetch();

		if ($cur_topic['password'] != '')
			check_forum_login_cookie($cur_topic['fid'], $cur_topic['password']);

		$data = array(
			':id' => $aura_user['id'],
			':tid' => $topic_id,
		);

		$ps = $db->select('topic_subscriptions', 1, $data, 'user_id=:id AND topic_id=:tid');
		if (!$ps->rowCount())
			message($lang->t('Not subscribed topic'));

		$data = array(
			':id' => $aura_user['id'],
			':tid' => $topic_id,
		);

		$db->delete('topic_subscriptions', 'user_id=:id AND topic_id=:tid', $data);
		redirect(aura_link($aura_url['topic'], array($topic_id, url_friendly($cur_topic['subject']))), $lang->t('Unsubscribe redirect'));
	}

	if ($forum_id)
	{
		if ($aura_config['o_forum_subscriptions'] != '1')
			message($lang->t('No permission'), false, '403 Forbidden');
		
		$data = array(
			':id' => $forum_id
		);

		$ps = $db->select('forums', 'forum_name, password', $data, 'id=:id');
		if (!$ps->rowCount())
			message($lang->t('Bad request'));
		else
			$cur_forum = $ps->fetch();

		if ($cur_forum['password'] != '')
			check_forum_login_cookie($forum_id, $cur_forum['password']);

		$data = array(
			':id' => $aura_user['id'],
			':fid' => $forum_id,
		);

		$ps = $db->select('forum_subscriptions', 1, $data, 'user_id=:id AND forum_id=:fid');
		if (!$ps->rowCount())
			message($lang->t('Not subscribed forum'));
		
		$data = array(
			':id' => $aura_user['id'],
			':fid' => $forum_id,
		);

		$db->delete('forum_subscriptions', 'user_id=:id AND forum_id=:fid', $data);
		redirect(aura_link($aura_url['forum'], array($forum_id, url_friendly($cur_forum['forum_name']))), $lang->t('Unsubscribe redirect'));
	}
}
else if ($action == 'leaders')
{
	if ($aura_user['g_read_board'] == '0')
		message($lang->t('No view'), false, '403 Forbidden');
	
	if ($aura_user['g_view_users'] == '0')
		message($lang->t('No permission'), false, '403 Forbidden');

	$permissions = $cache->get('perms');

	// Load the online language file
	$lang->load('online');
	
	$data = array(
		':admin' => AURA_ADMIN,
	);

	define('AURA_ACTIVE_PAGE', 'leaders');
	$page_title = array($aura_config['o_board_title'], $lang->t('User list'), $lang->t('The team'));
	require AURA_ROOT.'header.php';

	$join = array(
		array(
			'type' => 'INNER',
			'table' => 'groups',
			'as' => 'g',
			'on' => 'u.group_id=g.g_id',
		),
		array(
			'type' => 'LEFT',
			'table' => 'online',
			'as' => 'o',
			'on' => 'o.user_id=u.id',
		),
	);

	$administrators = array();
	$ps = $db->join('users', 'u', $join, 'u.id AS id, u.username, u.group_id, o.currently', $data, 'u.group_id=:admin OR g.g_admin=1');
	foreach ($ps as $user_data)
	{
		$administrators[$user_data['id']] = array(
			'username' => colourise_group($user_data['username'], $user_data['group_id'], $user_data['id']),
		);

		if ($aura_config['o_users_online'] == '1')
			$administrators[$user_data['id']]['location'] = fetch_user_location($user_data['currently']);
	}

	$join = array(
		array(
			'type' => 'INNER',
			'table' => 'groups',
			'as' => 'g',
			'on' => 'u.group_id=g.g_id',
		),
		array(
			'type' => 'LEFT',
			'table' => 'online',
			'as' => 'o',
			'on' => 'o.user_id=u.id',
		),
	);

	$global_moderators = array();
	$ps = $db->join('users', 'u', $join, 'u.id AS id, u.username, u.group_id, o.currently', array(), 'g.g_moderator=1 AND g.g_global_moderator=1 AND g.g_admin=0');
	foreach ($ps as $user_data)
	{
		$global_moderators[$user_data['id']] = array(
			'username' => colourise_group($user_data['username'], $user_data['group_id'], $user_data['id']),
		);

		if ($aura_config['o_users_online'] == '1')
			$global_moderators[$user_data['id']]['location'] = fetch_user_location($user_data['currently']);
	}

	$join = array(
		array(
			'type' => 'INNER',
			'table' => 'groups',
			'as' => 'g',
			'on' => 'u.group_id=g.g_id',
		),
		array(
			'type' => 'LEFT',
			'table' => 'online',
			'as' => 'o',
			'on' => 'o.user_id=u.id',
		),
	);

	$moderators = array();
	$aura_forums = $cache->get('forums');
	$forum_moderators = $cache->get('moderators');
	$ps = $db->join('users', 'u', $join, 'u.id AS id, u.username, u.group_id, o.currently', array(), 'g.g_moderator=1 AND g.g_global_moderator=0 AND g.g_admin=0');
	foreach ($ps as $user_data)
	{
		$total = 0;
		$forums = array();
		foreach ($aura_forums as $cur_forum)
		{
			if (!isset($permissions[$aura_user['g_id'].'_'.$cur_forum['id']]))
				$permissions[$aura_user['g_id'].'_'.$cur_forum['id']] = $permissions['_'];

			if (isset($forum_moderators[$cur_forum['id']]['u'.$user_data['id']]) || isset($forum_moderators[$cur_forum['id']]['g'.$user_data['group_id']]) && ($permissions[$aura_user['g_id'].'_'.$cur_forum['id']]['read_forum'] == '1' || is_null($permissions[$aura_user['g_id'].'_'.$cur_forum['id']]['read_forum'])))
			{
				$forums[] = array('forum_id' => $cur_forum['id'], 'forum_name' => $cur_forum['forum_name'], 'forum_url' => url_friendly($cur_forum['forum_name']));
				++$total;
			}
		}

		$moderators[$user_data['id']] = array(
			'username' => colourise_group($user_data['username'], $user_data['group_id'], $user_data['id']),
			'total' => $total,
			'forums' => $forums,
		);

		if ($aura_config['o_users_online'] == '1')
			$moderators[$user_data['id']]['location'] = fetch_user_location($user_data['currently']);
	}

	$tpl = load_template('leaders.tpl');
	echo $tpl->render(
		array(
			'lang' => $lang,
			'global_moderators' => $global_moderators,
			'administrators' => $administrators,
			'moderators' => $moderators,
			'action' => aura_link($aura_url['forum_noid']),
			'aura_config' => $aura_config,
			'location' => aura_link($aura_url['forum'], array("'+this.options[this.selectedIndex].value)+'", "'+this.options[this.selectedIndex].getAttribute('data-url')+'")),
		)
	);

	require AURA_ROOT.'footer.php';
}
else
	message($lang->t('Bad request'), false, '404 Not Found');