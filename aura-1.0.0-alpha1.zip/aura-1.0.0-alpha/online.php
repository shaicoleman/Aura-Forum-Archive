<?php
/**
 * Copyright (C) 2017 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

if (!defined('AURA'))
{
	define('AURA_ROOT', __DIR__.'/');
	require AURA_ROOT.'include/common.php';
}
	
if ($aura_user['g_read_board'] == '0')
	message($lang->t('No view'), false, '403 Forbidden');

if ($aura_user['is_bot'])
	message($lang->t('No permission'));

// Load the online language file
$lang->load('online');

// Load the search language file
$lang->load('search');

if ($aura_user['g_view_users'] == '0')
	message($lang->t('No permission'), false, '403 Forbidden');

$ps = $db->select('online', 'COUNT(user_id)', array(), 'idle=0');
$num_online = $ps->fetchColumn();

// Determine the post offset (based on $_GET['p'])
$num_pages = ceil(($num_online) / $aura_user['disp_posts']);

$p = (!isset($_GET['p']) || $_GET['p'] <= 1 || $_GET['p'] > $num_pages) ? 1 : intval($_GET['p']);
$start_from = $aura_user['disp_posts'] * ($p - 1);

($hook = get_extensions('online_before_header')) ? eval($hook) : null;

$page_title = array($aura_config['o_board_title'], $lang->t('Viewing users online'));
define('AURA_ACTIVE_PAGE', 'online');
require AURA_ROOT.'header.php';

$bots = $online = array();
$data = array(
	':start' => $start_from,
	':limit' => $aura_user['disp_posts'],
);

$join = array(
	array(
		'type' => 'INNER',
		'table' => 'users',
		'as' => 'u',
		'on' => 'o.user_id=u.id',
	),
);

$ps = $db->join('online', 'o', $join, 'o.user_id, o.ident, o.currently, o.logged, u.group_id', $data, 'o.idle=0 LIMIT :start,:limit');
foreach ($ps as $aura_user_online)
{
	if (strpos($aura_user_online['ident'], '[Bot]') !== false)
	{
		$name = explode('[Bot]', $aura_user_online['ident']);
		if (empty($bots[$name[1]])) $bots[$name[1]] = 1;
			else ++$bots[$name[1]];

		foreach ($bots as $online_name => $online_id)
		   $ident = $online_name.' [Bot]';
	}
	else
	{
		if ($aura_user_online['user_id'] == 1)
			$ident = $lang->t('Guest');
		else
			$ident = $aura_user_online['ident'];
	}

	$online[] = array(
		'username' => colourise_group($ident, $aura_user_online['group_id'], $aura_user_online['user_id']),
		'location' => fetch_user_location($aura_user_online['currently']),
		'last_active' => format_time_difference($aura_user_online['logged']),
	);
}

$tpl = load_template('online.tpl');
echo $tpl->render(
	array(
		'pagination' => paginate($num_pages, $p, $aura_url['online']),
		'lang' => $lang,
		'users_online' => $online,
		'num_pages' => $num_pages,
	)
);

($hook = get_extensions('online_after_display')) ? eval($hook) : null;

require AURA_ROOT.'footer.php';