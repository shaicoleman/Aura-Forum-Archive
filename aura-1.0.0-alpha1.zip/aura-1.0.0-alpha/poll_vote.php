<?php
/**
 * Copyright (C) 2017 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

if (!defined('AURA'))
{
	define('AURA_ROOT', __DIR__.'/');
	require AURA_ROOT.'include/common.php';
}

if ($aura_user['g_read_board'] == '0')
	message($lang->t('No view'), false, '403 Forbidden');

$id = isset($_POST['poll_id']) ? intval($_POST['poll_id']) : 0;

if ($id < 1)
	message($lang->t('Bad request'), false, '404 Not Found');

$join = array(
	array(
		'type' => 'INNER',
		'table' => 'topics',
		'as' => 't',
		'on' => 'p.topic_id=t.id',
	),
	array(
		'type' => 'INNER',
		'table' => 'forums',
		'as' => 'f',
		'on' => 'f.id=t.forum_id',
	),
	array(
		'type' => 'LEFT',
		'table' => 'forum_perms',
		'as' => 'fp',
		'on' => '(fp.forum_id=f.id AND fp.group_id=:gid)',
	),
);

$data = array(
	':id' => $id,
	':gid' => $aura_user['g_id'],
);

$ps = $db->join('polls', 'p', $join, 'f.id, f.password, f.redirect_url, fp.post_replies, fp.post_topics, t.subject, t.closed, t.archived, p.id AS pid, p.type, p.options, p.voters, p.votes', $data, '(fp.read_forum IS NULL OR fp.read_forum=1) AND t.id=:id');
if (!$ps->rowCount())
	message($lang->t('Bad request'), false, '404 Not Found');

$cur_poll = $ps->fetch();

if ($cur_poll['password'] != '')
		check_forum_login_cookie($cur_poll['id'], $cur_poll['password']);

$moderators = $cache->get('moderators');
$is_admmod = ($aura_user['is_admin'] || ($aura_user['g_moderator'] == '1' && $aura_user['g_global_moderator'] == '1' || isset($moderators[$cur_poll['id']]['u'.$aura_user['id']]) || isset($moderators[$cur_poll['id']]['g'.$aura_user['g_id']]))) ? true : false;

// Make sure we have permission to vote
if ((((($cur_poll['post_replies'] == '' && $aura_user['g_post_replies'] == '0') || $cur_poll['post_replies'] == '0') || $aura_user['is_guest']) || $cur_poll['closed'] == '1') && !$is_admmod || $cur_poll['archived'] == '1')
	message($lang->t('No permission'), false, '403 Forbidden');

$lang->load('poll');

if (isset($_POST['form_sent']))
{
	confirm_referrer('viewtopic.php');

	$options = ($cur_poll['options'] != '') ? unserialize($cur_poll['options']) : array();
	$voters = ($cur_poll['voters'] != '') ? unserialize($cur_poll['voters']) : array();
	$votes = ($cur_poll['votes'] != '') ? unserialize($cur_poll['votes']) : array();
	
	($hook = get_extensions('poll_vote_before_validation')) ? eval($hook) : null;

	if (in_array($aura_user['id'], $voters))
		message($lang->t('Already voted'));

	if ($cur_poll['type'] == '1')
	{
		$vote = isset($_POST['vote']) ? intval($_POST['vote']) : -1;
		if ($vote < 0)
			message($lang->t('Bad request'), false, '404 Not Found');

		// Increment the amount of votes for this option
		$votes[$vote] = isset($votes[$vote]) ? $votes[$vote]++ : 1;
	}
	else
	{
		$vote = isset($_POST['options']) && is_array($_POST['options']) ? array_map('intval', $_POST['options']) : array();

		if (empty($vote))
			message($lang->t('Bad request'), false, '404 Not Found');

		foreach ($vote as $key => $value)
		{
			// If the value isn't nothing, and it's a valid option, increment the votes
			if (!empty($value) && isset($options[$key]))
				$votes[$key] = isset($votes[$key]) ? $votes[$key]++ : 1;
		}
	}

	$voters[] = $aura_user['id'];
	$update = array(
		'votes'	 => serialize($votes),
		'voters' => serialize($voters),
	);

	$data = array(
		':id'	=>	$cur_poll['pid'],
	);

	$db->update('polls', $update, 'id=:id', $data);
	redirect(aura_link($aura_url['topic'], array($id, url_friendly($cur_poll['subject']))), $lang->t('Vote success'));
}
else
	message($lang->t('Bad request'), false, '404 Not Found');