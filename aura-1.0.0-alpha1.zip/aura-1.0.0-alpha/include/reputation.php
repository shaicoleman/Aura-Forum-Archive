<?php
/**
 * Copyright (C) 2017 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

define('AURA_ROOT', __DIR__.'/../');
require AURA_ROOT.'include/common.php';
$lang->load('reputation');

$action = isset($_GET['action']) ? $_GET['action'] : null;
$section = isset($_GET['section']) && in_array($_GET['section'], array('rep_received', 'rep_given')) ? $_GET['section'] : 'rep_received';
$vote = isset($_GET['vote']) ? intval($_GET['vote']) : '0';
$id = isset($_GET['id']) ? intval($_GET['id']) : '0';

if ($aura_config['o_reputation'] == '0')
	exit($lang->t('reputation disabled'));

if ($aura_user['g_rep_enabled'] == '0')
	exit($lang->t('Group disabled'));

if ($action == 'remove' && isset($_GET['p']) && isset($_GET['uid']))
{
	if (!$aura_user['is_admmod'] && !$aura_user['is_admin'] && $aura_user['g_access_admin_cp'] == '0')
		message($lang->t('No permission'));
		
	$data = array(
		':id' => $id,
	);

	$join = array(
		array(
			'type' => 'LEFT',
			'table' => 'posts',
			'as' => 'p',
			'on' => 'r.post_id=p.id',
		),
	);

	$ps = $db->join('reputation', 'r', $join, 'p.id, p.poster_id, r.vote', $data, 'r.id=:id');
	$cur_post = $ps->fetch();

	$vote = (($vote == '-1') ? '+1' : '-1');
	$data = array(
		':id'	=>	$cur_post['id'],
	);
	
	$db->run('UPDATE '.$db->prefix.'posts SET reputation=reputation'.$vote.' WHERE id=:id', $data);
	$data = array(
		':id' => $cur_post['poster_id'],
	);
	
	$db->run('UPDATE '.$db->prefix.'users SET reputation=reputation'.$vote.' WHERE id=:id', $data);
	$data = array(
		':id' => $id,
	);
	
	($hook = get_extensions('reputation_before_deletion')) ? eval($hook) : null;
	$db->delete('reputation', 'id=:id', $data);

	$db->end_transaction();
	header('Location: '.aura_link($aura_url['profile_'.$section], array(intval($_GET['uid']))));
	exit;
}
else
{
	if ($id < 1 || $vote == '0' || !defined('AURA_AJAX_REQUEST'))
	 	exit($lang->t('Bad request'));

	confirm_referrer('viewtopic.php');
	$data = array(
		':id'	=>	$id,
	);

	$join = array(
		array(
			'type' => 'INNER',
			'table' => 'topics',
			'as' => 't',
			'on' => 'p.topic_id=t.id',
		),
		array(
			'type' => 'INNER',
			'table' => 'forums',
			'as' => 'f',
			'on' => 't.forum_id=f.id',
		),
	);

	$ps = $db->join('posts', 'p', $join, 'f.use_reputation, t.closed, t.archived, f.id, p.poster_id, p.reputation, p.poster', $data, 'p.id=:id');
	if (!$ps->rowCount())
		exit($lang->t('Bad request'));
	else
			$cur_forum = $ps->fetch();
		
	if ($cur_forum['archived'] == '1')
		exit($lang->t('archived message'));

	if ($cur_forum['use_reputation'] == '0')
		exit($lang->t('reputation forum disabled'));
				
	if ($cur_forum['closed'] == '1' && !$aura_user['is_admmod'])
		exit($lang->t('topic closed'));

	if ($aura_user['id'] == $cur_forum['poster_id'])
		exit($lang->t('no own votes'));
	
	if ($cur_forum['poster_id'] == 1)
		exit($lang->t('no guest votes'));		

	if ($aura_user['g_rep_interval'] != '0')
	{
		$data = array(
			':id' => $aura_user['id'],
			':time'	=> (CURRENT_TIMESTAMP - $aura_user['g_rep_interval']),
		);

		$ps = $db->select('reputation', 'time_given', $data, 'given_by=:id AND time_given>:time');
		if ($ps->rowCount())
			exit($lang->t('Rep interval', $aura_user['g_rep_interval'] - (CURRENT_TIMESTAMP - $ps->fetchColumn())));
	}

	if ($vote != '-1' && $vote != '1')
		exit($lang->t('Bad request'));

	if ($vote == '-1')
	{
		if ($aura_config['o_rep_type'] == 2)
			exit($lang->t('invalid rep type'));

		$data = array(
			':uid' => $aura_user['id'],
			':id' => $id,
		);

		$ps = $db->select('reputation', 1, $data, 'post_id=:id AND given_by=:uid AND vote=-1');
		if ($ps->rowCount())
			exit($lang->t('duplicate entry minus'));

		if ($aura_user['g_rep_minus'] != '0')
		{
			$data = array(
				':id' => $aura_user['id'],
				':time'	=> (CURRENT_TIMESTAMP - 86400),
			);

			$ps = $db->select('reputation', 'COUNT(id)', $data, 'given_by=:id AND vote=-1 AND time_given>:time');
			if ($ps->fetchColumn() > $aura_user['g_rep_minus'])
				exit($lang->t('exceed negative reputation'));
		}
	}
	else
	{
		if ($aura_config['o_rep_type'] == 3)
			exit($lang->t('invalid rep type'));

		$data = array(
			':uid' => $aura_user['id'],
			':id' => $id,
		);

		$ps = $db->select('reputation', 1, $data, 'post_id=:id AND given_by=:uid AND vote=1');
		if ($ps->rowCount())
			exit($lang->t('duplicate entry positive'));

		if ($aura_user['g_rep_plus'] != '0')
		{
			$data = array(
				':id'	=>	$aura_user['id'],
				':time'	=>	(CURRENT_TIMESTAMP - 86400),
			);

			$ps = $db->select('reputation', 'COUNT(id)', $data, 'given_by=:id AND vote=1 AND time_given>:time');		
			if ($ps->fetchColumn() > $aura_user['g_rep_plus'])
				exit($lang->t('exceed positive reputation'));
		}
	}

	if ($aura_config['o_rep_abuse'] != 0)
	{
		$data = array(
			':id' => $aura_user['id'],
			':limit' => $aura_config['o_rep_abuse'],
		);
	
		$join = array(
			array(
				'type' => 'LEFT',
				'table' => 'posts',
				'as' => 'p',
				'on' => 'r.post_id=p.id',
			),
		);

		$ps = $db->join('reputation', 'r', $join, 'p.poster_id, r.vote, p.topic_id, r.id', $data, 'r.given_by=:id ORDER BY r.id DESC LIMIT :limit');
		if ($ps->rowCount())
		{
			$abuse = array('positive' => array(), 'negative' => array());
			foreach ($ps as $rep)
			{
				if ($rep['vote'] == '1') // It's a positive vote
				{
					if (array_key_exists($rep['poster_id'], $abuse['positive']))
						++$abuse['positive'][$rep['poster_id']];
					else
						$abuse['positive'][$rep['poster_id']] = '1';
				}
				else // We're issuing negative rep
				{
					if (array_key_exists($rep['poster_id'], $abuse['negative'])) // Have we already got a record of points issued for this user?
						++$abuse['negative'][$rep['poster_id']];
					else
						$abuse['negative'][$rep['poster_id']] = '1';
				}
			}

			// Here, we need to get the user ID which is stored as the array key above, so a few filters are needed first ....
			$positive = (!empty($abuse['positive'])) ? array_search(max(array_values($abuse['positive'])), $abuse['positive']) : '0';
			$negative = (!empty($abuse['negative'])) ? array_search(max(array_values($abuse['negative'])), $abuse['negative']) : '0';
			$rep_abuse = ($positive < $negative) ? array('user' => $negative, 'votes' => $abuse['negative'][$negative], 'type' => 'negative') : array('user' => $positive, 'votes' => $abuse['positive'][$positive], 'type' => 'positive');

			if ($rep_abuse['votes'] >= $aura_config['o_rep_abuse'] && $aura_config['o_mailing_list'] != '')
			{
				// Bugfix: Ticket #WYU-860-98170 - Rep Abuse alerted incorrectly
				$data = array(
					':id' => $rep_abuse['user'],
				);

				$ps = $db->select('users', 'username', $data, 'id=:id');
				$username = $ps->fetchColumn();

				$email = new email($aura_config);
				$info = array(
					'message' => array(
						'<abuser>' => $aura_user['username'],
						'<amount>' => $aura_config['o_rep_abuse'],
						'<type>' => $rep_abuse['type'],
						'<user>' => $username,
						'<profile_url>' => aura_link($aura_url['profile_rep_received'], array($rep_abuse['user'])),
					)
				);

				$mail_tpl = parse_email('rep_abuse', $aura_user['language'], $info);
				$email->send($aura_config['o_mailing_list'], $mail_tpl['subject'], $mail_tpl['message']);
			}
		}
	}
	
	($hook = get_extensions('reputation_after_rep_abuse')) ? eval($hook) : null;

	// Has the user issue issued the opposite vote? If so, remove it first ...
	$opposite_rep = false;
	
	$data = array(
		':uid' => $aura_user['id'],
		':id' => $id
	);

	$ps = $db->select('reputation', 1, $data, 'given_by=:uid AND post_id=:id');
	if ($ps->rowCount())
	{
			$opposite_rep = true;
			$vote_add = (($vote == '-1') ? '-1' : '+1');
			
			$data = array(
				':uid' => $aura_user['id'],
				':id' => $id,
			);

			$db->delete('reputation', 'given_by=:uid AND post_id=:id', $data);
			$data = array(
				':id' => $id,
			);

			$db->run('UPDATE '.$db->prefix.'posts SET reputation=reputation'.$vote_add.' WHERE id=:id', $data);
			$data = array(
				':id' => $cur_forum['poster_id'],
			);
			
			$db->run('UPDATE '.$db->prefix.'users SET reputation=reputation'.$vote_add.' WHERE id=:id', $data);
	}
	
	$insert = array(
		'post_id'	=>	$id,
		'given_by'	=>	$aura_user['id'], 
		'vote'		=>	(($vote == '-1') ? '-1' : '1'),
		'time_given'=>	CURRENT_TIMESTAMP,
	);

	$db->insert('reputation', $insert);

	$vote = (($vote == '-1') ? '-1' : '+1');
	
	$data = array(
		':id' => $cur_forum['poster_id'],
	);

	$db->run('UPDATE '.$db->prefix.'users SET reputation=reputation'.$vote.' WHERE id=:id', $data);
	
	$data = array(
		':id' => $id,
	);
	
	$db->run('UPDATE '.$db->prefix.'posts SET reputation=reputation'.$vote.' WHERE id=:id', $data);
	
	$db->end_transaction();
		
	if ($opposite_rep)
	{
		if ($vote == '-1')
			--$cur_forum['reputation'];
		else
			++$cur_forum['reputation'];		
	}

	if ($vote == '-1')
		--$cur_forum['reputation'];
	else
		++$cur_forum['reputation'];
		
		echo $cur_forum['reputation'];
}