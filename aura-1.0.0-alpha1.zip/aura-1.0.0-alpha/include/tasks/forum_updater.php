<?php
/**
 * Copyright (C) 2017 Aura (https://www.get-aura.org)
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

class task_forum_updater
{
		public function __construct($db, $aura_config, $cache)
		{
			$this->config = $aura_config;
			$this->db = $db;
			$this->cache = $cache;
		}

		public function run()
		{
			global $lang, $aura_user;

			$upgrade = new automatic_upgrade($this->config, $lang, $this->cache, $this->db);
			$result = $upgrade->run();

			$email = new email($this->config);
			if ($result['state'] == false)
			{
				if ($result['attempted']) // We only really need to log something if it's been attempted
				{
					$info = array(
						'subject' => array(
							'<version>' => $upgrade->version,
						),
						'message' => array(
							'<version>' => $upgrade->version,
							'<base_url>' => get_base_url(),
							'<message>' => $result['lang'],
						)
					);

					$mail_tpl = parse_email('upgrade_failed', $aura_user['language'], $info);
					$email->send($this->config['o_admin_email'], $mail_tpl['subject'], $mail_tpl['message']);
				}
			}
			else // Everything went ok
			{
				$info = array(
					'subject' => array(
						'<version>' => $upgrade->version,
					),
					'message' => array(
						'<version>' => $upgrade->version,
						'<base_url>' => get_base_url(),
					)
				);

				$mail_tpl = parse_email('upgrade', $aura_user['language'], $info);
				$email->send($this->config['o_admin_email'], $mail_tpl['subject'], $mail_tpl['message']);

				// Make sure we end the transaction
				$this->db->end_transaction();

				// Here we should refresh the script - updates can take a long time!
				header('Location: '.get_current_url());
				exit;
			}
		}
}