<?php
/**
 * Copyright (C) 2017 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

//
// Cookie stuff!
//
function check_cookie(&$aura_user)
{
	global $db, $aura_config;

	// If the cookie is set and it matches the correct pattern, then read the values from it
	if (isset($_COOKIE[$aura_config['o_cookie_name']]) && preg_match('%^(\d+)\|([0-9a-fA-F]+)\|(\d+)\|([0-9a-fA-F]+)$%', $_COOKIE[$aura_config['o_cookie_name']], $matches))
	{
		$cookie = array(
			'user_id'			=> intval($matches[1]),
			'password_hash' 	=> $matches[2],
			'expiration_time'	=> intval($matches[3]),
			'cookie_hash'		=> $matches[4],
		);
	}

	// If it has a non-guest user, and hasn't expired
	if (isset($cookie) && $cookie['user_id'] > 1 && $cookie['expiration_time'] > CURRENT_TIMESTAMP)
	{
		// If the cookie has been tampered with
		if (!aura_hash_equals(hash_hmac('sha512', $cookie['user_id'].'|'.$cookie['expiration_time'], $aura_config['o_cookie_seed'].'_cookie_hash'), $cookie['cookie_hash']))
		{
			$expire = CURRENT_TIMESTAMP + 31536000; // The cookie expires after a year
			aura_setcookie(1, aura_hash(uniqid(rand(), true)), $expire);
			set_default_user();

			return;
		}

		$data = array(
			':id' => $cookie['user_id'],
		);

		// Check if there's a user with the user ID and password hash from the cookie
		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'groups',
				'as' => 'g',
				'on' => 'u.group_id=g.g_id',
			),
			array(
				'type' => 'LEFT',
				'table' => 'online',
				'as' => 'o',
				'on' => 'o.user_id=u.id',
			),
		);

		$ps = $db->join('users', 'u', $join, 'u.*, g.*, o.logged, o.idle', $data, 'u.id=:id');
		$aura_user = $ps->fetch();

		// If user authorisation failed
		if (!isset($aura_user['id']) || !aura_hash_equals(hash_hmac('sha512', $aura_user['login_key'], $aura_config['o_cookie_seed'].'_password_hash'), $cookie['password_hash']))
		{
			$expire = CURRENT_TIMESTAMP + 31536000; // The cookie expires after a year
			aura_setcookie(1, aura_hash(uniqid(rand(), true)), $expire);
			set_default_user();

			return;
		}

		// Send a new, updated cookie with a new expiration timestamp
		$expire = ($cookie['expiration_time'] > CURRENT_TIMESTAMP + $aura_config['o_timeout_visit']) ? CURRENT_TIMESTAMP + 1209600 : CURRENT_TIMESTAMP + $aura_config['o_timeout_visit'];
		aura_setcookie($aura_user['id'], $aura_user['login_key'], $expire);

		// Set a default language if the user selected language no longer exists
		if (!file_exists(AURA_ROOT.'lang/'.$aura_user['language']))
			$aura_user['language'] = $aura_config['o_default_lang'];

		$style_root = (($aura_config['o_style_path'] != 'styles') ? $aura_config['o_style_path'] : AURA_ROOT.$aura_config['o_style_path']).'/';

		// Set a default style if the user selected style no longer exists
		if (!file_exists($style_root.$aura_user['style'].'.css'))
			$aura_user['style'] = $aura_config['o_default_style'];

		if (!$aura_user['disp_topics'])
			$aura_user['disp_topics'] = $aura_config['o_disp_topics_default'];

		if (!$aura_user['disp_posts'])
			$aura_user['disp_posts'] = $aura_config['o_disp_posts_default'];

		// Define this if you want this visit to affect the online list and the users last visit data
		if (!defined('AURA_QUIET_VISIT'))
		{
			// Update the online list
			if (!$aura_user['logged'])
			{
				$aura_user['logged'] = CURRENT_TIMESTAMP;
				$replace = array(
					'user_id' => $aura_user['id'],
					'ident' => $aura_user['username'],
					'logged' => $aura_user['logged'],
				);

				// REPLACE avoids a user having two rows in the online table
				$db->replace('online', $replace);

				// Reset tracked topics
				set_tracked_topics(null);
			}
			else
			{
				$data = array(
					':id' => $aura_user['id'],
				);

				// Special case: We've timed out, but no other user has browsed the forums since we timed out
				if ($aura_user['logged'] < (CURRENT_TIMESTAMP-$aura_config['o_timeout_visit']))
				{
					$update = array(
						'last_visit' => $aura_user['logged'],
					);

					$db->update('users', $update, 'id=:id', $data);
					$aura_user['last_visit'] = $aura_user['logged'];
				}

				$update = array(
					'logged' => CURRENT_TIMESTAMP,
				);

				if ($aura_user['idle'] == '1')
					$update['idle'] = 0;

				$db->update('online', $update, 'user_id=:id', $data);

				// Update tracked topics with the current expire time
				if (isset($_COOKIE[$aura_config['o_cookie_name'].'_track']))
					forum_setcookie($aura_config['o_cookie_name'].'_track', $_COOKIE[$aura_config['o_cookie_name'].'_track'], CURRENT_TIMESTAMP + $aura_config['o_timeout_visit']);
			}
		}
		else
		{
			if (!$aura_user['logged'])
				$aura_user['logged'] = $aura_user['last_visit'];
		}

		$aura_user['is_guest'] = false;
		$aura_user['is_admmod'] = $aura_user['g_id'] == AURA_ADMIN || $aura_user['g_moderator'] == '1';
		$aura_user['is_admin'] = $aura_user['g_id'] == AURA_ADMIN || $aura_user['g_moderator'] == '1' && $aura_user['g_admin'] == '1';
		$aura_user['is_bot'] = false;
	}
	else
		set_default_user();
}

function aura_hash_equals($hash, $input)
{
	if (function_exists('hash_equals'))
		return hash_equals((string)$hash, $input);

	$input_length = strlen($input);
	if ($input_length !== strlen($hash))
		return false;

	$result = 0;
	for ($i = 0; $i < $input_length; $i++)
		$result |= ord($input[$i]) ^ ord($hash[$i]);

	return $result === 0;
}


//
// Try to determine the current URL
//
function get_current_url($max_length = 0)
{
	$protocol = get_current_protocol();
	$port = (isset($_SERVER['SERVER_PORT']) && (($_SERVER['SERVER_PORT'] != '80' && $protocol == 'http') || ($_SERVER['SERVER_PORT'] != '443' && $protocol == 'https')) && strpos($_SERVER['HTTP_HOST'], ':') === false) ? ':'.$_SERVER['SERVER_PORT'] : '';

	$url = urldecode($protocol.'://'.$_SERVER['HTTP_HOST'].$port.$_SERVER['REQUEST_URI']);

	if (strlen($url) <= $max_length || $max_length == 0)
		return $url;

	// We can't find a short enough url
	return null;
}

//
// Fetch the current protocol in use - http or https
//
function get_current_protocol()
{
	$protocol = 'http';

	// Check if the server is claiming to using HTTPS
	if (!empty($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS']) != 'off')
		$protocol = 'https';

	// If we are behind a reverse proxy try to decide which protocol it is using
	if (defined('FORUM_BEHIND_REVERSE_PROXY'))
	{
		// Check if we are behind a Microsoft based reverse proxy
		if (!empty($_SERVER['HTTP_FRONT_END_HTTPS']) && strtolower($_SERVER['HTTP_FRONT_END_HTTPS']) != 'off')
			$protocol = 'https';

		// Check if we're behind a "proper" reverse proxy, and what protocol it's using
		if (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']))
			$protocol = strtolower($_SERVER['HTTP_X_FORWARDED_PROTO']);
	}

	return $protocol;
}

function check_ssl_state()
{
	global $aura_config;
	if ($aura_config['o_force_ssl'] == '1' && get_current_protocol() == 'http')
	{
		header('Location: '.str_replace('http://', 'https://', get_current_url()));
		exit;
	}
}

//
// Fetch the base_url, optionally support HTTPS and HTTP
//
function get_base_url($support_https = true)
{
	global $aura_config;
	static $base_url;

	if (!$support_https)
		return $aura_config['o_base_url'];

	if (!isset($base_url))
	{
		// Make sure we are using the correct protocol
		$base_url = str_replace(array('http://', 'https://'), get_current_protocol().'://', $aura_config['o_base_url']);
	}

	return $base_url;
}

//
// Fill $aura_user with default values (for guests)
//
function set_default_user()
{
	global $db, $aura_user, $aura_config;

	$remote_addr = get_remote_address();
	$remote_addr = isbotex($remote_addr);

	$data = array(
		':ident' => $remote_addr,
	);

	$join = array(
		array(
			'type' => 'INNER',
			'table' => 'groups',
			'as' => 'g',
			'on' => 'u.group_id=g.g_id',
		),
		array(
			'type' => 'LEFT',
			'table' => 'online',
			'as' => 'o',
			'on' => 'o.ident=:ident',
		),
	);

	// Fetch guest user
	$ps = $db->join('users', 'u', $join, 'u.*, g.*, o.logged, o.last_post, o.last_search', $data, 'u.id=1');
	if (!$ps->rowCount())
		throw new Exception('Unable to fetch guest information. Your database must contain both a guest user and a guest user group.');

	$aura_user = $ps->fetch();

	// Update online list
	if (!$aura_user['logged'])
	{
		$aura_user['logged'] = CURRENT_TIMESTAMP;
		$replace = array(
			'user_id' => 1,
			'ident' => $remote_addr,
			'logged' => $aura_user['logged'],
		);

		// REPLACE avoids a user having two rows in the online table
		$db->replace('online', $replace);
	}
	else
	{
		$update = array(
			'logged' => CURRENT_TIMESTAMP,
		);

		$data = array(
			':ident' => $remote_addr,
		);

		$db->update('online', $update, 'ident=:ident', $data);
	}

	$aura_user['disp_topics'] = $aura_config['o_disp_topics_default'];
	$aura_user['disp_posts'] = $aura_config['o_disp_posts_default'];
	$aura_user['timezone'] = $aura_config['o_default_timezone'];
	$aura_user['dst'] = $aura_config['o_default_dst'];
	$aura_user['language'] = $aura_config['o_default_lang'];
	$aura_user['style'] = $aura_config['o_default_style'];
	$aura_user['is_guest'] = true;
	$aura_user['is_admmod'] = false;
	$aura_user['is_admin'] = false;
	$aura_user['is_bot'] = (strpos($remote_addr, '[Bot]') !== false);
}

//
// Set a cookie, Panther style!
// Wrapper for forum_setcookie
//
function aura_setcookie($user_id, $password_hash, $expire)
{
	global $aura_config;
	forum_setcookie($aura_config['o_cookie_name'], $user_id.'|'.hash_hmac('sha512', $password_hash, $aura_config['o_cookie_seed'].'_password_hash').'|'.$expire.'|'.hash_hmac('sha512', $user_id.'|'.$expire, $aura_config['o_cookie_seed'].'_cookie_hash'), $expire);
}

//
// Set a cookie, Panther style!
//
function forum_setcookie($name, $value, $expire)
{
	global $aura_config;

	if ($expire - CURRENT_TIMESTAMP - $aura_config['o_timeout_visit'] < 1)
		$expire = 0;

	// Enable sending of a P3P header
	header('P3P: CP="CUR ADM"');
	setcookie($name, $value, $expire, $aura_config['o_cookie_path'], $aura_config['o_cookie_domain'], $aura_config['o_cookie_secure'], true);
}

//
// Check whether the connecting user is banned (and delete any expired bans while we're at it)
//
function check_bans()
{
	global $db, $cache, $aura_config, $lang, $aura_user, $aura_bans;

	// Admins and moderators aren't affected
	if ($aura_user['is_admmod'] || !$aura_bans || defined('AURA_TURN_OFF_BANS'))
		return;

	// Add a dot or a colon (depending on IPv4/IPv6) at the end of the IP address to prevent banned address
	// 192.168.0.5 from matching e.g. 192.168.0.50
	$user_ip = get_remote_address();
	$user_ip .= (strpos($user_ip, '.') !== false) ? '.' : ':';

	$bans_altered = false;
	$is_banned = false;

	foreach ($aura_bans as $cur_ban)
	{
		// Has this ban expired?
		if ($cur_ban['expire'] != '' && $cur_ban['expire'] <= CURRENT_TIMESTAMP)
		{
			$data = array(
				':id' => $cur_ban['id'],
			);

			$db->delete('bans', 'id=:id', $data);
			$bans_altered = true;
			continue;
		}

		if ($cur_ban['username'] != '' && utf8_strtolower($aura_user['username']) == utf8_strtolower($cur_ban['username']))
			$is_banned = true;

		if ($cur_ban['ip'] != '')
		{
			$cur_ban_ips = explode(' ', $cur_ban['ip']);

			$num_ips = count($cur_ban_ips);
			for ($i = 0; $i < $num_ips; ++$i)
			{
				// Add the proper ending to the ban
				if (strpos($user_ip, '.') !== false)
					$cur_ban_ips[$i] = $cur_ban_ips[$i].'.';
				else
					$cur_ban_ips[$i] = $cur_ban_ips[$i].':';

				if (substr($user_ip, 0, strlen($cur_ban_ips[$i])) == $cur_ban_ips[$i])
				{
					$is_banned = true;
					break;
				}
			}
		}

		if ($is_banned)
		{
			$data = array(
				':ident' => $aura_user['username'],
			);

			$db->delete('online', 'ident=:ident', $data);
			message($lang->t('Ban message').' '.(($cur_ban['expire'] != '') ? $lang->t('Ban message 2').' '.strtolower(format_time($cur_ban['expire'])).'. ' : '').(($cur_ban['message'] != '') ? $lang->t('Ban message 3').'<br /><br /><strong>'.$cur_ban['message'].'</strong><br /><br />' : '<br /><br />').$lang->t('Ban message 4').' '.$aura_config['o_admin_email'], true);
		}
	}

	// If we removed any expired bans during our run-through, we need to regenerate the bans cache
	if ($bans_altered)
		$cache->generate('bans');
}

//
// Check for a banned email address
//
function is_banned_email($email)
{
	global $aura_bans;

	foreach ($aura_bans as $cur_ban)
	{
		if ($cur_ban['email'] != '' && ($email == $cur_ban['email'] || (strpos($cur_ban['email'], '@') === false && stristr($email, '@'.$cur_ban['email']))))
			return true;
	}

	return false;
}

//
// Check username
//
function check_username($username, $exclude_id = null)
{
	global $db, $aura_config, $errors, $lang, $aura_bans;

	// Include UTF-8 function
	require_once AURA_ROOT.'include/lib/utf8/strcasecmp.php';

	// Convert multiple whitespace characters into one (to prevent people from registering with indistinguishable usernames)
	$username = preg_replace('%\s+%s', ' ', $username);

	// Validate username
	if (aura_strlen($username) < 2)
		$errors[] = $lang->t('Username too short');
	else if (aura_strlen($username) > 25) // This usually doesn't happen since the form element only accepts 25 characters
		$errors[] = $lang->t('Username too long');
	else if (!strcasecmp($username, 'Guest') || !utf8_strcasecmp($username, $lang->t('Guest')))
		$errors[] = $lang->t('Username guest');
	else if (preg_match('%[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}%', $username) || preg_match('%((([0-9A-Fa-f]{1,4}:){7}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){6}:[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){5}:([0-9A-Fa-f]{1,4}:)?[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){4}:([0-9A-Fa-f]{1,4}:){0,2}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){3}:([0-9A-Fa-f]{1,4}:){0,3}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){2}:([0-9A-Fa-f]{1,4}:){0,4}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){6}((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|(([0-9A-Fa-f]{1,4}:){0,5}:((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|(::([0-9A-Fa-f]{1,4}:){0,5}((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|([0-9A-Fa-f]{1,4}::([0-9A-Fa-f]{1,4}:){0,5}[0-9A-Fa-f]{1,4})|(::([0-9A-Fa-f]{1,4}:){0,6}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){1,7}:))%', $username))
		$errors[] = $lang->t('Username IP');
	else if ((strpos($username, '[') !== false || strpos($username, ']') !== false) && strpos($username, '\'') !== false && strpos($username, '"') !== false)
		$errors[] = $lang->t('Username reserved chars');
	else if (preg_match('%(?:\[/?(?:b|u|s|ins|del|em|i|h|colou?r|quote|code|img|url|email|list|\*|topic|post|forum|user)\]|\[(?:img|url|quote|list)=)%i', $username))
		$errors[] = $lang->t('Username BBCode');

	// Check username for any censored words
	if ($aura_config['o_censoring'] == '1' && censor_words($username) != $username)
		$errors[] = $lang->t('Username censor');

	$where_cond = '(UPPER(username)=UPPER(:username) OR UPPER(username)=UPPER(:username2)) AND id>1';
	
	$data = array(
		':username'	=> $username,
		':username2' => ucp_preg_replace('%[^\p{L}\p{N}]%u', '', $username),
	);

	// Check that the username (or a too similar username) is not already registered
	if (!is_null($exclude_id))
	{
		$where_cond .= ' AND id!=:id';
		$data[':id'] = $exclude_id;
	}

	$ps = $db->select('users', 'username', $data, $where_cond);
	if ($ps->rowCount())
	{
		$busy = $ps->fetchColumn();
		$errors[] = $lang->t('Username dupe 1').' '.$busy.'. '.$lang->t('Username dupe 2');
	}

	// Check username for any banned usernames
	foreach ($aura_bans as $cur_ban)
	{
		if ($cur_ban['username'] != '' && utf8_strtolower($username) == utf8_strtolower($cur_ban['username']))
		{
			$errors[] = $lang->t('Banned username');
			break;
		}
	}
}

//
// Validates a password against the forum password requirements
//

function validate_password($password1, $password2)
{
	global $aura_config, $lang;

	$errors = array();
	if (aura_strlen($password1) < $aura_config['o_password_min_length'])
		$errors[] = $lang->t('Password too short', $aura_config['o_password_min_length']);
	else if (!aura_hash_equals($password1, $password2))
		$errors[] = $lang->t('Passwords do not match');
	else if (aura_strlen(preg_replace('/[^0-9]/', '', $password1)) < $aura_config['o_password_min_digits'])
		$errors[] = $lang->t('Password no digits', $aura_config['o_password_min_digits']);
	else if (aura_strlen(preg_replace('/[^A-Z]/', '', $password1)) < $aura_config['o_password_min_uppercase'])
		$errors[] = $lang->t('Password no uppercase', $aura_config['o_password_min_uppercase']);
	else if (utf8_strlen(preg_replace('/[0-9A-Za-z]/', '', $password1)) < $aura_config['o_password_min_symbols'])
		$errors[] = $lang->t('Password no symbols', $aura_config['o_password_min_symbols']);

	return $errors;
}

//
// Update "Users online"
//
function update_users_online()
{
	global $db, $aura_config, $aura_user;

	$cur_position = substr($_SERVER['REQUEST_URI'], 1);
	$server_base = dirname($_SERVER['PHP_SELF']);

	if ($server_base !== '/')
		$cur_position = substr($cur_position, strlen($server_base));

	$cur_position = ($cur_position == '') ? 'index.php' : $cur_position;
	$online['users'] = $online['guests'] = array();

	$join = array(
		array(
			'type' => 'LEFT',
			'table' => 'users',
			'as' => 'u',
			'on' => 'o.user_id=u.id',
		),
	);

	// Fetch all online list entries that are older than "o_timeout_online"
	$ps = $db->join('online', 'o', $join, 'o.user_id, o.ident, o.logged, o.idle, u.group_id');
	foreach ($ps as $cur_user)
	{
		if ($cur_user['logged'] < (CURRENT_TIMESTAMP - $aura_config['o_timeout_online']))
		{
			// If the entry is a guest, delete it
			if ($cur_user['user_id'] == '1')
			{
				$data = array(
					':ident' => $cur_user['ident']
				);

				$db->delete('online', 'ident=:ident', $data);
			}
			else
			{
				// If the entry is older than "o_timeout_visit", update last_visit for the user in question, then delete him/her from the online list
				if ($cur_user['logged'] < (CURRENT_TIMESTAMP - $aura_config['o_timeout_visit']))
				{
					$update = array(
						'last_visit' => $cur_user['logged'],
					);
					
					$data = array(
						':id' => $cur_user['user_id'],
					);
					
					$db->update('users', $update, 'id=:id', $data);
					$db->delete('online', 'user_id=:id', $data);
				}
			}
		}
		else
		{
			if ($cur_user['user_id'] == 1)
				$online['guests'][] = array('ident' => $cur_user['ident'], 'group_id' => AURA_GUEST);
			else
				$online['users'][$cur_user['user_id']] = array('username' => $cur_user['ident'], 'group_id' => $cur_user['group_id'], 'id' => $cur_user['user_id']);
		}
	}

	if (!$aura_user['is_bot'])
	{
		$update = array(
			'currently'	=> generate_location($cur_position),
		);

		$data = array();
		if ($aura_user['is_guest'])
		{
			$field = 'ident';
			$data[':ident'] = get_remote_address();
		}
		else
		{
			$field = 'user_id';
			$data[':ident'] = $aura_user['id'];
		}

		$db->update('online', $update, $field.'=:ident', $data);
	}

	return $online;
}

//
// Display the profile navigation menu
//
function generate_profile_menu($page = '')
{
	global $lang, $aura_config, $aura_user, $id, $aura_url;
	
	$sections = array(
		array('page' => 'essentials', 'link' => aura_link($aura_url['profile_essentials'], array($id)), 'lang' => $lang->t('Section essentials')),
		array('page' => 'personal', 'link' => aura_link($aura_url['profile_personal'], array($id)), 'lang' => $lang->t('Section personal')),
		array('page' => 'messaging', 'link' => aura_link($aura_url['profile_messaging'], array($id)), 'lang' => $lang->t('Section messaging')),
	);

	if ($aura_config['o_avatars'] == '1' || $aura_config['o_signatures'] == '1')
		$sections[] = array('page' => 'personality', 'link' => aura_link($aura_url['profile_personality'], array($id)), 'lang' => $lang->t('Section personality'));

	$sections[] = array('page' => 'display', 'link' => aura_link($aura_url['profile_display'], array($id)), 'lang' => $lang->t('Section display'));
	$sections[] = array('page' => 'privacy', 'link' => aura_link($aura_url['profile_privacy'], array($id)), 'lang' => $lang->t('Section privacy'));

	if ($aura_config['o_attachments'] == '1')
		$sections[] = array('page' => 'attachments', 'link' => aura_link($aura_url['profile_attachments'], array($id)), 'lang' => $lang->t('Section attachments'));

	$sections[] = array('page' => 'view', 'link' => aura_link($aura_url['profile_view'], array($id)), 'lang' => $lang->t('Section view'));

	if ($aura_user['is_admin'] || ($aura_user['g_moderator'] == '1' && $aura_user['g_mod_ban_users'] == '1'))
		$sections[] = array('page' => 'admin', 'link' => aura_link($aura_url['profile_admin'], array($id)), 'lang' => $lang->t('Section admin'));

	$tpl = load_template('profile_sidebar.tpl');
	echo $tpl->render(
		array(
			'lang' => $lang,
			'sections' => $sections,
			'page' => $page,
		)
	);
}

//
// Display PM menu
//

function generate_pm_menu($page = 2) // Default to inbox
{
	global $aura_url, $lang, $aura_user, $db;
	static $folders;

	$percent = ($aura_user['g_pm_limit'] != '0') ? round(ceil($aura_user['num_pms'] / $aura_user['g_pm_limit']*100), 0) : 0;
	$limit = ($aura_user['g_pm_limit'] == '0') ? '&infin;' : $aura_user['g_pm_limit'];
	
	$data = array(
		':uid'	=>	$aura_user['id'],
	);

	$folders = array();
	$ps = $db->select('folders', 'name, id', $data, 'user_id=:uid OR user_id=1', 'id, user_id ASC');
	foreach ($ps as $folder)
	{
		$data = array(
			':id'	=>	$folder['id'],
			':uid'	=>	$aura_user['id'],
		);

		$ps1 = $db->select('pms_data', 'COUNT(topic_id)', $data, 'user_id=:uid AND deleted=0 AND (folder_id=:id '.(($folder['id'] == 1) ? 'OR viewed=0)' : ')'));
		$amount = $ps1->fetchColumn();

		$folders[] = array(
			'id' => $folder['id'],
			'link' => aura_link($aura_url['box'], array($folder['id'])),
			'name' => $folder['name'],
			'amount' => $amount,
		);
	}
	
	$tpl = load_template('pm_sidebar.tpl');
	return $tpl->render(
		array(
			'lang' => $lang,
			'folders' => $folders,
			'percent' => $percent,
			'num_pms' => forum_number_format($aura_user['num_pms']),
			'limit' => forum_number_format($limit),
			'blocked_link' => aura_link($aura_url['pms_blocked']),
			'folders_link' => aura_link($aura_url['pms_folders']),
			'page' => $page,
		)
	);
}

//
// Outputs markup to display a user's avatar
//
function generate_avatar_markup($user_id, $user_email, $use_gravatar = 0, $size = array())
{
	global $aura_config;
	static $user_avatar_cache = array();

	if (!isset($user_avatar_cache[$user_id]))
	{
		$avatar_path = ($aura_config['o_avatars_dir'] != '') ? $aura_config['o_avatars_path'] : AURA_ROOT.$aura_config['o_avatars_path'];
		$avatar_dir = ($aura_config['o_avatars_dir'] != '') ? $aura_config['o_avatars_dir'] : get_base_url().'/'.$aura_config['o_avatars_path'];

		if ($use_gravatar == 1)
		{
			$params = count($size) == 2 ? array($size[0], $size[1]) : array($aura_config['o_avatars_width'], $aura_config['o_avatars_height']);
			$avatar = array('https://www.gravatar.com/avatar.php?gravatar_id='.md5(strtolower($user_email)).'&amp;size='.$params[0], $params[0], $params[1], '');
		}
		else if ($aura_config['o_avatar_upload'] == '1')
		{
			$filetypes = array('jpg', 'gif', 'png');
			foreach ($filetypes as $cur_type)
			{
				$path = $avatar_path.$user_id.'.'.$cur_type;
				$url = $avatar_dir.$user_id.'.'.$cur_type;
				if (file_exists($path) && $img_size = getimagesize($path))
				{
					$size = count($size) == 2 ? array($size[0], $size[1]) : array($img_size[0], $img_size[1]);
					$avatar = array($url.'?m='.filemtime($path), $size[0], $size[1], '');
					break;
				}
			}
		}

		// If there's no avatar set, we mustn't have one uploaded. Set the default!
		if (!isset($avatar))
		{
			$path = $avatar_path.'1.'.$aura_config['o_avatar'];
			$url = $avatar_dir.'1.'.$aura_config['o_avatar'];
			$img_size = getimagesize($path);

			$size = count($size) == 2 ? array($size[0], $size[1]) : array($img_size[0], $img_size[1]);
			$avatar = array($url.'?m='.filemtime($path), $size[0], $size[1], '');
		}

		$user_avatar_cache[$user_id] = style_html('avatar_string', $avatar);
	}

	return $user_avatar_cache[$user_id];
}

//
// Generate browser's title
//
function generate_page_title($page_title, $p = null)
{
	global $lang;

	if (!is_array($page_title))
		$page_title = array($page_title);

	$page_title = array_reverse($page_title);

	if ($p > 1)
		$page_title[0] .= ' ('.$lang->t('Page', forum_number_format($p)).')';

	$crumbs = implode($lang->t('Title separator'), $page_title);

	return $crumbs;
}

//
// Save array of tracked topics in cookie
//
function set_tracked_topics($tracked_topics)
{
	global $aura_config;

	$cookie_data = '';
	if (!empty($tracked_topics))
	{
		// Sort the arrays (latest read first)
		arsort($tracked_topics['topics'], SORT_NUMERIC);
		arsort($tracked_topics['forums'], SORT_NUMERIC);

		// Homebrew serialization (to avoid having to run unserialize() on cookie data)
		foreach ($tracked_topics['topics'] as $id => $timestamp)
			$cookie_data .= 't'.$id.'='.$timestamp.';';
		foreach ($tracked_topics['forums'] as $id => $timestamp)
			$cookie_data .= 'f'.$id.'='.$timestamp.';';

		// Enforce a byte size limit (4096 minus some space for the cookie name - defaults to 4048)
		if (strlen($cookie_data) > FORUM_MAX_COOKIE_SIZE)
		{
			$cookie_data = substr($cookie_data, 0, FORUM_MAX_COOKIE_SIZE);
			$cookie_data = substr($cookie_data, 0, strrpos($cookie_data, ';')).';';
		}
	}

	forum_setcookie($aura_config['o_cookie_name'].'_track', $cookie_data, CURRENT_TIMESTAMP + $aura_config['o_timeout_visit']);
	$_COOKIE[$aura_config['o_cookie_name'].'_track'] = $cookie_data; // Set it directly in $_COOKIE as well
}

//
// Extract array of tracked topics from cookie
//
function get_tracked_topics()
{
	global $aura_config;

	$cookie_data = isset($_COOKIE[$aura_config['o_cookie_name'].'_track']) ? $_COOKIE[$aura_config['o_cookie_name'].'_track'] : false;
	if (!$cookie_data)
		return array('topics' => array(), 'forums' => array());

	if (strlen($cookie_data) > FORUM_MAX_COOKIE_SIZE)
		return array('topics' => array(), 'forums' => array());

	// Unserialize data from cookie
	$tracked_topics = array('topics' => array(), 'forums' => array());
	$temp = explode(';', $cookie_data);
	foreach ($temp as $t)
	{
		$type = substr($t, 0, 1) == 'f' ? 'forums' : 'topics';
		$id = intval(substr($t, 1));
		$timestamp = intval(substr($t, strpos($t, '=') + 1));
		if ($id > 0 && $timestamp > 0)
			$tracked_topics[$type][$id] = $timestamp;
	}

	return $tracked_topics;
}

//
// Update posts, topics, last_post, last_post_id and last_poster for a forum
//
function update_forum($forum_id)
{
	global $db;
	$data = array(
		':id'	=>	$forum_id,
	);

	$ps = $db->select('topics', 'COUNT(id), SUM(num_replies)', $data, 'forum_id=:id AND approved=1 AND deleted=0');
	list($num_topics, $num_posts) = $ps->fetch(PDO::FETCH_NUM);

	$num_posts = $num_posts + $num_topics; // $num_posts is only the sum of all replies (we have to add the topic posts)
	$data = array(
		':id' => $forum_id
	);

	$ps = $db->select('topics', 'last_post, last_post_id, last_poster, subject, id', $data, 'forum_id=:id AND approved=1 AND deleted=0 AND moved_to IS NULL ORDER BY last_post DESC LIMIT 1');
	if ($ps->rowCount()) // There are topics in the forum
	{
		list($last_post, $last_post_id, $last_poster, $last_topic, $last_topic_id) = $ps->fetch(PDO::FETCH_NUM);
		$update = array(
			'num_topics'	=>	$num_topics,
			'num_posts'		=>	$num_posts,
			'last_post'		=>	$last_post,
			'last_post_id'	=>	$last_post_id,
			'last_topic'	=>	$last_topic,
			'last_topic_id'	=>	$last_topic_id,
			'last_poster'	=>	$last_poster,
		);

		$data = array(
			':id' => $forum_id,
		);

		$db->update('forums', $update, 'id=:id', $data);
	}
	else // There are no topics
	{
		$data = array(
			':num_topics'	=>	$num_topics,
			':num_posts'	=>	$num_posts,
			':id'		=>	$forum_id,
		);

		// Annoyingly PDO does not allow NULL values to be added in prepared statements. When added it becomes 'NULL', so we have to run the query manually instead
		$db->run('UPDATE '.$db->prefix.'forums SET num_topics=:num_topics, num_posts=:num_posts, last_post=NULL, last_post_id=NULL, last_poster=NULL, last_topic=\'\', last_topic_id=0 WHERE id=:id', $data);
	}
}

//
// Deletes any avatars owned by the specified user ID
//
function delete_avatar($user_id)
{
	global $aura_config;

	$filetypes = array('jpg', 'gif', 'png');
	$avatar_path = ($aura_config['o_avatars_dir'] != '') ? $aura_config['o_avatars_path'] : AURA_ROOT.$aura_config['o_avatars_path'];

	// Delete user avatar
	foreach ($filetypes as $cur_type)
	{
		if (file_exists($avatar_path.$user_id.'.'.$cur_type))
			@unlink($avatar_path.$user_id.'.'.$cur_type);
	}
}

//
// Delete a topic and all of its posts
//
function delete_topic($topic_id)
{
	global $db, $aura_config;

	// Delete the topic and any redirect topics
	attach_delete_thread($topic_id);
	$data = array(
		':id'	=>	$topic_id,
	);

	$topic = array(
		':id'	=>	$topic_id,
		':moved_to'	=>	$topic_id,
	);

	$update = array(
		'deleted'	=>	1,
	);

	$post_ids = array();
	$db->update('topics', $update, 'id=:id OR moved_to=:moved_to', $topic);
	$db->delete('polls', 'topic_id=:id', $data);

	// Get all post IDs from this topic.
	$markers = array();
	$ps = $db->select('posts', 'id', $data, 'topic_id=:id');
	foreach ($ps as $cur_post)
	{
		$post_ids[] = $cur_post['id'];
		$markers[] = '?';
	}

	// Make sure we have a list of post IDs
	if (!empty($post_ids))
	{
		strip_search_index($post_ids);
		$db->update('posts', $update, 'topic_id=:id', $data);

		$db->delete('reputation', 'post_id IN ('.implode(', ', $markers).')', $post_ids);
	}

	if ($aura_config['o_delete_full'] == '1')
		permanently_delete_topic($topic_id);
}

//
// Delete a single post
//
function delete_post($post_id, $topic_id)
{
	global $db, $aura_config;
	$topic_data = array(
		':id'	=>	$topic_id,
	);	

	$post_data = array(
		':id'	=>	$post_id,
	);

	$ps = $db->select('posts', 'id, poster, posted', $topic_data, 'topic_id=:id AND approved=1 AND deleted=0', 'id DESC LIMIT 2');
	list($last_id, ,) = $ps->fetch(PDO::FETCH_NUM);
	list($second_last_id, $second_poster, $second_posted) = $ps->fetch(PDO::FETCH_NUM);

	// Delete the post
	attach_delete_post($post_id);
	$update = array(
		'deleted' => 1,
	);

	$db->update('posts', $update, 'id=:id', $post_data);
	strip_search_index(array($post_id));

	// Count number of replies in the topic
	$ps = $db->select('posts', 'COUNT(id)', $topic_data, 'topic_id=:id AND approved=1 AND deleted=0');
	$num_replies = $ps->fetchColumn() - 1; // Decrement the deleted post

	// If the message we deleted is the most recent in the topic (at the end of the topic)
	if ($last_id == $post_id)
	{
		// If there is a $second_last_id there is more than 1 reply to the topic
		if (!empty($second_last_id))
		{
			$update = array(
				'last_post'	=>	$second_posted,
				'last_post_id'	=>	$second_last_id,
				'last_poster'	=>	$second_poster,
				'num_replies'	=>	$num_replies,
			);

			$data = array(
				':id' => $topic_id,
			);

			$db->update('topics', $update, 'id=:id', $data);
		}
		else
		{
			$data = array(
				':id'	=>	$topic_id,
				':num_replies'	=>	$num_replies-1,
			);

			// We deleted the only reply, so now last_post/last_post_id/last_poster is posted/id/poster from the topic itself
			$db->run('UPDATE '.$db->prefix.'topics SET last_post=posted, last_post_id=id, last_poster=poster, num_replies=:num_replies WHERE id=:id', $data);
		}
	}
	else	// Otherwise we just decrement the reply counter
	{
		$update = array(
			'num_replies' => $num_replies,
		);

		$db->update('topics', $update, 'id=:id', $topic_data);
	}

	$db->delete('reputation', 'post_id=:id', $post_data);
	if ($aura_config['o_delete_full'] == '1')
		permanently_delete_post($post_id);
}

//
// Permanently delete a single post
//
function permanently_delete_post($id)
{
	global $db;
	$data = array(
		':id' => $id,
	);

	$db->delete('posts', 'id=:id AND deleted=1', $data); // Since we've already stripped the search index, all we need to do is delete the row
}

//
// Permanently delete a topic
//
function permanently_delete_topic($id)
{
	global $db;
	$data = array(
		':id'	=>	$id,
		':moved_to'	=>	$id,
	);

	$db->delete('topics', '(id=:id OR moved_to=:moved_to) AND deleted=1', $data);
	unset($data[':moved_to']);
	$db->delete('posts', 'topic_id=? AND deleted=1', array_values($data));

	// Delete any subscriptions for this topic
	$db->delete('topic_subscriptions', 'topic_id=?', array_values($data));
}

//
// Replace censored words in $text
//
function censor_words($text)
{
	global $db, $cache;
	static $search_for, $replace_with;

	// If not already built in a previous call, build an array of censor words and their replacement text
	if (!isset($search_for))
		list ($search_for, $replace_with) = $cache->get('censoring');

	if (!empty($search_for))
		$text = substr(ucp_preg_replace($search_for, $replace_with, ' '.$text.' '), 1, -1);

	return $text;
}

//
// Determines the correct title for $user
// $user must contain the elements 'username', 'title', 'posts', 'g_id' and 'g_user_title'
//
function get_title($user)
{
	global $aura_bans, $lang, $cache, $aura_config;
	static $ban_list, $aura_ranks;

	// If not already built in a previous call, build an array of lowercase banned usernames
	if (!isset($ban_list))
	{
		$ban_list = array();
		foreach ($aura_bans as $cur_ban)
			$ban_list[] = utf8_strtolower($cur_ban['username']);
	}

	// If not already loaded in a previous call, load the cached ranks
	if ($aura_config['o_ranks'] == '1' && !isset($aura_ranks))
		$aura_ranks = $cache->get('ranks');

	// If the user is banned
	if (in_array(utf8_strtolower($user['username']), $ban_list))
		$user_title = $lang->t('Banned');
	// If the user has a custom title
	else if ($user['title'] != '')
		$user_title = $user['title'];
	// If the user group has a default user title
	else if ($user['g_user_title'] != '')
		$user_title = $user['g_user_title'];
	// If the user is a guest
	else if ($user['g_id'] == AURA_GUEST)
		$user_title = $lang->t('Guest');
	// If nothing else helps, we assign the default
	else
	{
		// Are there any ranks?
		if ($aura_config['o_ranks'] == '1' && !empty($aura_ranks))
		{
			foreach ($aura_ranks as $cur_rank)
			{
				if ($user['num_posts'] >= $cur_rank['min_posts'])
					$user_title = $cur_rank['rank'];
			}
		}

		// If the user didn't "reach" any rank (or if ranks are disabled), we assign the default
		if (!isset($user_title))
		  $user_title = $lang->t('Member');
	}

	return $user_title;
}

//
// Generate a string with numbered links (for multipage scripts)
//
function paginate($num_pages, $cur_page, $link, $args = null)
{
	global $lang, $aura_config, $aura_url;

	$pages = array();
	$link_to_all = false;

	// If $cur_page == -1, we link to all pages (used in viewforum.php)
	if ($cur_page == -1)
	{
		$cur_page = 1;
		$link_to_all = true;
	}

	if ($num_pages > 1)
	{
		if ($cur_page > 1)
			$pages[] = array('item' => true, 'href' => get_sublink($link, $aura_url['page'], ($cur_page - 1), $args), 'current' => $lang->t('Previous'));

		if ($cur_page > 3)
		{
			$pages[] = array('item' => (empty($pages) ? true : false), 'href' => get_sublink($link, $aura_url['page'], 1, $args), 'current' => 1);
			if ($cur_page > 5)
				$pages[] = $lang->t('Spacer');
		}

		// Don't ask me how the following works. It just does, OK? =)
		for ($current = ($cur_page == 5) ? $cur_page - 3 : $cur_page - 2, $stop = ($cur_page + 4 == $num_pages) ? $cur_page + 4 : $cur_page + 3; $current < $stop; ++$current)
		{
			if ($current < 1 || $current > $num_pages)
				continue;
			else if ($current != $cur_page || $link_to_all)
				$pages[] = array('item' => (empty($pages) ? true : false), 'href' => get_sublink($link, $aura_url['page'], $current, $args), 'current' => forum_number_format($current));
			else
				$pages[] = array('item' => (empty($pages) ? true : false), 'current' => forum_number_format($current));
		}

		if ($cur_page <= ($num_pages-3))
		{
			if ($cur_page != ($num_pages-3) && $cur_page != ($num_pages-4))
				$pages[] = $lang->t('Spacer');

			$pages[] = array('item' => (empty($pages) ? true : false), 'href' => get_sublink($link, $aura_url['page'], $num_pages, $args), 'current' => forum_number_format($num_pages));
		}

		// Add a next page link
		if ($num_pages > 1 && !$link_to_all && $cur_page < $num_pages)
			$pages[] = array('item' => (empty($pages) ? true : false), 'rel' => 'next', 'href' => get_sublink($link, $aura_url['page'], ($cur_page + 1), $args), 'current' => $lang->t('Next'));
	}

	$tpl = load_template('pagination.tpl');
	return $tpl->render(
		array(
			'num_pages' => $num_pages,
			'cur_page' => $cur_page,
			'pages' => $pages,
			'link' => $link,
		)
	);
}

//
// Display a message
//
function message($message, $no_back_link = false, $http_status = null)
{
	global $db, $lang, $aura_config, $aura_start, $tpl_main, $aura_user, $aura_url, $cache;

	// Did we receive a custom header?
	if (!is_null($http_status))
		header('HTTP/1.1 '.$http_status);

	if (!defined('AURA_HEADER'))
	{
		$page_title = array($aura_config['o_board_title'], $lang->t('Info'));
		define('AURA_ACTIVE_PAGE', 'index');
		require AURA_ROOT.'header.php';
	}

	$tpl = load_template('message.tpl');
	echo $tpl->render(
		array(
			'lang' => $lang,
			'message' => $message,
			'no_back_link' => $no_back_link,
		)
	);

	require AURA_ROOT.'footer.php';
}

//
// Format a time string according to $time_format and time zones
//
function format_time($timestamp, $date_only = false, $date_format = null, $time_format = null, $time_only = false, $no_text = false)
{
	global $lang, $aura_user, $aura_config;

	if ($timestamp == '')
		return $lang->t('Never');

	$diff = ($aura_user['timezone'] + $aura_user['dst']) * 3600;
	$timestamp += $diff;

	if (is_null($date_format))
		$date_format = $aura_config['o_date_formats'][$aura_user['date_format']];

	if (is_null($time_format))
		$time_format = $aura_config['o_time_formats'][$aura_user['time_format']];

	$date = gmdate($date_format, $timestamp);
	$today = gmdate($date_format, CURRENT_TIMESTAMP+$diff);
	$yesterday = gmdate($date_format, CURRENT_TIMESTAMP+$diff-86400);

	if (!$no_text)
	{
		if ($date == $today)
			$date = $lang->t('Today');
		else if ($date == $yesterday)
			$date = $lang->t('Yesterday');
	}

	if ($date_only)
		return $date;
	else if ($time_only)
		return gmdate($time_format, $timestamp);
	else
		return $date.' '.gmdate($time_format, $timestamp);
}


//
// A wrapper for PHP's number_format function
//
function forum_number_format($number, $decimals = 0)
{
	global $lang;

	return is_numeric($number) ? number_format($number, $decimals, $lang->t('lang_decimal_point'), $lang->t('lang_thousands_sep')) : $number;
}

//
// Generate a random key of length $len
//
function random_key($len, $readable = false, $hash = false)
{
	if (!function_exists('secure_random_bytes'))
		include AURA_ROOT.'include/srand.php';

	$key = secure_random_bytes($len);

	if ($hash)
		return substr(bin2hex($key), 0, $len);
	else if ($readable)
	{
		$chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';

		$result = '';
		for ($i = 0; $i < $len; ++$i)
			$result .= substr($chars, (ord($key[$i]) % strlen($chars)), 1);

		return $result;
	}

	return $key;
}

//
// Make sure that user is using a valid token
// 
function confirm_referrer($script, $use_ip = true)
{
	global $lang, $aura_user;

	// Yeah, pretty complex ternary =)
	$sent_hash = ((isset($_POST['csrf_token'])) ? aura_trim($_POST['csrf_token']) : (isset($_GET['csrf_token']) ? aura_trim($_GET['csrf_token']) : ''));

	if (!aura_hash_equals(generate_csrf_token($script, $use_ip), $sent_hash))
		message($lang->t('Bad referrer'));
}

//
// Generate a csrf token
//
function generate_csrf_token($script = 'nothing', $use_ip = true)
{
	global $aura_user;

	$script = ($script != 'nothing') ? $script : aura_trim(basename($_SERVER['SCRIPT_NAME']));
	return aura_hash($aura_user['id'].$script.$aura_user['salt'].(($use_ip ? get_remote_address() : '')).$aura_user['login_key']);
}

//
// Validate the given redirect URL, use the fallback otherwise
//
function validate_redirect($redirect_url, $fallback_url)
{
	$referrer = parse_url(strtolower($redirect_url));

	// Make sure the host component exists
	if (!isset($referrer['host']))
		$referrer['host'] = '';

	// Remove www subdomain if it exists
	if (strpos($referrer['host'], 'www.') === 0)
		$referrer['host'] = substr($referrer['host'], 4);

	// Make sure the path component exists
	if (!isset($referrer['path']))
		$referrer['path'] = '';

	$valid = parse_url(strtolower(get_base_url()));

	// Remove www subdomain if it exists
	if (strpos($valid['host'], 'www.') === 0)
		$valid['host'] = substr($valid['host'], 4);

	// Make sure the path component exists
	if (!isset($valid['path']))
		$valid['path'] = '';

	if ($referrer['host'] == $valid['host'] && preg_match('%^'.preg_quote($valid['path'], '%').'/(.*?)\.php%i', $referrer['path']))
		return $redirect_url;
	else
		return $fallback_url;
}

//
// Generate a random password of length $len
// Compatibility wrapper for random_key
//
function random_pass($len)
{
	return random_key($len, true);
}

//
// Compute a hash of $str
//
function aura_hash($str)
{
	return hash('sha512', $str);
}

//
// Try to determine the correct remote IP-address
//
function get_remote_address()
{
	$remote_addr = $_SERVER['REMOTE_ADDR'];

	// If we are behind a reverse proxy try to find the real users IP
	if (defined('FORUM_BEHIND_REVERSE_PROXY'))
	{
		if (isset($_SERVER['HTTP_X_FORWARDED_FOR']))
		{
			// The general format of the field is:
			// X-Forwarded-For: client1, proxy1, proxy2
			// where the value is a comma+space separated list of IP addresses, the left-most being the farthest downstream client,
			// and each successive proxy that passed the request adding the IP address where it received the request from.
			$forwarded_for = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
			$forwarded_for = trim($forwarded_for[0]);

			if (@preg_match('%^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$%', $forwarded_for) || @preg_match('%^((([0-9A-Fa-f]{1,4}:){7}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){6}:[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){5}:([0-9A-Fa-f]{1,4}:)?[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){4}:([0-9A-Fa-f]{1,4}:){0,2}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){3}:([0-9A-Fa-f]{1,4}:){0,3}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){2}:([0-9A-Fa-f]{1,4}:){0,4}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){6}((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|(([0-9A-Fa-f]{1,4}:){0,5}:((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|(::([0-9A-Fa-f]{1,4}:){0,5}((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|([0-9A-Fa-f]{1,4}::([0-9A-Fa-f]{1,4}:){0,5}[0-9A-Fa-f]{1,4})|(::([0-9A-Fa-f]{1,4}:){0,6}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){1,7}:))$%', $forwarded_for))
				$remote_addr = $forwarded_for;
		}
	}

	return $remote_addr;
}

//
// Calls htmlspecialchars with a few options already set
// As of 1.1.0, this has been deprecated and will be removed soon. Use Twig instead.
//
function aura_htmlspecialchars($str)
{
	return htmlspecialchars($str, ENT_QUOTES, 'UTF-8');
}

//
// Calls htmlspecialchars_decode with a few options already set
//
function aura_htmlspecialchars_decode($str)
{
	if (function_exists('htmlspecialchars_decode'))
		return htmlspecialchars_decode($str, ENT_QUOTES);

	static $translations;
	if (!isset($translations))
	{
		$translations = get_html_translation_table(HTML_SPECIALCHARS, ENT_QUOTES);
		$translations['&#039;'] = '\''; // get_html_translation_table doesn't include &#039; which is what htmlspecialchars translates ' to, but apparently that is okay?! http://bugs.php.net/bug.php?id=25927
		$translations = array_flip($translations);
	}

	return strtr($str, $translations);
}

//
// A wrapper for utf8_strlen for compatibility
//
function aura_strlen($str)
{
	return utf8_strlen($str);
}

//
// Convert \r\n and \r to \n
//
function aura_linebreaks($str)
{
	return str_replace(array("\r\n", "\r"), "\n", $str);
}

//
// A wrapper for utf8_trim for compatibility
//
function aura_trim($str, $charlist = false)
{
	return is_string($str) ? utf8_trim($str, $charlist) : '';
}

//
// Checks if a string is in all uppercase
//
function is_all_uppercase($string)
{
	return utf8_strtoupper($string) == $string && utf8_strtolower($string) != $string;
}

//
// Inserts $element into $input at $offset
// $offset can be either a numerical offset to insert at (eg: 0 inserts at the beginning of the array)
// or a string, which is the key that the new element should be inserted before
// $key is optional: it's used when inserting a new key/value pair into an associative array
//
function array_insert(&$input, $offset, $element, $key = null)
{
	if (is_null($key))
		$key = $offset;

	// Determine the proper offset if we're using a string
	if (!is_int($offset))
		$offset = array_search($offset, array_keys($input), true);

	// Out of bounds checks
	if ($offset > count($input))
		$offset = count($input);
	else if ($offset < 0)
		$offset = 0;

	$input = array_merge(array_slice($input, 0, $offset), array($key => $element), array_slice($input, $offset));
}

//
// Return a template object from Twig
//
function load_template($tpl_file)
{
	global $aura_user, $aura_config, $tpl_manager;
	
	$style_root = (($aura_config['o_style_path'] != 'styles') ? $aura_config['o_style_path'] : AURA_ROOT.$aura_config['o_style_path']).'/'.$aura_user['style'].'/templates/';
	if (file_exists($style_root.$tpl_file))
		$tpl_file = $tpl_manager->loadTemplate('@style/'.$tpl_file);
	else
		$tpl_file = $tpl_manager->loadTemplate('@core/'.$tpl_file);

	return $tpl_file;
}

//
// Check if a string is valid JSON
//

function is_json($string)
{
   return is_string($string) && is_array(json_decode($string, true)) && (json_last_error() == JSON_ERROR_NONE) ? true : false;
}

//
// Display a message when board is in maintenance mode
//
function maintenance_message()
{
	global $db, $aura_config, $lang, $aura_user;

	// Send no-cache headers
	header('Expires: Thu, 21 Jul 1977 07:30:00 GMT'); // When yours truly first set eyes on this world! :)
	header('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT');
	header('Cache-Control: post-check=0, pre-check=0', false);
	header('Pragma: no-cache'); // For HTTP/1.0 compatibility

	// Send the Content-type header in case the web server is setup to send something else
	header('Content-type: text/html; charset=utf-8');

	// Deal with newlines, tabs and multiple spaces
	$pattern = array("\t", '  ', '  ');
	$replace = array('&#160; &#160; ', '&#160; ', ' &#160;');
	$message = str_replace($pattern, $replace, $aura_config['o_maintenance_message']);

	$tpl = load_template('maintenance.tpl');
	echo $tpl->render(
		array(
			'lang' => $lang,
			'message' => $message,
			'style_core' => (($aura_config['o_style_dir']) != '' ? $aura_config['o_style_dir'] : get_base_url().'/styles/').'core/',
			'page_title' => generate_page_title(array($aura_config['o_board_title'], $lang->t('Maintenance'))),
			'style' => (($aura_config['o_style_dir']) != '' ? $aura_config['o_style_dir'] : get_base_url().'/styles/').$aura_user['style'],
			'aura_config' => $aura_config,
		)
	);

	// End the transaction
	$db->end_transaction();

	exit;
}

//
// Display $message and redirect user to $destination_url
//
function redirect($destination_url, $message)
{
	global $db, $aura_config, $lang, $aura_user;

	// Prefix with base_url (unless there's already a valid URI)
	if (strpos($destination_url, 'http://') !== 0 && strpos($destination_url, 'https://') !== 0 && strpos($destination_url, '/') !== 0)
		$destination_url = get_base_url(true).'/'.$destination_url;

	// Do a little spring cleaning
	$destination_url = preg_replace('%([\r\n])|(\%0[ad])|(;\s*data\s*:)%i', '', $destination_url);

	// If the delay is 0 seconds, we might as well skip the redirect all together
	if ($aura_config['o_redirect_delay'] == '0')
	{
		$db->end_transaction();

		header('Location: '.str_replace('&amp;', '&', $destination_url));
		exit;
	}

	// Send no-cache headers
	header('Expires: Thu, 21 Jul 1977 07:30:00 GMT'); // When yours truly first set eyes on this world! :)
	header('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT');
	header('Cache-Control: post-check=0, pre-check=0', false);
	header('Pragma: no-cache'); // For HTTP/1.0 compatibility

	// Send the Content-type header in case the web server is setup to send something else
	header('Content-type: text/html; charset=utf-8');

	$tpl = load_template('redirect.tpl');
	echo $tpl->render(
		array(
			'lang' => $lang,
			'destination_url' => $destination_url,
			'message' => $message,
			'queries' => ($aura_config['o_show_queries'] == '1') ? display_saved_queries() : '',
			'aura_config' => $aura_config,
			'style_core' => (($aura_config['o_style_dir']) != '' ? $aura_config['o_style_dir'] : get_base_url().'/styles/').'core/',
			'page_title' => generate_page_title(array($aura_config['o_board_title'], $lang->t('Redirecting'))),
			'css_url' => (($aura_config['o_style_dir']) != '' ? $aura_config['o_style_dir'] : get_base_url().'/styles/').$aura_user['style'],
		)
	);
	
	$db->end_transaction();
	exit;
}

//
// Removes any "bad" characters (characters which mess with the display of a page, are invisible, etc) from user input
//
function forum_remove_bad_characters()
{
	$_GET = remove_bad_characters($_GET);
	$_POST = remove_bad_characters($_POST);
	$_COOKIE = remove_bad_characters($_COOKIE);
}

//
// Removes any "bad" characters (characters which mess with the display of a page, are invisible, etc) from the given string
// See: http://kb.mozillazine.org/Network.IDN.blacklist_chars
//
function remove_bad_characters($array)
{
	static $bad_utf8_chars;

	if (!isset($bad_utf8_chars))
	{
		$bad_utf8_chars = array(
			"\xcc\xb7"		=> '',		// COMBINING SHORT SOLIDUS OVERLAY		0337	*
			"\xcc\xb8"		=> '',		// COMBINING LONG SOLIDUS OVERLAY		0338	*
			"\xe1\x85\x9F"	=> '',		// HANGUL CHOSEONG FILLER				115F	*
			"\xe1\x85\xA0"	=> '',		// HANGUL JUNGSEONG FILLER				1160	*
			"\xe2\x80\x8b"	=> '',		// ZERO WIDTH SPACE						200B	*
			"\xe2\x80\x8c"	=> '',		// ZERO WIDTH NON-JOINER				200C
			"\xe2\x80\x8d"	=> '',		// ZERO WIDTH JOINER					200D
			"\xe2\x80\x8e"	=> '',		// LEFT-TO-RIGHT MARK					200E
			"\xe2\x80\x8f"	=> '',		// RIGHT-TO-LEFT MARK					200F
			"\xe2\x80\xaa"	=> '',		// LEFT-TO-RIGHT EMBEDDING				202A
			"\xe2\x80\xab"	=> '',		// RIGHT-TO-LEFT EMBEDDING				202B
			"\xe2\x80\xac"	=> '', 		// POP DIRECTIONAL FORMATTING			202C
			"\xe2\x80\xad"	=> '',		// LEFT-TO-RIGHT OVERRIDE				202D
			"\xe2\x80\xae"	=> '',		// RIGHT-TO-LEFT OVERRIDE				202E
			"\xe2\x80\xaf"	=> '',		// NARROW NO-BREAK SPACE				202F	*
			"\xe2\x81\x9f"	=> '',		// MEDIUM MATHEMATICAL SPACE			205F	*
			"\xe2\x81\xa0"	=> '',		// WORD JOINER							2060
			"\xe3\x85\xa4"	=> '',		// HANGUL FILLER						3164	*
			"\xef\xbb\xbf"	=> '',		// ZERO WIDTH NO-BREAK SPACE			FEFF
			"\xef\xbe\xa0"	=> '',		// HALFWIDTH HANGUL FILLER				FFA0	*
			"\xef\xbf\xb9"	=> '',		// INTERLINEAR ANNOTATION ANCHOR		FFF9	*
			"\xef\xbf\xba"	=> '',		// INTERLINEAR ANNOTATION SEPARATOR		FFFA	*
			"\xef\xbf\xbb"	=> '',		// INTERLINEAR ANNOTATION TERMINATOR	FFFB	*
			"\xef\xbf\xbc"	=> '',		// OBJECT REPLACEMENT CHARACTER			FFFC	*
			"\xef\xbf\xbd"	=> '',		// REPLACEMENT CHARACTER				FFFD	*
			"\xe2\x80\x80"	=> ' ',		// EN QUAD								2000	*
			"\xe2\x80\x81"	=> ' ',		// EM QUAD								2001	*
			"\xe2\x80\x82"	=> ' ',		// EN SPACE								2002	*
			"\xe2\x80\x83"	=> ' ',		// EM SPACE								2003	*
			"\xe2\x80\x84"	=> ' ',		// THREE-PER-EM SPACE					2004	*
			"\xe2\x80\x85"	=> ' ',		// FOUR-PER-EM SPACE					2005	*
			"\xe2\x80\x86"	=> ' ',		// SIX-PER-EM SPACE						2006	*
			"\xe2\x80\x87"	=> ' ',		// FIGURE SPACE							2007	*
			"\xe2\x80\x88"	=> ' ',		// AURACTUATION SPACE					2008	*
			"\xe2\x80\x89"	=> ' ',		// THIN SPACE							2009	*
			"\xe2\x80\x8a"	=> ' ',		// HAIR SPACE							200A	*
			"\xE3\x80\x80"	=> ' ',		// IDEOGRAPHIC SPACE					3000	*
		);
	}

	if (is_array($array))
		return array_map('remove_bad_characters', $array);

	// Strip out any invalid characters
	$array = utf8_bad_strip($array);

	// Remove control characters
	$array = preg_replace('%[\x00-\x08\x0b-\x0c\x0e-\x1f]%', '', $array);

	// Replace some "bad" characters
	$array = str_replace(array_keys($bad_utf8_chars), array_values($bad_utf8_chars), $array);

	return $array;
}

//
// Converts the file size in bytes to a human readable file size
//
function file_size($size)
{
	global $lang;

	$units = array('B', 'KiB', 'MiB', 'GiB', 'TiB', 'PiB', 'EiB');

	for ($i = 0; $size > 1024; $i++)
		$size /= 1024;

	return $lang->t('Size unit '.$units[$i], round($size, 2));
}

//
// Fetch a list of available styles
//
function forum_list_styles()
{
	global $aura_config;
	$styles = array();
	$style = ($aura_config['o_style_path'] != 'styles') ? $aura_config['o_style_path'] : AURA_ROOT.$aura_config['o_style_path'];

	$styles = array();
	$files = array_diff(scandir($style), array('.', '..'));
	foreach ($files as $style)
	{
		if (substr($style, -4) == '.css')
			$styles[] = substr($style, 0, -4);
	}

	natcasesort($styles);
	return $styles;
}

//
// Get all URL schemes
//
function get_url_schemes()
{
	$schemes = array();
	$files = array_diff(scandir(AURA_ROOT.'include/url'), array('.', '..'));
	foreach ($files as $scheme)
	{
		if (preg_match('/^[a-z0-9-_]+\.(php)$/i', $scheme))
			$schemes[] = substr($scheme, 0, -4);
	}

	return $schemes;
}

//
// For forum passwords, show this...
//

function show_forum_login_box($id)
{
	global $lang, $aura_config, $aura_start, $tpl_main, $aura_user, $db, $aura_url, $cache;
	$required_fields = array('req_password' => $lang->t('Password'));
	$focus_element = array('request_pass', 'req_password');

	$data = array(
		':id'	=>	$id,
	);
	
	$ps = $db->select('forums', 'forum_name', $data, 'id=:id');
	$forum_name = url_friendly($ps->fetchColumn());
	
	$redirect_url = validate_redirect(get_current_url(), null);

	if (!isset($redirect_url))
		$redirect_url = aura_link($aura_url['forum'], array($id, $forum_name));
	else if (preg_match('%viewtopic\.php\?pid=(\d+)$%', $redirect_url, $matches))
		$redirect_url .= '#p'.$matches[1];

	$page_title = array($aura_config['o_board_title'], $lang->t('Info'));
	define('AURA_ACTIVE_PAGE', 'index');
	require AURA_ROOT.'header.php';

	$tpl = load_template('forum_password.tpl');
	echo $tpl->render(
		array(
			'lang' => $lang,
			'form_action' => aura_link($aura_url['forum'], array($id, $forum_name)),
			'csrf_token' => generate_csrf_token('viewforum.php'),
			'redirect_url' => $redirect_url,
		)
	);

	require AURA_ROOT.'footer.php';
}

//
// Check if given forum password is indeed valid
//
function validate_login_attempt($id)
{
	global $lang, $db, $aura_url, $aura_config;
	confirm_referrer('viewforum.php');

	$password = isset($_POST['req_password']) ? aura_trim($_POST['req_password']) : '';
	$redirect_url = validate_redirect($_POST['redirect_url'], aura_link($aura_url['index']));	// If we've tampered, or maybe something just went wrong, send them back to the board index
	$data = array(
		':id' => $id,
	);

	$ps = $db->select('forums', 'password, salt, forum_name AS name', $data, 'id=:id');
	$cur_forum = $ps->fetch();

	if ($aura_config['o_login_queue'] == '1')
	{
		$data = array(
			':username' => $cur_forum['name'],
			':timeout' => (TIMEOUT * 1000),
		);

		$ps = $db->select('login_queue', 'COUNT(*) AS overall, COUNT(IF(username = :username, TRUE, NULL)) AS user', $data, 'last_checked > NOW() - INTERVAL :timeout MICROSECOND');
		$count = $ps->fetch();

		if (!$count)
			message($lang->t('Unable to query size'));
		else if ($count['overall'] >= $aura_config['o_queue_size'] || $count['user'] >= $aura_config['o_max_attempts'])
			message($lang->t('Login queue exceeded'));	

		$insert = array(
			'ip_address' => get_remote_address(),
			'username' => $cur_forum['name'],
		);

		$db->insert('login_queue', $insert) or message($lang->t('IP address in queue'));
		$attempt = $db->lastInsertId($db->prefix.'login_queue');

		// This time, while() is actually in our favour. Yes, I know!
		while (!check_queue($cur_forum['name'], $attempt))
			usleep(250 * 1000);

		//Force delay between logins, remove dead attempts
		usleep(ATTEMPT_DELAY * 1000);

		$data = array(
			':id' => $attempt,
			':timeout' => (TIMEOUT * 1000),
		);

		$db->delete('login_queue', 'id=:id OR last_checked < NOW() - INTERVAL :timeout MICROSECOND', $data);
	}

	if (aura_hash_equals($cur_forum['password'], aura_hash($password.aura_hash($cur_forum['salt']))))
	{
		set_forum_login_cookie($id, $cur_forum['password']);

		header('Location: '.$redirect_url);
		exit;
	}
	else
	{
		($hook = get_extensions('forum_password_on_failure')) ? eval($hook) : null;
		message($lang->t('Incorrect password'));
	}
}

function set_forum_login_cookie($id, $forum_password)
{
	global $aura_config;

	$cookie_data = isset($_COOKIE[$aura_config['o_cookie_name'].'_forums']) ? $_COOKIE[$aura_config['o_cookie_name'].'_forums'] : '';
	if (!$cookie_data || strlen($cookie_data) > FORUM_MAX_COOKIE_SIZE)
		$cookie_data = '';

	$cookie_data = unserialize($cookie_data);
	$salt = random_key(64, true);
	$cookie_hash = aura_hash($forum_password.aura_hash($salt));
	$cookie_data[$id] = array('hash' => $cookie_hash, 'salt' => $salt);

	forum_setcookie($aura_config['o_cookie_name'].'_forums', serialize($cookie_data), CURRENT_TIMESTAMP + $aura_config['o_timeout_visit']);
	$_COOKIE[$aura_config['o_cookie_name'].'_forums'] = serialize($cookie_data);
}

function check_forum_login_cookie($id, $forum_password, $return = false)
{
	global $aura_config;

	$cookie_data = isset($_COOKIE[$aura_config['o_cookie_name'].'_forums']) ? $_COOKIE[$aura_config['o_cookie_name'].'_forums'] : '';
	if (!$cookie_data || strlen($cookie_data) > FORUM_MAX_COOKIE_SIZE)
		$cookie_data = '';

	// If it's empty, define as a blank array to avoid 'must be a boolean' error
	$cookie_data = ($cookie_data !== '') ? unserialize($cookie_data) : array();
	if (!isset($cookie_data[$id]))
	{
		if (!$return)
			show_forum_login_box($id);
		else
			return false;
	}
	else
	{
		if ($cookie_data[$id]['hash'] !== aura_hash($forum_password.aura_hash($cookie_data[$id]['salt'])))
		{
			if (!$return)
				show_forum_login_box($id);
			else
				return false;
		}
		else
			return true;
	}
}

//
// Generate a cache ID based on the last modification time for all stopwords files
//
function generate_stopwords_cache_id()
{
	global $lang;
	$files = $lang->get_language_stopwords();
	if ($files === false)
		return 'cache_id_error';

	$hash = array();
	foreach ($files as $file)
	{
		$hash[] = $file;
		$hash[] = filemtime($file);
	}

	return aura_hash(implode('|', $hash));
}

//
// Split text into chunks ($inside contains all text inside $start and $end, and $outside contains all text outside)
//
function split_text($text, $start, $end, $retab = true)
{
	global $aura_config;

	$result = array(0 => array(), 1 => array()); // 0 = inside, 1 = outside

	// split the text into parts
	$parts = preg_split('%'.preg_quote($start, '%').'(.*)'.preg_quote($end, '%').'%Us', $text, -1, PREG_SPLIT_DELIM_CAPTURE);
	$num_parts = count($parts);

	// preg_split results in outside parts having even indices, inside parts having odd
	for ($i = 0;$i < $num_parts;$i++)
		$result[1 - ($i % 2)][] = $parts[$i];

	if ($aura_config['o_indent_num_spaces'] != 8 && $retab)
	{
		$spaces = str_repeat(' ', $aura_config['o_indent_num_spaces']);
		$result[1] = str_replace("\t", $spaces, $result[1]);
	}

	return $result;
}

function extract_blocks($text, $start, $end, $retab = true)
{
	global $aura_config;

	$code = array();
	$start_len = strlen($start);
	$end_len = strlen($end);
	$regex = '%(?:'.preg_quote($start, '%').'|'.preg_quote($end, '%').')%';
	$matches = array();

	if (preg_match_all($regex, $text, $matches))
	{
		$counter = $offset = 0;
		$start_pos = $end_pos = false;

		foreach ($matches[0] as $match)
		{
			if ($match == $start)
			{
				if ($counter == 0)
					$start_pos = strpos($text, $start);
				$counter++;
			}
			elseif ($match == $end)
			{
				$counter--;
				if ($counter == 0)
					$end_pos = strpos($text, $end, $offset + 1);
				$offset = strpos($text, $end, $offset + 1);
			}

			if ($start_pos !== false && $end_pos !== false)
			{
				$code[] = substr($text, $start_pos + $start_len,
					$end_pos - $start_pos - $start_len);
				$text = substr_replace($text, "\1", $start_pos,
					$end_pos - $start_pos + $end_len);
				$start_pos = $end_pos = false;
				$offset = 0;
			}
		}
	}

	if ($aura_config['o_indent_num_spaces'] != 8 && $retab)
	{
		$spaces = str_repeat(' ', $aura_config['o_indent_num_spaces']);
		$text = str_replace("\t", $spaces, $text);
	}

	return array($code, $text);
}

function contains_url($data)
{
	return preg_match('/# Valid absolute URI having a non-empty, valid DNS host.
		^
		(?P<scheme>[A-Za-z][A-Za-z0-9+\-.]*):\/\/
		(?P<authority>
		  (?:(?P<userinfo>(?:[A-Za-z0-9\-._~!$&\'()*+,;=:]|%[0-9A-Fa-f]{2})*)@)?
		  (?P<host>
			(?P<IP_literal>
			  \[
			  (?:
				(?P<IPV6address>
				  (?:												 (?:[0-9A-Fa-f]{1,4}:){6}
				  |												   ::(?:[0-9A-Fa-f]{1,4}:){5}
				  | (?:							 [0-9A-Fa-f]{1,4})?::(?:[0-9A-Fa-f]{1,4}:){4}
				  | (?:(?:[0-9A-Fa-f]{1,4}:){0,1}[0-9A-Fa-f]{1,4})?::(?:[0-9A-Fa-f]{1,4}:){3}
				  | (?:(?:[0-9A-Fa-f]{1,4}:){0,2}[0-9A-Fa-f]{1,4})?::(?:[0-9A-Fa-f]{1,4}:){2}
				  | (?:(?:[0-9A-Fa-f]{1,4}:){0,3}[0-9A-Fa-f]{1,4})?::	[0-9A-Fa-f]{1,4}:
				  | (?:(?:[0-9A-Fa-f]{1,4}:){0,4}[0-9A-Fa-f]{1,4})?::
				  )
				  (?P<ls32>[0-9A-Fa-f]{1,4}:[0-9A-Fa-f]{1,4}
				  | (?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}
					   (?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)
				  )
				|	(?:(?:[0-9A-Fa-f]{1,4}:){0,5}[0-9A-Fa-f]{1,4})?::	[0-9A-Fa-f]{1,4}
				|	(?:(?:[0-9A-Fa-f]{1,4}:){0,6}[0-9A-Fa-f]{1,4})?::
				)
			  | (?P<IPvFuture>[Vv][0-9A-Fa-f]+\.[A-Za-z0-9\-._~!$&\'()*+,;=:]+)
			  )
			  \]
			)
		  | (?P<IPv4address>(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}
							   (?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?))
		  | (?P<regname>(?:[A-Za-z0-9\-._~!$&\'()*+,;=]|%[0-9A-Fa-f]{2})+)
		  )
		  (?::(?P<port>[0-9]*))?
		)
		(?P<path_abempty>(?:\/(?:[A-Za-z0-9\-._~!$&\'()*+,;=:@]|%[0-9A-Fa-f]{2})*)*)
		(?:\?(?P<query>		  (?:[A-Za-z0-9\-._~!$&\'()*+,;=:@\\/?]|%[0-9A-Fa-f]{2})*))?
		(?:\#(?P<fragment>	  (?:[A-Za-z0-9\-._~!$&\'()*+,;=:@\\/?]|%[0-9A-Fa-f]{2})*))?
		$
		/mx', $data);
}

function url_valid($url)
{
	if (strpos($url, 'www.') === 0) $url = 'http://'. $url;
	if (strpos($url, 'ftp.') === 0) $url = 'ftp://'. $url;
	if (!preg_match('/# Valid absolute URI having a non-empty, valid DNS host.
		^
		(?P<scheme>[A-Za-z][A-Za-z0-9+\-.]*):\/\/
		(?P<authority>
		  (?:(?P<userinfo>(?:[A-Za-z0-9\-._~!$&\'()*+,;=:]|%[0-9A-Fa-f]{2})*)@)?
		  (?P<host>
			(?P<IP_literal>
			  \[
			  (?:
				(?P<IPV6address>
				  (?:												 (?:[0-9A-Fa-f]{1,4}:){6}
				  |												   ::(?:[0-9A-Fa-f]{1,4}:){5}
				  | (?:							 [0-9A-Fa-f]{1,4})?::(?:[0-9A-Fa-f]{1,4}:){4}
				  | (?:(?:[0-9A-Fa-f]{1,4}:){0,1}[0-9A-Fa-f]{1,4})?::(?:[0-9A-Fa-f]{1,4}:){3}
				  | (?:(?:[0-9A-Fa-f]{1,4}:){0,2}[0-9A-Fa-f]{1,4})?::(?:[0-9A-Fa-f]{1,4}:){2}
				  | (?:(?:[0-9A-Fa-f]{1,4}:){0,3}[0-9A-Fa-f]{1,4})?::	[0-9A-Fa-f]{1,4}:
				  | (?:(?:[0-9A-Fa-f]{1,4}:){0,4}[0-9A-Fa-f]{1,4})?::
				  )
				  (?P<ls32>[0-9A-Fa-f]{1,4}:[0-9A-Fa-f]{1,4}
				  | (?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}
					   (?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)
				  )
				|	(?:(?:[0-9A-Fa-f]{1,4}:){0,5}[0-9A-Fa-f]{1,4})?::	[0-9A-Fa-f]{1,4}
				|	(?:(?:[0-9A-Fa-f]{1,4}:){0,6}[0-9A-Fa-f]{1,4})?::
				)
			  | (?P<IPvFuture>[Vv][0-9A-Fa-f]+\.[A-Za-z0-9\-._~!$&\'()*+,;=:]+)
			  )
			  \]
			)
		  | (?P<IPv4address>(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}
							   (?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?))
		  | (?P<regname>(?:[A-Za-z0-9\-._~!$&\'()*+,;=]|%[0-9A-Fa-f]{2})+)
		  )
		  (?::(?P<port>[0-9]*))?
		)
		(?P<path_abempty>(?:\/(?:[A-Za-z0-9\-._~!$&\'()*+,;=:@]|%[0-9A-Fa-f]{2})*)*)
		(?:\?(?P<query>		  (?:[A-Za-z0-9\-._~!$&\'()*+,;=:@\\/?]|%[0-9A-Fa-f]{2})*))?
		(?:\#(?P<fragment>	  (?:[A-Za-z0-9\-._~!$&\'()*+,;=:@\\/?]|%[0-9A-Fa-f]{2})*))?
		$
		/mx', $url, $m)) return FALSE;
	switch ($m['scheme'])
	{
	case 'https':
	case 'http':
		if ($m['userinfo']) return FALSE; // HTTP scheme does not allow userinfo.
		break;
	case 'ftps':
	case 'ftp':
		break;
	default:
		return FALSE;	// Unrecognised URI scheme. Default to FALSE.
	}
	// Validate host name conforms to DNS "dot-separated-parts".
	if ($m{'regname'}) // If host regname specified, check for DNS conformance.
	{
		if (!preg_match('/# HTTP DNS host name.
			^					   # Anchor to beginning of string.
			(?!.{256})			   # Overall host length is less than 256 chars.
			(?:					   # Group dot separated host part alternatives.
			  [0-9A-Za-z]\.		   # Either a single alphanum followed by dot
			|					   # or... part has more than one char (63 chars max).
			  [0-9A-Za-z]		   # Part first char is alphanum (no dash).
			  [\-0-9A-Za-z]{0,61}  # Internal chars are alphanum plus dash.
			  [0-9A-Za-z]		   # Part last char is alphanum (no dash).
			  \.				   # Each part followed by literal dot.
			)*					   # One or more parts before top level domain.
			(?:					   # Top level domains
			  [A-Za-z]{2,63}|	   # Country codes are exactly two alpha chars.
			  xn--[0-9A-Za-z]{4,59})		   # Internationalized Domain Name (IDN)
			$					   # Anchor to end of string.
			/ix', $m['host'])) return FALSE;
	}
	$m['url'] = $url;
	for ($i = 0; isset($m[$i]); ++$i) unset($m[$i]);
	return $m; // return TRUE == array of useful named $matches plus the valid $url.
}

//
// Replace string matching regular expression
//
// This function takes care of possibly disabled unicode properties in PCRE builds
//
function ucp_preg_replace($pattern, $replace, $subject, $callback = false)
{
	if($callback) 
		$replaced = preg_replace_callback($pattern, create_function('$matches', 'return '.$replace.';'), $subject);
	else
		$replaced = preg_replace($pattern, $replace, $subject);

	// If preg_replace() returns false, this probably means unicode support is not built-in, so we need to modify the pattern a little
	if ($replaced === false)
	{
		if (is_array($pattern))
		{
			foreach ($pattern as $cur_key => $cur_pattern)
				$pattern[$cur_key] = str_replace('\p{L}\p{N}', '\w', $cur_pattern);

			$replaced = preg_replace($pattern, $replace, $subject);
		}
		else
			$replaced = preg_replace(str_replace('\p{L}\p{N}', '\w', $pattern), $replace, $subject);
	}

	return $replaced;
}

//
// A wrapper for ucp_preg_replace
//
function ucp_preg_replace_callback($pattern, $replace, $subject)
{
	return ucp_preg_replace($pattern, $replace, $subject, true);
}

//
// Replace four-byte characters with a question mark
//
// As MySQL cannot properly handle four-byte characters with the default utf-8
// charset up until version 5.5.3 (where a special charset has to be used), they
// need to be replaced, by question marks in this case.
//
function strip_bad_multibyte_chars($str)
{
	$result = '';
	$length = strlen($str);

	for ($i = 0; $i < $length; $i++)
	{
		// Replace four-byte characters (11110www 10zzzzzz 10yyyyyy 10xxxxxx)
		$ord = ord($str[$i]);
		if ($ord >= 240 && $ord <= 244)
		{
			$result .= '?';
			$i += 3;
		}
		else
			$result .= $str[$i];
	}

	return $result;
}

//
// Check whether a file/folder is writable.
//
// This function also works on Windows Server where ACLs seem to be ignored.
//
function forum_is_writable($path)
{
	if (is_dir($path))
	{
		$path = rtrim($path, '/').'/';
		return forum_is_writable($path.uniqid(mt_rand()).'.tmp');
	}

	// Check temporary file for read/write capabilities
	$rm = file_exists($path);
	$f = @fopen($path, 'a');

	if ($f === false)
		return false;

	fclose($f);

	if (!$rm)
		@unlink($path);

	return true;
}

//
// Display executed queries (if enabled)
//
function display_saved_queries()
{
	global $db, $lang;

	// Get the queries so that we can print them out
	$saved_queries = $db->get_saved_queries();

	$queries = array();
	$query_time_total = 0.0;
	foreach ($saved_queries as $cur_query)
	{
		$query_time_total += $cur_query[1];
		$queries[] = array(
			'sql' => $cur_query[0],
			'time' => $cur_query[1],
		);
	}

	$tpl = load_template('debug.tpl');
	return $tpl->render(
		array(
			'lang' => $lang,
			'query_time_total' => $query_time_total,
			'queries' => $queries,
		)
	);
}

//
// Dump contents of variable(s)
//
function dump()
{
	echo '<pre>';

	$num_args = func_num_args();

	for ($i = 0; $i < $num_args; ++$i)
	{
		print_r(func_get_arg($i));
		echo "\n\n";
	}

	echo '</pre>';
}

function check_queue($form_username, $attempt)
{
	global $db;
	$data = array(
		':timeout'	=>	(TIMEOUT * 1000),
		':username'	=>	$form_username,
	);

	$ps = $db->select('login_queue', 'id', $data, 'last_checked > NOW() - INTERVAL :timeout MICROSECOND AND username = :username', 'id ASC LIMIT 1');
	$id = $ps->fetchColumn();

	// Due to the fact we're not updating with data, we can't use the update() method. Instead, we have to use run() to avoid the string 'CURRENT_TIMESTAMP' being the value entered.
	$db->run('UPDATE '.$db->prefix.'login_queue SET last_checked = CURRENT_TIMESTAMP WHERE id=? LIMIT 1', array($attempt));
	return ($id == $attempt) ? true : false;
}

function is_bot($ua, $ual)
{
	if (!trim($ua))
		return false;

	if (strpos($ual, 'bot') !== false || strpos($ual, 'spider') !== false || strpos($ual, 'crawler') !== false || strpos($ual, 'http') !== false)
		return true;

	if (strpos($ua, 'Mozilla/') !== false)
	{
		if (strpos($ua, 'Gecko') !== false)
			return false;

		if (strpos($ua, '(compatible; MSIE ') !== false && strpos($ua, 'Windows') !== false)
			return false;
	}
	else if (strpos($ua, 'Opera/') !== false)
	{
		if (strpos($ua, 'Presto/') !== false)
			return false;
	}

	return true;
}

function isbotex($ra)
{
	$ua = getenv('HTTP_USER_AGENT');
	$ual = strtolower($ua);

	if (!is_bot($ua, $ual))
		return $ra;

	if (strpos($ual, 'mozilla') !== false)
		$ua = preg_replace('%Mozilla.*?compatible%i', ' ', $ua);

	if(strpos($ual, 'http') !== false || strpos($ual, 'www.') !== false)
		$ua = preg_replace('%(?:https?://|www\.)[^\)]*(\)[^/]+$)?%i', ' ', $ua);

	if (strpos($ua, '@') !== false)
		$ua = preg_replace('%\b[\w\.-]+@[^\)]+%i', ' ', $ua);

	if (strpos($ual, 'bot') !== false || strpos($ual, 'spider') !== false || strpos($ual, 'crawler') !== false || strpos($ual, 'engine') !== false)
	{
		$f = true;
		$p = '%(?<=[^a-z\d\.-])(?:robot|bot|spider|crawler)\b.*%i';
	}
	else
	{
		$f = false;
		$p = '%^$%';
	}

	if ($f && preg_match('%\b(([a-z\d\.! _-]+)?(?:robot|(?<!ro)bot|spider|crawler|engine)(?(2)[a-z\d\.! _-]*|[a-z\d\.! _-]+))%i', $ua, $matches))
	{
		$ua = $matches[1];

		$pat = array(
			$p,
			'%[^a-z\d\.!-]+%i',
			'%(?<=^|\s|-)v?\d+\.\d[^\s]*\s*%i',
			'%(?<=^|\s)\S{1,2}(?:\s|$)%',
		);
		$rep = array(
			'',
			' ',
			'',
			'',
		);
	}
	else
	{
		$pat = array(
			'%\((?:KHTML|Linux|Mac|Windows|X11)[^\)]*\)?%i',
			$p,
			'%\b(?:AppleWebKit|Chrom|compatible|Firefox|Gecko|Mobile(?=[/ ])|Moz|Opera|OPR|Presto|Safari|Version)[^\s]*%i',
			'%\b(?:InfoP|Intel|Linux|Mac|MRA|MRS|MSIE|SV|Trident|Win|WOW|X11)[^;\)]*%i',
			'%\.NET[^;\)]*%i',
			'%/.*%',
			'%[^a-z\d\.!-]+%i',
			'%(?<=^|\s|-)v?\d+\.\d[^\s]*\s*%i',
			'%(?<=^|\s)\S{1,2}(?:\s|$)%',
		);
		$rep = array(
			' ',
			'',
			'',
			'',
			'',
			'',
			' ',
			'',
			'',
		);
	}

	$ua = trim(preg_replace($pat, $rep, $ua), ' -');

	if (empty($ua))
		return $ra.'[Bot] Unknown';

	$a = explode(' ', $ua);

	$ua = $a[0];
	if (strlen($ua) < 20 && !empty($a[1]) && strlen($ua.' '.$a[1]) < 26)
		$ua.= ' '.$a[1];
	else if (strlen($ua) > 25)
		$ua = 'Unknown';

	return $ra.'[Bot]'.$ua;

}

//
// Fetch an easy-to-use location of where the user is on the forum based on a URL
//
function generate_location($url)
{
	global $db;

	switch ($url)
	{
		case stristr($url, 'userlist.php'): // Userlist
			return 'userlist';
		break;
		case stristr($url, 'search'):
			return 'search';
		break;
		case 'online.php':
			return 'online';
		break;
		case 'misc.php?action=rules':
			return 'rules';
		break;
		case stristr($url, 'post.php?action=post'):
			return 'posting';
		break;
		case stristr($url, 'help'):
			return 'help';
		break;
		case stristr($url, AURA_ADMIN_DIR):
			return 'admin';
		break;
		case stristr($url, 'pms_'):
			return 'pm';
		break;
		case stristr($url, 'login'):
			return 'login';
		break;
		case stristr($url, 'moderate.php'):
			return 'moderate';
		break;
		case stristr($url, 'register.php'):
			return 'register';
		break;
		case stristr($url, 'misc.php?action=leaders'):
			return 'moderators';
		break;
		case stristr($url, 'profile'):
			$id = filter_var($url, FILTER_SANITIZE_NUMBER_INT);
			return 'profile|'.$id;
		break;
		case stristr($url, 'viewforum.php'): // If we're viewing the forum itself
			// We don't want any page IDs intefering
			if (strpos($url, '&p=')!== false)
			{
				preg_match('~&p=(.*)~', $url, $replace);
				$url = str_replace($replace[0], '', $url);
			}
			
			$id = filter_var($url, FILTER_SANITIZE_NUMBER_INT);
			return 'forum|'.$id;
		break;
		case stristr($url, 'viewtopic.php?pid'):
			$pid = filter_var($url, FILTER_SANITIZE_NUMBER_INT);

			$join = array(
				array(
					'type' => 'INNER',
					'table' => 'topics',
					'as' => 't',
					'on' => 'p.topic_id=t.id',
				),
			);

			$data = array(
				':id' => $pid,
			);

			$ps = $db->join('posts', 'p', $join, 't.id AS tid, t.forum_id AS fid', $data, 'p.id=:id');
			$cur_post = $ps->fetch();

			return 'forum|'.$cur_post['fid'].'|topic|'.$cur_post['tid'];
		break;
		case stristr($url, 'viewtopic.php?id'):
			if (strpos($url, '&p=')!== false)
			{
				preg_match('~&p=(.*)~', $url, $replace);
				$url = str_replace($replace[0], '', $url);
			}

			$id = filter_var($url, FILTER_SANITIZE_NUMBER_INT);
			$data = array(
				':id' => $id,
			);

			$ps = $db->select('topics', 'forum_id', $data, 'id=:id');
			$forum_id = $ps->fetchColumn();

			return 'forum|'.$forum_id.'|topic|'.$id;
		break;
		case stristr($url, 'post.php?fid'):
			$fid = filter_var($url, FILTER_SANITIZE_NUMBER_INT);
			return 'post-topic|'.$fid;
		break;
		case stristr($url, 'post.php?tid'):
			$tid = filter_var($url, FILTER_SANITIZE_NUMBER_INT);
			return 'post-reply|'.$tid;
		break;
		case stristr($url, 'edit.php?id'):
			$id = filter_var($url, FILTER_SANITIZE_NUMBER_INT);

			$join = array(
				array(
					'type' => 'INNER',
					'table' => 'topics',
					'as' => 't',
					'on' => 'p.topic_id=t.id',
				),
			);

			$data = array(
				':id' => $id,
			);

			$ps = $db->join('posts', 'p', $join, 't.id', $data, 'p.id=:id');
			$topic_id = $ps->fetchColumn();

			return 'edit|'.$topic_id;
		break;
		case stristr($url, 'delete.php?id'):
			$id = filter_var($url, FILTER_SANITIZE_NUMBER_INT);

			$join = array(
				array(
					'type' => 'INNER',
					'table' => 'topics',
					'as' => 't',
					'on' => 'p.topic_id=t.id',
				),
			);

			$data = array(
				':id' => $id,
			);

			$ps = $db->join('posts', 'p', $join, 't.id', $data, 'p.id=:id');
			$topic_id = $ps->fetchColumn();

			return 'delete|'.$topic_id;
		break;
		case '':
			$id = filter_var($url, FILTER_SANITIZE_NUMBER_INT);
		break;
		default:
			return 'index';
		break;
	}
}

//
// Present the user with a nicely-formatted location string of where this user is
//
function fetch_user_location($location)
{
	global $db, $cache, $lang, $aura_user, $aura_url;
	static $permissions;

	if (!isset($permissions))
		$permissions = $cache->get('perms');

	$location = explode('|', $location);
	switch ($location[0])
	{
		case null:
			return $lang->t('Unavailable');
		case '':
			return $lang->t('Not online');
		case 'index':
			return $lang->t('Viewing index');
		case 'userlist':
			return $lang->t('Viewing userlist');
		case 'search':
			return $lang->t('Searching');
		case 'online':
			return $lang->t('Viewing users online');
		case 'rules':
			return $lang->t('Viewing board rules');
		case 'posting':
			return $lang->t('Posting');
		case 'help':
			return $lang->t('Viewing help');
		case 'admin':
			return $lang->t('In administration');
		case 'pm':
			return $lang->t('Using personal messaging');
		case 'login':
			return $lang->t('Logging in');
		case 'moderate':
			return $lang->t('Moderating');
		case 'register':
			return $lang->t('Registering');
		case 'moderators':
			return $lang->t('Viewing the team');
		case 'profile':
			$data = array(
				':id' => $location[1],
			);

			$ps = $db->select('users', 'username, group_id', $data, 'id=:id');
			$cur_user = $ps->fetch();

			return array('lang' => $lang->t('Viewing profile'), 'name' => colourise_group($cur_user['username'], $cur_user['group_id'], $location[1]));
		case 'forum':
			if (isset($location[2])) // Then we're actually viewing a topic
			{
				$data = array(
					':id' => $location[3],
				);

				$ps = $db->select('topics', 'subject, forum_id AS fid', $data, 'id=:id');
				$cur_topic = $ps->fetch();

				if (!isset($permissions[$aura_user['g_id'].'_'.$cur_topic['fid']]))
					$permissions[$aura_user['g_id'].'_'.$cur_topic['fid']] = $permissions['_'];

				if ($permissions[$aura_user['g_id'].'_'.$cur_topic['fid']]['read_forum'] == '1' || is_null($permissions[$aura_user['g_id'].'_'.$cur_topic['fid']]['read_forum']))
					return array('href' => aura_link($aura_url['topic'], array($location[3], url_friendly($cur_topic['subject']))), 'name' => $cur_topic['subject'], 'lang' => $lang->t('Viewing topic'));
			}
			else // Or it is actually a forum
			{
				$data = array(
					':id' => $location[1],
				);

				$ps = $db->select('forums', 'forum_name', $data, 'id=:id');
				$forum_name = $ps->fetchColumn();

				if (!isset($permissions[$aura_user['g_id'].'_'.$location[1]]))
					$permissions[$aura_user['g_id'].'_'.$location[1]] = $permissions['_'];
				
				if ($permissions[$aura_user['g_id'].'_'.$location[1]]['read_forum'] == '1' || is_null($permissions[$aura_user['g_id'].'_'.$location[1]]['read_forum']))
					return array('href' => aura_link($aura_url['forum'], array($location[1], url_friendly($forum_name))), 'name' => $forum_name, 'lang' => $lang->t('Viewing forum'));
			}

			return $lang->t('Viewing hidden forum');
		case 'post-topic':
			$data = array(
				':id' => $location[1],
			);

			$ps = $db->select('forums', 'forum_name', $data, 'id=:id');
			$forum_name = $ps->fetchColumn();

			if (!isset($permissions[$aura_user['g_id'].'_'.$location[1]]))
				$permissions[$aura_user['g_id'].'_'.$location[1]] = $permissions['_'];
			
			if ($permissions[$aura_user['g_id'].'_'.$location[1]]['read_forum'] == '1' || is_null($permissions[$aura_user['g_id'].'_'.$location[1]]['read_forum']))
				return array('href' => aura_link($aura_url['forum'], array($location[1], url_friendly($forum_name))), 'name' => $forum_name, 'lang' => $lang->t('Posting topic'));

			return $lang->t('Viewing hidden forum');
		case 'post-reply':
			$data = array(
				':id' => $location[1],
			);

			$ps = $db->select('topics', 'subject, forum_id AS fid', $data, 'id=:id');
			$cur_topic = $ps->fetch();	

			if (!isset($permissions[$aura_user['g_id'].'_'.$cur_topic['fid']]))
				$permissions[$aura_user['g_id'].'_'.$cur_topic['fid']] = $permissions['_'];

			if ($permissions[$aura_user['g_id'].'_'.$cur_topic['fid']]['read_forum'] == '1' || is_null($permissions[$aura_user['g_id'].'_'.$cur_topic['fid']]['read_forum']))
				return array('href' => aura_link($aura_url['topic'], array($location[1], url_friendly($cur_topic['subject']))), 'name' => $cur_topic['subject'], 'lang' => $lang->t('Replying to topic'));

			return $lang->t('Viewing hidden forum');
		case 'edit':
			$join = array(
				array(
					'type' => 'INNER',
					'table' => 'topics',
					'as' => 't',
					'on' => 'p.topic_id=t.id',
				),
			);

			$data = array(
				':id' => $location[1],
			);

			$ps = $db->join('posts', 'p', $join, 't.subject, t.forum_id AS fid', $data, 'p.id=:id');
			$cur_topic = $ps->fetch();

			if (!isset($permissions[$aura_user['g_id'].'_'.$cur_topic['fid']]))
				$permissions[$aura_user['g_id'].'_'.$cur_topic['fid']] = $permissions['_'];

			if ($permissions[$aura_user['g_id'].'_'.$cur_topic['fid']]['read_forum'] == '1' || is_null($permissions[$aura_user['g_id'].'_'.$cur_topic['fid']]['read_forum']))
				return array('href' => aura_link($aura_url['post'], array($id)), 'name' => $cur_topic['subject'], 'lang' => $lang->t('Editing post'));

			return $lang->t('Viewing hidden forum');
		case 'delete':
			$join = array(
				array(
					'type' => 'INNER',
					'table' => 'topics',
					'as' => 't',
					'on' => 'p.topic_id=t.id',
				),
			);

			$data = array(
				':id' => $location[1],
			);

			$ps = $db->join('posts', 'p', $join, 't.subject, t.forum_id AS fid', $data, 'p.id=:id');
			$cur_topic = $ps->fetch();

			if (!isset($perms[$aura_user['g_id'].'_'.$cur_topic['fid']]))
				$perms[$aura_user['g_id'].'_'.$cur_topic['fid']] = $perms['_'];

			if ($perms[$aura_user['g_id'].'_'.$cur_topic['fid']]['read_forum'] == '1' || is_null($perms[$aura_user['g_id'].'_'.$cur_topic['fid']]['read_forum']))
				return array('href' => aura_link($aura_url['post'], array($location[1])), 'name' => $cur_topic['subject'], 'lang' => $lang->t('Deleting post'));

			return $lang->t('Viewing hidden forum');
		default:
			// In case users integrate the forum with their site, and would like custom locations added
			($hook = get_extensions('online_fetch_location')) ? eval($hook) : null;
		break;
	}

	// If all else fails, just return the location string
	return $location[0];
}

function format_time_difference($logged)
{
	global $lang;

	$difference = CURRENT_TIMESTAMP - $logged;
	$intervals = array('minute'=> 60); 
	if ($difference < 60)
	{
		if ($difference == '1')
			$difference = $lang->t('Second ago', $difference);
		else
			$difference = $lang->t('Seconds ago', $difference);
	}        

	if ($difference >= 60)
	{
		$difference = floor($difference/$intervals['minute']);
		if ($difference == '1')
			$difference = $lang->t('Minute ago', $difference);
		else
			$difference = $lang->t('Minutes ago', $difference);
	}  
	return $difference;
}

function colourise_group($username, $gid, $user_id = 1)
{
	global $aura_user, $aura_url;
	static $colourise_cache = array();

	if (!isset($colourise_cache[$username]))
	{
		$name = style_html('user_group_name', array($gid, aura_htmlspecialchars($username)));

		if ($aura_user['g_view_users'] == 1 && $user_id > 1)
			$colourise_cache[$username] = style_html('username_link', array(aura_link($aura_url['profile'], array($user_id, url_friendly($username))), $name));
		else
			$colourise_cache[$username] = $name;
	}

	return $colourise_cache[$username];
}

function attach_delete_thread($id = 0)
{
	global $db, $aura_config;

	// Should we orhpan any attachments
	if ($aura_config['o_create_orphans'] == 0)
	{
		$join = array(
			array(
				'type' => 'LEFT',
				'table' => 'posts',
				'as' => 'p',
				'on' => 'a.post_id=p.id',
			),
		);

		$data = array(
			':id' => $id,	
		);

		$ps = $db->join('attachments', 'a', $join, 'a.id', $data, 'p.topic_id=:id');
		if ($ps->rowCount())
		{
			$ps->setFetchMode(PDO::FETCH_COLUMN, 0);
			foreach ($ps as $attach_id)
			{
				if (!delete_attachment($attach_id))
					continue;
			}
		}
	}
}

function attach_delete_post($id = 0)
{
	global $db;

	$data = array(
		':id' => $id,
	);

	$ps = $db->select('attachments', 'id', $data, 'post_id=:id');
	if ($ps->rowCount())
	{
		$ps->setFetchMode(PDO::FETCH_COLUMN, 0);		
		foreach ($ps as $attach_id)
		{
				if (!delete_attachment($attach_id))
					continue;
		}
	}
}

function delete_attachment($item = 0)
{
	global $db, $aura_user, $aura_config;
	$join = array(
		array(
			'type' => 'LEFT',
			'table' => 'posts',
			'as' => 'p',
			'on' => 'a.post_id=p.id',
		),
		array(
			'type' => 'LEFT',
			'table' => 'topics',
			'as' => 't',
			'on' => 'p.topic_id=t.id',
		),
		array(
			'type' => 'LEFT',
			'table' => 'forum_perms',
			'as' => 'fp',
			'on' => 't.forum_id=fp.forum_id AND fp.group_id=:uid',
		),
	);

	$data = array(
		':uid' => $aura_user['g_id'],
		':id' => $item,
	);
	
	// Make sure the item actually exists
	$ps = $db->join('attachments', 'a', $join, 'a.owner, a.location', $data, 'a.id=:id');
	if (!$ps->rowCount())
		message($lang->t('Bad request'));
	else
		$attachment = $ps->fetch();
	
	$data = array(
		':id' => $item,
	);

	$db->delete('attachments', 'id=:id', $data);
	if ($aura_config['o_create_orphans'] == '0')
		@unlink($aura_config['o_attachments_dir'].$attachment['location']);

	return true;
}

function file_upload_error_message($code) 
{
	switch ($code) 
	{ 
		case UPLOAD_ERR_INI_SIZE: 
			return 'The uploaded file exceeds the upload_max_filesize configuration setting in php.ini'; 
		case UPLOAD_ERR_FORM_SIZE: 
			return 'The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form'; 
		case UPLOAD_ERR_PARTIAL: 
			return 'The uploaded file was only partially uploaded'; 
		case UPLOAD_ERR_NO_FILE: 
			return 'No file was uploaded'; 
		case UPLOAD_ERR_NO_TMP_DIR: 
			return 'Missing a temporary folder'; 
		case UPLOAD_ERR_CANT_WRITE: 
			return 'Failed to write file to disk'; 
		case UPLOAD_ERR_EXTENSION: 
			return 'File upload stopped by extension'; 
		default: 
			return 'An unknown upload error was encountered'; 
	} 
}

function create_attachment($name = '', $mime = '', $size = 0, $tmp_name = '', $post_id = 0, $message = 0)
{
	global $db, $aura_user, $aura_config;

	$unique_name = attach_generate_filename($aura_config['o_attachments_dir'], $message, $size);
	if (!move_uploaded_file($tmp_name, $aura_config['o_attachments_dir'].$unique_name))
		throw new Exception('Unable to move file from: '.$tmp_name.' to '.$aura_config['o_attachments_dir'].$unique_name);

	if (strlen($mime) < 1)
		$mime = attach_create_mime(attach_find_extention($name));

	$insert	= array(
		'owner'	=>	$aura_user['id'],
		'post_id'	=>	$post_id,
		'filename'	=>	$name,
		'extension'	=>	attach_get_extension($name),
		'mime'		=>	$mime,
		'location'	=>	$unique_name,
		'size'		=>	$size
	);

	$db->insert('attachments', $insert);
	return true;
}

function attach_generate_filename($storagepath, $messagelength = 0, $size = 0)
{
	// Login keys are one time use only. Use this as salt too.
	global $aura_user;

	$newfile = md5($messagelength.$size.$aura_user['login_key'].random_key(18)).'.attach';
	if (!is_file($storagepath.$newfile))
		return $newfile;
	else
		return attach_generate_filename($storagepath, $messagelength, $size);
}

function attach_create_mime($extension = '')
{
	// Some of these may well no longer exist.
	$mimes = array (
		'diff'			=> 		'text/x-diff',
		'patch'			=> 		'text/x-diff',
		'rtf' 			=>		'text/richtext',
		'html'			=>		'text/html',
		'htm'			=>		'text/html',
		'aiff'			=>		'audio/x-aiff',
		'iff'			=>		'audio/x-aiff',
		'basic'			=>		'audio/basic',
		'wav'			=>		'audio/wav',
		'gif'			=>		'image/gif',
		'jpg'			=>		'image/jpeg',
		'jpeg'			=>		'image/pjpeg',
		'tif'			=>		'image/tiff',
		'png'			=>		'image/x-png',
		'xbm'			=>		'image/x-xbitmap',
		'bmp'			=>		'image/bmp',
		'xjg'			=>		'image/x-jg',
		'emf'			=>		'image/x-emf',
		'wmf'			=>		'image/x-wmf',
		'avi'			=>		'video/avi',
		'mpg'			=>		'video/mpeg',
		'mpeg'			=>		'video/mpeg',
		'ps'			=>		'application/postscript',
		'b64'			=>		'application/base64',
		'macbinhex'		=>		'application/macbinhex40',
		'pdf'			=>		'application/pdf',
		'xzip'			=>		'application/x-compressed',
		'zip'			=>		'application/x-zip-compressed',
		'gzip'			=>		'application/x-gzip-compressed',
		'java'			=>		'application/java',
		'msdownload'	=>		'application/x-msdownload'
	);

	foreach ($mimes as $type => $mime)
	{
		if ($extension == $type)
			return $mime;
	}
	return 'application/octet-stream';
}

function attach_get_extension($filename = '')
{
	if (strlen($filename) < 1)
		return '';

	return strtolower(ltrim(strrchr($filename, "."), "."));
}

function check_file_extension($file_name)
{
	global $aura_config;

	$actual_extension = attach_get_extension($file_name);
	$always_deny = explode(',', $aura_config['o_always_deny']);
	foreach ($always_deny as $ext)
	{
		if ($ext == $actual_extension)
			return false;
	}
	
	return true;
}

function attach_icon($extension)
{
	global $aura_config, $aura_user;
	static $base_url, $attach_icons;

	$icon_dir = ($aura_config['o_attachment_icon_dir'] != '') ? $aura_config['o_attachment_icon_dir'] : get_base_url().'/'.$aura_config['o_attachment_icon_path'].'/';
	if ($aura_user['show_img'] == 0 || $aura_config['o_attachment_icons'] == 0)
		return '';

	if (!isset($attach_icons))
	{
		$attach_icons = array();
		$extensions = explode(',', $aura_config['o_attachment_extensions']);
		$icons = explode(',', $aura_config['o_attachment_images']);

		for ($i = 0; $i < count($extensions); $i++)
		{
			if (!isset($extensions[$i]) || !isset($icons[$i]))
				break;

			$attach_icons[$extensions[$i]] = $icons[$i];
		}
	}

	$icon = isset($attach_icons[$extension]) ? $attach_icons[$extension] : 'unknown.png';
	return array('file' => $icon_dir.$icon, 'extension' => $extension);
}

function return_bytes($val)
{
    $last = strtolower($val[strlen($val)-1]);
    switch($last)
	{
		case 'g':
            $val *= 1024;
		case 'm':
            $val *= 1024;
		case 'k':
            $val *= 1024;
    }

    return $val;
}

function check_authentication()
{
	global $db, $aura_config, $aura_user;
	
	function send_authentication()
	{
		global $lang;

		header('WWW-Authenticate: Basic realm="Aura Admin CP"');
		header('HTTP/1.1 401 Unauthorized');
		message($lang->t('Unauthorised'));
	}

	if ($aura_config['o_http_authentication'] == '1')
	{
		if (!isset($_SERVER['PHP_AUTH_USER']) && !isset($_SERVER['PHP_AUTH_PW']))
			send_authentication();
		else if (isset($_SERVER['PHP_AUTH_USER']) && isset($_SERVER['PHP_AUTH_PW']))
		{
			$form_username = aura_trim($_SERVER['PHP_AUTH_USER']);
			$form_password = aura_trim($_SERVER['PHP_AUTH_PW']);
			
			$data = array(
				':id'	=>	$aura_user['id'],
				':username'	=>	$form_username,
			);

			$ps = $db->select('users', 'password, salt', $data, 'username=:username AND id=:id');
			if (!$ps->rowCount())
				send_authentication();
			else
			{
				$cur_user = $ps->fetch();
				if (!aura_hash_equals($cur_user['password'], aura_hash($form_password.$cur_user['salt'])))
					send_authentication();
			}
		}
	}
}

// Generate link to another page on the forum
function aura_link($link, $args = null)
{
	static $base_url;
	$base_url = (!$base_url) ? get_base_url() : $base_url;

	$gen_link = $link;
	if ($args == null)
		$gen_link = $base_url.'/'.$link;
	else if (!is_array($args))
		$gen_link = $base_url.'/'.str_replace('$1', $args, $link);
	else
	{
		for ($i = 0; isset($args[$i]); ++$i)
			$gen_link = str_replace('$'.($i + 1), $args[$i], $gen_link);

		$gen_link = $base_url.'/'.$gen_link;
	}

	return $gen_link;
}

// Generate a hyperlink with parameters and anchor and a subsection such as a subpage
function get_sublink($link, $sublink, $subarg, $args = null)
{
	global $aura_url;
	static $base_url = null;

	$base_url = (!$base_url) ? get_base_url() : $base_url;

	// If there is only one page, then return the canonical url with no page numbers attached
	if ($sublink == $aura_url['page'] && $subarg == 1)
	{
		if (isset($aura_url['insertion_find']))
			return str_replace($aura_url['insertion_find'], '', aura_link($link, $args));
		else
			return aura_link($link, $args);
	}

	$gen_link = $link;
	if (!is_array($args) && $args != null)
		$gen_link = str_replace('$1', $args, $link);
	else
	{
		for ($i = 0; isset($args[$i]); ++$i)
			$gen_link = str_replace('$'.($i + 1), $args[$i], $gen_link);
	}

	if (isset($aura_url['insertion_find']))
		$gen_link = $base_url.'/'.str_replace($aura_url['insertion_find'], str_replace('$1', str_replace('$1', $subarg, $sublink), $aura_url['insertion_replace']), $gen_link);
	else
		$gen_link = $base_url.'/'.$gen_link.str_replace('$1', $subarg, $sublink);

	return $gen_link;
}

function style_html($html, $args = null)
{
	global $aura_style;

	// If the cache has failed for some reason, just fall back on the default styles.xml
	if (is_null($aura_style))
	{
		$parser = new XMLParser;
		$parser->load(AURA_ROOT.'include/styles.xml');
		$style = $parser->fetch_array();

		$config = array();
		foreach ($style['style'] as $name => $item)
		{
			if ($name == 'data')
				continue;

			$aura_style[$name] = isset($item['data']) ? aura_trim($item['data']) : '';
		}
	}

	if ($args == null)
		return $aura_style[$html];
	else if (!is_array($args))
		return str_replace('$1', $args, $aura_style[$html]);

	$html = $aura_style[$html];
	for ($i = 0; isset($args[$i]); ++$i)
		$html = str_replace('$'.($i + 1), $args[$i], $html);

	return $html;
}

// Make a string safe to use in a URL
function url_friendly($str)
{
	static $url_replace;

	if (!isset($url_replace))
		require AURA_ROOT.'include/url_replace.php';

	$str = strtr($str, $url_replace);
	$str = strtolower(utf8_decode($str));
	$str = aura_trim(preg_replace(array('/[^a-z0-9\s]/', '/[\s]+/'), array('', '-'), $str), '-');

	return $str;
}

//
//	Generate a one time use login key to set in the cookie
//
function generate_login_key($uid = 1)
{
	global $db, $aura_user;
	$key = random_pass(60);

	$data = array(
		':key'	=>	$key,
	);
	
	$ps = $db->select('users', 1, $data, 'login_key=:key');
	if ($ps->rowCount()) // There is already a key with this string (keys are unique)
		generate_login_key();
	else
	{
		$data = array(
			':id'	=>	($uid !=1) ? $uid : $aura_user['id'],
		);
		
		$update = array(
			'login_key'	=>	$key,
		);

		$db->update('users', $update, 'id=:id', $data);
		return $key;
	}
}

function check_archive_rules($archive_rules, $tid = 0)
{
	global $cur_topic, $db;
	
	$day = (24*60*60);	// Set some useful time related stuff
	$month = (24*60*60*date('t'));
	$year = ($month*12);

	$sql = $data = array();
	if ($archive_rules['closed'] != '2')
	{
		$data[] = $archive_rules['closed'];
		$sql[] = 'closed=?';
	}
	
	if ($archive_rules['sticky'] != '2')
	{
		$data[] = $archive_rules['sticky'];
		$sql[] = 'sticky=?';
	}
	
	if ($archive_rules['time'] != '0')
	{
		switch ($archive_rules['unit'])
		{
			case 'years':
				$seconds = $archive_rules['time']*$year;
			break;
			case 'months':
				$seconds = $archive_rules['time']*$month;
			break;
			case 'days':
			default:
				$seconds = $archive_rules['time']*$day;
			break;
		}

		$data[] = (CURRENT_TIMESTAMP-$seconds);
		$sql[] = 'last_post<?';
	}
	
	if ($archive_rules['forums'][0] != '0')
	{
		$forums = '';
		for ($i = 0; $i < count($i); $i++)
		{
			$forums .= ($forums != '') ? ',?' : '?';
			$data[] = $archive_rules['forums'][$i];
		}
		$sql[] = 'forum_id IN('.$forums.')';
	}

	if ($tid != 0)
	{
		$sql[] = 'id=?';
		$data[] = $tid;
		$fetch = 1;
	}
	else
	{
		$fetch = 'id';
		$sql[] = 'archived=0 AND deleted=0 AND approved=1';	// Make sure to get topics that have the ability to be archived
	}

	$ps = $db->select('topics', $fetch, $data, implode(' AND ', $sql));
	
	if ($tid != 0)
	{
		if ($ps->rowCount()) // Time to archive!
		{
			$update = array(
				'archived'	=>	1,
			);
			
			$data = array(
				':id'	=>	$tid,
			);

			return $db->update('topics', $update, 'id=:id', $data);
		}
		else
			return 0;
	}
	else
	{
		$topics = array(
			'count'	=>	$ps->rowCount(),
			'topics'	=>	array(),
		);

		$ps->setFetchMode(PDO::FETCH_COLUMN, 0);
		foreach ($ps as $tid)
			$topics['topics'][] = $tid;
	}
		return $topics;
}

//
// Format time in seconds to display as hours/days/months/never
//
function format_expiration_time($seconds)
{
	global $lang;
	$seconds = intval($seconds);

	if ($seconds <= 0)
		return $lang->t('Never');
	else if ($seconds % (30*24*60*60) == '0')
	{
		//Months
		$expiration_value = $seconds / (30*24*60*60);
		return $lang->t('No of months', $expiration_value);
	}
	else if ($seconds % (24*60*60) == '0')
	{
		//Days
		$expiration_value = $seconds / (24*60*60);
		return $lang->t('No of days', $expiration_value);
	}
	else
	{
		//Hours
		$expiration_value = $seconds / (60*60);
		return $lang->t('No of hours', $expiration_value);
	}
}

//
// Get expiration time (in seconds)
//
function get_expiration_time($value = 0, $unit)
{
	$value = abs(intval($value));

	if ($value == '0')
		$expiration_time = 0;
	else if ($unit == 'minutes')
		$expiration_time = $value*60;
	else if ($unit == 'hours')
		$expiration_time = $value*60*60;
	else if ($unit == 'days')
		$expiration_time = $value*24*60*60;
	else if ($unit == 'months')
		$expiration_time = $value*30*24*60*60;
	else if ($unit == 'never')
		$expiration_time = 0;
	else 
		$expiration_time = 0;

	return $expiration_time;
}

//
// Checks when a posting ban has expired
//
function format_posting_ban_expiration($expires)
{
	global $lang;

	$month = (24*60*60*date('t'));
	$day = (24*60*60);
	$hour = (60*60);
	$minute = 60;
	switch(true)
	{
		case ($expires > $month):
			$seconds = array(round($expires/$month), ($expires % $month), $lang->t('Months'));
		break;
		case ($expires > $day):
			$seconds = array(round($expires/$day), ($expires % $day), $lang->t('Days'));
		break;
		case ($expires > $hour):
			$seconds = array(round($expires/$hour), ($expires % $hour), $lang->t('Hours'));
		break;
		case ($expires > $minute):
			$seconds = array(round($expires/$minute), ($expires % $minute), $lang->t('Minutes'));
		break;
		default:
			$seconds = array(10, 0, $lang->t('Never'));			
		break;
	}

	return $seconds;
}

function check_posting_ban()
{
	global $aura_user, $db, $lang;

	if ($aura_user['posting_ban'] != '0')
	{
		if ($aura_user['posting_ban'] < CURRENT_TIMESTAMP)
		{
			$update = array(
				'posting_ban'	=>	0,
			);

			$data = array(
				':id'	=>	$aura_user['id'],
			);

			$db->update('users', $update, 'id=:id', $data);
		}
		else
			message($lang->t('posting_ban', format_time($aura_user['posting_ban'])));
	}
}

function stopforumspam_report($api_key, $remote_address, $email, $username, $message)
{
	$context = stream_context_create(
		array('http' => 
			array(
				'method'	=> 'POST',
				'header'	=> 'Content-type: application/x-www-form-urlencoded',
				'content'	=> http_build_query(
					array(
						'ip_addr'	=> $remote_address,
						'email'		=> $email,
						'username'	=> $username,
						'evidence'	=> $message,
						'api_key'	=> $api_key,
					)
				),
			)
		)
	);

	return @file_get_contents('http://www.stopforumspam.com/add', false, $context) ? true : false;
}

//
// Compress image using TinyPNG compression API
//
function compress_image($image)
{
	global $aura_config;
	if ($aura_config['o_tinypng_api'] == '')
		return;

	if (substr($image, strrpos($image, '.')+1) == 'gif') // Then it can't be compressed, and will return nothing causing the error handler
	{
		$key = max(array_keys(explode('/', $image)));
		cache_cloudflare($image[$key]);
		return;
	}

	if (is_callable('curl_init'))
	{
		$request = curl_init();
		curl_setopt_array($request, array(
			CURLOPT_URL => "https://api.tinypng.com/shrink",
			CURLOPT_USERPWD => "api:".$aura_config['o_tinypng_api'],
			CURLOPT_POSTFIELDS => file_get_contents($image),
			CURLOPT_BINARYTRANSFER => true,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_HEADER => true,
			CURLOPT_SSL_VERIFYPEER => true
		));

		$response = curl_exec($request);
		if (curl_getinfo($request, CURLINFO_HTTP_CODE) === 201)
		{
			$headers = substr($response, 0, curl_getinfo($request, CURLINFO_HEADER_SIZE));
			foreach (explode("\r\n", $headers) as $header)
			{
				if (substr($header, 0, 10) === "Location: ")
				{
					$request = curl_init();
					curl_setopt_array($request, array(
						CURLOPT_URL => substr($header, 10),
						CURLOPT_RETURNTRANSFER => true,
						CURLOPT_SSL_VERIFYPEER => true
					));

					// Replace the image with the compressed one
					file_put_contents($image, curl_exec($request));
				}
			}
		}
		else
			throw new Exception(curl_error($request));
			
		// We only want this doing if the first one works
		$key = max(array_keys(explode('/', $image)));
		cache_cloudflare($image[$key]);
	}
}

//
// Cache images through CloudFlare API
//
function cache_cloudflare($file)
{
	global $aura_config;

	if ($aura_config['o_cloudflare_api'] != '')
		return;

	if (is_callable('curl_init'))
	{
		$request = curl_init("https://www.cloudflare.com/api_json.html");
		curl_setopt($request, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($request, CURLOPT_FOLLOWLOCATION, 1);
		curl_setopt($request, CURLOPT_SSL_VERIFYPEER, false);

		$params = array(
			'a' => 'zone_file_purge',
			'tkn' => $aura_config['o_cloudflare_api'],
			'email' => $aura_config['o_clouflare_email'],
			'z' => $aura_config['o_clouflare_domain'],
			'url' => $aura_config['o_clouflare_domain'].$file,
		);
		curl_setopt($request, CURLOPT_POST, 1);
		curl_setopt($request, CURLOPT_POSTFIELDS, http_build_query($params));
		$response = curl_exec($request);
		if (curl_getinfo($request, CURLINFO_HTTP_CODE) === 201)
		{
			$result = json_decode($response, true);
			curl_close($request);

			if ($result['msg'] != 'success')
				throw new Exception($result['msg']);

			return true;
		}
	}
}

function xml_to_array($raw_xml)
{
	$xml_array = array();
	$xml_parser = xml_parser_create();
	xml_parser_set_option($xml_parser, XML_OPTION_CASE_FOLDING, 0);
	xml_parser_set_option($xml_parser, XML_OPTION_SKIP_WHITE, 0);
	xml_parse_into_struct($xml_parser, $raw_xml, $parsed_xml);
	xml_parser_free($xml_parser);

	foreach ($parsed_xml as $xml_elem)
	{
		$x_tag = $xml_elem['tag'];
		$x_level = $xml_elem['level'];
		$x_type = $xml_elem['type'];

		if ($x_level != 1 && $x_type == 'close')
		{
			if (isset($multi_key[$x_tag][$x_level]))
				$multi_key[$x_tag][$x_level] = 1;
			else
				$multi_key[$x_tag][$x_level] = 0;
		}

		if ($x_level != 1 && $x_type == 'complete')
		{
			if (isset($tmp) && $tmp == $x_tag)
				$multi_key[$x_tag][$x_level] = 1;

			$tmp = $x_tag;
		}
	}

	foreach ($parsed_xml as $xml_elem)
	{
		$x_tag = $xml_elem['tag'];
		$x_level = $xml_elem['level'];
		$x_type = $xml_elem['type'];

		if ($x_type == 'open')
			$level[$x_level] = $x_tag;

		$start_level = 1;
		$php_stmt = '$xml_array';
		if ($x_type == 'close' && $x_level != 1)
			$multi_key[$x_tag][$x_level]++;

		while ($start_level < $x_level)
		{
			$php_stmt .= '[$level['.$start_level.']]';
			if (isset($multi_key[$level[$start_level]][$start_level]) && $multi_key[$level[$start_level]][$start_level])
				$php_stmt .= '['.($multi_key[$level[$start_level]][$start_level]-1).']';

			++$start_level;
		}

		$add = '';
		if (isset($multi_key[$x_tag][$x_level]) && $multi_key[$x_tag][$x_level] && ($x_type == 'open' || $x_type == 'complete'))
		{
			if (!isset($multi_key2[$x_tag][$x_level]))
				$multi_key2[$x_tag][$x_level] = 0;
			else
				$multi_key2[$x_tag][$x_level]++;

			$add = '['.$multi_key2[$x_tag][$x_level].']';
		}

		if (isset($xml_elem['value']) && aura_trim($xml_elem['value']) != '' && !isset($xml_elem['attributes']))
		{
			if ($x_type == 'open')
				$php_stmt_main = $php_stmt.'[$x_type]'.$add.'[\'content\'] = $xml_elem[\'value\'];';
			else
				$php_stmt_main = $php_stmt.'[$x_tag]'.$add.' = $xml_elem[\'value\'];';

			eval($php_stmt_main);
		}

		if (isset($xml_elem['attributes']))
		{
			if (isset($xml_elem['value']))
			{
				$php_stmt_main = $php_stmt.'[$x_tag]'.$add.'[\'content\'] = $xml_elem[\'value\'];';
				eval($php_stmt_main);
			}

			foreach ($xml_elem['attributes'] as $key=>$value)
			{
				$php_stmt_att=$php_stmt.'[$x_tag]'.$add.'[\'attributes\'][$key] = $value;';
				eval($php_stmt_att);
			}
		}
	}

	// Make sure there's an array of hooks (even if there is only one)
	if (isset($xml_array['extension']['hooks']) && isset($xml_array['extension']['hooks']['hook']))
	{
		if (!is_array(current($xml_array['extension']['hooks']['hook'])))
			$xml_array['extension']['hooks']['hook'] = array($xml_array['extension']['hooks']['hook']);
	}

	return $xml_array;
}

function get_extensions($hook)
{
	global $aura_extensions;
	return (isset($aura_extensions[$hook])) ? implode("\n", $aura_extensions[$hook]) : false;
}

function delete_directory($path)
{
	if (!file_exists($path))
		return;

	if (is_dir($path))
	{
		$objects = array_diff(scandir($path), array('.', '..'));
		foreach ($objects as $object)
		{
			if (filetype($path.DIRECTORY_SEPARATOR.$object) == 'dir')
				delete_directory($path.DIRECTORY_SEPARATOR.$object);
			else
				unlink($path.DIRECTORY_SEPARATOR.$object);
		}
	}

	reset($objects);
	rmdir($path);
}

function autoloader($class)
{
	if (file_exists(AURA_ROOT.'include/classes/'.$class.'.php'))
		require AURA_ROOT.'include/classes/'.$class.'.php';
}

function parse_email($tpl, $language, $data)
{
	global $aura_config;

	$mail_tpl = trim(file_get_contents(lang::mail_template_location($language).$tpl.'.tpl'));
	$data['message']['<board_mailer>'] = $aura_config['o_board_title'];

	// The first row contains the subject (it also starts with "Subject:")
	$first_crlf = strpos($mail_tpl, "\n");
	$mail_subject = trim(substr($mail_tpl, 8, $first_crlf-8));
	$mail_message = trim(substr($mail_tpl, $first_crlf));
		
	if (isset($data['subject']))
		$mail_subject = str_replace(array_keys($data['subject']), array_values($data['subject']), $mail_subject);
		
	$mail_message = str_replace(array_keys($data['message']), array_values($data['message']), $mail_message);
	return array('subject' => $mail_subject, 'message' => $mail_message);
}

($hook = get_extensions('functions_after_functions')) ? eval($hook) : null;