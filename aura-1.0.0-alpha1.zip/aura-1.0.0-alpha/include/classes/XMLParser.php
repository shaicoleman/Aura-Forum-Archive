<?php
class XMLParser extends DOMDocument
{
	public function __construct($version = '1.0', $charset = 'utf-8')
	{
		parent::__construct($version, $charset);
	}

	public function fetch_array()
	{
		return $this->xml_to_array($this);
	}

	protected function xml_to_array($node)
	{
		$xml = array();
		if ($node->nodeType == XML_TEXT_NODE) // If this is the actual data
			$xml = $this->convert_utf8($node->nodeValue);
		else if ($node->nodeType == XML_CDATA_SECTION_NODE) // If we're on the CDATA section
			$xml = $this->convert_utf8($node->nodeValue);
		else
		{
			// Does this element have any specific attributes?
			if ($node->hasAttributes())
			{
				$attributes = $node->attributes;
				foreach ($attributes as $index => $attribute)
					$xml['attributes'][$attribute->name] = $attribute->value;
			}

			// Are there any child nodes?
			if ($node->hasChildNodes())
			{
				$nodes = array();
				$children = $node->childNodes;
				foreach ($children as $child)
				{
					if ($child->nodeName != '#text' && $child->nodeName != '#cdata-section')
						$nodes[$child->nodeName] = isset($nodes[$child->nodeName]) ? $nodes[$child->nodeName] + 1 : 1;
				}

				for ($i = 0; $i < $children->length; $i++)
				{
					$child = $children->item($i);
					$name = $child->nodeName;

					if ($child->nodeName == '#text' || $child->nodeName == '#cdata-section')
						$name = 'data';

					if (isset($nodes[$child->nodeName]) && $nodes[$child->nodeName] > 1)
						$xml[$name][] = $this->xml_to_array($child);
					else
						$xml[$name] = $this->xml_to_array($child);
				}
			}
		}

		return $xml;
	}

	public function fetch_xml($data, DOMElement $element = null)
	{
		$element = !is_null($element) ? $element : $this;

		if (is_array($data))
		{
			if (isset($data['attributes']))
			{
				foreach ($data['attributes'] as $name => $attribute)
				{
					$node = $element->setAttribute($name, $attribute);
					$element->appendChild($node);
				}

				unset($data['attributes']);
			}

			foreach ($data as $index => $d)
			{
				if (is_int($index))
				{
					if ($index == 0)
						$node = $element;
					else
					{
						$node = $this->createElement($element->tagName);
						$element->parentNode->appendChild($node);
					}
				}
				else
				{
					$node = $this->createElement($index);
					$element->appendChild($node);
				}

				$this->fetch_xml($d, $node);
			}
		}
		else
		{
			// Check if we need to create a CDATA section
			if (preg_match('/[\'\"\[\]<>&]/', $data))
				$element->appendChild($this->createCDATASection($this->escape_cdata($data)));
			else
				$element->appendChild($this->createTextNode($data));
		}
	}
	
	public function convert_utf8($data)
	{
		if ($this->encoding == 'utf-8')
			return $data;
		else if ($this->encoding == 'iso-8859-1') // Most commonly used encoding type with XML
			return utf8_decode($data);
		else
		{
			return $data; // Do something
		}
	}

	public function escape_cdata($str)
	{
		return str_replace(']]>', ']]&gt;', $str);
	}
}