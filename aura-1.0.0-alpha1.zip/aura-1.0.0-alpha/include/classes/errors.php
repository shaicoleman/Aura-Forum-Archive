<?php
class errors
{
	protected $db_error = false;
	protected $premature_exception = false;
	public function __construct($aura_config = array(), $aura_user = array(), $aura_url = array())
	{
		if (empty($aura_config))
		{
			// Make an educated guess regarding base_url
			$base_url  = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') ? 'https://' : 'http://';	// protocol
			$base_url .= preg_replace('%:(80|443)$%', '', $_SERVER['HTTP_HOST']);							// host[:port]
			$base_url .= str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));							// path

			if (substr($base_url, -1) == '/')
				$base_url = substr($base_url, 0, -1);

			$aura_config = array(
				'o_board_title'	=> 'Aura',
				'o_gzip'		=> '0',
				'o_debug_mode'	=>	'1',
				'o_webmaster_email'	=>	$_SERVER['SERVER_ADMIN'],
				'o_default_style'	=>	'Pantherone',
				'o_base_url'	=>	$base_url,
				'o_style_dir' => 'styles/',
				'o_style_path' => '/styles/',
			);

			$this->premature_exception = true;
		}

		if (empty($aura_user))
		{
			$aura_user = array(
				'style' => $aura_config['o_default_style'],
				'is_admin' => false,
				'is_admmod' => false,
				'is_guest' => true,
			);

			$this->premature_exception = true;
		}

		if (empty($aura_url))
		{
			require AURA_ROOT.'include/url/default.php';
			$this->premature_exception = true;
		}

		$this->config = $aura_config;
		$this->user = $aura_user;
		$this->url = $aura_url;

		$this->lang = array(
			'lang_identifier' => 'en',
			'Server' => 'server',
			'Database' => 'database',
			'Database error' => 'Database Error',
			'Server error' => 'Server Error',
			'Exception trace' => '%s in %s on line %s',
			'Request aborted' => 'The request was aborted: A %s error was encountered.',
			'Database error line 1' => 'The server encountered a database error, we\'ve been unable to display the page you requested. Please try again.',
			'Database error line 2' => 'If the issue persists, contact the server administrator and inform them of the time the error occured, along with anything you may have done which could have caused the error.',
			'Database reported' => 'Database Reported:',
			'Failed sql' => 'Failed SQL:',
			'Parameters' => 'Parameters:',
			'Contact admin' => 'Contact server administrator',
			'Try again' => 'Try again',
			'Back to index' => 'Back to the index',
			'Server error line 1' => 'The server encountered an internal error or misconfiguration, we\'ve been unable to display the page you requested.',
			'Server error line 2' => 'We apologise for the inconvenience this may have caused, use the link below to try again, alternatively you can return to the board index.',
			'Server error line 3' => 'Errno [%s] %s in  %s on line %s',
		);
	}

	// Main entry point - Errors, Exceptions and Fatal errors all get routed here
	public function handle($errno = 0, $errstr = 'Error', $errfile = 'unknown', $errline = 0)
	{
		if (error_reporting() == 0) // If we want to supress errors
			return;

		// First we check for exceptions rather than errors
		if (!is_int($errno))
		{
			list(, $errstr, $errfile, $errline) = $this->parse_exception($errno);
			$errno = 1;

			if (is_json($errstr)) // Then we check if it's specifically a database exception, these are generated differently
			{
				$error = json_decode($errstr, true);

				$this->db_error = true;
				$errstr = $error['message'];
				$errsql = $error['sql'];
				$errparameters = $error['parameters'];
				$errfile = $error['trace'][1]['file'];
				$errline = $error['trace'][1]['line'];
			}
		}
		else
			$this->db_error = false;

		// Stop register_shutdown_function interfering in normal circumstances
		$error = error_get_last();
		if ($errno < 1 && $error['type'] !== E_ERROR)
			exit;

		// Check if we're dealing with a fatal error (these must be handled seperately with register_shutdown_function)
		if ($error['type'] == E_ERROR)
		{
			$errno = $error['type'];
			$errstr = $error['message'];
			$errfile = $error['file'];
			$errline = $error['line'];
		}

		// We don't want to expose anything other than the forum structure
		$errfile = substr(str_replace(realpath(AURA_ROOT), '', $errfile), 1);

		// Empty all output buffers and stop buffering (only if we've started)
		if (ob_get_level() > 0 && ob_get_length())
			@ob_clean();

		// If we've failed on an AJAX request, it's a premature exception, or we're using the CLI interface, we'd better not send HTML
		if (defined('AURA_AJAX_REQUEST') || $this->premature_exception || substr(PHP_SAPI, 0, 3) == 'cli')
		{
			if ($this->config['o_debug_mode'] == '1')
				exit(sprintf($this->lang['Exception trace'], $errstr, $errfile, $errline));

			exit(sprintf($this->lang['Request aborted'], (($this->db_error) ? $this->lang['Database'] : $this->lang['Server'])));
		}
		else if (!headers_sent()) // Ticket #YCZ-278-40842 - Headers sporadically messing with error handling of AJAX requests
		{
			// "Restart" output buffering if we are using ob_gzhandler (since the gzip header is already sent)
			if ($this->config['o_gzip'] && extension_loaded('zlib') && !ob_get_length())
				ob_start('ob_gzhandler');

			// Send no-cache headers
			header('Expires: Thu, 21 Jul 1977 07:30:00 GMT'); // When yours truly first set eyes on this world! :)
			header('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT');
			header('Cache-Control: post-check=0, pre-check=0', false);
			header('Pragma: no-cache'); // For HTTP/1.0 compatibility

			// Send the Content-type header in case the web server is setup to send something else
			header('Content-type: text/html; charset=utf-8');

			// Send headers telling people we're down
			header('HTTP/1.1 503 Service Temporarily Unavailable');
			header('Status: 503 Service Temporarily Unavailable');
		}

		// Check and see if we have a custom error style for this style, otherwise fallback to the core error style
		$style_path = ($this->config['o_style_dir'] != '') ? $this->config['o_style_dir'] : AURA_ROOT.$this->config['o_style_dir'].'styles/';
		if (file_exists($style_path.$this->user['style'].'/error.css'))
			$error_style = (($this->config['o_style_dir']) != '' ? $this->config['o_style_dir'] : get_base_url().'/styles/').$this->user['style'];
		else
			$error_style = (($this->config['o_style_dir']) != '' ? $this->config['o_style_dir'] : get_base_url().'/styles/').'core';

		$args = array(
			'aura_config' => $this->config,
			'error_style' => $error_style,
			'lang' => $this->lang,
			'page_title' => generate_page_title(array($this->config['o_board_title'], (($this->db_error) ? $this->lang['Database error'] : $this->lang['Server error']))),
			'errno' => $errno,
			'errstr' => $errstr,
			'errfile' => $errfile,
			'errline' => $errline,
			'index' => aura_link($this->url['index']),
		);

		if ($this->db_error)
		{
			ob_start();
			dump($errparameters);
			$debug = trim(ob_get_contents());
			ob_end_clean();

			$tpl = load_template('db_error.tpl');
			echo $tpl->render(
				array_merge(
					$args, array(
						'error' => $errstr,
						'sql' => $errsql,
						'debug' => $debug,
					)
				)
			);
		}
		else
		{
			$tpl = load_template('server_error.tpl');
			echo $tpl->render($args);
		}

		exit;
	}

	protected function parse_exception($str)
	{
		if (preg_match("/message '(.*)' in (.*):([0-9]+)/", $str, $matches))
			return $matches;

		return 'unknown exception';
	}
}

class DBException extends Exception
{
	public function __construct($message, $sql = '', $parameters = array())
	{
		$message = array(
			'message' => $message,
			'sql' => $sql,
			'parameters' => $parameters,
			'trace' => $this->getTrace(),
		);

		parent::__construct(json_encode($message), $this->getCode(), $this->getPrevious());
	}
}