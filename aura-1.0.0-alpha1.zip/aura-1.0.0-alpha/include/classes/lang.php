<?php
class lang
{
	protected $translations = array();
	protected static $lang_dir = 'languages';
	protected static $default_lang = 'en_GB';
	protected $lang = 'en_GB';
	protected $loaded_resources = array();

	public function __construct($cache)
	{
		self::set_default_language(self::$default_lang);
		$this->cache = $cache;
	}

	public static function get_language_locales()
	{
		static $locales = array();

		$languages = self::get_language_list();
		foreach ($languages as $language)
		{
			if (file_exists(AURA_ROOT.'/'.self::$lang_dir.'/'.$language.'/locale.txt'))
				$locales[$language] = file_get_contents(AURA_ROOT.'/'.self::$lang_dir.'/'.$language.'/locale.txt');
			else
				$locales[$language] = null;
		}

		return $locales;
	}

	public static function get_language_stopwords()
	{
		static $stopwords = array();

		$languages = self::get_language_list();
		foreach ($languages as $language)
		{
			if (file_exists(AURA_ROOT.'/'.self::$lang_dir.'/'.$language.'/stopwords.txt'))
				$stopwords = array_merge($stopwords, file(AURA_ROOT.'/'.self::$lang_dir.'/'.$language.'/stopwords.txt'));
		}

		return $stopwords;
	}

	public static function mail_template_location($language)
	{
		return AURA_ROOT.'/'.self::$lang_dir.'/'.$language.'/mail_templates/';
	}

	public static function get_language_list()
	{
		static $list = null;

		if (!isset($list))
		{
			$list = array();
			foreach (glob(AURA_ROOT.self::$lang_dir.'/*', GLOB_ONLYDIR) as $dir)
			{
				$dirs = explode('/', $dir);
				$list[] = end($dirs);
			}
		}

		return $list;
	}

	public static function language_exists($lang)
	{
		return in_array($lang, self::get_language_list());
	}

	public static function set_default_language($lang)
	{
		if (self::language_exists($lang))
			self::$default_lang = $lang;
		else
			throw new Exception('Language '.$lang.' cannot be found');
	}

	public function set_language($lang)
	{
		if (self::language_exists($lang))
			$this->lang = $lang;
		else
			throw new Exception('Language '.$lang.' cannot be found');
	}

	public function load($resource, $path = '')
	{
		// Make sure we don't load it twice
		if (in_array($resource, $this->loaded_resources))
			return;

		$this->loaded_resources[] = $resource;
		if ($path == '')
			$path = AURA_ROOT.'/'.self::$lang_dir;
		else if ($path != '' && !file_exists($path))
			throw new Exception('File path '.$path.' does not exist or cannot be found');

		$trans_cache = $this->cache->get('language', array($this->lang, $resource, $path), true, true); 
		if (self::$default_lang != $this->lang) // If this isn't the default language then load that too, and we'll use it for fallback
		{
			$def_trans_cache = $this->cache->get('language', array(self::$default_lang, $resource, $path), true, true);
			$trans_cache = array_merge($def_trans_cache, $trans_cache);
		}

		// Store the loaded values for usage
		$this->translations = array_merge($this->translations, $trans_cache);
	}

	public function t($str)
	{
		if (isset($this->translations[$str]))
		{
			$args = func_get_args();
			$args[0] = $this->translations[$args[0]];
			return call_user_func_array('sprintf', $args);
		}

		return $str;
	}
}