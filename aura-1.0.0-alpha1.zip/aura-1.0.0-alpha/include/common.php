<?php
/**
 * Copyright (C) 2017 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

if (!defined('AURA_ROOT'))
	exit('The constant AURA_ROOT must be defined and point to a valid Panther installation root directory.');

// Check if we're using an AJAX request (i.e. reputation) 
if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest')
	define('AURA_AJAX_REQUEST', 1);

if (function_exists('date_default_timezone_set') && function_exists('date_default_timezone_get'))
	date_default_timezone_set(@date_default_timezone_get());

// Block prefetch requests
if (isset($_SERVER['HTTP_X_MOZ']) && $_SERVER['HTTP_X_MOZ'] == 'prefetch')
{
	header('HTTP/1.1 403 Prefetching Forbidden');
    
	// Send no-cache headers
	header('Expires: Thu, 21 Jul 1977 07:30:00 GMT'); // When yours truly first set eyes on this world! :)
	header('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT');
	header('Cache-Control: post-check=0, pre-check=0', false);
	header('Pragma: no-cache'); // For HTTP/1.0 compatibility
	exit;
}

// Attempt to load the configuration file config.php
if (file_exists(AURA_ROOT.'include/config.php'))
	require AURA_ROOT.'include/config.php';

require AURA_ROOT.'include/lib/Twig/Autoloader.php';

// Register Twig autoloader
Twig_Autoloader::register();

// Load the functions script
require AURA_ROOT.'include/functions.php';

// Register the autoloader for non-existing classes
spl_autoload_register('autoloader');

// Load UTF-8 functions
require AURA_ROOT.'include/lib/utf8/utf8.php';

// Strip out "bad" UTF-8 characters
forum_remove_bad_characters();

// If AURA isn't defined, config.php is missing or corrupt
if (!defined('AURA'))
{
	header('Location: install/');
	exit;
}

// Record the start time (will be used to calculate the generation time for the page)
$aura_start = microtime(true);

// Force POSIX locale (to prevent functions such as strtolower() from messing up UTF-8 strings)
setlocale(LC_CTYPE, 'C');

// If the admin directory is not specified, use the default
if (!defined('AURA_ADMIN_DIR'))
	define('AURA_ADMIN_DIR', 'admin');

if (!defined('AURA_EXTENSIONS_DIR'))
	define('AURA_EXTENSIONS_DIR', AURA_ROOT.'extensions/');

if (!defined('AURA_PLUGINS_DIR'))
	define('AURA_PLUGINS_DIR', AURA_ROOT.'plugins/');

define('CURRENT_TIMESTAMP', time());

// We don't have any config settings at this point, so for now it's a watered down version of it
$handler = new errors;
set_error_handler(array($handler, 'handle'));
set_exception_handler(array($handler, 'handle'));

// Make sure PHP reports no errors apart from parse errors (this is handled by the error handler from this point on)
error_reporting(E_PARSE);

// Define a few commonly used constants
define('AURA_UNVERIFIED', 0);
define('AURA_ADMIN', 1);
define('AURA_MOD', 2);
define('AURA_GUEST', 4);
define('AURA_MEMBER', 6);

// Brute force stuff
define('ATTEMPT_DELAY', 1000);
define('TIMEOUT', 5000);

// Load database class and connect
require AURA_ROOT.'include/database.php';
$db = new db($config);

// Start a transaction
$db->start_transaction();

$cache = new cache($db);

$aura_config = $cache->get('config', array('o_default_user_group' => AURA_MEMBER));
$aura_extensions = $cache->get('extensions');

// Check whether we should be using https
check_ssl_state();

// Load URL rewriting functions
if (file_exists(AURA_ROOT.'include/url/'.$aura_config['o_url_type'].'.php'))
	require AURA_ROOT.'include/url/'.$aura_config['o_url_type'].'.php';
else
	require AURA_ROOT.'include/url/default.php';

// Enable output buffering
if (!defined('AURA_DISABLE_BUFFERING'))
{
	// Should we use gzip output compression?
	if ($aura_config['o_gzip'] && extension_loaded('zlib'))
		ob_start('ob_gzhandler');
	else
		ob_start();
}

// Define standard date/time formats
$aura_config['o_time_formats'] = explode(',', $aura_config['o_time_formats']);
$aura_config['o_date_formats'] = explode(',', $aura_config['o_date_formats']);

// Check/update/set cookie and fetch user info
$aura_user = array();
check_cookie($aura_user);

$aura_style = $cache->get('style', array($aura_config, $aura_user), true, true);

$loader = new Twig_Loader_Filesystem(AURA_ROOT.'include/templates');

$style_root = (($aura_config['o_style_path'] != 'styles') ? $aura_config['o_style_path'] : AURA_ROOT.$aura_config['o_style_path']).'/'.$aura_user['style'].'/templates/';
$loader->addPath(AURA_ROOT.'include/templates/', 'core');

if (file_exists($style_root)) // If the custom style doesn't use templates, then this is silly
	$loader->addPath($style_root, 'style');

$tpl_manager = new Twig_Environment($loader, 
	array(
		'cache' => $cache->cache_dir.'templates/'.$aura_user['style'],
		'debug' => ($aura_config['o_debug_mode'] == '1') ? true : false,
	)
);

$lang = new lang($cache);
$lang->set_language($aura_user['language']);

$lang->load('common');

// Now we have the arguments we need for the proper error handler
$handler = new errors($aura_config, $aura_user, $aura_url, $lang);

register_shutdown_function(array($handler, 'handle'));
set_error_handler(array($handler, 'handle'));
set_exception_handler(array($handler, 'handle'));

// Load the task manager
require AURA_ROOT.'include/tasks.php';
$tasks = new task_scheduler($db, $aura_config, $cache);

// Check if we are to display a maintenance message
if ($aura_config['o_maintenance'] && $aura_user['g_id'] != AURA_ADMIN && !defined('AURA_TURN_OFF_MAINT') && !defined('IN_CRON'))
	maintenance_message();

$aura_bans = $cache->get('bans');

// Check if current user is banned
check_bans();

// Update online list
if (($aura_config['o_url_type'] == 'default' || strstr($_SERVER['PHP_SELF'], 'index.php') || strstr($_SERVER['PHP_SELF'], '/index.php')) && !defined('IN_CRON'))
	$online = update_users_online();

// Check to see if we logged in without a cookie being set
if ($aura_user['is_guest'] && isset($_GET['login']))
	message($lang->t('No cookie'));

($hook = get_extensions('common_after_validation')) ? eval($hook) : null;

// The maximum size of a post, in bytes, since the field is now MEDIUMTEXT this allows ~16MB but lets cap at 1MB...
if (!defined('AURA_MAX_POSTSIZE'))
	define('AURA_MAX_POSTSIZE', 1048576);

if (!defined('AURA_SEARCH_MIN_WORD'))
	define('AURA_SEARCH_MIN_WORD', 3);
if (!defined('AURA_SEARCH_MAX_WORD'))
	define('AURA_SEARCH_MAX_WORD', 20);

if (!defined('FORUM_MAX_COOKIE_SIZE'))
	define('FORUM_MAX_COOKIE_SIZE', 4048);