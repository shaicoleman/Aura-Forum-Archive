<?php
/**
 * Copyright (C) 2017 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

// Make sure no one attempts to run this script "directly"
if (!defined('AURA'))
	exit;

define('AURA_ADMIN_CONSOLE', 1);

// Load the common-admin language pack
$lang->load('admin_common');

$restrictions = $cache->get('restrictions');
if (!isset($restrictions[$aura_user['id']]) || $aura_user['id'] == '2')
	$restrictions[$aura_user['id']] = array(
		'admin_options' => 1,
		'admin_permissions' => 1,
		'admin_categories' => 1,
		'admin_forums' => 1,
		'admin_groups' => 1,
		'admin_censoring' => 1,
		'admin_maintenance' => 1,
		'admin_plugins' => 1,
		'admin_restrictions' => 1,
		'admin_users' => 1,
		'admin_moderate' => 1,
		'admin_ranks' => 1,
		'admin_updates' => 1,
		'admin_archive' => 1,
		'admin_smilies' => 1,
		'admin_warnings' => 1,
		'admin_attachments' => 1,
		'admin_robots' => 1,
		'admin_extensions' => 1,
		'admin_tasks' => 1,
	);

//
// Display the admin navigation menu
//
function generate_admin_menu($page = '')
{
	global $aura_config, $aura_user, $lang, $restrictions, $aura_url;
	$admin_menu = array();

	if ($aura_user['is_admin'])
	{
		if ($restrictions[$aura_user['id']]['admin_options'] == '1')
			$admin_menu[] = array('page' => 'options', 'href' => aura_link($aura_url['admin_options']), 'title' => $lang->t('Options'));

		if ($restrictions[$aura_user['id']]['admin_archive'] == '1')
			$admin_menu[] = array('page' => 'archive', 'href' => aura_link($aura_url['admin_archive']), 'title' => $lang->t('Archive'));

		if ($restrictions[$aura_user['id']]['admin_permissions'] == '1')
			$admin_menu[] = array('page' => 'permissions', 'href' => aura_link($aura_url['admin_permissions']), 'title' => $lang->t('Permissions'));

		if ($restrictions[$aura_user['id']]['admin_categories'] == '1')
			$admin_menu[] = array('page' => 'categories', 'href' => aura_link($aura_url['admin_categories']), 'title' => $lang->t('Categories'));

		if ($restrictions[$aura_user['id']]['admin_forums'] == '1')
			$admin_menu[] = array('page' => 'forums', 'href' => aura_link($aura_url['admin_forums']), 'title' => $lang->t('Forums'));

		if ($restrictions[$aura_user['id']]['admin_groups'] == '1')
			$admin_menu[] = array('page' => 'groups', 'href' => aura_link($aura_url['admin_groups']), 'title' => $lang->t('User groups'));

		if ($restrictions[$aura_user['id']]['admin_censoring'] == '1')
			$admin_menu[] = array('page' => 'censoring', 'href' => aura_link($aura_url['admin_censoring']), 'title' => $lang->t('Censoring'));

		if ($restrictions[$aura_user['id']]['admin_ranks'] == '1') 
			$admin_menu[] = array('page' => 'ranks', 'href' => aura_link($aura_url['admin_ranks']), 'title' => $lang->t('Ranks')); 

		if ($restrictions[$aura_user['id']]['admin_robots'] == '1')
			$admin_menu[] = array('page' => 'robots', 'href' => aura_link($aura_url['admin_robots']), 'title' => $lang->t('Robots'));

		if ($restrictions[$aura_user['id']]['admin_smilies'] == '1' && $aura_config['o_smilies'] == '1')
			$admin_menu[] = array('page' => 'smilies', 'href' => aura_link($aura_url['admin_smilies']), 'title' => $lang->t('Smilies'));
	
		if ($restrictions[$aura_user['id']]['admin_warnings'] == '1' && $aura_config['o_warnings'] == '1')
			$admin_menu[] = array('page' => 'warnings', 'href' => aura_link($aura_url['admin_warnings']), 'title' => $lang->t('Warnings'));

		if ($restrictions[$aura_user['id']]['admin_moderate'] == '1')
			$admin_menu[] = array('page' => 'moderate', 'href' => aura_link($aura_url['admin_moderate']), 'title' => $lang->t('Moderate'));

		if ($restrictions[$aura_user['id']]['admin_attachments'] == '1' && $aura_config['o_attachments'] == '1')
			$admin_menu[] = array('page' => 'attachments', 'href' => aura_link($aura_url['admin_attachments']), 'title' => $lang->t('Attachments'));

		if ($restrictions[$aura_user['id']]['admin_restrictions'] == '1')
			$admin_menu[] = array('page' => 'restrictions', 'href' => aura_link($aura_url['admin_restrictions']), 'title' => $lang->t('Restrictions'));

		if ($restrictions[$aura_user['id']]['admin_tasks'] == '1')
			$admin_menu[] = array('page' => 'tasks', 'href' => aura_link($aura_url['admin_tasks']), 'title' => $lang->t('Tasks'));

		if ($restrictions[$aura_user['id']]['admin_extensions'] == '1')
			$admin_menu[] = array('page' => 'extensions', 'href' => aura_link($aura_url['admin_extensions']), 'title' => $lang->t('Extensions'));

		if ($restrictions[$aura_user['id']]['admin_maintenance'] == '1')
			$admin_menu[] = array('page' => 'maintenance', 'href' => aura_link($aura_url['admin_maintenance']), 'title' => $lang->t('Maintenance'));

		if ($restrictions[$aura_user['id']]['admin_updates'] == '1')
			$admin_menu[] = array('page' => 'updates', 'href' => aura_link($aura_url['admin_update']), 'title' => $lang->t('Updates'));
	}

	$plugin_menu = array();
	$plugins = forum_list_plugins($aura_user['is_admin']);
	if (!empty($plugins) && ($restrictions[$aura_user['id']]['admin_plugins'] == '1'))
	{
		foreach ($plugins as $plugin_name => $plugin)
			$plugin_menu[] = array('page' => $plugin_name, 'href' => aura_link($aura_url['admin_loader'], array($plugin_name)), 'title' => str_replace('_', ' ', $plugin));
	}

	$tpl = load_template('admin_sidebar.tpl');
	echo $tpl->render(
		array(
			'lang' => $lang,
			'aura_user' => $aura_user,
			'aura_config' => $aura_config,
			'page' => $page,
			'ban_link' => aura_link($aura_url['admin_bans']),
			'index_link' => aura_link($aura_url['admin_index']),
			'users_link' => aura_link($aura_url['admin_users']),
			'announce_link' => aura_link($aura_url['admin_announcements']),
			'posts_link' => aura_link($aura_url['admin_posts']),
			'reports_link' => aura_link($aura_url['admin_reports']),
			'deleted_link' => aura_link($aura_url['admin_deleted']),
			'admin_menu' => $admin_menu,
			'plugin_menu' => $plugin_menu,
		)
	);
}

//
// Delete topics from $forum_id that are "older than" $prune_date (if $prune_sticky is 1, sticky topics will also be deleted)
//
function prune($forum_id, $prune_sticky, $prune_date)
{
	global $db;
	
	$data = array(
		':id'	=>	$forum_id,
	);

	$where_cond = 'forum_id=:id';
	if ($prune_date != -1)
	{
		$where_cond .= ' And last_post<:last_post';
		$data[':last_post'] = $prune_date;
	}

	if (!$prune_sticky)
		$where_cond .= ' AND sticky=0';

	// Fetch topics to prune
	$ps = $db->select('topics', 'id', $data, $where_cond);

	$topic_ids = array();
	foreach ($ps as $cur_topic)
	{
		$topic_ids[] = $cur_topic['id'];
		$placeholders[] = '?';
	}

	if (!empty($topic_ids))
	{
		$post_ids = array(); // Fetch posts to prune
		$ps = $db->select('posts', 'id', $topic_ids, 'topic_id IN('.implode(',', $placeholders).')'); 
		foreach ($ps as $cur_post)
		{
			$markers[] = '?';
			$post_ids[] = $cur_post['id'];
		}

		if ($post_ids != '')
		{
			$db->delete('topics', 'id IN('.implode(',', $placeholders).')', $topic_ids);
			$db->delete('topic_subscriptions', 'topic_id IN('.implode(',', $placeholders).')', $topic_ids);
			$db->delete('posts', 'id IN('.implode(',', $markers).')', $post_ids);

			// We removed a bunch of posts, so now we have to update the search index
			if (!defined('AURA_CJK_HANGUL_REGEX'))
				require AURA_ROOT.'include/search_idx.php';

			strip_search_index($post_ids);
		}
	}
}

//
// Fetch a list of available admin plugins
//
function forum_list_plugins($is_admin)
{
	$plugins = array();
	$files = array_diff(scandir(AURA_PLUGINS_DIR), array('.', '..'));
	foreach ($files as $entry)
	{
		$prefix = substr($entry, 0, strpos($entry, '_'));
		$suffix = substr($entry, strlen($entry) - 4);

		if ($suffix == '.php' && ((!$is_admin && $prefix == 'AMP') || ($is_admin && ($prefix == 'AP' || $prefix == 'AMP'))))
			$plugins[substr($entry, 0, -4)] = substr($entry, strpos($entry, '_') + 1, -4);
	}

	natcasesort($plugins);
	return $plugins;
}

function forum_list_themes()
{ 
	global $aura_config;
	$style_root = ($aura_config['o_style_path'] != 'styles') ? $aura_config['o_style_path'] : AURA_ROOT.$aura_config['o_style_path'];
	if (!file_exists($style_root.'/'.$aura_config['o_default_style'].'/themes'))
		return;

	$themes = array();
	$files = array_diff(scandir($style_root.'/'.$aura_config['o_default_style'].'/themes'), array('.', '..'));
	foreach ($files as $theme)
	{
		if (substr($theme, -4) == '.css')
		$themes[] = substr($theme, 0, -4);
	}

	return $themes;
}

//
// Validate an Extension schema when installing it into the Amin panel
//
function validate_extension($extension, $errors)
{
	global $lang, $aura_config;

	if (!isset($extension['extension']))
		$errors[] = $lang->t('Extension tag missing', 'extension');

	if (empty($errors))
	{
		// First off start by validating the Engine
		$extension = $extension['extension'];
		if (!isset($extension['attributes']['engine']))
			$errors[] = $lang->t('Extension attribute missing', 'engine');
		else if ($extension['attributes']['engine'] < '1.1')
			$errors[] = $lang->t('Extension engine incompatible', $aura_config['o_cur_version']);
		else if ($extension['attributes']['engine'] != '1.1')
			$errors[] = $lang->t('Extension engine invalid');

		// Next, validate we have an appropriate title
		else if (!isset($extension['title']))
			$errors[] = $lang->t('Extension tag missing', 'title');
		else if (utf8_strlen($extension['title']) <= 5)
			$errors[] = $lang->t('Extension title too short');

		// Validate the extension version
		if (!isset($extension['version']))
			$errors[] = $lang->t('Extension tag missing', 'version');
		else if (!is_numeric($extension['version']))
			$errors[] = $lang->t('Extension version invalid');

		// Optional: 'plugin_folder' if we are installing files
		else if (isset($extension['plugin_folder']) && (utf8_strlen($extension['plugin_folder']) < 5 || preg_match('/[^a-z0-9\s-]/s', $extension['plugin_folder'])))
			$errors[] = $lang->t('Extension plugin folder name invalid');

		// Description for the extension
		else if (!isset($extension['description']))
			$errors[] = $lang->t('Extension tag missing', 'description');
		else if (utf8_strlen($extension['description']) <= 20)
			$errors[] = $lang->t('Extension description too short');

		// Validate the extension author
		else if (!isset($extension['author']))
			$errors[] = $lang->t('Extension tag missing', 'author');
		else if (utf8_strlen($extension['author']) <= 3)
			$errors[] = $lang->t('Extension author too short');

		// Check out all extension versions
		else if (!isset($extension['supported_versions']))
			$errors[] = $lang->t('Extension tag missing', 'supported_versions');
		else
		{
			$versions = explode(',', $extension['supported_versions']);
			if (empty($versions))
				$errors[] = $lang->t('Extension supported versions empty');
			else if (count(array_filter($versions)) != count($versions))
				$errors[] = $lang->t('Extension supported versions markup invalid');
		}

		// Validate the extension hooks
		if (empty($errors))
		{
			if (!isset($extension['hooks']))
				$errors[] = $lang->t('Extension tag missing', 'hooks');
			else if (!is_array($extension['hooks']))
				$errors[] = $lang->t('Extension hook missing');
			else
			{
				if (!isset($extension['hooks']['hook']))
					$errors[] = $lang->t('Extension tag missing', 'hook');
				else if (!is_array($extension['hooks']['hook']))
					$errors[] = $lang->t('Extension hook missing');
				else
				{
					foreach ($extension['hooks']['hook'] as $hook)
					{
						if (!isset($hook['attributes']['id']))
						{
							$errors[] = $lang->t('Extension attribute missing', 'id');
							break;
						}
						else if (utf8_strlen($hook['attributes']['id']) < 5)
						{
							$errors[] = $lang->t('Invalid hook attribute', $hook['attributes']['id']);
							break;
						}
						else if (!isset($hook['content']) || utf8_trim($hook['content']) == '')
						{
							$errors[] = $lang->t('Extension hook missing content', $hook['attributes']['id']);
							break;
						}
					}
				}
			}
		}

		// Optional: validate the install tag
		if (empty($errors) && isset($extension['install']))
		{
			if (empty($extension['install']))
				$errors[] = $lang->t('Invalid or unused extension tag', 'install');

			// If we're executing code when we install this extension
			else if (isset($extension['install']['execute']) && utf8_trim($extension['install']['execute']) == '')
				$errors[] = $lang->t('Invalid or empty extension tag', 'execute');

			// If we're installing additional templates when we install this extension
			if (isset($extension['install']['templates']))
			{
				if (!isset($extension['install']['templates']['template']))
					$errors[] = $lang->t('Extension tag missing', 'template');
				else if (!is_array($extension['install']['templates']['template']))
					$errors[] = $lang->t('Extension template missing');
				else
				{
					// Hacky solution to only having one template
					if (isset($extension['install']['templates']['template']['content']))
					{
						$extension['install']['templates']['template'][0] = $extension['install']['templates']['template'];
						unset($extension['install']['templates']['template']['content']);
						unset($extension['install']['templates']['template']['attributes']);
					}

					$templates = array();
					foreach ($extension['install']['templates']['template'] as $template)
					{
						if (!isset($template['attributes']['id']))
						{
							$errors[] = $lang->t('Extension attribute missing', 'id');
							break;
						}
						else if (utf8_strlen($template['attributes']['id']) < 5 || !preg_match('/([a-z]+).tpl/s', $template['attributes']['id']))
						{
							$errors[] = $lang->t('Invalid template attribute', $template['attributes']['id']);
							break;
						}
						else if (!isset($template['content']) || utf8_trim($template['content']) == '')
						{
							$errors[] = $lang->t('Extension template missing content', $template['attributes']['id']);
							break;
						}

						$templates[] = $template['attributes']['id'];
					}

					// Check for duplicate template files being installed in the extension
					if (count($templates) !== count(array_unique($templates)))
						$errors[] = $lang->t('Template names not unique');
				}
			}

			// Do we have an unused 'plugin folder' component?
			if (isset($extension['plugin_folder']) && !isset($extension['install']['templates']) && !isset($extension['install']['languages']) && !isset($extension['install']['files']))
				$errors[] = $lang->t('Invalid extension component', 'plugin_folder');
			else if (is_dir(AURA_ROOT.'include/extensions/'.$extension['plugin_folder'])) // Does it already exist?
				$errors[] = $lang->t('Plugin folder already used');

			// If we're installing additional plugin files with this extension
			if (empty($errors) && isset($extension['install']['plugins']))
			{
				if (!isset($extension['install']['plugins']['plugin']))
					$errors[] = $lang->t('Extension tag missing', 'plugin');
				else if (!is_array($extension['install']['plugins']['plugin']))
					$errors[] = $lang->t('Extension plugin missing');
				else
				{
					// Hacky solution to only having one template
					if (isset($extension['install']['plugins']['plugin']['content']))
					{
						$extension['install']['plugins']['plugin'][0] = $extension['install']['plugins']['plugin'];
						unset($extension['install']['plugins']['plugin']['content']);
						unset($extension['install']['plugins']['plugin']['attributes']);
					}

					$plugins = array();
					foreach ($extension['install']['plugins']['plugin'] as $plugin)
					{
						if (!isset($plugin['attributes']['id']))
						{
							$errors[] = $lang->t('Extension attribute missing', 'id');
							break;
						}
						else if (utf8_strlen($plugin['attributes']['id']) < 5 || !preg_match('/(AP_|AMP_)([A-Za-z0-9_]+).php/s', $plugin['attributes']['id']))
						{
							$errors[] = $lang->t('Invalid plugin attribute', $plugin['attributes']['id']);
							break;
						}
						else if (!isset($plugin['content']) || utf8_trim($plugin['content']) == '')
						{
							$errors[] = $lang->t('Extension plugin missing content', $plugin['attributes']['id']);
							break;
						}

						$plugins[] = $plugin['attributes']['id'];
					}

					// Check for duplicate plugin files in this extension
					if (count($plugins) !== count(array_unique($plugins)))
						$errors[] = $lang->t('Plugin names not unique');

					// Then look through to make sure we're not going to be overwriting anything that already exists
					foreach ($plugins as $plugin)
					{
						if (file_exists(AURA_PLUGINS_DIR.$plugin))
						{
							$errors[] = $lang->t('Plugin already exists', $plugin);
							break;
						}
					}
				}
			}

			// If we're installing additional languages along with this extension
			if (empty($errors) && isset($extension['install']['languages']))
			{
				if (!isset($extension['install']['languages']['language']))
					$errors[] = $lang->t('Extension tag missing', 'language');
				else if (!is_array($extension['install']['languages']['language']))
					$errors[] = $lang->t('Extension language missing');
				else
				{
					// Hacky solution to only having one language
					if (isset($extension['install']['languages']['language']['content']))
					{
						$extension['install']['languages']['language'][0] = $extension['install']['languages']['language'];
						unset($extension['install']['languages']['language']['content']);
						unset($extension['install']['languages']['language']['attributes']);
					}

					$languages = array();
					foreach ($extension['install']['languages']['language'] as $language)
					{
						if (!isset($language['attributes']['id']))
						{
							$errors[] = $lang->t('Extension attribute missing', 'id');
							break;
						}
						else if (utf8_strlen($language['attributes']['id']) < 5 || !preg_match('/([a-z_]+).po/s', $language['attributes']['id']))
						{
							$errors[] = $lang->t('Invalid language attribute', $language['attributes']['id']);
							break;
						}
						if (!isset($language['attributes']['iso']))
						{
							$errors[] = $lang->t('Extension attribute missing', 'iso');
							break;
						}
						else if (!preg_match('/([a-z]{2})_([A-Z]{2})/s', $language['attributes']['iso']))
						{
							$errors[] = $lang->t('Invalid language attribute', $language['attributes']['iso']);
							break;
						}
						else if (!isset($language['content']) || utf8_trim($language['content']) == '')
						{
							$errors[] = $lang->t('Extension language missing content', $language['attributes']['id']);
							break;
						}

						$languages[] = $language['attributes']['id'].'_'.$language['attributes']['iso'];
					}

					// Check for duplicate language files being installed in the extension
					if (count($languages) !== count(array_unique($languages)))
						$errors[] = $lang->t('Language files not unique');
				}
			}

			// If we're installing additional files with this extension
			if (empty($errors) && isset($extension['install']['files']))
			{
				if (!isset($extension['install']['files']['file']))
					$errors[] = $lang->t('Extension tag missing', 'file');
				else if (!is_array($extension['install']['files']['file']))
					$errors[] = $lang->t('Extension file missing');
				else
				{
					// Hacky solution to only having one template
					if (isset($extension['install']['files']['file']['content']))
					{
						$extension['install']['files']['file'][0] = $extension['install']['files']['file'];
						unset($extension['install']['files']['file']['content']);
						unset($extension['install']['files']['file']['attributes']);
					}

					$files = array();
					foreach ($extension['install']['files']['file'] as $file)
					{
						if (!isset($file['attributes']['name']))
						{
							$errors[] = $lang->t('Extension attribute missing', 'name');
							break;
						}
						else if (utf8_strlen($file['attributes']['name']) < 5 || !preg_match('/([a-z]+).php/s', $file['attributes']['name']))
						{
							$errors[] = $lang->t('Invalid file attribute', $file['attributes']['name']);
							break;
						}
						else if (!isset($file['content']) || utf8_trim($file['content']) == '')
						{
							$errors[] = $lang->t('Extension file missing content', $file['attributes']['name']);
							break;
						}

						$files[] = $file['attributes']['name'];
					}

					// Check for duplicate files in this extension
					if (count($files) !== count(array_unique($files)))
						$errors[] = $lang->t('File names not unique');
				}
			}

			// If we're installing additional tasks along with this extension
			if (empty($errors) && isset($extension['install']['tasks']))
			{
				
			}

			// If we're installing additional styles along with this extension
			if (empty($errors) && isset($extension['install']['styles']))
			{
				
			}
		}

		// Optional: validate the uninstall tag
		if (empty($errors) && isset($extension['uninstall']))
		{
			if (empty($extension['uninstall']))
				$errors[] = $lang->t('Invalid or unused extension tag', 'uninstall');

			// If we're executing code during this uninstall
			else if (isset($extension['uninstall']['execute']) && utf8_trim($extension['uninstall']['execute']) == '')
				$errors[] = $lang->t('Invalid or empty extension tag', 'execute');
			// Validate the uninstall note
			else if (isset($extension['uninstall']['note']) && utf8_strlen($extension['uninstall']['note']) <= 5)
				$errors[] = $lang->t('Uninstall note too short');
		}
	}

	return array($extension, $errors);
}