#!/usr/bin/php -q
<?php
/**
 * Copyright (C) 2017 Aura (https://www.get-aura.org)
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
if (substr(PHP_SAPI, 0, 3) != 'cli')
{
	// Output transparent gif
	header('Expires: Thu, 21 Jul 1977 07:30:00 GMT');
	header('Cache-Control: post-check=0, pre-check=0', false);
	header('X-Frame-Options: deny');
	header('Cache-Control: no-cache');
	header('Content-type: image/gif');
	header('Content-length: 43');

	echo base64_decode('R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==');

	flush();
	exit;
}

define('IN_CRON', true);
define('AURA_DISABLE_BUFFERING', true);
define('AURA_QUIET_VISIT', true);
define('AURA_ROOT', __DIR__.'/../');
require AURA_ROOT.'include/common.php';

($hook = get_extensions('task_after_run')) ? eval($hook) : null;

$db->end_transaction();
exit;