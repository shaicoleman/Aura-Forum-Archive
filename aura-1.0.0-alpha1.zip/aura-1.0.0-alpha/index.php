<?php
/**
 * Copyright (C) 2017 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

if (!defined('AURA'))
{
	define('AURA_ROOT', __DIR__.'/');
	require AURA_ROOT.'include/common.php';
}

if ($aura_user['g_read_board'] == '0')
	message($lang->t('No view'), false, '403 Forbidden');

// Load the index language file
$lang->load('index');

// Get list of forums and topics with new posts since last visit
if (!$aura_user['is_guest'])
{
	$join = array(
		array(
			'type' => 'LEFT',
			'table' => 'forum_perms',
			'as' => 'fp',
			'on' => '(fp.forum_id=f.id AND fp.group_id=:id)',
		),
	);

	$data = array(
		':id' => $aura_user['g_id'],
		':last_visit' => $aura_user['last_visit'],
	);

	$ps = $db->join('forums', 'f', $join, 'f.id, f.last_post', $data, '(fp.read_forum IS NULL OR fp.read_forum=1) AND f.last_post>:last_visit');
	if ($ps->rowCount())
	{
		$forums = $new_topics = array();
		$tracked_topics = get_tracked_topics();
		foreach ($ps as $cur_forum)
		{
			if (!isset($tracked_topics['forums'][$cur_forum['id']]) || $tracked_topics['forums'][$cur_forum['id']] < $cur_forum['last_post'])
				$forums[$cur_forum['id']] = $cur_forum['last_post'];
		}

		if (!empty($forums))
		{
			if (empty($tracked_topics['topics']))
				$new_topics = $forums;
			else
			{
				for ($i = 0; $i < count($forums); $i++)
					$placeholders[] = '?';

				$data = array_keys($forums);
				$data[] = $aura_user['last_visit'];

				$ps = $db->select('topics', 'forum_id, id, last_post', $data, 'forum_id IN('.implode(',', $placeholders).') AND last_post>? AND moved_to IS NULL');
				foreach ($ps as $cur_topic)
				{
					if (!isset($new_topics[$cur_topic['forum_id']]) && (!isset($tracked_topics['forums'][$cur_topic['forum_id']]) || $tracked_topics['forums'][$cur_topic['forum_id']] < $forums[$cur_topic['forum_id']]) && (!isset($tracked_topics['topics'][$cur_topic['id']]) || $tracked_topics['topics'][$cur_topic['id']] < $cur_topic['last_post']))
						$new_topics[$cur_topic['forum_id']] = $forums[$cur_topic['forum_id']];
				}
			}
		}
	}
}

$page_head['canonical'] = array('href' => aura_link($aura_url['index']), 'rel' => 'canonical');

if ($aura_config['o_feed_type'] == '1')
    $page_head['feed'] = array('href' => aura_link($aura_url['index_rss']), 'rel' => 'alternate', 'type' => 'application/rss+xml', 'title' => $lang->t('RSS active topics feed'));
else if ($aura_config['o_feed_type'] == '2') 
    $page_head['feed'] = array('href' => aura_link($aura_url['index_atom']), 'rel' => 'alternate', 'type' => 'application/atom+xml', 'title' => $lang->t('Atom active topics feed'));

$join = array(
	array(
		'type' => 'LEFT',
		'table' => 'forum_perms',
		'as' => 'fp',
		'on' => '(fp.forum_id=f.id AND fp.group_id=:id)',
	),
	array(
		'type' => 'LEFT',
		'table' => 'users',
		'as' => 'u',
		'on' => '(f.last_poster=u.username)',
	),
);

$data = array(
	':id' => $aura_user['g_id'],
);

$sub_forums = array();
$ps = $db->join('forums', 'f', $join, 'u.id AS uid, u.email, u.use_gravatar, u.group_id, f.num_topics, f.num_posts, f.last_topic, f.last_topic_id, f.parent_forum, f.last_post_id, f.show_post_info, f.last_poster, f.last_post, f.id, f.forum_name, f.last_topic', $data, '(fp.read_forum IS NULL OR fp.read_forum=1) AND f.parent_forum <> 0', 'f.disp_position');
foreach ($ps as $current)
{
	if (!isset($sub_forums[$current['parent_forum']]))
		$sub_forums[$current['parent_forum']] = array();

	$sub_forums[$current['parent_forum']][] = $current;
}

($hook = get_extensions('index_before_header')) ? eval($hook) : null;

$page_title = array($aura_config['o_board_title']);
define('AURA_ALLOW_INDEX', 1);
define('AURA_ACTIVE_PAGE', 'index');
require AURA_ROOT.'header.php';

$join = array(
	array(
		'type' => 'INNER',
		'table' => 'forums',
		'as' => 'f',
		'on' => 'c.id=f.cat_id',
	),
	array(
		'type' => 'LEFT',
		'table' => 'forum_perms',
		'as' => 'fp',
		'on' => '(fp.forum_id=f.id AND fp.group_id=:id)',
	),
	array(
		'type' => 'LEFT',
		'table' => 'users',
		'as' => 'u',
		'on' => '(f.last_poster=u.username)',
	),
);

// Retrieve the categories and forums
$categories = $forums = array();
$moderators = $cache->get('moderators');
$ps = $db->join('categories', 'c', $join, 'c.id AS cid, c.cat_name, f.id AS fid, f.forum_name, f.forum_desc, f.last_topic, f.last_topic_id, f.show_post_info, f.redirect_url, f.num_topics, f.num_posts, f.last_post, f.last_post_id, f.last_poster, f.parent_forum, f.last_topic, u.group_id, u.id AS uid, u.email, u.use_gravatar', $data, '(fp.read_forum IS NULL OR fp.read_forum=1) AND (f.parent_forum IS NULL OR f.parent_forum=0) ORDER BY c.disp_position, c.id, f.disp_position');
foreach ($ps as $cur_forum)
{
	if (!in_array($cur_forum['cid'], $categories))
		$categories[$cur_forum['cid']] = array(
			'cid' => $cur_forum['cid'],
			'name' => $cur_forum['cat_name'],
		);

	$num_topics = $cur_forum['num_topics'];
	$num_posts = $cur_forum['num_posts'];

	$cur_forum['search_link'] = aura_link($aura_url['search_new_results'], array($cur_forum['fid']));

	$cur_forum['moderators'] = array();
	if (isset($moderators[$cur_forum['fid']]))
	{
		foreach ($moderators[$cur_forum['fid']] as $moderator)
		{
			if ($moderator['user_id']) // It's a user
			{
				$data = array(
					':id' => $moderator['user_id'],
				);

				// There has to be a better way of doing this ....
				$ps1 = $db->select('users', 'group_id', $data, 'id=:id');
				$group_id = $ps1->fetchColumn();

				$cur_forum['moderators'][] = colourise_group($moderator['username'], $group_id, $moderator['user_id']);
			}
			else // It's an entire user group
				$cur_forum['moderators'][] = colourise_group($moderator['group_title'], $moderator['group_id']);
		}
	}

	$subforum_list = array();
	if (isset($sub_forums[$cur_forum['fid']]))
	{
		// There can be more than one sub forum per forum
		foreach ($sub_forums[$cur_forum['fid']] as $cur_subforum)
		{
			$num_topics += $cur_subforum['num_topics'];
			$num_posts += $cur_subforum['num_posts'];

			if ($cur_forum['last_post'] < $cur_subforum['last_post'])
			{
				$cur_forum['last_post_id'] = $cur_subforum['last_post_id'];
				$cur_forum['last_poster'] = $cur_subforum['last_poster'];
				$cur_forum['last_post'] = $cur_subforum['last_post'];
				$cur_forum['email'] = $cur_subforum['email'];
				$cur_forum['uid'] = $cur_subforum['uid'];
				$cur_forum['use_gravatar'] = $cur_subforum['use_gravatar'];
				$cur_forum['group_id'] = $cur_subforum['group_id'];
				$cur_forum['last_topic'] = $cur_subforum['last_topic'];
				$cur_forum['last_topic_id'] = $cur_subforum['last_topic_id'];

				// If there are no new topics in the actual forum but there are in the sub forum
				if (!isset($new_topics[$cur_forum['fid']]) && isset($new_topics[$cur_subforum['id']]))
				{
					$new_topics[$cur_forum['fid']] = $cur_subforum['last_post'];
					$cur_forum['search_link'] = aura_link($aura_url['search_new_results'], array($cur_subforum['id']));
				}
			}

			$subforum_list[] = array('fid' => $cur_subforum['id'], 'name' => $cur_subforum['forum_name'], 'link' => aura_link($aura_url['forum'], array($cur_subforum['id'], url_friendly($cur_subforum['forum_name']))));
		}
	}

	if ($cur_forum['redirect_url'] != '')
		$num_topics = $num_posts = '-';
	else
	{
		$num_topics = forum_number_format($num_topics);
		$num_posts = forum_number_format($num_posts);
	}

	$forums[$cur_forum['fid']] = array(
		'cid' => $cur_forum['cid'],
		'fid' => $cur_forum['fid'],
		'moderators' => $cur_forum['moderators'],
		'last_post' => ($cur_forum['last_post']) ? format_time($cur_forum['last_post']) : '',
		'num_topics' => $num_topics,
		'num_posts' => $num_posts,
		'link' => aura_link($aura_url['forum'], array($cur_forum['fid'], url_friendly($cur_forum['forum_name']))),
		'forum_name' => $cur_forum['forum_name'],
		'forum_desc' => $cur_forum['forum_desc'],
		'search_forum' => $cur_forum['search_link'],
		'redirect_url' => $cur_forum['redirect_url'],
		'show_post_info' => $cur_forum['show_post_info'],
		'subforum_list' => $subforum_list,
	);
		
	if ($cur_forum['last_post'])
	{
		$forums[$cur_forum['fid']]['last_post_avatar'] = generate_avatar_markup($cur_forum['uid'], $cur_forum['email'], $cur_forum['use_gravatar'], array(32, 32));
		$forums[$cur_forum['fid']]['last_post_link'] = aura_link($aura_url['post'], array($cur_forum['last_post_id']));
		$forums[$cur_forum['fid']]['last_topic_link'] = aura_link($aura_url['topic'], array($cur_forum['last_topic_id'], url_friendly($cur_forum['last_topic'])));
		$forums[$cur_forum['fid']]['last_topic'] = ((aura_strlen($cur_forum['last_topic']) > 30) ? utf8_substr($cur_forum['last_topic'], 0, 30).' …' : $cur_forum['last_topic']);
		$forums[$cur_forum['fid']]['last_poster'] = (isset($cur_forum['group_id'])) ? colourise_group($cur_forum['last_poster'], $cur_forum['group_id'], $cur_forum['uid']) : colourise_group($cur_forum['last_poster'], AURA_GUEST);
	}
}

// Collect some statistics from the database
$stats = $cache->get('stats');

$ps = $db->select('forums', 'SUM(num_topics), SUM(num_posts)');
list($stats['total_topics'], $stats['total_posts']) = array_map('forum_number_format', $ps->fetch(PDO::FETCH_NUM));

$stats['newest_user'] = colourise_group($stats['last_user']['username'], $stats['last_user']['group_id'], $stats['last_user']['id']);

$users = $bots_online = array();
$num_guests = $num_bots = $num_users = 0;
if ($aura_config['o_users_online'] == '1')
{
	// Fetch users online info and generate strings for output
	$num_guests = count($online['guests']);
	$num_users = count($online['users']);
	$num_bots = 0;
	$users = $bots = $bots_online = array();

	foreach ($online['users'] as $online_id => $details)
		$users[] = colourise_group($details['username'], $details['group_id'], $details['id'], $online_id);

	foreach ($online['guests'] as $details)
	{
		if (strpos($details['ident'], '[Bot]') !== false)
		{
			++$num_bots;
			$name = explode('[Bot]', $details['ident']);
			if (empty($bots[$name[1]]))
				$bots[$name[1]] = 1;
			else
				++$bots[$name[1]];
		}
	}

	foreach ($bots as $online_name => $online_id)
		   $bots_online[] = $online_name.' [Bot]'.($online_id > 1 ? ' ('.$online_id.')' : '');

	$num_guests = $num_guests - $num_bots;
}

$legend = array();
$groups = $cache->get('groups');
foreach ($groups as $g_id => $details)
{
	if (!in_array($g_id, array(AURA_GUEST, AURA_MEMBER)) && $details['g_colour'] !== '')
		$legend[] = array('link' => aura_link($aura_url['userlist_group'], array($g_id)), 'title' => colourise_group($details['g_title'], $g_id));
}

$tpl = load_template('index.tpl');
echo $tpl->render(
	array(
		'categories' => $categories,
		'forums' => $forums,
		'lang' => $lang,
		'new_posts' => !empty($new_topics) ? $new_topics : array(),
		'aura_user' => $aura_user,
		'aura_config' => $aura_config,
		'mark_read' => aura_link($aura_url['mark_read'], array(generate_csrf_token('index.php'))),
		'num_users' => forum_number_format($num_users),
		'num_guests' => forum_number_format($num_guests),
		'num_bots' => forum_number_format($num_bots),
		'users' => $users,
		'bots' => $bots_online,
		'groups' => $legend,
		'stats' => $stats,
	)
);

($hook = get_extensions('index_after_display')) ? eval($hook) : null;

$footer_style = 'index';
require AURA_ROOT.'footer.php';