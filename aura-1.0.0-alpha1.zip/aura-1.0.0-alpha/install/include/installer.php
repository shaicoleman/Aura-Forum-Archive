<?php
class installer
{
	// Things used in multiple locations should be static ...
	public static $section;
	public static $progress = 0; // Starting progress for installer
	public static $base_url;
	public static $next_step;
	public static $previous_step;
	public static $language;
	public static $data;
	public $db;

	protected $path = 'include/modules/';
	protected $steps = array(
		'welcome',
		'requirements',
		'license',
		'database',
		'user',
		'settings',
		'advanced',
		'install',
	);

	final public function __construct($tpl, $cache, $language, $lang)
	{
		self::$section = isset($_GET['act']) ? $_GET['act'] : current($this->steps);
		self::$base_url = guess_base_url();
		self::$language = $language;
		$this->lang = $lang;

		$current_step = array_search(self::$section, $this->steps);

		// This should never happen if it's using valid steps
		if ($current_step === false)
			throw new Exception ('Invalid installation step \''.self::$section.'\'');

		if (isset($this->steps[--$current_step]))
			self::$previous_step = $this->steps[$current_step++]; // Grab this key then reset the pointer back to the current one
		else
			self::$previous_step = $this->steps[++$current_step]; // If there is no previous step

		if (isset($this->steps[++$current_step]))
			self::$next_step = $this->steps[$current_step];

		// If we're on the first step
		if (self::$section == current($this->steps))
		{
			$data = array(
				'progress' => self::$progress,
				'csrf_token' => aura_hash(random_key(64, false, true)),
				'language' => self::$language,
				'previous' => self::$section, // Here we put the current step to verify on the next page
				'config' => array(
					'type' => key(config::$drivers), // Get the first database driver
					'host' => '',
					'engine' => key(config::$engines),
					'prefix' => config::DEFAULT_TABLE_PREFIX,
					'username' => '',
					'password' => '',
					'db_name' => '',
					'p_connect' => config::PERSISTENT_CONNECTIONS,
				),
			);

			$_SESSION['install'] = serialize($data);
			self::$data = $data;
		}
		else
		{
			if (!isset($_SESSION['install']))
			{
				header('Location: '.guess_base_url().'install/');
				exit;
			}

			$data = unserialize($_SESSION['install']);
			self::$progress = $data['progress'];

			self::$data = $data;

			// Verify we came from the correct step ...
			if ($data['previous'] !== self::$previous_step && !isset($_POST['form_sent']) && !defined('AURA_AJAX_REQUEST') && self::$section !== end($this->steps))
			{
				header('Location: '.guess_base_url().'install/');
				exit;
			}

			// Check if we've passed the database stage, if so, load the database
			if (!empty(self::$data['config']['host']))
			{
				require_once AURA_ROOT.'include/database.php';
				$this->db = new db(self::$data['config']);
			}
		}

		$this->module = $this->path.self::$section.'.php';

		$this->template = $tpl;
		$this->cache = $cache;
	}

	public function run()
	{
		if (!file_exists($this->module) || !is_readable($this->module))
			throw new Exception('Unable to load command module \''.self::$section.'\'');

		require $this->module;

		$class = 'module_'.self::$section;
		$module = new $class($this->template, $this->cache, self::$language, $this->lang);
		$module->run();
	}

	protected static function add_progress($progress)
	{
		self::$data['progress'] += $progress;
	}

	final public function __destruct()
	{
		self::$data['previous'] = self::$section;
		$_SESSION['install'] = serialize(self::$data);
	}
}