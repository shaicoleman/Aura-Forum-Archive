<?php
if (!defined('INSTALL_ROOT'))
	exit;

function guess_base_url()
{
	static $base_url;

	if (!isset($base_url))
	{
		$base_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') ? 'https://' : 'http://'; // protocol
		$base_url .= preg_replace('%:(80|443)$%', '', $_SERVER['HTTP_HOST']); // host[:port]
		$base_url .= str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])); // path

		if (substr($base_url, -1) == '/')
			$base_url = substr($base_url, 0, -1);

		// Remove 'install'
		$base_url = substr($base_url, 0, -7);
	}

	return $base_url;
}

function generate_config_file($config)
{
	return '<?php'."\n\n\$config = ".var_export($config, true).";\n\ndefine('AURA', 1);\n";
}