<?php
class template
{
	public $data = array();
	public $header = array();
	public function __construct($cache, $lang)
	{
		$this->lang = $lang;
		$this->cache = $cache;

		require AURA_ROOT.'include/lib/Twig/Autoloader.php';

		// Register Twig autoloader
		Twig_Autoloader::register();

		$loader = new Twig_Loader_Filesystem(INSTALL_ROOT.'include/templates');
		$loader->addPath(INSTALL_ROOT.'include/templates/', 'install');

		$this->tpl = new Twig_Environment($loader, 
			array(
				'cache' => $cache->cache_dir.'templates/install/',
				'debug' => false,
			)
		);
	}

	public function render($tpl_file)
	{
		$this->send_header();

		$tpl = $this->tpl->loadTemplate('@install/'.$tpl_file.'.tpl');
		echo $tpl->render(
			array_merge(
				$this->data, array(
					'lang' => $this->lang,
					'language' => installer::$language,
					'base_url' => installer::$base_url.'install/',
					'next_step' => installer::$next_step,
					'csrf_token' => installer::$data['csrf_token'],
				)
			)
		); 

		$this->send_footer();
	}

	protected function send_header()
	{
		$tpl = $this->tpl->loadTemplate('@install/header.tpl');
		echo $tpl->render(
			array_merge(
				$this->header, array(
					'lang' => $this->lang,
					'language' => installer::$language,
					'title' => installer::$section,
					'base_url' => installer::$base_url,
				)
			)
		); 
	}

	protected function send_footer()
	{
		$tpl = $this->tpl->loadTemplate('@install/footer.tpl');
		echo $tpl->render(
			array(
				'lang' => $this->lang,
				'progress' => installer::$progress,
				'page' => installer::$section,
				'default_lang' => installer::$data['language'],
				'languages' => $this->cache->get('locales'),
				'SESSION' => $_SESSION,
			)
		); 
	}
}