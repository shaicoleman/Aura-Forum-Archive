<?php
class config
{
	// The Panther version this setup wizard installs
	const AURA_VERSION = '1.0.0';

	// Minimum requirements
	const MIN_PHP_VERSION = '5.3.0';
	const MIN_MEMORY_LIMIT = '128M';

	// Some default settings for the board
	const DEFAULT_LANG = 'en_GB';
	const DEFAULT_STYLE = 'aura';

	// Some settings relevant for searching
	const AURA_SEARCH_MIN_WORD = 3;
	const AURA_SEARCH_MAX_WORD = 20;

	// Full list of database drivers supported by this version
	public static $drivers = array(
		'mysql' => 'MySQL',
	);

	// Minimum versions of each database driver supported
	public static $versions = array(
		'mysql' => '5.0.15',
	);

	// List of MySQL database engines supported by this version
	public static $engines = array(
		'innodb' => 'InnoDB',
		'myisam' => 'MyISAM',
	);

	// Whether to use persistent connections by default
	const PERSISTENT_CONNECTIONS = false;

	// The default table prefix to install with
	const DEFAULT_TABLE_PREFIX = 'aura_';

	// The default cookie name
	const DEFAULT_COOKIE_NAME = 'aura_cookie_';

	// The minimum user-generated password length allowed
	const MIN_PASSWORD_LENGTH = 8;

	// The length of randomly generated passwords
	const PASSWORD_GENERATION_LENGTH = 12;

	// The minimum number of digits a password must contain
	const PASSWORD_MIN_DIGITS = 2;

	// The minimum number of uppercase characters a password must contain
	const PASSWORD_MIN_UPPERCASE = 2;

	// The minimum number of symbols which a password must contain
	const PASSWORD_MIN_SYMBOLS = 0;

	// The number of days after passwords expire
	const PASSWORD_EXPIRATION_DATE = 0;

	// Support links (after install)
	const AURA_SUPPORT_CENTRE = 'https://www.get-aura.org/development/tracker';
	const AURA_DOCUMENTATION = 'https://www.get-aura.org/development/docs';
	const AURA_RESOURCES = 'https://www.get-aura.org/resources';
	const AURA_FORUMS = 'https://www.get-aura.org/community/';
}