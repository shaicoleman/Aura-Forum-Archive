<?php
if (!defined('INSTALL_ROOT'))
	exit;

session_start();
session_regenerate_id();
define('AURA_ROOT', __DIR__.'/../../');

require INSTALL_ROOT.'include/config.php';
require INSTALL_ROOT.'include/functions.php';
require INSTALL_ROOT.'include/installer.php';

// Send the Content-type header in case the web server is setup to send something else
header('Content-type: text/html; charset=utf-8');

// Load the functions script
require AURA_ROOT.'include/functions.php';

// Register the autoloader for non-existing classes
spl_autoload_register('autoloader');

// Load UTF-8 functions
require AURA_ROOT.'include/lib/utf8/utf8.php';

// Strip out "bad" UTF-8 characters
forum_remove_bad_characters();

// Force POSIX locale (to prevent functions such as strtolower() from messing up UTF-8 strings)
setlocale(LC_CTYPE, 'C');

if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest')
	define('AURA_AJAX_REQUEST', 1);

if (function_exists('date_default_timezone_set') && function_exists('date_default_timezone_get'))
	date_default_timezone_set(@date_default_timezone_get());

// Has Panther already been installed?
if (file_exists(AURA_ROOT.'include/config.php'))
	include AURA_ROOT.'include/config.php';

// If the installation is not corrupt, then abort
if (defined('AURA'))
{
	header('Location: '.guess_base_url());
	exit;
}

// ... Otherwise define it here as we need it for various other things ...
define('AURA', 1);
define('CURRENT_TIMESTAMP', time());

// Setup the error handler
define('AURA_ADMIN_DIR', 'admin');

$handler = new errors;

set_error_handler(array($handler, 'handle'));
set_exception_handler(array($handler, 'handle'));
register_shutdown_function(array($handler, 'handle'));

// We want no errors reported, they're handled by the error handler
error_reporting(E_PARSE);

// Load the cache
$cache = new cache(null);
$lang = new lang($cache);

if (isset($_POST['change_language']))
{
	$install_lang = isset($_POST['language']) && preg_match('/^[a-z]{2}_[A-Z]{2}$/', $_POST['language']) ? aura_trim($_POST['language']) : config::DEFAULT_LANG;
	$_SESSION['language'] = $install_lang;
}
else
	$install_lang = (isset($_SESSION['language'])) ? $_SESSION['language'] : config::DEFAULT_LANG;

$lang->set_language($install_lang);
$lang->load('install');

require INSTALL_ROOT.'include/template.php';

$tpl = new template($cache, $lang);
$setup = new installer($tpl, $cache, $install_lang, $lang);

// Yuck, global variable support =(
$db = $setup->db;

$aura_config = array(
	'o_style_path' => 'styles',
	'o_show_queries' => '0',
);