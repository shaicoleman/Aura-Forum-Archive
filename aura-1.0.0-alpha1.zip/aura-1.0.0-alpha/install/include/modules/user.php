<?php
if (!defined('INSTALL_ROOT'))
	exit;

class module_user extends installer
{
	function run()
	{
		$user = array();
		$errors = array();
		if (isset($_POST['form_sent']))
		{
			$csrf_token = isset($_POST['csrf_token']) ? aura_trim($_POST['csrf_token']) : '';
			if (!aura_hash_equals(self::$data['csrf_token'], $csrf_token))
				throw new Exception($this->lang('Invalid csrf token'));

			$user = array(
				'username' => isset($_POST['username']) ? aura_trim($_POST['username']) : '',
				'email' => isset($_POST['email']) ? strtolower(aura_trim($_POST['email'])) : '',
				'password1' => isset($_POST['password1']) ? aura_trim($_POST['password1']) : '',
				'password2' => isset($_POST['password2']) ? aura_trim($_POST['password2']) : '',
			);

			if (aura_strlen($user['username']) < 2)
				$errors[] = $this->lang->t('Username 1');
			else if (aura_strlen($user['username']) > 25) // This usually doesn't happen since the form element only accepts 25 characters
				$errors[] = $this->lang->t('Username 2');
			else if (!strcasecmp($user['username'], 'Guest'))
				$errors[] = $this->lang->t('Username 3');
			else if (preg_match('%[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}%', $user['username']) || preg_match('%((([0-9A-Fa-f]{1,4}:){7}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){6}:[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){5}:([0-9A-Fa-f]{1,4}:)?[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){4}:([0-9A-Fa-f]{1,4}:){0,2}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){3}:([0-9A-Fa-f]{1,4}:){0,3}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){2}:([0-9A-Fa-f]{1,4}:){0,4}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){6}((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|(([0-9A-Fa-f]{1,4}:){0,5}:((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|(::([0-9A-Fa-f]{1,4}:){0,5}((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|([0-9A-Fa-f]{1,4}::([0-9A-Fa-f]{1,4}:){0,5}[0-9A-Fa-f]{1,4})|(::([0-9A-Fa-f]{1,4}:){0,6}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){1,7}:))%', $user['username']))
				$errors[] = $this->lang->t('Username 4');
			else if ((strpos($user['username'], '[') !== false || strpos($user['username'], ']') !== false) && strpos($user['username'], '\'') !== false && strpos($user['username'], '"') !== false)
				$errors[] = $this->lang->t('Username 5');
			else if (preg_match('%(?:\[/?(?:b|u|i|h|colou?r|quote|code|img|url|email|list)\]|\[(?:code|quote|list)=)%i', $user['username']))
				$errors[] = $this->lang->t('Username 6');

			if (aura_strlen($user['password1']) < 6)
				$errors[] = $this->lang->t('Short password');
			else if ($user['password1'] != $user['password2'])
				$errors[] = $this->lang->t('Passwords not match');

			if (!email::is_valid_email($user['email']))
				$errors[] = $this->lang->t('Invalid email');

			if (empty($errors))
			{
				$password_salt = random_pass(16);
				$user = array(
					'username' => $user['username'],
					'email' => $user['email'],
					'password' => aura_hash($user['password1'].$password_salt),
					'password_salt' => $password_salt,
				);

				installer::add_progress(5);
				self::$data = array_merge($user, self::$data);

				header('Location: '.self::$base_url.'install/?act=settings');
				exit;
			}
		}

		$this->template->data = array(
			'errors' => $errors,
			'user' => $user,
		);

		$this->template->render('user');
	}
}