<?php
/**
 * Copyright (C) 2017 Aura (https://www.get-aura.org)
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

if (!defined('AURA'))
{
	define('AURA_ROOT', __DIR__.'/../');
	require AURA_ROOT.'include/common.php';
}

require AURA_ROOT.'include/common_admin.php';

if (!$aura_user['is_admin'])
	message($lang->t('No permission'), false, '403 Forbidden');

if ($aura_user['id'] != '2')
{
	if (!is_null($restrictions[$aura_user['id']]['admin_updates']))
	{
		if ($restrictions[$aura_user['id']]['admin_updates'] == '0')
			message($lang->t('No permission'), false, '403 Forbidden');
	}
}

check_authentication();

// Load the admin-update language file
$lang->load('admin_update');

$errors = array();
if (isset($_POST['form_sent']))
{
	confirm_referrer(AURA_ADMIN_DIR.'/updates.php');

	$upgrade = new manual_upgrade($aura_config, $lang, $cache, $db);
	$result = $upgrade->run();
	if ($result['state']) // If it succeeded
		redirect(aura_link($aura_url['about_aura']), $lang->t('Forum updated'));
	else
		$errors[] = $result['lang'];
}

$page_title = array($aura_config['o_board_title'], $lang->t('Admin'), $lang->t('Update forum'));
define('AURA_ACTIVE_PAGE', 'admin');
require AURA_ROOT.'header.php';

generate_admin_menu('updates');

$tpl = load_template('admin_updates.tpl');
echo $tpl->render(
	array(
		'lang' => $lang,
		'errors' => $errors,
		'form_action' => aura_link($aura_url['admin_update']),
		'csrf_token' => generate_csrf_token(AURA_ADMIN_DIR.'/updates.php'),
	)
);

require AURA_ROOT.'footer.php';