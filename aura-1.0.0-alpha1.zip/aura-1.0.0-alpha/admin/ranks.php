<?php
/**
 * Copyright (C) 2017 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

if (!defined('AURA'))
{
	define('AURA_ROOT', __DIR__.'/../');
	require AURA_ROOT.'include/common.php';
}
require AURA_ROOT.'include/common_admin.php';

if (!$aura_user['is_admin'])
	message($lang->t('No permission'), false, '403 Forbidden');

if ($aura_user['id'] != '2')
{
	if (!is_null($restrictions[$aura_user['id']]['admin_ranks']))
	{
		if ($restrictions[$aura_user['id']]['admin_ranks'] == '0')
			message($lang->t('No permission'), false, '403 Forbidden');
	}
}

check_authentication();

// Load the admin-ranks language file
$lang->load('admin_ranks');

// Add a rank
if (isset($_POST['add_rank']))
{
	confirm_referrer(AURA_ADMIN_DIR.'/ranks.php');

	$rank = isset($_POST['new_rank']) ? aura_trim($_POST['new_rank']) : '';
	$min_posts = isset($_POST['new_min_posts']) ? aura_trim($_POST['new_min_posts']) : '';

	if ($rank == '')
		message($lang->t('Must enter title message'));

	if ($min_posts == '' || preg_match('%[^0-9]%', $min_posts))
		message($lang->t('Must be integer message'));

	// Make sure there isn't already a rank with the same min_posts value
	$data = array(
		':posts' => $min_posts,
	);

	$ps = $db->select('ranks', 1, $data, 'min_posts=:posts');
	if ($ps->rowCount())
		message($lang->t('Dupe min posts message', $min_posts));
	
	$insert = array(
		'rank'	=>	$rank,
		'min_posts'	=>	$min_posts,
	);

	$db->insert('ranks', $insert);

	// Regenerate the ranks cache
	$cache->generate('ranks');
	redirect(aura_link($aura_url['admin_ranks']), $lang->t('Rank added redirect'));
}
else if (isset($_POST['update'])) // Update a rank
{
	confirm_referrer(AURA_ADMIN_DIR.'/ranks.php');

	$id = intval(key($_POST['update']));

	$rank = isset($_POST['rank'][$id]) ? aura_trim($_POST['rank'][$id]) : '';
	$min_posts = isset($_POST['min_posts'][$id]) ? aura_trim($_POST['min_posts'][$id]) : '';

	if ($rank == '')
		message($lang->t('Must enter title message'));

	if ($min_posts == '' || preg_match('%[^0-9]%', $min_posts))
		message($lang->t('Must be integer message'));

	// Make sure there isn't already a rank with the same min_posts value
	$data = array(
		':id' => $id,
		':posts' => $min_posts,
	);

	$ps = $db->select('ranks', 1, $data, 'id!=:id AND min_posts=:posts');
	if ($ps->rowCount())
		message($lang->t('Dupe min posts message', $min_posts));

	$update = array(
		'rank' => $rank,
		'min_posts'	=> $min_posts,
	);

	$data = array(
		':id'	=>	$id,
	);

	$db->update('ranks', $update, 'id=:id', $data);

	// Regenerate the ranks cache
	$cache->generate('ranks');
	redirect(aura_link($aura_url['admin_ranks']), $lang->t('Rank updated redirect'));
}
else if (isset($_POST['remove'])) // Remove a rank
{
	confirm_referrer(AURA_ADMIN_DIR.'/ranks.php');

	$id = intval(key($_POST['remove']));
	$data = array(
		':id'	=>	$id,
	);

	$db->delete('ranks', 'id=:id', $data);

	// Regenerate the ranks cache
	$cache->generate('ranks');
	redirect(aura_link($aura_url['admin_ranks']), $lang->t('Rank removed redirect'));
}

$page_title = array($aura_config['o_board_title'], $lang->t('Admin'), $lang->t('Ranks'));
$focus_element = array('ranks', 'new_rank');
define('AURA_ACTIVE_PAGE', 'admin');
require AURA_ROOT.'header.php';

generate_admin_menu('ranks');

$ranks = array();
$ps = $db->select('ranks', 'id, rank, min_posts', array(), '', 'min_posts');
foreach ($ps as $cur_rank)
	$ranks[] = array('id' => $cur_rank['id'], 'rank' => $cur_rank['rank'], 'min_posts' => $cur_rank['min_posts']);

$tpl = load_template('admin_ranks.tpl');
echo $tpl->render(
	array(
		'lang' => $lang,
		'form_action' => aura_link($aura_url['admin_ranks']),
		'csrf_token' => generate_csrf_token(AURA_ADMIN_DIR.'/ranks.php'),
		'admin_options' => aura_link($aura_url['admin_options']),
		'ranks' => $ranks,
		'ranks_lang' => $aura_config['o_ranks'] == '1' ? $lang->t('Ranks enabled') : $lang->t('Ranks disabled'),
		'aura_config' => $aura_config,
	)
);

require AURA_ROOT.'footer.php';