<?php
/**
 * Copyright (C) 2017 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

if (!defined('AURA'))
{
	define('AURA_ROOT', __DIR__.'/../');
	require AURA_ROOT.'include/common.php';
}
require AURA_ROOT.'include/common_admin.php';

if (($aura_user['is_admmod'] && $aura_user['g_mod_cp'] == '0' && !$aura_user['is_admin']) || !$aura_user['is_admmod'])
	message($lang->t('No permission'), false, '403 Forbidden');

check_authentication();

$aura_groups = $cache->get('groups');

// Load the admin-users language file
$lang->load('admin_users');

// Show IP statistics for a certain user ID
if (isset($_GET['ip_stats']))
{
	$ip_stats = intval($_GET['ip_stats']);
	if ($ip_stats < 1)
		message($lang->t('Bad request'), false, '404 Not Found');

	// Fetch ip count
	$data = array(
		':id' => $ip_stats,
	);

	$ps = $db->select('posts', 'poster_ip, MAX(posted) AS last_used', $data, 'poster_id=:id GROUP BY poster_ip');
	$num_ips = $ps->rowCount();

	// Determine the ip offset (based on $_GET['p'])
	$num_pages = ceil($num_ips / 50);

	$p = (!isset($_GET['p']) || $_GET['p'] <= 1 || $_GET['p'] > $num_pages) ? 1 : intval($_GET['p']);
	$start_from = 50 * ($p - 1);
	
	$data = array(
		':id'	=>	$ip_stats,
		':limit'	=>	$start_from,
	);

	$ps = $db->select('posts', 'poster_ip, MAX(posted) AS last_used, COUNT(id) AS used_times', $data, 'poster_id=:id GROUP BY poster_ip', 'last_used DESC LIMIT :limit, 50');

	$page_title = array($aura_config['o_board_title'], $lang->t('Admin'), $lang->t('Users'), $lang->t('Results head'));
	define('AURA_ACTIVE_PAGE', 'admin');
	require AURA_ROOT.'header.php';
	
	$users = array();
	foreach ($ps as $cur_user)
		$users[] = array('host' => aura_link($aura_url['get_host'], array($cur_user['poster_ip'])), 'poster_ip' => $cur_user['poster_ip'], 'last_used' => format_time($cur_user['last_used']), 'used_times' => $cur_user['used_times'], 'show_link' => aura_link($aura_url['admin_users_users'], array($cur_user['poster_ip'])));

	$tpl = load_template('ip_stats.tpl');
	echo $tpl->render(
		array(
			'lang' => $lang,
			'index_link' => aura_link($aura_url['admin_index']),
			'users_link' => aura_link($aura_url['admin_users']),
			'pagination' => paginate($num_pages, $p, $aura_url['admin_users_ip_stats'], array($ip_stats)),
			'users' => $users,
		)
	);

	require AURA_ROOT.'footer.php';
}

if (isset($_GET['show_users']))
{
	$ip = aura_trim($_GET['show_users']);
	if (!@preg_match('%^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$%', $ip) && !@preg_match('%^((([0-9A-Fa-f]{1,4}:){7}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){6}:[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){5}:([0-9A-Fa-f]{1,4}:)?[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){4}:([0-9A-Fa-f]{1,4}:){0,2}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){3}:([0-9A-Fa-f]{1,4}:){0,3}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){2}:([0-9A-Fa-f]{1,4}:){0,4}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){6}((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|(([0-9A-Fa-f]{1,4}:){0,5}:((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|(::([0-9A-Fa-f]{1,4}:){0,5}((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|([0-9A-Fa-f]{1,4}::([0-9A-Fa-f]{1,4}:){0,5}[0-9A-Fa-f]{1,4})|(::([0-9A-Fa-f]{1,4}:){0,6}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){1,7}:))$%', $ip))
		message($lang->t('Bad IP message'));

	// Fetch user count
	$data = array(
		':ip' => $ip,
	);

	$ps = $db->select('posts', 'DISTINCT poster_id', $data, 'poster_ip=:ip');
	$num_users = $ps->rowCount();

	// Determine the user offset (based on $_GET['p'])
	$num_pages = ceil($num_users / 50);

	$p = (!isset($_GET['p']) || $_GET['p'] <= 1 || $_GET['p'] > $num_pages) ? 1 : intval($_GET['p']);
	$start_from = 50 * ($p - 1);
	
	$data = array(
		':ip' => $ip,
		':limit' => $start_from,
	);

	$page_title = array($aura_config['o_board_title'], $lang->t('Admin'), $lang->t('Users'), $lang->t('Results head'));
	define('AURA_ACTIVE_PAGE', 'admin');
	require AURA_ROOT.'header.php';
	
	$ps = $db->select('posts', 'DISTINCT poster_id, poster', $data, 'poster_ip=:ip', 'poster ASC LIMIT :limit, 50');
	$num_posts = $ps->rowCount();

	$users = array();
	if ($num_posts)
	{
		$posters = $poster_ids = $markers = $results = array();
		foreach ($ps as $cur_poster)
		{
			$posters[] = $cur_poster;
			$markers[] = '?';
			$poster_ids[] = $cur_poster['poster_id'];
		}

		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'groups',
				'as' => 'g',
				'on' => 'g.g_id=u.group_id',
			),
		);

		$user_data = array();
		$ps = $db->join('users', 'u', $join, 'u.id, u.username, u.email, u.title, u.num_posts, u.admin_note, g.g_id, g.g_user_title', $poster_ids, 'u.id>1 AND u.id IN('.implode(',', $markers).')');
		foreach ($ps as $cur_user)
			$user_data[$cur_user['id']] = $cur_user;

		// Loop through users and print out some info
		foreach ($posters as $cur_poster)
		{
			if (isset($user_data[$cur_poster['poster_id']]))
			{
				$users[] = array(
					'link' => aura_link($aura_url['profile'], array($user_data[$cur_poster['poster_id']]['id'], url_friendly($user_data[$cur_poster['poster_id']]['username']))),
					'username' => $user_data[$cur_poster['poster_id']]['username'],
					'email' => $user_data[$cur_poster['poster_id']]['email'],
					'title' => get_title($user_data[$cur_poster['poster_id']]),
					'num_posts' => forum_number_format($user_data[$cur_poster['poster_id']]['num_posts']),
					'admin_note' => $user_data[$cur_poster['poster_id']]['admin_note'],
					'ip_stats_link' => aura_link($aura_url['admin_users_ip_stats'], array($user_data[$cur_poster['poster_id']]['id'])),
					'search_posts_link' => aura_link($aura_url['search_user_posts'], array($user_data[$cur_poster['poster_id']]['id'])),
				);
			}
			else
				$users[] = array('poster' => $cur_poster['poster']);
		}
	}

	$tpl = load_template('show_users.tpl');
	echo $tpl->render(
		array(
			'lang' => $lang,
			'index_link' => aura_link($aura_url['admin_index']),
			'users_link' => aura_link($aura_url['admin_users']),
			'users' => $users,
			'pagination' => paginate($num_pages, $p, $aura_url['admin_users_users'], array($ip)),
		)
	);
	require AURA_ROOT.'footer.php';
}

// Move multiple users to other user groups
else if (isset($_POST['move_users']) || isset($_POST['move_users_comply']))
{
	if (!$aura_user['is_admin'])
		message($lang->t('No permission'), false, '403 Forbidden');

	confirm_referrer(AURA_ADMIN_DIR.'/users.php');

	if (isset($_POST['users']))
	{
		$user_ids = is_array($_POST['users']) ? array_keys($_POST['users']) : explode(',', $_POST['users']);
		$user_ids = array_map('intval', $user_ids);

		// Delete invalid IDs
		$user_ids = array_diff($user_ids, array(0, 1));
	}
	else
		$user_ids = array();

	if (empty($user_ids))
		message($lang->t('No users selected'));

	$data = array(AURA_ADMIN);
	$markers = array();
	for($i = 0; $i < count($user_ids); $i++)
	{
		$markers[] = '?';
		$data[] = $user_ids[$i];
	}

	// Are we trying to batch move any admins?
	$ps = $db->select('users', 1, $data, 'group_id=? AND id IN ('.implode(',', $markers).')');
	if ($ps->rowCount())
		message($lang->t('No move admins message'));

	// Fetch all user groups
	$all_groups = array();
	foreach ($aura_groups as $cur_group)
	{
		if ($cur_group['g_id'] != AURA_GUEST && $cur_group['g_id'] != AURA_ADMIN)
			$all_groups[$cur_group['g_id']] = $cur_group['g_title'];
	}

	if (isset($_POST['move_users_comply']))
	{
		$admins_altered = $moderators_altered = false;
		$new_group = isset($_POST['new_group']) && isset($all_groups[$_POST['new_group']]) ? $_POST['new_group'] : message($lang->t('Invalid group message'));

		unset($data[0]); // Avoid a second loop =)

		// Fetch user groups
		$user_groups = array();
		$ps = $db->select('users', 'id, group_id', array_values($data), 'id IN ('.implode(',', $markers).')');
		foreach ($ps as $cur_user)
		{
			// If we're unverified
			if (!$cur_user['group_id'])
				continue;

			if (($aura_groups[$cur_user['group_id']]['g_moderator'] == '1' || $cur_user['group_id'] == AURA_ADMIN) && $new_group != AURA_ADMIN && $aura_groups[$new_group]['g_moderator'] != '1')
			{
				$user_data = array(
					':id' => $cur_user['id'],
				);

				$ps = $db->delete('moderators', 'user_id=:id', $user_data);
				$moderators_altered = true;
			}

			// Check if the old group was an admin group and the new one isn't - or vice versa
			if ($aura_groups[$cur_user['group_id']]['g_admin'] != $aura_groups[$new_group]['g_admin'] || ($new_group != AURA_ADMIN && $cur_user['group_id'] == AURA_ADMIN || $cur_user['group_id'] != AURA_ADMIN && $new_group == AURA_ADMIN))
				$admins_altered = true;
		}

		$data[0] = $new_group;
		// Change user group

		$db->run('UPDATE '.$db->prefix.'users SET group_id=? WHERE id IN ('.implode(',', $markers).')', $data);

		// If the admins were altered earlier we need to relfect this in the cache
		if ($admins_altered)
			$cache->generate('admins');

		// And the same for the moderators
		if ($moderators_altered)
			$cache->generate('moderators');

		$cache->generate('stats');
		redirect(aura_link($aura_url['admin_users']), $lang->t('Users move redirect'));
	}

	$page_title = array($aura_config['o_board_title'], $lang->t('Admin'), $lang->t('Users'), $lang->t('Move users'));
	define('AURA_ACTIVE_PAGE', 'admin');
	require AURA_ROOT.'header.php';

	generate_admin_menu('users');
	
	$group_options = array();
	foreach ($all_groups as $gid => $group)
		$group_options[] = array('id' => $gid, 'title' => $group);
	
	$tpl = load_template('move_users.tpl');
	echo $tpl->render(
		array (
			'lang' => $lang,
			'form_action' => aura_link($aura_url['admin_users']),
			'user_ids' => $user_ids,
			'csrf_token' => generate_csrf_token(AURA_ADMIN_DIR.'/users.php'),
			'group_options' => $group_options,
		)
	);

	require AURA_ROOT.'footer.php';
}

// Delete multiple users
else if (isset($_POST['delete_users']) || isset($_POST['delete_users_comply']))
{
	if (!$aura_user['is_admin'])
		message($lang->t('No permission'), false, '403 Forbidden');

	confirm_referrer(AURA_ADMIN_DIR.'/users.php');

	if (isset($_POST['users']))
	{
		$user_ids = is_array($_POST['users']) ? array_keys($_POST['users']) : explode(',', $_POST['users']);
		$user_ids = array_map('intval', $user_ids);

		// Delete invalid IDs
		$user_ids = array_diff($user_ids, array(0, 1));
	}
	else
		$user_ids = array();

	if (empty($user_ids))
		message($lang->t('No users selected'));

	// Are we trying to delete any admins?
	$data = array(AURA_ADMIN);
	$markers = array();
	for($i = 0; $i < count($user_ids); $i++)
	{
		$markers[] = '?';
		$data[] = $user_ids[$i];
	}

	$ps = $db->select('users', 1, $data, 'group_id=? AND id IN ('.implode(',', $markers).')');
	if ($ps->rowCount())
		message($lang->t('No delete admins message'));

	if (isset($_POST['delete_users_comply']))
	{
		unset($data[0]);
		// Fetch user groups
		$user_groups = array();
		$admins_altered = false;
		$ps = $db->select('users', 'id, group_id', array_values($data), 'id IN ('.implode(',', $markers).')');
		foreach ($ps as $cur_user)
		{
			if ($cur_user['group_id'] == 0)
				continue;

			if ($aura_groups[$cur_user['group_id']]['g_moderator'] == '1' || $cur_user['group_id'] == AURA_ADMIN)
			{
				$user_data = array(
					':id' => $cur_user['id'],
				);

				$ps = $db->delete('moderators', 'user_id=:id', $user_data);
				$moderators_altered = true;
			}

			if ($aura_groups[$cur_user['group_id']]['g_admin'] == '1' || $cur_user['group_id'] == AURA_ADMIN)
				$admins_altered = true;
		}

		// Delete any subscriptions, then remove them from the online list (if they happen to be logged in)
		$db->delete('topic_subscriptions', 'user_id IN ('.implode(',', $markers).')', array_values($data));
		$db->delete('forum_subscriptions', 'user_id IN ('.implode(',', $markers).')', array_values($data));
		$db->delete('online', 'user_id IN ('.implode(',', $markers).')', array_values($data));		

		// Should we delete all posts made by these users?
		if (isset($_POST['delete_posts']))
		{
			require AURA_ROOT.'include/search_idx.php';
			@set_time_limit(0);

			$join = array(
				array(
					'type' => 'INNER',
					'table' => 'topics',
					'as' => 't',
					'on' => 't.id=p.topic_id',
				),
				array(
					'type' => 'INNER',
					'table' => 'forums',
					'as' => 'f',
					'on' => 'f.id=t.forum_id',
				),
			);

			// Find all posts made by this user
			$ps = $db->join('posts', 'p', $join, 'p.id, p.topic_id, t.forum_id', array_values($data), 'p.poster_id IN ('.implode(',', $markers).')');
			if ($ps->rowCount())
			{
				foreach ($ps as $cur_post)
				{
					// Determine whether this post is the "topic post" or not
					$data1 = array(
						':id' => $cur_post['topic_id'],
					);

					$ps1 = $db->select('posts', 'id', $data1, 'topic_id=:id', 'posted DESC LIMIT 1');
					if ($ps1->fetchColumn() == $cur_post['id'])
						delete_topic($cur_post['topic_id']);
					else
						delete_post($cur_post['id'], $cur_post['topic_id']);

					update_forum($cur_post['forum_id']);
				}
			}
		}
		else
			$db->run('UPDATE '.$db->prefix.'posts SET poster_id=1 WHERE poster_id IN ('.implode(',', $markers).')', array_values($data));

		// Delete the users
		$db->delete('users', 'id IN ('.implode(',', $markers).')', array_values($data));

		// Delete user avatars
		foreach ($user_ids as $user_id)
			delete_avatar($user_id);

		// If the admins were altered earlier we need to relfect this in the cache
		if ($admins_altered)
			$cache->generate('admins');

		// And the same for the moderators
		if ($moderators_altered)
			$cache->generate('moderators');

		// Regenerate the users info cache
		$cache->generate('stats');
		redirect(aura_link($aura_url['admin_users']), $lang->t('Users delete redirect'));
	}

	$page_title = array($aura_config['o_board_title'], $lang->t('Admin'), $lang->t('Users'), $lang->t('Delete users'));
	define('AURA_ACTIVE_PAGE', 'admin');
	require AURA_ROOT.'header.php';

	generate_admin_menu('users');
	
	$tpl = load_template('delete_users.tpl');
	echo $tpl->render(
		array(
			'lang' => $lang,
			'form_action' => aura_link($aura_url['admin_users']),
			'user_ids' => $user_ids,
			'csrf_token' => generate_csrf_token(AURA_ADMIN_DIR.'/users.php'),
		)
	);

	require AURA_ROOT.'footer.php';
}

// Ban multiple users
else if (isset($_POST['ban_users']) || isset($_POST['ban_users_comply']))
{
	if (!$aura_user['is_admin'] && ($aura_user['g_moderator'] != '1' || $aura_user['g_mod_ban_users'] == '0'))
		message($lang->t('No permission'), false, '403 Forbidden');

	confirm_referrer(AURA_ADMIN_DIR.'/users.php');

	if (isset($_POST['users']))
	{
		$user_ids = is_array($_POST['users']) ? array_keys($_POST['users']) : explode(',', $_POST['users']);
		$user_ids = array_map('intval', $user_ids);

		// Delete invalid IDs
		$user_ids = array_diff($user_ids, array(0, 1));
	}
	else
		$user_ids = array();

	if (empty($user_ids))
		message($lang->t('No users selected'));
	
	$data = array(AURA_ADMIN);
	$markers = array();
	for ($i = 0; $i < count($user_ids); $i++)
	{
		$data[] = $user_ids[$i];
		$markers[] = '?';
	}

	// Are we trying to ban any admins?
	$ps = $db->select('users', 1, $data, 'group_id=? AND id IN('.implode(',', $markers).')');
	if ($ps->rowCount())
		message($lang->t('No ban admins message'));
	
	unset($data[0]);

	$join = array(
		array(
			'type' => 'INNER',
			'table' => 'groups',
			'as' => 'g',
			'on' => 'u.group_id=g.g_id',
		),
	);

	// Also, we cannot ban moderators
	$ps = $db->join('users', 'u', $join, 1, array_values($data), 'g.g_moderator=1 AND u.id IN ('.implode(',', $markers).')');
	if ($ps->rowCount())
		message($lang->t('No ban mods message'));

	if (isset($_POST['ban_users_comply']))
	{
		$ban_message = aura_trim($_POST['ban_message']);
		$ban_expire = aura_trim($_POST['ban_expire']);
		$ban_the_ip = isset($_POST['ban_the_ip']) ? intval($_POST['ban_the_ip']) : 0;

		if ($ban_expire != '' && $ban_expire != 'Never')
		{
			$ban_expire = strtotime($ban_expire.' GMT');

			if ($ban_expire == -1 || !$ban_expire)
				message($lang->t('Invalid date message').' '.$lang->t('Invalid date reasons'));

			$diff = ($aura_user['timezone'] + $aura_user['dst']) * 3600;
			$ban_expire -= $diff;

			if ($ban_expire <= CURRENT_TIMESTAMP)
				message($lang->t('Invalid date message').' '.$lang->t('Invalid date reasons'));
		}
		else
			$ban_expire = null;

		$ban_message = ($ban_message != '') ? $ban_message : null;

		// Fetch user information
		$user_info = array();
		$ps = $db->select('users', 'id, username, email, registration_ip', array_values($data), 'id IN ('.implode(',', $markers).')');
		foreach ($ps as $cur_user)
			$user_info[$cur_user['id']] = array('username' => $cur_user['username'], 'email' => $cur_user['email'], 'ip' => $cur_user['registration_ip']);

		// Overwrite the registration IP with one from the last post (if it exists)
		if ($ban_the_ip != 0)
		{
			$ps = $db->run('SELECT p.poster_id, p.poster_ip FROM '.$db->prefix.'posts AS p INNER JOIN (SELECT MAX(id) AS id FROM '.$db->prefix.'posts WHERE poster_id IN ('.implode(',', $markers).') GROUP BY poster_id) AS i ON p.id=i.id', array_values($data));
			foreach ($ps as $cur_address)
				$user_info[$cur_address['poster_id']]['ip'] = $cur_address['poster_ip'];
		}

		// And insert the bans!
		foreach ($user_ids as $user_id)
		{

			$insert = array(
				'username'	=>	$user_info[$user_id]['username'],
				'ip'		=>	($ban_the_ip != 0) ? $user_info[$user_id]['ip'] : null,
				'email'	=>	$user_info[$user_id]['email'],
				'message'	=>	$ban_message,
				'expire'	=>	$ban_expire,
				'ban_creator'	=>	$aura_user['id'],
			);
			
			$db->insert('bans', $insert);
		}

		// Regenerate the bans cache
		$cache->generate('bans');
		redirect(aura_link($aura_url['admin_users']), $lang->t('Users banned redirect'));
	}

	$page_title = array($aura_config['o_board_title'], $lang->t('Admin'), $lang->t('Bans'));
	$focus_element = array('bans2', 'ban_message');
	define('AURA_ACTIVE_PAGE', 'admin');
	require AURA_ROOT.'header.php';

	generate_admin_menu('users');
	
	$tpl = load_template('ban_users.tpl');
	echo $tpl->render(
		array(
			'lang' => $lang,
			'form_action' => aura_link($aura_url['admin_users']),
			'user_ids' => $user_ids,
			'csrf_token' => generate_csrf_token(AURA_ADMIN_DIR.'/users.php'),
		)
	);

	require AURA_ROOT.'footer.php';
}
else if (isset($_GET['find_user']))
{
	$form = isset($_GET['form']) ? $_GET['form'] : array();

	// trim() all elements in $form
	$form = array_map('aura_trim', $form);
	$conditions = $query_str = $sql = $data = array();

	$posts_greater = isset($_GET['posts_greater']) ? aura_trim($_GET['posts_greater']) : '';
	$posts_less = isset($_GET['posts_less']) ? aura_trim($_GET['posts_less']) : '';
	$last_post_after = isset($_GET['last_post_after']) ? aura_trim($_GET['last_post_after']) : '';
	$last_post_before = isset($_GET['last_post_before']) ? aura_trim($_GET['last_post_before']) : '';
	$last_visit_after = isset($_GET['last_visit_after']) ? aura_trim($_GET['last_visit_after']) : '';
	$last_visit_before = isset($_GET['last_visit_before']) ? aura_trim($_GET['last_visit_before']) : '';
	$registered_after = isset($_GET['registered_after']) ? aura_trim($_GET['registered_after']) : '';
	$registered_before = isset($_GET['registered_before']) ? aura_trim($_GET['registered_before']) : '';
	$order_by = isset($_GET['order_by']) && in_array($_GET['order_by'], array('username', 'email', 'num_posts', 'last_post', 'last_visit', 'registered')) ? $_GET['order_by'] : 'username';
	$direction = isset($_GET['direction']) && $_GET['direction'] == 'DESC' ? 'DESC' : 'ASC';
	$user_group = isset($_GET['user_group']) ? intval($_GET['user_group']) : -1;

	$query_str[] = 'order_by='.$order_by;
	$query_str[] = 'direction='.$direction;
	$query_str[] = 'user_group='.$user_group;

	if (preg_match('%[^0-9]%', $posts_greater.$posts_less))
		message($lang->t('Non numeric message'));

	$sql[] = 'u.id>1';
	// Try to convert date/time to timestamps
	if ($last_post_after != '')
	{
		$query_str[] = 'last_post_after='.$last_post_after;

		$last_post_after = strtotime($last_post_after);
		if ($last_post_after === false || $last_post_after == -1)
			message($lang->t('Invalid date time message'));

		$sql[] = 'u.last_post>?';
		$data[] = $last_post_after;
	}
	if ($last_post_before != '')
	{
		$query_str[] = 'last_post_before='.$last_post_before;

		$last_post_before = strtotime($last_post_before);
		if ($last_post_before === false || $last_post_before == -1)
			message($lang->t('Invalid date time message'));

		$sql[] = 'u.last_post<?';
		$data[] = $last_post_before;
	}
	if ($last_visit_after != '')
	{
		$query_str[] = 'last_visit_after='.$last_visit_after;

		$last_visit_after = strtotime($last_visit_after);
		if ($last_visit_after === false || $last_visit_after == -1)
			message($lang->t('Invalid date time message'));

		$sql[] = 'u.last_visit>?';
		$data[] = $last_visit_after;
	}
	if ($last_visit_before != '')
	{
		$query_str[] = 'last_visit_before='.$last_visit_before;

		$last_visit_before = strtotime($last_visit_before);
		if ($last_visit_before === false || $last_visit_before == -1)
			message($lang->t('Invalid date time message'));

		$sql[] = 'u.last_visit<?';
		$data[] = $last_visit_before;
	}
	if ($registered_after != '')
	{
		$query_str[] = 'registered_after='.$registered_after;

		$registered_after = strtotime($registered_after);
		if ($registered_after === false || $registered_after == -1)
			message($lang->t('Invalid date time message'));

		$sql[] = 'u.registered>?';
		$data[] = $registered_after;
	}
	if ($registered_before != '')
	{
		$query_str[] = 'registered_before='.$registered_before;

		$registered_before = strtotime($registered_before);
		if ($registered_before === false || $registered_before == -1)
			message($lang->t('Invalid date time message'));

		$sql[] = 'u.registered<?';
		$data[] = $registered_before;
	}

	foreach ($form as $key => $input)
	{
		if ($input != '' && in_array($key, array('username', 'email', 'title', 'realname', 'url', 'facebook', 'steam', 'skype', 'twitter', 'google', 'location', 'signature', 'admin_note')))
		{
			$sql[] = 'u.'.$key.' LIKE ?';
			$data[] = str_replace('*', '%', $input);
			$query_str[] = 'form%5B'.$key.'%5D='.urlencode($input);
		}
	}

	if ($posts_greater != '')
	{
		$query_str[] = 'posts_greater='.$posts_greater;
		$conditions[] = 'u.num_posts>'.$posts_greater;
	}
	if ($posts_less != '')
	{
		$query_str[] = 'posts_less='.$posts_less;
		$conditions[] = 'u.num_posts<'.$posts_less;
	}

	if ($user_group > -1)
	{
		$sql[] = 'u.group_id=?';
		$data[] = $user_group;
	}

	$join = array(
		array(
			'type' => 'LEFT',
			'table' => 'groups',
			'as' => 'g',
			'on' => 'g.g_id=u.group_id',
		),
	);

	// Fetch user count
	$ps = $db->join('users', 'u', $join, 'COUNT(id)', $data, implode(' AND ', $sql));
	$num_users = $ps->fetchColumn();

	// Determine the user offset (based on $_GET['p'])
	$num_pages = ceil($num_users / 50);

	$p = (!isset($_GET['p']) || $_GET['p'] <= 1 || $_GET['p'] > $num_pages) ? 1 : intval($_GET['p']);
	$start_from = 50 * ($p - 1);

	// Some helper variables for permissions
	$can_delete = $can_move = $aura_user['is_admin'];
	$can_ban = $aura_user['is_admin'] || ($aura_user['g_moderator'] == '1' && $aura_user['g_mod_ban_users'] == '1');
	$can_action = ($can_delete || $can_ban || $can_move) && $num_users > 0;

	$join = array(
		array(
			'type' => 'LEFT',
			'table' => 'groups',
			'as' => 'g',
			'on' => 'g.g_id=u.group_id',
		),
	);

	$data[] = $start_from;
	$ps = $db->join('users', 'u', $join, 'u.id, u.username, u.email, u.title, u.num_posts, u.admin_note, g.g_id, g.g_user_title', $data, implode(' AND ', $sql), $order_by.' '.$direction.' LIMIT ?, 50');

	define('COMMON_JAVASCRIPT', true);
	$page_title = array($aura_config['o_board_title'], $lang->t('Admin'), $lang->t('Users'), $lang->t('Results head'));
	define('AURA_ACTIVE_PAGE', 'admin');
	require AURA_ROOT.'header.php';

	generate_admin_menu('users');

	$users = array();
	foreach ($ps as $user_data)
	{
		$user_title = get_title($user_data);
		$users[] = array(
			'id' => $user_data['id'],
			'title' => $user_title,
			'email' => $user_data['email'],
			'ip_stats_link' => aura_link($aura_url['admin_users_ip_stats'], array($user_data['id'])),
			'search_posts_link' => aura_link($aura_url['search_user_posts'], array($user_data['id'])),
			'profile_link' => aura_link($aura_url['profile'], array($user_data['id'], url_friendly($user_data['username']))),
			'username' => $user_data['username'],
			'num_posts' => forum_number_format($user_data['num_posts']),
			'admin_note' => $user_data['admin_note'],
			'unverified' => (($user_data['g_id'] == '' || $user_data['g_id'] == AURA_UNVERIFIED) && $user_title != $lang->t('Banned')) ? true : false,
		);
	}

	$tpl = load_template('admin_users_result.tpl');
	echo $tpl->render(
		array(
			'lang' => $lang,
			'index_link' => aura_link($aura_url['admin_index']),
			'form_action' => aura_link($aura_url['admin_users']),
			'can_action' => $can_action,
			'can_ban' => $can_ban,
			'can_delete' => $can_delete,
			'can_move' => $can_move,
			'csrf_token' => generate_csrf_token(AURA_ADMIN_DIR.'/users.php'),
			'pagination' => paginate($num_pages, $p, $aura_url['admin_users'].'?find_user=&amp;'.implode('&amp;', $query_str)),
			'users' => $users,
		)
	);

	require AURA_ROOT.'footer.php';
}
else
{
	$page_title = array($aura_config['o_board_title'], $lang->t('Admin'), $lang->t('Users'));
	$focus_element = array('find_user', 'form[username]');
	define('AURA_ACTIVE_PAGE', 'admin');
	require AURA_ROOT.'header.php';

	$groups = array();
	foreach ($aura_groups as $cur_group)
	{
		if ($cur_group['g_id'] != AURA_GUEST)
			$groups[] = array('id' => $cur_group['g_id'], 'title' => $cur_group['g_title']);
	}

	generate_admin_menu('users');
	$tpl = load_template('admin_users.tpl');
	echo $tpl->render(
		array(
			'lang' => $lang,
			'form_action' => aura_link($aura_url['admin_users']),
			'groups' => $groups
		)
	);

	require AURA_ROOT.'footer.php';
}