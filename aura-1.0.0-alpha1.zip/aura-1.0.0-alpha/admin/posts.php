<?php
/**
 * Copyright (C) 2017 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

if (!defined('AURA'))
{
	define('AURA_ROOT', __DIR__.'/../');
	require AURA_ROOT.'include/common.php';
}

require AURA_ROOT.'include/common_admin.php';

if (($aura_user['is_admmod'] && $aura_user['g_mod_cp'] == '0' && !$aura_user['is_admin']) || !$aura_user['is_admmod'])
	message($lang->t('No permission'), false, '403 Forbidden');

check_authentication();

// Load the admin-posts language file
$lang->load('admin_posts');

$parser = new parser($aura_config, $aura_user, $lang, $db, $cache);

require AURA_ROOT.'include/search_idx.php';
if (isset($_POST['post_id']))
{
	confirm_referrer(AURA_ADMIN_DIR.'/posts.php');
	$post_id = intval(key($_POST['post_id']));
	$action = isset($_POST['action']) && is_array($_POST['action']) ? intval($_POST['action'][$post_id]) : '1';
	$data = array(
		':id' => $post_id
	);

	$join = array(
		array(
			'type' => 'LEFT',
			'table' => 'topics',
			'as' => 't',
			'on' => 'p.topic_id=t.id',
		),
		array(
			'type' => 'LEFT',
			'table' => 'forums',
			'as' => 'f',
			'on' => 't.forum_id=f.id',
		),
		array(
			'type' => 'LEFT',
			'table' => 'users',
			'as' => 'u',
			'on' => 'p.poster_id=u.id',
		),
		array(
			'type' => 'LEFT',
			'table' => 'groups',
			'as' => 'g',
			'on' => 'u.group_id=g.g_id',
		),
	);

	$ps = $db->join('posts', 'p', $join, 'p.posted, p.message, p.poster, p.poster_id, p.topic_id, p.poster_email, u.email, p.poster_ip, t.forum_id, t.subject, t.first_post_id, f.forum_name, u.num_posts, g.g_promote_next_group, g.g_promote_min_posts', $data, 'p.id=:id');
	$post = $ps->fetch();

	$is_topic_post = ($post_id == $post['first_post_id']) ? true : false;
	if ($action == '1')
	{
		$update = array(
			'approved' => 1,
		);
		
		$db->update('posts', $update, 'id=:id', $data);
		if ($is_topic_post)
		{
			$update = array(
				'approved' => 1,
			);

			$data = array(
				':id' => $post['topic_id'],
			);
			$db->update('topics', $update, 'id=:id', $data);

			update_search_index('post', $post_id, $post['message'], $post['subject']);

			$aura_forums = $cache->get('forums');
			$subscriptions = new subscriptions($aura_config, $aura_user, $aura_url, $lang, $db, $aura_forums);
			$subscriptions->handle_forum_subscriptions($post, $post['poster'], $post['topic_id']);
		}
		else
		{
			// Just to be safe in case there has been another reply made since...
			$data = array(
				':id'	=>	$post['topic_id']
			);

			$ps = $db->select('posts', 'id, poster, posted', $data, 'topic_id=:id AND approved=1 AND deleted=0', 'id DESC LIMIT 1');
			list($last_id, $poster, $posted) = $ps->fetch(PDO::FETCH_NUM);
			
			$data = array(
				':last_post'	=>	$posted,
				':last_post_id'	=>	$last_id,
				':poster'		=>	$poster,
				':id'			=>	$post['topic_id'],
			);
	
			$db->run('UPDATE '.$db->prefix.'topics SET num_replies=num_replies+1, last_post=:last_post, last_post_id=:last_post_id, last_poster=:poster WHERE id=:id', $data);
			update_search_index('post', $post_id, $post['message'], $post['subject']);

			$aura_forums = $cache->get('forums');
			$subscriptions = new subscriptions($aura_config, $aura_user, $aura_url, $lang, $db, $aura_forums);
			$subscriptions->handle_topic_subscriptions($post['topic_id'], $post, $post['poster'], $post_id, $posted);
		}

		$aura_forums = $cache->get('forums');
		if ($aura_forums[$post['forum_id']]['increment_posts'] == '1')
		{
			$data = array(
				':id'	=>	$post['poster_id'],
			);

			$db->run('UPDATE '.$db->prefix.'users SET num_posts=num_posts+1 WHERE id=:id', $data);
		
			// Promote this user to a new group if enabled
			if ($post['g_promote_next_group'] != 0 && $post['num_posts'] >= $post['g_promote_min_posts'])
			{
				$update = array(
					'group_id' => $post['g_promote_next_group'],
				);
				
				$data = array(
					':id' => $post['poster_id'],
				);
				
				$db->update('users', $update, 'id=:id', $data);
			}
		}

		update_forum($post['forum_id']);
		redirect(aura_link($aura_url['admin_posts']), $lang->t('Post approved redirect'));
	}
	else
	{
		if (($aura_user['g_mod_sfs_report'] == '1' || $aura_user['is_admin']) && $action == '3' && $aura_config['o_sfs_api'] != '')
		{
			//If the user wasn't a guest we need to get the email from the users table
			$email = ($post['poster_email'] == '' && $post['poster_id'] != 1) ? $post['email'] : $post['poster_email'];

			//Reporting now made fun =)
			if (!stopforumspam_report($aura_config['o_sfs_api'], $post['poster_ip'], $email, $post['poster'], $post['message']))
				message($lang->t('Unable to add spam data'));
		}

		if ($is_topic_post)
		{
			delete_topic($post['topic_id']);
			update_forum($post['forum_id']);		
		}
		else
		{
			delete_post($post_id, $post['topic_id']);
			update_forum($post['forum_id']);
		}

		redirect(aura_link($aura_url['admin_posts']), $lang->t('Post deleted redirect'));
	}
}

$page_title = array($aura_config['o_board_title'], $lang->t('Admin'), $lang->t('Posts'));
define('AURA_ACTIVE_PAGE', 'admin');
require AURA_ROOT.'header.php';

generate_admin_menu('posts');

$join = array(
	array(
		'type' => 'INNER',
		'table' => 'topics',
		'as' => 't',
		'on' => 'p.topic_id=t.id',
	),
	array(
		'type' => 'LEFT',
		'table' => 'forums',
		'as' => 'f',
		'on' => 't.forum_id=f.id',
	),
	array(
		'type' => 'LEFT',
		'table' => 'forum_perms',
		'as' => 'fp',
		'on' => '(fp.forum_id=f.id AND fp.group_id=:gid)',
	),
);

$data = array(
	':gid' => $aura_user['g_id'],
);

$posts = array();
$moderators = $cache->get('moderators');
$ps = $db->join('posts', 'p', $join, 't.id AS topic_id, t.forum_id, p.poster, p.poster_id, p.posted, p.message, p.id AS pid, p.hide_smilies, t.subject, f.forum_name', $data, '(fp.read_forum IS NULL OR fp.read_forum=1) AND p.approved=0 AND p.deleted=0', 'p.posted DESC');
foreach ($ps as $cur_post)
{
	// Check if we can moderate this forum (if not, we shouldn't be approving posts for it)
	if (!isset($moderators[$cur_post['forum_id']]['u'.$aura_user['id']]) && !isset($moderators[$cur_post['forum_id']]['g'.$aura_user['g_id']]) && !$aura_user['is_admin'] && $aura_user['g_global_moderator'] != 1)
		continue;

	$data = array(
		':id'	=>	$cur_post['pid'],
	);

	$attachments = array();
	$ps1 = $db->select('attachments', 'id, filename, post_id, size, downloads', $data, 'post_id=:id');
	foreach ($ps1 as $cur_attach)
		$attachments[] = array('icon' => attach_icon(attach_get_extension($cur_attach['filename'])), 'link' => aura_link($aura_url['attachment'], array($cur_attach['id'])), 'name' => $cur_attach['filename'], 'size' => $lang->t('Attachment size', file_size($cur_attach['size'])), 'downloads' => $lang->t('Attachment downloads', forum_number_format($cur_attach['downloads'])));

	$posts[] = array(
		'posted' => format_time($cur_post['posted']),
		'poster' => ($cur_post['poster'] != '') ? array('href' => aura_link($aura_url['profile'], array($cur_post['poster_id'], url_friendly($cur_post['poster']))), 'poster' => $cur_post['poster']) : '',
		'message' => $parser->parse_message($cur_post['message'], $cur_post['hide_smilies']),
		'id' => $cur_post['pid'],
		'attachments' => $attachments,
		'forum' => ($cur_post['forum_name'] != '') ? array('href' => aura_link($aura_url['forum'], array($cur_post['forum_id'], url_friendly($cur_post['forum_name']))), 'forum_name' => $cur_post['forum_name']) : '',
		'topic' => ($cur_post['subject'] != '') ? array('href' => aura_link($aura_url['topic'], array($cur_post['topic_id'], url_friendly($cur_post['subject']))), 'subject' => $cur_post['subject']) : '',
		'post' => ($cur_post['pid'] != '') ? array('href' => aura_link($aura_url['post'], array($cur_post['pid'])), 'post' => $lang->t('Post ID', $cur_post['pid'])) : '',
	);
}

$tpl = load_template('admin_posts.tpl');
echo $tpl->render(
	array(
		'lang' => $lang,
		'form_action' => aura_link($aura_url['admin_posts']),
		'csrf_token' => generate_csrf_token(AURA_ADMIN_DIR.'/posts.php'),
		'posts' => $posts,
	)
);

require AURA_ROOT.'footer.php';