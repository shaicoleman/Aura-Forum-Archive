<?php
/**
 * Copyright (C) 2017 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

if (!defined('AURA'))
{
	define('AURA_ROOT', __DIR__.'/../');
	require AURA_ROOT.'include/common.php';
}

require AURA_ROOT.'include/common_admin.php';
$action = isset($_GET['action']) ? $_GET['action'] : null;
$id = isset($_GET['id']) ? intval($_GET['id']) : '0';
$page = (!isset($_GET['p']) || $_GET['p'] <= '1') ? '1' : intval($_GET['p']);

if (!$aura_user['is_admin'])
	message($lang->t('No permission'), false, '403 Forbidden');

if ($aura_user['id'] != '2')
{
	if (!is_null($restrictions[$aura_user['id']]['admin_moderate']))
	{
		if ($restrictions[$aura_user['id']]['admin_moderate'] == '0')
			message($lang->t('No permission'), false, '403 Forbidden');
	}
}

check_authentication();

// Load the admin-moderate language file
$lang->load('admin_moderate');

if (isset($_POST['form_sent']))
{
	confirm_referrer(AURA_ADMIN_DIR.'/moderate.php');
	if ($action == 'add')
	{
		$message = isset($_POST['message']) ? aura_trim($_POST['message']) : null;
		$title = isset($_POST['title']) ? aura_trim($_POST['title']) : null;
		$add_start = isset($_POST['add_start']) ? utf8_ltrim($_POST['add_start']) : null;
		$add_end = isset($_POST['add_end']) ? utf8_rtrim($_POST['add_end']) : null;
		$increment_posts = isset($_POST['increment_posts']) ? intval($_POST['increment_posts']) : '0';
		$report_posts = isset($_POST['report_posts']) ? intval($_POST['report_posts']) : '0';
		$send_email = isset($_POST['send_email']) ? intval($_POST['send_email']) : '0';

		if (aura_strlen($title) > 50)
			message($lang->t('Title too long'));

		if (aura_strlen($add_start) > 50 || strlen($add_end) > 50)
			message($lang->t('Addition too long'));

		if (aura_strlen($title) < 1)
			message($lang->t('Bad request'));

		$close = isset($_POST['close']) ? intval($_POST['close']) : '2';
		$stick = isset($_POST['stick']) ? intval($_POST['stick']) : '2';
		$archive = isset($_POST['archive']) ? intval($_POST['archive']) : '2';
		$move = isset($_POST['forum']) ? intval($_POST['forum']) : '0';
		$leave_redirect = isset($_POST['redirect']) ? intval($_POST['redirect']) : '0';
	
		$insert = array(
			'title'	=>	$title,
			'close'	=>	$close,
			'stick'	=>	$stick,
			'archive' => $archive,
			'move'	=>	$move,
			'leave_redirect' => $leave_redirect,
			'reply_message'	=>	$message,
			'add_start'	=>	$add_start,
			'add_end'	=>	$add_end,
			'send_email' =>	$send_email,
			'increment_posts' => $increment_posts,
			'report_posts' => $report_posts,
		);

		$db->insert('multi_moderation', $insert);
		redirect(aura_link($aura_url['admin_moderate']), $lang->t('Added redirect'));
	}
	elseif ($action == 'edit' && $id > '0')
	{
		$message = isset($_POST['message']) ? aura_trim($_POST['message']) : null;
		$title = isset($_POST['title']) ? aura_trim($_POST['title']) : null;
		$add_start = isset($_POST['add_start']) ? utf8_ltrim($_POST['add_start']) : null;
		$add_end = isset($_POST['add_end']) ? utf8_rtrim($_POST['add_end']) : null;

		if (aura_strlen($title) > 50)
			message($lang->t('Title too long'));
			
		if (aura_strlen($add_start) > 50 || strlen($add_end) > 50)
			message($lang->t('addition too long'));
	
		if (aura_strlen($title) < 1)
			message($lang->t('Bad request'));
	
		$close = isset($_POST['close']) ? intval($_POST['close']) : '2';
		$stick = isset($_POST['stick']) ? intval($_POST['stick']) : '2';
		$archive = isset($_POST['archive']) ? intval($_POST['archive']) : '2';
		$move = isset($_POST['forum']) ? intval($_POST['forum']) : '0';
		$leave_redirect = isset($_POST['redirect']) ? intval($_POST['redirect']) : '0';
		$increment_posts = isset($_POST['increment_posts']) ? intval($_POST['increment_posts']) : '0';
		$report_posts = isset($_POST['report_posts']) ? intval($_POST['report_posts']) : '0';
		$send_email = isset($_POST['send_email']) ? intval($_POST['send_email']) : '0';
		
		$update = array(
			'title' => $title,
			'close' => $close,
			'stick' => $stick,
			'archive' => $archive,
			'move' => $move,
			'leave_redirect' =>	$leave_redirect,
			'reply_message'	=>	$message,
			'add_start' => $add_start,
			'add_end' => $add_end,
			'send_email' => $send_email,
			'increment_posts' => $increment_posts,
			'report_posts' => $report_posts,
		);
		
		$data = array(
			':id'	=>	$id,
		);

		$db->update('multi_moderation', $update, 'id=:id', $data);
		redirect(aura_link($aura_url['admin_moderate']), $lang->t('Edit redirect'));
	}
	elseif ($action == 'delete' && $id > '0')
	{
		$data = array(
			':id'	=>	$id,
		);

		$rows = $db->delete('multi_moderation', 'id=:id', $data);
		if (!$rows)
			message($lang->t('Bad request')); // If there are no rows returned we've either attempted to URL hack or something is wrong with the database (which will be displayed)

		redirect(aura_link($aura_url['admin_moderate']), $lang->t('delete redirect'));
	}
}

$page_title = array($aura_config['o_board_title'], $lang->t('Admin'), $lang->t('Moderate'));
define('AURA_ACTIVE_PAGE', 'admin');
require AURA_ROOT.'header.php';

generate_admin_menu('moderate'); 

if ($action == 'add' || $action == 'edit')
{
	if ($action == 'edit')
	{
		$data = array(
			':id'	=>	$id,
		);

		$ps = $db->select('multi_moderation', 'close, stick, archive, move, leave_redirect, reply_message, title, add_start, add_end, send_email, increment_posts, report_posts', $data, 'id=:id');
		$cur_action = $ps->fetch();
	}
	else
	{
		$cur_action = array(
			'close' => 2,
			'stick' => 2,
			'archive' => 2,
			'move' => 0,
			'leave_redirect' => 0,
			'reply_message' => '',
			'title' => '',
			'add_start' => '',
			'add_end' => '',
			'send_email' => 1,
			'increment_posts' => 1,
			'report_posts' => 0,
		);
	}

	$join = array(
		array(
			'type' => 'INNER',
			'table' => 'forums',
			'as' => 'f',
			'on' => 'c.id=f.cat_id',
		),
	);

	// Display all the categories and forums
	$categories = $forums = array();
	$ps = $db->join('categories', 'c', $join, 'c.id AS cid, c.cat_name, f.id AS fid, f.forum_name', array(), 'f.redirect_url IS NULL', 'c.disp_position, c.id, f.disp_position');
	foreach ($ps as $cur_forum)
	{
		if (!isset($categories[$cur_forum['cid']]))
			$categories[$cur_forum['cid']] = array(
				'name' => $cur_forum['cat_name'],
				'id' => $cur_forum['cid'],
			);

		$forums[] = array(
			'id' => $cur_forum['fid'],
			'name' => $cur_forum['forum_name'],
			'category_id' => $cur_forum['cid'],
		);
	}

	$tpl = load_template('edit_action.tpl');
	echo $tpl->render(
		array(
			'aura_config' => $aura_config,
			'lang' => $lang,
			'csrf_token' => generate_csrf_token(AURA_ADMIN_DIR.'/moderate.php'),
			'form_action' => ($action == 'add') ? aura_link($aura_url['admin_moderate_add']) : aura_link($aura_url['admin_moderate_edit'], array($id)),
			'action' => $cur_action,
			'categories' => $categories,
			'forums' => $forums,
		)
	);
}
else if ($action == 'delete' && $id > '0')
{
	$tpl = load_template('delete_action.tpl');
	echo $tpl->render(
		array(
			'lang' => $lang,
			'form_action' => aura_link($aura_url['admin_moderate_delete'], array($id)),
			'csrf_token' => generate_csrf_token(AURA_ADMIN_DIR.'/moderate.php'),
		)
	);
}
else
{
	$ps = $db->select('multi_moderation', 'COUNT(id)');
	$total = $ps->fetchColumn();

	$num_pages = ceil($total/15);
	if ($page > $num_pages) $page = 1;
	$start_from = 15*($page-1);

	$ps = $db->select('multi_moderation', 'title, id', array(), '', 'id DESC LIMIT '.$start_from.', '.$aura_config['o_disp_topics_default']);

	$actions = array();
	foreach ($ps as $action)
		$actions[] = array(
			'title' => $action['title'],
			'edit_link' => aura_link($aura_url['admin_moderate_edit'], array($action['id'])),
			'delete_link' => aura_link($aura_url['admin_moderate_delete'], array($action['id'])),
		);

	$tpl = load_template('admin_moderate.tpl');
	echo $tpl->render(
		array(
			'lang' => $lang,
			'add_link' => aura_link($aura_url['admin_moderate_add']),
			'pagination' => paginate($num_pages, $page, $aura_url['admin_moderate'].'?'),
			'actions' => $actions,
		)
	);
}

require AURA_ROOT.'footer.php';