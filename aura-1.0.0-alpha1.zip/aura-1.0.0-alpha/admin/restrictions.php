<?php
/**
 * Copyright (C) 2017 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

if (!defined('AURA'))
{
	define('AURA_ROOT', __DIR__.'/../');
	require AURA_ROOT.'include/common.php';
}

require AURA_ROOT.'include/common_admin.php';

if (!$aura_user['is_admin'])
	message($lang->t('No permission'));

// Load the admin-restrictions language file
$lang->load('admin_restrictions');

if ($aura_user['id'] != '2')
{
	if (!is_null($restrictions[$aura_user['id']]['admin_restrictions']))
	{
		if ($restrictions[$aura_user['id']]['admin_restrictions'] == '0')
			message($lang->t('No permission'), false, '403 Forbidden');
	}
}

check_authentication();

$action = isset($_GET['action']) ? $_GET['action'] : null;
$stage = isset($_GET['stage']) ? intval($_GET['stage']) : null;
$csrf_token = generate_csrf_token(AURA_ADMIN_DIR.'/restrictions.php');

if (($action == 'add' || $action == 'edit') && isset($_POST['form_sent']) && $stage == '3')
{
	confirm_referrer(AURA_ADMIN_DIR.'/restrictions.php');

	//Stage 3: Add/edit restrictions
	$user = isset($_POST['admin_id']) ? intval($_POST['admin_id']) : 0;
	if ($user < 1)
		message($lang->t('Bad request'));

	$board_config = isset($_POST['board_config']) ? intval($_POST['board_config']) : '1';
	$board_perms = isset($_POST['board_perms']) ? intval($_POST['board_perms']) : '1';	
	$board_cats = isset($_POST['board_cats']) ? intval($_POST['board_cats']) : '1';
	$board_forums = isset($_POST['board_forums']) ? intval($_POST['board_forums']) : '1';	
	$board_groups = isset($_POST['board_groups']) ? intval($_POST['board_groups']) : '1';
	$board_users = isset($_POST['board_users']) ? intval($_POST['board_users']) : '1';
	$board_censoring = isset($_POST['board_censoring']) ? intval($_POST['board_censoring']) : '1';
	$board_ranks = isset($_POST['board_ranks']) ? intval($_POST['board_ranks']) : '1';
	$board_moderate = isset($_POST['board_moderate']) ? intval($_POST['board_moderate']) : '1';
	$board_maintenance = isset($_POST['board_maintenance']) ? intval($_POST['board_maintenance']) : '0';
	$board_plugins = isset($_POST['board_plugins']) ? intval($_POST['board_plugins']) : '1';
	$board_restrictions = isset($_POST['board_restrictions']) ? intval($_POST['board_restrictions']) : '0';
	$board_updates = isset($_POST['board_updates']) ? intval($_POST['board_updates']) : '0';
	$board_archive = isset($_POST['board_archive']) ? intval($_POST['board_archive']) : '1';
	$board_smilies = isset($_POST['board_smilies']) ? intval($_POST['board_smilies']) : '1';
	$board_warnings = isset($_POST['board_warnings']) ? intval($_POST['board_warnings']) : '1';
	$board_attachments = isset($_POST['board_attachments']) ? intval($_POST['board_attachments']) : '1';
	$board_robots = isset($_POST['board_robots']) ? intval($_POST['board_robots']) : '1';
	$board_extensions = isset($_POST['board_addons']) ? intval($_POST['board_addons']) : '1';
	$board_tasks = isset($_POST['board_tasks']) ? intval($_POST['board_tasks']) : '1';

	$data = array(
		':id'	=>	$user,
		':admin' => AURA_ADMIN,
	);

	$join = array(
		array(
			'type' => 'INNER',
			'table' => 'groups',
			'as' => 'g',
			'on' => 'u.group_id=g.g_id',
		),
	);

	$ps = $db->join('users', 'u', $join, 1, $data, 'u.group_id=:id OR g.g_admin=1 OR g.g_id=:admin');
	if (!$ps->rowCount())
		message($lang->t('No user'));

	$data = array(
		':id' => $user,
	);

	$restrictions = array(
		'admin_options' => $board_config,
		'admin_permissions' => $board_perms,
		'admin_categories' => $board_cats,
		'admin_forums' => $board_forums,
		'admin_groups' => $board_groups,
		'admin_censoring' => $board_censoring,
		'admin_maintenance' => $board_maintenance,
		'admin_plugins' => $board_plugins,
		'admin_restrictions' => $board_restrictions,
		'admin_users' => $board_users,
		'admin_moderate' => $board_moderate,
		'admin_ranks' => $board_ranks,
		'admin_updates' => $board_updates,
		'admin_archive' => $board_archive,
		'admin_smilies' => $board_smilies,
		'admin_warnings' => $board_warnings,
		'admin_attachments' => $board_attachments,
		'admin_robots' => $board_robots,
		'admin_extensions' => $board_extensions,
		'admin_tasks' => $board_tasks,
	);

	$insert = array(
		'admin_id'	=>	$user,
		'restrictions' => serialize($restrictions),
	);

	if ($action == 'add')
	{
		$db->insert('restrictions', $insert);
		$redirect_lang = $lang->t('Added redirect');
	}
	else
	{
		$data = array(
			':id' => $user,
		);

		$db->update('restrictions', $insert, 'admin_id=:id', $data);
		$redirect_lang = $lang->t('Edited redirect');
	}

	$cache->generate('restrictions');
	redirect(aura_link($aura_url['admin_restrictions']), $redirect_lang);
}
else if ($action == 'delete' && isset($_POST['form_sent']) && $stage == '3')
{
	confirm_referrer(AURA_ADMIN_DIR.'/restrictions.php');

	//Stage 3: Remove restrictions
	$user = isset($_POST['admin_id']) ? intval($_POST['admin_id']) : 0;
	$data = array(
		':id' => $user,
	);

	$ps = $db->select('restrictions', 1, $data, 'admin_id=:id');

	if (!$ps->rowCount())
		message($lang->t('No restrictions'));

	$db->delete('restrictions', 'admin_id=:id', $data);

	$cache->generate('restrictions');
	redirect(aura_link($aura_url['admin_restrictions']), $lang->t('Removed redirect'));
}

$page_title = array($aura_config['o_board_title'], $lang->t('Admin'), $lang->t('Restrictions'));
define('AURA_ACTIVE_PAGE', 'admin');
require AURA_ROOT.'header.php';

if ($action == 'delete' && isset($_POST['form_sent']) && $stage == '2')
{
	//Stage 2: Confirm Removal of existing restrictions
	$user = isset($_POST['user']) ? intval($_POST['user']) : 0;
	$data = array(
		':id' => $user,
	);

	$ps = $db->select('restrictions', 1, $data, 'admin_id=:id');

	if (!$ps->rowCount())
		message($lang->t('No restrictions'));

	generate_admin_menu('restrictions');

	$tpl = load_template('delete_restriction.tpl');
	echo $tpl->render(
		array(
			'lang' => $lang,
			'form_action' => aura_link($aura_url['admin_restrictions_query'], array('action=delete&stage=3')),
			'csrf_token' => $csrf_token,
			'user' => $user,
		)
	);
}
else if (($action == 'edit' || $action == 'add') && isset($_POST['form_sent']) && $stage == '2')
{
	confirm_referrer(AURA_ADMIN_DIR.'/restrictions.php');

	//Stage 2: Edit existing restrictions
	$user = isset($_POST['user']) ? intval($_POST['user']) : 0;
	$data = array(
		':id' => $user,
	);

	$ps = $db->select('users', 'username, group_id', $data, 'id=:id');
	if (!$ps->rowCount())
		message($lang->t('Bad request'));

	list($username, $group_id) = $ps->fetch(PDO::FETCH_NUM);

	$groups = $cache->get('groups');
	if ($groups[$group_id]['g_admin'] != '1' && $group_id != AURA_ADMIN)
		message($lang->t('Bad request'));

	// Then we're adding restrictions
	if (!isset($restrictions[$user]))
	{
		$restrictions[$user] = array(
			'admin_options' => 1,
			'admin_permissions' => 1,
			'admin_categories' => 1,
			'admin_forums' => 1,
			'admin_groups' => 1,
			'admin_censoring' => 1,
			'admin_maintenance' => 1,
			'admin_plugins' => 1,
			'admin_restrictions' => 1,
			'admin_users' => 1,
			'admin_moderate' => 1,
			'admin_ranks' => 1,
			'admin_updates' => 1,
			'admin_archive' => 1,
			'admin_smilies' => 1,
			'admin_warnings' => 1,
			'admin_attachments' => 1,
			'admin_robots' => 1,
			'admin_extensions' => 1,
			'admin_tasks' => 1,
		);
	}

	generate_admin_menu('restrictions');

	$tpl = load_template('edit_restriction.tpl');
	echo $tpl->render(
		array(
			'lang' => $lang,
			'admin' => $restrictions[$user],
			'user' => $user,
			'csrf_token' => $csrf_token,
			'form_action' => aura_link($aura_url['admin_restrictions_query'], array('action='.$action.'&stage=3')),
			'username' => $username,
		)
	);
}
else
{
	if (count($cache->get('admins')) < 2)
		message($lang->t('No administrators available'));

	$data = array(
		':admin' => AURA_ADMIN,
	);

	$join = array(
		array(
			'type' => 'LEFT',
			'table' => 'restrictions',
			'as' => 'ar',
			'on' => 'u.id=ar.admin_id',
		),
		array(
			'type' => 'INNER',
			'table' => 'groups',
			'as' => 'g',
			'on' => 'u.group_id=g.g_id',
		),
	);

	$administrators = $restricted = array();
	$ps = $db->join('users', 'u', $join, 'u.username, u.id', $data, '(u.group_id=:admin OR g.g_admin=1) AND u.id!=2 AND ar.admin_id IS NULL', 'u.id ASC');
	foreach ($ps as $admin)
		$administrators[] = array('id' => $admin['id'], 'username' => $admin['username']);

	$ps = $db->join('users', 'u', $join, 'u.username, u.id', $data, '(u.group_id=:admin OR g.g_admin=1) AND u.id!=2 AND ar.admin_id IS NOT NULL', 'u.id ASC');
	foreach ($ps as $admin)
		$restricted[] = array('id' => $admin['id'], 'username' => $admin['username']);

	generate_admin_menu('restrictions');

	$tpl = load_template('admin_restrictions.tpl');
	echo $tpl->render(
		array(
			'lang' => $lang,
			'csrf_token' => $csrf_token,
			'add_action' => aura_link($aura_url['admin_restrictions_query'], array('action=add&stage=2')),
			'edit_action' => aura_link($aura_url['admin_restrictions_query'], array('action=edit&stage=2')),
			'delete_action' => aura_link($aura_url['admin_restrictions_query'], array('action=delete&stage=2')),
			'restrictions' => $restricted,
			'administrators' => $administrators,
		)
	);
}

require AURA_ROOT.'footer.php';