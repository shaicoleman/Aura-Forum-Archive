<?php
/**
 * Copyright (C) 2017 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

if (!defined('AURA'))
{
	define('AURA_ROOT', __DIR__.'/../');
	require AURA_ROOT.'include/common.php';
}
require AURA_ROOT.'include/common_admin.php';

if (($aura_user['is_admmod'] && $aura_user['g_mod_cp'] == '0' && !$aura_user['is_admin']) || !$aura_user['is_admmod'])
	message($lang->t('No permission'), false, '403 Forbidden');

check_authentication();

if ($aura_config['o_delete_full'] == '1')
	message($lang->t('Bad request'));

// Load the admin-deleted language file
$lang->load('admin_deleted');

if (isset($_POST['post_id']))
{
	confirm_referrer(AURA_ADMIN_DIR.'/deleted.php');
	$post_id = intval(key($_POST['post_id']));
	$action = isset($_POST['action']) && is_array($_POST['action']) ? intval($_POST['action'][$post_id]) : '1';

	$join = array(
		array(
			'type' => 'INNER',
			'table' => 'topics',
			'as' => 't',
			'on' => 'p.topic_id=t.id',
		),
	);

	$data = array(
		':id' => $post_id,
	);

	$ps = $db->join('posts', 'p', $join, 't.first_post_id, p.topic_id, p.message, t.subject, t.forum_id', $data, 'p.id=:id AND p.deleted=1');
	if (!$ps->rowCount())
		message($lang->t('Bad request'));
	else
		$post = $ps->fetch();

	$is_topic_post = ($post_id == $post['first_post_id']) ? true : false;
	if ($action == '1')
	{
		if ($is_topic_post)
		{
			$update = array(
				'deleted' => 0,
			);

			$data = array(
				':id' => $post['topic_id'],
			);

			$db->update('topics', $update, 'id=:id', $data);
			if (!defined('AURA_CJK_HANGUL_REGEX'))
				require AURA_ROOT.'include/search_idx.php';

			update_search_index('post', $post['topic_id'], $post['message'], $post['subject']);

			$db->update('posts', $update, 'topic_id=:id AND deleted=1 AND approved=1', $data);
			$ps = $db->select('posts', 'message, id', $data, 'id=:id');
			foreach ($ps as $cur_post)
				update_search_index('post', $cur_post['id'], $cur_post['message']);

			update_forum($post['forum_id']);
			redirect(aura_link($aura_url['admin_deleted']), $lang->t('Topic approved redirect'));
		}
		else
		{
			$topic_data = array(
				':id' => $post['topic_id'],
			);

			$ps = $db->select('topics', 1, $topic_data, 'id=:id AND deleted=0 AND approved=1');	// Check there's a valid topic to go back to
			if (!$ps->rowCount())
				message($lang->t('topic has been deleted'));

			$update = array(
				'deleted' => 0,
			);
			
			$post_data = array(
				':id' => $post_id,
			);
			
			$db->update('posts', $update, 'id=:id', $post_data);
			if (!defined('AURA_CJK_HANGUL_REGEX'))
				require AURA_ROOT.'include/search_idx.php';

			update_search_index('post', $post_id, $post['message']);
			
			$ps = $db->select('posts', 'id, poster, posted', $topic_data, 'topic_id=:id AND approved=1 AND deleted=0', 'id DESC LIMIT 1');
			list($last_id, $poster, $posted) = $ps->fetch(PDO::FETCH_NUM);
			
			$ps = $db->select('topics', 'num_replies', $topic_data, 'id=:id');
			$num_replies = $ps->fetchColumn();
			
			$update = array(
				'num_replies' => $num_replies+1,
				'last_post' => $posted,
				'last_post_id' => $last_id,
				'last_poster' => $poster,
			);

			$db->update('topics', $update, 'id=:id', $topic_data);
			update_search_index('post', $post_id, $post['message']);
				
			update_forum($post['forum_id']);
			redirect(aura_link($aura_url['admin_deleted']), $lang->t('Post approved redirect'));			
		}
	}
	else
	{
		if ($is_topic_post)
		{
			permanently_delete_topic($post['topic_id']);
			redirect(aura_link($aura_url['admin_deleted']), $lang->t('Topic deleted redirect'));
		}
		else
		{
			permanently_delete_post($post_id);
			redirect(aura_link($aura_url['admin_deleted']), $lang->t('Post deleted redirect'));
		}
	}
}

$join = array(
	array(
		'type' => 'LEFT',
		'table' => 'topics',
		'as' => 't',
		'on' => 'p.topic_id=t.id',
	),
	array(
		'type' => 'LEFT',
		'table' => 'forums',
		'as' => 'f',
		'on' => 't.forum_id=f.id',
	),
);

$ps = $db->join('posts', 'p', $join, 't.id AS topic_id, t.forum_id, p.poster, p.poster_id, p.posted, p.message, p.id AS pid, p.hide_smilies, t.subject, f.forum_name', array(), 'p.deleted=1 OR t.deleted=1', 'p.posted DESC');

$parser = new parser($aura_config, $aura_user, $lang, $db, $cache);

$page_title = array($aura_config['o_board_title'], $lang->t('Admin'), $lang->t('Deleted'));
define('AURA_ACTIVE_PAGE', 'admin');
require AURA_ROOT.'header.php';

generate_admin_menu('deleted');

$posts = array();
foreach ($ps as $cur_post)
	$posts[] = array(
		'id' => $cur_post['pid'],
		'posted' => format_time($cur_post['posted']),
		'message' => $parser->parse_message($cur_post['message'], $cur_post['hide_smilies']),
		'poster' => ($cur_post['poster'] != '') ? array('href' => aura_link($aura_url['profile'], array($cur_post['poster_id'], url_friendly($cur_post['poster']))), 'poster' => $cur_post['poster']) : '',
		'forum' => ($cur_post['forum_name'] != '') ? array('href' => aura_link($aura_url['forum'], array($cur_post['forum_id'], url_friendly($cur_post['forum_name']))), 'forum_name' => $cur_post['forum_name']) : '',
		'topic' => ($cur_post['subject'] != '') ? array('href' => aura_link($aura_url['topic'], array($cur_post['topic_id'], url_friendly($cur_post['subject']))), 'subject' => $cur_post['subject']) : '',
		'post' => ($cur_post['pid'] != '') ? array('href' => aura_link($aura_url['post'], array($cur_post['pid'])), 'post' => $lang->t('Post ID', $cur_post['pid'])) : '',
	);

$tpl = load_template('admin_deleted.tpl');
echo $tpl->render(
	array(
		'lang' => $lang,
		'form_action' => aura_link($aura_url['admin_deleted']),
		'csrf_token' => generate_csrf_token(AURA_ADMIN_DIR.'/deleted.php'),
		'posts' => $posts,
	)
);

require AURA_ROOT.'footer.php';