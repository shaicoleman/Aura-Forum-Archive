<?php
/**
 * Copyright (C) 2017 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

if (!defined('AURA'))
{
	define('AURA_ROOT', __DIR__.'/../');
	require AURA_ROOT.'include/common.php';
}

require AURA_ROOT.'include/common_admin.php';

if (!$aura_user['is_admmod'])
	message($lang->t('No permission'), false, '403 Forbidden');

check_authentication();

// Load the admin-index language file
$lang->load('admin_index');

// Get the server load averages (if possible)
if (@file_exists('/proc/loadavg') && is_readable('/proc/loadavg'))
{
	// We use @ just in case
	$fh = @fopen('/proc/loadavg', 'r');
	$load_averages = @fread($fh, 64);
	@fclose($fh);

	if (($fh = @fopen('/proc/loadavg', 'r')))
	{
		$load_averages = fread($fh, 64);
		fclose($fh);
	}
	else
		$load_averages = '';

	$load_averages = @explode(' ', $load_averages);
	$server_load = isset($load_averages[2]) ? $load_averages[0].' '.$load_averages[1].' '.$load_averages[2] : $lang->t('Not available');
}
else if (!in_array(PHP_OS, array('WINNT', 'WIN32')) && preg_match('%averages?: ([0-9\.]+),?\s+([0-9\.]+),?\s+([0-9\.]+)%i', @exec('uptime'), $load_averages))
	$server_load = $load_averages[1].' '.$load_averages[2].' '.$load_averages[3];
else
	$server_load = $lang->t('Not available');

// Get number of current visitors
$ps = $db->select('online', 'COUNT(user_id)', array(), 'idle=0');
$num_online = $ps->fetchColumn();

$page_title = array($aura_config['o_board_title'], $lang->t('Admin'), $lang->t('Server statistics'));
define('AURA_ACTIVE_PAGE', 'admin');
require AURA_ROOT.'header.php';

generate_admin_menu('index');

$render = array();
if ($aura_user['is_admin'])
{
	// Collect some additional info about MySQL
	$ps = $db->run('SHOW TABLE STATUS');
	$total_records = $total_size = 0;
	foreach ($ps as $status)
	{
		$total_records += $status['Rows'];
		$total_size += $status['Data_length'] + $status['Index_length'];
	}

	$total_size = file_size($total_size);

	// Check for the existence of various PHP opcode caches/optimizers
	if (function_exists('mmcache'))
		$php_accelerator = array('url' => $lang->t('Turck MMCache link'), 'title' => $lang->t('Turck MMCache'));
	else if (isset($_PHPA))
		$php_accelerator = array('url' => $lang->t('ionCube PHP Accelerator link'), 'title' => $lang->t('ionCube PHP Accelerator'));
	else if (ini_get('apc.enabled'))
		$php_accelerator = array('url' => $lang->t('Alternative PHP Cache (APC) link'), 'title' => $lang->t('Alternative PHP Cache (APC)'));
	else if (ini_get('zend_optimizer.optimization_level'))
		$php_accelerator = array('url' => $lang->t('Zend Optimizer link'), 'title' => $lang->t('Zend Optimizer'));
	else if (ini_get('eaccelerator.enable'))
		$php_accelerator = array('url' => $lang->t('eAccelerator link'), 'title' => $lang->t('eAccelerator'));
	else if (ini_get('xcache.cacher'))
		$php_accelerator = array('url' => $lang->t('XCache link'), 'title' => $lang->t('XCache'));
	else
		$php_accelerator = $lang->t('NA');

	$render = array(
		'PHP_OS' => PHP_OS,
		'php_version' => PHP_VERSION,
		'phpinfo' => aura_link($aura_url['phpinfo']),
		'php_accelerator' => $php_accelerator,
		'db_version' => $db->get_version(),
		'total_records' => forum_number_format($total_records),
		'total_size' => $total_size
	);
}

$tpl = load_template('admin_statistics.tpl');
echo $tpl->render(
	array_merge(
			array(
			'lang' => $lang,
			'server_load' => $server_load,
			'num_online' => $num_online,
			'aura_user' => $aura_user,
		), $render
	)
);

require AURA_ROOT.'footer.php';