<?php
/**
 * Copyright (C) 2017 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

// Tell header.php we want jQuery included ...
define('JQUERY_REQUIRED', 1);

// ... and that we want the jQuery for the admin notes included.
define('ADMIN_INDEX', 1);

if (!defined('AURA'))
{
	define('AURA_ROOT', __DIR__.'/../');
	require AURA_ROOT.'include/common.php';
}

require AURA_ROOT.'include/common_admin.php';

if (($aura_user['is_admmod'] && $aura_user['g_mod_cp'] == '0' && !$aura_user['is_admin']) || !$aura_user['is_admmod'])
	message($lang->t('No permission'), false, '403 Forbidden');

check_authentication();

// Load the admin_index language file
$lang->load('admin_index');

$action = isset($_GET['action']) ? $_GET['action'] : null;

// Check for upgrade
if ($action == 'check_upgrade')
{
	$update = $cache->generate('updates', array($lang, true));
	if (version_compare($aura_config['o_cur_version'], $update['version'], '>='))
		message($lang->t('Running latest version message'));

    message($lang->t('New version available message', $update['version']));
}
else if ($action == 'delete_install')
{
	if (!$aura_user['is_admin'])
		message($lang->t('No permission'));

	delete_directory(AURA_ROOT.'install');
	delete_directory($cache->cache_dir.'templates/install');
	redirect(aura_link($aura_url['admin_index']), $lang->t('Deleted install redirect'));
}
else if ($action == 'phpinfo' && $aura_user['is_admin'])
{
	// Is phpinfo() a disabled function?
	if (strpos(strtolower((string) ini_get('disable_functions')), 'phpinfo') !== false)
		message($lang->t('PHPinfo disabled message'));

	phpinfo();
	exit;
}
elseif ($action == 'save_notes')
{
	if (!defined('AURA_AJAX_REQUEST'))
		message($lang->t('No permission'));

	$notes = isset($_POST['notes']) ? aura_trim($_POST['notes']) : $lang->t('Admin notes');
	$update = array(
		'conf_value' => $notes,
	);

	$db->update('config', $update, 'conf_name=\'o_admin_notes\'');
	$cache->generate('config', array($aura_config));

	$db->end_transaction();
	exit;
}

$alerts = array();
if ($aura_user['is_admin'])
{
	if (is_dir(AURA_ROOT.'/install'))
		$alerts[] = array('lang' => $lang->t('Install directory exists'), 'action_url' => aura_link($aura_url['delete_install']), 'action' => $lang->t('Delete install directory'));

	if (substr(sprintf('%o', fileperms(AURA_ROOT.'include/config.php')), -4) > 644)
		$alerts[] = array('lang' => $lang->t('Config file writable'), 'action_url' => 'https://www.get-aura.org/docs/article/19-configuration-file-is-currently-writable-security-risk-how-to-resolve-problem/', 'action' => $lang->t('Change now'));

	$update = $cache->get('updates', array($lang));
	if (!$update['failed'])
	{
		if (version_compare($aura_config['o_cur_version'], $update['version'], '<'))
			$alerts[] = array('lang' => $lang->t('New version alert', $update['version']), 'action_url' => aura_link($aura_url['admin_update']), 'action' => $lang->t('Update now'));

		if (file_exists(AURA_ROOT.'include/updates/'.$update['package']))
			$alerts[] = array('lang' => $lang->t('Update downloaded', $update['version']), 'action_url' => aura_link($aura_url['admin_update']), 'action' => $lang->t('Install package'));
	}

	foreach ($cache->get('admins') as $admin)
	{
		if ($admin == '2') // No restrictions for the original administrator
			continue;

		$data = array(
			':admin' => $admin,
		);

		if (!isset($restrictions[$admin]))
		{
			$alerts[] = array('lang' => $lang->t('No restrictions'), 'action_url' => aura_link($aura_url['admin_restrictions']), 'action' => $lang->t('Configure restrictions'));
			break;
		}
	}

	$avatar_path = ($aura_config['o_avatars_dir'] != '') ? $aura_config['o_avatars_path'].'/' : AURA_ROOT.$aura_config['o_avatars_path'].'/';
	$smiley_path = ($aura_config['o_smilies_dir'] != '') ? $aura_config['o_smilies_path'].'/' : AURA_ROOT.$aura_config['o_smilies_path'].'/';

	if (!forum_is_writable($avatar_path))
		$alerts[] = array('lang' => $lang->t('Alert avatar', $avatar_path));

	if (!forum_is_writable($smiley_path))
		$alerts[] = array('lang' => $lang->t('Alert smilies', $smiley_path));
}

$page_title = array($aura_config['o_board_title'], $lang->t('Admin'), $lang->t('Index'));
define('AURA_ACTIVE_PAGE', 'admin');
require AURA_ROOT.'header.php';

generate_admin_menu('index');

$tpl = load_template('admin_index.tpl');
echo $tpl->render(
	array(
		'lang' => $lang,
		'form_action' => aura_link($aura_url['save_notes']),
		'aura_config' => $aura_config,
		'upgrade_link' => aura_link($aura_url['check_upgrade']),
		'stats_link' => aura_link($aura_url['admin_statistics']),
		'alerts' => $alerts,
	)
);

require AURA_ROOT.'footer.php';