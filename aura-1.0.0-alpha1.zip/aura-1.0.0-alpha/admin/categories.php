<?php
/**
 * Copyright (C) 2017 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

if (!defined('AURA'))
{
	define('AURA_ROOT', __DIR__.'/../');
	require AURA_ROOT.'include/common.php';
}
require AURA_ROOT.'include/common_admin.php';

if (!$aura_user['is_admin'])
	message($lang->t('No permission'), false, '403 Forbidden');

if ($aura_user['id'] != '2')
{
	if (!is_null($restrictions[$aura_user['id']]['admin_categories']))
	{
		if ($restrictions[$aura_user['id']]['admin_categories'] == '0')
			message($lang->t('No permission'), false, '403 Forbidden');
	}
}

check_authentication();

// Load the admin-categories language file
$lang->load('admin_categories');

// Add a new category
if (isset($_POST['add_cat']))
{
	confirm_referrer(AURA_ADMIN_DIR.'/categories.php');

	$new_cat_name = isset($_POST['new_cat_name']) ? aura_trim($_POST['new_cat_name']) : '';
	if ($new_cat_name == '')
		message($lang->t('Must enter name message'));

	$insert = array(
		'cat_name'	=>	$new_cat_name,
	);

	$db->insert('categories', $insert);
	redirect(aura_link($aura_url['admin_categories']), $lang->t('Category added redirect'));
}

// Delete a category
else if (isset($_POST['del_cat']) || isset($_POST['del_cat_comply']))
{
	confirm_referrer(AURA_ADMIN_DIR.'/categories.php');

	$cat_to_delete = isset($_POST['cat_to_delete']) ? intval($_POST['cat_to_delete']) : 0;
	if ($cat_to_delete < 1)
		message($lang->t('Bad request'), false, '404 Not Found');

	if (isset($_POST['del_cat_comply'])) // Delete a category with all forums and posts
	{
		@set_time_limit(0);
		$data = array(
			':id' => $cat_to_delete,
		);

		$ps = $db->select('forums', 'id', $data, 'cat_id=:id');
		$ps->setFetchMode(PDO::FETCH_COLUMN, 0);
		foreach ($ps as $cur_forum)
		{
			prune($cur_forum, 1, -1);
			$data = array(
				':id'	=>	$cur_forum,
			);

			// Delete the forum
			$db->delete('forums', 'id=:id', $data);
		}

		$join = array(
			array(
				'type' => 'LEFT',
				'table' => 'topics',
				'as' => 't2',
				'on' => 't1.moved_to=t2.id',
			),
		);

		// Locate any "orphaned redirect topics" and delete them
		$db->join('topics', 't1', $join, 't1.id', array(), 't2.id IS NULL AND t1.moved_to IS NOT NULL');
		if ($ps->rowCount())
		{
			$data = $markers = array();
			$ps->setFetchMode(PDO::FETCH_COLUMN, 0);
			foreach ($ps as $orphan)
			{
				$markers[] = '?';
				$data[] = $orphan;
			}

			$db->delete('topics', 'id IN('.implode(',', $markers).')', $data);
		}
		
		$data = array(
			':id' => $cat_to_delete
		);

		// Delete the category
		$db->delete('categories', 'id=:id', $data);

		// Regenerate some caches ...
		$cache->generate('forums');
		$cache->generate('quickjump');
		$cache->generate('perms');

		redirect(aura_link($aura_url['admin_categories']), $lang->t('Category deleted redirect'));
	}
	else // If the user hasn't confirmed the delete
	{
		$data = array(
			':id' => $cat_to_delete,
		);

		$ps = $db->select('categories', 'cat_name', $data, 'id=:id');
		$cat_name = $ps->fetchColumn();

		$page_title = array($aura_config['o_board_title'], $lang->t('Admin'), $lang->t('Categories'));
		define('AURA_ACTIVE_PAGE', 'admin');
		require AURA_ROOT.'header.php';

		generate_admin_menu('categories');
		
		$tpl = load_template('delete_category.tpl');
		echo $tpl->render(
			array(
				'lang' => $lang,
				'form_action' => aura_link($aura_url['admin_categories']),
				'csrf_token' => generate_csrf_token(AURA_ADMIN_DIR.'/categories.php'),
				'cat_name' => $cat_name,
				'cat_to_delete' => $cat_to_delete,
			)
		);

		require AURA_ROOT.'footer.php';
	}
}
else if (isset($_POST['update'])) // Change position and name of the categories
{
	confirm_referrer(AURA_ADMIN_DIR.'/categories.php');

	$categories = isset($_POST['cat']) && is_array($_POST['cat']) ? $_POST['cat'] : array();
	if (empty($categories))
		message($lang->t('Bad request'), false, '404 Not Found');

	foreach ($categories as $cat_id => $cur_cat)
	{
		$cur_cat['name'] = isset($cur_cat['name']) ? aura_trim($cur_cat['name']) : '';
		$cur_cat['order'] = isset($cur_cat['order']) ? intval($cur_cat['order']) : 0;

		if ($cur_cat['name'] == '')
			message($lang->t('Must enter name message'));

		if ($cur_cat['order'] < 0)
			message($lang->t('Must enter integer message'));
		
		$update = array(
			'cat_name' => $cur_cat['name'],
			'disp_position' => $cur_cat['order'],
		);
		
		$data = array(
			':id' => intval($cat_id),
		);

		$db->update('categories', $update, 'id=:id', $data);
	}

	// Regenerate the quick jump cache
	$cache->generate('quickjump');
	redirect(aura_link($aura_url['admin_categories']), $lang->t('Categories updated redirect'));
}

$page_title = array($aura_config['o_board_title'], $lang->t('Admin'), $lang->t('Categories'));
define('AURA_ACTIVE_PAGE', 'admin');
require AURA_ROOT.'header.php';

generate_admin_menu('categories');

$categories = array();
$ps = $db->select('categories', 'id, cat_name, disp_position', array(), '', 'disp_position');
foreach ($ps as $cur_cat)
	$categories[] = array('id' => $cur_cat['id'], 'name' => $cur_cat['cat_name'], 'disp_position' => $cur_cat['disp_position']);

$tpl = load_template('admin_categories.tpl');
echo $tpl->render(
	array(
		'lang' => $lang,
		'form_action' => aura_link($aura_url['admin_categories']),
		'csrf_token' => generate_csrf_token(AURA_ADMIN_DIR.'/categories.php'),
		'admin_forums' => aura_link($aura_url['admin_forums']),
		'categories' => $categories,
	)
);

require AURA_ROOT.'footer.php';