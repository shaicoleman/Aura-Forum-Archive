<?php
/**
 * Copyright (C) 2017 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

if (!defined('AURA'))
{
	define('AURA_ROOT', __DIR__.'/../');
	require AURA_ROOT.'include/common.php';
}
require AURA_ROOT.'include/common_admin.php';

if (!$aura_user['is_admin'])
	message($lang->t('No permission'), false, '403 Forbidden');

if ($aura_user['id'] != '2')
{
	if (!is_null($restrictions[$aura_user['id']]['admin_permissions']))
	{
		if ($restrictions[$aura_user['id']]['admin_permissions'] == '0')
			message($lang->t('No permission'), false, '403 Forbidden');
	}
}

check_authentication();

// Load the admin-permissions language file
$lang->load('admin_permissions');

if (isset($_POST['form_sent']))
{
	confirm_referrer(AURA_ADMIN_DIR.'/permissions.php');
	$form = isset($_POST['form']) && is_array($_POST['form']) ? array_map('intval', $_POST['form']) : array();
	foreach ($form as $key => $input)
	{
		// Make sure the input is never a negative value
		if($input < 0)
			$input = 0;

		// Only update values that have changed
		if (array_key_exists('p_'.$key, $aura_config) && $aura_config['p_'.$key] != $input)
		{
			$update = array(
				'conf_value' => $input,
			);
			
			$data = array(
				':conf_name' => 'p_'.$key,
			);
			
			$db->update('config', $update, 'conf_name=:conf_name', $data);
		}
	}

	// Regenerate the config cache
	$cache->generate('config', array($aura_config));
	redirect(aura_link($aura_url['admin_permissions']), $lang->t('Perms updated redirect'));
}

$page_title = array($aura_config['o_board_title'], $lang->t('Admin'), $lang->t('Permissions'));
define('AURA_ACTIVE_PAGE', 'admin');
require AURA_ROOT.'header.php';

generate_admin_menu('permissions');

$tpl = load_template('admin_permissions.tpl');
echo $tpl->render(
	array(
		'lang' => $lang,
		'aura_config' => $aura_config,
		'form_action' => aura_link($aura_url['admin_permissions']),
		'csrf_token' => generate_csrf_token(AURA_ADMIN_DIR.'/permissions.php'),
	)
);

require AURA_ROOT.'footer.php';