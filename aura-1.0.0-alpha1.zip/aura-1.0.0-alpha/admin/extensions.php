<?php
/**
 * Copyright (C) 2017 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

if (!defined('AURA'))
{
	define('AURA_ROOT', __DIR__.'/../');
	require AURA_ROOT.'include/common.php';
}

require AURA_ROOT.'include/common_admin.php';

if (!$aura_user['is_admin'])
	message($lang->t('No permission'), false, '403 Forbidden');

// Load the admin-extensions language file
$lang->load('admin_extensions');

check_authentication();

if ($aura_user['id'] != '2')
{
	if (!is_null($restrictions[$aura_user['id']]['admin_extensions']))
	{
		if ($restrictions[$aura_user['id']]['admin_extensions'] == '0')
			message($lang->t('No permission'));
	}
}

$errors = array();
$action = isset($_GET['action']) ? utf8_trim($_GET['action']) : '';

if ($action == 'install')
{
	$file = isset($_GET['file']) ? utf8_trim($_GET['file']) : '';
	if (!file_exists(AURA_EXTENSIONS_DIR.$file.'.xml'))
		message($lang->t('Bad request'));

	$data = array(
		':id' => $file,
	);

	$ps = $db->select('extensions', 1, $data, 'id=:id');
	if ($ps->rowCount())
		message($lang->t('Extension already installed'));

	$content = file_get_contents(AURA_EXTENSIONS_DIR.$file.'.xml');
	$extension = xml_to_array($content);

	list ($extension, $errors) = validate_extension($extension, $errors);

	if (isset($_POST['form_sent']) && empty($errors))
	{
		confirm_referrer(AURA_ADMIN_DIR.'/extensions.php');

		// Insert all the hooks
		foreach ($extension['hooks']['hook'] as $hook)
		{
			$insert = array(
				'extension_id' => $file,
				'hook' => $hook['attributes']['id'],
				'code' => aura_trim($hook['content']),
			);

			$db->insert('extension_code', $insert);
		}

		// Are we installing templates
		if (isset($extension['plugin_folder']))
		{
			if (!is_dir(AURA_ROOT.'include/extensions'))
				@mkdir(AURA_ROOT.'include/extensions', 0755);

			@mkdir(AURA_ROOT.'include/extensions/'.$extension['plugin_folder'], 0755);
		}

		$files = array();

		// Install templates if they exist
		if (isset($extension['install']['templates']))
		{
			@mkdir(AURA_ROOT.'include/extensions/'.$extension['plugin_folder'].'/templates', 0755);
			foreach ($extension['install']['templates']['template'] as $template)
			{
				$fh = @fopen(AURA_ROOT.'include/extensions/'.$extension['plugin_folder'].'/templates/'.$template['attributes']['id'], 'wb');
				if ($fh)
				{
					fwrite($fh, utf8_trim($template['content']));
					fclose($fh);

					@chmod(AURA_ROOT.'include/extensions/'.$extension['plugin_folder'].'/templates/'.$template['attributes']['id'], 0644);
					$files[] = array('type' => 'template', 'file' => $template['attributes']['id']);
				}
			}
		}

		// Install languages if they exist
		if (isset($extension['install']['languages']))
		{
			@mkdir(AURA_ROOT.'include/extensions/'.$extension['plugin_folder'].'/languages', 0755);
			foreach ($extension['install']['languages']['language'] as $language)
			{
				// If this language ISO directory doesn't already exist, we create it
				if (!is_dir(AURA_ROOT.'include/extensions/'.$extension['plugin_folder'].'/languages/'.$language['attributes']['iso']))
					@mkdir(AURA_ROOT.'include/extensions/'.$extension['plugin_folder'].'/languages/'.$language['attributes']['iso']);

				$fh = @fopen(AURA_ROOT.'include/extensions/'.$extension['plugin_folder'].'/languages/'.$language['attributes']['iso'].'/'.$language['attributes']['id'], 'wb');
				if ($fh)
				{
					fwrite($fh, utf8_trim($language['content']));
					fclose($fh);

					@chmod(AURA_ROOT.'include/extensions/'.$extension['plugin_folder'].'/languages/'.$language['attributes']['iso'].'/'.$language['attributes']['id'], 0644);
					$files[] = array('type' => 'language', 'file' => $language['attributes']['id'], 'iso' => $language['attributes']['iso']);
				}
			}
		}

		// Install files if they exist
		if (isset($extension['install']['files']))
		{
			@mkdir(AURA_ROOT.'include/extensions/'.$extension['plugin_folder'].'/include', 0755);
			foreach ($extension['install']['files']['file'] as $file)
			{
				$fh = @fopen(AURA_ROOT.'include/extensions/'.$extension['plugin_folder'].'/include/'.$file['attributes']['name'], 'wb');
				if ($fh)
				{
					fwrite($fh, utf8_trim($file['content']));
					fclose($fh);

					@chmod(AURA_ROOT.'include/extensions/'.$extension['plugin_folder'].'/include/'.$file['attributes']['name'], 0644);
					$files[] = array('type' => 'dependency', 'file' => $file['attributes']['name']);
				}
			}
		}

		// Install plugins if they exist
		if (isset($extension['install']['plugins']))
		{
			foreach ($extension['install']['plugins']['plugin'] as $plugin)
			{
				$fh = @fopen(AURA_PLUGINS_DIR.$plugin['attributes']['id'], 'wb');
				if ($fh)
				{
					fwrite($fh, utf8_trim($plugin['content']));
					fclose($fh);

					@chmod(AURA_PLUGINS_DIR.$plugin['attributes']['id'], 0644);
					$files[] = array('type' => 'plugin', 'file' => $plugin['attributes']['id']);
				}
			}
		}

		$uninstall = array(
			'code' => (isset($extension['uninstall']['execute']) ? utf8_trim($extension['uninstall']['execute']) : ''),
			'plugin_folder' => $extension['plugin_folder'],
			'files' => $files,
		);

		$insert = array(
			'id' => $file,
			'title' => $extension['title'],
			'version' => $extension['version'],
			'description' => $extension['description'],
			'author' => $extension['author'],
			'uninstall_note' => (isset($extension['uninstall']['note']) ? utf8_trim($extension['uninstall']['note']) : ''),
			'uninstall' => serialize($uninstall),
			'enabled' => isset($_POST['enable']) ? 1 : 0,
		);

		$db->insert('extensions', $insert);
		$extension_id = $db->lastInsertId($db->prefix.'extensions');

		if (isset($extension['install']['execute']))
			eval($extension['install']['execute']);

		$cache->generate('extensions');
		redirect(aura_link($aura_url['admin_extensions']), $lang->t('Extension installed redirect'));
	}

	$warnings = array();
	$versions = explode(',', $extension['supported_versions']);
	if (!in_array($aura_config['o_cur_version'], $versions))
		$warnings[] = $lang->t('Version warning', $aura_config['o_cur_version'], $extension['supported_versions']);

	$id = sha1($content); // Make sure this extension is 'aura approved'
	$content = @file_get_contents('https://www.get-aura.org/resources/extensions/check/'.$id);
	if (!$content || !aura_hash_equals($content, $id))
		$warnings[] = $lang->t('Extension not approved warning');

	$page_title = array($aura_config['o_board_title'], $lang->t('Admin'), $lang->t('Extensions'));
	define('AURA_ACTIVE_PAGE', 'admin');
	require AURA_ROOT.'header.php';
	generate_admin_menu('extensions');

	$tpl = load_template('install_extension.tpl');
	echo $tpl->render(
		array(
			'lang' => $lang,
			'form_action' => aura_link($aura_url['install_extension'],  array($file)),
			'csrf_token' => generate_csrf_token(AURA_ADMIN_DIR.'/extensions.php'),
			'extension' => $extension,
			'warnings' => $warnings,
			'errors' => $errors,
		)
	);
}
else if ($action == 'uninstall')
{
	$file = isset($_GET['file']) ? utf8_trim($_GET['file']) : '';
	if (!file_exists(AURA_EXTENSIONS_DIR.$file.'.xml'))
		message($lang->t('Bad request'));

	$data = array(
		':id' => $file,
	);

	$ps = $db->select('extensions', 'uninstall, uninstall_note', $data, 'id=:id');
	if (!$ps->rowCount())
		message($lang->t('Extension not installed'));

	$extension = $ps->fetch();

	if (isset($_POST['form_sent']))
	{
		confirm_referrer(AURA_ADMIN_DIR.'/extensions.php');
		$data = array(
			'id' => $file,
		);

		$db->delete('extensions', 'id=:id', $data);
		$db->delete('extension_code', 'extension_id=:id', $data);

		$uninstall = unserialize($extension['uninstall']);
		if (!empty($uninstall['files']))
		{
			foreach ($uninstall['files'] as $file)
			{
				if ($file['type'] == 'template')
					@unlink(AURA_ROOT.'include/extensions/'.$uninstall['plugin_folder'].'/templates/'.$file['file']);
				else if ($file['type'] == 'dependency')
					@unlink(AURA_ROOT.'include/extensions/'.$uninstall['plugin_folder'].'/include/'.$file['file']);
				else if ($file['type'] == 'language')
				{
					@unlink(AURA_ROOT.'include/extensions/'.$uninstall['plugin_folder'].'/languages/'.$file['iso'].'/'.$file['file']);

					// Check if there are any more files within this language ISO folder
					$files = array_diff(scandir(AURA_ROOT.'include/extensions/'.$uninstall['plugin_folder'].'/languages/'.$file['iso']), array('.', '..'));
					if (empty($files))
						@rmdir(AURA_ROOT.'include/extensions/'.$uninstall['plugin_folder'].'/languages/'.$file['iso']);
				}
				else
					@unlink(AURA_PLUGINS_DIR.$file['file']);
			}

			@rmdir(AURA_ROOT.'include/extensions/'.$uninstall['plugin_folder'].'/templates');
			@rmdir(AURA_ROOT.'include/extensions/'.$uninstall['plugin_folder'].'/languages');
			@rmdir(AURA_ROOT.'include/extensions/'.$uninstall['plugin_folder'].'/include');
			@rmdir(AURA_ROOT.'include/extensions/'.$uninstall['plugin_folder']);

			// We also want to check if there are no other extension folders which exist on the server
			$files = array_diff(scandir(AURA_ROOT.'include/extensions'), array('.', '..'));
			if (empty($files))
				@rmdir(AURA_ROOT.'include/extensions');
		}

		eval($uninstall['code']);

		$cache->generate('extensions');
		redirect(aura_link($aura_url['admin_extensions']), $lang->t('Extension uninstalled redirect'));
	}

	$page_title = array($aura_config['o_board_title'], $lang->t('Admin'), $lang->t('Extensions'));
	define('AURA_ACTIVE_PAGE', 'admin');
	require AURA_ROOT.'header.php';
	generate_admin_menu('extensions');

	$tpl = load_template('uninstall_extension.tpl');
	echo $tpl->render(
		array(
			'extension' => $extension,
			'lang' => $lang,
			'form_action' => aura_link($aura_url['uninstall_extension'],  array($file)),
			'csrf_token' => generate_csrf_token(AURA_ADMIN_DIR.'/extensions.php'),
		)
	);
}
else if ($action == 'enable' || $action == 'disable')
{
	$file = isset($_GET['file']) ? utf8_trim($_GET['file']) : '';
	$data = array(
		':id' => $file,
	);

	$ps = $db->select('extensions', 1, $data, 'id=:id');
	if (!$ps->rowCount())
		message($lang->t('Bad request'));

	$update = array(
		'enabled' => ($action == 'enable') ? 1 : 0,
	);

	$db->update('extensions', $update, 'id=:id', $data);
	
	$cache->generate('extensions');
	redirect(aura_link($aura_url['admin_extensions']), ($action == 'enable' ? $lang->t('Extension enabled redirect') : $lang->t('Extension disabled redirect')));
}
else
{
	// Upload a new extension
	if (isset($_POST['upload']))
	{
		confirm_referrer(AURA_ADMIN_DIR.'/extensions.php');
		if (!isset($_FILES['req_file']))
			message($lang->t('No file'));

		$uploaded_file = $_FILES['req_file'];

		// Make sure the upload went smooth
		if (isset($uploaded_file['error']))
		{
			switch ($uploaded_file['error'])
			{
				case 1:	// UPLOAD_ERR_INI_SIZE
				case 2:	// UPLOAD_ERR_FORM_SIZE
					message($lang->t('Too large ini'));
				break;
				case 3:	// UPLOAD_ERR_PARTIAL
					message($lang->t('Partial upload'));
				break;
				case 4:	// UPLOAD_ERR_NO_FILE
					message($lang->t('No file'));
				break;
				case 6:	// UPLOAD_ERR_NO_TMP_DIR
					message($lang->t('No tmp directory'));
				break;
				default:
					// No error occured, but was something actually uploaded?
					if ($uploaded_file['size'] == 0)
						message($lang->t('No file'));
				break;
			}
		}

		$filename = $uploaded_file['name'];
		if (!is_uploaded_file($uploaded_file['tmp_name']))
			$errors[] = $lang->t('Unknown failure');
		else if (!preg_match('/^[a-z0-9-]+\.xml$/i', $uploaded_file['name']))
			$errors[] = $lang->t('Bad type');
		else if (file_exists(AURA_EXTENSIONS_DIR.$filename)) // Make sure there is no file already under this name
			$errors[] = $lang->t('Extension exists', $filename);
		else if (!@move_uploaded_file($uploaded_file['tmp_name'], AURA_EXTENSIONS_DIR.$filename)) // Move the file to the extensions directory.
		{
			$errors[] = $lang->t('Move failed');
			@unlink(AURA_EXTENSIONS_DIR.$filename);
		}

		if (empty($errors))
		{
			@chmod(AURA_EXTENSIONS_DIR.$filename, 0644);		
			redirect(aura_link($aura_url['admin_extensions']), $lang->t('Extension uploaded redirect'));
		}
	}

	$extensions = array();
	$ps = $db->select('extensions', 'id, title, enabled');
	foreach ($ps as $cur_extension)
		$extensions[$cur_extension['id']] = $cur_extension;

	$result = array();
	$xml_files = array_diff(scandir(AURA_EXTENSIONS_DIR), array('.', '..', '.htaccess'));
	foreach ($xml_files as $entry)
	{
		if (substr($entry, -4) == '.xml')
		{
			if (isset($extensions[substr($entry, 0, -4)])) // Then this is installed already
			{
				$extension = $extensions[substr($entry, 0, -4)];
				$result[] = array(
					'title' => $extension['title'],
					'status' => $extension['enabled'],
					'installed' => true,
					'status_link' => ($extension['enabled']) ? aura_link($aura_url['disable_extension'],  array($extension['id'])) : aura_link($aura_url['enable_extension'],  array($extension['id'])),
					'uninstall_link' => aura_link($aura_url['uninstall_extension'], array($extension['id'])),
				);
			}
			else
			{
				$result[] = array(
					'title' => str_replace('-', ' ', substr($entry, 0, -4)),
					'status' => -1,
					'installed' => false,
					'install_link' => aura_link($aura_url['install_extension'], array(substr($entry, 0, -4))),
				);
			}
		}
	}

	$page_title = array($aura_config['o_board_title'], $lang->t('Admin'), $lang->t('Extensions'));
	define('AURA_ACTIVE_PAGE', 'admin');
	require AURA_ROOT.'header.php';
	generate_admin_menu('extensions');

	$tpl = load_template('admin_extensions.tpl');
	echo $tpl->render(
		array(
			'lang' => $lang,
			'errors' => $errors,
			'extensions' => $result,
			'form_action' => aura_link($aura_url['admin_extensions']),
			'csrf_token' => generate_csrf_token(AURA_ADMIN_DIR.'/extensions.php'),
		)
	);
}

require AURA_ROOT.'footer.php';