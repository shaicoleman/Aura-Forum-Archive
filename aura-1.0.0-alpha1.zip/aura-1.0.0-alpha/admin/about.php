<?php
/**
 * Copyright (C) 2017 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

define('ADMIN_INDEX', 1);

if (!defined('AURA'))
{
	define('AURA_ROOT', __DIR__.'/../');
	require AURA_ROOT.'include/common.php';
}

require AURA_ROOT.'include/common_admin.php';

if (($aura_user['is_admmod'] && $aura_user['g_mod_cp'] == '0' && !$aura_user['is_admin']) || !$aura_user['is_admmod'])
	message($lang->t('No permission'), false, '403 Forbidden');

check_authentication();

// Load the admin_about language file
$lang->load('admin_about');

$page_title = array($aura_config['o_board_title'], $lang->t('Admin'), $lang->t('About'));
define('AURA_ACTIVE_PAGE', 'admin');
require AURA_ROOT.'header.php';

generate_admin_menu('about');

$tpl = load_template('admin_about.tpl');
echo $tpl->render(
	array(
		'lang' => $lang,
		'aura_config' => $aura_config,
	)
);

require AURA_ROOT.'footer.php';