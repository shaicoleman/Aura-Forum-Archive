<?php
/**
 * Copyright (C) 2017 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

// Make sure no one attempts to run this script "directly"
if (!defined('AURA'))
	exit;

$controls = $links = array();
if (isset($footer_style) && ($footer_style == 'viewforum' || $footer_style == 'viewtopic') && $is_admmod)
{
	if ($footer_style == 'viewforum')
		$controls[] = array('link' => aura_link($aura_url['moderate_forum_p'], array($forum_id, $p)), 'lang' => $lang->t('Moderate forum'));
	else if ($footer_style == 'viewtopic')
	{
		if ($cur_topic['archived'] != '1')
		{
			$controls[] = array('link' => aura_link($aura_url['moderate_topic_p'], array($forum_id, $id, $p)), 'lang' => $lang->t('Moderate topic'), 'num_pages' => $num_pages, 'moderate_all' => aura_link($aura_url['moderate_all'], array($forum_id, $id)), 'all' => $lang->t('All'));
			$controls[] = array('link' => aura_link($aura_url['move'], array($forum_id, $id, $csrf_token)), 'lang' => $lang->t('Move topic'));

			if ($cur_topic['closed'] == '1')
				$controls[] = array('link' => aura_link($aura_url['open'], array($forum_id, $id, $csrf_token)), 'lang' => $lang->t('Open topic'));
			else
				$controls[] = array('link' => aura_link($aura_url['close'], array($forum_id, $id, $csrf_token)), 'lang' => $lang->t('Close topic'));

			if ($cur_topic['sticky'] == '1')
				$controls[] = array('link' => aura_link($aura_url['unstick'], array($forum_id, $id, $csrf_token)), 'lang' => $lang->t('Unstick topic'));
			else
				$controls[] = array('link' => aura_link($aura_url['stick'], array($forum_id, $id, $csrf_token)), 'lang' => $lang->t('Stick topic'));

			$controls[] = array('link' => aura_link($aura_url['archive'], array($forum_id, $id, $csrf_token)), 'lang' => $lang->t('Archive topic'));
			$controls[] = array('link' => aura_link($aura_url['moderate_multi'], array($forum_id, $id, $csrf_token)), 'lang' => $lang->t('More moderation actions'));
		}
		else if ($aura_user['is_admin'])
			$controls[] = array('link' => aura_link($aura_url['unarchive'], array($forum_id, $id, $csrf_token)), 'lang' => $lang->t('Unarchive topic'));
	}

	($hook = get_extensions('footer_moderator_controls')) ? eval($hook) : null;
}

// Display the "Jump to" drop list
if ($aura_config['o_quickjump'] == '1')
{
	ob_start();
	// Load cached quick jump
	$cache->get('quickjump', array($aura_user['g_id']), true, true);
	require $cache->cache_dir.'/templates/'.$aura_user['style'].'/cache_quickjump_'.$aura_user['g_id'].'.php';

	$quickjump_tpl = trim(ob_get_contents());
	ob_end_clean();
}
else
	$quickjump_tpl = '';

$feed = array();
if (isset($footer_style) && $footer_style == 'warnings')
{
	$links[] = array('url' => aura_link($aura_url['warnings']), 'lang' => $lang->t('Show warning types'));
	
	if ($aura_user['is_admmod'])
		$links[] = array('url' => aura_link($aura_url['warnings_recent']), 'lang' => $lang->t('Show recent warnings'));
	
	($hook = get_extensions('footer_warnings')) ? eval($hook) : null;
}
elseif (isset($footer_style) && ($footer_style == 'index' || $footer_style == 'viewforum' || $footer_style == 'viewtopic') && ($aura_config['o_feed_type'] == '1' || $aura_config['o_feed_type'] == '2'))
{
	switch ($footer_style)
	{
		case 'index':
			if ($aura_config['o_feed_type'] == '1')
			{
				$feed = array(
					'type' => 'rss',
					'link' => aura_link($aura_url['index_rss']),
					'lang' => $lang->t('RSS active topics feed'),
				);
			}
			else if ($aura_config['o_feed_type'] == '2')
			{
				$feed = array(
					'type' => 'atom',
					'link' => aura_link($aura_url['index_atom']),
					'lang' => $lang->t('Atom active topics feed'),
				);
			}
		break;
		case 'viewforum':
			if ($aura_config['o_feed_type'] == '1')
			{
				$feed = array(
					'type' => 'rss',
					'link' => aura_link($aura_url['forum_rss'], array($id)),
					'lang' => $lang->t('RSS forum feed'),
				);
			}
			else if ($aura_config['o_feed_type'] == '2')
			{
				$feed = array(
					'type' => 'atom',
					'link' => aura_link($aura_url['forum_atom'], array($id)),
					'lang' => $lang->t('Atom forum feed'),
				);
			}			
		break;
		case 'viewtopic':
			if ($aura_config['o_feed_type'] == '1')
			{
				$feed = array(
					'type' => 'rss',
					'link' => aura_link($aura_url['topic_rss'], array($id)),
					'lang' => $lang->t('RSS topic feed'),
				);
			}
			else if ($aura_config['o_feed_type'] == '2')
			{
				$feed = array(
					'type' => 'atom',
					'link' => aura_link($aura_url['topic_atom'], array($id)),
					'lang' => $lang->t('Atom topic feed'),
				);
			}			
		break;
	}

	($hook = get_extensions('footer_feeds')) ? eval($hook) : null;
}

// Display debug info (if enabled/defined)
if ($aura_config['o_debug_mode'] == '1')
{
	// Calculate script generation time
	$time_diff = sprintf('%.3f', microtime(true) - $aura_start);
	$debug_info = $lang->t('Querytime', $time_diff, $db->get_num_queries());

	if (function_exists('memory_get_usage'))
	{
		$debug_info .= ' - '.$lang->t('Memory usage', file_size(memory_get_usage()));

		if (function_exists('memory_get_peak_usage'))
			$debug_info .= ' '.$lang->t('Peak usage', file_size(memory_get_peak_usage()));
	}
}
else
	$debug_info = '';

$queries = ($aura_config['o_show_queries'] == '1') ? display_saved_queries() : '';

// End the transaction
$db->end_transaction();

$style_path = (($aura_config['o_style_path'] != 'styles') ? $aura_config['o_style_path'] : AURA_ROOT.$aura_config['o_style_path']).'/'.$aura_user['style'].'/templates/';
$tpl = (defined('AURA_ADMIN_CONSOLE') && (file_exists($style_path.'admin_footer.tpl') || $aura_user['style'] == $aura_config['o_default_style'] && !file_exists($style_path)) ? 'admin_footer.tpl' : 'footer.tpl');
$tpl = load_template($tpl);
echo $tpl->render(
	array(
		'footer_style' => isset($footer_style) ? $footer_style : '',
		'controls' => $controls,
		'quickjump' => $quickjump_tpl,
		'lang' => $lang,
		'links' => $links,
		'aura_config' => $aura_config,
		'feed' => $feed,
		'debug_info' => $debug_info,
		'queries' => $queries,
	)
);

ob_flush();
exit;