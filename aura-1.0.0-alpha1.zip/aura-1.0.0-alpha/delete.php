<?php
/**
 * Copyright (C) 2017 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

if (!defined('AURA'))
{
	define('AURA_ROOT', __DIR__.'/');
	require AURA_ROOT.'include/common.php';
}

if ($aura_user['g_read_board'] == '0')
	message($lang->t('No view'), false, '403 Forbidden');

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($id < 1)
	message($lang->t('Bad request'), false, '404 Not Found');

if ($aura_user['is_bot'])
	message($lang->t('No permission'));

// Fetch some info about the post, the topic and the forum
$data = array(
	':gid' => $aura_user['g_id'],
	':id' => $id,
);

$join = array(
	array(
		'type' => 'INNER',
		'table' => 'topics',
		'as' => 't',
		'on' => 't.id=p.topic_id',
	),
	array(
		'type' => 'INNER',
		'table' => 'forums',
		'as' => 'f',
		'on' => 'f.id=t.forum_id',
	),
	array(
		'type' => 'LEFT',
		'table' => 'forum_perms',
		'as' => 'fp',
		'on' => '(fp.forum_id=f.id AND fp.group_id=:gid)',
	),
);

$ps = $db->join('posts', 'p', $join, 'f.id AS fid, f.forum_name, f.password, f.redirect_url, fp.post_replies, fp.post_topics, t.id AS tid, t.subject, t.archived, t.first_post_id, t.closed, p.posted, p.poster, p.poster_id, p.poster_ip, p.message, p.hide_smilies, p.poster_email', $data, '(fp.read_forum IS NULL OR fp.read_forum=1) AND p.id=:id AND p.approved=1 AND p.deleted=0');
if (!$ps->rowCount())
	message($lang->t('Bad request'), false, '404 Not Found');

$cur_post = $ps->fetch();

if ($aura_config['o_censoring'] == '1')
	$cur_post['subject'] = censor_words($cur_post['subject']);

// Sort out who the moderators are and if we are currently a moderator (or an admin)
$moderators = $cache->get('moderators');
$is_admmod = ($aura_user['is_admin'] || ($aura_user['g_moderator'] == '1' && $aura_user['g_global_moderator'] == '1' || isset($moderators[$cur_post['fid']]['u'.$aura_user['id']]) || isset($moderators[$cur_post['fid']]['g'.$aura_user['g_id']]))) ? true : false;

$is_topic_post = ($id == $cur_post['first_post_id']) ? true : false;

// Do we have permission to edit this post?
if (($aura_user['g_delete_posts'] == '0' || ($aura_user['g_delete_topics'] == '0' && $is_topic_post) || $cur_post['poster_id'] != $aura_user['id'] || $cur_post['closed'] == '1' || $aura_user['g_deledit_interval'] != 0 && (CURRENT_TIMESTAMP - $cur_post['posted']) > $aura_user['g_deledit_interval']) && !$is_admmod)
	message($lang->t('No permission'), false, '403 Forbidden');

if ($is_admmod && (!$aura_user['is_admin'] && (in_array($cur_post['poster_id'], $cache->get('admins')) && $aura_user['g_mod_edit_admin_posts'] == '0')))
	message($lang->t('No permission'), false, '403 Forbidden');

// Load the delete language file
$lang->load('delete');

if ($cur_post['password'] != '')
	check_forum_login_cookie($cur_post['fid'], $cur_post['password']);

check_posting_ban();

if ($cur_post['archived'] == '1')
	message($lang->t('Topic archived'));

if (isset($_POST['delete']))
{
	// Make sure they got here from the site
	confirm_referrer('delete.php');

	require AURA_ROOT.'include/search_idx.php';
	if ($aura_user['is_admmod'] && ($aura_user['g_mod_sfs_report'] == '1' || $aura_user['is_admin']))
	{
		$sfs_report = isset($_POST['sfs_report']) ? intval($_POST['sfs_report']) : '0';
		if ($sfs_report == '1' && $aura_config['o_sfs_api'] != '')
		{
			//If the user wasn't a guest we need to get the email from the users table
			if ($cur_post['poster_email'] == '' && $cur_post['poster_id'] != 1)
			{
				$data = array(
					':id'	=>	$cur_post['poster_id'],
				);

				$ps = $db->select('users', 'email', $data, 'id=:id');
				$email= $ps->fetchColumn();
			}
			else
				$email = $cur_post['poster_email'];

			//Reporting now made fun =)
			if (!stopforumspam_report($aura_config['o_sfs_api'], $cur_post['poster_ip'], $email, $cur_post['poster'], $cur_post['message']))
				message($lang->t('Unable to add spam data'));
		}
	}

	if ($is_topic_post)
	{
		// Delete the topic and all of its posts
		delete_topic($cur_post['tid']);
		update_forum($cur_post['fid']);
		
		($hook = get_extensions('delete_after_delete')) ? eval($hook) : null;
		redirect(aura_link($aura_url['forum'], array($cur_post['fid'], url_friendly($cur_post['forum_name']))), $lang->t('Topic del redirect'));
	}
	else
	{
		// Delete just this one post
		delete_post($id, $cur_post['tid']);
		update_forum($cur_post['fid']);

		// Redirect towards the previous post
		$data = array(
			':tid'	=>	$cur_post['tid'],
			':id'	=>	$id,
		);

		$ps = $db->select('posts', 'id', $data, 'topic_id=:tid AND id < :id AND approved=1 AND deleted=0', 'id DESC LIMIT 1');
		$post_id = $ps->fetchColumn();
		
		($hook = get_extensions('delete_after_delete')) ? eval($hook) : null;
		redirect(aura_link($aura_url['post'], array($post_id)), $lang->t('Post del redirect'));
	}
}

$parser = new parser($aura_config, $aura_user, $lang, $db, $cache);

$page_title = array($aura_config['o_board_title'], $lang->t('Delete post'));
define ('AURA_ACTIVE_PAGE', 'index');
require AURA_ROOT.'header.php';

$tpl = load_template('delete.tpl');
echo $tpl->render(
	array(
		'lang' => $lang,
		'index_link' => aura_link($aura_url['index']),
		'forum_link' => aura_link($aura_url['forum'], array($cur_post['fid'], url_friendly($cur_post['forum_name']))),
		'post_link' => aura_link($aura_url['post'], array($id)),
		'cur_post' => $cur_post,
		'form_action' => aura_link($aura_url['delete'], array($id)),
		'csrf_token' => generate_csrf_token(),
		'is_topic_post' => $is_topic_post,
		'posted' => format_time($cur_post['posted']),
		'is_admmod' => $is_admmod,
		'aura_config' => $aura_config,
		'message' => $parser->parse_message($cur_post['message'], $cur_post['hide_smilies']),
	)
);

require AURA_ROOT.'footer.php';