<?php
/**
 * Copyright (C) 2017 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

if (!defined('AURA'))
{
	define('AURA_ROOT', __DIR__.'/');
	require AURA_ROOT.'include/common.php';
}

if ($aura_user['is_bot'])
	message($lang->t('No permission'));

if ($aura_user['g_read_board'] == '0')
	message($lang->t('No view'), false, '403 Forbidden');
else if ($aura_user['g_view_users'] == '0')
	message($lang->t('No permission'), false, '403 Forbidden');

// Load language files
$lang->load('userlist');
$lang->load('search');
$lang->load('online');

// Determine if we are allowed to view post counts
$show_post_count = ($aura_config['o_show_post_count'] == '1' || $aura_user['is_admmod']) ? true : false;

$username = isset($_GET['username']) && $aura_user['g_search_users'] == '1' ? aura_trim($_GET['username']) : '';
$show_group = isset($_GET['show_group']) ? intval($_GET['show_group']) : -1;
$sort_by = isset($_GET['sort_by']) && (in_array($_GET['sort_by'], array('username', 'registered')) || ($_GET['sort_by'] == 'num_posts' && $show_post_count)) ? $_GET['sort_by'] : 'username';
$sort_dir = isset($_GET['sort_dir']) && $_GET['sort_dir'] == 'DESC' ? 'DESC' : 'ASC';

// Create any applicable SQL generated from the GET array
$data = array(
	':unverified' => AURA_UNVERIFIED,
);

$fields = array();
$sql = 'SELECT COUNT(id) FROM '.$db->prefix.'users AS u WHERE u.id > 1 AND u.group_id != :unverified';
$sql1 = 'SELECT u.id, u.username, u.title, u.num_posts, u.registered, u.email, u.use_gravatar, u.group_id AS g_id, g.g_user_title, o.user_id AS is_online FROM '.$db->prefix.'users AS u LEFT JOIN '.$db->prefix.'groups AS g ON g.g_id=u.group_id LEFT JOIN '.$db->prefix.'online AS o ON (o.user_id=u.id AND o.user_id!=1) WHERE u.id>1 AND u.group_id!=:unverified';

if ($username != '')
{
	$fields['username'] = ' AND u.username LIKE :username';
	$data[':username'] = str_replace('*', '%', $username);
}

if ($show_group > -1)
{
	$fields['gid'] = ' AND u.group_id = :gid';
	$data[':gid'] = $show_group;
}

foreach($fields as $field => $where_cond)
{
	$sql .= $where_cond;
	$sql1 .= $where_cond;
}

// Fetch user count
$ps = $db->run($sql, $data);
$num_users = $ps->fetchColumn();

// Determine the user offset (based on $_GET['p'])
$num_pages = ceil($num_users / 50);

$p = (!isset($_GET['p']) || $_GET['p'] <= 1 || $_GET['p'] > $num_pages) ? 1 : intval($_GET['p']);
$start_from = 50 * ($p - 1);

$data[':start'] = $start_from;
$sql1 .= " ORDER BY ".$sort_by." ".$sort_dir.", u.id ASC LIMIT :start, 50";

$page_title = array($aura_config['o_board_title'], $lang->t('User list'));
if ($aura_user['g_search_users'] == '1')
	$focus_element = array('userlist', 'username');

($hook = get_extensions('userlist_before_header')) ? eval($hook) : null;

define('AURA_ALLOW_INDEX', 1);
define('AURA_ACTIVE_PAGE', 'userlist');
require AURA_ROOT.'header.php';

$users = array();
$ps = $db->run($sql1, $data);
if ($ps->rowCount())
{
	foreach ($ps as $user_data)
	{
		$users[] = array(
			'avatar' => generate_avatar_markup($user_data['id'], $user_data['email'], $user_data['use_gravatar'], array(32, 32)),
			'is_online' => ($user_data['is_online'] == $user_data['id']) ? true : false,
			'username' => colourise_group($user_data['username'], $user_data['g_id'], $user_data['id']),
			'title' => get_title($user_data),
			'num_posts' => forum_number_format($user_data['num_posts']),
			'registered' => format_time($user_data['registered'], true),
		);
	}
}

$aura_groups = $cache->get('groups');
$tpl = load_template('userlist.tpl');
echo $tpl->render(
	array(
		'lang' => $lang,
		'aura_groups' => $aura_groups,
		'show_post_count' => $show_post_count,
		'userlist_link' => aura_link($aura_url['userlist']),
		'aura_user' => $aura_user,
		'username' => $username,
		'show_group' => $show_group,
		'sort_by' => $sort_by,
		'sort_dir' => $sort_dir,
		'pagination' => paginate($num_pages, $p, $aura_url['userlist_result'], array(urlencode($username), $show_group, $sort_by, $sort_dir)),
		'users' => $users,
		'aura_config' => $aura_config,
	)
);

($hook = get_extensions('userlist_after_output')) ? eval($hook) : null;

require AURA_ROOT.'footer.php';