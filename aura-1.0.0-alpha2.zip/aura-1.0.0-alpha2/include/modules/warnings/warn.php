<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class warn_controller extends base_controller
{
	/**
	 * Main app entry point, we load the form and attempt to warn the user
	 */
	public function execute()
	{
		if ($this->config['o_warnings'] == '0')
			$this->registry->get('\handlers\message')->show($this->lang->t('Warning system disabled'));

		// Load the warnings/post language files
		$this->lang->load('warnings');
		$this->lang->load('post');

		$errors = array();
		if ($this->user['g_mod_warn_users'] == '0' && !$this->user['is_admin'])
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'));

		$user_id = isset($_GET['uid']) ? intval($_GET['uid']) : 0;
		$post_id = isset($_GET['pid']) ? intval($_GET['pid']) : 0;
		if ($user_id < 1)
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'));

		if ($post_id < 0)
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'));

		if ($user_id == $this->user['id'] || $user_id < 2 || (in_array($user_id, $this->cache->get('admins'))))
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'));

		// Check whether user has been warned already for this post (users can only receive one warning per post)
		if ($post_id)
		{
			$data = array(
				':id' => $post_id,
			);

			$ps = $this->db->select('warnings', 'id', $data, 'post_id=:id');
			if ($ps->rowCount())
			{
				$warning_id = $ps->fetchColumn();
				$warning_link = $this->registry->get('\links')->aura_link($this->rewrite->url['warning_details'], array($warning_id));

				$this->registry->get('\handlers\message')->show($this->lang->t('Already warned', '<a href="'.$warning_link.'">'.$warning_link.'</a>'));
			}
		}

		$cur_user = null;
		if (isset($_POST['form_sent']))
			$this->warn_user($user_id, $post_id);

		// Fetch the warning data and some history about the post to generate on the form
		list($num_active, $num_expired, $points_active, $points_expired, $pm_subject, $pm_message, $types) = $this->fetch_warning_data($user_id, $errors, $cur_user);

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Warning system')),
			'active_page' => 'index'
		);

		$this->template->footer = array(
			'footer_style' => 'warnings',
		);

		$tpl = $this->template->load('warn_user.tpl');
		$this->template->output($tpl,
			array(
				'errors' => $errors,
				'types' => $types,
				'form_action' => (!$post_id) ? $this->registry->get('\links')->aura_link($this->rewrite->url['warn_user'], array($user_id)) : $this->registry->get('\links')->aura_link($this->rewrite->url['warn_pid'], array($user_id, $post_id)),
				'username' => $this->functions->colourise_group($cur_user['username'], $cur_user['group_id'], $user_id),
				'num_active' => $num_active,
				'points_active' => $points_active,
				'num_expired' => $num_expired,
				'points_expired' => $points_expired,
				'csrf_token' => $this->registry->get('\auth\csrf')->generate('warnings'),
				'subject' => $pm_subject,
				'message' => $pm_message,
				'expiration_unit' => isset($expiration_unit) ? $expiration_unit : 'days',
				'warning_type' => isset($warning_type) ? $warning_type : -1,
				'warning_title' => isset($warning_title) ? $warning_title : '',
				'expiration_time' => isset($expiration_time) ? $expiration_time : 10,
				'warning_points' => isset($warning_points) ? $warning_points : '',
			)
		);
	}

	/**
	 * Fetch all warning data to generate in the post
	 */
	protected function fetch_warning_data($user_id, $errors, $cur_user)
	{
		list($pm_subject, $pm_message) = null;
		$data = array(
			':id' => $user_id,
		);

		$ps = $this->db->select('users', 'username, group_id', $data, 'id=:id');
		$cur_user = $ps->fetch();

		$data = array(
			':id' => $user_id,
			':time' => CURRENT_TIMESTAMP,
		);

		$ps = $this->db->select('warnings', 'COUNT(id)', $data, 'user_id=:id AND (date_expire>:time OR date_expire=0)');
		$num_active = $ps->fetchColumn();

		$ps = $this->db->select('warnings', 'COUNT(id)', $data, 'user_id=:id AND date_expire<=:time AND date_expire!=0');
		$num_expired = $ps->fetchColumn();

		$ps = $this->db->select('warnings', 'COALESCE(SUM(points), 0)', $data, 'user_id=:id AND (date_expire>:time OR date_expire=0)');
		$points_active = $ps->fetchColumn();

		$ps = $this->db->select('warnings', 'COALESCE(SUM(points), 0)', $data, 'user_id=:id AND date_expire<=:time AND date_expire!=0');
		$points_expired = $ps->fetchColumn();

		if ($this->config['o_private_messaging'] == '1' && empty($errors))
		{
			$info = array(
				'message' => array(
					'<username>' => '[user]'.$cur_user['username'].'[/user]',
					'<board_title>' => $this->config['o_board_title'],
				),
			);

			list($pm_subject, $pm_message) = array_values($this->registry->get('\email\parser')->parse_email('warning_pm', $this->user['language'], $info));
		}

		$types = array();
		$ps = $this->db->select('warning_types', 'id, title, points, expiration_time', array(), '', 'points');
		foreach ($ps as $cur_warning)
			$types[] = array('id' => $cur_warning['id'], 'title' => $cur_warning['title'], 'num_points' => $this->functions->forum_number_format($cur_warning['points']), 'expires' => $this->lang->t('Expires after period', $this->registry->get('\aura_time')->format_expiration_time($cur_warning['expiration_time'])));

		return array($num_active, $num_expired, $points_active, $points_expired, $pm_subject, $pm_message, $types);
	}

	/**
	 * Warn the user
	 */
	protected function warn_user($user_id, $post_id)
	{
		$this->registry->get('\auth\csrf')->confirm('warnings');
		$data = array(
			':id' => $user_id,
		);

		$ps = $this->db->select('users', 'username, pm_notify, email', $data, 'id=:id');
		if (!$ps->rowCount())
		$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'));

		list($username, $pm_notify, $email) = $ps->fetch(PDO::FETCH_NUM);
		if ($post_id)
		{
			$data = array(
				':uid'	=>	$user_id,
				':id'	=>	$post_id,
			);

			$ps = $this->db->select('posts', 'poster_id, message', $data, 'id=:id AND poster_id=:uid AND approved=1 AND deleted=0');
			if (!$ps->rowCount())
				$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'));

			list($poster_id, $message) = $ps->fetch(PDO::FETCH_NUM);
		}

		// Check warning type
		$warning_type = isset($_POST['warning_type']) ? intval($_POST['warning_type']) : -1;

		// Make sure this warning type exists (and grab some data while we're at it)
		if ($warning_type > 0)
		{
			$data = array(
				':id' => $warning_type,
			);

			$ps = $this->db->select('warning_types', 'title, points, expiration_time', $data, 'id=:id');
			if (!$ps->rowCount())
				$errors[] = $this->lang->t('No warning type');

			list ($warning_title, $warning_points, $expiration) = $ps->fetch(PDO::FETCH_NUM);
		}
		else // ... Otherwise it's a custom warning
		{
			if ($this->config['o_custom_warnings'] == '0')
				$errors[] = $this->lang->t('Custom warnings disabled');

			if ($warning_type != 0)
				$errors[] = $this->lang->t('No warning type');

			$warning_title = isset($_POST['custom_title']) ? utf8_trim($_POST['custom_title']) : '';
			if ($warning_title == '')
				$errors[] = $this->lang->t('No warning reason');
			else if (aura_strlen($warning_title) > 120)
				$errors[] = $this->lang->t('Too long warning reason');

			$warning_points = isset($_POST['custom_points']) ? intval($_POST['custom_points']) : 0;
			if ($warning_points < 0)
				$errors[] = $this->lang->t('No points');

			$expiration_time = isset($_POST['custom_expiration_time']) ? intval($_POST['custom_expiration_time']) : 0;
			$expiration_unit = isset($_POST['custom_expiration_unit']) ? utf8_trim($_POST['custom_expiration_unit']) : '';

			if ($expiration_time < 1 && $expiration_unit != 'never')
				$errors[] = $this->lang->t('No expiration time');

			$expiration = $this->registry->get('\aura_time')->get_expiration_time($expiration_time, $expiration_unit);
		}

		$admin_note = aura_linebreaks(utf8_trim($_POST['note_admin']));
		if (strlen($admin_note) > 65535)
			$errors[] = $this->lang->t('Too long admin note');

		if ($this->config['o_private_messaging'] == '1')
		{
			$link = '[url]'.$this->registry->get('\links')->aura_link($this->rewrite->url['warning_view'], array($user_id)).'[/url]';
			$pm_subject = isset($_POST['req_subject']) ? utf8_trim($_POST['req_subject']) : '';

			if ($this->config['o_censoring'] == '1')
				$censored_subject = utf8_trim($this->registry->get('\message\bbcode')->censor_words($pm_subject));

			if ($pm_subject == '')
				$errors[] = $this->lang->t('No subject');
			else if ($this->config['o_censoring'] == '1' && $censored_subject == '')
				$errors[] = $this->lang->t('No subject after censoring');
			else if (aura_strlen($pm_subject) > 70)
				$errors[] = $this->lang->t('Too long subject');

			$pm_message = aura_linebreaks(utf8_trim($_POST['req_message']));

			if ($pm_message == '')
				$errors[] = $this->lang->t('No message');
			else if (strlen($pm_message) > AURA_MAX_POSTSIZE)
				$errors[] = $this->lang->t('Too long message', $this->functions->forum_number_format(AURA_MAX_POSTSIZE));

			if ($this->config['p_message_bbcode'] == '1')
			{
				$parser = new parser($this->registry);
				$pm_message = $parser->preparse_bbcode($pm_message, $errors);
			}

			if (empty($errors))
			{
				if ($pm_message == '')
				$errors[] = $this->lang->t('No message');
				else if ($this->config['o_censoring'] == '1')
				{
					// Censor message to see if that causes problems
					$censored_message = utf8_trim($this->registry->get('\message\bbcode')->censor_words($pm_message));

					if ($censored_message == '')
						$errors[] = $this->lang->t('No message after censoring');
				}
			}

			$pm_subject = str_replace('<warning_type>', $warning_title, $pm_subject);
			$pm_subject = str_replace('<warnings_url>', $link, $pm_subject);
			$pm_message = str_replace('<warning_type>', $warning_title, $pm_message);
			$pm_message = str_replace('<warnings_url>', $link, $pm_message);

			$note_pm = 'Subject: '.$pm_subject."\n\n".'Message:'."\n\n".$pm_message;
		}
		else
			$note_pm = '';

		if (empty($errors))
		{
			$expiration = ($expiration != '0') ? (CURRENT_TIMESTAMP + $expiration) : 0;
			$insert = array(
				'user_id'	=>	$user_id,
				'type_id'	=>	$warning_type,
				'post_id'	=>	$post_id,
				'title'	=>	($warning_type == 0) ? $warning_title : '', // Check if this is a custom warning
				'points'	=>	$warning_points,
				'date_issued'	=>	CURRENT_TIMESTAMP,
				'date_expire'	=>	$expiration,
				'issued_by'	=>	$this->user['id'],
				'note_admin'	=>	$admin_note,
				'note_post'	=>	isset($message) ? $message : '',
				'note_pm'	=>	$note_pm,
			);

			$this->db->insert('warnings', $insert);

			// If private messaging system is enabled
			if ($this->config['o_private_messaging'] == '1')
			{
				$insert = array(
					'subject'	=>	$pm_subject,
					'poster'	=>	$this->user['username'],
					'poster_id'	=>	$this->user['id'],
					'num_replies'	=>	0,
					'last_post'	=>	CURRENT_TIMESTAMP,
					'last_poster'	=>	$this->user['username'],
				);

				$this->db->insert('conversations', $insert);
				$new_tid = $this->db->lastInsertId($this->db->prefix.'conversations');

				$insert = array(
					'poster'	=>	$this->user['username'],
					'poster_id'	=>	$this->user['id'],
					'poster_ip'	=>	get_remote_address(),
					'message'	=>	$pm_message,
					'hide_smilies'	=>	0,
					'posted'	=>	CURRENT_TIMESTAMP,
					'topic_id'	=>	$new_tid,
				);

				$this->db->insert('messages', $insert);
				$new_pid = $this->db->lastInsertId($this->db->prefix.'messages');

				$update = array(
					'first_post_id'	=>	$new_pid,
					'last_post_id'	=>	$new_pid,
				);

				$data = array(
					':tid'	=>	$new_tid,
				);

				$this->db->update('conversations', $update, 'id=:tid', $data);
				$insert = array(
					'topic_id'	=>	$new_tid,
					'user_id'	=>	$user_id,
				);

				$this->db->insert('pms_data', $insert);

				$insert = array(
					'topic_id' => $new_tid,
					'user_id' => $this->user['id'],
					'viewed' => 1,
					'deleted' => 1,
				);

				$this->db->insert('pms_data', $insert);
				$data = array(
					':id' => $user_id,
				);

				$this->db->run('UPDATE '.$this->db->prefix.'users SET num_pms=num_pms+1 WHERE id=:id', $data);
				if ($pm_notify == '1')
				{
					$mail = new \email\email($this->registry);
					$info = array(
						'message' => array(
						'<username>' => $username,
						'<sender>' => $this->user['username'],
						'<message>' => $pm_message,
						'<pm_title>' => $pm_subject,
						'<message_url>' => $this->registry->get('\links')->aura_link($this->rewrite->url['pms_post'], array($new_pid)),
						)
					);

					$mail_tpl = $this->registry->get('\email\parser')->parse_email('new_pm', $this->user['language'], $info);
					$mail->send($email, $mail_tpl['subject'], $mail_tpl['message']);
				}

				$update = array(
					'last_post' => CURRENT_TIMESTAMP,
				);

				$data = array(
					':id' => $this->user['id'],
				);

				$this->db->update('users', $update, 'id=:id', $data);

				// Check whether user should be banned according to warning levels
				if ($warning_points > 0)
				{
					$data = array(
						':uid' => $user_id,
						':now' => CURRENT_TIMESTAMP,
					);

					$ps = $this->db->select('warnings', 'SUM(points)', $data, 'user_id=:uid AND (date_expire>:now OR date_expire=0)');
					$points_active = $ps->fetchColumn();

					$data = array(
						':active' => $points_active,
					);

					$ps = $this->db->select('warning_levels', 'message, period', $data, 'points<=:active', 'points DESC LIMIT 1');
					if ($ps->rowCount())
					{
						list($ban_message, $ban_period) = $ps->fetch(PDO::FETCH_NUM);
						$data = array(
							':username' => $username,
						);

						$ps = $this->db->select('bans', 'expire', $data, 'username=:username', 'expire DESC LIMIT 1');
						if ($ps->rowCount())
						{
							$ban_expire = $ps->fetchColumn();

							// Only delete user's current bans if new ban is greater than curent ban and current ban is not a permanent ban
							if (((CURRENT_TIMESTAMP + $ban_period) > $ban_expire || $ban_period == '0') && $ban_expire != null)
							{
								$ps = $this->db->delete('bans', 'username=:username', $data);
								$insert = array(
								'username'	=>	$username,
								'message'	=>	$ban_message,
								'ban_creator' => $this->user['id'],
								);

								if ($ban_period != 0)
								$insert['expire'] = CURRENT_TIMESTAMP + $ban_period;

								$this->db->insert('bans', $insert);
							}
						}
						else
						{
							$insert = array(
								'username'	=>	$username,
								'message'	=>	$ban_message,
								'ban_creator'	=>	$this->user['id'],
							);

							if ($ban_period != 0)
							$insert['expire'] = CURRENT_TIMESTAMP + $ban_period;

								$this->db->insert('bans', $insert);
						}

						// Regenerate the bans cache
						$this->cache->generate('bans');
					}
				}

				$redirect_link = ($post_id) ? $this->registry->get('\links')->aura_link($this->rewrite->url['post'], array($post_id)) : $this->registry->get('\links')->aura_link($this->rewrite->url['profile'], array($user_id, \url\url::replace($username)));
				$this->registry->get('\handlers\redirect')->show($redirect_link, $this->lang->t('Warning added redirect'));
			}
		}
	}
}