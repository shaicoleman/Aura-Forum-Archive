<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class details_controller extends base_controller
{
	/**
	 * Main app entry point, we display the details
	 */
	public function execute()
	{
		$this->configure_warnings();

		$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
		if ($id < 1)
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'));

		$warning_details = $this->fetch_warning_details($id);

		// Normal users can only view their own warnings if they have permission
		if ($this->user['is_guest'] || (!$this->user['is_admmod'] && $this->user['id'] != $warning_details['user_id']) || (!$this->user['is_admmod'] && $this->config['o_warning_status'] == '2'))
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'));

		if ($warning_details['custom_title'] != '')
			$warning_title = $this->lang->t('Custom warning', $warning_details['custom_title']).' ('.$this->lang->t('No of points', $warning_details['points']).')';
		else if ($warning_details['title'] != '')
			$warning_title = $warning_details['title'].' ('.$this->lang->t('No of points', $warning_details['points']).')';
		else
			$warning_title = ''; // This warning type has been deleted

		$data = array(
			':id' => $warning_details['user_id']
		);

		$ps = $this->db->select('users', 'username, group_id', $data, 'id=:id');
		list($username, $group_id) = $ps->fetch(PDO::FETCH_NUM);

		if ($warning_details['date_expire'] == '0')
			$warning_expires = $this->lang->t('Expires', $this->lang->t('Never'));
		else if ($warning_details['date_expire'] > CURRENT_TIMESTAMP)
			$warning_expires = $this->lang->t('Expires', $this->registry->get('\aura_time')->format($warning_details['date_expire']));
		else
			$warning_expires = $this->lang->t('Expired', $this->registry->get('\aura_time')->format($warning_details['date_expire']));

		$render = array(
			'form_action' => $this->registry->get('\links')->aura_link($this->rewrite->url['delete_warning']),
			'issued_to' => $this->functions->colourise_group($username, $group_id, $warning_details['user_id']),
			'warning_title' => $warning_title,
			'issued' => $this->registry->get('\aura_time')->format($warning_details['date_issued']),
			'warning_expires' => $warning_expires,
			'issued_by' => $this->functions->colourise_group($warning_details['issued_by_username'], $warning_details['issuer_gid'], $warning_details['issued_by']),
			'details_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['warning_details'], array($id)),
			'view_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['warning_view'], array($warning_details['user_id'])),
			'profile_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['profile'], array($warning_details['user_id'], \url\url::replace($username))),
			'username' => $username,
			'post_id' => $warning_details['post_id'],
			'aura_user' => $this->user,
			'csrf_token' => $this->registry->get('\auth\csrf')->generate('warning_details'),
			'user_id' => $warning_details['user_id'],
			'warning_id' => $id,
		);

		$parser = new \message\parser($this->registry);
		if ($this->user['is_admmod'])
		{
			$note_admin = $parser->parse_message($warning_details['note_admin'], 0);
			$render['admin_note'] = ($note_admin  == '') ? $this->lang->t('No admin note') : $note_admin;
		}

		if ($this->config['o_private_messaging'] == '1')
		{
			$note_pm = $parser->parse_message($warning_details['note_pm'], 0);
			$render['pm_note'] = ($note_pm == '') ? $this->lang->t('No message') : $note_pm;
		}

		if ($warning_details['post_id'])
		{
			$render['message'] = $parser->parse_message($warning_details['note_post'], 0);
			$render['post_link'] = $this->registry->get('\links')->aura_link($this->rewrite->url['post'], array($warning_details['post_id']));
		}

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Warning system')),
			'active_page' => 'index',
		);

		$this->template->footer = array(
			'footer_style' => 'warnings',
		);

		$tpl = $this->template->load('warning_details.tpl');
		$this->template->output($tpl, $render);
	}

	/**
	 * Delete the warning
	 */
	public function delete_warning()
	{
		$this->configure_warnings();

		$this->registry->get('\auth\csrf')->confirm('warning_details');

		// Are we allowed to delete warnings?
		if (!$this->user['is_admin'] && (!$this->user['is_admmod'] || $this->user['g_mod_warn_users'] == '0'))
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'));

		$id = isset($_POST['delete_id']) ? intval($_POST['delete_id']) : 0;
		$user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;

		if ($id < 1)
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'));

		$data = array(
			':id' => $id,
		);

		// Delete the warning
		$this->db->delete('warnings', 'id=:id', $data);
		$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['warning_view'], array($user_id)), $this->lang->t('Warning deleted redirect'));
	}

	/**
	 * Fetch the details of the warning
	 */
	protected function fetch_warning_details($id)
	{
		$join = array(
			array(
				'type' => 'LEFT',
				'table' => 'warning_types',
				'as' => 't',
				'on' => 't.id=w.type_id',
			),
			array(
				'type' => 'LEFT',
				'table' => 'users',
				'as' => 'u',
				'on' => 'u.id=w.issued_by',
			),
		);

		$data = array(
			':id' => $id,
		);

		$ps = $this->db->join('warnings', 'w', $join, 'w.id, w.user_id, w.type_id, w.post_id, w.title AS custom_title, w.points, w.date_issued, w.date_expire, w.issued_by, w.note_admin, w.note_post, w.note_pm, t.title, u.username AS issued_by_username, u.group_id AS issuer_gid', $data, 'w.id=:id');
		if (!$ps->rowCount())
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'));

		$warning_details = $ps->fetch();

		return $warning_details;
	}

	/**
	 * Load some common resources we need
	 */
	protected function configure_warnings()
	{
		if ($this->config['o_warnings'] == '0')
			$this->registry->get('\handlers\message')->show($this->lang->t('Warning system disabled'));

		// Load the warnings/post language files
		$this->lang->load('warnings');
		$this->lang->load('post');
	}
}