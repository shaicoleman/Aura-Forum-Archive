<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class index_controller extends base_controller
{
	/**
	 * Main app entry point, we display the warning types and configuration here
	 */
	public function execute()
	{
		if ($this->config['o_warnings'] == '0')
			$this->registry->get('\handlers\message')->show($this->lang->t('Warning system disabled'));

		// Load the warnings/post language files
		$this->lang->load('warnings');
		$this->lang->load('post');

		list($warning_levels, $warning_types) = $this->fetch_warning_levels();

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Warning system')),
			'active_page' => 'index',
		);

		$this->template->footer = array(
			'footer_style' => 'warnings',
		);

		$tpl = $this->template->load('warnings.tpl');
		$this->template->output($tpl,
			array(
				'warning_levels' => $warning_levels,
				'warning_types' => $warning_types,
			)
		);
	}

	/**
	 * Fetch the warning levels
	 */
	protected function fetch_warning_levels()
	{
		$ps = $this->db->select('warning_types', 'id, title, description, points, expiration_time', array(), '', 'points, id');
		$ps1 = $this->db->select('warning_levels', 'id, points, period', array(), '', 'points, id');

		// If neither have been configured
		if (!$ps->rowCount() && !$ps1->rowCount())
			$this->registry->get('\handlers\message')->show($this->lang->t('No configured warnings'));

		$warning_types = array();
		foreach ($ps as $cur_type)
		{
			$warning_types[] = array(
				'title' => $cur_type['title'],
				'description' => $cur_type['description'],
				'points' => $cur_type['points'],
			);
		}

		$warning_levels = array();
		foreach ($ps1 as $cur_level)
		{
			$ban_title =  ($cur_level['period'] == '0') ? $this->lang->t('Permanent ban') : $this->registry->get('\aura_time')->format_expiration_time($cur_level['period']);
			$warning_levels[] = array(
				'title' => $ban_title,
				'points' => $cur_level['points'],
			);
		}

		return array($warning_levels, $warning_types);
	}
}