<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class update_controller extends base_controller
{
	/**
	 * Main class entry point
	 */
	public function execute()
	{
		$admin = new \admin\common($this->registry);

		if (!$this->user['is_admin'])
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		$admin->check_user('admin_updates');

		$this->registry->get('\auth\http_auth')->check_authentication();

		// Load the admin-update language file
		$this->lang->load('admin_update');

		$errors = array();
		if (isset($_POST['form_sent']))
		{
			$this->registry->get('\auth\csrf')->confirm('upgrade_forum');

			$upgrade = new \upgrade\manual($this->registry);
			$result = $upgrade->run();
			if ($result['state']) // If it succeeded
				$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['about_aura']), $this->lang->t('Forum updated'));
			else
				$errors[] = $result['lang'];
		}

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Admin'), $this->lang->t('Update forum')),
			'active_page' => 'admin',
			'admin_console' => true,
		);

		$this->template->footer = array(
			'admin_console' => true,
		);

		$tpl = $this->template->load('admin/updates.tpl');
		$this->template->output($tpl,
			array(
				'errors' => $errors,
				'admin_menu' => $admin->generate_menu('updates'),
				'form_action' => $this->registry->get('\links')->aura_link($this->rewrite->url['admin_update']),
				'csrf_token' => $this->registry->get('\auth\csrf')->generate('upgrade_forum'),
			)
		);
	}
}