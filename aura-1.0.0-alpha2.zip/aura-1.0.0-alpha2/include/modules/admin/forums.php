<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class forums_controller extends base_controller
{
	/**
	 * Main app entry point
	 */
	public function execute()
	{
		$this->configure_page();

		// Setup some event handlers
		if (isset($_POST['add_forum']))
			$this->add_forum(); // Add a "default" forum
		else if (isset($_GET['del_forum'])) // Delete a forum
			$this->delete_forum();
		else if (isset($_POST['update_positions']) && isset($_POST['position']) && is_array($_POST['position']))
			$this->update_positions(); // Update forum positions
		else if (isset($_GET['edit_forum']))
			$this->edit_forum();

		// Fetch a list of all the categories/forums available
		list ($category_list, $forums, $categories) = $this->fetch_forums();

		$tpl = $this->template->load('admin/forums.tpl');
		$this->template->output($tpl,
			array(
				'admin_menu' => $this->admin->generate_menu('forums'),
				'form_action' => $this->registry->get('\links')->aura_link($this->rewrite->url['admin_forums']),
				'csrf_token' => $this->registry->get('\auth\csrf')->generate(config::ADMIN_DIR.'_forums'),
				'categories' => $categories,
				'category_list' => $category_list,
				'forums' => $forums,
			)
		);
	}

	/**
	 * Removes a moderator from the forum
	 */
	protected function remove_moderator($forum_id)
	{
		$this->registry->get('\auth\csrf')->confirm(config::ADMIN_DIR.'_forums');

		$id = is_array($_POST['delete_moderator']) ? utf8_trim(key($_POST['delete_moderator'])) : '';
		$type = substr($id, 0, 1);

		if ($type != 'g' && $type != 'u')
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		$data = array(
			':id' => intval(substr($id, 1)), // Clean the ID up with the 'g' or 'u' removed
			':fid' => $forum_id,
		);

		if ($type == 'g')
			$this->db->delete('moderators', 'group_id=:id AND forum_id=:fid', $data);
		else
			$this->db->delete('moderators', 'user_id=:id AND forum_id=:fid', $data);

		$this->cache->generate('moderators');
		$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['admin_forums']), $this->lang->t('Moderator removed redirect'));		
	}

	/**
	 * Add a Moderator to the forum
	 */
	protected function add_moderator($forum_id)
	{
		$this->registry->get('\auth\csrf')->confirm(config::ADMIN_DIR.'_forums');

		$moderators = $this->cache->get('moderators');
		$moderators = isset($moderators[$forum_id]) ? $moderators[$forum_id] : array();
		$moderator = isset($_POST['moderator']) ? utf8_trim($_POST['moderator']) : '';

		if ($moderator == '')
			$this->registry->get('\handlers\message')->show($this->lang->t('Must enter moderator message'));
		else
		{
			// Always try a user first
			$is_group = false;
			$data = array(
				':username' => $moderator,
			);

			$ps = $this->db->select('users', 'username, id, group_id', $data, 'username=:username AND id>1');
			if (!$ps->rowCount())
			{
				$ps = $this->db->select('groups', 'g_title, g_id', $data, 'g_title=:username');
				if (!$ps->rowCount())
					$this->registry->get('\handlers\message')->show($this->lang->t('Invalid moderator message'));

				list($moderator, $id) = $ps->fetch(PDO::FETCH_NUM);
				$is_group = true;
			}
			else
				list($moderator, $id, $group_id) = $ps->fetch(PDO::FETCH_NUM);

			if ($is_group)
			{
				if (isset($moderators['g'.$id]))
					$this->registry->get('\handlers\message')->show($this->lang->t('User group already assigned'));
				else if ($id == AURA_GUEST)
					$this->registry->get('\handlers\message')->show($this->lang->t('Cannot assign guest group'));
				else if ($id == $this->config['o_default_user_group'])
					$this->registry->get('\handlers\message')->show($this->lang->t('Cannot assign new member group'));

				$insert = array(
					'forum_id' => $forum_id,
					'group_title' => $moderator,
					'group_id' => $id,
				);
			}
			else
			{
				if (isset($moderators['u'.$id]))
					$this->registry->get('\handlers\message')->show($this->lang->t('Moderator already assigned'));
				else if (isset($moderators['g'.$group_id])) // Check if this user's group has already been assigned (not much point in assigning them in that case)
					$this->registry->get('\handlers\message')->show($this->lang->t('Moderator user group already assigned'));

				$insert = array(
					'forum_id' => $forum_id,
					'username' => $moderator,
					'user_id' => $id,
				);
			}

			$this->db->insert('moderators', $insert);

			$this->cache->generate('moderators');
			$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['admin_forums']), $this->lang->t('Moderator added redirect'));
		}
	}

	/**
	 * Save the information of a forum
	 */
	protected function save_forum($forum_id)
	{
		$this->registry->get('\auth\csrf')->confirm(config::ADMIN_DIR.'_forums');

		// Start with the forum details
		$forum_name = isset($_POST['forum_name']) ? utf8_trim($_POST['forum_name']) : '';
		$forum_desc = isset($_POST['forum_desc']) ? aura_linebreaks(utf8_trim($_POST['forum_desc'])) : '';
		$cat_id = isset($_POST['cat_id']) ? intval($_POST['cat_id']) : '';
		$sort_by = isset($_POST['sort_by']) ? intval($_POST['sort_by']) : '';
		$redirect_url = isset($_POST['redirect_url']) ? utf8_trim($_POST['redirect_url']) : null;
		$use_reputation = isset($_POST['use_reputation']) && $_POST['use_reputation'] == '1' ? '1' : '0';
		$force_approve = isset($_POST['moderator_approve']) ? intval($_POST['moderator_approve']) : '0';
		$parent_forum = isset($_POST['parent_forum']) ? intval($_POST['parent_forum']) : '0';
		$show_post_info = isset($_POST['show_post_info']) ? intval($_POST['show_post_info']) :'1';
		$forum_password1 = isset($_POST['forum_password1']) ? utf8_trim($_POST['forum_password1']) : '';
		$forum_password2 = isset($_POST['forum_password2']) ? utf8_trim($_POST['forum_password2']) : '';
		$change_password = isset($_POST['change_forum_pass']) ? intval($_POST['change_forum_pass']) : '0';
		$quickjump = isset($_POST['quickjump']) ? intval($_POST['quickjump']) : '1';
		$protected = isset($_POST['protected']) ? intval($_POST['protected']) : '0';
		$increment_posts = isset($_POST['increment_posts']) ? intval($_POST['increment_posts']) : 1;

		if ($forum_name == '')
			$this->registry->get('\handlers\message')->show($this->lang->t('Must enter name message'));

		if ($cat_id < 1)
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');
			
		$data = array(
			':id' => $forum_id,
		);

		if ($change_password == '1')
		{
			if ($forum_password1 == $forum_password2)
			{
				if ($forum_password1 == '')
				{
					$update = array(
						'password' => '',
						'salt' => '',
					);
						
					$this->db->update('forums', $update, 'id=:id', $data);
				}
				else
				{
					$salt = random_key(16, true);
					$update = array(
						'password' => aura_hash($forum_password1.aura_hash($salt)),
						'salt' => $salt,
					);

					$this->db->update('forums', $update, 'id=:id', $data);					
				}
			}
			else
				$this->registry->get('\handlers\message')->show($this->lang->t('passwords do not match'));
		}

		$forum_desc = ($forum_desc != '') ? $forum_desc : null;
		$redirect_url = ($redirect_url != '') ? $redirect_url : null;

		$update = array(
			'forum_name'	=>	$forum_name,
			'forum_desc'	=>	$forum_desc,
			'use_reputation'	=>	$use_reputation,
			'parent_forum'	=>	$parent_forum,
			'redirect_url'	=>	$redirect_url,
			'force_approve'	=>	$force_approve,
			'sort_by'		=>	$sort_by,
			'cat_id'		=>	$cat_id,
			'show_post_info'	=>	$show_post_info,
			'quickjump'		=>	$quickjump,
			'protected'		=>	$protected,
			'increment_posts'	=>	$increment_posts,
		);

		$this->db->update('forums', $update, 'id=:id', $data);

		// Now let's deal with the permissions
		if (isset($_POST['read_forum_old']))
		{
			$groups = $this->cache->get('groups');
			foreach ($groups as $cur_group)
			{
				if ($cur_group['g_id'] != AURA_ADMIN)
				{
					$read_forum_new = ($cur_group['g_read_board'] == '1') ? isset($_POST['read_forum_new'][$cur_group['g_id']]) ? '1' : '0' : intval($_POST['read_forum_old'][$cur_group['g_id']]);
					$post_replies_new = isset($_POST['post_replies_new'][$cur_group['g_id']]) ? '1' : '0';
					$post_topics_new = isset($_POST['post_topics_new'][$cur_group['g_id']]) ? '1' : '0';
					$post_polls_new = isset($_POST['post_polls_new'][$cur_group['g_id']]) ? '1' : '0';
					$upload_new = isset($_POST['upload_new'][$cur_group['g_id']]) ? '1' : '0';
					$download_new = isset($_POST['download_new'][$cur_group['g_id']]) ? '1' : '0';
					$delete_new = isset($_POST['delete_new'][$cur_group['g_id']]) ? '1' : '0';

					// Check if the new settings differ from the old
					if ($read_forum_new != $_POST['read_forum_old'][$cur_group['g_id']] || $post_replies_new != $_POST['post_replies_old'][$cur_group['g_id']] || $post_polls_new != $_POST['post_polls_old'][$cur_group['g_id']] || $post_topics_new != $_POST['post_topics_old'][$cur_group['g_id']] || $upload_new != $_POST['upload_old'][$cur_group['g_id']] || $download_new != $_POST['download_old'][$cur_group['g_id']] || $delete_new != $_POST['delete_old'][$cur_group['g_id']])
					{
						// If the new settings are identical to the default settings for this group, delete its row in forum_perms
						if ($read_forum_new == '1' && $post_replies_new == $cur_group['g_post_replies'] && $post_topics_new == $cur_group['g_post_topics'] && $post_polls_new == $cur_group['g_post_polls'] && $upload_new == $cur_group['g_attach_files'] && $delete_new == $cur_group['g_delete_posts'] && $download_new == '1')
						{
							$data = array(
								':gid'	=>	$cur_group['g_id'],
								':fid'	=>	$forum_id,
							);

							$this->db->delete('forum_perms', 'group_id=:gid AND forum_id=:fid', $data);
						}
						else
						{
							$data = array(
								'group_id'	=>	$cur_group['g_id'],
								'forum_id'	=>	$forum_id,
								'read_forum'	=>	$read_forum_new,
								'post_replies'	=>	$post_replies_new,
								'post_polls'	=>	$post_polls_new,
								'post_topics'	=>	$post_topics_new,
								'upload'		=>	$upload_new,
								'download'		=>	$download_new,
								'delete_files'	=>	$delete_new,
							);

							$this->db->replace('forum_perms', $replace);
						}
					}
				}
			}
		}

		// Regenerate some caches ...
		$this->cache->generate('forums');
		$this->cache->generate('quickjump');
		$this->cache->generate('perms');

		$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['admin_forums']), $this->lang->t('Forum updated redirect'));		
	}

	/**
	 * Revert the user group permissions of a forum to the default
	 */
	protected function revert_permissions($forum_id)
	{
		$this->registry->get('\auth\csrf')->confirm(config::ADMIN_DIR.'_forums');
		$data = array(
			':id' => $forum_id,
		);

		$this->db->delete('forum_perms', 'forum_id=:id', $data);

		// Regenerate some caches ...
		$this->cache->generate('forums');
		$this->cache->generate('quickjump');
		$this->cache->generate('perms');

		$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['edit_forum'], array($forum_id)), $this->lang->t('Perms reverted redirect'));		
	}

	/**
	 * Edit a forum
	 */
	protected function edit_forum()
	{
		$forum_id = intval($_GET['edit_forum']);
		if ($forum_id < 1)
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		// Remove a moderator
		if (isset($_POST['delete_moderator']))
			$this->remove_moderator($forum_id);
		else if (isset($_POST['add_moderator'])) // Add a moderator
			$this->add_moderator($forum_id);
		// Update group permissions for $forum_id
		else if (isset($_POST['save']))
			$this->save_forum($forum_id);
		else if (isset($_POST['revert_perms']))
			$this->revert_permissions($forum_id);

		// Fetch forum info
		$aura_forums = $this->cache->get('forums');
		if (!isset($aura_forums[$forum_id]))
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');
		else
			$cur_forum = $aura_forums[$forum_id];

		$password = ($cur_forum['password'] != '' && $cur_forum['redirect_url'] == '') ? random_key(12, true) : '';

		$parent_forums = array();
		$ps = $this->db->select('forums', 'DISTINCT parent_forum', array(), 'parent_forum!=0');
		$ps->setFetchMode(PDO::FETCH_COLUMN, 0);
		foreach ($ps as $fid)
			$parent_forums[] = $fid;

		$categories = array();
		$ps = $this->db->select('categories', 'id, cat_name', array(), '', 'disp_position');
		foreach ($ps as $cur_cat)
			$categories[] = array('id' => $cur_cat['id'], 'name' => $cur_cat['cat_name']);

		$forums = $category_list = array();
		if (!in_array($cur_forum['id'], $parent_forums))
		{
			$join = array(
				array(
					'type' => 'INNER',
					'table' => 'forums',
					'as' => 'f',
					'on' => 'c.id=f.cat_id',
				),
			);

			$ps = $this->db->join('categories', 'c', $join, 'c.id AS cid, c.cat_name, f.id, f.forum_name, f.redirect_url, f.parent_forum', array(), '', 'c.disp_position, c.id, f.disp_position');
			foreach ($ps as $forum_list)
			{
				if (!isset($category_list[$forum_list['cid']]))
					$category_list[$forum_list['cid']] = array(
						'cat_name' => $forum_list['cat_name'],
						'id' => $forum_list['cid'],
					);

				if (!$forum_list['parent_forum'] && $forum_list['id'] != $cur_forum['id'])
					$forums[] = array('id' => $forum_list['id'], 'name' => $forum_list['forum_name'], 'category_id' => $forum_list['cid']);
			}
		}

		$data = array(
			':gid' => AURA_ADMIN,
			':fid' => $forum_id,
		);

		$join = array(
			array(
				'type' => 'LEFT',
				'table' => 'forum_perms',
				'as' => 'fp',
				'on' => '(g.g_id=fp.group_id AND fp.forum_id=:fid)',
			),
		);

		$groups = array();
		$ps = $this->db->join('groups', 'g', $join, 'g.g_id, g.g_title, g.g_read_board, g.g_post_replies, g.g_post_topics, g.g_delete_posts, g.g_attach_files, g.g_post_polls, fp.read_forum, fp.post_replies, fp.post_topics, fp.post_polls, fp.upload, fp.download, fp.delete_files', $data, 'g.g_id!=:gid', 'g.g_id');
		foreach ($ps as $cur_perm)
		{
			$read_forum = ($cur_perm['read_forum'] != '0') ? true : false;
			$post_replies = (($cur_perm['g_post_replies'] == '0' && $cur_perm['post_replies'] == '1') || ($cur_perm['g_post_replies'] == '1' && $cur_perm['post_replies'] != '0')) ? true : false;
			$post_topics = (($cur_perm['g_post_topics'] == '0' && $cur_perm['post_topics'] == '1') || ($cur_perm['g_post_topics'] == '1' && $cur_perm['post_topics'] != '0')) ? true : false;
			$post_polls = (($cur_perm['g_post_polls'] == '0' && $cur_perm['post_polls'] == '1') || ($cur_perm['g_post_polls'] == '1' && $cur_perm['post_polls'] != '0')) ? true : false;
			$upload = (($cur_perm['g_attach_files'] == '0' && $cur_perm['upload'] == '1') || ($cur_perm['g_attach_files'] == '1' && $cur_perm['upload'] != '0')) ? true : false;
			$download = (($cur_perm['read_forum'] != '0' && $cur_perm['download'] != '0') || ($cur_perm['read_forum'] == '1' && $cur_perm['download'] != '0')) ? true : false;
			$delete = (($cur_perm['g_delete_posts'] == '0' && $cur_perm['delete_files'] == '1') || ($cur_perm['g_delete_posts'] == '1' && $cur_perm['delete_files'] != '0')) ? true : false;

			// Determine if the current settings differ from the default or not
			$read_forum_def = ($cur_perm['read_forum'] == '0') ? false : true;
			$post_replies_def = (($post_replies && $cur_perm['g_post_replies'] == '0') || (!$post_replies && ($cur_perm['g_post_replies'] == '' || $cur_perm['g_post_replies'] == '1'))) ? false : true;
			$post_topics_def = (($post_topics && $cur_perm['g_post_topics'] == '0') || (!$post_topics && ($cur_perm['g_post_topics'] == '' || $cur_perm['g_post_topics'] == '1'))) ? false : true;
			$post_polls_def = (($post_polls && $cur_perm['g_post_polls'] == '0') || (!$post_polls && ($cur_perm['g_post_polls'] == '' || $cur_perm['g_post_polls'] == '1'))) ? false : true;
			$upload_def = (($upload && $cur_perm['g_attach_files'] == '0') || (!$upload && ($cur_perm['g_attach_files'] == '' || $cur_perm['g_attach_files'] == '1'))) ? false : true;
			$download_def = (($download && $cur_perm['read_forum'] == '0') || (!$download && ($cur_perm['read_forum'] == '' || $cur_perm['read_forum'] == '1'))) ? false : true;
			$delete_def = (($delete && $cur_perm['g_delete_posts'] == '0') || (!$delete && ($cur_perm['g_delete_posts'] == '' || $cur_perm['g_delete_posts'] == '1'))) ? false : true;

			$groups[] = array(
				'perm' => $cur_perm,
				'read_forum_def' => $read_forum_def,
				'read_forum' => $read_forum,
				'post_replies_def' => $post_replies_def,
				'post_replies' => $post_replies,
				'post_topics_def' => $post_topics_def,
				'post_topics' => $post_topics,
				'post_polls_def' => $post_polls_def,
				'post_polls' => $post_polls,
				'upload_def' => $upload_def,
				'upload' => $upload,
				'download_def' => $download_def,
				'download' => $download,
				'delete_def' => $delete_def,
				'delete' => $delete,
			);
		}

		$forum_moderators = array();
		$moderators = $this->cache->get('moderators');
		if (isset($moderators[$forum_id]))
		{
			foreach ($moderators[$forum_id] as $key => $moderator)
			{
				if ($moderator['user_id']) // It's a user
				{
					$data = array(
						':id' => $moderator['user_id'],
					);

					// There has to be a better way of doing this ....
					$ps1 = $this->db->select('users', 'group_id', $data, 'id=:id');
					$group_id = $ps1->fetchColumn();

					$forum_moderators[] = array('id' => $key, 'name' => $this->functions->colourise_group($moderator['username'], $group_id, $moderator['user_id']));
				}
				else // It's an entire user group
					$forum_moderators[] = array('id' => $key, 'name' => $this->functions->colourise_group($moderator['group_title'], $moderator['group_id']));
			}
		}

		$tpl = $this->template->load('admin/edit_forum.tpl');
		$this->template->output($tpl,
			array(
				'admin_menu' => $this->admin->generate_menu('forums'),
				'forum' => $cur_forum,
				'password' => ($cur_forum['password'] != '') ? random_key(12, true) : '',
				'form_action' => $this->registry->get('\links')->aura_link($this->rewrite->url['edit_forum'], array($forum_id)),
				'csrf_token' => $this->registry->get('\auth\csrf')->generate(config::ADMIN_DIR.'_forums'),
				'categories' => $categories,
				'category_list' => $category_list,
				'forums' => $forums,
				'groups_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['admin_groups']),
				'groups' => $groups,
				'moderators' => $forum_moderators,
			)
		);

		exit;
	}

	/**
	 * Update the visibility positions of forums
	 */
	protected function update_positions()
	{
		$this->registry->get('\auth\csrf')->confirm(config::ADMIN_DIR.'_forums');

		foreach ($_POST['position'] as $forum_id => $disp_position)
		{
			$disp_position = isset($disp_position) ? utf8_trim($disp_position) : 0;
			if ($disp_position < 0)
				$this->registry->get('\handlers\message')->show($this->lang->t('Must be integer message'));

			$update = array(
				'disp_position'	=> $disp_position,
			);

			$data = array(
				':id' => intval($forum_id),
			);

			$this->db->update('forums', $update, 'id=:id', $data);
		}

		// Regenerate some caches ...
		$this->cache->generate('forums');
		$this->cache->generate('quickjump');
		$this->cache->generate('perms');

		$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['admin_forums']), $this->lang->t('Forums updated redirect'));
	}

	/**
	 * Delete a forum
	 */
	protected function delete_forum()
	{
		$forum_id = intval($_GET['del_forum']);
		if ($forum_id < 1)
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		if (isset($_POST['del_forum_comply'])) // Delete a forum with all posts
		{
			$this->registry->get('\auth\csrf')->confirm(config::ADMIN_DIR.'_forums');
			@set_time_limit(0);

			// Prune all posts and topics
			$this->registry->get('\admin\misc')->prune($forum_id, 1, -1);

			$join = array(
				array(
					'type' => 'LEFT',
					'table' => 'topics',
					'as' => 't2',
					'on' => 't1.moved_to=t2.id',
				),
			);

			// Locate any "orphaned redirect topics" and delete them
			$ps = $this->db->join('topics', 't1', $join, 't1.id', array(), 't2.id IS NULL AND t1.moved_to IS NOT NULL');
			if ($ps->rowCount())
			{
				$markers = $orphans = array();
				$ps->setFetchMode(PDO::FETCH_COLUMN, 0);
				foreach ($ps as $orphan)
				{
					$orphans[] = $orphan;
					$markers[] = '?';
				}

				$this->db->delete('topics', 'id IN ('.implode(',', $markers).')', $orphans);
			}

			// Delete the forum and any forum specific group permissions
			$data = array(
				':id' => $forum_id,
			);

			$this->db->delete('forums', 'id=:id', $data);
			$this->db->delete('forum_perms', 'forum_id=:id', $data);

			// Delete any subscriptions for this forum
			$this->db->delete('forum_subscriptions', 'forum_id=:id', $data);

			// Regenerate some caches ...
			$this->cache->generate('forums');
			$this->cache->generate('announcements');
			$this->cache->generate('quickjump');
			$this->cache->generate('perms');

			$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['admin_forums']), $this->lang->t('Forum deleted redirect'));
		}
		else // If the user hasn't confirmed the delete
		{
			$data = array(
				':id' => $forum_id,
			);

			$ps = $this->db->select('forums', 'forum_name', $data, 'id=:id');
			$forum_name = $ps->fetchColumn();

			$tpl = $this->template->load('admin/delete_forum.tpl');
			$this->template->output($tpl,
				array(
					'admin_menu' => $this->admin->generate_menu('forums'),
					'form_action' => $this->registry->get('\links')->aura_link($this->rewrite->url['del_forum'], array($forum_id)),
					'csrf_token' => $this->registry->get('\auth\csrf')->generate(config::ADMIN_DIR.'_forums'),
					'forum_name' => $forum_name,
				)
			);

			exit;
		}
	}

	/**
	 * Add a new forum to the site
	 */
	protected function add_forum()
	{
		$this->registry->get('\auth\csrf')->confirm(config::ADMIN_DIR.'_forums');

		$add_to_cat = isset($_POST['add_to_cat']) ? intval($_POST['add_to_cat']) : '';
		if ($add_to_cat < 1)
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		$insert = array(
			'forum_name' => $this->lang->t('New forum'),
			'cat_id' => $add_to_cat,
		);

		$this->db->insert('forums', $insert);
		$new_fid = $this->db->lastInsertId($this->db->prefix.'forums');

		// Regenerate some caches ...
		$this->cache->generate('forums');
		$this->cache->generate('announcements');
		$this->cache->generate('quickjump');
		$this->cache->generate('perms');

		$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['edit_forum'], array($new_fid)), $this->lang->t('Forum added redirect'));
	}

	/**
	 * Setup a few commonly used things
	 */
	protected function configure_page()
	{
		$this->admin = new \admin\common($this->registry);

		if (!$this->user['is_admin'])
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		$this->admin->check_user('admin_forums');

		$this->registry->get('\auth\http_auth')->check_authentication();

		// Load the admin-forums language file
		$this->lang->load('admin_forums');

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Admin'), $this->lang->t('Forums')),
			'active_page' => 'admin',
			'admin_console' => true,
		);

		$this->template->footer = array(
			'admin_console' => true,
		);
	}

	/**
	 * Fetches a list of all categories/forums
	 */
	protected function fetch_forums()
	{
		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'forums',
				'as' => 'f',
				'on' => 'c.id=f.cat_id',
			),
		);

		// Display all the categories and forums
		$category_list = $forums = array();
		$ps = $this->db->join('categories', 'c', $join, 'c.id AS cid, c.cat_name, f.id AS fid, f.forum_name, f.disp_position, f.parent_forum', array(), '', 'c.disp_position, c.id, f.disp_position');
		foreach ($ps as $cur_forum)
		{
			if (!isset($catgeory_list[$cur_forum['cid']]))
				$category_list[$cur_forum['cid']] = array(
					'cat_name' => $cur_forum['cat_name'],
					'id' => $cur_forum['cid'],
				);

			$forums[] = array(
				'edit_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['edit_forum'], array($cur_forum['fid'])),
				'delete_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['del_forum'], array($cur_forum['fid'])),
				'id' => $cur_forum['fid'],
				'name' => $cur_forum['forum_name'],
				'disp_position' => $cur_forum['disp_position'],
				'parent_forum' => $cur_forum['parent_forum'],
				'category_id' => $cur_forum['cid'],
			);
		}

		$categories = array();
		$ps = $this->db->select('categories', 'id, cat_name', array(), '', 'disp_position');
		foreach ($ps as $cur_cat)
			$categories[] = array('id' => $cur_cat['id'], 'cat_name' => $cur_cat['cat_name']);

		return array($category_list, $forums, $categories);
	}
}