<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class tasks_controller extends base_controller
{
	/**
	 * Main app entry point, we display the tasks
	 */
	public function execute()
	{
		$this->configure_page();

		// Configure some event handlers we need to use
		if (isset($_POST['add_task']))
			$this->add_task();
		else if (isset($_POST['upload_task']))
			$this->upload_task();
		else if (isset($_POST['delete_task']))
			$this->delete_task_comply();

		// Fetch some data containing all of the currently configured tasks
		list ($configured_tasks, $options) = $this->fetch_configured_tasks();

		$tpl = $this->template->load('admin/tasks.tpl');
		$this->template->output($tpl,
			array(
				'admin_menu' => $this->admin->generate_menu('tasks'),
				'form_action' => $this->registry->get('\links')->aura_link($this->rewrite->url['admin_tasks']),
				'csrf_token' => $this->registry->get('\auth\csrf')->generate('admin_tasks'),
				'configured_tasks' => $configured_tasks,
				'tasks' => $options,
			)
		);
	}

	/**
	 * Edit a task on the forum
	 */
	public function edit_task()
	{
		$this->configure_page();

		$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
		if (isset($_POST['update'])) // Update a task
			$this->update_task($id);

		$data = array(
			':id' => $id,
		);

		$ps = $this->db->select('tasks', 'title, minute, hour, day, month, week_day, script', $data, 'id=:id');
		if (!$ps->rowCount())
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'));

		$cur_task = $ps->fetch();

		$options = array();
		$tasks = array_diff(scandir(AURA_ROOT.'include/tasks'), array('.', '..'));
		foreach ($tasks as $cur_file)
			$options[] = array('option' => substr($cur_file, 0, -4), 'title' => ucwords(str_replace('_', ' ', substr($cur_file, 0, -4))));

		$tpl = $this->template->load('admin/edit_task.tpl');
		$this->template->output($tpl,
			array(
				'admin_menu' => $this->admin->generate_menu('tasks'),
				'cur_task' => $cur_task,
				'form_action' => $this->registry->get('\links')->aura_link($this->rewrite->url['edit_task'], array($id)),
				'csrf_token' => $this->registry->get('\auth\csrf')->generate('admin_tasks'),
				'id' => $id,
				'tasks' => $options,
			)
		);
	}

	/**
	 * Delete a task on the system
	 */
	public function delete_task()
	{
		$this->configure_page();

		$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
		$data = array(
			':id' => $id,
		);

		$ps = $this->db->select('tasks', 1, $data, 'id=:id');
		if (!$ps->rowCount())
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'));

		if (isset($_POST['remove']))
			$this->remove_task($id);

		$tpl = $this->template->load('admin/delete_task.tpl');
		$this->template->output($tpl,
			array(
				'admin_menu' => $this->admin->generate_menu('tasks'),
				'form_action' => $this->registry->get('\links')->aura_link($this->rewrite->url['delete_task'], array($id)),
				'csrf_token' => $this->registry->get('\auth\csrf')->generate('admin_tasks'),
				'id' => $id,
			)
		);
	}

	/**
	 * Removes a physical task file from the server
	 */
	protected function delete_task_comply()
	{
		$this->registry->get('\auth\csrf')->confirm('admin_tasks');

		$tasks = isset($_POST['del_tasks']) && is_array($_POST['del_tasks']) ? array_map('aura_trim', $_POST['del_tasks']) : array();

		if (empty($tasks))
			$this->registry->get('\handlers\message')->show($this->lang->t('No tasks'));

		foreach ($tasks as $task)
		{
			// Make sure it doesn't look suspicious
			if (file_exists(AURA_ROOT.'include/tasks/'.$task.'.php') && (preg_match('/^[a-z0-9-_]+$/i', $task)) && !preg_match('/^[\/\.@[{}]!"£\|<>:]+$/i', $task))
				unlink(AURA_ROOT.'include/tasks/'.$task.'.php');
		}

		$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['admin_tasks']), $this->lang->t('Task removed redirect'));
	}

	/**
	 * Uploads a new task to the server
	 */
	protected function upload_task()
	{
		$this->registry->get('\auth\csrf')->confirm('admin_tasks');

		if (!isset($_FILES['req_file']))
			$this->registry->get('\handlers\message')->show($this->lang->t('No file'));

		$uploaded_file = $_FILES['req_file'];

		// Make sure the upload went smooth
		if (isset($uploaded_file['error']))
		{
			switch ($uploaded_file['error'])
			{
				case 1:	// UPLOAD_ERR_INI_SIZE
				case 2:	// UPLOAD_ERR_FORM_SIZE
					$this->registry->get('\handlers\message')->show($this->lang->t('Too large ini'));
				break;
				case 3:	// UPLOAD_ERR_PARTIAL
					$this->registry->get('\handlers\message')->show($this->lang->t('Partial upload'));
				break;
				case 4:	// UPLOAD_ERR_NO_FILE
					$this->registry->get('\handlers\message')->show($this->lang->t('No file'));
				break;
				case 6:	// UPLOAD_ERR_NO_TMP_DIR
					$this->registry->get('\handlers\message')->show($this->lang->t('No tmp directory'));
				break;
				default:
					// No error occured, but was something actually uploaded?
					if ($uploaded_file['size'] == 0)
						$this->registry->get('\handlers\message')->show($this->lang->t('No file'));
				break;
			}
		}

		if (is_uploaded_file($uploaded_file['tmp_name']))
		{
			$filename = $uploaded_file['name'];
			if (!preg_match('/^[a-z0-9-_]+\.(php)$/i', $uploaded_file['name']))
				$this->registry->get('\handlers\message')->show($this->lang->t('Bad type'));

			// Make sure there is no file already under this name
			if (file_exists(AURA_ROOT.'include/tasks/'.$filename))
				$this->registry->get('\handlers\message')->show($this->lang->t('Task exists', $filename));

			// Move the file to the addons directory.
			if (!@move_uploaded_file($uploaded_file['tmp_name'], AURA_ROOT.'include/tasks/'.$filename))
				$this->registry->get('\handlers\message')->show($this->lang->t('Move failed'));

			@chmod(AURA_ROOT.'include/tasks/'.$filename, 0644);
		}
		else
			$this->registry->get('\handlers\message')->show($this->lang->t('Unknown failure'));

		$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['admin_tasks']), $this->lang->t('Successful Upload Task'));
	}

	/**
	 * Removes a task from the system
	 */
	protected function remove_task($id)
	{
		$this->registry->get('\auth\csrf')->confirm('admin_tasks');

		$data = array(
			':id' => $id,
		);

		$ps = $this->db->select('tasks', 'minute, hour, day, month, week_day, script', $data, 'id=:id');
		$cur_task = $ps->fetch();

		$this->db->delete('tasks', 'id=:id', $data);
		if ($this->config['o_task_type'] == '1' && function_exists('exec'))
		{
			$delete = $cur_task['minute']. ' '.$cur_task['hour'].' '.$cur_task['day'].' '.$cur_task['month'].' '.$cur_task['week_day'].' '.substr(AURA_ROOT, 0, -3).'cron.php';

			exec('crontab -l', $cron_jobs);
			$cron = array_search($delete, $cron_jobs);
			if ($cron !== false)
			{
				exec('crontab -r');
				unset($cron_jobs[$cron]);
			}
			else
				$this->registry->get('\handlers\message')->show($this->lang->t('Unable to remove'));

			foreach ($cron_jobs as $cur_job)
				exec('echo -e "`crontab -l`\n'.$cur_job.'" | crontab -');
		}

		$this->cache->generate('tasks');
		$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['admin_tasks']),  $this->lang->t('Task removed redirect'));		
	}

	/**
	 * Insert a new task into the system
	 */
	protected function add_task()
	{
		$this->registry->get('\auth\csrf')->confirm('admin_tasks');

		list ($title, $minute, $hour, $day, $month, $week_day, $script) = $this->validate_task();
		$insert = array(
			'title'	=>	$title,
			'next_run' => $this->registry->get('\tasks\task_time')->next_run($minute, $hour, $day, $month, $week_day),
			'script' => $script,
			'minute' => $minute,
			'hour' => $hour,
			'day' => $day,
			'month' => $month,
			'week_day' => $week_day,
		);

		$this->db->insert('tasks', $insert);

		// If we're using proper cron jobs, then set it up
		if ($this->config['o_task_type'] == '1' && function_exists('exec'))
			exec('echo -e "`crontab -l`\n'.$minute.' '.$hour.' '.$day.' '.$month.' '.$week_day.' '.substr(AURA_ROOT, 0, -3).'cron.php'.'" | crontab -');

		$this->cache->generate('tasks');
		$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['admin_tasks']), $this->lang->t('Task added redirect'));
	}

	/**
	 * Update an existing task in the system
	 */
	protected function update_task($id)
	{
		$this->registry->get('\auth\csrf')->confirm('admin_tasks');

		list ($title, $minute, $hour, $day, $month, $week_day, $script) = $this->validate_task();
		$data = array(
			':id' => $id,
		);

		$ps = $this->db->select('tasks', 'minute, hour, day, month, week_day, script', $data, 'id=:id');
		$cur_task = $ps->fetch();

		$update = array(
			'title'	=>	$title,
			'next_run' => $this->registry->get('\tasks\task_time')->next_run($minute, $hour, $day, $month, $week_day),
			'script' => $script,
			'minute' => $minute,
			'hour' => $hour,
			'day' => $day,
			'month' => $month,
			'week_day' => $week_day,
		);

		$this->db->update('tasks', $update, 'id=:id', $data);

		if ($this->config['o_task_type'] == '1' && function_exists('exec'))
		{
			$delete = $cur_task['minute']. ' '.$cur_task['hour'].' '.$cur_task['day'].' '.$cur_task['month'].' '.$cur_task['week_day'].' '.substr(AURA_ROOT, 0, -3).'cron.php';
			exec('crontab -l', $cron_jobs);

			$cron = array_search($delete, $cron_jobs);
			if ($cron !== false)
			{
				exec('crontab -r');
				unset($cron_jobs[$cron]);
			}
			else
				$this->registry->get('\handlers\message')->show($this->lang->t('Unable to remove old task'));

			// We can only remove all cron jobs. So we now need to re-create them all ...
			foreach ($cron_jobs as $cur_job)
				exec('echo -e "`crontab -l`\n'.$cur_job.'" | crontab -');

			exec('echo -e "`crontab -l`\n'.$minute.' '.$hour.' '.$day.' '.$month.' '.$week_day.' '.substr(AURA_ROOT, 0, -3).'cron.php'.'" | crontab -');
		}

		$this->cache->generate('tasks');
		$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['admin_tasks']), $this->lang->t('Task updated redirect'));
	}

	/**
	 * Validate the task and verify all information is correct
	 */
	protected function validate_task()
	{
		$title = isset($_POST['new_task_title']) ? utf8_trim($_POST['new_task_title']) : '';
		$minute = isset($_POST['minute']) && $_POST['minute'] != '*' && $_POST['minute'] >= 0 && $_POST['minute'] <= 59 ? intval($_POST['minute']) : '*';
		$hour = isset($_POST['hour']) && $_POST['hour'] != '*' && $_POST['hour'] >= 0 && $_POST['hour'] <= 23 ? intval($_POST['hour']) : '*';
		$day = isset($_POST['day']) && $_POST['day'] != '*' && $_POST['day'] >= 1 && $_POST['day'] <= 31 ? intval($_POST['day']) : '*';
		$month = isset($_POST['month']) && $_POST['month'] != '*' && $_POST['month'] >= 1 && $_POST['month'] <= 12 ? intval($_POST['month']) : '*';
		$week_day = isset($_POST['week_day']) && $_POST['week_day'] != '*' && $_POST['week_day'] >= 0 && $_POST['week_day'] <= 6 ? intval($_POST['week_day']) : '*';
		$script = isset($_POST['script']) ? utf8_trim($_POST['script']) : '';

		if (!file_exists(AURA_ROOT.'/include/tasks/'.$script.'.php') || !preg_match('/^[a-z-_0-9]+$/i', $script))
			$this->registry->get('\handlers\message')->show($this->lang->t('Not valid task', $script));

		if (aura_strlen($title) < 5)
			$this->registry->get('\handlers\message')->show($this->lang->t('Too short title'));

		return array($title, $minute, $hour, $day, $month, $week_day, $script);
	}

	/**
	 * Fetches a list of all currently configured tasks
	 */
	protected function fetch_configured_tasks()
	{
		$configured_tasks = array();
		$ps = $this->db->select('tasks', 'id, title, minute, hour, day, month, week_day, script, next_run', array(), '', 'id');
		foreach ($ps as $cur_task)
		{
			$configured_tasks[] = array(
				'minute' => $cur_task['minute'],
				'hour' => $cur_task['hour'],
				'day' => $cur_task['day'],
				'month' => $cur_task['month'],
				'week_day' => $cur_task['week_day'],
				'delete_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['delete_task'], array($cur_task['id'])),
				'edit_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['edit_task'], array($cur_task['id'])),
				'next_run' => $this->registry->get('\aura_time')->format($cur_task['next_run']),
				'title' => $cur_task['title'],
			);
		}

		$options = array();
		$tasks = array_diff(scandir(AURA_ROOT.'include/tasks'), array('.', '..'));
		foreach ($tasks as $cur_task)
		{
			$options[] = array(
				'title' => ucwords(str_replace('_', ' ', substr($cur_task, 0, -4))),
				'file' => substr($cur_task, 0, -4),
			);
		}

		return array($configured_tasks, $options);
	}

	/**
	 * Setup a few things to use on the page
	 */
	protected function configure_page()
	{
		$this->admin = new \admin\common($this->registry);

		if (!$this->user['is_admin'])
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		$this->admin->check_user('admin_tasks');

		$this->registry->get('\auth\http_auth')->check_authentication();

		// Load the admin-tasks language file
		$this->lang->load('admin_tasks');

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Admin'), $this->lang->t('Tasks')),
			'active_page' => 'admin',
			'admin_console' => true,
		);

		$this->template->footer = array(
			'admin_console' => true,
		);
	}
}