<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class extensions_controller extends base_controller
{
	/**
	 * Main class entry point, we display the extensions
	 */
	public function execute()
	{
		// First we setup a few things we need ....
		$this->configure_page();

		$errors = array(); // ... Then setup our event handler to upload a new extension
		if (isset($_POST['upload'])) 
			$errors = $this->upload_extension();

		// Fetch the available extensions
		$extensions = $this->fetch_extensions();

		$tpl = $this->template->load('admin/extensions.tpl');
		$this->template->output($tpl,
			array(
				'admin_menu' => $this->admin->generate_menu('extensions'),
				'errors' => $errors,
				'extensions' => $extensions,
				'form_action' => $this->registry->get('\links')->aura_link($this->rewrite->url['admin_extensions']),
				'csrf_token' => $this->registry->get('\auth\csrf')->generate('admin_extensions'),
			)
		);
	}

	/**
	 * Install a new extension
	 */
	public function install()
	{
		$this->configure_page();

		$errors = array();
		$file = isset($_GET['file']) ? utf8_trim($_GET['file']) : '';
		if (!file_exists(config::EXTENSIONS_DIR.$file.'.xml'))
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'));

		$data = array(
			':id' => $file,
		);

		$ps = $this->db->select('extensions', 1, $data, 'id=:id');
		if ($ps->rowCount())
			$this->registry->get('\handlers\message')->show($this->lang->t('Extension already installed'));

		$content = file_get_contents(config::EXTENSIONS_DIR.$file.'.xml');
		$extension = $this->registry->get('\xml\convert')->fetch_array($content);

		list ($extension, $errors) = $this->registry->get('\admin\extension')->validate($extension, $errors);

		if (isset($_POST['form_sent']) && empty($errors))
			$this->install_extension($extension, $file);

		$warnings = array();
		$versions = explode(',', $extension['supported_versions']);
		if (!in_array($this->config['o_cur_version'], $versions))
			$warnings[] = $this->lang->t('Version warning', $this->config['o_cur_version'], $extension['supported_versions']);

		$id = sha1($content); // Make sure this extension is 'aura approved'
		$content = @file_get_contents('https://www.get-aura.org/resources/extensions/check/'.$id);
		if (!$content || !aura_hash_equals($content, $id))
			$warnings[] = $this->lang->t('Extension not approved warning');

		$tpl = $this->template->load('admin/install_extension.tpl');
		$this->template->output($tpl,
			array(
				'admin_menu' => $this->admin->generate_menu('extensions'),
				'form_action' => $this->registry->get('\links')->aura_link($this->rewrite->url['install_extension'],  array($file)),
				'csrf_token' => $this->registry->get('\auth\csrf')->generate('admin_extensions'),
				'extension' => $extension,
				'warnings' => $warnings,
				'errors' => $errors,
			)
		);
	}

	/**
	 * Uninstall a new extension
	 */
	public function uninstall()
	{
		$this->configure_page();

		$file = isset($_GET['file']) ? utf8_trim($_GET['file']) : '';
		if (!file_exists(config::EXTENSIONS_DIR.$file.'.xml'))
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'));

		$data = array(
			':id' => $file,
		);

		$ps = $this->db->select('extensions', 'uninstall, uninstall_note', $data, 'id=:id');
		if (!$ps->rowCount())
			$this->registry->get('\handlers\message')->show($this->lang->t('Extension not installed'));

		$extension = $ps->fetch();

		if (isset($_POST['form_sent']))
			$this->uninstall_extension($extension, $file);

		$tpl = $this->template->load('admin/uninstall_extension.tpl');
		$this->template->output($tpl,
				array(
					'admin_menu' => $this->admin->generate_menu('admin_extensions'),
					'extension' => $extension,
					'form_action' => $this->registry->get('\links')->aura_link($this->rewrite->url['uninstall_extension'],  array($file)),
					'csrf_token' => $this->registry->get('\auth\csrf')->generate('admin_extensions'),
				)
			);
	}

	/**
	 * Uninstall the extension from the forum
	 */
	protected function uninstall_extension($extension, $file)
	{
		$this->registry->get('\auth\csrf')->confirm('admin_extensions');

		$data = array(
			'id' => $file,
		);

		$this->db->delete('extensions', 'id=:id', $data);
		$this->db->delete('extension_code', 'extension_id=:id', $data);

		$uninstall = unserialize($extension['uninstall']);
		if (!empty($uninstall['files']))
		{
			foreach ($uninstall['files'] as $file)
			{
				if ($file['type'] == 'template')
					@unlink(AURA_ROOT.'include/extensions/'.$uninstall['plugin_folder'].'/templates/'.$file['file']);
				else if ($file['type'] == 'dependency')
					@unlink(AURA_ROOT.'include/extensions/'.$uninstall['plugin_folder'].'/include/'.$file['file']);
				else if ($file['type'] == 'language')
				{
					@unlink(AURA_ROOT.'include/extensions/'.$uninstall['plugin_folder'].'/languages/'.$file['iso'].'/'.$file['file']);

					// Check if there are any more files within this language ISO folder
					$files = array_diff(scandir(AURA_ROOT.'include/extensions/'.$uninstall['plugin_folder'].'/languages/'.$file['iso']), array('.', '..'));
					if (empty($files))
						@rmdir(AURA_ROOT.'include/extensions/'.$uninstall['plugin_folder'].'/languages/'.$file['iso']);
				}
				else
					@unlink(config::PLUGINS_DIR.$file['file']);
			}

			@rmdir(AURA_ROOT.'include/extensions/'.$uninstall['plugin_folder'].'/templates');
			@rmdir(AURA_ROOT.'include/extensions/'.$uninstall['plugin_folder'].'/languages');
			@rmdir(AURA_ROOT.'include/extensions/'.$uninstall['plugin_folder'].'/include');
			@rmdir(AURA_ROOT.'include/extensions/'.$uninstall['plugin_folder']);

			// We also want to check if there are no other extension folders which exist on the server
			$files = array_diff(scandir(AURA_ROOT.'include/extensions'), array('.', '..'));
			if (empty($files))
				@rmdir(AURA_ROOT.'include/extensions');
		}

		eval($uninstall['code']);

		$this->cache->generate('extensions');
		$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['admin_extensions']), $this->lang->t('Extension uninstalled redirect'));		
	}

	/**
	 * Enable an extension
	 */
	public function enable()
	{
		$this->configure_page();

		$this->flip_extension_state(1, $this->lang->t('Extension enabled redirect'));
	}

	/**
	 * Disable an extension
	 */
	public function disable()
	{
		$this->configure_page();

		$this->flip_extension_state(0, $this->lang->t('Extension disabled redirect'));
	}

	/**
	 * Flip the state of an extension, i.e. enable or disable it
	 */
	protected function flip_extension_state($action, $redirect_lang)
	{
		$file = isset($_GET['file']) ? utf8_trim($_GET['file']) : '';
		$data = array(
			':id' => $file,
		);

		$ps = $this->db->select('extensions', 1, $data, 'id=:id');
		if (!$ps->rowCount())
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'));

		$update = array(
			'enabled' => $action,
		);

		$this->db->update('extensions', $update, 'id=:id', $data);
		
		$this->cache->generate('extensions');
		$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['admin_extensions']), $redirect_lang);
	}

	/**
	 * Install the new extension on the forum
	 */
	protected function install_extension($extension, $file)
	{
		$this->registry->get('\auth\csrf')->confirm('admin_extensions');

		// Insert all the hooks
		foreach ($extension['hooks']['hook'] as $hook)
		{
			$insert = array(
				'extension_id' => $file,
				'hook' => $hook['attributes']['id'],
				'code' => utf8_trim($hook['content']),
			);

			$this->db->insert('extension_code', $insert);
		}

		// Are we installing templates
		if (isset($extension['plugin_folder']))
		{
			if (!is_dir(AURA_ROOT.'include/extensions'))
				@mkdir(AURA_ROOT.'include/extensions', 0755);

			@mkdir(AURA_ROOT.'include/extensions/'.$extension['plugin_folder'], 0755);
		}

		$files = array();

		// Install templates if they exist
		if (isset($extension['install']['templates']))
		{
			@mkdir(AURA_ROOT.'include/extensions/'.$extension['plugin_folder'].'/templates', 0755);
			foreach ($extension['install']['templates']['template'] as $template)
			{
				$fh = @fopen(AURA_ROOT.'include/extensions/'.$extension['plugin_folder'].'/templates/'.$template['attributes']['id'], 'wb');
				if ($fh)
				{
					fwrite($fh, utf8_trim($template['content']));
					fclose($fh);

					@chmod(AURA_ROOT.'include/extensions/'.$extension['plugin_folder'].'/templates/'.$template['attributes']['id'], 0644);
					$files[] = array('type' => 'template', 'file' => $template['attributes']['id']);
				}
			}
		}

		// Install languages if they exist
		if (isset($extension['install']['languages']))
		{
			@mkdir(AURA_ROOT.'include/extensions/'.$extension['plugin_folder'].'/languages', 0755);
			foreach ($extension['install']['languages']['language'] as $this->language)
			{
				// If this language ISO directory doesn't already exist, we create it
				if (!is_dir(AURA_ROOT.'include/extensions/'.$extension['plugin_folder'].'/languages/'.$this->language['attributes']['iso']))
					@mkdir(AURA_ROOT.'include/extensions/'.$extension['plugin_folder'].'/languages/'.$this->language['attributes']['iso']);

				$fh = @fopen(AURA_ROOT.'include/extensions/'.$extension['plugin_folder'].'/languages/'.$this->language['attributes']['iso'].'/'.$this->language['attributes']['id'], 'wb');
				if ($fh)
				{
					fwrite($fh, utf8_trim($this->language['content']));
					fclose($fh);

					@chmod(AURA_ROOT.'include/extensions/'.$extension['plugin_folder'].'/languages/'.$this->language['attributes']['iso'].'/'.$this->language['attributes']['id'], 0644);
					$files[] = array('type' => 'language', 'file' => $this->language['attributes']['id'], 'iso' => $this->language['attributes']['iso']);
				}
			}
		}

		// Install files if they exist
		if (isset($extension['install']['files']))
		{
			@mkdir(AURA_ROOT.'include/extensions/'.$extension['plugin_folder'].'/include', 0755);
			foreach ($extension['install']['files']['file'] as $file)
			{
				$fh = @fopen(AURA_ROOT.'include/extensions/'.$extension['plugin_folder'].'/include/'.$file['attributes']['name'], 'wb');
				if ($fh)
				{
					fwrite($fh, utf8_trim($file['content']));
					fclose($fh);

					@chmod(AURA_ROOT.'include/extensions/'.$extension['plugin_folder'].'/include/'.$file['attributes']['name'], 0644);
					$files[] = array('type' => 'dependency', 'file' => $file['attributes']['name']);
				}
			}
		}

		// Install plugins if they exist
		if (isset($extension['install']['plugins']))
		{
			foreach ($extension['install']['plugins']['plugin'] as $plugin)
			{
				$fh = @fopen(config::PLUGINS_DIR.$plugin['attributes']['id'], 'wb');
				if ($fh)
				{
					fwrite($fh, utf8_trim($plugin['content']));
					fclose($fh);

					@chmod(config::PLUGINS_DIR.$plugin['attributes']['id'], 0644);
					$files[] = array('type' => 'plugin', 'file' => $plugin['attributes']['id']);
				}
			}
		}

		$uninstall = array(
			'code' => (isset($extension['uninstall']['execute']) ? utf8_trim($extension['uninstall']['execute']) : ''),
			'plugin_folder' => $extension['plugin_folder'],
			'files' => $files,
		);

		$insert = array(
			'id' => $file,
			'title' => $extension['title'],
			'version' => $extension['version'],
			'description' => $extension['description'],
			'author' => $extension['author'],
			'uninstall_note' => (isset($extension['uninstall']['note']) ? utf8_trim($extension['uninstall']['note']) : ''),
			'uninstall' => serialize($uninstall),
			'enabled' => isset($_POST['enable']) ? 1 : 0,
		);

		$this->db->insert('extensions', $insert);
		$extension_id = $this->db->lastInsertId($this->db->prefix.'extensions');

		if (isset($extension['install']['execute']))
			eval($extension['install']['execute']);

		$this->cache->generate('extensions');
		$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['admin_extensions']), $this->lang->t('Extension installed redirect'));		
	}

	/**
	 * Fetches a list of all extensions which are installed or available for install
	 */
	protected function fetch_extensions()
	{
		$extensions = array();
		$ps = $this->db->select('extensions', 'id, title, enabled');
		foreach ($ps as $cur_extension)
			$extensions[$cur_extension['id']] = $cur_extension;

		$result = array();
		$xml_files = array_diff(scandir(config::EXTENSIONS_DIR), array('.', '..', '.htaccess'));
		foreach ($xml_files as $entry)
		{
			if (substr($entry, -4) == '.xml')
			{
				if (isset($extensions[substr($entry, 0, -4)])) // Then this is installed already
				{
					$extension = $extensions[substr($entry, 0, -4)];
					$result[] = array(
						'title' => $extension['title'],
						'status' => $extension['enabled'],
						'installed' => true,
						'status_link' => ($extension['enabled']) ? $this->registry->get('\links')->aura_link($this->rewrite->url['disable_extension'],  array($extension['id'])) : $this->registry->get('\links')->aura_link($this->rewrite->url['enable_extension'],  array($extension['id'])),
						'uninstall_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['uninstall_extension'], array($extension['id'])),
					);
				}
				else
				{
					$result[] = array(
						'title' => str_replace('-', ' ', substr($entry, 0, -4)),
						'status' => -1,
						'installed' => false,
						'install_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['install_extension'], array(substr($entry, 0, -4))),
					);
				}
			}
		}

		return $result;
	}

	/**
	 * Upload a new extension to be ready for install
	 */
	protected function upload_extension()
	{
		$this->registry->get('\auth\csrf')->confirm('admin_extensions');

		if (!isset($_FILES['req_file']))
			$this->registry->get('\handlers\message')->show($this->lang->t('No file'));

		$uploaded_file = $_FILES['req_file'];

		// Make sure the upload went smooth
		if (isset($uploaded_file['error']))
		{
			switch ($uploaded_file['error'])
			{
				case 1:	// UPLOAD_ERR_INI_SIZE
				case 2:	// UPLOAD_ERR_FORM_SIZE
					$this->registry->get('\handlers\message')->show($this->lang->t('Too large ini'));
				break;
				case 3:	// UPLOAD_ERR_PARTIAL
					$this->registry->get('\handlers\message')->show($this->lang->t('Partial upload'));
				break;
				case 4:	// UPLOAD_ERR_NO_FILE
					$this->registry->get('\handlers\message')->show($this->lang->t('No file'));
				break;
				case 6:	// UPLOAD_ERR_NO_TMP_DIR
					$this->registry->get('\handlers\message')->show($this->lang->t('No tmp directory'));
				break;
				default:
					// No error occured, but was something actually uploaded?
					if ($uploaded_file['size'] == 0)
						$this->registry->get('\handlers\message')->show($this->lang->t('No file'));
				break;
			}
		}

		$filename = $uploaded_file['name'];
		if (!is_uploaded_file($uploaded_file['tmp_name']))
			$errors[] = $this->lang->t('Unknown failure');
		else if (!preg_match('/^[a-z0-9-]+\.xml$/i', $uploaded_file['name']))
			$errors[] = $this->lang->t('Bad type');
		else if (file_exists(config::EXTENSIONS_DIR.$filename)) // Make sure there is no file already under this name
			$errors[] = $this->lang->t('Extension exists', $filename);
		else if (!@move_uploaded_file($uploaded_file['tmp_name'], config::EXTENSIONS_DIR.$filename)) // Move the file to the extensions directory.
		{
			$errors[] = $this->lang->t('Move failed');
			@unlink(config::EXTENSIONS_DIR.$filename);
		}

		if (empty($errors))
		{
			@chmod(config::EXTENSIONS_DIR.$filename, 0644);		
			$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['admin_extensions']), $this->lang->t('Extension uploaded redirect'));
		}
	}

	/**
	 * Configure the page and setup a few commonly used things
	 */
	protected function configure_page()
	{
		$this->admin = new \admin\common($this->registry);

		if (!$this->user['is_admin'])
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		$this->admin->check_user('admin_extensions');

		$this->registry->get('\auth\http_auth')->check_authentication();

		// Load the admin-extensions language file
		$this->lang->load('admin_extensions');

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Admin'), $this->lang->t('Extensions')),
			'active_page' => 'admin',
			'admin_console' => true,
		);

		$this->template->footer = array(
			'admin_console' => true,
		);
	}
}