<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class restrictions_controller extends base_controller
{
	/**
	 * Main app entry point, we show the main form
	 */
	public function execute()
	{
		$this->configure_page();

		if (count($this->cache->get('admins')) < 2)
			$this->registry->get('\handlers\message')->show($this->lang->t('No administrators available'));

		list ($administrators, $restricted) = $this->fetch_administrators();

		$tpl = $this->template->load('admin/restrictions.tpl');
		$this->template->output($tpl,
			array(
				'admin_menu' => $this->admin->generate_menu('restrictions'),
				'csrf_token' => $this->registry->get('\auth\csrf')->generate('admin_restrictions'),
				'add_action' => $this->registry->get('\links')->aura_link($this->rewrite->url['add_restrictions']),
				'edit_action' => $this->registry->get('\links')->aura_link($this->rewrite->url['edit_restrictions']),
				'delete_action' => $this->registry->get('\links')->aura_link($this->rewrite->url['delete_restrictions']),
				'restrictions' => $restricted,
				'administrators' => $administrators,
			)
		);
	}

	/**
	 * Configure the page and setup a few commonly used things
	 */
	public function configure_page()
	{
		$this->admin = new \admin\common($this->registry);

		if (!$this->user['is_admin'])
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		$this->admin->check_user('admin_restrictions');

		$this->registry->get('\auth\http_auth')->check_authentication();

		// Load the admin-restrictions language file
		$this->lang->load('admin_restrictions');

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Admin'), $this->lang->t('Restrictions')),
			'active_page' => 'admin',
			'admin_console' => true,
		);

		$this->template->footer = array(
			'admin_console' => true,
		);
	}

	/**
	 * Delete some restrictions
	 */
	public function delete()
	{
		$this->configure_page();

		$user = isset($_POST['user']) ? intval($_POST['user']) : 0;
		$data = array(
			':id' => $user,
		);

		$ps = $this->db->select('users', 'username, group_id', $data, 'id=:id');
		if (!$ps->rowCount())
			$this->registry->get('\handlers\message')->show($this->lang->t('No restrictions'));

		list($username, $group_id) = $ps->fetch(PDO::FETCH_NUM);

		$groups = $this->cache->get('groups');
		if ($groups[$group_id]['g_admin'] != '1' && $group_id != AURA_ADMIN)
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'));

		if (isset($_POST['delete_restrictions']))
			$this->delete_restrictions();

		$tpl = $this->template->load('admin/delete_restrictions.tpl');
		$this->template->output($tpl,
			array(
				'admin_menu' => $this->admin->generate_menu('restrictions'),
				'form_action' => $this->registry->get('\links')->aura_link($this->rewrite->url['delete_restrictions']),
				'csrf_token' => $this->registry->get('\auth\csrf')->generate('admin_restrictions'),
				'user' => $user,
			)
		);
	}

	/**
	 * Delete a set of restrictions on the forum
	 */
	public function delete_restrictions()
	{
		$this->registry->get('\auth\csrf')->confirm('admin_restrictions');

		$user = isset($_POST['user']) ? intval($_POST['user']) : 0;
		$data = array(
			':id' => $user,
		);

		$ps = $this->db->select('restrictions', 1, $data, 'admin_id=:id');

		if (!$ps->rowCount())
			$this->registry->get('\handlers\message')->show($this->lang->t('No restrictions'));

		$this->db->delete('restrictions', 'admin_id=:id', $data);

		$this->cache->generate('restrictions');
		$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['admin_restrictions']), $this->lang->t('Removed redirect'));
	}

	/**
	 * Add a new set of restrictions
	 */
	public function add()
	{
		$this->configure_page();

		$user = isset($_POST['user']) ? intval($_POST['user']) : 0;
		$data = array(
			':id' => $user,
		);

		$ps = $this->db->select('users', 'username, group_id', $data, 'id=:id');
		if (!$ps->rowCount())
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'));

		list($username, $group_id) = $ps->fetch(PDO::FETCH_NUM);

		$groups = $this->cache->get('groups');
		if ($groups[$group_id]['g_admin'] != '1' && $group_id != AURA_ADMIN)
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'));

		if (isset($_POST['restrictions']))
			$this->add_restrictions();

		$restrictions[$user] = array(
			'admin_options' => 1,
			'admin_permissions' => 1,
			'admin_categories' => 1,
			'admin_forums' => 1,
			'admin_groups' => 1,
			'admin_censoring' => 1,
			'admin_maintenance' => 1,
			'admin_plugins' => 1,
			'admin_restrictions' => 1,
			'admin_users' => 1,
			'admin_moderate' => 1,
			'admin_ranks' => 1,
			'admin_updates' => 1,
			'admin_archive' => 1,
			'admin_smilies' => 1,
			'admin_warnings' => 1,
			'admin_attachments' => 1,
			'admin_robots' => 1,
			'admin_extensions' => 1,
			'admin_tasks' => 1,
		);

		$tpl = $this->template->load('admin/modify_restrictions.tpl');
		$this->template->output($tpl,
			array(
				'admin_menu' => $this->admin->generate_menu('restrictions'),
				'admin' => $restrictions[$user],
				'user' => $user,
				'csrf_token' => $this->registry->get('\auth\csrf')->generate('admin_restrictions'),
				'form_action' => $this->registry->get('\links')->aura_link($this->rewrite->url['add_restrictions']),
				'username' => $username,
			)
		);
	}

	/**
	 * Entry point for editing a set of restrictions
	 */
	public function edit()
	{
		$this->configure_page();

		$user = isset($_POST['user']) ? intval($_POST['user']) : 0;
		$data = array(
			':id' => $user,
		);

		$ps = $this->db->select('users', 'username, group_id', $data, 'id=:id');
		if (!$ps->rowCount())
			$this->registry->get('\handlers\message')->show($this->lang->t('No restrictions'));

		list($username, $group_id) = $ps->fetch(PDO::FETCH_NUM);

		$groups = $this->cache->get('groups');
		if ($groups[$group_id]['g_admin'] != '1' && $group_id != AURA_ADMIN)
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'));

		if (isset($_POST['restrictions']))
			$this->edit_restrictions();

		$tpl = $this->template->load('admin/modify_restrictions.tpl');
		$this->template->output($tpl,
			array(
				'admin_menu' => $this->admin->generate_menu('restrictions'),
				'admin' => $this->admin->fetch_restrictions($user),
				'user' => $user,
				'csrf_token' => $this->registry->get('\auth\csrf')->generate('admin_restrictions'),
				'form_action' => $this->registry->get('\links')->aura_link($this->rewrite->url['edit_restrictions']),
				'username' => $username,
			)
		);
	}

	/**
	 * Edit an existing set of restrictions on the forum
	 */
	public function edit_restrictions()
	{
		$this->registry->get('\auth\csrf')->confirm('admin_restrictions');

		list($restrictions, $user) = $this->validate_restrictions();

		$update = array(
			'admin_id' => $user,
			'restrictions' => serialize($restrictions),
		);

		$data = array(
			':id' => $user,
		);

		$this->db->update('restrictions', $update, 'admin_id=:id', $data);

		$this->cache->generate('restrictions');
		$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['admin_restrictions']), $this->lang->t('Edited redirect'));
	}

	/**
	 * Add a new set of restrictions to the forum
	 */
	protected function add_restrictions()
	{
		$this->registry->get('\auth\csrf')->confirm('admin_restrictions');

		list($restrictions, $user) = $this->validate_restrictions();

		$insert = array(
			'admin_id'	=> $user,
			'restrictions' => serialize($restrictions),
		);

		$this->db->insert('restrictions', $insert);

		$this->cache->generate('restrictions');
		$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['admin_restrictions']), $this->lang->t('Added redirect'));
	}

	/**
	 * Validate a set of submitted restrictions
	 */
	protected function validate_restrictions()
	{
		$user = isset($_POST['user']) ? intval($_POST['user']) : 0;
		if ($user < 2)
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request1'));

		$board_config = isset($_POST['board_config']) ? intval($_POST['board_config']) : '1';
		$board_perms = isset($_POST['board_perms']) ? intval($_POST['board_perms']) : '1';	
		$board_cats = isset($_POST['board_cats']) ? intval($_POST['board_cats']) : '1';
		$board_forums = isset($_POST['board_forums']) ? intval($_POST['board_forums']) : '1';	
		$board_groups = isset($_POST['board_groups']) ? intval($_POST['board_groups']) : '1';
		$board_users = isset($_POST['board_users']) ? intval($_POST['board_users']) : '1';
		$board_censoring = isset($_POST['board_censoring']) ? intval($_POST['board_censoring']) : '1';
		$board_ranks = isset($_POST['board_ranks']) ? intval($_POST['board_ranks']) : '1';
		$board_moderate = isset($_POST['board_moderate']) ? intval($_POST['board_moderate']) : '1';
		$board_maintenance = isset($_POST['board_maintenance']) ? intval($_POST['board_maintenance']) : '0';
		$board_plugins = isset($_POST['board_plugins']) ? intval($_POST['board_plugins']) : '1';
		$board_restrictions = isset($_POST['board_restrictions']) ? intval($_POST['board_restrictions']) : '0';
		$board_updates = isset($_POST['board_updates']) ? intval($_POST['board_updates']) : '0';
		$board_archive = isset($_POST['board_archive']) ? intval($_POST['board_archive']) : '1';
		$board_smilies = isset($_POST['board_smilies']) ? intval($_POST['board_smilies']) : '1';
		$board_warnings = isset($_POST['board_warnings']) ? intval($_POST['board_warnings']) : '1';
		$board_attachments = isset($_POST['board_attachments']) ? intval($_POST['board_attachments']) : '1';
		$board_robots = isset($_POST['board_robots']) ? intval($_POST['board_robots']) : '1';
		$board_extensions = isset($_POST['board_addons']) ? intval($_POST['board_addons']) : '1';
		$board_tasks = isset($_POST['board_tasks']) ? intval($_POST['board_tasks']) : '1';

		$data = array(
			':id'	=>	$user,
			':admin' => AURA_ADMIN,
		);

		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'groups',
				'as' => 'g',
				'on' => 'u.group_id=g.g_id',
			),
		);

		$ps = $this->db->join('users', 'u', $join, 1, $data, 'u.group_id=:id OR g.g_admin=1 OR g.g_id=:admin');
		if (!$ps->rowCount())
			$this->registry->get('\handlers\message')->show($this->lang->t('No user'));

		$data = array(
			':id' => $user,
		);

		$restrictions = array(
			'admin_options' => $board_config,
			'admin_permissions' => $board_perms,
			'admin_categories' => $board_cats,
			'admin_forums' => $board_forums,
			'admin_groups' => $board_groups,
			'admin_censoring' => $board_censoring,
			'admin_maintenance' => $board_maintenance,
			'admin_plugins' => $board_plugins,
			'admin_restrictions' => $board_restrictions,
			'admin_users' => $board_users,
			'admin_moderate' => $board_moderate,
			'admin_ranks' => $board_ranks,
			'admin_updates' => $board_updates,
			'admin_archive' => $board_archive,
			'admin_smilies' => $board_smilies,
			'admin_warnings' => $board_warnings,
			'admin_attachments' => $board_attachments,
			'admin_robots' => $board_robots,
			'admin_extensions' => $board_extensions,
			'admin_tasks' => $board_tasks,
		);

		return array($restrictions, $user);
	}

	/**
	 * Fetch the board administrators so we can issue restrictions
	 */
	protected function fetch_administrators()
	{
		$data = array(
			':admin' => AURA_ADMIN,
		);

		$join = array(
			array(
				'type' => 'LEFT',
				'table' => 'restrictions',
				'as' => 'ar',
				'on' => 'u.id=ar.admin_id',
			),
			array(
				'type' => 'INNER',
				'table' => 'groups',
				'as' => 'g',
				'on' => 'u.group_id=g.g_id',
			),
		);

		$administrators = $restricted = array();
		$ps = $this->db->join('users', 'u', $join, 'u.username, u.id', $data, '(u.group_id=:admin OR g.g_admin=1) AND u.id!=2 AND ar.admin_id IS NULL', 'u.id ASC');
		foreach ($ps as $admin)
			$administrators[] = array('id' => $admin['id'], 'username' => $admin['username']);

		$ps = $this->db->join('users', 'u', $join, 'u.username, u.id', $data, '(u.group_id=:admin OR g.g_admin=1) AND u.id!=2 AND ar.admin_id IS NOT NULL', 'u.id ASC');
		foreach ($ps as $admin)
			$restricted[] = array('id' => $admin['id'], 'username' => $admin['username']);

		return array($administrators, $restricted);
	}
}