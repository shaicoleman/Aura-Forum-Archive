<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class smilies_controller extends base_controller
{
	/**
	 * Main app entry point
	 */
	public function execute()
	{
		$admin = new \admin\common($this->registry);

		if (!$this->user['is_admin'])
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		$admin->check_user('admin_smilies');

		$this->registry->get('\auth\http_auth')->check_authentication();

		// Load the admin-smilies language file
		$this->lang->load('admin_smilies');

		$smiley_path = ($this->config['o_smilies_dir'] != '') ? $this->config['o_smilies_path'] : AURA_ROOT.$this->config['o_smilies_path'].'/';
		$smiley_dir = ($this->config['o_smilies_dir'] != '') ? $this->config['o_smilies_dir'] : $this->functions->get_base_url().'/'.$this->config['o_smilies_path'].'/';

		// Retrieve the smiley images
		$img_smilies = array_diff(scandir($smiley_path), array('.', '..'));
		@natsort();

		if (isset($_POST['reorder']))
			$this->reorder_smilies();
		else if (isset($_POST['remove'])) // Delete the emoticon codes from the database
			$this->remove_smilies();
		else if (isset($_POST['delete'])) // We're actually removing smiley images from the server
			$this->delete_smilies($smiley_path);
		else if (isset($_POST['add_smiley'])) // Create a new smiley code
			$this->add_smiley();
		else if (isset($_POST['add_image']))  // We're uploading a new image to the server
			$this->upload_smiley();

		// Fetch the Smilies
		list ($emoticons, $options, $smiley_list, $images) = $this->fetch_smilies($smiley_dir, $img_smilies);

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Admin'), $this->lang->t('Smilies')),
			'active_page' => 'admin',
			'admin_console' => true,
		);

		$this->template->footer = array(
			'admin_console' => true,
		);

		$tpl = $this->template->load('admin/smilies.tpl');
		$this->template->output($tpl,
			array(
				'admin_menu' => $admin->generate_menu('smilies'),
				'form_action' => $this->registry->get('\links')->aura_link($this->rewrite->url['admin_smilies']),
				'csrf_token' => $this->registry->get('\auth\csrf')->generate('admin_smilies'),
				'emoticons' => $emoticons,
				'img_smilies' => $img_smilies,
				'options' => $options,
				'smiley_list' => $smiley_list,
				'images' => $images,
			)
		);
	}

	/**
	 * We're removing a smiley emoticon format from the database
	 */
	protected function remove_smilies()
	{
		$this->registry->get('\auth\csrf')->confirm('admin_smilies');

		$smilies = isset($_POST['remove_smilies']) && is_array($_POST['remove_smilies']) ? array_map('intval', $_POST['remove_smilies']) : array();
		if (empty($smilies))
			$this->registry->get('\handlers\message')->show($this->lang->t('No Smileys'));

		$markers = $data = array();
		for ($i = 0; $i < count($smilies); $i++)
			$markers[] = '?';

		// Delete smilies
		$this->db->delete('smilies', 'id IN('.implode(', ', $markers).')', array_values($smilies));

		$this->cache->generate('smilies');
		$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['admin_smilies']), $this->lang->t('Delete Smiley Redirect'));		
	}

	/**
	 * We're actually removing an emoticon itself from the server
	 */
	protected function delete_smilies($smiley_path)
	{
		$this->registry->get('\auth\csrf')->confirm('admin_smilies');

		$del_smilies = isset($_POST['del_smilies']) && is_array($_POST['del_smilies']) ? array_map('aura_trim', $_POST['del_smilies']) : array();
		if (empty($del_smilies))
			$this->registry->get('\handlers\message')->show($this->lang->t('No Images'));

		// Check if the images are being used
		$smilies = $this->cache->get('smilies');
		foreach ($del_smilies as $id => $img)
		{
			$data = array(
				':image' => $img,
			);

			$ps = $this->db->select('smilies', 1, $data, 'image=:image');
			if ($ps->rowCount())
				$this->registry->get('\handlers\message')->show($this->lang->t('Smiley in use', $img));

			// Only remove if it's a valid image
			if (preg_match('/^[a-zA-Z0-9\-_]+\.(png|jpg|jpeg|gif)$/i', $img))
				@unlink($smiley_path.'/'.$img);
		}

		$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['admin_smilies']), $this->lang->t('Images deleted'));
	}

	protected function add_smiley()
	{
		$this->registry->get('\auth\csrf')->confirm('admin_smilies');

		$code = isset($_POST['smiley_code']) ? aura_trim($_POST['smiley_code']) : '';
		$image = isset($_POST['smiley_image']) ? aura_trim($_POST['smiley_image']) : '';

		if ($code == '')
			$this->registry->get('\handlers\message')->show($this->lang->t('Create Smiley Code None'));

		if ($image == '')
			$this->registry->get('\handlers\message')->show($this->lang->t('Create Smiley Image None'));

		$insert = array(
			'image'	=>	$image,
			'code'	=>	$code,
		);

		// Add the smiley
		$this->db->insert('smilies', $insert);
		$this->cache->generate('smilies');
		$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['admin_smilies']), $this->lang->t('Successful Creation'));
	}

	protected function upload_smiley($smiley_path)
	{
		if (!isset($_FILES['req_file']))
			$this->registry->get('\handlers\message')->show($this->lang->t('No file'));

		$uploaded_file = $_FILES['req_file'];

		// Make sure the upload went smooth
		if (isset($uploaded_file['error']))
		{
			switch ($uploaded_file['error'])
			{
				case 1:	// UPLOAD_ERR_INI_SIZE
				case 2:	// UPLOAD_ERR_FORM_SIZE
					$this->registry->get('\handlers\message')->show($this->lang->t('Too large ini'));
				break;
				case 3:	// UPLOAD_ERR_PARTIAL
					$this->registry->get('\handlers\message')->show($this->lang->t('Partial upload'));
				break;
				case 4:	// UPLOAD_ERR_NO_FILE
					$this->registry->get('\handlers\message')->show($this->lang->t('No file'));
				break;
				case 6:	// UPLOAD_ERR_NO_TMP_DIR
					$this->registry->get('\handlers\message')->show($this->lang->t('No tmp directory'));
				break;
				default:
					// No error occured, but was something actually uploaded?
					if ($uploaded_file['size'] == 0)
						$this->registry->get('\handlers\message')->show($this->lang->t('No file'));
				break;
			}
		}

		if (is_uploaded_file($uploaded_file['tmp_name']))
		{
			$filename = substr($uploaded_file['name'], 0, strpos($uploaded_file['name'], '.'));

			// Check types
			$allowed_types = array('image/gif', 'image/jpeg', 'image/pjpeg', 'image/png', 'image/x-png');
			if (!in_array($uploaded_file['type'], $allowed_types))
				$this->registry->get('\handlers\message')->show($this->lang->t('Bad type'));

			// Make sure the file isn't too big
			if ($uploaded_file['size'] > $this->config['o_smilies_size'])
				$this->registry->get('\handlers\message')->show($this->lang->t('Too large').' '.$this->config['o_smilies_size'].' '.$this->lang->t('bytes').'.');

			// Determine type
			$extensions = null;
			if ($uploaded_file['type'] == 'image/gif')
				$extensions = array('.gif', '.jpg', '.png');
			else if ($uploaded_file['type'] == 'image/jpeg' || $uploaded_file['type'] == 'image/pjpeg')
				$extensions = array('.jpg', '.gif', '.png');
			else
				$extensions = array('.png', '.gif', '.jpg');

			// Move the file to the avatar directory. We do this before checking the width/height to circumvent open_basedir restrictions.
			if (!@move_uploaded_file($uploaded_file['tmp_name'], $smiley_path.'/'.$filename.'.tmp'))
				$this->registry->get('\handlers\message')->show($this->lang->t('Move failed'));

			// Now check the width/height
			list($width, $height, $type,) = getimagesize($smiley_path.'/'.$filename.'.tmp');
			if (empty($width) || empty($height) || $width > $this->config['o_smilies_width'] || $height > $this->config['o_smilies_height'])
			{
				@unlink($smiley_path.'/'.$filename.'.tmp');
				$this->registry->get('\handlers\message')->show($this->lang->t('Too wide or high').' '.$this->config['o_smilies_width'].'x'.$this->config['o_smilies_height'].' '.$this->lang->t('pixels').'.');
			}
			else if ($type == 1 && $uploaded_file['type'] != 'image/gif') // Prevent dodgy uploads
			{
				@unlink($smiley_path.'/'.$filename.'.tmp');
				$this->registry->get('\handlers\message')->show($this->lang->t('Bad type'));
			}
		
			// Delete any old images and put the new one in place
			@unlink($smiley_path.'/'.$filename.$extensions[0]);
			@unlink($smiley_path.'/'.$filename.$extensions[1]);
			@unlink($smiley_path.'/'.$filename.$extensions[2]);
			@rename($smiley_path.'/'.$filename.'.tmp', $smiley_path.'/'.$filename.$extensions[0]);

			compress_image($smiley_path.'/'.$filename.$extensions[0]);
			@chmod($smiley_path.'/'.$filename.$extensions[0], 0644);
		}
		else
			$this->registry->get('\handlers\message')->show($this->lang->t('Unknown failure'));
		
		$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['admin_smilies']), $this->lang->t('Successful Upload'));
	}
	/**
	 * Fetch Smilies to list on the page
	 */
	protected function fetch_smilies($smiley_dir, $img_smilies)
	{
		$emoticons = $options = array();
		$ps = $this->db->select('smilies', 'id, image, code, disp_position', array(), '', 'disp_position');
		foreach ($ps as $cur_smiley)
		{
			foreach ($img_smilies as $img)
				$options[$cur_smiley['id']][] = $img;

			$emoticons[] = array(
				'id' => $cur_smiley['id'],
				'disp_position' => $cur_smiley['disp_position'],
				'code' => $cur_smiley['code'],
				'image' => $smiley_dir.$cur_smiley['image'],
				'file' => $cur_smiley['image'],
			);
		}

		$smiley_list = $images = array();
		foreach ($img_smilies as $id => $img)
		{
			$smiley_list[] = array(
				'file' => $img,
				'image' => $smiley_dir.$img,
				'id' => $id,
			);

			$images[] = $img;
		}

		return array($emoticons, $options, $smiley_list, $images);
	}

	protected function reorder_smilies()
	{
		$this->registry->get('\auth\csrf')->confirm('admin_smilies');

		$disp_position = isset($_POST['disp_position']) && is_array($_POST['disp_position']) ? array_map('intval', $_POST['disp_position']) : array();
		$image = isset($_POST['smilies_img']) && is_array($_POST['smilies_img']) ? array_map('utf8_trim', $_POST['smilies_img']) : array();
		$smiley_code = isset($_POST['smilies_code']) && is_array($_POST['smilies_code']) ? array_map('utf8_trim', $_POST['smilies_code']) : array();

		$duplicates = array();
		foreach ($smiley_code as $code)
		{
			if ($code == '')
				$this->registry->get('\handlers\message')->show($this->lang->t('Create Smiley Code None'));

			if (in_array($code, $duplicates))
				$this->registry->get('\handlers\message')->show($this->lang->t('Duplicate smilies code', $code));

			$duplicates[] = $code;
		}

		$ps = $this->db->select('smilies', 'id', array(), '', 'disp_position');
		foreach ($ps as $cur_smiley)
		{
			$update = array(
				'code'	=>	$smiley_code[$cur_smiley['id']],
				'image'	=>	$image[$cur_smiley['id']],
				'disp_position'	=>	$disp_position[$cur_smiley['id']],
			);

			$data = array(
				':id' => $cur_smiley['id'],
			);

			$this->db->update('smilies', $update, 'id=:id', $data);
		}

		$this->cache->generate('smilies');
		$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['admin_smilies']), $this->lang->t('Smilies edited'));
	}
}