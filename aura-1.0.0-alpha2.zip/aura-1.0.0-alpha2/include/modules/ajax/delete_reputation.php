<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class delete_reputation_controller extends base_controller
{
	public function execute()
	{
		if (!$this->user['is_admmod'] && !$this->user['is_admin'] && $this->user['g_access_admin_cp'] == '0')
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'));

		$data = array(
			':id' => $id,
		);

		$join = array(
			array(
				'type' => 'LEFT',
				'table' => 'posts',
				'as' => 'p',
				'on' => 'r.post_id=p.id',
			),
		);

		$ps = $this->db->join('reputation', 'r', $join, 'p.id, p.poster_id, r.vote', $data, 'r.id=:id');
		$cur_post = $ps->fetch();

		$vote = (($vote == '-1') ? '+1' : '-1');
		$data = array(
			':id'	=>	$cur_post['id'],
		);

		$this->db->run('UPDATE '.$this->db->prefix.'posts SET reputation=reputation'.$vote.' WHERE id=:id', $data);
		$data = array(
			':id' => $cur_post['poster_id'],
		);

		$this->db->run('UPDATE '.$this->db->prefix.'users SET reputation=reputation'.$vote.' WHERE id=:id', $data);
		$data = array(
			':id' => $id,
		);

		$this->db->delete('reputation', 'id=:id', $data);

		$this->db->end_transaction();
		header('Location: '.$this->registry->get('\links')->aura_link($this->rewrite->url['profile_'.$section], array(intval($_GET['uid']))));
		exit;
	}
}