<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class blocked_controller extends base_controller
{
	/*
	 * Main class entry point, display the form and handle any actions
	 */
	public function execute()
	{
		$this->configure_pms();

		$errors = array();
		if (isset($_POST['add_block']))
			$errors = $this->add_block($errors);
		else if (isset($_POST['remove']))
			$this->unblock_user();

		$data = array(
			':uid' => $this->user['id'],
		);

		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'users',
				'as' => 'u',
				'on' => 'b.block_id=u.id',
			),
		);

		$users = array();
		$ps = $this->db->join('blocks', 'b', $join, 'b.id, b.block_id, u.username, u.group_id', $data, 'b.user_id=:uid');
		foreach ($ps as $cur_block)
			$users[] = array('name' => $this->functions->colourise_group($cur_block['username'], $cur_block['group_id'], $cur_block['block_id']), 'id' => $cur_block['id']);

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('PM'), $this->lang->t('My blocked')),
			'required_fields' => array('req_username' => $this->lang->t('Username')),
			'focus_element' => array('block', 'req_username'),
			'active_page' => 'pm',
		);

		$tpl = $this->template->load('blocked_users.tpl');
		$this->template->output($tpl,
			array(
				'errors' => $errors,
				'lang' => $this->lang,
				'pm_menu' => $this->registry->get('\messenger\menu')->generate('blocked'),
				'form_action' => $this->registry->get('\links')->aura_link($this->rewrite->url['pms_blocked']),
				'username' => (isset($username)) ? $username : '',
				'users' => $users,
			)
		);
	}

	/*
	 * Configure and setup a few things before we start each action
	 */
	protected function configure_pms()
	{
		if ($this->user['g_read_board'] == '0')
			$this->registry->get('\handlers\message')->show($this->lang->t('No view'), false, '403 Forbidden');

		if ($this->user['is_guest'])
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'));

		if ($this->config['o_private_messaging'] == '0' || $this->user['g_use_pm'] == '0' || $this->user['pm_enabled'] == '0')
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'));

		$this->lang->load('pms');

		// Load the post language file
		$this->lang->load('post');		
	}

	/*
	 * We want to block a new user
	 */
	protected function add_block($errors)
	{
		$username = isset($_POST['req_username']) ? utf8_trim($_POST['req_username']) : '';

		if (utf8_strtolower($username) == utf8_strtolower($this->user['username']))
			$errors[] = $this->lang->t('No block self');

		$data = array(
			':username'	=> $username,
		);

		$ps = $this->db->select('users', 'group_id, id', $data, 'username=:username');
		if (!$ps->rowCount() || $username == $this->lang->t('Guest'))
			$errors[] = $this->lang->t('No user x', $username);
		else
			list($group_id, $uid) = $ps->fetch(PDO::FETCH_NUM);

		if (empty($errors))
		{
			$groups = $this->cache->get('groups');
			if ($groups[$group_id]['g_id'] == '1')
				$errors[] = $this->lang->t('User is admin', $username);
			elseif ($groups[$group_id]['g_moderator'] == '1')
				$errors[] = $this->lang->t('User is mod', $username);

			$data = array(
				':id' => $uid,
			);

			$ps = $this->db->select('blocks', 1, $data, 'block_id=:id');
			if ($ps->rowCount())
				$errors[] = $this->lang->t('Already blocked');
		}

		if (empty($errors))
		{
			$insert = array(
				'user_id' => $this->user['id'],
				'block_id' => $uid,
			);

			$this->db->insert('blocks', $insert);
			$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['pms_blocked']), $this->lang->t('Block added redirect'));
		}

		return $errors;
	}

	/*
	 * We want to unblock a user
	 */
	protected function unblock_user()
	{
		$id = intval(key($_POST['remove']));
		$data = array(
			':id' => $id,
			':uid' => $this->user['id'],
		);

		// Before we do anything, check we blocked this user
		$ps = $this->db->select('blocks', 1, $data, 'id=:id AND user_id=:uid');
		if (!$ps->rowCount())
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'));

		$this->db->delete('blocks', 'id=:id AND user_id=:uid', $data);
		$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['pms_blocked']), $this->lang->t('Block del redirect'));
	}
}