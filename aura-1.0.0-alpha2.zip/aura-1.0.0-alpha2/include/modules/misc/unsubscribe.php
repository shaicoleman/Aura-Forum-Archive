<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class unsubscribe_controller extends base_controller
{
	/*
	 * Main entry point, unsubscribe to the topic/forum
	 */
	public function execute()
	{
		$this->registry->get('\auth\csrf')->confirm('unsubscribe');
		if ($this->user['is_guest'])
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		$this->lang->load('misc');
		$topic_id = isset($_GET['tid']) ? intval($_GET['tid']) : 0;
		$forum_id = isset($_GET['fid']) ? intval($_GET['fid']) : 0;
		if ($topic_id < 1 && $forum_id < 1)
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		if ($topic_id)
			$this->topic($topic_id);
		else
			$this->forum($forum_id);
	}

	/*
	 * Unsubscribe to a topic
	 */
	protected function topic($topic_id)
	{
		if ($this->config['o_topic_subscriptions'] != '1')
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		$data = array(
			':id' => $topic_id,
		);

		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'forums',
				'as' => 'f',
				'on' => 't.forum_id=f.id',
			),
		);

		$ps = $this->db->join('topics', 't', $join, 't.subject, f.password, f.id AS fid', $data, 't.id=:id');
		if (!$ps->rowCount())
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'));
		else
			$cur_topic = $ps->fetch();

		if ($cur_topic['password'] != '')
			$this->registry->get('\cookie\cookie')->check_forum_login_cookie($cur_topic['fid'], $cur_topic['password']);

		$data = array(
			':id' => $this->user['id'],
			':tid' => $topic_id,
		);

		$ps = $this->db->select('topic_subscriptions', 1, $data, 'user_id=:id AND topic_id=:tid');
		if (!$ps->rowCount())
			$this->registry->get('\handlers\message')->show($this->lang->t('Not subscribed topic'));

		$data = array(
			':id' => $this->user['id'],
			':tid' => $topic_id,
		);

		$this->db->delete('topic_subscriptions', 'user_id=:id AND topic_id=:tid', $data);
		$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['topic'], array($topic_id, \url\url::replace($cur_topic['subject']))), $this->lang->t('Unsubscribe redirect'));
	}

	/*
	 * Unsubscribe to a forum
	 */
	protected function forum($forum_id)
	{
		if ($this->config['o_forum_subscriptions'] != '1')
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');
		
		$data = array(
			':id' => $forum_id
		);

		$ps = $this->db->select('forums', 'forum_name, password', $data, 'id=:id');
		if (!$ps->rowCount())
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'));
		else
			$cur_forum = $ps->fetch();

		if ($cur_forum['password'] != '')
			$this->registry->get('\cookie\cookie')->check_forum_login_cookie($forum_id, $cur_forum['password']);

		$data = array(
			':id' => $this->user['id'],
			':fid' => $forum_id,
		);

		$ps = $this->db->select('forum_subscriptions', 1, $data, 'user_id=:id AND forum_id=:fid');
		if (!$ps->rowCount())
			$this->registry->get('\handlers\message')->show($this->lang->t('Not subscribed forum'));
		
		$data = array(
			':id' => $this->user['id'],
			':fid' => $forum_id,
		);

		$this->db->delete('forum_subscriptions', 'user_id=:id AND forum_id=:fid', $data);
		$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['forum'], array($forum_id, \url\url::replace($cur_forum['forum_name']))), $this->lang->t('Unsubscribe redirect'));
	}
}