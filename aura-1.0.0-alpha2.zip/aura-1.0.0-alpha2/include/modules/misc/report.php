<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class report_controller extends base_controller
{
	/*
	 * Main entry point, run the report function
	 */
	public function execute()
	{
		$this->lang->load('misc');
		if ($this->user['is_guest'])
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		$post_id = isset($_GET['id']) ? intval($_GET['id']) : 1;
		if ($post_id < 1)
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		$errors = $this->submit_report($post_id);

		// Fetch some info about the post, the topic and the forum
		$cur_post = $this->fetch_post_info($post_id);

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Report post')),
			'required_fields' => array('req_reason' => $this->lang->t('Reason')),
			'focus_element' => array('report', 'req_reason'),
			'active_page' => 'index',
		);

		$tpl = $this->template->load('report.tpl');
		$this->template->output($tpl,
			array(
				'index_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['index']),
				'cur_post' => $cur_post,
				'forum_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['forum'], array($cur_post['fid'], \url\url::replace($cur_post['forum_name']))),
				'post_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['post'], array($post_id)),
				'form_action' => $this->registry->get('\links')->aura_link($this->rewrite->url['report'], array($post_id)),
				'csrf_token' => $this->registry->get('\auth\csrf')->generate('report'),
				'errors' => $errors,
				'message' => isset($_POST['req_reason']) ? $_POST['req_reason'] : '',
			)
		);
	}

	/*
	 * Submit the report- either via email, internal through the database or both
	 */
	protected function submit_report($post_id)
	{
		$errors = array();
		if (isset($_POST['form_sent']))
		{
			// Make sure they got here from the site
			$this->registry->get('\auth\csrf')->confirm('report');

			// Clean up reason from POST
			$reason = isset($_POST['req_reason']) ? aura_linebreaks(utf8_trim($_POST['req_reason'])) : '';
			if ($reason == '')
				$errors[] = $this->lang->t('No reason');
			else if (strlen($reason) > 65535) // TEXT field can only hold 65535 bytes
				$errors[] = $this->lang->t('Reason too long');

			if ($this->user['last_report_sent'] != '' && (CURRENT_TIMESTAMP - $this->user['last_report_sent']) < $this->user['g_report_flood'] && (CURRENT_TIMESTAMP - $this->user['last_report_sent']) >= 0)
				$errors[] = $this->lang->t('Report flood', $this->user['g_report_flood'], $this->user['g_report_flood'] - (CURRENT_TIMESTAMP - $this->user['last_report_sent']));

			if (empty($errors))
			{
				// Get the topic ID
				$data = array(
					':id' => $post_id,
				);

				$ps = $this->db->select('posts', 'topic_id', $data, 'id=:id');
				if (!$ps->rowCount())
					message($this->lang->t('Bad request'), false, '404 Not Found');

				$topic_id = $ps->fetchColumn();
				$data = array(
					':id' => $topic_id,
				);

				// Get the subject and forum ID
				$join = array(
					array(
						'type' => 'INNER',
						'table' => 'forums',
						'as' => 'f',
						'on' => 't.forum_id=f.id',
					),
				);

				$ps = $this->db->join('topics', 't', $join, 't.subject, t.forum_id, f.forum_name, f.password', $data, 't.id=:id');
				if (!$ps->rowCount())
					$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

				list($subject, $forum_id, $forum_name, $forum_password) = $ps->fetch(PDO::FETCH_NUM);

				if ($forum_password != '')
					$this->registry->get('\cookie\cookie')->check_forum_login_cookie($forum_id, $forum_password);

				// Should we use the internal report handling?
				if ($this->config['o_report_method'] == '0' || $this->config['o_report_method'] == '2')
				{
					$insert = array(
						'post_id'	=>	$post_id,
						'topic_id'	=>	$topic_id,
						'forum_id'	=>	$forum_id,
						'reported_by'	=>	$this->user['id'],
						'created'	=>	CURRENT_TIMESTAMP,
						'message'	=>	$reason,
					);

					$this->db->insert('reports', $insert);
				}

				// Should we email the report?
				if ($this->config['o_report_method'] == '1' || $this->config['o_report_method'] == '2')
				{
					// We send it to the complete mailing-list in one swoop
					if ($this->config['o_mailing_list'] != '')
					{
						$email = new \email\email($this->registry);
						$info = array(
							'subject' => array(
								'<forum_id>' => $forum_id,
								'<topic_subject>' => $subject,
							),
							'message' => array(
								'<username>' => $this->user['username'],
								'<post_url>' => $this->registry->get('\links')->aura_link($this->rewrite->url['post'], array($post_id)),
								'<reason>' => $reason,
							)
						);

						$mail_tpl = $this->registry->get('\email\parser')->parse_email('new_report', $this->user['language'], $info);
						$email->send($this->config['o_mailing_list'], $mail_tpl['subject'], $mail_tpl['message']);
					}
				}

				$update = array(
					'last_report_sent' => CURRENT_TIMESTAMP,
				);

				$data = array(
					':id' => $this->user['id'],
				);

				$this->db->update('users', $update, 'id=:id', $data);
				$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['forum'], array($forum_id, \url\url::replace($forum_name))), $this->lang->t('Report redirect'));
			}
		}

		return $errors;
	}

	/*
	 * Fetch some information about the report prior to loading the form
	 */
	protected function fetch_post_info($post_id)
	{
		$data = array(
			':gid' => $this->user['g_id'],
			':pid' => $post_id,
		);

		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'topics',
				'as' => 't',
				'on' => 't.id=p.topic_id',
			),
			array(
				'type' => 'INNER',
				'table' => 'forums',
				'as' => 'f',
				'on' => 'f.id=t.forum_id',
			),
			array(
				'type' => 'LEFT',
				'table' => 'forum_perms',
				'as' => 'fp',
				'on' => '(fp.forum_id=f.id AND fp.group_id=:gid)',
			),
		);

		$ps = $this->db->join('posts', 'p', $join, 'f.id AS fid, f.forum_name, f.password, f.protected, t.id AS tid, t.subject, t.archived, p.poster_id', $data, '(fp.read_forum IS NULL OR fp.read_forum=1) AND p.id=:pid');
		if (!$ps->rowCount())
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		$cur_post = $ps->fetch();

		if ($cur_post['password'] != '')
			$this->registry->get('\cookie\cookie')->check_forum_login_cookie($cur_post['fid'], $cur_post['password']);

		$moderators = $this->cache->get('moderators');
		if ($cur_post['protected'] == '1' && $this->user['id'] != $cur_post['poster_id'] && $this->user['g_global_moderator'] != 1 && !$this->user['is_admin'] && !isset($moderators[$cur_post['fid']]['u'.$this->user['id']]) && !isset($moderators[$cur_post['fid']]['g'.$this->user['g_id']]))
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		if ($this->config['o_censoring'] == '1')
			$cur_post['subject'] = $this->registry->get('\message\bbcode')->censor_words($cur_post['subject']);

		if ($cur_post['archived'] == '1')
			$this->registry->get('\handlers\message')->show($this->lang->t('Topic archived'));

		return $cur_post;
	}
}