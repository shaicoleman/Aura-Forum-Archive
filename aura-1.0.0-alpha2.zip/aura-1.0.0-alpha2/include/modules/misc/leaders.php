<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class leaders_controller extends base_controller
{
	/*
	 * Main entry point, run the leaders module
	 */
	public function execute()
	{
		if ($this->user['g_read_board'] == '0')
			$this->registry->get('\handlers\message')->show($this->lang->t('No view'), false, '403 Forbidden');
		
		if ($this->user['g_view_users'] == '0')
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		// Load the online language file
		$this->lang->load('online');
		
		$administrators = $this->fetch_administrators();

		$global_moderators = $this->fetch_global_moderators();

		$moderators = $this->fetch_moderators();

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('User list'), $this->lang->t('The team')),
			'active_page' => 'leaders',
		);

		$tpl = $this->template->load('leaders.tpl');
		$this->template->output($tpl,
			array(
				'global_moderators' => $global_moderators,
				'administrators' => $administrators,
				'moderators' => $moderators,
				'action' => $this->registry->get('\links')->aura_link($this->rewrite->url['forum_noid']),
				'location' => $this->registry->get('\links')->aura_link($this->rewrite->url['forum'], array("'+this.options[this.selectedIndex].value)+'", "'+this.options[this.selectedIndex].getAttribute('data-url')+'")),
			)
		);
	}

	/*
	 * Fetches a list of all board administrators
	 */
	protected function fetch_administrators()
	{
		$administrators = array();
		$data = array(
			':admin' => AURA_ADMIN,
		);

		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'groups',
				'as' => 'g',
				'on' => 'u.group_id=g.g_id',
			),
			array(
				'type' => 'LEFT',
				'table' => 'online',
				'as' => 'o',
				'on' => 'o.user_id=u.id',
			),
		);

		$administrators = array();
		$ps = $this->db->join('users', 'u', $join, 'u.id AS id, u.username, u.group_id, o.currently', $data, 'u.group_id=:admin OR g.g_admin=1');
		foreach ($ps as $user_data)
		{
			$administrators[$user_data['id']] = array(
				'username' => $this->functions->colourise_group($user_data['username'], $user_data['group_id'], $user_data['id']),
			);

			if ($this->config['o_users_online'] == '1')
				$administrators[$user_data['id']]['location'] = $this->registry->get('\online')->fetch_user_location($user_data['currently']);
		}

		return $administrators;
	}

	/*
	 * Fetches a list of all board global moderators
	 */
	protected function fetch_global_moderators()
	{
		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'groups',
				'as' => 'g',
				'on' => 'u.group_id=g.g_id',
			),
			array(
				'type' => 'LEFT',
				'table' => 'online',
				'as' => 'o',
				'on' => 'o.user_id=u.id',
			),
		);

		$global_moderators = array();
		$ps = $this->db->join('users', 'u', $join, 'u.id AS id, u.username, u.group_id, o.currently', array(), 'g.g_moderator=1 AND g.g_global_moderator=1 AND g.g_admin=0');
		foreach ($ps as $user_data)
		{
			$global_moderators[$user_data['id']] = array(
				'username' => $this->functions->colourise_group($user_data['username'], $user_data['group_id'], $user_data['id']),
			);

			if ($this->config['o_users_online'] == '1')
				$global_moderators[$user_data['id']]['location'] = $this->registry->get('\online')->fetch_user_location($user_data['currently']);
		}

		return $global_moderators;
	}

	/*
	 * Fetches a list of all board moderators and their respective forums
	 */
	protected function fetch_moderators()
	{
		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'groups',
				'as' => 'g',
				'on' => 'u.group_id=g.g_id',
			),
			array(
				'type' => 'LEFT',
				'table' => 'online',
				'as' => 'o',
				'on' => 'o.user_id=u.id',
			),
		);

		$moderators = array();
		$permissions = $this->cache->get('perms');
		$aura_forums = $this->cache->get('forums');
		$forum_moderators = $this->cache->get('moderators');
		$ps = $this->db->join('users', 'u', $join, 'u.id AS id, u.username, u.group_id, o.currently', array(), 'g.g_moderator=1 AND g.g_global_moderator=0 AND g.g_admin=0');
		foreach ($ps as $user_data)
		{
			$total = 0;
			$forums = array();
			foreach ($aura_forums as $cur_forum)
			{
				if (!isset($permissions[$this->user['g_id'].'_'.$cur_forum['id']]))
					$permissions[$this->user['g_id'].'_'.$cur_forum['id']] = $permissions['_'];

				if (isset($forum_moderators[$cur_forum['id']]['u'.$user_data['id']]) || isset($forum_moderators[$cur_forum['id']]['g'.$user_data['group_id']]) && ($permissions[$this->user['g_id'].'_'.$cur_forum['id']]['read_forum'] == '1' || is_null($permissions[$this->user['g_id'].'_'.$cur_forum['id']]['read_forum'])))
				{
					$forums[] = array('forum_id' => $cur_forum['id'], 'forum_name' => $cur_forum['forum_name'], 'forum_url' => \url\url::replace($cur_forum['forum_name']));
					++$total;
				}
			}

			$moderators[$user_data['id']] = array(
				'username' => $this->functions->colourise_group($user_data['username'], $user_data['group_id'], $user_data['id']),
				'total' => $total,
				'forums' => $forums,
			);

			if ($this->config['o_users_online'] == '1')
				$moderators[$user_data['id']]['location'] = $this->registry->get('\online')->fetch_user_location($user_data['currently']);
		}

		return $moderators;
	}
}