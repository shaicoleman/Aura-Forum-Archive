<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class get_host_controller extends base_controller
{
	/**
	 * Main app entry point, we get the host
	 */
	public function execute()
	{
		if (!$this->user['is_admmod'])
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		if (!isset($_GET['host']))
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		// Is get_host an IP address or a post ID?
		if (@preg_match('%^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$%', $_GET['host']) || @preg_match('%^((([0-9A-Fa-f]{1,4}:){7}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){6}:[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){5}:([0-9A-Fa-f]{1,4}:)?[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){4}:([0-9A-Fa-f]{1,4}:){0,2}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){3}:([0-9A-Fa-f]{1,4}:){0,3}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){2}:([0-9A-Fa-f]{1,4}:){0,4}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){6}((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|(([0-9A-Fa-f]{1,4}:){0,5}:((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|(::([0-9A-Fa-f]{1,4}:){0,5}((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|([0-9A-Fa-f]{1,4}::([0-9A-Fa-f]{1,4}:){0,5}[0-9A-Fa-f]{1,4})|(::([0-9A-Fa-f]{1,4}:){0,6}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){1,7}:))$%', $_GET['host']))
			$ip = $_GET['host'];
		else
		{
			$get_host = intval($_GET['host']);
			if ($get_host < 1)
				$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

			$data = array(
				':id' => $get_host,
			);
			
			$ps = $this->db->select('posts', 'poster_ip', $data, 'id=:id');
			if (!$ps->rowCount())
				$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

			$ip = $ps->fetchColumn();
		}

		// Load the miscellaneous language file
		$this->lang->load('misc');

		$this->registry->get('\handlers\message')->show($this->lang->t('Host info 1', $ip).' | '.$this->lang->t('Host info 2', @gethostbyaddr($ip)));
	}
}