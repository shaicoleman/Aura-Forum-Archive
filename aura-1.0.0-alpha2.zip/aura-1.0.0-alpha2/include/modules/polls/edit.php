<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class edit_controller extends base_controller
{
	/**
	 * Main class entry point- load the form
	 */
	public function execute()
	{
		list($id, $cur_topic, $choices, $options) = $this->configure_poll();

		// Do we have permission to edit this poll?
		if (($cur_topic['poster'] != $this->user['username'] || $this->user['g_edit_polls'] == '0' || $cur_topic['closed'] == '1') && !$is_admmod)
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'));

		$errors = array();
		if (isset($_POST['form_sent']))
			$errors = $this->edit_poll($cur_topic, $id, $choices);

		$fields = array();
		for ($i = 0; $i <= $this->config['o_max_poll_fields']; $i++)
			$fields[] = ((isset($options[$i])) ? $options[$i] : '');
		
		$this->lang->load('post');

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $cur_topic['forum_name'], $cur_topic['subject'], $this->lang->t('Edit poll')),
			'active_page' => 'index',
		);

		$tpl = $this->template->load('edit_poll.tpl');
		$this->template->output($tpl,
			array(
				'form_action' => $this->registry->get('\links')->aura_link($this->rewrite->url['poll_edit'], array($id)),
				'csrf_token' => $this->registry->get('\auth\csrf')->generate('edit_poll'),
				'cur_topic' => $cur_topic,
				'options' => $fields,
				'errors' => $errors,
			)
		);
	}

	/**
	 * Configures the poll and checks a few things
	 */
	protected function configure_poll()
	{
		if ($this->user['g_read_board'] == '0')
			$this->registry->get('\handlers\message')->show($this->lang->t('No view'), false, '403 Forbidden');

		$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
		if ($id < 1)
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'));

		$this->lang->load('poll');

		$cur_topic = $this->fetch_topic_info($id);

		// Is this a redirect forum? In that case, abort!
		if ($cur_topic['redirect_url'] != '' || $cur_topic['question'] == '')
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'));

		if ($cur_topic['password'] != '')
				$this->registry->get('\cookie\cookie')->check_forum_login_cookie($id, $cur_topic['password']);

		$moderators = $this->cache->get('moderators');
		$is_admmod = ($this->user['is_admin'] || ($this->user['g_moderator'] == '1' && $this->user['g_global_moderator'] == '1' || isset($moderators[$cur_topic['fid']]['u'.$this->user['id']]) || isset($moderators[$cur_topic['fid']]['g'.$this->user['g_id']]))) ? true : false;

		$choices = $options = ($cur_topic['options'] != '') ? unserialize($cur_topic['options']) : array();

		if ($cur_topic['archived'] == '1')
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'));

		if (!$is_admmod)
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'));

		return array($id, $cur_topic, $choices, $options);
	}

	/**
	 * Fetches some information about the poll
	 */
	protected function fetch_topic_info($id)
	{
		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'forums',
				'as' => 'f',
				'on' => 'f.id=t.forum_id',
			),
			array(
				'type' => 'INNER',
				'table' => 'polls',
				'as' => 'p',
				'on' => 't.id=p.topic_id',
			),
			array(
				'type' => 'LEFT',
				'table' => 'forum_perms',
				'as' => 'fp',
				'on' => '(fp.forum_id=f.id AND fp.group_id=:gid)',
			),
		);

		$data = array(
			':gid' => $this->user['g_id'],
			':tid' => $id,
		);

		// Fetch some info about the topic and the forum
		$ps = $this->db->join('topics', 't', $join, 'f.forum_name, f.password, f.redirect_url, f.id AS fid, t.archived, t.closed, t.subject, t.poster, t.question, p.type, p.options, p.votes, p.id AS pid', $data, '(fp.read_forum IS NULL OR fp.read_forum=1) AND t.question!=\'\' AND t.id=:tid');
		if (!$ps->rowCount())
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'));
			
		$cur_topic = $ps->fetch();

		return $cur_topic;
	}

	/**
	 * Edit the poll
	 */
	protected function edit_poll($cur_topic, $id, $choices)
	{
		$this->registry->get('\auth\csrf')->confirm('edit_poll');

		$errors = array();
		$question = isset($_POST['req_question']) ? utf8_trim($_POST['req_question']) : '';
		$options = isset($_POST['options']) && is_array($_POST['options']) ? array_map('utf8_trim', $_POST['options']) : array();

		if ($question == '')
			$errors[] = $this->lang->t('No question');
		else if (aura_strlen($question) > 70)
			$errors[] = $this->lang->t('Too long question');
		else if ($this->config['p_subject_all_caps'] == '0' && $this->functions->is_all_uppercase($question) && !$this->user['is_admmod'])
			$errors[] = $this->lang->t('All caps question');

		if (empty($options))
			$errors[] = $this->lang->t('No options');

		$option_data = array();
		for ($i = 0; $i <= $this->config['o_max_poll_fields']; $i++)
		{
			if (!empty($errors))
				break;

			if (aura_strlen($options[$i]) > 55)
				$errors[] = $this->lang->t('Too long option');
			else if ($this->config['p_subject_all_caps'] == '0' && $this->functions->is_all_uppercase($options[$i]) && !$this->user['is_admmod'])
				$errors[] = $this->lang->t('All caps option');
			else if ($options[$i] != '')
				$option_data[] = $options[$i];
		}

		if (count($options) < 2)
			$errors[] = $this->lang->t('Low options');

		if (empty($errors))
		{
			$votes_array = array();
			// Here, we need to check if any options have been removed/updated/changed position, and if so update the options (and their respective votes)
			$votes = ($cur_topic['votes'] != '') ? unserialize($cur_topic['votes']) : array();
			foreach ($votes as $key => $amount)
				$votes_array[utf8_strtolower($choices[$key])] = $key;

			$fixed_keys = array();
			$options_array = array_filter($options);
			foreach ($options_array as $key => $option)
			{
				if (isset($votes_array[utf8_strtolower($option)]))
				{
					$real_key = $votes_array[utf8_strtolower($option)];
					if ($real_key !== $key)
					{
						if (isset($option_data[$real_key]))
						{
							$new_option = $option_data[$real_key];
							if (isset($votes_array[utf8_strtolower($new_option)]))
							{
								$new_key = $votes_array[utf8_strtolower($new_option)];
								if ($new_key !== $real_key && !in_array($key, $fixed_keys))
								{
									$option_data[$real_key] = $new_option;
									$option_data[$key] = $option_data[$key];

									$new_vote = $votes[$key];
									$votes[$key] = $votes[$real_key];
									$votes[$real_key] = $new_vote;

									$fixed_keys[] = $real_key; // Add this to the fixed keys, so we don't reverse it later
								}
							}
							else
							{
								$votes[$key] = $votes[$real_key];
								unset($votes[$real_key]);
							}
						}
					}
				}
			}

			// Now we need to search for votes that belong to answers that have just been removed
			foreach ($votes as $key => $num_votes)
			{
				if (!isset($option_data[$key]))
					unset($votes[$key]);
			}

			$update = array(
				'question' => $question,
			);

			$data = array(
				':id' => $id,
			);

			$this->db->update('topics', $update, 'id=:id', $data);
			$update = array(
				'options' => serialize($option_data),
				'votes' => serialize($votes),
			);

			$data = array(
				':id' => $cur_topic['pid'],
			);
				
			$this->db->update('polls', $update, 'id=:id', $data);
			$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['topic'], array($id, \url\url::replace($cur_topic['subject']))), $this->lang->t('Poll updated redirect'));
		}

		return $errors;
	}
}