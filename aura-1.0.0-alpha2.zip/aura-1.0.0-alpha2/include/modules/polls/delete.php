<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class delete_controller extends base_controller
{
	/**
	 * Main class entry point- load the form
	 */
	public function execute()
	{
		list($id, $cur_topic) = $this->configure_poll();

		// Do we have permission to delete this poll?
		if (($cur_topic['poster'] != $this->user['username'] || $this->user['g_edit_polls'] == '0' || $cur_topic['closed'] == '1') && !$is_admmod)
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'));

		if (isset($_POST['form_sent']))
			$this->delete_poll($cur_topic, $id);

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Delete poll')),
			'active_page' => 'index',
		);

		$tpl = $this->template->load('delete_poll.tpl');
		$this->template->output($tpl,
			array(
				'form_action' => $this->registry->get('\links')->aura_link($this->rewrite->url['poll_delete'], array($id)),
				'csrf_token' => $this->registry->get('\auth\csrf')->generate('delete_poll'),
			)
		);
	}

	/**
	 * Configures the poll and checks a few things
	 */
	protected function configure_poll()
	{
		if ($this->user['g_read_board'] == '0')
			$this->registry->get('\handlers\message')->show($this->lang->t('No view'), false, '403 Forbidden');

		$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
		if ($id < 1)
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'));

		$this->lang->load('poll');

		$cur_topic = $this->fetch_topic_info($id);

		// Is this a redirect forum? In that case, abort!
		if ($cur_topic['redirect_url'] != '' || $cur_topic['question'] == '')
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'));

		if ($cur_topic['password'] != '')
				$this->registry->get('\cookie\cookie')->check_forum_login_cookie($id, $cur_topic['password']);

		$moderators = $this->cache->get('moderators');
		$is_admmod = ($this->user['is_admin'] || ($this->user['g_moderator'] == '1' && $this->user['g_global_moderator'] == '1' || isset($moderators[$cur_topic['fid']]['u'.$this->user['id']]) || isset($moderators[$cur_topic['fid']]['g'.$this->user['g_id']]))) ? true : false;

		if ($cur_topic['archived'] == '1')
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'));

		if (!$is_admmod)
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'));

		return array($id, $cur_topic);
	}

	/**
	 * Fetches some information about the poll
	 */
	protected function fetch_topic_info($id)
	{
		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'forums',
				'as' => 'f',
				'on' => 'f.id=t.forum_id',
			),
			array(
				'type' => 'INNER',
				'table' => 'polls',
				'as' => 'p',
				'on' => 't.id=p.topic_id',
			),
			array(
				'type' => 'LEFT',
				'table' => 'forum_perms',
				'as' => 'fp',
				'on' => '(fp.forum_id=f.id AND fp.group_id=:gid)',
			),
		);

		$data = array(
			':gid' => $this->user['g_id'],
			':tid' => $id,
		);

		// Fetch some info about the topic and the forum
		$ps = $this->db->join('topics', 't', $join, 'f.forum_name, f.password, f.redirect_url, f.id AS fid, t.archived, t.closed, t.subject, t.poster, t.question, p.type, p.options, p.votes, p.id AS pid', $data, '(fp.read_forum IS NULL OR fp.read_forum=1) AND t.question!=\'\' AND t.id=:tid');
		if (!$ps->rowCount())
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'));
			
		$cur_topic = $ps->fetch();

		return $cur_topic;
	}

	protected function delete_poll($cur_topic, $id)
	{
		$this->registry->get('\auth\csrf')->confirm('delete_poll');
		$data = array(
			':id' => $cur_topic['pid'],
		);

		$this->db->delete('polls', 'id=:id', $data);
		$update = array(
			'question' => '',
		);

		$data = array(
			':id' => $id,
		);

		$this->db->update('topics', $update, 'id=:id', $data);

		$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['topic'], array($id, \url\url::replace($cur_topic['subject']))), $this->lang->t('Poll deleted redirect'));
	}
}