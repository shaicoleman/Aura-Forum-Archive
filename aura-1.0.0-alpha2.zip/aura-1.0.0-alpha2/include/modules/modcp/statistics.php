<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class statistics_controller extends base_controller
{
	/**
	 * Main class entry point
	 */
	public function execute()
	{
		$admin = new \admin\common($this->registry);

		if (!$this->user['is_admin'])
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		$this->registry->get('\auth\http_auth')->check_authentication();

		// Load the admin-index language file
		$this->lang->load('admin_index');

		$server_load = $this->fetch_server_load();

		// Get number of current visitors
		$ps = $this->db->select('online', 'COUNT(user_id)', array(), 'idle=0');
		$num_online = $ps->fetchColumn();

		$render = $this->fetch_admin_statistics();

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Admin'), $this->lang->t('Server statistics')),
			'active_page' => 'admin',
			'admin_console' => true,
		);

		$this->template->footer = array(
			'admin_console' => true,
		);

		$tpl = $this->template->load('admin/statistics.tpl');
		$this->template->output($tpl,
			array_merge(
					array(
					'admin_menu' => $admin->generate_menu('index'),
					'server_load' => $server_load,
					'num_online' => $num_online,
					'aura_user' => $this->user,
				), $render
			)
		);
	}

	protected function fetch_server_load()
	{
		// Get the server load averages (if possible)
		if (@file_exists('/proc/loadavg') && is_readable('/proc/loadavg'))
		{
			// We use @ just in case
			$fh = @fopen('/proc/loadavg', 'r');
			$load_averages = @fread($fh, 64);
			@fclose($fh);

			if (($fh = @fopen('/proc/loadavg', 'r')))
			{
				$load_averages = fread($fh, 64);
				fclose($fh);
			}
			else
				$load_averages = '';

			$load_averages = @explode(' ', $load_averages);
			$server_load = isset($load_averages[2]) ? $load_averages[0].' '.$load_averages[1].' '.$load_averages[2] : $this->lang->t('Not available');
		}
		else if (!in_array(PHP_OS, array('WINNT', 'WIN32')) && preg_match('%averages?: ([0-9\.]+),?\s+([0-9\.]+),?\s+([0-9\.]+)%i', @exec('uptime'), $load_averages))
			$server_load = $load_averages[1].' '.$load_averages[2].' '.$load_averages[3];
		else
			$server_load = $this->lang->t('Not available');

		return $server_load;
	}

	/**
	 * Fetch the admin statistics
	 */
	protected function fetch_admin_statistics()
	{
		$render = array();
		if ($this->user['is_admin'])
		{
			// Collect some additional info about MySQL
			$ps = $this->db->run('SHOW TABLE STATUS');
			$total_records = $total_size = 0;
			foreach ($ps as $status)
			{
				$total_records += $status['Rows'];
				$total_size += $status['Data_length'] + $status['Index_length'];
			}

			$total_size = $this->functions->file_size($total_size);

			// Check for the existence of various PHP opcode caches/optimizers
			if (function_exists('mmcache'))
				$php_accelerator = array('url' => $this->lang->t('Turck MMCache link'), 'title' => $this->lang->t('Turck MMCache'));
			else if (isset($_PHPA))
				$php_accelerator = array('url' => $this->lang->t('ionCube PHP Accelerator link'), 'title' => $this->lang->t('ionCube PHP Accelerator'));
			else if (ini_get('apc.enabled'))
				$php_accelerator = array('url' => $this->lang->t('Alternative PHP Cache (APC) link'), 'title' => $this->lang->t('Alternative PHP Cache (APC)'));
			else if (ini_get('zend_optimizer.optimization_level'))
				$php_accelerator = array('url' => $this->lang->t('Zend Optimizer link'), 'title' => $this->lang->t('Zend Optimizer'));
			else if (ini_get('eaccelerator.enable'))
				$php_accelerator = array('url' => $this->lang->t('eAccelerator link'), 'title' => $this->lang->t('eAccelerator'));
			else if (ini_get('xcache.cacher'))
				$php_accelerator = array('url' => $this->lang->t('XCache link'), 'title' => $this->lang->t('XCache'));
			else
				$php_accelerator = $this->lang->t('NA');

			$render = array(
				'PHP_OS' => PHP_OS,
				'php_version' => PHP_VERSION,
				'phpinfo' => $this->registry->get('\links')->aura_link($this->rewrite->url['phpinfo']),
				'php_accelerator' => $php_accelerator,
				'db_version' => $this->db->get_version(),
				'total_records' => $this->functions->forum_number_format($total_records),
				'total_size' => $total_size
			);
		}

		return $render;
	}
}