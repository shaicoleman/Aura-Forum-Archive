<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class index_controller extends base_controller
{
	/**
	 * Main App entry point, we display the index page
	 */
	public function execute()
	{
		$this->configure_page();

		$alerts = $this->fetch_alerts();

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Admin'), $this->lang->t('Index')),
			'active_page' => 'admin',
			'admin_console' => true,
			'jquery' => true,
			'admin_index' => true,
		);

		$this->template->footer = array(
			'admin_console' => true,
		);

		$tpl = $this->template->load('admin/index.tpl');
		$this->template->output($tpl,
			array(
				'admin_menu' => $this->admin->generate_menu('index'),
				'form_action' => $this->registry->get('\links')->aura_link($this->rewrite->url['save_notes'], array($this->registry->get('\auth\csrf')->generate('save_notes'))),
				'upgrade_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['check_upgrade']),
				'stats_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['admin_statistics']),
				'alerts' => $alerts,
			)
		);
	}

	/**
	 * Configure a few commonly used things on the page before we start
	 */
	protected function configure_page()
	{
		$this->admin = new \admin\common($this->registry);

		if (($this->user['is_admmod'] && $this->user['g_mod_cp'] == '0' && !$this->user['is_admin']) || !$this->user['is_admmod'])
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		$this->registry->get('\auth\http_auth')->check_authentication();

		// Load the admin_index language file
		$this->lang->load('admin_index');
	}

	/**
	 * Do we have any upgrades available?
	 */
	public function check_upgrade()
	{
		$this->configure_page();

		$update = $this->cache->generate('updates', array($this->lang, true));
		if (version_compare($this->config['o_cur_version'], $update['version'], '>='))
			$this->registry->get('\handlers\message')->show($this->lang->t('Running latest version message'));

		$this->registry->get('\handlers\message')->show($this->lang->t('New version available message', $update['version']), false, null, true);
	}

	/**
	 * Delete the installation folder
	 */
	public function delete_install()
	{
		$this->configure_page();

		if (!$this->user['is_admin'])
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'));

		$this->registry->get('\auth\csrf')->confirm('delete_install');

		delete_directory(AURA_ROOT.'install');
		delete_directory($this->cache->cache_dir.'templates/install');
		$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['admin_index']), $this->lang->t('Deleted install redirect'));
	}

	/**
	 * Show PHPinfo
	 */
	public function show_phpinfo()
	{
		$this->configure_page();

		// Is phpinfo() a disabled function?
		if (strpos(strtolower((string) ini_get('disable_functions')), 'phpinfo') !== false)
			$this->registry->get('\handlers\message')->show($this->lang->t('PHPinfo disabled message'));

		ob_start();
		phpinfo();
		$phpinfo = trim(ob_get_clean());

		preg_match_all('#<body[^>]*>(.*)</body>#si', $phpinfo, $output);
		if (empty($phpinfo) || empty($output[1][0]))
			$this->registry->get('\handlers\message')->show($this->lang->t('PHPinfo disabled message'));

		$phpinfo = $output[1][0];
		preg_match_all('#<div class="center">(.*)</div>#siU', $phpinfo, $output);

		$this->template->header = array(
			'page_title' => array(),
			'active_page' => 'admin',
			'admin_console' => true,
		);

		$this->template->footer = array(
			'admin_console' => true,
		);

		$tpl = $this->template->load('admin/phpinfo.tpl');
		$this->template->output($tpl,
			array(
				'admin_menu' => $this->admin->generate_menu('index'),
				'phpinfo' => $output[1][0],
			)
		);
	}

	/**
	 * Save the admin notes
	 */
	public function save_notes()
	{
		$this->configure_page();

		if (!defined('AURA_AJAX_REQUEST'))
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'));

		$this->registry->get('\auth\csrf')->confirm('save_notes');

		$notes = isset($_POST['notes']) ? utf8_trim($_POST['notes']) : $this->lang->t('Admin notes');
		$update = array(
			'conf_value' => $notes,
		);

		$this->db->update('config', $update, 'conf_name=\'o_admin_notes\'');
		$this->cache->generate('config', array($this->config));
	}

	/**
	 * Fetch the alerts shown on the dashboard
	 */
	protected function fetch_alerts()
	{
		$alerts = array();
		if ($this->user['is_admin'])
		{
			if (is_dir(AURA_ROOT.'/install'))
				$alerts[] = array('lang' => $this->lang->t('Install directory exists'), 'action_url' => $this->registry->get('\links')->aura_link($this->rewrite->url['delete_install'], array($this->registry->get('\auth\csrf')->generate('delete_install'))), 'action' => $this->lang->t('Delete install directory'));

			if (substr(sprintf('%o', fileperms(AURA_ROOT.'include/config.php')), -4) > 644)
				$alerts[] = array('lang' => $this->lang->t('Config file writable'), 'action_url' => 'https://www.get-aura.org/docs/article/19-configuration-file-is-currently-writable-security-risk-how-to-resolve-problem/', 'action' => $this->lang->t('Change now'));

			$update = $this->cache->get('updates', array($this->lang));
			if (!$update['failed'])
			{
				if (version_compare($this->config['o_cur_version'], $update['version'], '<'))
					$alerts[] = array('lang' => $this->lang->t('New version alert', $update['version']), 'action_url' => $this->registry->get('\links')->aura_link($this->rewrite->url['admin_update']), 'action' => $this->lang->t('Update now'));

				if (file_exists(AURA_ROOT.'include/updates/'.$update['package']))
					$alerts[] = array('lang' => $this->lang->t('Update downloaded', $update['version']), 'action_url' => $this->registry->get('\links')->aura_link($this->rewrite->url['admin_update']), 'action' => $this->lang->t('Install package'));
			}

			foreach ($this->cache->get('admins') as $admin)
			{
				if ($admin == '2') // No restrictions for the original administrator
					continue;

				$data = array(
					':admin' => $admin,
				);

				if (empty($this->admin->fetch_restrictions($admin)))
				{
					$alerts[] = array('lang' => $this->lang->t('No restrictions'), 'action_url' => $this->registry->get('\links')->aura_link($this->rewrite->url['admin_restrictions']), 'action' => $this->lang->t('Configure restrictions'));
					break;
				}
			}

			$avatar_path = ($this->config['o_avatars_dir'] != '') ? $this->config['o_avatars_path'].'/' : AURA_ROOT.$this->config['o_avatars_path'].'/';
			$smiley_path = ($this->config['o_smilies_dir'] != '') ? $this->config['o_smilies_path'].'/' : AURA_ROOT.$this->config['o_smilies_path'].'/';

			if (!forum_is_writable($avatar_path))
				$alerts[] = array('lang' => $this->lang->t('Alert avatar', $avatar_path));

			if (!forum_is_writable($smiley_path))
				$alerts[] = array('lang' => $this->lang->t('Alert smilies', $smiley_path));
		}

		return $alerts;
	}
}