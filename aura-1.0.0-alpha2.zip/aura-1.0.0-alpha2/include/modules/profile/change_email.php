<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class change_email_controller extends base_controller
{
	/**
	 * Main app entry point, we display the form
	 */
	public function execute()
	{
		$profile = new \profile\common($this->registry);
		$id = $profile->fetch_id();

		// Make sure we are allowed to change this user's email
		if ($this->user['id'] != $id)
			$this->change_email();
		else if (isset($_POST['form_sent']))
			$this->send_activation_email();

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Profile'), $this->lang->t('Change email')),
			'required_fields' => array('req_new_email' => $this->lang->t('new \email\email'), 'req_password' => $this->lang->t('Password')),
			'focus_element' => array('change_email', 'req_new_email'),
			'active_page' => 'profile',
		);

		$tpl = $this->template->load('change_email.tpl');
		$this->template->output($tpl,
			array(
				'form_action' => $this->registry->get('\links')->aura_link($this->rewrite->url['change_email'], array($id)),
				'csrf_token' => $this->registry->get('\auth\csrf')->generate('change_email'),
			)
		);
	}

	/**
	 * Change the email and send out the activation email
	 */
	protected function send_activation_email()
	{
		$this->registry->get('\auth\csrf')->confirm('change_email');

		$password = isset($_POST['req_password']) ? utf8_trim($_POST['req_password']) : '';
		if (!aura_hash_equals($this->user['password'], $password.$this->user['salt']))
			$this->registry->get('\handlers\message')->show($this->lang->t('Wrong pass'));

		$email = new \email\email($this->config);

		// Validate the email address
		$new_email = isset($_POST['req_new_email']) ? strtolower(utf8_trim($_POST['req_new_email'])) : '';
		if (!is_valid_email($new_email))
			$this->registry->get('\handlers\message')->show($this->lang->t('Invalid email'));

		// Check if it's a banned email address
		if ($this->registry->get('\auth\bans')->is_banned_email($new_email))
		{
			if ($this->config['p_allow_banned_email'] == '0')
				$this->registry->get('\handlers\message')->show($this->lang->t('Banned email'));
			else if ($this->config['o_mailing_list'] != '')
			{
				$info = array(
					'message' => array(
						'<username>' => $this->user['username'],
						'<email>' => $new_email,
						'<profile_url>' => $this->registry->get('\links')->aura_link($this->rewrite->url['profile_essentials'], array($id)),
					)
				);

				$mail_tpl = $this->registry->get('\email\parser')->parse_email('banned_email_change', $this->user['language'], $info);
				$email->send($this->config['o_mailing_list'], $mail_tpl['subject'], $mail_tpl['message']);
			}
		}

		// Check if someone else already has registered with that email address
		$data = array(
			':email' => $new_email,
		);

		$ps = $this->db->select('users', 'id, username', $data, 'email=:email');
		if ($ps->rowCount())
		{
			if ($this->config['p_allow_dupe_email'] == '0')
				$this->registry->get('\handlers\message')->show($this->lang->t('Dupe email'));
			else if ($this->config['o_mailing_list'] != '')
			{
				$ps->setFetchMode(PDO::FETCH_COLUMN, 0);
				foreach ($ps as $cur_dupe)
					$dupe_list[] = $cur_dupe;

				$info = array(
					'message' => array(
						'<username>' => $this->user['username'],
						'<dupe_list>' => implode(', ', $dupe_list),
						'<profile_url>' => $this->registry->get('\links')->aura_link($this->rewrite->url['profile_essentials'], array($id)),
					)
				);

				$mail_tpl = $this->registry->get('\email\parser')->parse_email('dupe_email_change', $this->user['language'], $info);
				$email->send($this->config['o_mailing_list'], $mail_tpl['subject'], $mail_tpl['message']);
			}
		}

		$new_email_key = random_pass(8);
		$update = array(
			'activate_string' => $new_email,
			'activate_key' => $new_email_key,
		);

		$data = array(
			':id'	=>	$id,
		);
			
		$this->db->update('users', $update, 'id=:id', $data);
			
		$info = array(
			'message' => array(
				'<username>' => $this->user['username'],
				'<base_url>' => get_base_url(),
				'<activation_url>' => $this->registry->get('\links')->aura_link($this->rewrite->url['change_email_key'], array($id, $new_email_key)),
			)
		);

		$mail_tpl = $this->registry->get('\email\parser')->parse_email('activate_email', $this->user['language'], $info);
		$email->send($new_email, $mail_tpl['subject'], $mail_tpl['message']);

		$this->registry->get('\handlers\message')->show($this->lang->t('Activate email sent', $this->config['o_admin_email']), true);
	}

	/**
	 * Change the email of the user
	 */
	protected function change_email()
	{
		if (!$this->user['is_admmod']) // A regular user trying to change another user's email?
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');
		else if ($this->user['g_moderator'] == '1') // A moderator trying to change a user's email?
		{
			$data = array(
				':id' => $id,
			);

			$join = array(
				array(
					'type' => 'INNER',
					'table' => 'groups',
					'as' => 'g',
					'on' => '(g.g_id=u.group_id)',
				),
			);

			$ps = $this->db->join('users', 'u', $join, 'u.group_id, g.g_moderator, g.g_admin', $data, 'u.id=:id');
			if (!$ps->rowCount())
				$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

			list($group_id, $is_moderator, $is_admin) = $ps->fetch(PDO::FETCH_NUM);

			if ($this->user['g_mod_edit_users'] == '0' || $group_id == AURA_ADMIN || $is_admin == '1' || $is_moderator == '1')
				$this->registry->get('\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');
		}
	}

	if (isset($_GET['key']))
	{
		$key = utf8_trim($_GET['key']);
		$update = array(
			':id' => $id,
		);
			
		$ps = $this->db->select('users', 'activate_string, activate_key', $update, 'id=:id');
		list($new_email, $new_email_key) = $ps->fetch(PDO::FETCH_NUM);

		if ($key == '' || $key != $new_email_key)
			$this->registry->get('\handlers\message')->show($this->lang->t('Email key bad', $this->config['o_admin_email']));
		else
		{
			$data = array(
				':id' => $id,
			);

			$this->db->run('UPDATE '.$this->db->prefix.'users SET email=activate_string, activate_string=NULL, activate_key=NULL WHERE id=:id', $data);
			$this->registry->get('\handlers\message')->show($this->lang->t('Email updated'), true);
		}
	}
}