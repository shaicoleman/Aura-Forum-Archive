<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class promote_controller extends base_controller
{
	public function execute()
	{
		$profile = new \profile\common($this->registry);
		$id = $profile->fetch_id();

		if ($this->config['o_reputation'] == '0')
			exit($this->lang->t('reputation disabled'));

		if ($this->user['g_rep_enabled'] == '0')
			exit($this->lang->t('Group disabled'));

		$this->registry->get('\auth\csrf')->confirm('viewtopic');

		if (!$this->user['is_admin'] && ($this->user['g_moderator'] != '1' || $this->user['g_mod_promote_users'] != '1'))
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'));

		$pid = isset($_GET['pid']) ? intval($_GET['pid']) : 0;
		if ($pid < 1)
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'));

		$data = array(
			':id' => $id,
		);

		$ps = $this->db->run('SELECT g.g_promote_next_group FROM '.$this->db->prefix.'groups AS g INNER JOIN '.$this->db->prefix.'users AS u ON u.group_id=g.g_id WHERE u.id=:id AND g.g_promote_next_group>0', $data);
		if (!$ps->rowCount())
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		$group_id = $ps->fetchColumn();

		if (!$group_id)
			$this->registry->get('\handlers\message')->show($this->lang->t('User cannot be promoted error'));

		$update = array(
			'group_id' => $group_id,
		);
		
		$data = array(
			':id' => $id,
		);

		$this->db->update('users', $update, 'id=:id', $data);
		$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['post'], array($pid)), $this->lang->t('User promote redirect'));
	}
}