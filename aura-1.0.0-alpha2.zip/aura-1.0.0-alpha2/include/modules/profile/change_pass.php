<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class change_pass_controller extends base_controller
{
	/*
	 * Main entry point- change the password!
	 */
	public function execute()
	{
		$profile = new \profile\common($this->registry);
		$id = $profile->fetch_id();

		if (isset($_GET['key']))
		{
			// If the user is already logged in we shouldn't be here :)
			if (!$this->user['is_guest'])
			{
				header('Location: '.$this->registry->get('\links')->aura_link($this->rewrite->url['index']));
				exit;
			}

			$key = $_GET['key'];

			$data = array(
				':id' => $id,
			);

			$ps = $db->select('users', 'activate_string, activate_key, salt', $data, 'id=:id');
			$cur_user = $ps->fetch();

			if ($key == '' || $key != $cur_user['activate_key'])
				$this->registry->get('\handlers\message')->show($lang->t('Pass key bad', $aura_config['o_admin_email']));
			else
			{
				$data = array(
					':password' => $cur_user['activate_string'],
					':id' => $id,
				);

				$this->db->run('UPDATE '.$this->db->prefix.'users SET password=:password, activate_string=NULL, activate_key=NULL WHERE id=:id', $data);
				$this->registry->get('\handlers\message')->show($lang->t('Pass updated'), true);
			}
		}
		else
		{
			if ($this->user['g_read_board'] == '0')
				$this->registry->get('\handlers\message')->show($this->lang->t('No view'), false, '403 Forbidden');
			else if ($this->user['g_view_users'] == '0' && ($this->user['is_guest'] || $this->user['id'] != $id))
				$this->registry->get('\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');
		}

		// Make sure we are allowed to change this user's password
		if ($this->user['id'] != $id)
		{
			if (!$this->user['is_admmod'])
				$this->registry->get('\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');
			else if ($this->user['g_moderator'] == '1') // A moderator trying to change a user's password?
			{
				$data = array(
					':id' => $id,
				);

				$join = array(
					array(
						'type' => 'INNER',
						'table' => 'groups',
						'as' => 'g',
						'on' => '(g.g_id=u.group_id)',
					),
				);

				$ps = $this->db->join('users', 'u', $join, 'u.group_id, g.g_moderator, g.g_admin', $data, 'u.id=:id');
				if (!$ps->rowCount())
					message($this->lang->t('Bad request'), false, '404 Not Found');

				list($group_id, $is_moderator, $is_admin) = $ps->fetch(PDO::FETCH_NUM);

				if ($this->user['g_mod_edit_users'] == '0' || $this->user['g_mod_change_passwords'] == '0' || $group_id == AURA_ADMIN || $is_admin == '1' || $is_moderator == '1')
					$this->registry->get('\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');
			}
		}

		$this->change_password($id);

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Profile'), $this->lang->t('Change pass')),
			'required_fields' => array('req_old_password' => $this->lang->t('Old pass'), 'req_new_password1' => $this->lang->t('New pass'), 'req_new_password2' => $this->lang->t('Confirm new pass')),
			'focus_element' => array('change_pass', ((!$this->user['is_admmod']) ? 'req_old_password' : 'req_new_password1')),
			'active_page' => 'profile',
		);

		$tpl = $this->template->load('change_password.tpl');
		$this->template->output($tpl,
			array(
				'csrf_token' => $this->registry->get('\auth\csrf')->generate('change_password'),
				'form_action' => $this->registry->get('\links')->aura_link($this->rewrite->url['change_password'], array($id)),
				'aura_user' => $this->user,
			)
		);
	}

	/*
	 * Attempt to change the user password
	 */
	protected function change_password($id)
	{
		if (isset($_POST['form_sent']))
		{
			$this->registry->get('\auth\csrf')->confirm('change_password');

			$old_password = isset($_POST['req_old_password']) ? utf8_trim($_POST['req_old_password']) : '';
			$new_password1 = isset($_POST['req_new_password1']) ? utf8_trim($_POST['req_new_password1']) : '';
			$new_password2 = isset($_POST['req_new_password2']) ? utf8_trim($_POST['req_new_password2']) : '';

			$errors = $this->registry->get('\auth\register')->validate_password($new_password1, $new_password2);
			if (!empty($errors))
				$this->registry->get('\handlers\message')->show($errors[0]);
			
			$data = array(
				':id' => $id,
			);

			$ps = $this->db->select('users', 'password, salt', $data, 'id=:id');
			$cur_user = $ps->fetch();

			$authorised = false;
			if (!empty($cur_user['password']))
			{
				$old_password_hash = aura_hash($old_password.$cur_user['salt']);
				if ($cur_user['password'] == $old_password_hash || $this->user['is_admmod'])
					$authorised = true;
			}

			if (!$authorised)
				$this->registry->get('\handlers\message')->show($lang->t('Wrong pass'));

			$new_salt = $this->registry->get('\auth\password')->generate(16);
			$new_password_hash = aura_hash($new_password1.$new_salt);

			$update = array(
				'password' => $new_password_hash,
				'salt' => $new_salt,
			);
			
			$data = array(
				':id' => $id,
			);
			
			$this->db->update('users', $update, 'id=:id', $data);

			if ($this->user['id'] == $id)
			{
				$login_key = $this->registry->get('\auth\login')->generate_login_key();
				$this->registry->get('\cookie\cookie')->aura_setcookie($this->user['id'], $login_key, CURRENT_TIMESTAMP + $this->config['o_timeout_visit']);
			}

			$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['profile_essentials'], array($id)), $this->lang->t('Pass updated redirect'));
		}
	}
}