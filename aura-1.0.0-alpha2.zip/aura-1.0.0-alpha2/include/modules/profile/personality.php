<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class personality_controller extends base_controller
{
	public function execute()
	{
		$profile = new \profile\common($this->registry);
		$id = $profile->fetch_id();

		$user = $profile->fetch_user();

		if (isset($_POST['form_sent']))
			$profile->update_profile('personality');

		if ($this->config['o_avatars'] == '0' && $this->config['o_signatures'] == '0')
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Profile'), $this->lang->t('Section personality')),
			'active_page' => 'profile',
			'posting' => true,
		);

		if ($user['signature'] != '')
		{
			$parser = new \message\parser($this->registry);
			$signature = $parser->parse_signature($user['signature']);
		}
		else
			$signature = '';

		$csrf_token = $this->registry->get('\auth\csrf')->generate('profile');
		$user_avatar = $this->registry->get('\avatar')->generate($id, $user['email'], $user['use_gravatar']);

		$avatar_links = array();
		$can_delete = (stristr($user_avatar, '1.'.$this->config['o_avatar']) === false && $user['use_gravatar'] == '0') ? true : false;

		if ($this->config['o_avatar_upload'] == '1' && $can_delete)
			$avatar_links[] = array('url' => $this->registry->get('\links')->aura_link($this->rewrite->url['upload_avatar'], array($id, $csrf_token)), 'class' => 'btn-edit', 'title' => $this->lang->t('Change avatar'));

		if ($can_delete)
			$avatar_links[] = array('url' => $this->registry->get('\links')->aura_link($this->rewrite->url['delete_avatar'], array($id, $csrf_token)), 'class' => 'btn-delete btn-red', 'title' => $this->lang->t('Delete avatar'));
		else if ($this->config['o_avatar_upload'] == '1')
			$avatar_links[] = array('url' => $this->registry->get('\links')->aura_link($this->rewrite->url['upload_avatar'], array($id, $csrf_token)), 'title' => $this->lang->t('Upload avatar'));

		$avatar_links[] = array('url' => $this->registry->get('\links')->aura_link($this->rewrite->url['use_gravatar'], array($id, $csrf_token)), 'class' => 'btn-image', 'title' => (($user['use_gravatar'] == '1') ? $this->lang->t('Disable gravatar') : $this->lang->t('Use gravatar')));

		$tpl = $this->template->load('profile_personality.tpl');
		$this->template->output($tpl,
			array(
				'user' => $user,
				'form_action' => $this->registry->get('\links')->aura_link($this->rewrite->url['profile_personality'], array($id)),
				'csrf_token' => $csrf_token,
				'user_avatar' => $user_avatar,
				'avatar_links' => $avatar_links,
				'signature_length' => $this->functions->forum_number_format($this->config['p_sig_length']),
				'signature' => $signature,
				'quickpost' => array(
					'bbcode' => $this->registry->get('\links')->aura_link($this->rewrite->url['help'], array('bbcode')),
					'url' => $this->registry->get('\links')->aura_link($this->rewrite->url['help'], array('url')),
					'img' => $this->registry->get('\links')->aura_link($this->rewrite->url['help'], array('img')),
					'smilies' => $this->registry->get('\links')->aura_link($this->rewrite->url['help'], array('smilies')),
				),
				'profile_menu' => $this->registry->get('\profile\menu')->generate($id, 'personality'),
			)
		);
	}
}