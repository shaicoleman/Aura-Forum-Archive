<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class attachment_controller extends base_controller
{
	public function execute()
	{
		// Load the attachment language file
		$this->lang->load('attach');

		$id = isset($_GET['item']) ? intval($_GET['item']) : 0;

		if ($id < 1 || $this->config['o_attachments'] == '0')
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'));

		$data = array(
			':id' => $id,
			':gid' => $this->user['g_id'],
		);

		$join = array(
			array(
				'type' => 'LEFT',
				'table' => 'posts',
				'as' => 'p',
				'on' => 'a.post_id=p.id',
			),
			array(
				'type' => 'LEFT',
				'table' => 'topics',
				'as' => 't',
				'on' => 'p.topic_id=t.id',
			),
			array(
				'type' => 'LEFT',
				'table' => 'forum_perms',
				'as' => 'fp',
				'on' => 't.forum_id=fp.forum_id AND fp.group_id=:gid',
			),
		);

		$ps = $this->db->join('attachments', 'a', $join, 'a.post_id, a.filename, a.extension, a.mime, a.location, a.size, fp.download', $data, 'a.id=:id');
		if (!$ps->rowCount())
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'));
		else
			$attachment = $ps->fetch();

		$download = false;
		if ($this->user['is_admin'])
			$download = true;
		else if ($attachment['download'] != 0 || is_null($attachment['download']))
			$download = true;

		if (!$download)
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'));

		if (($attachment['extension'] == 'jpg' || $attachment['extension'] == 'jpeg' || $attachment['extension'] == 'gif' || $attachment['extension'] == 'png') && !isset($_GET['download']))
		{
			$this->template->header = array(
				'page_title' => array($this->config['o_board_title'], $this->lang->t('Image view'), $attachment['filename']),
				'active_page' => 'index',
			);

			$tpl = $this->template->load('attachment.tpl');
			$this->template->output($tpl,
				array(
					'name' => $attachment['filename'],
					'download_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['attachment_download'], array($id)),
				)
			);
		}

		$data = array(
			':id' => $id,
		);

		$this->db->run('UPDATE '.$this->db->prefix.'attachments SET downloads=downloads+1 WHERE id=:id', $data);
		$this->db->end_transaction();

		$fp = fopen($aura_config['o_attachments_dir'].$attachment['location'], "rb");
		if(!$fp)
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'));

		$attachment['filename'] = rawurlencode($attachment['filename']);

		// send some headers
		header('Content-Disposition: attachment; filename='.$attachment['filename']);
		if (strlen($attachment['mime']) > 0)
			header('Content-Type: '.$attachment['mime']);
		else
			header('Content-type: application/octet-stream');

		header('Pragma: no-cache');
		header('Expires: 0'); 
		header('Connection: close');
		if ($attachment['size'] != 0)
			header('Content-Length: '.$attachment['size']);

		fpassthru($fp);
		exit;
	}
}