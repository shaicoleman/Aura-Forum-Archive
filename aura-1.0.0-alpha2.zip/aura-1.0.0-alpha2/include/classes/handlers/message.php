<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

namespace handlers;
use AuraClass;

class message extends AuraClass
{
	//
	// Display a message
	//
	function show($message, $no_back_link = false, $http_status = null, $admin_console = false)
	{
		// Did we receive a custom header?
		if (!is_null($http_status))
			header('HTTP/1.1 '.$http_status);

		// If we failed on an AJAX request, we don't want to send HTML
		if (defined('AURA_AJAX_REQUEST'))
			exit($message);

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Info')),
			'active_page' => 'index',
			'admin_console' => $admin_console,
		);

		$this->template->footer = array(
			'admin_console' => $admin_console,
		);

		$tpl = $this->template->load('message.tpl');
		$this->template->output($tpl, 
			array(
				'lang' => $this->lang,
				'message' => $message,
				'no_back_link' => $no_back_link,
			)
		);

		ob_flush();
		exit;
	}
}