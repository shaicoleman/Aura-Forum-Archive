<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

namespace cookie;
use AuraClass;

class tracked extends AuraClass
{
	//
	// Extract array of tracked topics from cookie
	//
	function get_tracked_topics()
	{
		$cookie_data = isset($_COOKIE[$this->config['o_cookie_name'].'_track']) ? $_COOKIE[$this->config['o_cookie_name'].'_track'] : false;
		if (!$cookie_data)
			return array('topics' => array(), 'forums' => array());

		if (strlen($cookie_data) > FORUM_MAX_COOKIE_SIZE)
			return array('topics' => array(), 'forums' => array());

		// Unserialize data from cookie
		$tracked_topics = array('topics' => array(), 'forums' => array());
		$temp = explode(';', $cookie_data);
		foreach ($temp as $t)
		{
			$type = substr($t, 0, 1) == 'f' ? 'forums' : 'topics';
			$id = intval(substr($t, 1));
			$timestamp = intval(substr($t, strpos($t, '=') + 1));
			if ($id > 0 && $timestamp > 0)
				$tracked_topics[$type][$id] = $timestamp;
		}

		return $tracked_topics;
	}

	//
	// Save array of tracked topics in cookie
	//
	function set_tracked_topics($tracked_topics)
	{
		$cookie_data = '';
		if (!empty($tracked_topics))
		{
			// Sort the arrays (latest read first)
			arsort($tracked_topics['topics'], SORT_NUMERIC);
			arsort($tracked_topics['forums'], SORT_NUMERIC);

			// Homebrew serialization (to avoid having to run unserialize() on cookie data)
			foreach ($tracked_topics['topics'] as $id => $timestamp)
				$cookie_data .= 't'.$id.'='.$timestamp.';';
			foreach ($tracked_topics['forums'] as $id => $timestamp)
				$cookie_data .= 'f'.$id.'='.$timestamp.';';

			// Enforce a byte size limit (4096 minus some space for the cookie name - defaults to 4048)
			if (strlen($cookie_data) > FORUM_MAX_COOKIE_SIZE)
			{
				$cookie_data = substr($cookie_data, 0, FORUM_MAX_COOKIE_SIZE);
				$cookie_data = substr($cookie_data, 0, strrpos($cookie_data, ';')).';';
			}
		}

		$this->registry->get('\cookie\cookie')->forum_setcookie($this->config['o_cookie_name'].'_track', $cookie_data, CURRENT_TIMESTAMP + $this->config['o_timeout_visit']);
		$_COOKIE[$this->config['o_cookie_name'].'_track'] = $cookie_data; // Set it directly in $_COOKIE as well
	}
}