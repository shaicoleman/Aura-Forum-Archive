<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class stopforumspam extends AuraClass
{
	function report($api_key, $remote_address, $email, $username, $message)
	{
		$context = stream_context_create(
			array('http' => 
				array(
					'method'	=> 'POST',
					'header'	=> 'Content-type: application/x-www-form-urlencoded',
					'content'	=> http_build_query(
						array(
							'ip_addr'	=> $remote_address,
							'email'		=> $email,
							'username'	=> $username,
							'evidence'	=> $message,
							'api_key'	=> $api_key,
						)
					),
				)
			)
		);

		return @file_get_contents('http://www.stopforumspam.com/add', false, $context) ? true : false;
	}
}