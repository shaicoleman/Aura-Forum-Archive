<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

namespace templates;
use template_element;
use registry;
use styles;

// Make sure no one attempts to run this script "directly"
if (!defined('config::SESSION'))
	exit;

class template_header extends template_element implements \interfaces\template_element_interface
{
	public function fetch_data()
	{
		registry::send_headers('html');

		$this->data['p'] = isset($this->data['p']) ? $this->data['p'] : null;
		$links = array();

		// Index should always be displayed
		$links[] = array('id' => 'navindex', 'class' => (($this->data['active_page'] == 'index') ? 'active' : ''), 'page' => $this->registry->get('\links')->aura_link($this->rewrite->url['index']), 'title' => $this->lang->t('Index'));

		if ($this->user['g_read_board'] == '1' && $this->user['g_view_users'] == '1')
			$links[] = array('id' => 'navuserlist', 'class' => (($this->data['active_page'] == 'userlist') ? 'active' : ''), 'page' => $this->registry->get('\links')->aura_link($this->rewrite->url['userlist']), 'title' => $this->lang->t('User list'));

		if ($this->user['g_read_board'] == '1' && $this->user['g_view_users'] == '1')
			$links[] = array('id' => 'navleaders', 'class' => (($this->data['active_page'] == 'leaders') ? 'active' : ''), 'page' => $this->registry->get('\links')->aura_link($this->rewrite->url['leaders']), 'title' => $this->lang->t('Moderating Team'));

		if ($this->user['g_read_board'] == '1' && $this->user['g_view_users'] == '1' && $this->config['o_users_online'] == '1')
			$links[] = array('id' => 'navonline', 'class' => (($this->data['active_page'] == 'online') ? 'active' : ''), 'page' => $this->registry->get('\links')->aura_link($this->rewrite->url['online']), 'title' => $this->lang->t('Online'));

		if ($this->config['o_rules'] == '1' && (!$this->user['is_guest'] || $this->user['g_read_board'] == '1' || $this->config['o_regs_allow'] == '1'))
			$links[] = array('id' => 'navrules', 'class' => (($this->data['active_page'] == 'rules') ? 'active' : ''), 'page' => $this->registry->get('\links')->aura_link($this->rewrite->url['rules']), 'title' => $this->lang->t('Rules'));

		if ($this->user['g_read_board'] == '1' && $this->user['g_search'] == '1')
			$links[] = array('id' => 'navsearch', 'class' => (($this->data['active_page'] == 'search') ? 'active' : ''), 'page' => $this->registry->get('\links')->aura_link($this->rewrite->url['search']), 'title' => $this->lang->t('Search'));

		if ($this->user['is_guest'])
		{
			$links[] = array('id' => 'navregister', 'class' => (($this->data['active_page'] == 'register') ? 'active' : ''), 'page' => $this->registry->get('\links')->aura_link($this->rewrite->url['register']), 'title' => $this->lang->t('Register'));
			$links[] = array('id' => 'navlogin', 'class' => (($this->data['active_page'] == 'login') ? 'active' : ''), 'page' => $this->registry->get('\links')->aura_link($this->rewrite->url['login']), 'title' => $this->lang->t('Login'));
		}
		else
		{
			// To avoid another preg replace, link directly to the essentials section
			$links[] = array('id' => 'navprofile', 'class' => (($this->data['active_page'] == 'profile') ? 'active' : ''), 'page' => $this->registry->get('\links')->aura_link($this->rewrite->url['profile_essentials'], array($this->user['id'])), 'title' => $this->lang->t('Profile'));

			if ($this->config['o_private_messaging'] == '1' && $this->user['g_use_pm'] == '1' && $this->user['pm_enabled'] == '1')
			{
				$join = array(
					array(
						'type' => 'INNER',
						'table' => 'pms_data',
						'as' => 'cd',
						'on' => 'c.id=cd.topic_id AND cd.user_id=:uid',
					),
				);

				$header_data = array(
					':uid' => $this->user['id'],
				);

				$ps_header = $this->db->join('conversations', 'c', $join, 'COUNT(c.id)', $header_data, 'cd.viewed=0 AND cd.deleted=0');
				$num_messages = $ps_header->fetchColumn();

				$pm_lang = ($num_messages) ? $this->lang->t('PM amount', $num_messages) : $this->lang->t('PM');
				$links[] = array('id' => 'navpm', 'class' => (($this->data['active_page'] == 'pm') ? 'active' : ''), 'page' => $this->registry->get('\links')->aura_link($this->rewrite->url['inbox']), 'title' => $pm_lang);
			}

			if ($this->user['is_admmod'] && ($this->user['is_admin'] || $this->user['g_mod_cp'] == '1'))
				$links[] = array('id' => 'navadmin', 'class' => (($this->data['active_page'] == 'admin') ? 'active' : ''), 'page' => $this->registry->get('\links')->aura_link($this->rewrite->url['admin_index']), 'title' => $this->lang->t('Admin'));

			$links[] = array('id' => 'navlogout', 'class' => '', 'page' => $this->registry->get('\links')->aura_link($this->rewrite->url['logout'], array($this->user['id'], $this->registry->get('\auth\csrf')->generate('login'))), 'title' => $this->lang->t('Logout'));
		}

		// Are there any additional navlinks we should insert into the array before imploding it?
		if ($this->user['g_read_board'] == '1' && $this->config['o_additional_navlinks'] != '')
		{
			if (preg_match_all('%([0-9]+)\s*=\s*(.*?)\n%s', $this->config['o_additional_navlinks']."\n", $extra_links))
			{
				// Insert any additional links into the $links array (at the correct index)
				$num_links = count($extra_links[1]);
				for ($i = 0; $i < $num_links; ++$i)
				{
					$link = explode('|', $extra_links[2][$i]);
					array_splice($links, $extra_links[1][$i], 0, array(array('id' => 'navextra'.($i + 1), 'class' => '', 'page' => $link[0], 'title' => $link[1])));
				}
			}
		}

		$reports = array();
		if ($this->user['is_admmod'])
		{
			if ($this->config['o_report_method'] == '0' || $this->config['o_report_method'] == '2')
			{
				$ps_header = $this->db->select('reports', 1, array(), 'zapped IS NULL');
				if ($ps_header->rowCount())
					$reports[] = array('link' => $this->registry->get('\links')->aura_link($this->rewrite->url['admin_reports']), 'title' => $this->lang->t('New reports'));
			}

			$ps_header = $this->db->select('posts', 1, array(), 'approved=0 AND deleted=0');
			if ($ps_header->rowCount())
				$reports[] = array('link' => $this->registry->get('\links')->aura_link($this->rewrite->url['admin_posts']), 'title' => $this->lang->t('New unapproved posts'));
		}

		$status_info = array();
		if ($this->user['g_read_board'] == '1' && $this->user['g_search'] == '1')
		{
			if (!$this->user['is_guest'])
			{
				$status_info[] = array('link' => $this->registry->get('\links')->aura_link($this->rewrite->url['search_replies']), 'title' => $this->lang->t('Show posted topics'), 'display' => $this->lang->t('Posted topics'));
				$status_info[] = array('link' => $this->registry->get('\links')->aura_link($this->rewrite->url['search_new']), 'title' => $this->lang->t('Show new posts'), 'display' => $this->lang->t('New posts header'));
			}

			$status_info[] = array('link' => $this->registry->get('\links')->aura_link($this->rewrite->url['search_recent']), 'title' => $this->lang->t('Show active topics'), 'display' => $this->lang->t('Active topics'));
			$status_info[] = array('link' => $this->registry->get('\links')->aura_link($this->rewrite->url['search_unanswered']), 'title' => $this->lang->t('Show unanswered topics'), 'display' => $this->lang->t('Unanswered topics'));
		}

		if (isset($this->data['required_fields']))
		{
			$element = '';
			$tpl_temp = count($this->data['required_fields']);
			foreach ($this->data['required_fields'] as $elem_orig => $elem_trans)
			{
				$element .= "\t\t\"".$elem_orig.'": "'.addslashes(str_replace('&#160;', ' ', $elem_trans));
				if (--$tpl_temp) $element .= "\",\n";
				else $element .= "\"\n\t};\n";
			}
		}
		else
			$element = '';

		ob_start();

		$style_path = styles::get_style_path().'/'.$this->user['style'].'/templates/';
		$tpl = (isset($this->data['admin_console']) && $this->data['admin_console'] && (file_exists($style_path.'admin/header.tpl') || $this->user['style'] == $this->config['o_default_style'] && !file_exists($style_path)) ? 'admin/header.tpl' : 'header.tpl');

		return array(
				'tpl_file' => $tpl,
				'username' => $this->functions->colourise_group($this->user['username'], $this->user['group_id'], $this->user['id']),
				'last_visit' => $this->registry->get('\aura_time')->format($this->user['last_visit']),
				'num_messages' => isset($num_messages) ? $num_messages : '',
				'page_title' => $this->functions->generate_page_title($this->data['page_title'], $this->data['p']),
				'stylesheet' => styles::get_style_root().$this->user['style'],
				'core_css' => styles::get_core_path(),
				'favicon' => $this->config['o_image_dir'].$this->config['o_favicon'],
				'page' => $this->data['active_page'],
				'index_url' => $this->registry->get('\links')->aura_link($this->rewrite->url['index']),
				'links' => $links,
				'inbox_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['inbox']),
				'maintenance_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['admin_options_direct'], array('maintenance')),
				'status_info' => $status_info,
				'reports' => $reports,
				'admin_style' => styles::get_custom_file('style_admin.css'),
				'smiley_path' => (($this->config['o_smilies_dir'] != '') ? $this->config['o_smilies_dir'] : $this->functions->get_base_url().'/'.$this->config['o_smilies_path'].'/'),
				'jquery' => (isset($this->data['jquery_required']) || (isset($this->data['posting']) && $this->config['o_use_editor'] == '1' && $this->user['use_editor'] == '1') || isset($this->data['posting']))?  '1' : '0',
				'reputation' => isset($this->data['reputation']) ? '1' : '0',
				'posting' => isset($this->data['posting']) && $this->config['o_use_editor'] != '0' && $this->user['use_editor'] == '1' ? '1' : '0',
				'admin_index' => isset($this->data['admin_index']) ? '1' : '0',
				'required_fields' => $element,
				'focus_element' => isset($focus_element) ? $focus_element : array(),
				'page_head' => !empty($page_head) ? $page_head : array(),
				'allow_index' => isset($this->data['allow_index']) ? '1' : '0',
				'common' => isset($this->data['common_javascript']) ? true : false,
				'admin_console' => isset($this->data['admin_console']) && $this->data['admin_console'] == true ? true : false,
			);
	}
}