<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
namespace errors;
use Exception;
 
// Make sure no one attempts to run this script "directly"
if (!defined('config::SESSION'))
	exit;

class database_error extends Exception
{
	public function __construct($message, $sql = '', $parameters = array())
	{
		$message = array(
			'message' => $message,
			'sql' => $sql,
			'parameters' => $parameters,
			'trace' => $this->getTrace(),
		);

		parent::__construct(json_encode($message), $this->getCode(), $this->getPrevious());
	}
}