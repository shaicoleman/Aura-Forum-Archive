<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

namespace topics;
use AuraClass;
use PDO;

class delete_post extends AuraClass
{
	//
	// Delete a single post
	//
	function delete_post_comply($post_id, $topic_id)
	{
		$topic_data = array(
			':id'	=>	$topic_id,
		);	

		$post_data = array(
			':id'	=>	$post_id,
		);

		$ps = $this->db->select('posts', 'id, poster, posted', $topic_data, 'topic_id=:id AND approved=1 AND deleted=0', 'id DESC LIMIT 2');
		list($last_id, ,) = $ps->fetch(PDO::FETCH_NUM);
		list($second_last_id, $second_poster, $second_posted) = $ps->fetch(PDO::FETCH_NUM);

		// Delete the post
		$this->registry->get('\topics\attachment')->attach_delete_post($post_id);
		$update = array(
			'deleted' => 1,
		);

		$this->db->update('posts', $update, 'id=:id', $post_data);

		$idx = new \search\idx($this->registry);
		$idx->strip_search_index(array($post_id));

		// Count number of replies in the topic
		$ps = $this->db->select('posts', 'COUNT(id)', $topic_data, 'topic_id=:id AND approved=1 AND deleted=0');
		$num_replies = $ps->fetchColumn() - 1; // Decrement the deleted post

		// If the message we deleted is the most recent in the topic (at the end of the topic)
		if ($last_id == $post_id)
		{
			// If there is a $second_last_id there is more than 1 reply to the topic
			if (!empty($second_last_id))
			{
				$update = array(
					'last_post'	=>	$second_posted,
					'last_post_id'	=>	$second_last_id,
					'last_poster'	=>	$second_poster,
					'num_replies'	=>	$num_replies,
				);

				$data = array(
					':id' => $topic_id,
				);

				$this->db->update('topics', $update, 'id=:id', $data);
			}
			else
			{
				$data = array(
					':id'	=>	$topic_id,
					':num_replies'	=>	$num_replies-1,
				);

				// We deleted the only reply, so now last_post/last_post_id/last_poster is posted/id/poster from the topic itself
				$this->db->run('UPDATE '.$this->db->prefix.'topics SET last_post=posted, last_post_id=id, last_poster=poster, num_replies=:num_replies WHERE id=:id', $data);
			}
		}
		else	// Otherwise we just decrement the reply counter
		{
			$update = array(
				'num_replies' => $num_replies,
			);

			$this->db->update('topics', $update, 'id=:id', $topic_data);
		}

		$this->db->delete('reputation', 'post_id=:id', $post_data);

		if ($this->config['o_delete_full'] == '1')
			$this->permanently_delete_post($post_id);
	}

	//
	// Permanently delete a single post
	//
	function permanently_delete_post($id)
	{
		$data = array(
			':id' => $id,
		);

		$this->db->delete('posts', 'id=:id AND deleted=1', $data); // Since we've already stripped the search index, all we need to do is delete the row
	}
}