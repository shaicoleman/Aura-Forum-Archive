<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

namespace topics;
use AuraClass;

class title extends AuraClass
{
	//
	// Determines the correct title for $user
	// $user must contain the elements 'username', 'title', 'posts', 'g_id' and 'g_user_title'
	//
	function get_title($user)
	{
		static $ban_list, $aura_ranks;

		// If not already built in a previous call, build an array of lowercase banned usernames
		if (!isset($ban_list))
		{
			$ban_list = array();
			foreach ($this->bans as $cur_ban)
				$ban_list[] = utf8_strtolower($cur_ban['username']);
		}

		// If not already loaded in a previous call, load the cached ranks
		if ($this->config['o_ranks'] == '1' && !isset($aura_ranks))
			$aura_ranks = $this->cache->get('ranks');

		// If the user is banned
		if (in_array(utf8_strtolower($user['username']), $ban_list))
			$user_title = $this->lang->t('Banned');
		// If the user has a custom title
		else if ($user['title'] != '')
			$user_title = $user['title'];
		// If the user group has a default user title
		else if ($user['g_user_title'] != '')
			$user_title = $user['g_user_title'];
		// If the user is a guest
		else if ($user['g_id'] == AURA_GUEST)
			$user_title = $this->lang->t('Guest');
		// If nothing else helps, we assign the default
		else
		{
			// Are there any ranks?
			if ($this->config['o_ranks'] == '1' && !empty($aura_ranks))
			{
				foreach ($aura_ranks as $cur_rank)
				{
					if ($user['num_posts'] >= $cur_rank['min_posts'])
						$user_title = $cur_rank['rank'];
				}
			}

			// If the user didn't "reach" any rank (or if ranks are disabled), we assign the default
			if (!isset($user_title))
			  $user_title = $this->lang->t('Member');
		}

		return $user_title;
	}
}