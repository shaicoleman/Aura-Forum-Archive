<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

namespace admin;
use AuraClass;
use config;

class extension extends AuraClass
{
	//
	// Validate an Extension schema when installing it into the Amin panel
	//
	function validate($extension, $errors)
	{
		if (!isset($extension['extension']))
			$errors[] = $this->lang->t('Extension tag missing', 'extension');

		if (empty($errors))
		{
			// First off start by validating the Engine
			$extension = $extension['extension'];
			if (!isset($extension['attributes']['engine']))
				$errors[] = $this->lang->t('Extension attribute missing', 'engine');
			else if ($extension['attributes']['engine'] < '1.1')
				$errors[] = $this->lang->t('Extension engine incompatible', $this->config['o_cur_version']);
			else if ($extension['attributes']['engine'] != '1.1')
				$errors[] = $this->lang->t('Extension engine invalid');

			// Next, validate we have an appropriate title
			else if (!isset($extension['title']))
				$errors[] = $this->lang->t('Extension tag missing', 'title');
			else if (utf8_strlen($extension['title']) <= 5)
				$errors[] = $this->lang->t('Extension title too short');

			// Validate the extension version
			if (!isset($extension['version']))
				$errors[] = $this->lang->t('Extension tag missing', 'version');
			else if (!is_numeric($extension['version']))
				$errors[] = $this->lang->t('Extension version invalid');

			// Optional: 'plugin_folder' if we are installing files
			else if (isset($extension['plugin_folder']) && (utf8_strlen($extension['plugin_folder']) < 5 || preg_match('/[^a-z0-9\s-]/s', $extension['plugin_folder'])))
				$errors[] = $this->lang->t('Extension plugin folder name invalid');

			// Description for the extension
			else if (!isset($extension['description']))
				$errors[] = $this->lang->t('Extension tag missing', 'description');
			else if (utf8_strlen($extension['description']) <= 20)
				$errors[] = $this->lang->t('Extension description too short');

			// Validate the extension author
			else if (!isset($extension['author']))
				$errors[] = $this->lang->t('Extension tag missing', 'author');
			else if (utf8_strlen($extension['author']) <= 3)
				$errors[] = $this->lang->t('Extension author too short');

			// Check out all extension versions
			else if (!isset($extension['supported_versions']))
				$errors[] = $this->lang->t('Extension tag missing', 'supported_versions');
			else
			{
				$versions = explode(',', $extension['supported_versions']);
				if (empty($versions))
					$errors[] = $this->lang->t('Extension supported versions empty');
				else if (count(array_filter($versions)) != count($versions))
					$errors[] = $this->lang->t('Extension supported versions markup invalid');
			}

			// Validate the extension hooks
			if (empty($errors))
			{
				if (!isset($extension['hooks']))
					$errors[] = $this->lang->t('Extension tag missing', 'hooks');
				else if (!is_array($extension['hooks']))
					$errors[] = $this->lang->t('Extension hook missing');
				else
				{
					if (!isset($extension['hooks']['hook']))
						$errors[] = $this->lang->t('Extension tag missing', 'hook');
					else if (!is_array($extension['hooks']['hook']))
						$errors[] = $this->lang->t('Extension hook missing');
					else
					{
						foreach ($extension['hooks']['hook'] as $hook)
						{
							if (!isset($hook['attributes']['id']))
							{
								$errors[] = $this->lang->t('Extension attribute missing', 'id');
								break;
							}
							else if (utf8_strlen($hook['attributes']['id']) < 5)
							{
								$errors[] = $this->lang->t('Invalid hook attribute', $hook['attributes']['id']);
								break;
							}
							else if (!isset($hook['content']) || utf8_trim($hook['content']) == '')
							{
								$errors[] = $this->lang->t('Extension hook missing content', $hook['attributes']['id']);
								break;
							}
						}
					}
				}
			}

			// Optional: validate the install tag
			if (empty($errors) && isset($extension['install']))
			{
				if (empty($extension['install']))
					$errors[] = $this->lang->t('Invalid or unused extension tag', 'install');

				// If we're executing code when we install this extension
				else if (isset($extension['install']['execute']) && utf8_trim($extension['install']['execute']) == '')
					$errors[] = $this->lang->t('Invalid or empty extension tag', 'execute');

				// If we're installing additional templates when we install this extension
				if (isset($extension['install']['templates']))
				{
					if (!isset($extension['install']['templates']['template']))
						$errors[] = $this->lang->t('Extension tag missing', 'template');
					else if (!is_array($extension['install']['templates']['template']))
						$errors[] = $this->lang->t('Extension template missing');
					else
					{
						// Hacky solution to only having one template
						if (isset($extension['install']['templates']['template']['content']))
						{
							$extension['install']['templates']['template'][0] = $extension['install']['templates']['template'];
							unset($extension['install']['templates']['template']['content']);
							unset($extension['install']['templates']['template']['attributes']);
						}

						$templates = array();
						foreach ($extension['install']['templates']['template'] as $template)
						{
							if (!isset($template['attributes']['id']))
							{
								$errors[] = $this->lang->t('Extension attribute missing', 'id');
								break;
							}
							else if (utf8_strlen($template['attributes']['id']) < 5 || !preg_match('/([a-z]+).tpl/s', $template['attributes']['id']))
							{
								$errors[] = $this->lang->t('Invalid template attribute', $template['attributes']['id']);
								break;
							}
							else if (!isset($template['content']) || utf8_trim($template['content']) == '')
							{
								$errors[] = $this->lang->t('Extension template missing content', $template['attributes']['id']);
								break;
							}

							$templates[] = $template['attributes']['id'];
						}

						// Check for duplicate template files being installed in the extension
						if (count($templates) !== count(array_unique($templates)))
							$errors[] = $this->lang->t('Template names not unique');
					}
				}

				// Do we have an unused 'plugin folder' component?
				if (isset($extension['plugin_folder']) && !isset($extension['install']['templates']) && !isset($extension['install']['languages']) && !isset($extension['install']['files']))
					$errors[] = $this->lang->t('Invalid extension component', 'plugin_folder');
				else if (is_dir(AURA_ROOT.'include/extensions/'.$extension['plugin_folder'])) // Does it already exist?
					$errors[] = $this->lang->t('Plugin folder already used');

				// If we're installing additional plugin files with this extension
				if (empty($errors) && isset($extension['install']['plugins']))
				{
					if (!isset($extension['install']['plugins']['plugin']))
						$errors[] = $this->lang->t('Extension tag missing', 'plugin');
					else if (!is_array($extension['install']['plugins']['plugin']))
						$errors[] = $this->lang->t('Extension plugin missing');
					else
					{
						// Hacky solution to only having one template
						if (isset($extension['install']['plugins']['plugin']['content']))
						{
							$extension['install']['plugins']['plugin'][0] = $extension['install']['plugins']['plugin'];
							unset($extension['install']['plugins']['plugin']['content']);
							unset($extension['install']['plugins']['plugin']['attributes']);
						}

						$plugins = array();
						foreach ($extension['install']['plugins']['plugin'] as $plugin)
						{
							if (!isset($plugin['attributes']['id']))
							{
								$errors[] = $this->lang->t('Extension attribute missing', 'id');
								break;
							}
							else if (utf8_strlen($plugin['attributes']['id']) < 5 || !preg_match('/(AP_|AMP_)([A-Za-z0-9_]+).php/s', $plugin['attributes']['id']))
							{
								$errors[] = $this->lang->t('Invalid plugin attribute', $plugin['attributes']['id']);
								break;
							}
							else if (!isset($plugin['content']) || utf8_trim($plugin['content']) == '')
							{
								$errors[] = $this->lang->t('Extension plugin missing content', $plugin['attributes']['id']);
								break;
							}

							$plugins[] = $plugin['attributes']['id'];
						}

						// Check for duplicate plugin files in this extension
						if (count($plugins) !== count(array_unique($plugins)))
							$errors[] = $this->lang->t('Plugin names not unique');

						// Then look through to make sure we're not going to be overwriting anything that already exists
						foreach ($plugins as $plugin)
						{
							if (file_exists(config::PLUGINS_DIR.$plugin))
							{
								$errors[] = $this->lang->t('Plugin already exists', $plugin);
								break;
							}
						}
					}
				}

				// If we're installing additional languages along with this extension
				if (empty($errors) && isset($extension['install']['languages']))
				{
					if (!isset($extension['install']['languages']['language']))
						$errors[] = $this->lang->t('Extension tag missing', 'language');
					else if (!is_array($extension['install']['languages']['language']))
						$errors[] = $this->lang->t('Extension language missing');
					else
					{
						// Hacky solution to only having one language
						if (isset($extension['install']['languages']['language']['content']))
						{
							$extension['install']['languages']['language'][0] = $extension['install']['languages']['language'];
							unset($extension['install']['languages']['language']['content']);
							unset($extension['install']['languages']['language']['attributes']);
						}

						$languages = array();
						foreach ($extension['install']['languages']['language'] as $language)
						{
							if (!isset($language['attributes']['id']))
							{
								$errors[] = $this->lang->t('Extension attribute missing', 'id');
								break;
							}
							else if (utf8_strlen($language['attributes']['id']) < 5 || !preg_match('/([a-z_]+).po/s', $language['attributes']['id']))
							{
								$errors[] = $this->lang->t('Invalid language attribute', $language['attributes']['id']);
								break;
							}
							if (!isset($language['attributes']['iso']))
							{
								$errors[] = $this->lang->t('Extension attribute missing', 'iso');
								break;
							}
							else if (!preg_match('/([a-z]{2})_([A-Z]{2})/s', $language['attributes']['iso']))
							{
								$errors[] = $this->lang->t('Invalid language attribute', $language['attributes']['iso']);
								break;
							}
							else if (!isset($language['content']) || utf8_trim($language['content']) == '')
							{
								$errors[] = $this->lang->t('Extension language missing content', $language['attributes']['id']);
								break;
							}

							$languages[] = $language['attributes']['id'].'_'.$language['attributes']['iso'];
						}

						// Check for duplicate language files being installed in the extension
						if (count($languages) !== count(array_unique($languages)))
							$errors[] = $this->lang->t('Language files not unique');
					}
				}

				// If we're installing additional files with this extension
				if (empty($errors) && isset($extension['install']['files']))
				{
					if (!isset($extension['install']['files']['file']))
						$errors[] = $this->lang->t('Extension tag missing', 'file');
					else if (!is_array($extension['install']['files']['file']))
						$errors[] = $this->lang->t('Extension file missing');
					else
					{
						// Hacky solution to only having one template
						if (isset($extension['install']['files']['file']['content']))
						{
							$extension['install']['files']['file'][0] = $extension['install']['files']['file'];
							unset($extension['install']['files']['file']['content']);
							unset($extension['install']['files']['file']['attributes']);
						}

						$files = array();
						foreach ($extension['install']['files']['file'] as $file)
						{
							if (!isset($file['attributes']['name']))
							{
								$errors[] = $this->lang->t('Extension attribute missing', 'name');
								break;
							}
							else if (utf8_strlen($file['attributes']['name']) < 5 || !preg_match('/([a-z]+).php/s', $file['attributes']['name']))
							{
								$errors[] = $this->lang->t('Invalid file attribute', $file['attributes']['name']);
								break;
							}
							else if (!isset($file['content']) || utf8_trim($file['content']) == '')
							{
								$errors[] = $this->lang->t('Extension file missing content', $file['attributes']['name']);
								break;
							}

							$files[] = $file['attributes']['name'];
						}

						// Check for duplicate files in this extension
						if (count($files) !== count(array_unique($files)))
							$errors[] = $this->lang->t('File names not unique');
					}
				}

				// If we're installing additional tasks along with this extension
				if (empty($errors) && isset($extension['install']['tasks']))
				{
					
				}

				// If we're installing additional styles along with this extension
				if (empty($errors) && isset($extension['install']['styles']))
				{
					
				}
			}

			// Optional: validate the uninstall tag
			if (empty($errors) && isset($extension['uninstall']))
			{
				if (empty($extension['uninstall']))
					$errors[] = $this->lang->t('Invalid or unused extension tag', 'uninstall');

				// If we're executing code during this uninstall
				else if (isset($extension['uninstall']['execute']) && utf8_trim($extension['uninstall']['execute']) == '')
					$errors[] = $this->lang->t('Invalid or empty extension tag', 'execute');
				// Validate the uninstall note
				else if (isset($extension['uninstall']['note']) && utf8_strlen($extension['uninstall']['note']) <= 5)
					$errors[] = $this->lang->t('Uninstall note too short');
			}
		}

		return array($extension, $errors);
	}
}