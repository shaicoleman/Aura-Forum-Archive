<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

namespace tasks;

abstract class background_task
{
	protected $registry;
	final public function __construct($registry)
	{
		$this->registry = $registry;
		$this->user = $registry->user;
		$this->config = $registry->config;
		$this->cache = $registry->cache;
		$this->lang = $registry->lang;
		$this->db = $registry->db;
		$this->rewrite = $registry->rewrite;
		$this->template = $registry->template;
		$this->functions = $registry->functions;
		$this->tasks = $registry->tasks;
	}

	public abstract function run();
}