<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

namespace xml;

if (!defined('config::SESSION'))
	exit;

class convert
{
	function fetch_array($raw_xml)
	{
		$xml_array = array();
		$xml_parser = xml_parser_create();
		xml_parser_set_option($xml_parser, XML_OPTION_CASE_FOLDING, 0);
		xml_parser_set_option($xml_parser, XML_OPTION_SKIP_WHITE, 0);
		xml_parse_into_struct($xml_parser, $raw_xml, $parsed_xml);
		xml_parser_free($xml_parser);

		foreach ($parsed_xml as $xml_elem)
		{
			$x_tag = $xml_elem['tag'];
			$x_level = $xml_elem['level'];
			$x_type = $xml_elem['type'];

			if ($x_level != 1 && $x_type == 'close')
			{
				if (isset($multi_key[$x_tag][$x_level]))
					$multi_key[$x_tag][$x_level] = 1;
				else
					$multi_key[$x_tag][$x_level] = 0;
			}

			if ($x_level != 1 && $x_type == 'complete')
			{
				if (isset($tmp) && $tmp == $x_tag)
					$multi_key[$x_tag][$x_level] = 1;

				$tmp = $x_tag;
			}
		}

		foreach ($parsed_xml as $xml_elem)
		{
			$x_tag = $xml_elem['tag'];
			$x_level = $xml_elem['level'];
			$x_type = $xml_elem['type'];

			if ($x_type == 'open')
				$level[$x_level] = $x_tag;

			$start_level = 1;
			$php_stmt = '$xml_array';
			if ($x_type == 'close' && $x_level != 1)
				$multi_key[$x_tag][$x_level]++;

			while ($start_level < $x_level)
			{
				$php_stmt .= '[$level['.$start_level.']]';
				if (isset($multi_key[$level[$start_level]][$start_level]) && $multi_key[$level[$start_level]][$start_level])
					$php_stmt .= '['.($multi_key[$level[$start_level]][$start_level]-1).']';

				++$start_level;
			}

			$add = '';
			if (isset($multi_key[$x_tag][$x_level]) && $multi_key[$x_tag][$x_level] && ($x_type == 'open' || $x_type == 'complete'))
			{
				if (!isset($multi_key2[$x_tag][$x_level]))
					$multi_key2[$x_tag][$x_level] = 0;
				else
					$multi_key2[$x_tag][$x_level]++;

				$add = '['.$multi_key2[$x_tag][$x_level].']';
			}

			if (isset($xml_elem['value']) && utf8_trim($xml_elem['value']) != '' && !isset($xml_elem['attributes']))
			{
				if ($x_type == 'open')
					$php_stmt_main = $php_stmt.'[$x_type]'.$add.'[\'content\'] = $xml_elem[\'value\'];';
				else
					$php_stmt_main = $php_stmt.'[$x_tag]'.$add.' = $xml_elem[\'value\'];';

				eval($php_stmt_main);
			}

			if (isset($xml_elem['attributes']))
			{
				if (isset($xml_elem['value']))
				{
					$php_stmt_main = $php_stmt.'[$x_tag]'.$add.'[\'content\'] = $xml_elem[\'value\'];';
					eval($php_stmt_main);
				}

				foreach ($xml_elem['attributes'] as $key=>$value)
				{
					$php_stmt_att=$php_stmt.'[$x_tag]'.$add.'[\'attributes\'][$key] = $value;';
					eval($php_stmt_att);
				}
			}
		}

		// Make sure there's an array of hooks (even if there is only one)
		if (isset($xml_array['extension']['hooks']) && isset($xml_array['extension']['hooks']['hook']))
		{
			if (!is_array(current($xml_array['extension']['hooks']['hook'])))
				$xml_array['extension']['hooks']['hook'] = array($xml_array['extension']['hooks']['hook']);
		}

		return $xml_array;
	}
}