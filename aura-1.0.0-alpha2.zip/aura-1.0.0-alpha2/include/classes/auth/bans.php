<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

namespace auth;
use AuraClass;

class bans extends AuraClass
{
	//
	// Check whether the connecting user is banned (and delete any expired bans while we're at it)
	//
	function check_bans()
	{
		// Admins and moderators aren't affected
		if ($this->user['is_admmod'] || !$this->registry->bans || defined('AURA_TURN_OFF_BANS'))
			return;

		// Add a dot or a colon (depending on IPv4/IPv6) at the end of the IP address to prevent banned address
		// 192.168.0.5 from matching e.g. 192.168.0.50
		$user_ip = get_remote_address();
		$user_ip .= (strpos($user_ip, '.') !== false) ? '.' : ':';

		$bans_altered = false;
		$is_banned = false;

		foreach ($this->registry->bans as $cur_ban)
		{
			// Has this ban expired?
			if ($cur_ban['expire'] != '' && $cur_ban['expire'] <= CURRENT_TIMESTAMP)
			{
				$data = array(
					':id' => $cur_ban['id'],
				);

				$this->db->delete('bans', 'id=:id', $data);
				$bans_altered = true;
				continue;
			}

			if ($cur_ban['username'] != '' && utf8_strtolower($this->user['username']) == utf8_strtolower($cur_ban['username']))
				$is_banned = true;

			if ($cur_ban['ip'] != '')
			{
				$cur_ban_ips = explode(' ', $cur_ban['ip']);

				$num_ips = count($cur_ban_ips);
				for ($i = 0; $i < $num_ips; ++$i)
				{
					// Add the proper ending to the ban
					if (strpos($user_ip, '.') !== false)
						$cur_ban_ips[$i] = $cur_ban_ips[$i].'.';
					else
						$cur_ban_ips[$i] = $cur_ban_ips[$i].':';

					if (substr($user_ip, 0, strlen($cur_ban_ips[$i])) == $cur_ban_ips[$i])
					{
						$is_banned = true;
						break;
					}
				}
			}

			if ($is_banned)
			{
				$data = array(
					':ident' => $this->user['username'],
				);

				$this->db->delete('online', 'ident=:ident', $data);
				$this->registry->get('\handlers\message')->show($this->lang->t('Ban message').' '.(($cur_ban['expire'] != '') ? $this->lang->t('Ban message 2').' '.strtolower($this->registry->get('\aura_time')->format($cur_ban['expire'])).'. ' : '').(($cur_ban['message'] != '') ? $this->lang->t('Ban message 3').$cur_ban['message'] : '').$this->lang->t('Ban message 4').' '.$this->config['o_admin_email'], true);
			}
		}

		// If we removed any expired bans during our run-through, we need to regenerate the bans cache
		if ($bans_altered)
			$this->cache->generate('bans');
	}

	//
	// Check for a banned email address
	//
	function is_banned_email($email)
	{
		foreach ($this->registry->bans as $cur_ban)
		{
			if ($cur_ban['email'] != '' && ($email == $cur_ban['email'] || (strpos($cur_ban['email'], '@') === false && stristr($email, '@'.$cur_ban['email']))))
				return true;
		}

		return false;
	}
}