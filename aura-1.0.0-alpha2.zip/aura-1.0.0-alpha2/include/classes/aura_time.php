<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class aura_time extends AuraClass
{
	//
	// Format a time string according to $time_format and time zones
	//
	function format($timestamp, $date_only = false, $date_format = null, $time_format = null, $time_only = false, $no_text = false)
	{
		if ($timestamp == '')
			return $this->lang->t('Never');

		$diff = ($this->user['timezone'] + $this->user['dst']) * 3600;
		$timestamp += $diff;

		if (is_null($date_format))
			$date_format = $this->config['o_date_formats'][$this->user['date_format']];

		if (is_null($time_format))
			$time_format = $this->config['o_time_formats'][$this->user['time_format']];

		$date = gmdate($date_format, $timestamp);
		$today = gmdate($date_format, CURRENT_TIMESTAMP+$diff);
		$yesterday = gmdate($date_format, CURRENT_TIMESTAMP+$diff-86400);

		if (!$no_text)
		{
			if ($date == $today)
				$date = $this->lang->t('Today');
			else if ($date == $yesterday)
				$date = $this->lang->t('Yesterday');
		}

		if ($date_only)
			return $date;
		else if ($time_only)
			return gmdate($time_format, $timestamp);
		else
			return $date.' '.gmdate($time_format, $timestamp);
	}

	function format_time_difference($logged)
	{
		$difference = CURRENT_TIMESTAMP - $logged;
		$intervals = array('minute'=> 60); 
		if ($difference < 60)
		{
			if ($difference == '1')
				$difference = $this->lang->t('Second ago', $difference);
			else
				$difference = $this->lang->t('Seconds ago', $difference);
		}        

		if ($difference >= 60)
		{
			$difference = floor($difference/$intervals['minute']);
			if ($difference == '1')
				$difference = $this->lang->t('Minute ago', $difference);
			else
				$difference = $this->lang->t('Minutes ago', $difference);
		}  
		return $difference;
	}

	//
	// Format time in seconds to display as hours/days/months/never
	//
	function format_expiration_time($seconds)
	{
		$seconds = intval($seconds);

		if ($seconds <= 0)
			return $this->lang->t('Never');
		else if ($seconds % (30*24*60*60) == '0')
		{
			//Months
			$expiration_value = $seconds / (30*24*60*60);
			return $this->lang->t('No of months', $expiration_value);
		}
		else if ($seconds % (24*60*60) == '0')
		{
			//Days
			$expiration_value = $seconds / (24*60*60);
			return $this->lang->t('No of days', $expiration_value);
		}
		else
		{
			//Hours
			$expiration_value = $seconds / (60*60);
			return $this->lang->t('No of hours', $expiration_value);
		}
	}

	//
	// Get expiration time (in seconds)
	//
	function get_expiration_time($value = 0, $unit)
	{
		$value = abs(intval($value));

		if ($value == '0')
			$expiration_time = 0;
		else if ($unit == 'minutes')
			$expiration_time = $value*60;
		else if ($unit == 'hours')
			$expiration_time = $value*60*60;
		else if ($unit == 'days')
			$expiration_time = $value*24*60*60;
		else if ($unit == 'months')
			$expiration_time = $value*30*24*60*60;
		else if ($unit == 'never')
			$expiration_time = 0;
		else 
			$expiration_time = 0;

		return $expiration_time;
	}

	//
	// Checks when a posting ban has expired
	//
	function format_posting_ban_expiration($expires)
	{
		$month = (24*60*60*date('t'));
		$day = (24*60*60);
		$hour = (60*60);
		$minute = 60;
		switch(true)
		{
			case ($expires > $month):
				$seconds = array(round($expires/$month), ($expires % $month), $this->lang->t('Months'));
			break;
			case ($expires > $day):
				$seconds = array(round($expires/$day), ($expires % $day), $this->lang->t('Days'));
			break;
			case ($expires > $hour):
				$seconds = array(round($expires/$hour), ($expires % $hour), $this->lang->t('Hours'));
			break;
			case ($expires > $minute):
				$seconds = array(round($expires/$minute), ($expires % $minute), $this->lang->t('Minutes'));
			break;
			default:
				$seconds = array(10, 0, $this->lang->t('Never'));			
			break;
		}

		return $seconds;
	}
}