<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('AURA_ROOT'))
	exit('The constant AURA_ROOT must be defined and point to a valid Aura installation directory.');

require AURA_ROOT.'app/Aura.php';
require AURA_ROOT.'app/registry.php';
require AURA_ROOT.'app/template.php';

define('CURRENT_TIMESTAMP', time());

// The maximum size of a post, in bytes, since the field is now MEDIUMTEXT this allows ~16MB but lets cap at 1MB...
if (!defined('AURA_MAX_POSTSIZE'))
	define('AURA_MAX_POSTSIZE', 1048576);

if (!defined('AURA_SEARCH_MIN_WORD'))
	define('AURA_SEARCH_MIN_WORD', 3);

if (!defined('AURA_SEARCH_MAX_WORD'))
	define('AURA_SEARCH_MAX_WORD', 20);

if (!defined('FORUM_MAX_COOKIE_SIZE'))
	define('FORUM_MAX_COOKIE_SIZE', 4048);

if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest')
	define('AURA_AJAX_REQUEST', 1);

if (function_exists('date_default_timezone_set') && function_exists('date_default_timezone_get'))
	date_default_timezone_set(@date_default_timezone_get());

// Various user group IDs
define('AURA_UNVERIFIED', 0);
define('AURA_ADMIN', 1);
define('AURA_MOD', 2);
define('AURA_GUEST', 4);
define('AURA_MEMBER', 6);
define('ATTEMPT_DELAY', 1000);
define('TIMEOUT', 5000);