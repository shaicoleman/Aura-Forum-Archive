<?php
if (!defined('INSTALL_ROOT'))
	exit;

//
// Take an educated guess at the base URL
//
function guess_base_url()
{
	static $base_url;

	if (!isset($base_url))
	{
		$base_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') ? 'https://' : 'http://'; // protocol
		$base_url .= preg_replace('%:(80|443)$%', '', $_SERVER['HTTP_HOST']); // host[:port]
		$base_url .= str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])); // path

		if (substr($base_url, -1) == '/')
			$base_url = substr($base_url, 0, -1);

		// Remove 'install'
		$base_url = substr($base_url, 0, -7);
	}

	return $base_url;
}

//
// Fetch a list of available styles
//
function forum_list_styles()
{
	$styles = array();
	$style = AURA_ROOT.'styles';

	$styles = array();
	$files = array_diff(scandir($style), array('.', '..'));
	foreach ($files as $style)
	{
		if (substr($style, -4) == '.css')
			$styles[] = substr($style, 0, -4);
	}

	natcasesort($styles);
	return $styles;
}

//
// Generate the configutation file
//
function generate_config_file($session_id, $admin_dir, $config)
{
	return '<?php'."\nclass config\n{\n\t/*\n\t * Unique installation session\n\t */\n\tCONST SESSION = '".$session_id."';\n\n\t/*\n\t * Setup the Administration directory on the server\n\t */\n\tCONST ADMIN_DIR = '".$admin_dir."';\n\n\t/*\n\t * Setup the extensions directory\n\t */\n\tCONST EXTENSIONS_DIR = 'include/extensions/';\n\n\t/*\n\t * And the same for the plugins directory too\n\t */\n\tCONST PLUGINS_DIR = 'include/plugins/';\n\t/*\n\t * Here we provide the database credentials\n\t */\n\tpublic static \$db = ".var_export($config, true).";\n}\n";
}