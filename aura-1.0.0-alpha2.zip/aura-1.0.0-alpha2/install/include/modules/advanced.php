<?php
if (!defined('INSTALL_ROOT'))
	exit;

class module_advanced extends installer
{
	function run()
	{
		$errors = array();
		if (isset($_POST['form_sent']))
		{
			$csrf_token = isset($_POST['csrf_token']) ? utf8_trim($_POST['csrf_token']) : '';
			if (!aura_hash_equals(self::$data['csrf_token'], $csrf_token))
				throw new Exception($this->lang('Invalid csrf token'));

			$advanced = array(
				'cookie_name' => isset($_POST['cookie_name']) ? utf8_trim($_POST['cookie_name']) : installation::DEFAULT_COOKIE_NAME.random_key(6, false, true),
				'cookie_seed' => isset($_POST['cookie_seed']) ? utf8_trim($_POST['cookie_seed']) : random_key(16, false, true),
				'admin_dir' => isset($_POST['admin_dir']) && preg_match('/([a-z0-9]+)/', $_POST['admin_dir']) ? utf8_trim($_POST['admin_dir']) : config::ADMIN_DIR,
				'delete_posts' => isset($_POST['delete_posts']) && $_POST['delete_posts'] == '1' ? '1' : '0',
				'gzip' => isset($_POST['gzip']) && $_POST['gzip'] == '1' ? '1' : '0',
				'use_avatars' => isset($_POST['use_avatars']) && $_POST['use_avatars'] == '1' ? '1' : '0',
				'allow_regs' => isset($_POST['allow_regs']) && $_POST['allow_regs'] == '1' ? '1' : '0',
			);

			if (aura_strlen($advanced['admin_dir']) < 4)
				$errors[] = $this->lang->t('Admin directory too short');

			if (empty($errors))
			{
				installer::add_progress(6);
				self::$data = array_merge($advanced, self::$data);

				header('Location: '.self::$base_url.'install/?act=install');
				exit;
			}
		}

		$data = array(
			'cookie_name' => installation::DEFAULT_COOKIE_NAME.random_key(6, false, true),
			'cookie_seed' => random_key(16, false, true),
			'admin_dir' => config::ADMIN_DIR,
			'errors' => $errors,
		);

		$this->template->output('advanced', $data);
	}
}