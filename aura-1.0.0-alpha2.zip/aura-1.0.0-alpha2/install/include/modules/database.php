<?php
if (!defined('INSTALL_ROOT'))
	exit;

class module_database extends installer
{
	function run()
	{
		$errors = array();
		if (isset($_POST['form_sent']))
		{
			$csrf_token = isset($_POST['csrf_token']) ? utf8_trim($_POST['csrf_token']) : '';
			if (!aura_hash_equals(self::$data['csrf_token'], $csrf_token))
				throw new Exception($this->lang->t('Invalid csrf token'));

			$config = array(
				'type' => isset($_POST['db_type']) ? utf8_trim($_POST['db_type']) : '',
				'host' => isset($_POST['db_host']) ? utf8_trim($_POST['db_host']) : '',
				'engine' => isset($_POST['db_engine']) && $_POST['db_type'] == 'mysql' && in_array($_POST['db_engine'], array_keys(installation::$engines)) ? utf8_trim($_POST['db_engine']) : '',
				'prefix' => isset($_POST['db_prefix']) ? utf8_trim($_POST['db_prefix']) : '',
				'username' => isset($_POST['db_username']) ? utf8_trim($_POST['db_username']) : '',
				'password' => isset($_POST['db_password']) ? utf8_trim($_POST['db_password']) : '',
				'db_name' => isset($_POST['db_name']) ? utf8_trim($_POST['db_name']) : '',
				'p_connect' => isset($_POST['p_connect']) && $_POST['p_connect'] == '1' ? true : false,
			);

			if (aura_strlen($config['db_name']) < 1)
				$errors[] = $this->lang->t('Invalid database name');

			if (strlen($config['prefix']) > 0 && (!preg_match('%^[a-zA-Z_][a-zA-Z0-9_]*$%', $config['prefix']) || strlen($config['prefix']) > 40))
				$errors[] = $this->lang->t('Invalid prefix');

			if (empty($errors))
			{
				$db_type = '\database\\'.$config['type'];
				$db = new $db_type($config);

				// Here we need a MySQL specific check on whether InnoDB is enabled
				if ($config['type'] == 'mysql')
				{
					$ps = $db->run('SELECT support FROM INFORMATION_SCHEMA.ENGINES WHERE ENGINE=\'InnoDB\'');
					$result = $ps->fetchColumn();

					if (!in_array($result, array('YES', 'DEFAULT')))
						$errors[] = $this->lang->t('Innodb disabled');
				}

				if ($db->table_exists('users'))
					$errors[] = $this->lang->t('Existing table error', $config['prefix'], $config['db_name']);

				$db_info = $db->get_version();
				if (version_compare($db_info['version'], installation::$versions[$config['type']], '<'))
					$errors[] = $this->lang->t('Mysql version problem', $mysql_info['version'], installation::$versions[$config['type']]);

				if (empty($errors))
				{
					installer::add_progress(8);
					self::$data['config'] = array_merge(self::$data['config'], $config);

					header('Location: '.self::$base_url.'install/?act=user');
					exit;
				}
			}
		}

		$extensions = array();
		$drivers = PDO::getAvailableDrivers();
		foreach ($drivers as $driver)
		{
			if (in_array($driver, array_keys(installation::$drivers)))
				$extensions[$driver] = installation::$drivers[$driver];
		}

		$data = array(
			'POST' => $_POST,
			'errors' => $errors,
			'drivers' => $extensions,
			'engines' => installation::$engines,
		);

		$this->template->output('database', $data);
	}
}