<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
if (!defined('INSTALL_ROOT'))
	exit;

session_start();
session_regenerate_id();

define('AURA_ROOT', INSTALL_ROOT.'/../');

require INSTALL_ROOT.'include/components/installation.php';
require INSTALL_ROOT.'include/components/functions.php';
require INSTALL_ROOT.'include/components/registry.php';
require INSTALL_ROOT.'include/components/installer.php';
require INSTALL_ROOT.'include/components/template.php';

// Send the Content-type header in case the web server is setup to send something else
header('Content-type: text/html; charset=utf-8');

// Has Aura already been installed?
if (file_exists(AURA_ROOT.'include/config.php'))
	include AURA_ROOT.'include/config.php';

// If the installation is not corrupt, then abort
if (defined('config::SESSION'))
{
	header('Location: '.guess_base_url());
	exit;
}
else
{
	// We define the class here for now so we can use it later when loading scripts
	class config
	{
		const SESSION = '';
		const ADMIN_DIR = 'admin';
	}
}

// Load the functions script
require AURA_ROOT.'include/functions.php';

// Register the autoloader for non-existing classes
spl_autoload_register('autoloader');

// Load UTF-8 functions
require AURA_ROOT.'include/lib/utf8/utf8.php';

// Strip out "bad" UTF-8 characters
$_GET = remove_bad_characters($_GET);
$_POST = remove_bad_characters($_POST);
$_COOKIE = remove_bad_characters($_COOKIE);

// Force POSIX locale (to prevent functions such as strtolower() from messing up UTF-8 strings)
setlocale(LC_CTYPE, 'C');

if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest')
	define('AURA_AJAX_REQUEST', 1);

if (function_exists('date_default_timezone_set') && function_exists('date_default_timezone_get'))
	date_default_timezone_set(@date_default_timezone_get());

define('CURRENT_TIMESTAMP', time());
define('AURA_ADMIN_DIR', 'admin');

// Setup the error handler
$handler = new \errors\handler;
set_error_handler(array($handler, 'handle'));
set_exception_handler(array($handler, 'handle'));

// We want no errors reported, they're handled by the error handler
error_reporting(E_ALL);

$registry = new registry;

$registry->cache = new \cache\cache($registry);
$registry->lang = new lang($registry);

if (isset($_POST['change_language']))
{
	$registry->install_lang = isset($_POST['language']) && preg_match('/^[a-z]{2}_[A-Z]{2}$/', $_POST['language']) ? utf8_trim($_POST['language']) : installation::DEFAULT_LANG;
	$_SESSION['language'] = $registry->install_lang;
}
else
	$registry->install_lang = (isset($_SESSION['language'])) ? $_SESSION['language'] : installation::DEFAULT_LANG;

$registry->lang->set_language($registry->install_lang);
$registry->lang->load('install');

$registry->config = array(
	'o_style_path' => 'styles',
	'o_style_dir' => guess_base_url().'styles/',
	'o_password_min_length' => installation::MIN_PASSWORD_LENGTH,
	'o_password_min_digits' => installation::PASSWORD_MIN_DIGITS,
	'o_password_min_symbols' => installation::PASSWORD_MIN_UPPERCASE,
	'o_password_min_uppercase' => installation::PASSWORD_MIN_SYMBOLS,
);

$registry->template = new template($registry);
$setup = new installer($registry);

define('AURA_UNVERIFIED', 0);
define('AURA_ADMIN', 1);