<?php
/**
 * Copyright (C) 2017 Aura (https://www.get-aura.org)
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

define('INSTALL_ROOT', __DIR__.'/');
require INSTALL_ROOT.'include/init.php';

$setup->run();