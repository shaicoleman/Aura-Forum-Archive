<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

class Aura
{
	const DEFAULT_APP = 'forums';
	const DEFAULT_ACT = 'index';
	const DEFAULT_DO = 'execute';
	protected $registry;
	/*
	 * Main App entry point- launch the App
	 */
	public static function run()
	{
		$aura = new Aura();
		$aura->initiate();

		$aura->set_vars();

		$aura->route_request();
	}

	/*
	 * Outside App entry point- we setup only the bare essentials
	 */
	public static function setup()
	{
		$aura = new Aura();
		$aura->initiate();

		$aura->set_vars();
	}

	/*
	 * Main Cron Job entry point
	 */
	public static function cron_mode()
	{
		if (!defined('AURA_CRON_MANAGER'))
		{
			self::run();
			exit;
		}

		$aura = new Aura();
		$aura->initiate();

		$aura->set_vars();

		$aura->tasks->run_tasks();
	}

	/*
	 * Initiate the app and get things moving
	 */
	public function initiate()
	{
		$this->registry = registry::construct();
		$this->registry->configure();
	}

	public function set_vars()
	{
		$this->user = $this->registry->user;
		$this->config = $this->registry->config;
		$this->cache = $this->registry->cache;
		$this->lang = $this->registry->lang;
		$this->db = $this->registry->db;
		$this->rewrite = $this->registry->rewrite;
		$this->template = $this->registry->template;
		$this->functions = $this->registry->functions;
		$this->tasks = $this->registry->tasks;
	}

	public function route_request()
	{
		$app = isset($_GET['app']) ? utf8_trim($_GET['app']) : self::DEFAULT_APP;
		$action = isset($_GET['act']) ? utf8_trim($_GET['act']) : self::DEFAULT_ACT;
		$do = isset($_GET['do']) ? utf8_trim($_GET['do']) : self::DEFAULT_DO;

		$file = AURA_ROOT.'include/modules/'.$app.'/'.$action.'.php';
		if (!file_exists($file))
		{
			$file = AURA_ROOT.'include/modules/'.$app.'/index.php';
			$action = 'index';
		}

		require $file;

		$class = $action.'_controller';
		$controller = new $class($this->registry);

		if (!is_callable(array($controller, $do)))
			$do = 'execute';

		call_user_func(array($controller, $do));
	}
}

abstract class base_controller
{
	protected $registry;
	final public function __construct($registry)
	{
		$this->registry = $registry;
		$this->user = $registry->user;
		$this->config = $registry->config;
		$this->cache = $registry->cache;
		$this->lang = $registry->lang;
		$this->db = $registry->db;
		$this->rewrite = $registry->rewrite;
		$this->template = $registry->template;
		$this->functions = $registry->functions;
		$this->manager = $registry->manager;
		$this->tasks = $registry->tasks;
	}

	protected abstract function execute();
}

class AuraClass
{
	final public function __construct(registry $registry)
	{
		$this->registry = $registry;
		$this->user = $registry->user;
		$this->config = $registry->config;
		$this->cache = $registry->cache;
		$this->lang = $registry->lang;
		$this->db = $registry->db;
		$this->rewrite = $registry->rewrite;
		$this->template = $registry->template;
		$this->functions = $registry->functions;
		$this->tasks = $registry->tasks;
	}
}