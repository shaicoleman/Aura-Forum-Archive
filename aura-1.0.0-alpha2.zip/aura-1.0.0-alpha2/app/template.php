<?php
class template
{
	public $header;
	public $footer;
	protected $manager;
	public function __construct($registry)
	{
		$this->registry = $registry;
		$this->user = $registry->user;
		$this->cache = $registry->cache;
		$this->lang = $registry->lang;
		$this->config = $registry->config;

		$loader = new Twig_Loader_Filesystem(AURA_ROOT.'include/templates');

		$style_root = (($this->config['o_style_path'] != 'styles') ? $this->config['o_style_path'] : AURA_ROOT.$this->config['o_style_path']).'/'.$this->user['style'].'/templates/';
		$loader->addPath(AURA_ROOT.'include/templates/', 'core');

		if (file_exists($style_root)) // If the custom style doesn't use templates, then this is silly
			$loader->addPath($style_root, 'style');

		$this->manager = new Twig_Environment($loader, 
			array(
				'cache' => $this->cache->cache_dir.'templates/'.$this->user['style'],
				'debug' => ($this->config['o_debug_mode'] == '1') ? true : false,
			)
		);
	}

	public function load($tpl_file)
	{
		$style_root = (($this->config['o_style_path'] != 'styles') ? $this->config['o_style_path'] : AURA_ROOT.$this->config['o_style_path']).'/'.$this->user['style'].'/templates/';
		if (file_exists($style_root.$tpl_file))
			$tpl_file = $this->manager->loadTemplate('@style/'.$tpl_file);
		else
			$tpl_file = $this->manager->loadTemplate('@core/'.$tpl_file);

		return $tpl_file;
	}

	public function output($tpl, $data = array(), $header = true, $footer = true)
	{
		if ($header)
			$this->execute_header();

		echo $tpl->render(array_merge(
				array(
					'lang' => $this->lang,
					'aura_config' => $this->config,
					'aura_user' => $this->user,
				), $data
			)
		);

		if ($footer)
			$this->execute_footer();
	}

	public function render($tpl, $data = array())
	{
		return $tpl->render(array_merge(
				array(
					'lang' => $this->lang,
					'aura_config' => $this->config,
					'aura_user' => $this->user,
				), $data
			)
		);
	}

	public function execute_header()
	{
		$header = new \templates\template_header($this->registry);
		$header->set_data($this->header);
		$args = $header->fetch_data();

		$tpl = $this->load($args['tpl_file']);
		$this->output($tpl, $args, false, false);
	}

	public function execute_footer()
	{
		$footer = new \templates\template_footer($this->registry);
		$footer->set_data($this->footer);
		$args = $footer->fetch_data();

		$tpl = $this->load($args['tpl_file']);
		$this->output($tpl, $args, false, false);
	}
}

abstract class template_element
{
	protected $data = array();
	final public function __construct($registry)
	{
		$this->registry = $registry;
		$this->db = $registry->db;
		$this->config = $registry->config;
		$this->user = $registry->user;
		$this->url = $registry->url;
		$this->lang = $registry->lang;
		$this->functions = $registry->functions;
		$this->cache = $registry->cache;
		$this->rewrite = $registry->rewrite;
	}

	final public function set_data($data)
	{
		$this->data = $data;
	}

	abstract function fetch_data();
}