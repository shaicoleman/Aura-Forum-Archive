<?php
/**
 * Copyright (C) 2015 Panther (https://www.pantherforum.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/');
	require PANTHER_ROOT.'include/common.php';
}

// Tell header we need some stuff
define('POSTING', 1);
define('REPUTATION', 1);

if ($panther_user['g_read_board'] == '0')
	message($lang_common['No view'], false, '403 Forbidden');

$action = isset($_GET['action']) ? $_GET['action'] : null;
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$pid = isset($_GET['pid']) ? intval($_GET['pid']) : 0;
if ($id < 1 && $pid < 1)
	message($lang_common['Bad request'], false, '404 Not Found');

// Load the viewtopic.php language file
require PANTHER_ROOT.'lang/'.$panther_user['language'].'/topic.php';

// If a post ID is specified we determine topic ID and page number so we can redirect to the correct message
if ($pid)
{
	$data = array(
		':id'	=>	$pid,
	);
	$ps = $db->select('posts', 'topic_id, posted', $data, 'id=:id AND approved=1 AND deleted=0');
	if (!$ps->rowCount())
		message($lang_common['Bad request'], false, '404 Not Found');
	else
		list($id, $posted) = $ps->fetch(PDO::FETCH_NUM);
	
	$data = array(
		':id'	=>	$id,
		':posted'	=>	$posted,
	);

	// Determine on which page the post is located (depending on $panther_user['disp_posts'])
	$ps = $db->select('posts', 'COUNT(id)', $data, 'topic_id=:id AND posted<:posted AND approved=1 AND deleted=0');
	$num_posts = $ps->fetchColumn() + 1;

	$_GET['p'] = ceil($num_posts / $panther_user['disp_posts']);
}
else
{
	// If action=new, we redirect to the first new post (if any)
	if ($action == 'new')
	{
		if (!$panther_user['is_guest'])
		{
			// We need to check if this topic has been viewed recently by the user
			$tracked_topics = get_tracked_topics();
			$last_viewed = isset($tracked_topics['topics'][$id]) ? $tracked_topics['topics'][$id] : $panther_user['last_visit'];
			
			$data = array(
				':id'	=>	$id,
				':posted'	=>	$last_viewed,
			);

			$ps = $db->select('posts', 'MIN(id)', $data, 'topic_id=:id AND posted>:posted AND approved=1 AND deleted=0');
			$first_new_post_id = $ps->fetchColumn();

			if ($first_new_post_id)
			{
				header('Location: '.get_link($panther_url['post'], array($first_new_post_id)));
				exit;
			}
		}

		// If there is no new post, we go to the last post
		$action = 'last';
	}

	// If action=last, we redirect to the last post
	if ($action == 'last')
	{
		$data = array(
			':id'	=>	$id,
		);

		$ps = $db->select('posts', 'MAX(id)', $data, 'topic_id=:id AND approved=1 AND deleted=0');
		$last_post_id = $ps->fetchColumn();

		if ($last_post_id)
		{
			header('Location: '.get_link($panther_url['post'], array($last_post_id)));
			exit;
		}
	}
}

$data = array(
	':gid'	=>	$panther_user['g_id'],
	':tid'	=>	$id,
);

// Fetch some info about the topic
if (!$panther_user['is_guest'])
{
	$data[':id'] = $panther_user['id'];
	$ps = $db->run('SELECT pf.forum_name AS parent, f.parent_forum, f.protected, t.subject, t.poster, t.closed, t.archived, t.question, t.num_replies, t.sticky, t.first_post_id, t.last_post, p.type, p.options, p.votes, p.voters, p.posted, f.id AS forum_id, f.forum_name, f.use_reputation, f.moderators, f.password, fp.post_replies, fp.download, s.user_id AS is_subscribed FROM '.$db->prefix.'topics AS t INNER JOIN '.$db->prefix.'forums AS f ON f.id=t.forum_id LEFT JOIN '.$db->prefix.'topic_subscriptions AS s ON (t.id=s.topic_id AND s.user_id=:id) LEFT JOIN '.$db->prefix.'forum_perms AS fp ON (fp.forum_id=f.id AND fp.group_id=:gid) LEFT JOIN '.$db->prefix.'forums AS pf ON f.parent_forum=pf.id LEFT JOIN '.$db->prefix.'polls AS p ON t.id=p.topic_id WHERE (fp.read_forum IS NULL OR fp.read_forum=1) AND t.id=:tid AND t.moved_to IS NULL AND t.approved=1 AND t.deleted=0', $data);
}
else
	$ps = $db->run('SELECT pf.forum_name AS parent, f.parent_forum, f.protected, t.subject, t.poster, t.closed, t.archived, t.question, t.num_replies, t.sticky, t.first_post_id, t.last_post, p.type, p.options, p.votes, p.voters, p.posted, f.id AS forum_id, f.forum_name, f.use_reputation, f.moderators, f.password, fp.post_replies, fp.download, 0 AS is_subscribed FROM '.$db->prefix.'topics AS t INNER JOIN '.$db->prefix.'forums AS f ON f.id=t.forum_id LEFT JOIN '.$db->prefix.'forum_perms AS fp ON (fp.forum_id=f.id AND fp.group_id=:gid) LEFT JOIN '.$db->prefix.'forums AS pf ON f.parent_forum=pf.id LEFT JOIN '.$db->prefix.'polls AS p ON t.id=p.topic_id WHERE (fp.read_forum IS NULL OR fp.read_forum=1) AND t.id=:tid AND t.moved_to IS NULL AND t.approved=1 AND t.deleted=0', $data);

if (!$ps->rowCount())
	message($lang_common['Bad request'], false, '404 Not Found');
else
	$cur_topic = $ps->fetch();

// Sort out who the moderators are and if we are currently a moderator (or an admin)
$mods_array = ($cur_topic['moderators'] != '') ? unserialize($cur_topic['moderators']) : array();
$is_admmod = ($panther_user['is_admin'] || ($panther_user['g_moderator'] == '1' && $panther_user['g_global_moderator'] ||  array_key_exists($panther_user['username'], $mods_array))) ? true : false;
if ($is_admmod)
	$admin_ids = get_admin_ids();

if ($cur_topic['password'] != '')
		check_forum_login_cookie($cur_topic['forum_id'], $cur_topic['password']);

if ($cur_topic['protected'] == '1' && $panther_user['username'] != $cur_topic['poster'] && !$is_admmod)
	message($lang_common['No permission']);

if ($panther_config['o_archiving'] == '1' && $cur_topic['archived'] == '0')
{
	if ($cur_topic['archived'] !== '2')
	{
		$archive_rules = unserialize($panther_config['o_archive_rules']);
		$cur_topic['archived'] = check_archive_rules($archive_rules, $id);
	}
}

// Can we or can we not post replies?
if ($cur_topic['archived'] == '1')
	$post_link = "\t\t\t".'<p class="postlink conr">'.$lang_topic['Topic archived'].'</p>'."\n";
else
{
	if ($cur_topic['closed'] == '0')
	{
		if (($cur_topic['post_replies'] == '' && $panther_user['g_post_replies'] == '1') || $cur_topic['post_replies'] == '1' || $is_admmod)
			$post_link = "\t\t\t".'<p class="postlink conr"><a href="'.get_link($panther_url['new_reply'], array($id)).'">'.$lang_topic['Post reply'].'</a></p>'."\n";
		else
			$post_link = '';
	}
	else
	{
		$post_link = $lang_topic['Topic closed'];

		if ($is_admmod)
			$post_link .= ' / <a href="'.get_link($panther_url['new_reply'], array($id)).'">'.$lang_topic['Post reply'].'</a>';

		$post_link = "\t\t\t".'<p class="postlink conr">'.$post_link.'</p>'."\n";
	}
}

// Add/update this topic in our list of tracked topics
if (!$panther_user['is_guest'])
{
	$tracked_topics = get_tracked_topics();
	$tracked_topics['topics'][$id] = time();
	set_tracked_topics($tracked_topics);
}

// Preg replace is slow!
$url_subject = url_friendly($cur_topic['subject']);
$url_forum = url_friendly($cur_topic['forum_name']);

// Determine the post offset (based on $_GET['p'])
$num_pages = ceil(($cur_topic['num_replies'] + 1) / $panther_user['disp_posts']);

$p = (!isset($_GET['p']) || $_GET['p'] <= 1 || $_GET['p'] > $num_pages) ? 1 : intval($_GET['p']);
$start_from = $panther_user['disp_posts'] * ($p - 1);

// Generate paging links
$paging_links = '<span class="pages-label">'.$lang_common['Pages'].' </span>'.paginate($num_pages, $p, $panther_url['topic_paginate'], array($id, $url_subject));

if ($panther_config['o_censoring'] == '1')
	$cur_topic['subject'] = censor_words($cur_topic['subject']);

$quickpost = false;
if ($panther_config['o_quickpost'] == '1' && $cur_topic['archived'] != '1' &&
	($cur_topic['post_replies'] == '1' || ($cur_topic['post_replies'] == '' && $panther_user['g_post_replies'] == '1')) &&
	($cur_topic['closed'] == '0' || $is_admmod))
{
	// Load the post.php language file
	require PANTHER_ROOT.'lang/'.$panther_user['language'].'/post.php';

	$required_fields = array('req_message' => $lang_common['Message']);
	if ($panther_user['is_guest'])
	{
		$required_fields['req_username'] = $lang_post['Guest name'];
		if ($panther_config['p_force_guest_email'] == '1')
			$required_fields['req_email'] = $lang_common['Email'];
	}
	$quickpost = true;
}

if (!$panther_user['is_guest'] && $panther_config['o_topic_subscriptions'] == '1')
{
	if ($cur_topic['is_subscribed'])
		// I apologize for the variable naming here. It's a mix of subscription and action I guess :-)
		$subscraction = "\t\t".'<p class="subscribelink clearb"><span>'.$lang_topic['Is subscribed'].' - </span><a href="'.get_link($panther_url['topic_unsubscribe'], array($id)).'">'.$lang_topic['Unsubscribe'].'</a></p>'."\n";
	else
		$subscraction = "\t\t".'<p class="subscribelink clearb"><a href="'.get_link($panther_url['topic_subscribe'], array($id)).'">'.$lang_topic['Subscribe'].'</a></p>'."\n";
}
else
	$subscraction = '';

// Add relationship meta tags
$page_head = array();
$page_head['canonical'] = "\t".'<link href="'.get_link($panther_url['topic'], array($id, $url_subject)).'" rel="canonical" />';

if ($num_pages > 1)
{
	if ($p > 1)
		$page_head['prev'] = "\t".'<link href="'.get_link($panther_url['topic_page'], array($id, $url_subject, ($p - 1))).'" rel="prev" />';
	if ($p < $num_pages)
		$page_head['next'] = "\t".'<link href="'.get_link($panther_url['topic_page'], array($id, $url_subject, ($p + 1))).'" rel="next" />';
}

if ($panther_config['o_feed_type'] == '1')
	$page_head['feed'] = "\t".'<link href="'.get_link($panther_url['topic_rss'], array($id)).'" type="application/rss+xml" rel="alternate" title="'.$lang_common['RSS topic feed'].'" />';
else if ($panther_config['o_feed_type'] == '2')
	$page_head['feed'] = "\t".'<link href="'.get_link($panther_url['topic_atom'], array($id)).'" type="application/atom+xml" rel="alternate" title="'.$lang_common['Atom topic feed'].'" />';

$csrf_token = generate_csrf_token();
$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), panther_htmlspecialchars($cur_topic['forum_name']), panther_htmlspecialchars($cur_topic['subject']));
define('PANTHER_ALLOW_INDEX', 1);
define('PANTHER_ACTIVE_PAGE', 'index');
require PANTHER_ROOT.'header.php';

require PANTHER_ROOT.'include/parser.php';
$post_count = 0; // Keep track of post numbers

$data = array(
	':id'	=>	$id,
);

// Retrieve a list of post IDs, LIMIT is (really) expensive so we only fetch the IDs here then later fetch the remaining data
$ps = $db->select('posts', 'id', $data, 'topic_id=:id AND approved=1 AND deleted=0', 'id LIMIT '.$start_from.','.$panther_user['disp_posts']);

$post_ids = array();
$ps->setFetchMode(PDO::FETCH_COLUMN, 0);
foreach ($ps as $cur_post_id)
{
	$post_ids[] = $cur_post_id;
	$placeholders[] = '?';
}

$content = array();
if (empty($post_ids))
	error_handler(E_ERROR, 'The post table and topic table seem to be out of sync', __FILE__, __LINE__);

flux_hook('viewtopic_before_display');

// Retrieve the posts (and their respective poster/online status)
if ($cur_topic['question'] != '')
{
	require PANTHER_ROOT.'lang/'.$panther_user['language'].'/poll.php';	

	// Make sure stuff is declared properly
	$options = ($cur_topic['options'] != '') ? unserialize($cur_topic['options']) : array();
	$voters = ($cur_topic['voters'] != '') ? unserialize($cur_topic['voters']) : array();
	$votes = ($cur_topic['votes'] != '') ? unserialize($cur_topic['votes']) : array();
	$total_votes = count($voters);
	$total = $percent = 0;

	$poll_actions = array();
	if ($panther_user['username'] == $cur_topic['poster'] || $is_admmod)
	{
		$poll_actions[] = '<li class="postdelete"><span><a href="'.get_link($panther_url['poll_delete'], array($id)).'">'.$lang_topic['Delete'].'</a></span></li> ';
		$poll_actions[] = '<li class="postedit"><span><a href="'.get_link($panther_url['poll_edit'], array($id)).'">'.$lang_topic['Edit'].'</a></span></li> ';

		if ($is_admmod)
			$poll_actions[] = '<li class="postedit"><span><a href="'.get_link($panther_url['poll_reset'], array($id)).'">'.$lang_poll['Reset'].'</a></span></li> ';
	}

	// Check and make sure we can vote
	$can_vote = ($quickpost && !$panther_user['is_guest']) && (!in_array($panther_user['id'], $voters)) ? true : false;

	// Grab the total amount of percent
	for ($i = 0; $i < count($options); $i++)
		$total += (isset($votes[$i])) ? $votes[$i] : 0;

	if ($can_vote)
	{
		$answers = array();
		$poll_row_tpl = panther_template('poll_vote_row.tpl');
		for ($i = 0; $i < count($options); $i++)
		{
			$input = ($cur_topic['type'] == 1) ? '<input name="vote"'.(($i == 0) ? ' checked="checked"' : '').' type="radio" value="'.$i.'" />' : '<input name="options['.$i.']" type="checkbox" value="1" />' ;
			$search = array(
				'{input}' => $input,
				'{answer}' => panther_htmlspecialchars($options[$i]),
			);

			$answers[] = str_replace(array_keys($search), array_values($search), $poll_row_tpl);
		}

		// Sort out the main poll template
		$poll_tpl = panther_template('poll_vote.tpl');
		$search = array(
			'{form_action}' => get_link($panther_url['poll_vote']),
			'{question}' => sprintf($lang_topic['Poll'], panther_htmlspecialchars($cur_topic['question'])),
			'{id}' => $id,
			'{csrf_token}' => generate_csrf_token(),
			'{poll_answers}' => count($answers) ? implode("\n", $answers) : '',
			'{submit}' => $lang_common['Submit'],
		);

		$poll_tpl = str_replace(array_keys($search), array_values($search), $poll_tpl);
	}
	else
	{
		$answers = array();
		$poll_row_tpl = panther_template('poll_display_row.tpl');
		foreach ($options as $key => $value)
		{
			// prevent division by zero
			if (isset($votes[$key]) && $total != 0)
			{
				$percent =  ($votes[$key] * 100) / $total;
				$percent = floor($percent);
			}
			else
				$percent = 0;
			
			$percent_int = (isset($votes[$key]) && $percent != 0) ? $percent : 1;
			$percent_vote = (isset($votes[$key])) ? $percent.'% (' . $votes[$key].')' : '0% (0)';
			$search = array(
				'{value}' => panther_htmlspecialchars($value),
				'{percent}' => $percent_int,
				'{vote}' => $percent_vote,
			);

			$answers[] = str_replace(array_keys($search), array_values($search), $poll_row_tpl);
		}

		$poll_tpl = panther_template('poll_display.tpl');
		$search = array(
			'{question}' => sprintf($lang_topic['Poll'], panther_htmlspecialchars($cur_topic['question'])),
			'{poll_answers}' => count($answers) ? implode("\n", $answers) : '',
			'{vote_information}' => sprintf($lang_topic['Voters'], $total_votes),
			'{poll_actions}' => implode("\n\t\t\t\t\t\t", $poll_actions),
		);

		$poll_tpl = str_replace(array_keys($search), array_values($search), $poll_tpl);
	}

	$content[] = str_replace('{poll_content}', $poll_tpl, panther_template('poll_wrapper.tpl'));
}

$results = array();
$download = false;
if ($panther_user['is_admin'])
	$download = true;
else if ($cur_topic['download'] == '1' || $cur_topic['download'] == '')
	$download = true;

if ($download)
{
	$ps = $db->run('SELECT id, filename, post_id, size, downloads FROM '.$db->prefix.'attachments WHERE post_id IN ('.implode(',', $placeholders).') ORDER BY post_id', $post_ids);
	foreach ($ps as $cur_attach)
	{
		if (!isset($results[$cur_attach['post_id']]))
			$results[$cur_attach['post_id']] = array();

		$results[$cur_attach['post_id']][$cur_attach['id']] = $cur_attach;
	}
}

$post_content_tpl = panther_template('post.tpl');
$signature_tpl = panther_template('signature.tpl');
$post_action_tpl = panther_template('post_actions.tpl');
$email_tpl = panther_template('email_link.tpl');
$ps = $db->run('SELECT u.email, u.use_gravatar, u.title, u.url, u.location, u.signature, u.email_setting, u.num_posts, u.registered, u.admin_note, u.reputation AS poster_reputation, p.id, p.reputation, p.poster AS username, p.poster_id, p.poster_ip, p.poster_email, p.message, p.hide_smilies, p.posted, p.edited, p.edit_reason, p.edited_by, g.g_id, g.g_user_title, g_image, g.g_promote_next_group, o.user_id AS is_online FROM '.$db->prefix.'posts AS p INNER JOIN '.$db->prefix.'users AS u ON u.id=p.poster_id INNER JOIN '.$db->prefix.'groups AS g ON g.g_id=u.group_id LEFT JOIN '.$db->prefix.'online AS o ON (o.user_id=u.id AND o.user_id!=1 AND o.idle=0) WHERE p.id IN ('.implode(',', $placeholders).') ORDER BY p.id', $post_ids);
foreach ($ps as $cur_post)
{
	$post_count++;
	$user_avatar = '';
	$user_info = array();
	$user_contacts = array();
	$post_actions = array();
	$is_online = '';
	$signature = '';

	// If the poster is a registered user
	if ($cur_post['poster_id'] > 1)
	{
		$username = colourize_group($cur_post['username'], $cur_post['g_id'], $cur_post['poster_id']);
		$user_title = get_title($cur_post);

		if ($panther_config['o_censoring'] == '1')
			$user_title = censor_words($user_title);

		// Format the online indicator
		$is_online = ($cur_post['is_online'] == $cur_post['poster_id']) ? '<strong>'.$lang_topic['Online'].'</strong>' : '<span>'.$lang_topic['Offline'].'</span>';

		if ($panther_config['o_avatars'] == '1' && $panther_user['show_avatars'] != '0')
			$user_avatar = generate_avatar_markup($cur_post['poster_id'], $cur_post['email'], $cur_post['use_gravatar']);

		// We only show location, register date, post count and the contact links if "Show user info" is enabled
		if ($panther_config['o_show_user_info'] == '1')
		{
			if ($cur_post['location'] != '')
			{
				if ($panther_config['o_censoring'] == '1')
					$cur_post['location'] = censor_words($cur_post['location']);

				$user_info[] = '<dd><span>'.$lang_topic['From'].' '.panther_htmlspecialchars($cur_post['location']).'</span></dd>';
			}

			$user_info[] = '<dd><span>'.$lang_topic['Registered'].' '.format_time($cur_post['registered'], true).'</span></dd>';

			if ($panther_config['o_show_post_count'] == '1' || $panther_user['is_admmod'])
				$user_info[] = '<dd><span>'.$lang_topic['Posts'].' '.forum_number_format($cur_post['num_posts']).'</span></dd>';

			// Now let's deal with the contact links (Email and URL)
			if ((($cur_post['email_setting'] == '0' && !$panther_user['is_guest']) || $panther_user['is_admmod']) && $panther_user['g_send_email'] == '1')
				$user_contacts[] = str_replace('{email_link}', '<a href="mailto:'.panther_htmlspecialchars($cur_post['email']).'">'.$lang_common['Email'].'</a>', $email_tpl);
			else if ($cur_post['email_setting'] == '1' && !$panther_user['is_guest'] && $panther_user['g_send_email'] == '1')
				$user_contacts[] = str_replace('{email_link}', '<a href="'.get_link($panther_url['email'], array($cur_post['poster_id'])).'">'.$lang_common['Email'].'</a>', $email_tpl);

			if ($cur_post['url'] != '')
			{
				if ($panther_config['o_censoring'] == '1')
					$cur_post['url'] = censor_words($cur_post['url']);

				$user_contacts[] = '<span class="website"><a href="'.panther_htmlspecialchars($cur_post['url']).'" rel="nofollow">'.$lang_topic['Website'].'</a></span>';
			}
		}

		if ($panther_user['is_admin'] || ($panther_user['g_moderator'] == '1' && $panther_user['g_mod_promote_users'] == '1'))
		{
			if ($cur_post['g_promote_next_group'])
				$user_info[] = '<dd><span><a href="'.get_link($panther_url['profile_promote'], array($cur_post['poster_id'], $cur_post['id'])).'">'.$lang_topic['Promote user'].'</a></span></dd>';
		}

		if ($panther_user['is_admmod'])
		{
			$user_info[] = '<dd><span><a href="'.get_link($panther_url['get_host'], array($cur_post['id'])).'" title="'.panther_htmlspecialchars($cur_post['poster_ip']).'">'.$lang_topic['IP address logged'].'</a></span></dd>';

			if ($cur_post['admin_note'] != '')
				$user_info[] = '<dd><span>'.$lang_topic['Note'].' <strong>'.panther_htmlspecialchars($cur_post['admin_note']).'</strong></span></dd>';
		}
		
		if ($panther_config['o_reputation'] == '1')
		{
			switch(true)
			{
				case $cur_post['poster_id'] == 1:
					$type = 'zero';
				break;
				case $cur_post['poster_reputation'] > '0':
					$type = 'positive';
				break;
				case $cur_post['poster_reputation'] < '0':
					$type = 'negative';
				break;
				default:
					$type = 'zero';
				break;
			}

			$cur_post['poster_reputation'] = '<span class="reputation '.$type.'">'.sprintf($lang_topic['reputation'], $cur_post['poster_reputation']).'</span><br /><br />';
			if ($cur_topic['use_reputation'] == '1')
			{
				switch(true)
				{
					case $cur_post['reputation'] > '0':
						$type = 'positive';
					break;
					case $cur_post['reputation'] < '0':
						$type = 'negative';
					break;
					default:
						$type = 'zero';
					break;
				}

				if ($cur_post['poster_id'] != 1)
				{
					if ($cur_post['poster_id'] != $panther_user['id'] && $panther_user['g_rep_enabled'] == '1' && $cur_topic['archived'] !== '1' && ($cur_topic['closed'] == '0' || $is_admmod))
					{
						$actions = array();
						if ($panther_config['o_rep_type'] != 3)
							$actions[] = '<img src="'.$panther_config['o_image_dir'].'plus.png" style="cursor:pointer;" onclick="reputation(1, '.$cur_post['id'].')" id="vote" width="16" height="16" />';

						if ($panther_config['o_rep_type'] != 2)
							$actions[] = '<img src="'.$panther_config['o_image_dir'].'minus.png" style="cursor:pointer;" onclick="reputation(-1,'.$cur_post['id'].')" id="vote" width="16" height="16" />';

						if (count($actions) > 0)
						{
							if ($cur_topic['first_post_id'] == $cur_post['id'])
								$post_actions[] = $lang_topic['topic helpful'].implode('&nbsp;&nbsp;', $actions);
							else
								$post_actions[] = $lang_topic['post helpful'].implode('&nbsp;&nbsp;', $actions);
						}
					}				
					$post_actions[] = '<span id="post_rep_'.$cur_post['id'].'" class="reputation '.$type.'">'.$cur_post['reputation'].'</span>';
				}
			}
		}
	}
	// If the poster is a guest (or a user that has been deleted)
	else
	{
		$username = colourize_group($cur_post['username'], $cur_post['g_id']);
		$user_title = get_title($cur_post);

		if ($panther_user['is_admmod'])
			$user_info[] = '<dd><span><a href="'.get_link($panther_url['get_host'], array($cur_post['id'])).'" title="'.panther_htmlspecialchars($cur_post['poster_ip']).'">'.$lang_topic['IP address logged'].'</a></span></dd>';

		if ($panther_config['o_show_user_info'] == '1' && $cur_post['poster_email'] != '' && !$panther_user['is_guest'] && $panther_user['g_send_email'] == '1')
			$user_contacts[] = '<span class="email"><a href="mailto:'.panther_htmlspecialchars($cur_post['poster_email']).'">'.$lang_common['Email'].'</a></span>';
	}
	
	if ($cur_post['g_image'] != '')
	{
		$image_dir = ($panther_config['o_image_group_dir'] != '') ? $panther_config['o_image_group_dir'] : panther_htmlspecialchars(get_base_url().'/'.$panther_config['o_image_group_path'].'/');
		$img_size = @getimagesize($panther_config['o_image_group_path'].'/'.$cur_post['g_id'].'.'.$cur_post['g_image']);
		$group_image = '<img src="'.$image_dir.$cur_post['g_id'].'.'.$cur_post['g_image'].'" '.$img_size[3].' alt="'.panther_htmlspecialchars($cur_post['g_user_title']).'" />';
	}
	else
		$group_image = '';

	// Generation post action array (quote, edit, delete etc.)
	if ($cur_topic['archived'] != '1')
	{
		if (!$is_admmod)
		{
			if (!$panther_user['is_guest'] && $cur_topic['archived'] == '0')
				$post_actions[] = '<li class="postreport"><span><a href="'.get_link($panther_url['report'], array($cur_post['id'])).'">'.$lang_topic['Report'].'</a></span></li>';

			if ($cur_topic['closed'] == '0' && $cur_topic['archived'] == '0')
			{
				if ($cur_post['poster_id'] == $panther_user['id'] && ($panther_user['g_deledit_interval'] == '0' || time() - $cur_post['posted'] < $panther_user['g_deledit_interval']))
				{
					if ((($start_from + $post_count) == 1 && $panther_user['g_delete_topics'] == '1') || (($start_from + $post_count) > 1 && $panther_user['g_delete_posts'] == '1'))
						$post_actions[] = '<li class="postdelete"><span><a href="'.get_link($panther_url['delete'], array($cur_post['id'])).'">'.$lang_topic['Delete'].'</a></span></li>';
					if ($panther_user['g_edit_posts'] == '1')
						$post_actions[] = '<li class="postedit"><span><a href="'.get_link($panther_url['edit'], array($cur_post['id'])).'">'.$lang_topic['Edit'].'</a></span></li>';
				}

				if (($cur_topic['post_replies'] == '' && $panther_user['g_post_replies'] == '1') || $cur_topic['post_replies'] == '1')
					$post_actions[] = '<li class="postquote"><span><a href="'.get_link($panther_url['quote'], array($id, $cur_post['id'])).'">'.$lang_topic['Quote'].'</a></span></li>';
			}
		}
		else
		{
			$post_actions[] = '<li class="postreport"><span><a href="'.get_link($panther_url['report'], array($cur_post['id'])).'">'.$lang_topic['Report'].'</a></span></li>';
			if ($panther_user['is_admin'] || $panther_user['g_mod_edit_admin_posts'] == '1' || !in_array($cur_post['poster_id'], $admin_ids))
			{
				if ($panther_config['o_warnings'] == '1' && (!in_array($cur_post['poster_id'], $admin_ids)) && $panther_user['id'] != $cur_post['poster_id'] && $cur_post['poster_id'] > 1 && ($panther_user['is_admin'] || $panther_user['g_mod_warn_users'] == '1'))
					$post_actions[] = '<li class="postdelete"><span><a href="'.get_link($panther_url['warn_pid'], array($cur_post['poster_id'], $cur_post['id'])).'">'.$lang_topic['Warn'].'</a></span></li>';

				$post_actions[] = '<li class="postdelete"><span><a href="'.get_link($panther_url['unapprove'], array($cur_topic['forum_id'], $cur_post['id'], $csrf_token)).'">'.$lang_topic['Unapprove'].'</a></span></li>'; 
				$post_actions[] = '<li class="postdelete"><span><a href="'.get_link($panther_url['delete'], array($cur_post['id'])).'">'.$lang_topic['Delete'].'</a></span></li>';
				$post_actions[] = '<li class="postedit"><span><a href="'.get_link($panther_url['edit'], array($cur_post['id'])).'">'.$lang_topic['Edit'].'</a></span></li>';
			}
			$post_actions[] = '<li class="postquote"><span><a href="'.get_link($panther_url['quote'], array($id, $cur_post['id'])).'">'.$lang_topic['Quote'].'</a></span></li>';
		}
	}

	// Perform the main parsing of the message (BBCode, smilies, censor words etc)
	$cur_post['message'] = parse_message($cur_post['message'], $cur_post['hide_smilies']);

	// Do signature parsing/caching
	if ($panther_config['o_signatures'] == '1' && $cur_post['signature'] != '' && $panther_user['show_sig'] != '0')
	{
		if (isset($signature_cache[$cur_post['poster_id']]))
			$signature = $signature_cache[$cur_post['poster_id']];
		else
		{
			$signature = parse_signature($cur_post['signature']);
			$signature_cache[$cur_post['poster_id']] = $signature;
		}
	}

	$attachments = '';
	if ($download && isset($results[$cur_post['id']]) && count($results[$cur_post['id']]) > 0)
	{
		$attachments = $lang_topic['Attachments'];
		foreach ($results[$cur_post['id']] as $cur_attach)
			$attachments .= '<br />'."\n\t\t\t\t\t\t".attach_icon(attach_get_extension($cur_attach['filename'])).' <a href="'.get_link($panther_url['attachment'], array($cur_attach['id'])).'">'.panther_htmlspecialchars($cur_attach['filename']).'</a>, '.sprintf($lang_topic['Attachment size'], file_size($cur_attach['size'])).', '.sprintf($lang_topic['Attachment downloads'], forum_number_format($cur_attach['downloads']));
	}
	
	$search = array(
		'{post_id}' => $cur_post['id'],
		'{post_type}' => ($post_count % 2 == 0) ? ' roweven' : ' rowodd'.(($cur_post['id'] == $cur_topic['first_post_id']) ? ' firstpost' : '').(($post_count == 1) ? ' blockpost1' : ''),
		'{post_no}' => ($start_from + $post_count),
		'{post_link}' => get_link($panther_url['post'], array($cur_post['id'])),
		'{post_posted}' => format_time($cur_post['posted']),
		'{username}' => $username,
		'{user_title}' => $user_title,
		'{user_avatar}' => (($panther_config['o_reputation'] == '1' && $cur_post['poster_id'] !=1) ? '<dd>'.$cur_post['poster_reputation'].'</dd>'."\n\t\t\t\t\t\t" : '').(($user_avatar != '') ? '<dd class="postavatar">'.$user_avatar.'</dd>' : ''),
		'{group_img}' => $group_image,
		'{user_info}' => (count($user_info) ? implode("\n\t\t\t\t\t\t", $user_info)."\n\t\t\t\t\t\t" : '').(count($user_contacts) ? '<dd class="usercontacts">'.implode(' ', $user_contacts).'</dd>' : ''),
		'{subject}' => (($cur_post['id'] != $cur_topic['first_post_id']) ? $lang_topic['Re'].' ' : '').panther_htmlspecialchars($cur_topic['subject']),
		'{message}' => $cur_post['message'],
		'{message_edited}' => (($cur_post['edited'] != '') ? "\n\t\t\t\t\t\t".'<p class="postedit"><em>'.$lang_topic['Last edit'].' '.panther_htmlspecialchars($cur_post['edited_by']).' ('.format_time($cur_post['edited']).')</em></p>' : '').(($cur_post['edit_reason'] != '') ? "\n\t\t\t\t\t\t".'<p class="postedit">'.sprintf($lang_topic['Edit reason'], panther_htmlspecialchars($cur_post['edit_reason'])).'</p>' : '').(($attachments != '') ? "\n\t\t\t\t\t".'<div class="postsignature"><hr />'.$attachments.'</div>' : ''),
		'{signature}' => (($signature != '') ? str_replace('{signature}', $signature, $signature_tpl) : ''),
		'{online_status}' => ($cur_post['poster_id'] > 1) ? $is_online : '',
		'{post_actions}' => (count($post_actions) ? str_replace('{post_actions}', implode("\n\t\t\t\t\t\t", $post_actions), $post_action_tpl) : ''),
	);

	$post_tpl[$cur_post['id']] = str_replace(array_keys($search), array_values($search), $post_content_tpl);
}

$content[] = implode("\n", $post_tpl);
if ($cur_topic['parent'])
{
	$parent_tpl = panther_template('parent_forum_breadcrumb.tpl');
	$search = array(
		'{forum_link}' => get_link($panther_url['forum'], array($cur_topic['parent_forum'], url_friendly($cur_topic['parent']))),
		'{forum_name}' => panther_htmlspecialchars($cur_topic['parent']),
	);
	
	$parent_tpl = "\n".str_replace(array_keys($search), array_values($search), $parent_tpl);
}
else
	$parent_tpl = '';

$topic_tpl = panther_template('topic.tpl');
$search = array(
	'{index_link}' => get_link($panther_url['index']),
	'{index}' => $lang_common['Index'],
	'{parent_forum}' => $parent_tpl,
	'{forum_link}' => get_link($panther_url['forum'], array($cur_topic['forum_id'], $url_forum)),
	'{forum_name}' => panther_htmlspecialchars($cur_topic['forum_name']),
	'{topic_link}' => get_link($panther_url['topic'], array($id, $url_subject)),
	'{topic}' => panther_htmlspecialchars($cur_topic['subject']),
	'{paging_links}' => $paging_links,
	'{post_link}' => $post_link,
	'{topic_content}' => count($content) ? implode("\n", $content) : '',
	'{subscribe_action}' => $subscraction,
);

echo str_replace(array_keys($search), array_values($search), $topic_tpl);
if ($panther_config['o_users_online'] == '1')
{
	require PANTHER_ROOT.'lang/'.$panther_user['language'].'/online.php';
	$guests_in_topic = $users = array();

	$online = $db->run('SELECT o.user_id, o.ident, o.currently, o.logged, u.group_id FROM '.$db->prefix.'online AS o INNER JOIN '.$db->prefix.'users AS u ON u.id=o.user_id WHERE o.currently LIKE \'%viewtopic.php%\' AND o.idle = 0');
	foreach ($online as $user_online)
	{
		if (strpos($user_online['currently'], '&p=')!== false)
		{
			preg_match('~&p=(.*)~', $user_online['currently'], $replace);
			$user_online['currently'] = str_replace($replace[0], '', $user_online['currently']);
		}
		$tid = filter_var($user_online['currently'], FILTER_SANITIZE_NUMBER_INT);
		if (strpos($user_online['currently'], '?pid') !== false)
		{
			if (in_array($tid, $post_ids))
			{
				if ($user_online['user_id'] == 1)
					$guests_in_topic[] = $user_online['ident'];
				else
					$users[] = colourize_group($user_online['ident'], $user_online['group_id'], $user_online['user_id']);
			}
		}
		elseif (strpos($user_online['currently'], '?id') !== false)
		{
			if ($tid == $id)
			{
				if ($user_online['user_id'] == 1)
					$guests_in_topic[] = $user_online['ident'];
				else
					$users[] = colourize_group($user_online['ident'], $user_online['group_id'], $user_online['user_id']);
			}
		}
			 
	}

	$users = (count($users)) ? implode(', ', $users) : $lang_online['no users'];
	echo str_replace('{users_online}', sprintf($lang_online['online topic'], count($guests_in_topic), $users), panther_template('online_forum.tpl'));
}

// Display quick post if enabled
if ($quickpost)
{
	$cur_index = 1;
	$post_tpl = panther_template('quickpost.tpl');

	if ($panther_user['is_guest'])
	{
		$email_label = ($panther_config['p_force_guest_email'] == '1') ? '<strong>'.$lang_common['Email'].' <span>'.$lang_common['Required'].'</span></strong>' : $lang_common['Email'];
		$email_form_name = ($panther_config['p_force_guest_email'] == '1') ? 'req_email' : 'email';

		$email_input = panther_template('post_guest_field.tpl');
		$search = array(
			'{guest_name}' => $lang_post['Guest name'],
			'{username_value}' => (isset($_POST['req_username'])) ? panther_htmlspecialchars($username) : '',
			'{index_1}' => $cur_index++,
			'{type}' => ($panther_config['p_force_guest_email'] == '1') ? ' required' : '',
			'{email_label}' => $email_label,
			'{email_form_name}' => $email_form_name,
			'{email_value}' => (isset($_POST[$email_form_name])) ? panther_htmlspecialchars($email) : '',
			'{index_2}' => $cur_index++,
			'{required}' => $lang_common['Required'],
		);

		$email_input = str_replace(array_keys($search), array_values($search), $email_input);
	}

	$search = array(
		'{quick_post}' => $lang_topic['Quick post'],
		'{form_action}' => get_link($panther_url['new_reply'], array($id)),
		'{write_message_legend}' => $lang_common['Write message legend'],
		'{csrf_token}' => generate_csrf_token('post.php'),
		'{subscribe}' => ($panther_config['o_topic_subscriptions'] == '1' && ($panther_user['auto_notify'] == '1' || $cur_topic['is_subscribed'])) ? "\n\t\t\t\t\t\t".'<input type="hidden" name="subscribe" value="1" />' : '',
		'{bbcode_help}' => get_link($panther_url['help'], array('bbcode')),
		'{bbcode}' => $lang_common['BBCode'],
		'{bbcode_onoff}' => ($panther_config['p_message_bbcode'] == '1') ? $lang_common['on'] : $lang_common['off'],
		'{url_help}' => get_link($panther_url['help'], array('url')),
		'{url}' => $lang_common['url tag'],
		'{url_onoff}' => ($panther_config['p_message_bbcode'] == '1' && $panther_user['g_post_links'] == '1') ? $lang_common['on'] : $lang_common['off'],
		'{img_help}' => get_link($panther_url['help'], array('img')),
		'{img}' => $lang_common['img tag'],
		'{img_onoff}' => ($panther_config['p_message_bbcode'] == '1' && $panther_config['p_message_img_tag'] == '1') ? $lang_common['on'] : $lang_common['off'],
		'{smilies_help}' => get_link($panther_url['help'], array('smilies')),
		'{smilies}' => $lang_common['Smilies'],
		'{smilies_onoff}' => ($panther_config['o_smilies'] == '1') ? $lang_common['on'] : $lang_common['off'],
		'{label}' => ($panther_user['is_guest']) ? $email_input."\n".'<label class="required"><strong>'.$lang_common['Message'].' <span>'.$lang_common['Required'].'</span></strong><br />' : '<label>',
		'{quickpost_hook}' => flux_hook('quickpost_before_submit'),
		'{submit}' => $lang_common['Submit'],
		'{preview}' => $lang_topic['Preview'],
		'{index1}' => $cur_index++,
		'{index2}' => $cur_index++,
		'{index3}' => $cur_index++
	);

	echo str_replace(array_keys($search), array_values($search), $post_tpl);
}

// Increment "num_views" for topic
if ($panther_config['o_topic_views'] == '1')
	$db->run('UPDATE '.$db->prefix.'topics SET num_views=num_views+1 WHERE id=:id', array($id));

$forum_id = $cur_topic['forum_id'];
$footer_style = 'viewtopic';
require PANTHER_ROOT.'footer.php';