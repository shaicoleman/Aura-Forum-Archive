<?php
/**
 * Copyright (C) 2015 Panther (https://www.pantherforum.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/');
	require PANTHER_ROOT.'include/common.php';
}

if ($panther_config['o_warnings'] == '0')
	message($lang_warnings['Warning system disabled']);

// Load the warnings.php/post.php language files
require PANTHER_ROOT.'lang/'.$panther_user['language'].'/warnings.php';
require PANTHER_ROOT.'lang/'.$panther_user['language'].'/post.php';

$action = isset($_GET['action']) ? panther_trim($_GET['action']) : '';

$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), panther_htmlspecialchars($lang_warnings['Warning system']));
define('PANTHER_ACTIVE_PAGE', 'index');
require PANTHER_ROOT.'header.php';

$cur_index = 1;
if (isset($_POST['form_sent']))
{
	// Make sure we have a valid token
	confirm_referrer('warnings.php');

	// Are we allowed to issue warnings?
	if ($panther_user['g_mod_warn_users'] == '0' && !$panther_user['is_admin'])
		message($lang_common['No permission']);

	$user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;
	$data = array(
		':id'	=>	$user_id,
	);
	
	if ($user_id == $panther_user['id'] || $user_id < 2 || (in_array($user_id, get_admin_ids())))
		message($lang_common['Bad request']);

	$ps = $db->select('users', 'username, pm_notify, email', $data, 'id=:id');
	if (!$ps->rowCount())
		message($lang_common['Bad request']);

	list($username, $pm_notify, $email) = $ps->fetch(PDO::FETCH_NUM);

	// Check post ID
	$post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;
	if ($post_id < 0)
			message($lang_common['Bad request']);
	else if ($post_id > 0)
	{
		$data = array(
			':uid'	=>	$user_id,
			':id'	=>	$post_id,
		);

		$ps = $db->select('posts', 'poster_id, message', $data, 'id=:id AND poster_id=:uid AND approved=1 AND deleted=0');
		if (!$ps->rowCount())
			message($lang_common['Bad request']);

		list($poster_id, $message) = $ps->fetch(PDO::FETCH_NUM);
	}
	else
	{
		$post_id = 0;
		$message = '';
	}

	// Check whether user has been warned already for this post (users can only receive one warning per post)
	if ($post_id)
	{
		$data = array(
			':id'	=>	$post_id,
		);

		$ps = $db->select('warnings', 'id', $data, 'post_id=:id');
		if ($ps->rowCount())
		{
			$warning_id = $ps->fetchColumn();
			$link = get_link($panther_url['warning_details'], array($warning_id));
			$link = '<a href="'.$link.'">'.$link.'</a>';
			
			message(sprintf($lang_warnings['Already warned'], $link));
		}
	}

	// Check warning type
	$warning_type = isset($_POST['warning_type']) ? intval($_POST['warning_type']) : -1;
	if ($warning_type < 0)
		message($lang_warnings['No warning type']);
	
	$now = time();

	// Make sure this warning type exists (and grab some data while we're at it)
	if ($warning_type != '0')
	{
		$data = array(
			':id'	=>	$warning_type,
		);

		$ps = $db->select('warning_types', 'title, points, expiration_time', $data, 'id=:id');
		if (!$ps->rowCount())
			message($lang_common['Bad request']);

		list ($warning_title, $warning_points, $expiration_time) = $ps->fetch(PDO::FETCH_NUM);
	}
	else // It's a custom warning
	{
		if ($panther_config['o_custom_warnings'] == '0')
			message($lang_warnings['Custom warnings disabled']);

		$warning_title = isset($_POST['custom_title']) ? panther_trim($_POST['custom_title']) : '';
		if ($warning_title == '')
			$errors[] = $lang_warnings['No warning reason'];
		else if (panther_strlen($custom_title) > 120)
			$errors[] = $lang_warnings['Too long warning reason'];

		$warning_points = isset($_POST['custom_points']) ? intval($_POST['custom_points']) : 0;
		if ($warning_points < 0)
			$errors[] = $lang_warnings['No points'];

		$expiration_time = isset($_POST['custom_expiration_time']) ? intval($_POST['custom_expiration_time']) : 0;
		$expiration_unit = isset($_POST['custom_expiration_unit']) ? panther_trim($_POST['custom_expiration_unit']) : '';

		if ($expiration_time < 1 && $expiration_unit != 'never')
			$errors[] = $lang_warnings['No expiration time'];

		$expiration_time = get_expiration_time($expiration_time, $expiration_unit);
	}

	$admin_note = panther_linebreaks(panther_trim($_POST['note_admin']));
	if (strlen($admin_note) > 65535)
		$errors[] = $lang_warnings['Too long admin note'];

	// If private messaging system is enabled (and if so, then send a PM to them)
	if ($panther_config['o_private_messaging'] == '1')
	{
		$link = get_link($panther_url['warning_view'], array($user_id));
		$link = '[url]'.$link.'[/url]';

		// Check message subject
		$pm_subject = isset($_POST['req_subject']) ? panther_trim($_POST['req_subject']) : '';
		
		if ($panther_config['o_censoring'] == '1')
			$censored_subject = panther_trim(censor_words($pm_subject));

		if ($pm_subject == '')
			$errors[] = $lang_warnings['No subject'];
		else if ($panther_config['o_censoring'] == '1' && $censored_subject == '')
			$errors[] = $lang_post['No subject after censoring'];
		else if (panther_strlen($pm_subject) > 70)
			$errors[] = $lang_post['Too long subject'];
		
		$pm_message = panther_linebreaks(panther_trim($_POST['req_message']));
		
		if ($pm_message == '')
			$errors[] = $lang_post['No message'];
		else if (strlen($pm_message) > PANTHER_MAX_POSTSIZE)
			$errors[] = sprintf($lang_post['Too long message'], forum_number_format(PANTHER_MAX_POSTSIZE));
		
		if ($panther_config['p_message_bbcode'] == '1')
		{
			require PANTHER_ROOT.'include/parser.php';
			$pm_message = preparse_bbcode($pm_message, $errors);
		}

		if (empty($errors))
		{
			if ($pm_message == '')
				$errors[] = $lang_post['No message'];
			else if ($panther_config['o_censoring'] == '1')
			{
				// Censor message to see if that causes problems
				$censored_message = panther_trim(censor_words($pm_message));

				if ($censored_message == '')
					$errors[] = $lang_post['No message after censoring'];
			}
		}

		$pm_subject = str_replace('<warning_type>', $warning_title, $pm_subject);
		$pm_subject = str_replace('<warnings_url>', $link, $pm_subject);
		$pm_message = str_replace('<warning_type>', $warning_title, $pm_message);
		$pm_message = str_replace('<warnings_url>', $link, $pm_message);

		// Check note_pm
		$note_pm = 'Subject: '.$pm_subject."\n\n".'Message:'."\n\n".$pm_message;
	}
	else
		$note_pm = '';

	// If there are errors, we display them
	if (!empty($errors))
	{
		$form_errors = array();
		foreach ($errors as $cur_error)
			$form_errors[] = "\t\t\t\t".'<li><strong>'.$cur_error.'</strong></li>'."\n";

		$error_tpl = panther_template('inline_errors.tpl');
		$search = array(
			'{errors}' => $lang_post['Post errors'],
			'{errors_info}' => $lang_warnings['Post errors info'],
			'{error_list}' => implode("\n", $form_errors),
		);

		echo str_replace(array_keys($search), array_values($search), $error_tpl);
	}
	else
	{
		$expiration_time = ($expiration_time != '0') ? ($now + $expiration_time) : 0;
		$insert = array(
			'user_id'	=>	$user_id,
			'type_id'	=>	$warning_type,
			'post_id'	=>	$post_id,
			'title'		=>	($warning_type == 0) ? $warning_title : '', // Check if this is a custom warning
			'points'	=>	$warning_points,
			'date_issued'	=>	$now,
			'date_expire'	=>	$expiration_time,
			'issued_by'	=>	$panther_user['id'],
			'note_admin'	=>	$admin_note,
			'note_post'	=>	$message,
			'note_pm'	=>	$note_pm,
		);
		
		$db->insert('warnings', $insert);

		// If private messaging system is enabled
		if ($panther_config['o_private_messaging'] == '1')
		{
			$insert = array(
				'subject'	=>	$pm_subject,
				'poster'	=>	$panther_user['username'],
				'poster_id'	=>	$panther_user['id'],
				'num_replies'	=>	0,
				'last_post'	=>	$now,
				'last_poster'	=>	$panther_user['username'],
			);

			$db->insert('conversations', $insert);
			$new_tid = $db->lastInsertId($db->prefix.'conversations');

			$insert = array(
				'poster'	=>	$panther_user['username'],
				'poster_id'	=>	$panther_user['id'],
				'poster_ip'	=>	get_remote_address(),
				'message'	=>	$pm_message,
				'hide_smilies'	=>	0,
				'posted'	=>	$now,
				'topic_id'	=>	$new_tid,
			);

			$db->insert('messages', $insert);
			$new_pid = $db->lastInsertId($db->prefix.'messages');
			
			$update = array(
				'first_post_id'	=>	$new_pid,
				'last_post_id'	=>	$new_pid,
			);
			
			$data = array(
				':tid'	=>	$new_tid,
			);
			
			$db->update('conversations', $update, 'id=:tid', $data);
			
			$insert = array(
				'topic_id'	=>	$new_tid,
				'user_id'	=>	$user_id,
			);

			$db->insert('pms_data', $insert);
			
			$insert = array(
				'topic_id'	=>	$new_tid,
				'user_id'	=>	$panther_user['id'],
				'viewed'	=>	1,
				'deleted'	=>	1,
			);

			$db->insert('pms_data', $insert);

			$data = array(
				':id'	=>	$user_id,
			);

			$db->run('UPDATE '.$db->prefix.'users SET num_pms=num_pms+1 WHERE id=:id', $data);

			if ($pm_notify == '1')
			{
				$mail_subject = trim(substr($mail_tpl, 8, $first_crlf-8));
				$mail_message = trim(substr($mail_tpl, $first_crlf));

				$mail_message = str_replace('<username>', panther_htmlspecialchars($username), $mail_message);
				$mail_message = str_replace('<sender>', panther_htmlspecialchars($panther_user['username']), $mail_message);
				$mail_message = str_replace('<message>', $pm_message, $mail_message);
				$mail_message = str_replace('<pm_title>', panther_htmlspecialchars($subject), $mail_message);
				$mail_message = str_replace('<message_url>', get_link($panther_url['pms_topic'], array($new_pid)), $mail_message);
				$mail_message = str_replace('<board_mailer>', panther_htmlspecialchars($panther_config['o_board_title']), $mail_message);

				panther_mail($email, $mail_subject, $mail_message);
			}
			
			$update = array(
				'last_post'	=>	$now,
			);

			$data = array(
				':id'	=>	$panther_user['id'],
			);

			$db->update('users', $update, 'id=:id', $data);

			// Check whether user should be banned according to warning levels
			if ($warning_points > 0)
			{
				$data = array(
					':uid'	=>	$user_id,
					':now'	=>	$now,
				);

				$ps = $db->select('warnings', 'SUM(points)', $data, 'user_id=:uid AND (date_expire>:now OR date_expire=0)');
				$points_active = $ps->fetchColumn();
				
				$data = array(
					':active'	=>	$points_active,
				);
				
				$ps = $db->select('warning_levels', 'message, period', $data, 'points<=:active', 'points DESC LIMIT 1');
				if ($ps->rowCount())
				{
					list($ban_message, $ban_period) = $ps->fetch(PDO::FETCH_NUM);
					$data = array(
						':username'	=>	$username,
					);

					$ps = $db->select('bans', 'expire', $data, 'username=:username', 'expire IS NULL DESC, expire DESC LIMIT 1');
					if ($ps->rowCount())
					{
						$ban_expire = $ps->fetchColumn();
						
						// Only delete user's current bans if new ban is greater than curent ban and current ban is not a permanent ban
						if ((($now + $ban_period) > $ban_expire || $ban_period == '0') && $ban_expire != null)
						{
							$ps = $db->delete('bans', 'username=:username', $data);
							$insert = array(
								'username'	=>	$username,
								'message'	=>	$ban_message,
							);

							if ($ban_period != 0)
								$insert['expire'] = $now + $ban_period;
								
							$db->insert('bans', $insert);
							
						}
					}
					else
					{
						$insert = array(
							'username'	=>	$username,
							'message'	=>	$ban_message,
							'ban_creator'	=>	$panther_user['id'],
						);
						
						if ($ban_period != 0)
							$insert['expire'] = $now + $ban_period;
						
						$db->insert('bans', $insert);
					}
					
					// Regenerate the bans cache
					if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
						require PANTHER_ROOT.'include/cache.php';
					
					generate_bans_cache();
				}
			}

			$redirect_link = ($post_id) ? get_link($panther_url['post'], array($post_id)) : get_link($panther_url['profile'], array($user_id, url_friendly($username)));
			redirect($redirect_link, $lang_warnings['Warning added redirect']);
		}
	}
}
else if (isset($_GET['warn']))
{
	// Are we allowed to issue warnings?
	if ($panther_user['g_mod_warn_users'] == '0' && !$panther_user['is_admin'])
		message($lang_common['No permission']);

	$user_id = isset($_GET['warn']) ? intval($_GET['warn']) : 0;
	if ($user_id < 1)
		message($lang_common['Bad request']);

	$post_id = isset($_GET['pid']) ? intval($_GET['pid']) : 0;
	if ($post_id < 0)
		message($lang_common['Bad request']);
	
	if ($user_id == $panther_user['id'] || $user_id < 2 || (in_array($user_id, get_admin_ids())))
		message($lang_common['Bad request']);

	// Check whether user has been warned already for this post (users can only receive one warning per post)
	if ($post_id)
	{
		$data = array(
			':id'	=>	$post_id,
		);

		$ps = $db->select('warnings', 'id', $data, 'post_id=:id');
		if ($ps->rowCount())
		{
			$warning_id = $ps->fetchColumn();
			$warning_link = get_link($panther_url['warning_details'], array($warning_id));
			$warning_link = '<a href="'.$warning_link.'">'.$warning_link.'</a>';
			
			message(sprintf($lang_warnings['Already warned'], $warning_link));
		}
	}
	
	$data = array(
		':id'	=>	$user_id,
	);

	$ps = $db->select('users', 'username, group_id', $data, 'id=:id');
	$cur_user = $ps->fetch();
	
	$now = time();
	$data = array(
		':id'	=>	$user_id,
		':time'	=>	$now
	);
	
	$ps = $db->select('warnings', 'COUNT(id)', $data, 'user_id=:id AND (date_expire>:time OR date_expire=0)');
	$num_active = $ps->fetchColumn();
	
	$data = array(
		':id'	=>	$user_id,
		':time'	=>	$now,
	);
	
	$ps = $db->select('warnings', 'COUNT(id)', $data, 'user_id=:id AND date_expire<=:time AND date_expire!=0');
	$num_expired = $ps->fetchColumn();
	
	$ps = $db->select('warnings', 'SUM(points)', $data, 'user_id=:id AND (date_expire>:time OR date_expire=0)');
	$points_active = $ps->fetchColumn();
	
	$ps = $db->select('warnings', 'SUM(points)', $data, 'user_id=:id AND date_expire<=:time AND date_expire!=0');
	$points_expired = $ps->fetchColumn();
	
	if ($panther_config['o_private_messaging'] == '1')
	{
		$pm_tpl = trim(file_get_contents(PANTHER_ROOT.'lang/'.$panther_user['language'].'/mail_templates/warning_pm.tpl'));

		// Load the "warning pm" template
		$first_crlf = strpos($pm_tpl, "\n");
		$pm_subject = trim(substr($pm_tpl, 8, $first_crlf-8));
		$pm_message = trim(substr($pm_tpl, $first_crlf));
		$pm_message = str_replace('<username>', '[user]'.panther_htmlspecialchars($cur_user['username']).'[/user]', $pm_message);
		$pm_message = str_replace('<board_title>', panther_htmlspecialchars($panther_config['o_board_title']), $pm_message);
	}
	
	$ps = $db->select('warning_types', 'id, title, points, expiration_time', array(), '', 'points');
	$warning_count = 1;
	
	$types = array();
	if ($ps->rowCount())
	{
		foreach ($ps as $cur_warning)
			$types[] = '<input id="wt'.$warning_count++.'" type="radio" name="warning_type" value="'.$cur_warning['id'].'" tabindex="'.$cur_index++.'" /> '.panther_htmlspecialchars($cur_warning['title']).' ('.sprintf($lang_warnings['No of points'], $cur_warning['points']).' / '.sprintf($lang_warnings['Expires after period'], format_expiration_time($cur_warning['expiration_time'])).')<br />';
	}
	else
		$types[] = $lang_warnings['No warning types'].'<br />';
	
	if ($panther_config['o_custom_warnings'] == '1')
	{
		$custom_tpl = panther_template('custom_warnings.tpl');
		$search = array(
			'{custom_warning_type}' => $lang_warnings['Custom warning type'],
			'{index_1}' => $cur_index++,
			'{index_2}' => $cur_index++,
			'{custom_points}' => sprintf($lang_warnings['No of points'], '<input type="text" name="custom_points" size="3" maxlength="3" tabindex="'.$cur_index++.'" />'),
			'{expires}' => sprintf($lang_warnings['Expires after period'], '<input type="text" name="custom_expiration_time" size="3" maxlength="3" value="10" tabindex="'.$cur_index++.'" />'),
			'{hours}' => $lang_warnings['Hours'],
			'{days}' => $lang_warnings['Days'],
			'{months}' => $lang_warnings['Months'],
			'{never}' => $lang_warnings['Never'],
		);

		$custom_tpl = str_replace(array_keys($search), array_values($search), $custom_tpl);
	}
	else
		$custom_tpl = '';
	
	if ($panther_config['o_private_messaging'] == '1')
	{
		$pm_tpl = panther_template('pm_warning.tpl');
		$search = array(
			'{enter_private_message}' => $lang_warnings['Enter private message'],
			'{subject}' => $lang_warnings['Subject'],
			'{message}' => $lang_warnings['Message'],
			'{subject_value}' => $pm_subject,
			'{message_value}' => $pm_message,
			'{index_1}' => $cur_index++,
			'{index_2}' => $cur_index++,
		);

		$pm_tpl = str_replace(array_keys($search), array_values($search), $pm_tpl);
	}
	
	$warn_tpl = panther_template('issue_warning.tpl');
	$search = array(
		'{issue_warning}' => $lang_warnings['Issue warning'],
		'{form_action}' => get_link($panther_url['warnings']),
		'{user_details}' => $lang_warnings['User details'],
		'{username}' => sprintf($lang_warnings['Username'], colourize_group($cur_user['username'], $cur_user['group_id'], $user_id)),
		'{active_warnings}' => sprintf($lang_warnings['Active warnings 2'], $num_active, $points_active),
		'{expired_warnings}' => sprintf($lang_warnings['Expired warnings 2'], $num_expired, $points_expired),
		'{enter_warning_details_legend}' => $lang_warnings['Enter warning details'],
		'{csrf_token}' => generate_csrf_token(),
		'{user_id}' => $user_id,
		'{post_id}' => $post_id,
		'{warning_type}' => $lang_warnings['Warning type'],
		'{admin_note}' => $lang_warnings['Admin note'],
		'{index_1}' => $cur_index++,
		'{private_messaging}' => $pm_tpl,
		'{submit}' => $lang_common['Submit'],
		'{index_2}' => $cur_index++,
		'{go_back}' => $lang_common['Go back'],
		'{warning_types}' => implode("\n", $types),
		'{custom_warnings}' => $custom_tpl,
		'{private_messaging}' => $pm_tpl,
	);

	echo str_replace(array_keys($search), array_values($search), $warn_tpl);
}
else if (isset($_GET['view']))
{
	$user_id = isset($_GET['view']) ? intval($_GET['view']) : 0;
	if ($user_id < 1)
		message($lang_common['Bad request']);

	// Normal users can only view their own warnings - and only if they have permission
	if ($panther_user['g_id'] == PANTHER_GUEST || (!$panther_user['is_admmod'] && $panther_user['id'] != $user_id) || (!$panther_user['is_admmod'] && $panther_config['o_warning_status'] == '2'))
		message($lang_common['No permission']);

	$now = time();
	$data = array(
		':id'	=>	$user_id,
	);

	$ps = $db->select('users', 'username', $data, 'id=:id');
	$username = $ps->fetchColumn();

	$url_username = url_friendly($username);
	$data = array(
		':id' => $user_id,
		':time' => $now,
	);

	$ps = $db->select('warnings', 'COUNT(id)', $data, 'user_id=:id AND (date_expire>:time OR date_expire=0)');
	$num_active = $ps->fetchColumn();

	$ps = $db->select('warnings', 'COUNT(id)', $data, 'user_id=:id AND date_expire<=:time OR date_expire!=0');
	$num_expired = $ps->fetchColumn();

	$ps = $db->select('warnings', 'SUM(points)', $data, 'user_id=:id AND (date_expire>:time OR date_expire=0)');
	$points_active = $ps->fetchColumn();

	$ps = $db->select('warnings', 'SUM(points)', $data, 'user_id=:id AND date_expire<=:time AND date_expire!=0');
	$points_expired = $ps->fetchColumn();

	$ps = $db->run('SELECT w.id, w.type_id, w.post_id, w.title AS custom_title, w.points, w.date_issued, w.date_expire, w.issued_by, t.title, u.username AS issued_by_username, u.group_id AS issuer_gid FROM '.$db->prefix.'warnings as w LEFT JOIN '.$db->prefix.'warning_types AS t ON t.id=w.type_id LEFT JOIN '.$db->prefix.'users AS u ON u.id = w.issued_by WHERE w.user_id=:id AND (w.date_expire>:time OR w.date_expire=0) ORDER BY w.date_issued DESC', $data);
	$ps1 = $db->run('SELECT w.id, w.type_id, w.post_id, w.title AS custom_title, w.points, w.date_issued, w.date_expire, w.issued_by, t.title, u.username AS issued_by_username, u.group_id AS issuer_gid FROM '.$db->prefix.'warnings as w LEFT JOIN '.$db->prefix.'warning_types AS t ON t.id=w.type_id LEFT JOIN '.$db->prefix.'users AS u ON u.id=w.issued_by WHERE w.user_id=:id AND w.date_expire<=:time AND w.date_expire!=0 ORDER BY w.date_issued DESC', $data);

	$warnings = array();
	$warning_row_tpl = panther_template('warning_view_row.tpl');
	$warn_row_tpl = panther_template('warning_row.tpl');
	if ($ps->rowCount())
	{
		foreach ($ps as $active_warnings)
		{
			if ($active_warnings['custom_title'] != '')
				$warning_title = sprintf($lang_warnings['Custom warning'], panther_htmlspecialchars($active_warnings['custom_title']));
			else if ($active_warnings['title'] != '')
				$warning_title = panther_htmlspecialchars($active_warnings['title']);
			else
				$warning_title = ''; // This warning type has been deleted

			$search = array(
				'{warning_title}' => $warning_title,
				'{date_issued}' => format_time($active_warnings['date_issued']),
				'{points}' => $active_warnings['points'],
				'{date_expire}' => ($active_warnings['date_expire'] == '0') ? $lang_warnings['Never'] : format_time($active_warnings['date_expire']),
				'{issuer_username}' => ($active_warnings['issued_by_username'] != '') ? colourize_group($active_warnings['issued_by_username'], $active_warnings['issuer_gid'], $active_warnings['issued_by']) : '',
				'{warning_detail}' => get_link($panther_url['warning_details'], array($active_warnings['id'])),
				'{details}' => $lang_warnings['Details'],
			);

			$warnings[] = str_replace(array_keys($search), array_values($search), $warn_row_tpl);
		}

		$search = array(
			'{warnings}' => sprintf($lang_warnings['No of warnings'], $num_active),
			'{points}' => $points_active,
		);

		$warnings[] = str_replace(array_keys($search), array_values($search), $warning_row_tpl); 
	}
	else
	{
		$warn_tpl = panther_template('no_warnings.tpl');
		$search = array(
			'{active}' => $lang_warnings['No active warnings'],
		);

		$warnings[] = str_replace(array_keys($search), array_values($search), $warn_tpl); 
	}

	$warning_content_tpl = implode("\n", $warnings);
	$warnings = array();
	if ($ps1->rowCount())
	{
		foreach ($ps1 as $expired_warnings)
		{
			// Determine warning type
			if ($expired_warnings['custom_title'] != '')
				$warning_title = sprintf($lang_warnings['Custom warning'], panther_htmlspecialchars($expired_warnings['custom_title']));
			else if ($warnings_expired['title'] != '')
				$warning_title = panther_htmlspecialchars($expired_warnings['title']);
			else
				$warning_title = ''; // This warning type has been deleted
			
			$search = array(
				'{warning_title}' => $warning_title,
				'{date_issued}' => format_time($expired_warnings['date_issued']),
				'{points}' => $expired_warnings['points'],
				'{date_expire}' => format_time($expired_warnings['date_expire']),
				'{issuer_username}' => ($expired_warnings['issued_by_username'] != '') ? colourize_group($expired_warnings['issued_by_username'], $expired_warnings['issuer_gid'], $expired_warnings['issued_by']) : '',
				'{warning_detail}' => get_link($panther_url['warning_details'], array($expired_warnings['id'])),
				'{details}' => $lang_warnings['Details'],
			);

			$warnings[] = str_replace(array_keys($search), array_values($search), $warn_row_tpl);
		}

		$search = array(
			'{warnings}' => sprintf($lang_warnings['No of warnings'], $num_expired),
			'{points}' => $points_expired,
		);

		$warnings[] = str_replace(array_keys($search), array_values($search), $warning_row_tpl); 
	}
	else
	{
		$warn_tpl = panther_template('no_warnings.tpl');
		$search = array(
			'{active}' => $lang_warnings['No expired warnings'],
		);

		$warnings[] = str_replace(array_keys($search), array_values($search), $warn_tpl); 
	}

	$expired_content_tpl = implode("\n", $warnings);
	$warn_tpl = panther_template('view_warning.tpl');
	$search = array(
		'{profile_link}' => get_link($panther_url['profile'], array($user_id, $url_username)),
		'{username}' => panther_htmlspecialchars($username),
		'{warning_link}' => get_link($panther_url['warning_view'], array($user_id)),
		'{warning}' => $lang_warnings['Warnings'],
		'{active_warnings}' => sprintf($lang_warnings['Active warnings'], panther_htmlspecialchars($username)),
		'{warning}' => $lang_warnings['Warning 2'],
		'{date_issued}' => $lang_warnings['Date issued 2'],
		'{points}' => $lang_warnings['Points'],
		'{expires}' => $lang_warnings['Expires'],
		'{expired}' => $lang_warnings['Expired'],
		'{issued}' => $lang_warnings['Issued by 2'],
		'{details}' => $lang_warnings['Details'],
		'{active_warnings_content}' => $warning_content_tpl,
		'{expired_warnings}' => sprintf($lang_warnings['Expired warnings'], panther_htmlspecialchars($username)),
		'{expired_warnings_content}' => $expired_content_tpl,
	);

	echo str_replace(array_keys($search), array_values($search), $warn_tpl);
}
else if (isset($_GET['details']))
{
	$warning_id = isset($_GET['details']) ? intval($_GET['details']) : 0;
	if ($warning_id < 1)
		message($lang_common['Bad request']);

	$data = array(
		':id' => $warning_id,
	);

	$ps = $db->run('SELECT w.id, w.user_id, w.type_id, w.post_id, w.title AS custom_title, w.points, w.date_issued, w.date_expire, w.issued_by, w.note_admin, w.note_post, w.note_pm, t.title, u.username AS issued_by_username, u.group_id AS issuer_gid FROM '.$db->prefix.'warnings as w LEFT JOIN '.$db->prefix.'warning_types AS t ON t.id=w.type_id LEFT JOIN '.$db->prefix.'users AS u ON u.id=w.issued_by WHERE w.id=:id', $data);
	if (!$ps->rowCount())
		message($lang_common['Bad request']);

	$warning_details = $ps->fetch();

	// Normal users can only view their own warnings if they have permission
	if ($panther_user['g_id'] == PANTHER_GUEST || (!$panther_user['is_admmod'] && $panther_user['id'] != $warning_details['user_id']) || (!$panther_user['is_admmod'] && $panther_config['o_warning_status'] == '2'))
		message($lang_common['No permission']);

	if ($warning_details['custom_title'] != '')
		$warning_title = sprintf($lang_warnings['Custom warning'], panther_htmlspecialchars($warning_details['custom_title'])).' ('.sprintf($lang_warnings['No of points'], $warning_details['points']).')';
	else if ($warning_details['title'] != '')
		$warning_title = panther_htmlspecialchars($warning_details['title']).' ('.sprintf($lang_warnings['No of points'], $warning_details['points']).')';
	else
		$warning_title = ''; // This warning type has been deleted

	$data = array(
		':id'	=>	$warning_details['user_id']
	);

	$ps = $db->select('users', 'username, group_id', $data, 'id=:id');
	list($username, $group_id) = $ps->fetch(PDO::FETCH_NUM);

	if ($warning_details['date_expire'] == '0')
		$warning_expires = $lang_warnings['Expires'].': '.$lang_warnings['Never'];
	else if ($warning_details['date_expire'] > time())
		$warning_expires = $lang_warnings['Expires'].': '.format_time($warning_details['date_expire']);
	else
		$warning_expires = $lang_warnings['Expired'].': '.format_time($warning_details['date_expire']);

	require PANTHER_ROOT.'include/parser.php';
	$note_admin = parse_message($warning_details['note_admin'], 0);
	$note_pm = parse_message($warning_details['note_pm'], 0);
	$message = parse_message($warning_details['note_post'], 0);

	if ($panther_user['is_admmod'])
	{
		$admin_tpl = panther_template('warning_admin_note.tpl');
		$search = array(
			'{admin_note}' => $lang_warnings['Admin note'],
			'{note_message}' => ($note_admin  == '') ? $lang_warnings['No admin note'] : $note_admin,
		);

		$admin_tpl = str_replace(array_keys($search), array_values($search), $admin_tpl);
	}
	else
		$admin_tpl = '';

	// If private messaging system is enabled
	if ($panther_config['o_private_messaging'] == '1')
	{
		$pm_tpl = panther_template('warning_pm.tpl');
		$search = array(
			'{pm_sent_legend}' => $lang_warnings['Private message sent'],
			'{note_message}' => ($note_pm == '') ? $lang_warnings['No message'] : $note_pm,
		);

		$pm_tpl = str_replace(array_keys($search), array_values($search), $pm_tpl);
	}
	else
		$pm_tpl = '';

	if ($panther_user['is_admmod'] && ($panther_user['g_mod_warn_users'] == '1' || $panther_user['is_admin']))
	{
		$del_tpl = panther_template('delete_warning.tpl');
		$search = array(
			'{warning_id}' => $warning_id,
			'{user_id}' => $warning_details['user_id'],
			'{csrf_token}' => generate_csrf_token(),
			'{delete}' => $lang_warnings['Delete'],
			'{delete_warning}' => $lang_warnings['Delete warning'],
		);

		$del_tpl = str_replace(array_keys($search), array_values($search), $del_tpl);
	}
	else
		$del_tpl = '';
	
	if ($warning_details['post_id'])
		$info_tpl = "\t\t".$message."\n\t\t".'<p><a href="'.get_link($panther_url['post'], array($warning_details['post_id'])).'">'.$lang_warnings['Link to post'].'</a></p>';
	else
		$info_tpl = "\t\t".'<p>'.$lang_warnings['Issued from profile'].'</p>';

	$url_username = url_friendly($username);
	$warn_tpl = panther_template('warning_details.tpl');
	$search = array(
		'{profile_link}' => get_link($panther_url['profile'], array($warning_details['user_id'], $url_username)),
		'{username}' => panther_htmlspecialchars($username),
		'{warnings_view}' => get_link($panther_url['warning_view'], array($warning_details['user_id'])),
		'{warnings}' => panther_htmlspecialchars($lang_warnings['Warnings']),
		'{warning_details_link}' => get_link($panther_url['warning_details'], array($warning_id)),
		'{details}' => panther_htmlspecialchars($lang_warnings['Details']),
		'{warning_details}' => $lang_warnings['Warning details'],
		'{form_action}' => get_link($panther_url['warnings']),
		'{warning_info}' => $lang_warnings['Warning info'],
		'{warned_username}' => sprintf($lang_warnings['Username'], colourize_group($url_username, $group_id, $warning_details['user_id'])),
		'{warning_title}' => sprintf($lang_warnings['Warning'], $warning_title),
		'{date_issued}' => sprintf($lang_warnings['Date issued'], format_time($warning_details['date_issued'])),
		'{warning_expires}' => $warning_expires,
		'{issued_by}' => sprintf($lang_warnings['Issued by'], colourize_group($warning_details['issued_by_username'], $warning_details['issuer_gid'], $warning_details['issued_by'])),
		'{admin_note}' => $admin_tpl,
		'{private_message}' => $pm_tpl,
		'{copy_of_post}' => $lang_warnings['Copy of post'],
		'{post_information}' => $info_tpl,
		'{delete_warning}' => $del_tpl,
	);

	echo str_replace(array_keys($search), array_values($search),$warn_tpl);
}
else if (isset($_POST['delete_id']))
{
	confirm_referrer('warnings.php');
	
	// Are we allowed to delete warnings?
	if (!$panther_user['is_admin'] && (!$panther_user['is_admmod'] || $panther_user['g_mod_warn_users'] == '0'))
		message($lang_common['No permission']);

	$warning_id = isset($_POST['delete_id']) ? intval($_POST['delete_id']) : 0;
	$user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;

	if ($warning_id < 1)
		message($lang_common['Bad request']);

	$data = array(
		':id'	=>	$warning_id,
	);

	// Delete the warning
	$db->delete('warnings', 'id=:id', $data);
	redirect(get_link($panther_url['warning_view'], array($user_id)), $lang_warnings['Warning deleted redirect']);
}
else if ($action == 'show_recent')
{
	if (!$panther_user['is_admmod'])
		message($lang_common['No permission']);

	// Fetch warnings count
	$ps = $db->select('warnings', 'COUNT(id)');
	$num_warnings = $ps->fetchColumn();

	// Determine the user offset (based on $_GET['p'])
	$num_pages = ceil($num_warnings / 50);

	$p = (!isset($_GET['p']) || !is_numeric($_GET['p']) || $_GET['p'] <= 1 || $_GET['p'] > $num_pages) ? 1 : $_GET['p'];
	$start_from = 50 * ($p - 1);

	// Generate paging links
	$paging_links = '<span class="pages-label">'.$lang_common['Pages'].' </span>'.paginate($num_pages, $p, $panther_url['warnings_recent']);
	$data = array(
		':start'	=>	$start_from,
	);

	$ps = $db->run('SELECT w.id, w.user_id, w.type_id, w.post_id, w.title AS custom_title, w.points, w.date_issued, w.date_expire, w.issued_by, t.title, u.username AS issued_by_username, u.group_id AS issuer_gid, v.username AS username, v.group_id AS user_gid FROM '.$db->prefix.'warnings as w LEFT JOIN '.$db->prefix.'warning_types AS t ON t.id=w.type_id LEFT JOIN '.$db->prefix.'users AS u ON u.id=w.issued_by LEFT JOIN '.$db->prefix.'users AS v ON v.id=w.user_id ORDER BY w.date_issued DESC LIMIT :start, 50', $data);

	$warnings = array();
	$warn_row_tpl = panther_template('warning_row.tpl');
	if ($ps->rowCount())
	{
		foreach ($ps as $active_warnings)
		{
			if ($active_warnings['custom_title'] != '')
				$warning_title = sprintf($lang_warnings['Custom warning'], panther_htmlspecialchars($active_warnings['custom_title']));
			else if ($active_warnings['title'] != '')
				$warning_title = panther_htmlspecialchars($active_warnings['title']);
			else
				$warning_title = '';

			$search = array(
				'{warning_title}' => $warning_title,
				'{date_issued}' => format_time($active_warnings['date_issued']),
				'{points}' => $active_warnings['points'],
				'{date_expire}' => ($active_warnings['username'] != '') ? colourize_group($active_warnings['username'], $active_warnings['user_gid'], $active_warnings['user_id']) : '',
				'{issuer_username}' => ($active_warnings['issued_by_username'] != '') ? colourize_group($active_warnings['issued_by_username'], $active_warnings['issuer_gid'], $active_warnings['issued_by']) : '',
				'{warning_detail}' => get_link($panther_url['warning_details'], array($active_warnings['id'])),
				'{details}' => $lang_warnings['Details'],
			);

			$warnings[] = str_replace(array_keys($search), array_values($search), $warn_row_tpl);			
		}
	}
	else
	{
		$warn_tpl = panther_template('no_warnings.tpl');
		$search = array(
			'{active}' => $lang_warnings['No warnings'],
		);

		$warnings[] = str_replace(array_keys($search), array_values($search), $warn_tpl); 
	}
	
	
	$warn_tpl = panther_template('warnings_recent.tpl');
	$search = array(
		'{paging_links}' => $paging_links,
		'{recent_warnings}' => $lang_warnings['Recent warnings'],
		'{warning}' => $lang_warnings['Warning 2'],
		'{date_issued}' => $lang_warnings['Date issued 2'],
		'{points}' => $lang_warnings['Points'],
		'{warned_users}' => $lang_warnings['Warned user'],
		'{issued_by}' => $lang_warnings['Issued by 2'],
		'{details}' => $lang_warnings['Details'],
		'{warning_rows}' => implode("\n", $warnings),
	);

	echo str_replace(array_keys($search), array_values($search), $warn_tpl);
}
else
{
	$ps = $db->select('warning_types', 'id, title, description, points, expiration_time', array(), '', 'points, id');
	$ps1 = $db->select('warning_levels', 'id, points, period', array(), '', 'points, id');

	// If neither produces a result
	if (!$ps->rowCount() && !$ps1->rowCount())
		message($lang_common['Bad request']);

	$level_row_tpl = panther_template('warnings_levels_row.tpl');
	$list_row_tpl = panther_template('warnings_types_row.tpl');
	$types = $levels = array();
	foreach ($ps as $list_types)
	{
		$search = array(
			'{title}' => $list_types['title'],
			'{description}' => $list_types['description'],
			'{points}' => $list_types['points'],
		);
		
		$types[] = str_replace(array_keys($search), array_values($search), $list_row_tpl);
	}

	foreach ($ps1 as $list_levels)
	{
		if ($list_levels['period'] == '0')
			$ban_title = $lang_warnings['Permanent ban'];
		else
			$ban_title = format_expiration_time($list_levels['period']);

		$search = array(
			'{title}' => $ban_title,
			'{points}' => sprintf($lang_warnings['No of points'], $list_levels['points']),
		);
		
		$levels[] = str_replace(array_keys($search), array_values($search), $level_row_tpl);
	}

	$warn_tpl = panther_template('warnings.tpl');
	$search = array(
		'{warning_types}' => $lang_warnings['Warning types'],
		'{name}' => $lang_warnings['Name'],
		'{description}' => $lang_warnings['Description'],
		'{points}' => $lang_warnings['Points'],
		'{warning_types_content}' => count($types) ? implode("\n", $types) : '',
		'{automatic_bans}' => $lang_warnings['Automatic bans'],
		'{ban_period}' => $lang_warnings['Ban period'],
		'{reason}' => $lang_warnings['Reason'],
		'{auto_ban_content}' => count($levels) ? implode("\n", $levels) : '',
	);

	echo str_replace(array_keys($search), array_values($search), $warn_tpl);
}

$footer_style = 'warnings';
require PANTHER_ROOT.'footer.php';