<?php
/**
 * Copyright (C) 2015 Panther (https://www.pantherforum.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

// Make sure no one attempts to run this script "directly"
if (!defined('PANTHER'))
	exit;

$tpl_temp = trim(ob_get_contents());
$tpl_main = str_replace('<panther_main>', $tpl_temp, $tpl_main);
ob_end_clean();
// END SUBST - <panther_main>

// START SUBST - <panther_footer>
if (isset($footer_style) && ($footer_style == 'viewforum' || $footer_style == 'viewtopic') && $is_admmod)
{
	$controls = array();
	if ($footer_style == 'viewforum')
	{
		$control_lang = $lang_forum['Mod controls'];
		$controls[] = "\t\t\t\t".'<dd><span><a href="'.get_link($panther_url['moderate_forum_p'], array($forum_id, $p)).'">'.$lang_common['Moderate forum'].'</a></span></dd>'."\n";
	}
	else if ($footer_style == 'viewtopic')
	{
		$control_lang = $lang_topic['Mod controls'];
		if ($cur_topic['archived'] != '1')
		{
			$controls[] = "\t\t\t\t".'<dd><span><a href="'.get_link($panther_url['moderate_topic_p'], array($forum_id, $id, $p)).'">'.$lang_common['Moderate topic'].'</a>'.($num_pages > 1 ? ' (<a href="'.get_link($panther_url['moderate_all'], array($forum_id, $id)).'">'.$lang_common['All'].'</a>)' : '').'</span></dd>'."\n";
			$controls[] = "\t\t\t\t".'<dd><span><a href="'.get_link($panther_url['move'], array($forum_id, $id, $csrf_token)).'">'.$lang_common['Move topic'].'</a></span></dd>'."\n";

			if ($cur_topic['closed'] == '1')
				$controls[] = "\t\t\t\t".'<dd><span><a href="'.get_link($panther_url['open'], array($forum_id, $id, $csrf_token)).'">'.$lang_common['Open topic'].'</a></span></dd>'."\n";
			else
				$controls[] = "\t\t\t\t".'<dd><span><a href="'.get_link($panther_url['close'], array($forum_id, $id, $csrf_token)).'">'.$lang_common['Close topic'].'</a></span></dd>'."\n";

			if ($cur_topic['sticky'] == '1')
				$controls[] = "\t\t\t\t".'<dd><span><a href="'.get_link($panther_url['unstick'], array($forum_id, $id, $csrf_token)).'">'.$lang_common['Unstick topic'].'</a></span></dd>'."\n";
			else
				$controls[] = "\t\t\t\t".'<dd><span><a href="'.get_link($panther_url['stick'], array($forum_id, $id, $csrf_token)).'">'.$lang_common['Stick topic'].'</a></span></dd>'."\n";

			$controls[] = "\t\t\t\t".'<dd><span><a href="'.get_link($panther_url['archive'], array($forum_id, $id, $csrf_token)).'">'.$lang_common['Archive topic'].'</a></span></dd>'."\n";
			$controls[] = "\t\t\t\t".'<dd><span><a href="'.get_link($panther_url['moderate_multi'], array($forum_id, $id, $csrf_token)).'">'.$lang_common['multi_moderate topic'].'</a></span></dd>'."\n";
		}
		else
		{
			if ($panther_user['is_admin'])
				$controls[] = "\t\t\t\t".'<dd><span><a href="'.get_link($panther_url['unarchive'], array($forum_id, $id, $csrf_token)).'">'.$lang_common['Unarchive topic'].'</a></span></dd>'."\n";
		}
	}

	$search = array(
		'{mod_controls}' => $control_lang,
		'{moderator_links}' => count($controls) ? implode("\n", $controls) : '',
	);
	
	$mod_controls_tpl = str_replace(array_keys($search), array_values($search), panther_template('moderator_controls.tpl'));
}
else
	$mod_controls_tpl = '';

// Display the "Jump to" drop list
if ($panther_config['o_quickjump'] == '1')
{
	ob_start();
	// Load cached quick jump
	if (file_exists(FORUM_CACHE_DIR.'cache_quickjump_'.$panther_user['g_id'].'.php'))
		require FORUM_CACHE_DIR.'cache_quickjump_'.$panther_user['g_id'].'.php';

	if (!defined('PANTHER_QJ_LOADED'))
	{
		if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
			require PANTHER_ROOT.'include/cache.php';

		generate_quickjump_cache($panther_user['g_id']);
		require FORUM_CACHE_DIR.'cache_quickjump_'.$panther_user['g_id'].'.php';
	}
	
	$quickjump_tpl = trim(ob_get_contents());
	ob_end_clean();
}
else
	$quickjump_tpl = '';

// If no footer style has been specified, we use the default (only copyright/debug info)
if (isset($footer_style) && $footer_style == 'warnings')
{
	$links = array();
	$feed_tpl = panther_template('warning_footer.tpl');	
	$links[] = "\t\t\t\t\t\t".'<dd><a href="'.get_link($panther_url['warnings']).'">'.$lang_warnings['Show warning types'].'</a></dd>';
	
	if ($panther_user['is_admmod'])
		$links[] = "\t\t\t\t\t\t".'<dd><a href="'.get_link($panther_url['warnings_recent']).'">'.$lang_warnings['Show recent warnings'].'</a></dd>';

	$search = array(
		'{warning_links}' => $lang_common['Warning links'],
		'{warnings}' => count($links) ? implode("\n", $links) : '',
	);

	$feed_tpl = str_replace(array_keys($search), array_values($search), $feed_tpl);
}
elseif (isset($footer_style) && ($footer_style == 'index' || $footer_style == 'viewforum' || $footer_style == 'viewtopic') && ($panther_config['o_feed_type'] == '1' || $panther_config['o_feed_type'] == '2'))
{
	$feed_tpl = panther_template('feed.tpl');
	switch ($footer_style)
	{
		case 'index':
			if ($panther_config['o_feed_type'] == '1')
			{
				$type = 'rss';
				$feed_link = get_link($panther_url['index_rss']);
				$feed_lang = $lang_common['RSS active topics feed'];
			}
			else
			{
				$type = 'atom';
				$feed_link = get_link($panther_url['index_atom']);
				$feed_lang = $lang_common['Atom active topics feed'];
			}
		break;
		case 'viewforum':
			if ($panther_config['o_feed_type'] == '1')
			{
				$type = 'rss';
				$feed_link = get_link($panther_url['forum_rss'], array($forum_id));
				$feed_lang = $lang_common['RSS forum feed'];
			}
			else
			{
				$type = 'atom';
				$feed_link = get_link($panther_url['forum_atom'], array($forum_id));
				$feed_lang = $lang_common['Atom forum feed'];
			}			
		break;
		case 'viewtopic':
			if ($panther_config['o_feed_type'] == '1')
			{
				$type = 'rss';
				$feed_link = get_link($panther_url['topic_rss'], array($id));
				$feed_lang = $lang_common['RSS topic feed'];
			}
			else
			{
				$type = 'atom';
				$feed_link = get_link($panther_url['topic_atom'], array($id));
				$feed_lang = $lang_common['Atom topic feed'];
			}			
		break;
	}

	$search = array(
		'{feed_link}' => $feed_link,
		'{feed_lang}' => $feed_lang,
		'{feed_type}' => $type,
	);

	$feed_tpl = "\n".str_replace(array_keys($search), array_values($search), $feed_tpl);
}
else
	$feed_tpl = '';

// Display debug info (if enabled/defined)
if ($panther_config['o_debug_mode'] == '1')
{
	// Calculate script generation time
	$time_diff = sprintf('%.3f', get_microtime() - $panther_start);
	$debug_tpl = sprintf($lang_common['Querytime'], $time_diff, $db->get_num_queries());

	if (function_exists('memory_get_usage'))
	{
		$debug_tpl .= ' - '.sprintf($lang_common['Memory usage'], file_size(memory_get_usage()));

		if (function_exists('memory_get_peak_usage'))
			$debug_tpl .= ' '.sprintf($lang_common['Peak usage'], file_size(memory_get_peak_usage()));
	}

	$debug_tpl = "\n".str_replace('{debug_info}', $debug_tpl, panther_template('debug_line.tpl'));
}
else
	$debug_tpl = '';

$footer_tpl = panther_template('footer.tpl');
$search = array(
	'{board_footer}' => $lang_common['Board footer'],
	'{mod_controls}' => $mod_controls_tpl,
	'{quickjump}' => $quickjump_tpl,
	'{footer}' => '',
	'{feed_links}' => $feed_tpl,
	'{powered_by_panther}' => sprintf($lang_common['Powered by'], '<a href="https://www.pantherforum.org/">Panther</a>'.(($panther_config['o_show_version'] == '1') ? ' '.$panther_config['o_cur_version'] : '')),
	'{debug_line}' => $debug_tpl.(($panther_config['o_show_queries'] == '1') ? "\n".display_saved_queries() : ''),
);

$tpl_temp = str_replace(array_keys($search), array_values($search), $footer_tpl);

// End the transaction
$db->end_transaction();

$tpl_main = str_replace('<panther_footer>', $tpl_temp, $tpl_main);
// END SUBST - <panther_footer>

// Close the db connection (and free up any result data)
$db->close();

// Spit out the page
exit($tpl_main);