<?php
/**
 * Copyright (C) 2015 Panther (https://www.pantherforum.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/');
	require PANTHER_ROOT.'include/common.php';
}

if ($panther_user['is_bot'])
	message($lang_common['No permission']);

if ($panther_user['g_read_board'] == '0')
	message($lang_common['No view'], false, '403 Forbidden');
else if ($panther_user['g_view_users'] == '0')
	message($lang_common['No permission'], false, '403 Forbidden');

// Load the userlist.php language file
require PANTHER_ROOT.'lang/'.$panther_user['language'].'/userlist.php';

// Load the search.php language file
require PANTHER_ROOT.'lang/'.$panther_user['language'].'/search.php';

// Determine if we are allowed to view post counts
$show_post_count = ($panther_config['o_show_post_count'] == '1' || $panther_user['is_admmod']) ? true : false;

$username = isset($_GET['username']) && $panther_user['g_search_users'] == '1' ? panther_trim($_GET['username']) : '';
$show_group = isset($_GET['show_group']) ? intval($_GET['show_group']) : -1;
$sort_by = isset($_GET['sort_by']) && (in_array($_GET['sort_by'], array('username', 'registered')) || ($_GET['sort_by'] == 'num_posts' && $show_post_count)) ? $_GET['sort_by'] : 'username';
$sort_dir = isset($_GET['sort_dir']) && $_GET['sort_dir'] == 'DESC' ? 'DESC' : 'ASC';

// Create any applicable SQL generated from the GET array
$data = array(
	':unverified'	=>	PANTHER_UNVERIFIED,
);

$fields = array();
$sql = 'SELECT COUNT(id) FROM '.$db->prefix.'users AS u WHERE u.id > 1 AND u.group_id != :unverified';
$sql1 = 'SELECT u.id, u.username, u.title, u.num_posts, u.registered, u.email, u.use_gravatar, u.group_id AS g_id, g.g_user_title, o.user_id AS is_online FROM '.$db->prefix.'users AS u LEFT JOIN '.$db->prefix.'groups AS g ON g.g_id=u.group_id LEFT JOIN '.$db->prefix.'online AS o ON (o.user_id=u.id AND o.user_id!=1) WHERE u.id>1 AND u.group_id!=:unverified';

if ($username != '')
{
	$fields['username'] = ' AND u.username LIKE :username';
	$data[':username'] = str_replace('*', '%', $username);
}

if ($show_group > -1)
{
	$fields['gid'] = ' AND u.group_id = :gid';
	$data[':gid'] = $show_group;
}

foreach($fields as $field => $where_cond)
{
	$sql .= $where_cond;
	$sql1 .= $where_cond;
}

// Fetch user count
$ps = $db->run($sql, $data);
$num_users = $ps->fetchColumn();

// Determine the user offset (based on $_GET['p'])
$num_pages = ceil($num_users / 50);

$p = (!isset($_GET['p']) || $_GET['p'] <= 1 || $_GET['p'] > $num_pages) ? 1 : intval($_GET['p']);
$start_from = 50 * ($p - 1);

$data[':start'] = $start_from;
$sql1 .= " ORDER BY ".$sort_by." ".$sort_dir.", u.id ASC LIMIT :start, 50";

$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_common['User list']);
if ($panther_user['g_search_users'] == '1')
	$focus_element = array('userlist', 'username');

// Generate paging links
$paging_links = '<span class="pages-label">'.$lang_common['Pages'].' </span>'.paginate($num_pages, $p, $panther_url['userlist_result'], array(urlencode($username), $show_group, $sort_by, $sort_dir));

define('PANTHER_ALLOW_INDEX', 1);
define('PANTHER_ACTIVE_PAGE', 'userlist');
require PANTHER_ROOT.'header.php';

$userlist_tpl = panther_template('userlist.tpl');

$options = array();
foreach ($panther_groups as $cur_group)
	$options[] = '<option value="'.$cur_group['g_id'].'"'.(($cur_group['g_id'] == $show_group) ? ' selected="selected"' : '').'>'.panther_htmlspecialchars($cur_group['g_title']).'</option>';

// Retrieve a list of user IDs, LIMIT is (really) expensive so we only fetch the IDs here then later fetch the remaining data
$ps = $db->run($sql1, $data);
if ($ps->rowCount())
{
	// Grab the users
	$user_row_tpl = panther_template('userlist_row.tpl');
	require PANTHER_ROOT.'lang/'.$panther_user['language'].'/online.php';
	foreach ($ps as $user_data)
	{
		$is_online = ($user_data['is_online'] == $user_data['id']) ? '<img src="'.$panther_config['o_image_dir'].'status_online.png" title="'.$lang_online['user is online'].'" />' : '<img src="'.$panther_config['o_image_dir'].'status_offline.png" title="'.$lang_online['user is offline'].'" />';

		$search = array(
			'{user_avatar}' => generate_avatar_markup($user_data['id'], $user_data['email'], $user_data['use_gravatar'], array(32, 32)),
			'{online_status}' => $is_online.colourize_group($user_data['username'], $user_data['g_id'], $user_data['id']),
			'{user_title}' => get_title($user_data),
			'{post_count_field}' => ($show_post_count) ? "\n\t\t\t\t\t".'<td class="tc3">'.forum_number_format($user_data['num_posts']).'</td>' : '',
			'{user_registered}' => format_time($user_data['registered'], true),
		);

		$user_tpl[$user_data['id']] = str_replace(array_keys($search), array_values($search), $user_row_tpl);
	}
}
else
	$user_tpl[0] = "\t\t\t".'<tr>'."\n\t\t\t\t\t".'<td class="tcl" colspan="'.(($show_post_count) ? 4 : 3).'">'.$lang_search['No hits'].'</td></tr>'."\n";

$search = array(
	'{userlist}' => $lang_search['User search'],
	'{form_action}' => get_link($panther_url['userlist']),
	'{user_find_legend}' => $lang_ul['User find legend'],
	'{username_field}' => ($panther_user['g_search_users'] == '1') ? "\n\t\t\t\t\t\t".'<label class="conl">'.$lang_common['Username'].'<br /><input type="text" name="username" value="'.panther_htmlspecialchars($username).'" size="25" maxlength="25" /><br /></label>' : '',
	'{user_group}' => $lang_ul['User group'],
	'{all_users_select}' => ($show_group == -1) ? ' selected="selected"' : '',
	'{all_users}' => $lang_ul['All users'],
	'{group_options}' => implode("\n\t\t\t\t\t\t\t", $options),
	'{sort_by}' => $lang_search['Sort by'],
	'{username_select}' => ($sort_by == 'username') ? ' selected="selected"' : '',
	'{username}' => $lang_common['Username'],
	'{post_count_option}' => ($show_post_count) ? "\n\t\t\t\t\t\t\t".'<option value="num_posts"'.(($sort_by == 'num_posts') ? ' selected="selected"' : '').'>'.$lang_ul['No of posts'].'</option>' : '',
	'{registered_select}' => ($sort_by == 'registered') ? ' selected="selected"' : '',
	'{registered}' => $lang_common['Registered'],
	'{sort_order}' => $lang_search['Sort order'],
	'{sort_asc_select}' => ($sort_dir == 'ASC') ? ' selected="selected"' : '',
	'{ascending}' => $lang_search['Ascending'],
	'{sort_desc_select}' => ($sort_dir == 'DESC') ? ' selected="selected"' : '',
	'{descending}' => $lang_search['Descending'],
	'{user_search_info}' => ($panther_user['g_search_users'] == '1' ? $lang_ul['User search info'].' ' : '').$lang_ul['User sort info'],
	'{submit}' => $lang_common['Submit'],
	'{paging_links}' => $paging_links,
	'{user_list}' => $lang_common['User list'],
	'{avatar}' => $lang_common['Avatar'],
	'{username}' => $lang_common['Username'],
	'{title}' => $lang_common['Title'],
	'{registered}' => $lang_common['Registered'],
	'{posts_column}' => ($show_post_count) ? "\n\t\t\t\t\t".'<th class="tc3" scope="col">'.$lang_common['Posts'].'</th>' : '',
	'{userlist_content}' => implode("\n", $user_tpl),
);

echo str_replace(array_keys($search), array_values($search), $userlist_tpl);
require PANTHER_ROOT.'footer.php';