<?php
/**
 * Copyright (C) 2015 Panther (https://www.pantherforum.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

// Tell header.php to use the admin template
define('PANTHER_ADMIN_CONSOLE', 1);

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/../');
	require PANTHER_ROOT.'include/common.php';
}
require PANTHER_ROOT.'include/common_admin.php';

if (($panther_user['is_admmod'] && $panther_user['g_mod_cp'] == '0' && !$panther_user['is_admin']) || !$panther_user['is_admmod'])
	message($lang_common['No permission'], false, '403 Forbidden');

check_authentication();

if ($panther_config['o_delete_full'] == '1')
	message($lang_common['Bad request']);

// Load the admin_deleted.php language file
require PANTHER_ROOT.'lang/'.$admin_language.'/admin_deleted.php';

if (isset($_POST['post_id']))
{
	confirm_referrer(PANTHER_ADMIN_DIR.'/deleted.php');
	$post_id = intval(key($_POST['post_id']));
	$action = isset($_POST['action']) && is_array($_POST['action']) ? intval($_POST['action'][$post_id]) : '1';
	$data = array(
		':id'	=>	$post_id,
	);

	$ps = $db->run('SELECT t.first_post_id, p.topic_id, p.message, t.subject, t.forum_id FROM '.$db->prefix.'posts AS p INNER JOIN '.$db->prefix.'topics AS t ON p.topic_id=t.id WHERE p.id=:id AND p.deleted=1', $data);
	if (!$ps->rowCount())
		message($lang_common['Bad request']);
	else
		$post = $ps->fetch();

	$is_topic_post = ($post_id == $post['first_post_id']) ? true : false;
	if ($action == '1')
	{
		if ($is_topic_post)
		{
			$update = array(
				'deleted'	=>	0,
			);

			$data = array(
				':id'	=>	$post['topic_id'],
			);

			$db->update('topics', $update, 'id=:id', $data);
			if (!defined('PANTHER_CJK_HANGUL_REGEX'))
				require PANTHER_ROOT.'include/search_idx.php';

			update_search_index('post', $post['topic_id'], $post['message'], $post['subject']);

			$db->update('posts', $update, 'topic_id=:id AND deleted=1 AND approved=1', $data);
			$ps = $db->select('posts', 'message, id', $data, 'id=:id');
			foreach ($ps as $cur_post)
				update_search_index('post', $cur_post['id'], $cur_post['message']);

			update_forum($post['forum_id']);
			redirect(get_link($panther_url['admin_deleted']), $lang_admin_deleted['Topic approved redirect']);
		}
		else
		{
			$topic_data = array(
				':id'	=>	$post['topic_id'],
			);

			$ps = $db->select('topics', 1, $topic_data, 'id=:id AND deleted=0 AND approved=1');	// Check there's a valid topic to go back to
			if (!$ps->rowCount())
				message($lang_admin_deleted['topic has been deleted']);
			
			$update = array(
				'deleted'	=>	0,
			);
			
			$post_data = array(
				':id'	=>	$post_id,
			);
			
			$db->update('posts', $update, 'id=:id', $post_data);
			if (!defined('PANTHER_CJK_HANGUL_REGEX'))
				require PANTHER_ROOT.'include/search_idx.php';

			update_search_index('post', $post_id, $post['message']);
			
			$ps = $db->select('posts', 'id, poster, posted', $topic_data, 'topic_id=:id AND approved=1 AND deleted=0', 'id DESC LIMIT 1');
			list($last_id, $poster, $posted) = $ps->fetch(PDO::FETCH_NUM);
			
			$ps = $db->select('topics', 'num_replies', $topic_data, 'id=:id');
			$num_replies = $ps->fetchColumn();
			
			$update = array(
				'num_replies'	=>	$num_replies+1,
				'last_post'		=>	$posted,
				'last_post_id'	=>	$last_id,
				'last_poster'	=>	$poster,
			);

			$db->update('topics', $update, 'id=:id', $topic_data);
			update_search_index('post', $post_id, $post['message']);
				
			update_forum($post['forum_id']);
			redirect(get_link($panther_url['admin_deleted']), $lang_admin_deleted['Post approved redirect']);			
		}
	}
	else
	{
		if ($is_topic_post)
		{
			permanently_delete_topic($post['topic_id']);
			redirect(get_link($panther_url['admin_deleted']), $lang_admin_deleted['Topic deleted redirect']);
		}
		else
		{
			permanently_delete_post($post_id);
			redirect(get_link($panther_url['admin_deleted']), $lang_admin_deleted['Post deleted redirect']);
		}
	}
}

$ps = $db->run('SELECT t.id AS topic_id, t.forum_id, p.poster, p.poster_id, p.posted, p.message, p.id AS pid, p.hide_smilies, t.subject, f.forum_name FROM '.$db->prefix.'posts AS p LEFT JOIN '.$db->prefix.'topics AS t ON p.topic_id=t.id LEFT JOIN '.$db->prefix.'forums AS f ON t.forum_id=f.id WHERE p.deleted=1 OR t.deleted=1 ORDER BY p.posted DESC');

require PANTHER_ROOT.'include/parser.php';
$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_admin_common['Admin'], $lang_admin_common['Deleted']);
define('PANTHER_ACTIVE_PAGE', 'admin');
require PANTHER_ROOT.'header.php';

generate_admin_menu('deleted');
if ($ps->rowCount())
{
	$deleted_tpl = array();
	$content_tpl = panther_template('deleted_content_row.tpl');
	foreach ($ps as $cur_post)
	{
		$poster = ($cur_post['poster'] != '') ? '<a href="'.get_link($panther_url['profile'], array($cur_post['poster_id'], url_friendly($cur_post['poster']))).'">'.panther_htmlspecialchars($cur_post['poster']).'</a>' : $lang_admin_deleted['Deleted user'];
		$forum = ($cur_post['forum_name'] != '') ? '<span><a href="'.get_link($panther_url['forum'], array($cur_post['forum_id'], url_friendly($cur_post['forum_name']))).'">'.panther_htmlspecialchars($cur_post['forum_name']).'</a></span>' : '<span>'.$lang_admin_deleted['Deleted'].'</span>';
		$topic = ($cur_post['subject'] != '') ? '<span>»&#160;<a href="'.get_link($panther_url['topic'], array($cur_post['topic_id'], url_friendly($cur_post['subject']))).'">'.panther_htmlspecialchars($cur_post['subject']).'</a></span>' : '<span>»&#160;'.$lang_admin_deleted['Deleted'].'</span>';

		$post_id = ($cur_post['pid'] != '') ? '<span>»&#160;<a href="'.get_link($panther_url['post'], array($cur_post['pid'])).'">'.sprintf($lang_admin_deleted['Post ID'], $cur_post['pid']).'</a></span>' : '<span>»&#160;'.$lang_admin_deleted['Deleted'].'</span>';
		$post_location = array($forum, $topic, $post_id);
		
		$search = array(
			'{post_deletion_subhead}' => sprintf($lang_admin_deleted['Post subhead'], format_time($cur_post['posted'])),
			'{poster}' => sprintf($lang_admin_deleted['Posted by'], $poster),
			'{post_location}' => implode(' ', $post_location),
			'{message}' => $lang_admin_deleted['Message'],
			'{post_id}' => $cur_post['pid'],
			'{restore}' => $lang_admin_deleted['Restore'],
			'{delete}' => $lang_admin_deleted['Delete'],
			'{submit}' => $lang_common['Submit'],
			'{post_message}' => parse_message($cur_post['message'], $cur_post['hide_smilies']),
		);
		
		$deleted_tpl[] = str_replace(array_keys($search), array_values($search), $content_tpl);
	}
	$deleted_tpl = implode("\n", $deleted_tpl);
}
else
{
	$deleted_tpl = panther_template('deleted_none.tpl');
	$search = array(
		'{none}' => $lang_admin_common['None'],
		'{no_new_posts}' => $lang_admin_deleted['No new posts'],
	);
	
	$deleted_tpl = str_replace(array_keys($search), array_values($search), $deleted_tpl);
}

$admin_tpl = panther_template('admin_deleted.tpl');
$search = array(
	'{deleted_posts_head}' => $lang_admin_deleted['Deleted posts head'],
	'{form_action}' => get_link($panther_url['admin_deleted']),
	'{csrf_token}' => generate_csrf_token(PANTHER_ADMIN_DIR.'/deleted.php'),
	'{deleted_content}' => "\n".$deleted_tpl,
);

echo str_replace(array_keys($search), array_values($search), $admin_tpl);
require PANTHER_ROOT.'footer.php';