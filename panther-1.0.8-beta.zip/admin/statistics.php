<?php
/**
 * Copyright (C) 2015 Panther (https://www.pantherforum.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

// Tell header.php to use the admin template
define('PANTHER_ADMIN_CONSOLE', 1);

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/../');
	require PANTHER_ROOT.'include/common.php';
}

require PANTHER_ROOT.'include/common_admin.php';

if (!$panther_user['is_admmod'])
	message($lang_common['No permission'], false, '403 Forbidden');

check_authentication();

// Load the admin_index.php language file
require PANTHER_ROOT.'lang/'.$admin_language.'/admin_index.php';

// Get the server load averages (if possible)
if (@file_exists('/proc/loadavg') && is_readable('/proc/loadavg'))
{
	// We use @ just in case
	$fh = @fopen('/proc/loadavg', 'r');
	$load_averages = @fread($fh, 64);
	@fclose($fh);

	if (($fh = @fopen('/proc/loadavg', 'r')))
	{
		$load_averages = fread($fh, 64);
		fclose($fh);
	}
	else
		$load_averages = '';

	$load_averages = @explode(' ', $load_averages);
	$server_load = isset($load_averages[2]) ? $load_averages[0].' '.$load_averages[1].' '.$load_averages[2] : $lang_admin_index['Not available'];
}
else if (!in_array(PHP_OS, array('WINNT', 'WIN32')) && preg_match('%averages?: ([0-9\.]+),?\s+([0-9\.]+),?\s+([0-9\.]+)%i', @exec('uptime'), $load_averages))
	$server_load = $load_averages[1].' '.$load_averages[2].' '.$load_averages[3];
else
	$server_load = $lang_admin_index['Not available'];

// Get number of current visitors
$ps = $db->select('online', 'COUNT(user_id)', array(), 'idle=0');
$num_online = $ps->fetchColumn();

$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_admin_common['Admin'], $lang_admin_common['Server statistics']);
define('PANTHER_ACTIVE_PAGE', 'admin');
require PANTHER_ROOT.'header.php';

generate_admin_menu('index');
if ($panther_user['is_admin'])
{
	// Collect some additional info about MySQL
	$ps = $db->run('SHOW TABLE STATUS');
	$total_records = $total_size = 0;
	foreach ($ps as $status)
	{
		$total_records += $status['Rows'];
		$total_size += $status['Data_length'] + $status['Index_length'];
	}

	$total_size = file_size($total_size);

	// Check for the existence of various PHP opcode caches/optimizers
	if (function_exists('mmcache'))
		$php_accelerator = '<a href="http://'.$lang_admin_index['Turck MMCache link'].'">'.$lang_admin_index['Turck MMCache'].'</a>';
	else if (isset($_PHPA))
		$php_accelerator = '<a href="http://'.$lang_admin_index['ionCube PHP Accelerator link'].'">'.$lang_admin_index['ionCube PHP Accelerator'].'</a>';
	else if (ini_get('apc.enabled'))
		$php_accelerator ='<a href="http://'.$lang_admin_index['Alternative PHP Cache (APC) link'].'">'.$lang_admin_index['Alternative PHP Cache (APC)'].'</a>';
	else if (ini_get('zend_optimizer.optimization_level'))
		$php_accelerator = '<a href="http://'.$lang_admin_index['Zend Optimizer link'].'">'.$lang_admin_index['Zend Optimizer'].'</a>';
	else if (ini_get('eaccelerator.enable'))
		$php_accelerator = '<a href="http://'.$lang_admin_index['eAccelerator link'].'">'.$lang_admin_index['eAccelerator'].'</a>';
	else if (ini_get('xcache.cacher'))
		$php_accelerator = '<a href="http://'.$lang_admin_index['XCache link'].'">'.$lang_admin_index['XCache'].'</a>';
	else
		$php_accelerator = $lang_admin_index['NA'];

	$server_tpl = panther_template('stats_admin.tpl');
	$search = array(
		'{environment_label}' => $lang_admin_index['Environment label'],
		'{php_environment}' => sprintf($lang_admin_index['Environment data OS'], PHP_OS),
		'{php_version}' => sprintf($lang_admin_index['Environment data version'], phpversion(), '<a href="'.get_link($panther_url['phpinfo']).'">'.$lang_admin_index['Show info'].'</a>'),
		'{php_accelerator}' => sprintf($lang_admin_index['Environment data acc']."\n", $php_accelerator),
		'{database_label}' => $lang_admin_index['Database label'],
		'{db_version}' => implode(' ', $db->get_version()),
		'{total_records}' => sprintf($lang_admin_index['Database data rows']."\n", forum_number_format($total_records)),
		'{total_size}' => sprintf($lang_admin_index['Database data size']."\n", $total_size),
	);

	$server_tpl = "\n".str_replace(array_keys($search), array_values($search), $server_tpl);
}
else
	$server_tpl = '';

$admin_tpl = panther_template('admin_statistics.tpl');
$search = array(
	'{server_statistics}' => $lang_admin_index['Server statistics head'],
	'{server_load}' => $lang_admin_index['Server load label'],
	'{load_data}' => sprintf($lang_admin_index['Server load data']."\n", $server_load, $num_online),
	'{admin_data}' => $server_tpl,
);

echo str_replace(array_keys($search), array_values($search), $admin_tpl);
require PANTHER_ROOT.'footer.php';