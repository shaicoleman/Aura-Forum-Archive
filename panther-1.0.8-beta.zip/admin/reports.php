<?php
/**
 * Copyright (C) 2015 Panther (https://www.pantherforum.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

// Tell header.php to use the admin template
define('PANTHER_ADMIN_CONSOLE', 1);

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/../');
	require PANTHER_ROOT.'include/common.php';
}
require PANTHER_ROOT.'include/common_admin.php';

if (($panther_user['is_admmod'] && $panther_user['g_mod_cp'] == '0' && !$panther_user['is_admin']) || !$panther_user['is_admmod'])
	message($lang_common['No permission'], false, '403 Forbidden');

check_authentication();

// Load the admin_reports.php language file
require PANTHER_ROOT.'lang/'.$admin_language.'/admin_reports.php';

// Zap a report
if (isset($_POST['zap_id']))
{
	confirm_referrer(PANTHER_ADMIN_DIR.'/reports.php');

	$zap_id = intval(key($_POST['zap_id']));
	$data = array(
		':id'	=>	$zap_id,
	);

	$ps = $db->select('reports', 'zapped', $data, 'id=:id');
	$zapped = $ps->fetchColumn();

	if ($zapped == '')
	{
		$update = array(
			'zapped'	=>	time(),
			'zapped_by'	=>	$panther_user['id'],
		);
		
		$data = array(
			':id'	=>	$zap_id
		);
		
		$db->update('reports', $update, 'id=:id', $data);
	}

	// Delete old reports (which cannot be viewed anyway)
	$ps = $db->select('reports', 'zapped', array(), 'zapped IS NOT NULL ORDER BY zapped DESC LIMIT 10, 1');
	if ($ps->rowCount())
	{
		$data = array(
			':zapped'	=>	$ps->fetchColumn(),
		);

		$db->delete('reports', 'zapped <= :zapped', $data);
	}

	redirect(get_link($panther_url['admin_reports']), $lang_admin_reports['Report zapped redirect']);
}

$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_admin_common['Admin'], $lang_admin_common['Reports']);
define('PANTHER_ACTIVE_PAGE', 'admin');
require PANTHER_ROOT.'header.php';

generate_admin_menu('reports');
$ps = $db->run('SELECT r.id, r.topic_id, r.forum_id, r.reported_by, r.created, r.message, p.id AS pid, t.subject, f.forum_name, u.username AS reporter FROM '.$db->prefix.'reports AS r LEFT JOIN '.$db->prefix.'posts AS p ON r.post_id=p.id LEFT JOIN '.$db->prefix.'topics AS t ON r.topic_id=t.id LEFT JOIN '.$db->prefix.'forums AS f ON r.forum_id=f.id LEFT JOIN '.$db->prefix.'users AS u ON r.reported_by=u.id WHERE r.zapped IS NULL ORDER BY created DESC');
if ($ps->rowCount())
{
	$reports = array();
	$report_tpl = panther_template('report_row.tpl');
	foreach ($ps as $cur_report)
	{
		$reporter = ($cur_report['reporter'] != '') ? '<a href="'.get_link($panther_url['profile'], array($cur_report['reported_by'], url_friendly($cur_report['reporter']))).'">'.panther_htmlspecialchars($cur_report['reporter']).'</a>' : $lang_admin_reports['Deleted user'];
		$forum = ($cur_report['forum_name'] != '') ? '<span><a href="'.get_link($panther_url['forum'], array($cur_report['forum_id'], url_friendly($cur_report['forum_name']))).'">'.panther_htmlspecialchars($cur_report['forum_name']).'</a></span>' : '<span>'.$lang_admin_reports['Deleted'].'</span>';
		$topic = ($cur_report['subject'] != '') ? '<span>»&#160;<a href="'.get_link($panther_url['topic'], array($cur_report['topic_id'], url_friendly($cur_report['subject']))).'">'.panther_htmlspecialchars($cur_report['subject']).'</a></span>' : '<span>»&#160;'.$lang_admin_reports['Deleted'].'</span>';
		$post = str_replace("\n", '<br />', panther_htmlspecialchars($cur_report['message']));
		$post_id = ($cur_report['pid'] != '') ? '<span>»&#160;<a href="'.get_link($panther_url['post'], array($cur_report['pid'])).'">'.sprintf($lang_admin_reports['Post ID'], $cur_report['pid']).'</a></span>' : '<span>»&#160;'.$lang_admin_reports['Deleted'].'</span>';
		$report_location = array($forum, $topic, $post_id);
		
		$search = array(
			'{report_subhead}' => sprintf($lang_admin_reports['Report subhead'], format_time($cur_report['created'])),
			'{reporter}' => sprintf($lang_admin_reports['Reported by'], $reporter),
			'{report_location}' => implode(' ', $report_location),
			'{reason}' => $lang_admin_reports['Reason'].'<div><input type="submit" name="zap_id['.$cur_report['id'].']" value="'.$lang_admin_reports['Zap'].'" />',
			'{post}' => $post,
		);

		$reports[] = str_replace(array_keys($search), array_values($search), $report_tpl);
	}

	$report_tpl = implode("\n", $reports);
}
else
{
	$report_tpl = panther_template('deleted_none.tpl');
	$search = array(
		'{none}' => $lang_admin_common['None'],
		'{no_new_posts}' => $lang_admin_reports['No new reports'] ,
	);

	$report_tpl = str_replace(array_keys($search), array_values($search), $report_tpl);
}

// Now get the zapped reports
$ps = $db->run('SELECT r.id, r.topic_id, r.forum_id, r.reported_by, r.message, r.zapped, r.zapped_by AS zapped_by_id, p.id AS pid, t.subject, f.forum_name, u.username AS reporter, u2.username AS zapped_by FROM '.$db->prefix.'reports AS r LEFT JOIN '.$db->prefix.'posts AS p ON r.post_id=p.id LEFT JOIN '.$db->prefix.'topics AS t ON r.topic_id=t.id LEFT JOIN '.$db->prefix.'forums AS f ON r.forum_id=f.id LEFT JOIN '.$db->prefix.'users AS u ON r.reported_by=u.id LEFT JOIN '.$db->prefix.'users AS u2 ON r.zapped_by=u2.id WHERE r.zapped IS NOT NULL ORDER BY zapped DESC LIMIT 10');
if ($ps->rowCount())
{
	$reports = array();
	$report_last_tpl = panther_template('report_row.tpl');
	foreach ($ps as $cur_report)
	{
		$reporter = ($cur_report['reporter'] != '') ? '<a href="'.get_link($panther_url['profile'], array($cur_report['reported_by'], url_friendly($cur_report['reporter']))).'">'.panther_htmlspecialchars($cur_report['reporter']).'</a>' : $lang_admin_reports['Deleted user'];
		$forum = ($cur_report['forum_name'] != '') ? '<span><a href="'.get_link($panther_url['forum'], array($cur_report['forum_id'], url_friendly($cur_report['forum_name']))).'">'.panther_htmlspecialchars($cur_report['forum_name']).'</a></span>' : '<span>'.$lang_admin_reports['Deleted'].'</span>';
		$topic = ($cur_report['subject'] != '') ? '<span>»&#160;<a href="'.get_link($panther_url['topic'], array($cur_report['topic_id'], url_friendly($cur_report['subject']))).'">'.panther_htmlspecialchars($cur_report['subject']).'</a></span>' : '<span>»&#160;'.$lang_admin_reports['Deleted'].'</span>';
		$post = str_replace("\n", '<br />', panther_htmlspecialchars($cur_report['message']));
		$post_id = ($cur_report['pid'] != '') ? '<span>»&#160;<a href="'.get_link($panther_url['post'], array($cur_report['pid'])).'">'.sprintf($lang_admin_reports['Post ID'], $cur_report['pid']).'</a></span>' : '<span>»&#160;'.$lang_admin_reports['Deleted'].'</span>';
		$zapped_by = ($cur_report['zapped_by'] != '') ? '<a href="'.get_link($panther_url['profile'], array($cur_report['zapped_by_id'])).'">'.panther_htmlspecialchars($cur_report['zapped_by']).'</a>' : $lang_admin_reports['NA'];
		$zapped_by = ($cur_report['zapped_by'] != '') ? '<strong>'.panther_htmlspecialchars($cur_report['zapped_by']).'</strong>' : $lang_admin_reports['NA'];
		$report_location = array($forum, $topic, $post_id);
		
		$search = array(
			'{report_subhead}' => sprintf($lang_admin_reports['Zapped subhead'], format_time($cur_report['zapped']), $zapped_by),
			'{reporter}' => sprintf($lang_admin_reports['Reported by'], $reporter),
			'{report_location}' => implode(' ', $report_location),
			'{reason}' => $lang_admin_reports['Reason'],
			'{post_id}' => $cur_report['id'],
			'{zap}' => $lang_admin_reports['Zap'],
			'{post}' => $post,
		);

		$reports[] = str_replace(array_keys($search), array_values($search), $report_last_tpl);
	}

	$report_last_tpl = implode("\n", $reports);
}
else
{
	$report_last_tpl = panther_template('deleted_none.tpl');
	$search = array(
		'{none}' => $lang_admin_common['None'],
		'{no_new_posts}' => $lang_admin_reports['No zapped reports'] ,
	);
	
	$report_last_tpl = str_replace(array_keys($search), array_values($search), $report_last_tpl);
}

$admin_tpl = panther_template('admin_reports.tpl');
$search = array(
	'{new_reports_head}' => $lang_admin_reports['New reports head'],
	'{form_action}' => get_link($panther_url['admin_reports_zap']),
	'{csrf_token}' => generate_csrf_token(PANTHER_ADMIN_DIR.'/reports.php'),
	'{reports}' => $report_tpl,
	'{last_ten_head}' => $lang_admin_reports['Last 10 head'],
	'{last_ten_reports}' => $report_last_tpl,
);

echo str_replace(array_keys($search), array_values($search), $admin_tpl);
require PANTHER_ROOT.'footer.php';