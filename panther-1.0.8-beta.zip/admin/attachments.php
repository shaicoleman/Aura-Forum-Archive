<?php
/**
 * Copyright (C) 2015 Panther (https://www.pantherforum.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

// Tell header.php to use the admin template
define('PANTHER_ADMIN_CONSOLE', 1);

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/../');
	require PANTHER_ROOT.'include/common.php';
}
require PANTHER_ROOT.'include/common_admin.php';

if (!$panther_user['is_admin'])
	message($lang_common['No permission'], false, '403 Forbidden');

if ($panther_user['id'] != '2')
{
	if(!is_null($admins[$panther_user['id']]['admin_attachments']))
	{
		if ($admins[$panther_user['id']]['admin_attachments'] == '0')
			message($lang_common['No permission'], false, '403 Forbidden');
	}
}

// Load the admin_attachments.php language file
require PANTHER_ROOT.'lang/'.$admin_language.'/admin_attachments.php';

check_authentication();

if ($panther_config['o_attachments'] == '0')
	message($lang_common['Bad request']);

$action = isset($_GET['action']) ? panther_htmlspecialchars($_GET['action']) : null;

if (isset($_POST['delete_attachment']))
{
	confirm_referrer(PANTHER_ADMIN_DIR.'/attachments.php');
	$id = intval(key($_POST['delete_attachment']));

	if (!delete_attachment($id))
		message($lang_admin_attachments['Unable to delete attachment']);

	redirect(get_link($panther_url['admin_attachments']), $lang_admin_attachments['Attachment del redirect']);
}
elseif (isset($_POST['delete_orphans']))
{

	$ps = $db->run('SELECT a.id FROM '.$db->prefix.'attachments AS a LEFT JOIN '.$db->prefix.'posts AS p ON p.id=a.post_id WHERE p.id IS NULL');
	if (!$ps->rowCount())
		message($lang_admin_attachments['No orphans']);

	$i = 0;
	$ps->setFetchMode(PDO::FETCH_COLUMN, 0);
	foreach ($ps as $attachment)
	{
		if (!delete_attachment($attachment))
			continue;
		else
			$i++;
	}

	message(sprintf($lang_admin_attachmetns['X orphans deleted'], array($i)));
}

$start = (isset($_POST['start'])) ? intval($_POST['start']) : 0;
$limit = (isset($_POST['number'])) ? intval($_POST['number']) : 50;
$increase = (isset($_POST['auto_increase']) && $_POST['auto_increase'] == '1') ? $start + $limit : $start;
$direction = (isset($_POST['direction']) && $_POST['direction'] == '1') ? 'ASC' : 'DESC';
$order = isset($_POST['order']) ? intval($_POST['order']) : 0;

switch ($order)
{
	case 1:
		$order = 'a.downloads';
		break;
	case 2:
		$order = 'a.size';
		break;
	case 3:
		$order = 'a.downloads*a.size';
		break;
	case 0:
	default:
		$order = 'a.id';
		break;
}

$data = array(
	':start'	=>	$start,
	':limit'	=>	$limit,
);

$ps = $db->run('SELECT a.id, a.owner, a.post_id, a.filename, a.extension, a.size, a.downloads, u.username, u.group_id FROM '.$db->prefix.'attachments AS a LEFT JOIN '.$db->prefix.'users AS u ON u.id=a.owner ORDER BY '.$order.' '.$direction.' LIMIT :start, :limit', $data);

$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_admin_common['Admin'], $lang_admin_common['Attachments']);
define('PANTHER_ACTIVE_PAGE', 'admin');
require PANTHER_ROOT.'header.php';

generate_admin_menu('attachments');
$attach_tpl = panther_template('admin_attachments.tpl');
$search = array(
	'{list_attachments}' => $lang_admin_attachments['List attachments'],
	'{form_action}' => get_link($panther_url['admin_attachments']),
	'{search_options}' => $lang_admin_attachments['Search options'],
	'{start_at}' => $lang_admin_attachments['Start at'],
	'{increase}' => $increase,
	'{auto_increase_lang}' => $lang_admin_attachments['Auto increase'],
	'{auto_increase}' => ($increase != $start) ? ' checked="checked"' : '',
	'{yes}' => $lang_admin_common['Yes'],
	'{no}' => $lang_admin_common['No'],
	'{no_auto_increase}' => ($increase == $start)? ' checked="checked"' : '',
	'{attachments}' => $lang_admin_attachments['Number of attachments'],
	'{limit}' => $limit,
	'{order}' => $lang_admin_attachments['Order'],
	'{order_checked}' => ($order == 'a.id') ? ' checked="checked"' : '',
	'{id}' => $lang_admin_attachments['ID'],
	'{downloads_checked}' => ($order == 'a.downloads') ? ' checked="checked"' : '',
	'{downloads}' => $lang_admin_attachments['Downloads'],
	'{size_checked}' => ($order == 'a.size') ? ' checked="checked"' : '',
	'{size}' => $lang_admin_attachments['Size'],
	'{transfer_checked}' => ($order == 'a.downloads*a.size') ? ' checked="checked"' : '',
	'{transfer}' => $lang_admin_attachments['Total transfer'],
	'{direction}' => $lang_admin_attachments['Direction'],
	'{direction_asc_checked}' => ($direction == 'ASC') ? ' checked="checked"' : '',
	'{ascending}' => $lang_admin_attachments['Ascending'],
	'{direction_desc_checked}' => ($direction == 'DESC') ? ' checked="checked"' : '',
	'{descending}' => $lang_admin_attachments['Descending'],
	'{list_attachments}' => $lang_admin_attachments['List Attachments'],
	'{delete_orphans}' => $lang_admin_attachments['Delete Orphans'],
	'{csrf_token}' => generate_csrf_token(PANTHER_ADMIN_DIR.'/bans.php'),
);

echo str_replace(array_keys($search), array_values($search), $attach_tpl);
if ($ps->rowCount())
{
	$attach_rows = array();
	$attach_row_tpl = panther_template('attachment_row.tpl');
	foreach ($ps as $cur_item)
	{
		$search = array(
			'{attach_icon}' => attach_icon($cur_item['extension']),
			'{attachment_link}' => get_link($panther_url['attachment'], array($cur_item['id'])),
			'{attachment_name}' => panther_htmlspecialchars($cur_item['filename']),
			'{owner}' => sprintf($lang_admin_attachments['By'], colourize_group($cur_item['username'], $cur_item['group_id'], $cur_item['owner'])),
			'{post_link}' => get_link($panther_url['post'], array($cur_item['post_id'])),
			'{post_number}' => $cur_item['post_id'],
			'{size}' => file_size($cur_item['size']),
			'{downloads}' => forum_number_format($cur_item['downloads']),
			'{transfer}' => file_size($cur_item['size'] * $cur_item['downloads']),
			'{attach_id}' => $cur_item['id'],
			'{delete}' => $lang_admin_common['Delete'],
		);

		$attach_rows[$cur_item['id']] = str_replace(array_keys($search), array_values($search), $attach_row_tpl);
	}

	$attach_tpl = panther_template('attachments.tpl');
	$search = array(
		'{attachment_list}' => $lang_admin_attachments['Attachment list'],
		'{attachments}' => $lang_admin_common['Attachments'],
		'{form_action}' => get_link($panther_url['admin_attachments']),
		'{filename}' => $lang_admin_attachments['Filename'],
		'{post_id}' => $lang_admin_attachments['Post ID'],
		'{filesize}' => $lang_admin_attachments['Filesize'],
		'{downloads}' => $lang_admin_attachments['Downloads'],
		'{total_transfer}' => $lang_admin_attachments['Total transfer'],
		'{delete}' => $lang_admin_common['Delete'],
		'{attachment_rows}' => count($attach_rows) ? implode("\n", $attach_rows) : '',
	);

	echo str_replace(array_keys($search), array_values($search), $attach_tpl);
}
?>
	<div class="clearer"></div>
<?php	
require PANTHER_ROOT.'footer.php';