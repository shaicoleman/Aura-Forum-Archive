<?php
/**
 * Copyright (C) 2015 Panther (https://www.pantherforum.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

// Tell header.php to use the admin template
define('PANTHER_ADMIN_CONSOLE', 1);

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/../');
	require PANTHER_ROOT.'include/common.php';
}
require PANTHER_ROOT.'include/common_admin.php';

if (!$panther_user['is_admin'])
	message($lang_common['No permission'], false, '403 Forbidden');

if ($panther_user['id'] != '2')
{
	if(!is_null($admins[$panther_user['id']]['admin_permissions']))
	{
		if ($admins[$panther_user['id']]['admin_permissions'] == '0')
			message($lang_common['No permission'], false, '403 Forbidden');
	}
}

check_authentication();

// Load the admin_permissions.php language file
require PANTHER_ROOT.'lang/'.$admin_language.'/admin_permissions.php';

if (isset($_POST['form_sent']))
{
	confirm_referrer(PANTHER_ADMIN_DIR.'/permissions.php');
	$form = array_map('intval', $_POST['form']);

	foreach ($form as $key => $input)
	{
		// Make sure the input is never a negative value
		if($input < 0)
			$input = 0;

		// Only update values that have changed
		if (array_key_exists('p_'.$key, $panther_config) && $panther_config['p_'.$key] != $input)
		{
			$update = array(
				'conf_value'	=>	$input,
			);
			
			$data = array(
				':conf_name'	=>	'p_'.$key,
			);
			
			$db->update('config', $update, 'conf_name=:conf_name', $data);
		}
	}

	// Regenerate the config cache
	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PANTHER_ROOT.'include/cache.php';

	generate_config_cache();
	redirect(get_link($panther_url['admin_permissions']), $lang_admin_permissions['Perms updated redirect']);
}

$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_admin_common['Admin'], $lang_admin_common['Permissions']);
define('PANTHER_ACTIVE_PAGE', 'admin');
require PANTHER_ROOT.'header.php';

generate_admin_menu('permissions');
$admin_tpl = panther_template('admin_permissions.tpl');
$search = array(
	'{permissions_head}' => $lang_admin_permissions['Permissions head'],
	'{form_action}' => get_link($panther_url['admin_permissions']),
	'{submit}' => $lang_admin_common['Save changes'],
	'{csrf_token}' => generate_csrf_token(PANTHER_ADMIN_DIR.'/permissions.php'),
	'{posting_subhead}' => $lang_admin_permissions['Posting subhead'],
	'{bbcode_label}' => $lang_admin_permissions['BBCode label'],
	'{message_bbcode_1_checked}' => ($panther_config['p_message_bbcode'] == '1') ? ' checked="checked"' : '',
	'{message_bbcode_0_checked}' => ($panther_config['p_message_bbcode'] == '0') ? ' checked="checked"' : '',
	'{yes}' => $lang_admin_common['Yes'],
	'{no}' => $lang_admin_common['No'],
	'{bbcode_help}' => $lang_admin_permissions['BBCode help'],
	'{image_tag_label}' => $lang_admin_permissions['Image tag label'],
	'{message_img_1_checked}' => ($panther_config['p_message_img_tag'] == '1') ? ' checked="checked"' : '',
	'{message_img_0_checked}' => ($panther_config['p_message_img_tag'] == '0') ? ' checked="checked"' : '',
	'{image_tag_help}' => $lang_admin_permissions['Image tag help'],
	'{message_caps_label}' => $lang_admin_permissions['All caps message label'],
	'{message_caps_1_checked}' => ($panther_config['p_message_all_caps'] == '1') ? ' checked="checked"' : '',
	'{message_caps_0_checked}' => ($panther_config['p_message_all_caps'] == '0') ? ' checked="checked"' : '',
	'{message_caps_help}' => $lang_admin_permissions['All caps message help'],
	'{subject_caps_label}' => $lang_admin_permissions['All caps subject label'],
	'{subject_caps_1_checked}' => ($panther_config['p_subject_all_caps'] == '1') ? ' checked="checked"' : '',
	'{subject_caps_0_checked}' => ($panther_config['p_subject_all_caps'] == '0') ? ' checked="checked"' : '',
	'{subject_caps_help}' => $lang_admin_permissions['All caps subject help'],
	'{require_email_label}' => $lang_admin_permissions['Require e-mail label'],
	'{require_email_1_checked}' => ($panther_config['p_force_guest_email'] == '1') ? ' checked="checked"' : '',
	'{require_email_0_checked}' => ($panther_config['p_force_guest_email'] == '0') ? ' checked="checked"' : '',
	'{require_email_help}' => $lang_admin_permissions['Require e-mail help'],
	'{signatures_subhead}' => $lang_admin_permissions['Signatures subhead'],
	'{bbcode_signature_label}' => $lang_admin_permissions['BBCode sigs label'],
	'{sig_bbcode_1_checked}' => ($panther_config['p_sig_bbcode'] == '1') ? ' checked="checked"' : '',
	'{sig_bbcode_0_checked}' => ($panther_config['p_sig_bbcode'] == '0') ? ' checked="checked"' : '',
	'{bbcode_sig_help}' => $lang_admin_permissions['BBCode sigs help'],
	'{img_signature_label}' => $lang_admin_permissions['Image tag sigs label'],
	'{sig_img_1_checked}' => ($panther_config['p_sig_img_tag'] == '1') ? ' checked="checked"' : '',
	'{sig_img_0_checked}' => ($panther_config['p_sig_img_tag'] == '0') ? ' checked="checked"' : '',
	'{img_sig_help}' => $lang_admin_permissions['Image tag sigs help'],
	'{caps_signature_label}' => $lang_admin_permissions['All caps sigs label'],
	'{sig_caps_1_checked}' => ($panther_config['p_sig_all_caps'] == '1') ? ' checked="checked"' : '',
	'{sig_caps_0_checked}' => ($panther_config['p_sig_all_caps'] == '0') ? ' checked="checked"' : '',
	'{all_caps_sig_help}' => $lang_admin_permissions['All caps sigs help'],
	'{max_sig_length_label}' => $lang_admin_permissions['Max sig length label'],
	'{signature_length}' => $panther_config['p_sig_length'],
	'{max_sig_length_help}' => $lang_admin_permissions['Max sig length help'],
	'{max_sig_lines_label}' => $lang_admin_permissions['Max sig lines label'],
	'{signature_lines}' => $panther_config['p_sig_lines'],
	'{max_sig_lines_help}' => $lang_admin_permissions['Max sig lines help'],
	'{registration_subhead}' => $lang_admin_permissions['Registration subhead'],
	'{banned_email_subhead}' => $lang_admin_permissions['Banned e-mail label'],
	'{allow_banned_1_checked}' => ($panther_config['p_allow_banned_email'] == '1') ? ' checked="checked"' : '',
	'{allow_banned_0_checked}' => ($panther_config['p_allow_banned_email'] == '0') ? ' checked="checked"' : '',
	'{banned_email_help}' => $lang_admin_permissions['Banned e-mail help'],
	'{duplicate_email_label}' => $lang_admin_permissions['Duplicate e-mail label'],
	'{allow_dupe_1_checked}' => ($panther_config['p_allow_dupe_email'] == '1') ? ' checked="checked"' : '',
	'{allow_dupe_0_checked}' => ($panther_config['p_allow_dupe_email'] == '0') ? ' checked="checked"' : '',
	'{duplicate_email_help}' => $lang_admin_permissions['Duplicate e-mail help'],
);

echo str_replace(array_keys($search), array_values($search), $admin_tpl);
require PANTHER_ROOT.'footer.php';