<?php
/**
 * Copyright (C) 2015 Panther (https://www.pantherforum.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

// Tell header.php to use the admin template
define('PANTHER_ADMIN_CONSOLE', 1);

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/../');
	require PANTHER_ROOT.'include/common.php';
}

require PANTHER_ROOT.'include/common_admin.php';

$action = isset($_GET['action']) ? panther_htmlspecialchars($_GET['action']) : null;
$id = isset($_GET['id']) ? intval($_GET['id']) : '0';
$page = (!isset($_GET['p']) || $_GET['p'] <= '1') ? '1' : intval($_GET['p']);

if (($panther_user['is_admmod'] && $panther_user['g_mod_cp'] == '0' && !$panther_user['is_admin']) || !$panther_user['is_admmod'])
	message($lang_common['No permission'], false, '403 Forbidden');

check_authentication();

// Load the admin_announcements.php language file
require PANTHER_ROOT.'lang/'.$admin_language.'/admin_announcements.php';

if (isset($_POST['form_sent']))
{
	confirm_referrer(PANTHER_ADMIN_DIR.'/announcements.php');
	$action = isset($_POST['action']) ? panther_trim($_POST['action']) : '';

	if ($action == 'add' || $action == 'edit')
	{
		$forums = isset($_POST['forums']) && is_array($_POST['forums']) ? array_map('intval', $_POST['forums']) : array();

		if (empty($forums))
			message($lang_common['Bad request']);

		$announcement = isset($_POST['message']) ? panther_trim($_POST['message']) : '';
		$title = isset($_POST['title']) ? panther_trim($_POST['title']) : '';
		$id = isset($_POST['id']) ? intval($_POST['id']) : 0;

		if (strlen($title) > 50)
			message($lang_admin_announcements['title too long']);

		if (strlen($announcement) < 1 || strlen($title) < 1)
			message($lang_common['Bad request']);

		$insert = array(
			'message'	=>	$announcement,
			'forum_id'	=>	implode(',', $forums),
			'user_id'	=>	$panther_user['id'],
			'subject'		=>	$title,
		);

		if ($action == 'add')
		{
			$db->insert('announcements', $insert);
			$id = $db->lastInsertId($db->prefix.'announcements');

			$redirect_msg = $lang_admin_announcements['added redirect'];
		}
		else
		{
			if ($id < 1)
				message($lang_common['Bad request']);

			$data = array(
				':id'	=>	$id,
			);
			
			$db->update('announcements', $insert, 'id=:id', $data);
			$redirect_msg = $lang_admin_announcements['edit redirect'];
		}

		if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
			require PANTHER_ROOT.'include/cache.php';

		generate_announcements_cache();
		redirect(get_link($panther_url['announcement_fid'], array($id, $forums[0], url_friendly($title))), $redirect_msg);
	}
	else if ($action == 'delete')
	{
		$id = isset($_POST['id']) ? intval($_POST['id']) : 0;
		if ($id < 1)
			message($lang_common['Bad request']);
		
		$data = array(
			':id'	=>	$id,
		);
		
		$db->delete('announcements', 'id=:id', $data);
		
		if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
			require PANTHER_ROOT.'include/cache.php';
		
		redirect(get_link($panther_url['admin_announcements']), $lang_admin_announcements['delete redirect']);
	}
	else
		message($lang_common['Bad request']);
}

$ps = $db->select('announcements', 'COUNT(id)');
$total = $ps->fetchColumn();
$num_pages = ceil($total/$panther_config['o_disp_topics_default']);
if ($page > $num_pages) $page = 1;
$start_from = intval($panther_config['o_disp_topics_default'])*($page-1);

$data = array(
	':start'	=>	$start_from,
	':limit'	=>	$panther_config['o_disp_topics_default'],
);

$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_admin_common['Admin'], $lang_admin_common['Announcements']);
define('PANTHER_ACTIVE_PAGE', 'admin');
require PANTHER_ROOT.'header.php';

generate_admin_menu('announcements');

if ($action == 'add' || $action == 'edit' && $id > 0)
{
	if ($action == 'edit')
	{
		$data = array(
			':id'	=>	$id,
		);

		$ps = $db->select('announcements', 'message, forum_id, subject', $data, 'id=:id');
		if (!$ps->rowCount())
			message($lang_common['Bad request']);

		$cur_announcement = $ps->fetch();
	}
	else
	{
		$cur_announcement = array(
			'forum_id'	=>	0,
			'subject'		=>	'',
			'message'	=>	'',
		);
	}

	// Display all the categories and forums
	$select = '';
	$ps = $db->run('SELECT c.id AS cid, c.cat_name, f.id AS fid, f.forum_name FROM '.$db->prefix.'categories AS c INNER JOIN '.$db->prefix.'forums AS f ON c.id=f.cat_id WHERE f.redirect_url IS NULL ORDER BY c.disp_position, c.id, f.disp_position');
	if ($ps->rowCount())
	{
		$count = 0;
		$cur_index = 4;
		$cur_category = 0;
		foreach ($ps as $cur_forum)
		{
			if ($cur_forum['cid'] != $cur_category) // A new category since last iteration?
			{
				$select .= '</optgroup>';
				$select .= "\t\t\t\t\t\t".'<optgroup label="'.panther_htmlspecialchars($cur_forum['cat_name']).'">'."\n";
				$cur_category = $cur_forum['cid'];
			}
				$select .= '<option value="'.$cur_forum['fid'].'"'.((in_array($cur_forum['fid'], explode(',', $cur_announcement['forum_id']))) ? ' selected="selected"' : null).'>'.panther_htmlspecialchars($cur_forum['forum_name']).'</option>'."\n";
		}
			$select .= "\t\t\t\t\t\t".'</optgroup>'."\n\t\t\t\t\t".'</select>'."\n";
	}
	
	$announce_tpl = panther_template('edit_announcement.tpl');
	$search = array(
		'{announcements_head}' => $lang_admin_announcements['announcements'],
		'{form_action}' => get_link($panther_url['admin_announcements']),
		'{csrf_token}' => generate_csrf_token(PANTHER_ADMIN_DIR.'/announcements.php'),
		'{action}' => $action,
		'{id_field}' => ($action == 'edit') ? "\n\t\t\t\t".'<input name="id" type="hidden" value="'.$id.'" />' : '',
		'{announce_legend}' => $lang_admin_announcements['announcements header'],
		'{title}' => $lang_admin_announcements['title'],
		'{subject}' => panther_htmlspecialchars($cur_announcement['subject']),
		'{title_help}' => $lang_admin_announcements['title help'],
		'{forum}' => $lang_admin_announcements['forum'],
		'{all_forums_selected}' => ($cur_announcement['forum_id'] == '0') ? ' selected="selected"' : '',
		'{all_forums}' => $lang_admin_announcements['all forums'],
		'{forum_options}' => $select,
		'{forum_help}' => $lang_admin_announcements['forum help'],
		'{announcement}' => $lang_admin_announcements['announcement'],
		'{message}' => panther_htmlspecialchars($cur_announcement['message']),
		'{announcement_help}' => sprintf($lang_admin_announcements['announcement help'], get_link($panther_url['help'], array('bbcode'))),
		'{submit}' => $lang_common['Submit'],
	);

	echo str_replace(array_keys($search), array_values($search), $announce_tpl);
}
elseif ($action == 'delete' && $id > 0)
{
	$announce_tpl = panther_template('del_announcement.tpl');
	$search = array(
		'{announcements_head}' => $lang_admin_announcements['announcements'],
		'{form_action}' => get_link($panther_url['delete_announcement']),
		'{csrf_token}' => generate_csrf_token(PANTHER_ADMIN_DIR.'/announcements.php'),
		'{id}' => $id,
		'{del_announcement}' => $lang_admin_announcements['delete announcement'],
		'{delete}' => $lang_admin_common['Delete'],
		'{go_back}' => $lang_common['Go back'],
	);

	echo str_replace(array_keys($search), array_values($search), $announce_tpl);
}
else
{
	$announcements = array();
	$announce_row_tpl = panther_template('admin_announcements_row.tpl');
	$ps = $db->run('SELECT a.subject, a.forum_id, a.user_id, u.username, u.group_id, a.id FROM '.$db->prefix.'announcements AS a INNER JOIN '.$db->prefix.'users AS u ON a.user_id=u.id ORDER BY a.id DESC LIMIT :start, :limit', $data);
	foreach ($ps as $announcement)
	{
		$forum_names = array();
		$ids = explode(',', $announcement['forum_id']);
		foreach ($ids as $id)
		{
			$data = array(
				':id'	=>	$id,
			);

			$ps1 = $db->select('forums', 'forum_name', $data, 'id=:id');
			$forum_names[] = $ps1->fetchColumn();
		}
		
		$search = array(
			'{edit_link}' => get_link($panther_url['edit_announcement'], array($announcement['id'])),
			'{edit_lang}' => $lang_admin_announcements['edit announcement'],
			'{del_link}' => get_link($panther_url['delete_announcement'], array($announcement['id'])),
			'{del_lang}' => $lang_admin_announcements['delete announcement 2'],
			'{announcement_name}' => panther_htmlspecialchars($announcement['subject']),
			'{poster}' => sprintf($lang_admin_announcements['by'], colourize_group($announcement['username'], $announcement['group_id'], $announcement['user_id'])),
		);
		
		$announcements[] = str_replace(array_keys($search), array_values($search), $announce_row_tpl);
	}

	$announce_tpl = panther_template('admin_announcements.tpl');
	$search = array(
		'{announcements}' => $lang_admin_announcements['announcements'],
		'{pagination}' => $lang_common['Pages'].' '.paginate($num_pages, $page, $panther_url['admin_announcements']),
		'{title}' => $lang_admin_announcements['title'],
		'{add_announcement}' => get_link($panther_url['add_announcement']),
		'{add_new}' => $lang_admin_announcements['add new'],
		'{add_new_label}' => $lang_admin_announcements['add new label'],
		'{announcement_rows}' => implode("\n", $announcements),
	);

	echo str_replace(array_keys($search), array_values($search), $announce_tpl);
}

require PANTHER_ROOT.'footer.php';