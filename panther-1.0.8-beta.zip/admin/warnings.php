<?php
/**
 * Copyright (C) 2015 Panther (https://www.pantherforum.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
// Tell header.php to use the admin template
define('PANTHER_ADMIN_CONSOLE', 1);

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/../');
	require PANTHER_ROOT.'include/common.php';
}

require PANTHER_ROOT.'include/common_admin.php';

if (!$panther_user['is_admin'])
	message($lang_common['No permission'], false, '403 Forbidden');

if ($panther_user['id'] != '2')
{
	if(!is_null($admins[$panther_user['id']]['admin_warnings']))
	{
		if ($admins[$panther_user['id']]['admin_warnings'] == '0')
			message($lang_common['No permission'], false, '403 Forbidden');
	}
}

check_authentication();

// Load the admin_warnings.php language file
require PANTHER_ROOT.'lang/'.$admin_language.'/admin_warnings.php';

if ($panther_user['g_read_board'] == '0')
	message($lang_common['No view'], false, '403 Forbidden');

if ($panther_config['o_warnings'] == '0')
	message($lang_warnings['Warnings disabled']);

if (isset($_POST['form_sent']))
{
	confirm_referrer(PANTHER_ADMIN_DIR.'/warnings.php');
	$action = isset($_POST['action']) ? panther_trim($_POST['action']) : '';
	$id = isset($_POST['id']) ? intval($_POST['id']) : 0;
	
	if ($action == '')
		message($lang_common['Bad request']);

	if ($action == 'types')
	{
		if (empty($_POST['warning_title']))
			message($lang_warnings['No title']);

		// Determine expiration time
		$expiration_time  = get_expiration_time($_POST['expiration_time'], $_POST['expiration_unit']);
		
		$warning_title = isset($_POST['warning_title']) ? panther_trim($_POST['warning_title']) : '';
		$warning_description = isset($_POST['warning_description']) ? panther_trim($_POST['warning_description']) : '';
		$points = isset($_POST['warning_points']) ? intval($_POST['warning_points']) : 0;

		if (strlen($warning_title) < 1)
			message($lang_warnings['No title']);
		else if (strlen($warning_title) > 70)
			message($lang_warnings['Title too long']);

		if ($warning_description == '')
			message($lang_warnings['Must enter descripiton']);
		else if (panther_strlen($warning_description) > PANTHER_MAX_POSTSIZE)
			message(sprintf($lang_warnings['Must enter descripiton'], forum_number_format(PANTHER_MAX_POSTSIZE)));
			
		$update = array(
			'title'	=>	$warning_title,
			'description'	=>	$warning_description,
			'points'	=>	$points,
			'expiration_time'	=>	$expiration_time,
		);

		if (isset($_POST['id']) && $id > 0) // Then we're editing
		{
			$data = array(
				':id'	=>	$id,
			);

			$ps = $db->select('warning_types', 'id, title, description, points, expiration_time', $data, 'id=:id');
			if ($ps->rowCount())
			{
				$warning_type = $ps->fetch();
				$data = array(
					':id'	=>	$warning_type['id'],
				);
				
				$db->update('warning_types', $update, 'id=:id', $data);
				$redirect_msg = $lang_warnings['Type updated redirect'];
			}
		}
		else // We're adding a new type
		{
			$db->insert('warning_types', $update);
			$redirect_msg = $lang_warnings['Type added redirect'];
		}
	}
	else // We're adding/editing warning levels
	{
		$warning_title = isset($_POST['warning_title']) ? panther_trim($_POST['warning_title']) : '';
		$warning_points = isset($_POST['warning_points']) ? intval($_POST['warning_points']) : 0;

		if ($warning_title == '')
			message($lang_warnings['No title']);

		// Determine expiration time
		$expiration_time  = get_expiration_time($_POST['expiration_time'], $_POST['expiration_unit']);

		$update = array(
			'points'	=>	$warning_points,
			'message'	=>	$warning_title,
			'period'	=>	$expiration_time,
		);

		if (isset($_POST['id']) && $id > 0)
		{
			$data = array(
				':id'	=>	$id,
			);

			$db->update('warning_levels', $update, 'id=:id', $data);
			$redirect_msg = $lang_warnings['Level update redirect'];
		}
		else
		{
			$db->insert('warning_levels', $update);
			$redirect_msg = $lang_warnings['Level added redirect'];
		}
	}

	redirect(get_link($panther_url['admin_warnings']), $redirect_msg);
}

$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_admin_common['Admin'], $lang_admin_common['Warnings']);
define('PANTHER_ACTIVE_PAGE', 'admin');
require PANTHER_ROOT.'header.php';

if (isset($_POST['add_type']))
{
	generate_admin_menu('warnings');
	$admin_tpl = panther_template('add_warning_type.tpl');
	$search = array(
		'{add_type_label}' => $lang_warnings['Add new type label'],
		'{form_action}' => get_link($panther_url['admin_warnings']),
		'{add_new}' => $lang_warnings['Add New'],
		'{type_details}' => $lang_warnings['Type details'],
		'{csrf_token}' => generate_csrf_token(PANTHER_ADMIN_DIR.'/warnings.php'),
		'{warning_title}' => $lang_warnings['Warning title'],
		'{points}' => $lang_warnings['Points'],
		'{expiration}' => $lang_warnings['Expiration'],
		'{hours}' => $lang_warnings['Hours'],
		'{days}' => $lang_warnings['Days'],
		'{months}' => $lang_warnings['Months'],
		'{never}' => $lang_warnings['Never'],
		'{description}' => $lang_warnings['Description'],
	);
	
	echo str_replace(array_keys($search), array_values($search), $admin_tpl);
}
else if (isset($_GET['edit_type']))
{
	$id = isset($_GET['edit_type']) ? intval($_GET['edit_type']) : 0;
	if ($id < 1)
		message($lang_common['Bad request']);
	
	$data = array(
		':id'	=>	$id,
	);

	// Get information of the warning
	$ps = $db->select('warning_types', 'id, title, description, points, expiration_time', $data, 'id=:id');
	if (!$ps->rowCount())
		message($lang_common['Bad request']);
		
	$warning_type = $ps->fetch();
		
	// Get expiration time and unit
	$expiration = explode(' ', format_expiration_time($warning_type['expiration_time']));
	if ($expiration[0] == 'Never')
	{
		$expiration[0] = '';
		$expiration[1] = 'Never';
	}

	generate_admin_menu('warnings');
	$admin_tpl = panther_template('edit_warning_type.tpl');
	$search = array(
		'{warning_type}' => $lang_warnings['Edit warning type'],
		'{form_action}' => get_link($panther_url['admin_warnings']),
		'{save}' => $lang_warnings['Save changes'],
		'{warning_type_details}' => $lang_warnings['Warning type details'],
		'{warning_id}' => $warning_type['id'],
		'{csrf_token}' => generate_csrf_token(PANTHER_ADMIN_DIR.'/warnings.php'),
		'{warning_title}' => $lang_warnings['Warning title'],
		'{title_value}' => panther_htmlspecialchars($warning_type['title']),
		'{points}' => $lang_warnings['Points'],
		'{points_value}' => panther_htmlspecialchars($warning_type['points']),
		'{expiration}' => $lang_warnings['Expiration'],
		'{expiration_value}' => panther_htmlspecialchars($expiration[0]),
		'{hours}' => $lang_warnings['Hours'],
		'{days}' => $lang_warnings['Days'],
		'{months}' => $lang_warnings['Months'],
		'{never}' => $lang_warnings['Never'],
		'{hours_checked}' => ($expiration[1] == 'hours') ? ' selected="selected"' : '',
		'{days_checked}' => ($expiration[1] == 'days') ? ' selected="selected"' : '',
		'{months_checked}' => ($expiration[1] == 'months') ? ' selected="selected"' : '',
		'{never_checked}' => ($expiration[1] == 'never') ? ' selected="selected"' : '',
		'{description}' => $lang_warnings['Description'],
		'{description_value}' => panther_htmlspecialchars($warning_type['description']),
	);
	
	echo str_replace(array_keys($search), array_values($search), $admin_tpl);
}
elseif (isset($_GET['del_type']))
{
	$id = isset($_GET['del_type']) ? intval($_GET['del_type']) : 0;
	if ($id < 1)
		message($lang_common['Bad request']);

	if (isset($_POST['del_type_comply']))
	{
		confirm_referrer(PANTHER_ADMIN_DIR.'/warnings.php');
		$data = array(
			':id'	=>	$id,
		);
		
		// Delete the warning type
		$db->delete('warning_types', 'id=:id', $data);
		redirect(get_link($panther_url['admin_warnings']), $lang_warnings['Type delete redirect']);
	}
	else	// If the user hasn't confirmed the delete
	{
		$data = array(
			':id'	=>	$id,
		);

		$ps = $db->select('warning_types', 'title', $data, 'id=:id');
		if (!$ps->rowCount())
			message($lang_common['Bad resuqest']);
		
		$warning_type = panther_htmlspecialchars($ps->fetchColumn());
		generate_admin_menu('warnings');
		$admin_tpl = panther_template('del_warning_type.tpl');
		$search = array(
			'{del_type}' => $lang_warnings['Confirm delete type'],
			'{form_action}' => get_link($panther_url['warning_del_type'], array($id)),
			'{csrf_token}' => generate_csrf_token(PANTHER_ADMIN_DIR.'/warnings.php'),
			'{important_information}' => $lang_warnings['Important Information'],
			'{confirm_delete}' => sprintf($lang_warnings['Del type confirm'], $warning_type),
			'{del_type_info}' => $lang_warnings['Del warning type'],
			'{delete}' => $lang_warnings['Delete'],
			'{go_back}' => $lang_common['Go back'],
		);
		
		echo str_replace(array_keys($search), array_values($search), $admin_tpl);
	}
}
else if (isset($_POST['add_level']))
{
	generate_admin_menu('warnings');
	$admin_tpl = panther_template('add_warning_level.tpl');
	$search = array(
		'{add_level_label}' => $lang_warnings['Add new level label'],
		'{form_action}' => get_link($panther_url['admin_warnings']),
		'{add_new}' => $lang_warnings['Add New'],
		'{csrf_token}' => generate_csrf_token(PANTHER_ADMIN_DIR.'/warnings.php'),
		'{warning_level_details}' => $lang_warnings['Warning level details'],
		'{ban_message}' => $lang_warnings['Ban message'],
		'{ban_message_help}' => $lang_warnings['Ban message help'],
		'{points}' => $lang_warnings['Points'],
		'{ban_points_help}' => $lang_warnings['Ban points help'],
		'{ban_duration}' => $lang_warnings['Ban duration'],
		'{hours}' => $lang_warnings['Hours'],
		'{days}' => $lang_warnings['Days'],
		'{months}' => $lang_warnings['Months'],
		'{never}' => $lang_warnings['Permanent'],
	);

	echo str_replace(array_keys($search), array_values($search), $admin_tpl);
}
else if (isset($_GET['edit_level']))
{
	$id = isset($_GET['edit_level']) ? intval($_GET['edit_level']) : 0;

	$data = array(
		':id'	=>	$id,
	);

	// Fetch warning information
	$ps = $db->select('warning_levels', 'id, points, message, period', $data, 'id=:id');
	if (!$ps->rowCount())
		message($lang_common['Bad request']);

	$warning_level = $ps->fetch();
	generate_admin_menu('warnings');

	// Get expiration time and unit
	$expiration = explode(' ', format_expiration_time($warning_level['period']));
	if ($expiration[0] == 'Never')
	{
		$expiration[0] = '';
		$expiration[1] = 'Never';
	}

	$admin_tpl = panther_template('edit_warning_level.tpl');
	$search = array(
		'{edit_level_label}' => $lang_warnings['Edit warning level'],
		'{form_action}' => get_link($panther_url['admin_warnings']),
		'{save_changes}' => $lang_warnings['Save changes'],
		'{csrf_token}' => generate_csrf_token(PANTHER_ADMIN_DIR.'/warnings.php'),
		'{warning_level_details}' => $lang_warnings['Warning level details'],
		'{warning_id}' => $warning_level['id'],
		'{ban_message}' => $lang_warnings['Ban message'],
		'{ban_message_value}' => panther_htmlspecialchars($warning_level['message']),
		'{ban_message_help}' => $lang_warnings['Ban message help'],
		'{points}' => $lang_warnings['Points'],
		'{points_value}' => panther_htmlspecialchars($warning_level['points']),
		'{ban_points_help}' => $lang_warnings['Ban points help'],
		'{ban_duration}' => $lang_warnings['Ban duration'],
		'{expiration_value}' => panther_htmlspecialchars($expiration[0]),
		'{hours}' => $lang_warnings['Hours'],
		'{days}' => $lang_warnings['Days'],
		'{months}' => $lang_warnings['Months'],
		'{never}' => $lang_warnings['Permanent'],
		'{hours_checked}' => ($expiration[1] == 'hours') ? ' selected="selected"' : '',
		'{days_checked}' => ($expiration[1] == 'days') ? ' selected="selected"' : '',
		'{months_checked}' => ($expiration[1] == 'months') ? ' selected="selected"' : '',
		'{never_checked}' => ($expiration[1] == 'never') ? ' selected="selected"' : '',
	);

	echo str_replace(array_keys($search), array_values($search), $admin_tpl);
}
else if (isset($_GET['del_level']))
{
	$id = isset($_GET['del_level']) ? intval($_GET['del_level']) : 0;
	if ($id < 1)
		message($lang_common['Bad request']);

	if (isset($_POST['del_level_comply']))
	{
		confirm_referrer(PANTHER_ADMIN_DIR.'/warnings.php');
		$data = array(
			':id'	=>	$id,
		);

		// Delete the warning level
		$db->delete('warning_levels', 'id=:id', $data);
		redirect(get_link($panther_url['admin_warnings']), $lang_warnings['Level del redirect']);
	}

	generate_admin_menu('warnings');
	$admin_tpl = panther_template('del_warning_level.tpl');
	$search = array(
		'{confirm_delete}' => $lang_warnings['Confirm delete level'],
		'{form_action}' => get_link($panther_url['warning_del_level'], array($id)),
		'{csrf_token}' => generate_csrf_token(PANTHER_ADMIN_DIR.'/warnings.php'),
		'{important_informatoin}' => $lang_warnings['Important Information'],
		'{delete_level}' => $lang_warnings['Delete level'],
		'{delete}' => $lang_warnings['Delete'],
		'{go_back}' => $lang_common['Go back'],
	);
	
	echo str_replace(array_keys($search), array_values($search), $admin_tpl);
}
else
{
	$ps = $db->select('warning_types', 'id, title, description, points, expiration_time', array(), '', 'points, id');
	$ps1 = $db->select('warning_levels', 'id, points, period', array(), '', 'points, id');
	
	$types = $levels = array();
	$row_tpl = panther_template('admin_warnings_row.tpl');
	foreach ($ps as $list_types)
	{
		$expiration = explode(' ', format_expiration_time($list_types['expiration_time']));
		if ($expiration[0] == $lang_warnings['Never'])
		{
			$expiration[0] = '';
			$expiration[1] = $lang_warnings['Never'];
		}
		
		$search = array(
			'{edit_link}' => get_link($panther_url['warning_edit_type'], array($list_types['id'])),
			'{edit}' => $lang_warnings['Edit'],
			'{del_link}' => get_link($panther_url['warning_del_type'], array($list_types['id'])),
			'{delete}' => $lang_warnings['Delete'],
			'{amount}' => sprintf($lang_warnings['Points 2'], $list_types['points']),
			'{title}' => panther_htmlspecialchars($list_types['title']),
			'{expires}' => sprintf($lang_warnings['Expires after x'], $expiration[0], $expiration[1]),
		);

		$types[] = str_replace(array_keys($search), array_values($search), $row_tpl);
	}

	foreach ($ps1 as $list_levels)
	{
		if ($list_levels['period'] == '0')
			$ban_title = $lang_warnings['Permanent ban'];
		else
		{
			$expiration = explode(' ', format_expiration_time($list_levels['period']));
			if ($expiration[0] == $lang_warnings['Never'])
			{
				$expiration[0] = '';
				$expiration[1] = $lang_warnings['Never'];
			}
			$ban_title = sprintf($lang_warnings['Temporary ban'], $expiration[0], $expiration[1]);
		}
		
		$search = array(
			'{edit_link}' => get_link($panther_url['warning_edit_level'], array($list_levels['id'])),
			'{edit}' => $lang_warnings['Edit'],
			'{del_link}' => get_link($panther_url['warning_del_level'], array($list_levels['id'])),
			'{delete}' => $lang_warnings['Delete'],
			'{amount}' => sprintf($lang_warnings['Points 2'], $list_levels['points']),
			'{title}' => $ban_title,
			'{expires}' => '',
		);

		$levels[] = str_replace(array_keys($search), array_values($search), $row_tpl);
	}

	// Display the admin navigation menu
	generate_admin_menu('warnings');
	$admin_tpl = panther_template('admin_warnings.tpl');
	$search = array(
		'{warning_types_label}' => $lang_warnings['Warning types'],
		'{form_action}' => get_link($panther_url['admin_warnings']),
		'{modify_warning_types}' => $lang_warnings['Modify warning types'],
		'{warning_types}' => count($types) ? implode("\n", $types) : '',
		'{add}' => $lang_warnings['Add'],
		'{warning_levels_label}' => $lang_warnings['Warning levels'],
		'{modify_warning_levels}' => $lang_warnings['Modify warning levels'],
		'{warning_levels}' => count($levels) ? implode("\n", $levels) : '',
	);

	echo str_replace(array_keys($search), array_values($search), $admin_tpl);
}

require PANTHER_ROOT.'footer.php';