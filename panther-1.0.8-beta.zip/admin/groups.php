<?php
/**
 * Copyright (C) 2015 Panther (https://www.pantherforum.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

// Tell header.php to use the admin template
define('PANTHER_ADMIN_CONSOLE', 1);

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/../');
	require PANTHER_ROOT.'include/common.php';
}
require PANTHER_ROOT.'include/common_admin.php';

if (!$panther_user['is_admin'])
	message($lang_common['No permission'], false, '403 Forbidden');

if ($panther_user['id'] != '2')
{
	if(!is_null($admins[$panther_user['id']]['admin_permissions']))
	{
		if ($admins[$panther_user['id']]['admin_permissions'] == '0')
			message($lang_common['No permission'], false, '403 Forbidden');
	}
}

check_authentication();

// Load the admin_censoring.php language file
require PANTHER_ROOT.'lang/'.$admin_language.'/admin_groups.php';

// Fetch all groups
$groups = array();
foreach ($panther_groups as $cur_group)
	$groups[$cur_group['g_id']] = $cur_group;
	
$action = isset($_GET['action']) ? $_GET['action'] : null;
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($action == 'upload_image')
{
	if (!isset($panther_groups[$id]))
		message($lang_common['Bad request']);

	$image_path = ($panther_config['o_image_group_dir'] != '') ? $panther_config['o_image_group_path'] : PANTHER_ROOT.$panther_config['o_image_group_path'].'/';

	if (isset($_POST['form_sent']))
	{
		if (!isset($_FILES['req_file']))
			message($lang_admin_groups['No file']);

		$uploaded_file = $_FILES['req_file'];

		// Make sure the upload went smooth
		if (isset($uploaded_file['error']))
		{
			switch ($uploaded_file['error'])
			{
				case 1:	// UPLOAD_ERR_INI_SIZE
				case 2:	// UPLOAD_ERR_FORM_SIZE
					message($lang_admin_groups['Too large ini']);
					break;

				case 3:	// UPLOAD_ERR_PARTIAL
					message($lang_admin_groups['Partial upload']);
					break;

				case 4:	// UPLOAD_ERR_NO_FILE
					message($lang_admin_groups['No file']);
					break;

				case 6:	// UPLOAD_ERR_NO_TMP_DIR
					message($lang_admin_groups['No tmp directory']);
					break;

				default:
					// No error occured, but was something actually uploaded?
					if ($uploaded_file['size'] == 0)
						message($lang_admin_groups['No file']);
					break;
			}
		}

		if (is_uploaded_file($uploaded_file['tmp_name']))
		{
			$allowed_types = array('image/gif', 'image/jpeg', 'image/pjpeg', 'image/png', 'image/x-png');
			if (!in_array($uploaded_file['type'], $allowed_types))
				message($lang_admin_groups['Bad type']);

			// Make sure the file isn't too big
			if ($uploaded_file['size'] > $panther_config['o_image_group_size'])
				message($lang_admin_groups['Too large'].' '.$panther_config['o_image_group_size'].' '.$lang_admin_groups['bytes'].'.');

			// Determine type
			switch($uploaded_file['type'])
			{
				case 'image/gif':
					$type = 'gif';
					break;
				case 'image/jpeg':
				case 'image/pjpeg':
					$type = 'jpg';
					break;
				default:
					$type = 'png';
					break;
			}

			// Move the file to the image directory. We do this before checking the width/height to circumvent open_basedir restrictions.
			if (!@move_uploaded_file($uploaded_file['tmp_name'], $image_path.$id.'.tmp'))
				message(sprintf($lang_admin_groups['Move failed'], ' <a href="mailto:'.$panther_config['o_admin_email'].'">'.$panther_config['o_admin_email'].'</a>.'));

			// Now check the width/height
			list($width, $height, $file_type,) = getimagesize($image_path.$id.'.tmp');
			if (empty($width) || empty($height) || $width > $panther_config['o_image_group_width'] || $height > $panther_config['o_image_group_height'])
			{
				@unlink($image_path.$id.'.tmp');
				message(sprintf($lang_admin_groups['Too wide or high'], $panther_config['o_image_group_width'], $panther_config['o_image_group_height']));
			}
			else if ($file_type == 1 && $uploaded_file['type'] != 'image/gif')	// Prevent dodgy uploads
			{
				@unlink($image_path.$id.'.tmp');
				message($lang_admin_groups['Bad type']);
			}

			// Delete the old image (if it exists) and put the new one in place
			if ($panther_groups[$id]['g_image'] != '')
				@unlink($image_path.$id.'.'.$panther_groups[$id]['g_image']);

			@rename($image_path.$id.'.tmp', $image_path.$id.'.'.$type);
			compress_image($image_path.$id.'.'.$type);
			@chmod($image_path.$id.'.'.$type, 0644);

			$update = array(
				'g_image'	=>	$type,
			);

			$data = array(
				':id'	=>	$id,
			);

			$db->update('groups', $update, 'g_id=:id', $data);
		}
		else
			message($lang_admin_image_group['Unknown failure']);

		if (!defined('FORUM_CACHE_FUNCITONS_LOADED'))
			require PANTHER_ROOT.'include/cache.php';
	
		generate_groups_cache();
		redirect(get_link($panther_url['admin_groups']), $lang_admin_groups['Image upload redirect']);
	}

	$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_admin_common['Admin'], $lang_admin_common['User groups']);
	$required_fields = array('req_file' => $lang_admin_groups['File']);
	$focus_element = array('upload_image', 'req_file');
	define('PANTHER_ACTIVE_PAGE', 'admin');
	require PANTHER_ROOT.'header.php';
	generate_admin_menu('groups');
	
	$group_tpl = panther_template('upload_group_image.tpl');
	$search = array(
		'{upload_image}' => $lang_admin_groups['Upload image'],
		'{form_action}' => get_link($panther_url['upload_image'], array($id)),
		'{upload_legend}' => $lang_admin_groups['Upload image legend'],
		'{max_size}' => $panther_config['o_image_group_size'],
		'{file}' => $lang_admin_groups['File'],
		'{upload_info}' => sprintf($lang_admin_groups['Image desc'], $panther_config['o_image_group_width'], $panther_config['o_image_group_height'], sprintf($panther_config['o_image_group_size'], $lang_common['Size unit B']), sprintf(ceil($panther_config['o_image_group_size'] / 1024), $lang_common['Size unit KiB'])),
		'{upload}' => $lang_admin_groups['Upload'],
		'{go_back}' => $lang_common['Go back'],
	);
	
	echo str_replace(array_keys($search), array_values($search), $group_tpl);
	require PANTHER_ROOT.'footer.php';
}
else if ($action == 'delete_image')
{
	if (!isset($panther_groups[$id]) || $id < 1)
		message($lang_common['Bad request']);

	if ($panther_groups[$id]['g_image'] == '')
		message($lang_common['Bad request']);

	$image_path = ($panther_config['o_image_group_dir'] != '') ? $panther_config['o_image_group_path'] : PANTHER_ROOT.$panther_config['o_image_group_path'].'/';
	@unlink($image_path.$id.'.'.$panther_groups[$id]['g_image']);

	$update = array(
		'g_image'	=>	'',
	);

	$data = array(
		':id'	=>	$id,
	);

	$db->update('groups', $update, 'g_id=:id', $data);
	
	if (!defined('FORUM_CACHE_FUNCITONS_LOADED'))
		require PANTHER_ROOT.'include/cache.php';

	generate_groups_cache();
	redirect(get_link($panther_url['admin_groups']), $lang_admin_groups['Image deleted redirect']);
}

// Add/edit a group (stage 1)
if (isset($_POST['add_group']) || isset($_GET['edit_group']))
{
	if (isset($_POST['add_group']))
	{
		$base_group = intval($_POST['base_group']);
		$group = $groups[$base_group];

		$mode = 'add';
	}
	else // We are editing a group
	{
		$group_id = intval($_GET['edit_group']);
		if ($group_id < 1 || !isset($groups[$group_id]))
			message($lang_common['Bad request'], false, '404 Not Found');

		$group = $groups[$group_id];

		$mode = 'edit';
	}

	$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_admin_common['Admin'], $lang_admin_common['User groups']);
	$required_fields = array('req_title' => $lang_admin_groups['Group title label']);
	$focus_element = array('groups2', 'req_title');
	define('PANTHER_ACTIVE_PAGE', 'admin');
	require PANTHER_ROOT.'header.php';

	generate_admin_menu('groups');
	if ($group['g_id'] != PANTHER_ADMIN)
	{
		if ($group['g_id'] != PANTHER_GUEST)
		{
			$member_tpl = panther_template('edit_group_promotion.tpl');
			$group_options = array();
			foreach ($groups as $cur_group)
			{
				if (($cur_group['g_id'] != $group['g_id'] || $mode == 'add') && $cur_group['g_id'] != PANTHER_ADMIN && $group['g_admin'] != '1' && $cur_group['g_id'] != PANTHER_GUEST)
					$group_options[] = "\t\t\t\t\t\t\t\t\t\t\t".'<option value="'.$cur_group['g_id'].'" '.(($cur_group['g_id'] == $group['g_promote_next_group']) ? ' selected="selected"' : '').'>'.panther_htmlspecialchars($cur_group['g_title']).'</option>';
			}
			
			$search = array(
				'{promote_users_label}' => $lang_admin_groups['Promote users label'],
				'{disable_promotions}' => $lang_admin_groups['Disable promotion'],
				'{group_options}' => (count($group_options) ? implode("\n", $group_options) : ''),
				'{promote_posts_value}' => panther_htmlspecialchars($group['g_promote_min_posts']),
				'{promote_users_help}' => sprintf($lang_admin_groups['Promote users help'], $lang_admin_groups['Disable promotion']),
			);
			
			$member_tpl = str_replace(array_keys($search), array_values($search), $member_tpl)."\n";
			$attachment_tpl = panther_template('edit_group_attachments.tpl');
			$search = array(
				'{add_attachments_label}' => $lang_admin_groups['Add attachments label'],
				'{attach_files_1_checked}' => ($group['g_attach_files'] == '1') ? ' checked="checked"' : '',
				'{attach_files_0_checked}' => ($group['g_attach_files'] == '0') ? ' checked="checked"' : '',
				'{yes}' => $lang_admin_common['Yes'],
				'{no}' => $lang_admin_common['No'],
				'{add_attachments_help}' => $lang_admin_groups['Add attachments help'],
				'{max_attachments_label}' => $lang_admin_groups['Max attachments label'],
				'{max_attachments_value}' => $group['g_max_attachments'],
				'{max_attachments_help}' => $lang_admin_groups['Max attachments help'],
				'{max_size_label}' => $lang_admin_groups['Max size label'],
				'{max_size_value}' => $group['g_max_size'],
				'{max_size_help}' => $lang_admin_groups['Max size help'],
				'{edit_posts_label}' => $lang_admin_groups['Edit posts label'],
				'{edit_posts_1_checked}' => ($group['g_edit_posts'] == '1') ? ' checked="checked"' : '',
				'{edit_posts_0_checked}' => ($group['g_edit_posts'] == '0') ? ' checked="checked"' : '',
				'{edit_posts_help}' => $lang_admin_groups['Edit posts help'],
				'{edit_subject_label}' => $lang_admin_groups['Edit post subject label'],
				'{edit_subject_label}' => $lang_admin_groups['Edit post subject label'],
				'{edit_subject_1_checked}' => ($group['g_edit_subject'] == '1') ? ' checked="checked"' : '',
				'{edit_subject_0_checked}' => ($group['g_edit_subject'] == '0') ? ' checked="checked"' : '',
				'{edit_subject_help}' => $lang_admin_groups['Edit subject help'],
				'{delete_posts_label}' => $lang_admin_groups['Delete posts label'],
				'{delete_posts_1_checked}' => ($group['g_delete_posts'] == '1') ? ' checked="checked"' : '',
				'{delete_posts_0_checked}' => ($group['g_delete_posts'] == '0') ? ' checked="checked"' : '',
				'{delete_posts_help}' => $lang_admin_groups['Delete posts help'],
				'{deledit_label}' => $lang_admin_groups['Deledit flood label'],
				'{deledit_value}' => $group['g_deledit_interval'],
				'{deledit_help}' => $lang_admin_groups['Deledit flood help'],
				'{delete_topics_label}' => $lang_admin_groups['Delete topics label'],
				'{delete_topics_1_checked}' => ($group['g_delete_topics'] == '1') ? ' checked="checked"' : '',
				'{delete_topics_0_checked}' => ($group['g_delete_topics'] == '0') ? ' checked="checked"' : '',
				'{delete_topics_help}' => $lang_admin_groups['Delete topics help'],
			);
			
			$attachment_tpl = "\n".str_replace(array_keys($search), array_values($search), $attachment_tpl);
			$title_tpl = panther_template('edit_group_title.tpl');
			$search = array(
				'{set_title_label}' => $lang_admin_groups['Set own title label'],
				'{set_title_1_checked}' => ($group['g_set_title'] == '1') ? ' checked="checked"' : '',
				'{set_title_0_checked}' => ($group['g_set_title'] == '0') ? ' checked="checked"' : '',
				'{yes}' => $lang_admin_common['Yes'],
				'{no}' => $lang_admin_common['No'],
				'{set_title_help}' => $lang_admin_groups['Set own title help'],
			);
			
			$title_tpl = "\n".str_replace(array_keys($search), array_values($search), $title_tpl);
			$email_tpl = panther_template('edit_group_emails.tpl');
			$search = array(
				'{send_emails}' => $lang_admin_groups['Send e-mails label'],
				'{send_email_1_checked}' => ($group['g_send_email'] == '1') ? ' checked="checked"' : '',
				'{send_email_0_checked}' => ($group['g_send_email'] == '0') ? ' checked="checked"' : '',
				'{yes}' => $lang_admin_common['Yes'],
				'{no}' => $lang_admin_common['No'],
				'{send_emails_help}' => $lang_admin_groups['Send e-mails help'],
				'{allow_rep}' => $lang_admin_groups['allow group reputation'],
				'{allow_rep_1_checked}' => ($group['g_rep_enabled'] == '1') ? ' checked="checked"' : '',
				'{allow_rep_0_checked}' => ($group['g_rep_enabled'] == '0') ? ' checked="checked"' : '',
				'{allow_rep_help}' => $lang_admin_groups['allow reputation privileges'],
				'{positive_votes_label}' => $lang_admin_groups['group max positive'],
				'{positive_value}' => $group['g_rep_plus'],
				'{positive_votes_help}' => $lang_admin_groups['group max positive legend'],
				'{negative_votes_label}' => $lang_admin_groups['group max negative'],
				'{negative_value}' => $group['g_rep_minus'],
				'{negative_votes_help}' => $lang_admin_groups['group max negative legend'],
				'{group_interval_label}' => $lang_admin_groups['group interval'],
				'{interval_value}' => $group['g_rep_interval'],
				'{group_interval_help}' => $lang_admin_groups['group interval legend'],
				'{use_pm_legend}' => $lang_admin_groups['Use pm label'],
				'{use_pm_1_checked}' => ($group['g_use_pm'] == '1') ? ' checked="checked"' : '',
				'{use_pm_0_checked}' => ($group['g_use_pm'] == '0') ? ' checked="checked"' : '',
				'{use_pm_help}' => $lang_admin_groups['Use pm help'],
				'{pm_limit_label}' => $lang_admin_groups['PM limit label'],
				'{pm_limit_value}' => $group['g_pm_limit'],
				'{pm_limit_help}' => $lang_admin_groups['PM limit help'],
				'{folder_limit_label}' => $lang_admin_groups['PM folder limit label'],
				'{folder_limit_value}' => $group['g_pm_folder_limit'],
				'{folder_limit_help}' => $lang_admin_groups['PM folder limit help'],
			);

			$email_tpl = "\n".str_replace(array_keys($search), array_values($search), $email_tpl);
			$flood_protection_tpl = panther_template('edit_group_flood_protection.tpl');
			$search = array(
				'{email_flood_label}' => $lang_admin_groups['E-mail flood label'],
				'{email_flood_value}' => $group['g_email_flood'],
				'{email_flood_help}' => $lang_admin_groups['E-mail flood help'],
				'{report_flood_label}' => $lang_admin_groups['Report flood label'],
				'{report_flood_value}' => $group['g_report_flood'],
				'{report_flood_help}' => $lang_admin_groups['Report flood help'],
			);

			$flood_protection_tpl = "\n".str_replace(array_keys($search), array_values($search), $flood_protection_tpl);			
			if ($mode != 'edit' || $panther_config['o_default_user_group'] != $group['g_id'])
			{
				$mod_tpl = panther_template('edit_group_moderator.tpl');
				$search = array(
					'{mod_privileges_label}' => $lang_admin_groups['Mod privileges label'],
					'{moderator_1_checked}' => ($group['g_moderator'] == '1') ? ' checked="checked"' : '',
					'{moderator_0_checked}' => ($group['g_moderator'] == '0') ? ' checked="checked"' : '',
					'{yes}' => $lang_admin_common['Yes'],
					'{no}' => $lang_admin_common['No'],
					'{mod_privileges_help}' => $lang_admin_groups['Mod privileges help'],
					'{mod_cp_label}' => $lang_admin_groups['Mod CP label'],
					'{mod_cp_1_checked}' => ($group['g_mod_cp'] == '1') ? ' checked="checked"' : '',
					'{mod_cp_0_checked}' => ($group['g_mod_cp'] == '0') ? ' checked="checked"' : '',
					'{mod_cp_help}' => $lang_admin_groups['Mod CP help'],
					'{admin_label}' => $lang_admin_groups['Admin label'],
					'{admin_1_checked}' => ($group['g_admin'] == '1') ? ' checked="checked"' : '',
					'{admin_0_checked}' => ($group['g_admin'] == '0') ? ' checked="checked"' : '',
					'{admin_help}' => $lang_admin_groups['Admin help'],
					'{global_mod_label}' => $lang_admin_groups['Global mod label'],
					'{global_mod_1_checked}' => ($group['g_global_moderator'] == '1') ? ' checked="checked"' : '',
					'{global_mod_0_checked}' => ($group['g_global_moderator'] == '0') ? ' checked="checked"' : '',
					'{global_mod_help}' => $lang_admin_groups['Global mod help'],
					'{edit_profile_label}' => $lang_admin_groups['Edit profile label'],
					'{edit_users_1_checked}' => ($group['g_mod_edit_users'] == '1') ? ' checked="checked"' : '',
					'{edit_users_0_checked}' => ($group['g_mod_edit_users'] == '0') ? ' checked="checked"' : '',
					'{edit_profile_help}' => $lang_admin_groups['Edit profile help'],
					'{rename_users_label}' => $lang_admin_groups['Rename users label'],
					'{rename_users_1_checked}' => ($group['g_mod_rename_users'] == '1') ? ' checked="checked"' : '',
					'{rename_users_0_checked}' => ($group['g_mod_rename_users'] == '0') ? ' checked="checked"' : '',
					'{rename_users_help}' => $lang_admin_groups['Rename users help'],
					'{change_passwords_label}' => $lang_admin_groups['Change passwords label'],
					'{change_passwords_1_checked}' => ($group['g_mod_change_passwords'] == '1') ? ' checked="checked"' : '',
					'{change_passwords_0_checked}' => ($group['g_mod_change_passwords'] == '0') ? ' checked="checked"' : '',
					'{change_password_help}' => $lang_admin_groups['Change passwords help'],
					'{promote_label}' => $lang_admin_groups['Mod promote users label'],
					'{promote_users_1_checked}' => ($group['g_mod_promote_users'] == '1') ? ' checked="checked"' : '',
					'{promote_users_0_checked}' => ($group['g_mod_promote_users'] == '0') ? ' checked="checked"' : '',
					'{promote_help}' => $lang_admin_groups['Mod promote users help'],
					'{report_posts}' => $lang_admin_groups['Report posts label'],
					'{sfs_1_checked}' => ($group['g_mod_sfs_report'] == '1') ? ' checked="checked"' : '',
					'{sfs_0_checked}' => ($group['g_mod_sfs_report'] == '0') ? ' checked="checked"' : '',
					'{report_posts_help}' => $lang_admin_groups['Report posts help'],
					'{warn_users_label}' => $lang_admin_groups['Warn users label'],
					'{warn_users_1_checked}' => ($group['g_mod_warn_users'] == '1') ? ' checked="checked"' : '',
					'{warn_users_0_checked}' => ($group['g_mod_warn_users'] == '0') ? ' checked="checked"' : '',
					'{warn_users_help}' => $lang_admin_groups['Warn users help'],
					'{ban_label}' => $lang_admin_groups['Ban users label'],
					'{ban_1_checked}' => ($group['g_mod_ban_users'] == '1') ? ' checked="checked"' : '',
					'{ban_0_checked}' => ($group['g_mod_ban_users'] == '0') ? ' checked="checked"' : '',
					'{ban_help}' => $lang_admin_groups['Ban users help'],
					'{edit_posts_label}' => $lang_admin_groups['Edit admin posts label'],
					'{edit_posts_1_checked}' => ($group['g_mod_edit_admin_posts'] == '1') ? ' checked="checked"' : '',
					'{edit_posts_0_checked}' => ($group['g_mod_edit_admin_posts'] == '0') ? ' checked="checked"' : '',
					'{edit_posts_help}' => $lang_admin_groups['Edit admin posts help'],
				);

				$mod_tpl = str_replace(array_keys($search), array_values($search), $mod_tpl)."\n";
			}
			else
				$mod_tpl = '';
		}
		else
			$member_tpl = $attachment_tpl = $title_tpl = $email_tpl = $flood_protection_tpl = $mod_tpl = '';
		
		$additional_tpl = panther_template('edit_group_additional.tpl');	
		$search = array(
			'{member_template}' => $member_tpl,
			'{moderator_privileges}' => $mod_tpl,
			'{read_board_label}' => $lang_admin_groups['Read board label'],
			'{read_board_1_checked}' => ($group['g_read_board'] == '1') ? ' checked="checked"' : '',
			'{read_board_0_checked}' => ($group['g_read_board'] == '0') ? ' checked="checked"' : '',
			'{yes}' => $lang_admin_common['Yes'],
			'{no}' => $lang_admin_common['No'],
			'{read_board_help}' => $lang_admin_groups['Read board help'],
			'{view_user_info_label}' => $lang_admin_groups['View user info label'],
			'{view_users_1_checked}' => ($group['g_view_users'] == '1') ? ' checked="checked"' : '',
			'{view_users_0_checked}' => ($group['g_view_users'] == '0') ? ' checked="checked"' : '',
			'{view_user_info_help}' => $lang_admin_groups['View user info help'],
			'{post_replies_label}' => $lang_admin_groups['Post replies label'],
			'{post_replies_1_checked}' => ($group['g_post_replies'] == '1') ? ' checked="checked"' : '',
			'{post_replies_0_checked}' => ($group['g_post_replies'] == '0') ? ' checked="checked"' : '',
			'{post_replies_help}' => $lang_admin_groups['Post replies help'],
			'{robot_verification}' => $lang_admin_groups['Robot verification label'],
			'{robot_test_1_checked}' => ($group['g_robot_test'] == '1') ? ' checked="checked"' : '',
			'{robot_test_0_checked}' => ($group['g_robot_test'] == '0') ? ' checked="checked"' : '',
			'{robot_verification_help}' => sprintf($lang_admin_groups['Robot verification help'], get_link($panther_url['admin_robots'])),
			'{post_polls_label}' => $lang_admin_groups['Post polls label'],
			'{post_polls_1_checked}' => ($group['g_post_polls'] == '1') ? ' checked="checked"' : '',
			'{post_polls_0_checked}' => ($group['g_post_polls'] == '0') ? ' checked="checked"' : '',
			'{post_polls_help}' => $lang_admin_groups['Post polls help'],
			'{post_moderation}' => $lang_admin_groups['Post moderation label'],
			'{moderate_posts_1_checked}' => ($group['g_moderate_posts'] == '1') ? ' checked="checked"' : '',
			'{moderate_posts_0_checked}' => ($group['g_moderate_posts'] == '0') ? ' checked="checked"' : '',
			'{post_moderation_help}' => $lang_admin_groups['Post moderation help'],
			'{post_topics_label}' => $lang_admin_groups['Post topics label'],
			'{post_topics_1_checked}' => ($group['g_post_topics'] == '1') ? ' checked="checked"' : '',
			'{post_topics_0_checked}' => ($group['g_post_topics'] == '0') ? ' checked="checked"' : '',
			'{post_topics_help}' => $lang_admin_groups['Post topics help'],
			'{attachment_permissions}' => $attachment_tpl,
			'{post_links_label}' => $lang_admin_groups['Post links label'],
			'{post_links_1_checked}' => ($group['g_post_links'] == '1') ? ' checked="checked"' : '',
			'{post_links_0_checked}' => ($group['g_post_links'] == '0') ? ' checked="checked"' : '',
			'{post_links_help}' => $lang_admin_groups['Post links help'],
			'{title_permission}' => $title_tpl,
			'{userlist_search_label}' => $lang_admin_groups['User search label'],
			'{userlist_search_1_checked}' => ($group['g_search'] == '1') ? ' checked="checked"' : '',
			'{userlist_search_0_checked}' => ($group['g_search'] == '0') ? ' checked="checked"' : '',
			'{user_search_help}' => $lang_admin_groups['User search help'],
			'{search_userlist_label}' => $lang_admin_groups['User list search label'],
			'{search_users_1_checked}' => ($group['g_search_users'] == '1') ? ' checked="checked"' : '',
			'{search_users_0_checked}' => ($group['g_search_users'] == '0') ? ' checked="checked"' : '',
			'{search_userlist_help}' => $lang_admin_groups['User list search help'],
			'{email_permissions}' => $email_tpl,
			'{post_flood_label}' => $lang_admin_groups['Post flood label'],
			'{post_flood_value}' => $group['g_post_flood'],
			'{post_flood_help}' => $lang_admin_groups['Post flood help'],
			'{search_flood_label}' => $lang_admin_groups['Search flood label'],
			'{search_flood_value}' => $group['g_search_flood'],
			'{search_flood_help}' => $lang_admin_groups['Search flood help'],
			'{flood_protection_permissions}' => $flood_protection_tpl,
		);
		
		$additional_tpl = str_replace(array_keys($search), array_values($search), $additional_tpl);
	}
	else
		$additional_tpl = '';
		
	if ($mode == 'edit')
	{
		$group_image_tpl = panther_template('group_image.tpl');
		if ($group['g_image'] != '')
		{
			$image_dir = ($panther_config['o_image_group_dir'] != '') ? $panther_config['o_image_group_dir'] : panther_htmlspecialchars(get_base_url().'/'.$panther_config['o_image_group_path'].'/');
			$img_size = @getimagesize($panther_config['o_image_group_path'].'/'.$group_id.'.'.$group['g_image']);
			$group_image = '<img src="'.$image_dir.$group_id.'.'.$group['g_image'].'" '.$img_size[3].' alt="'.panther_htmlspecialchars($group['g_user_title']).'" />';
		}
		else
			$group_image = '';

		$search = array(
			'{image_legend}' => $lang_admin_groups['Image legend'],
			'{image_size}' => (isset($img_size)) ? "\n\t\t\t\t\t".'<p>'.$group_image.'</p>' : '',
			'{image_info}' => $lang_admin_groups['Image info'],
			'{url_link}' => get_link($panther_url['upload_image'], array($group_id)),
			'{upload_lang}' => (isset($img_size)) ? $lang_admin_groups['Change image'] : $lang_admin_groups['Upload image'],
			'{delete_link}' => (isset($img_size)) ? '&nbsp;&nbsp;&nbsp;<a href="'.get_link($panther_url['delete_image'], array($group_id)).'">'.$lang_admin_groups['Delete image'].'</a>' : '',
		);
		
		$group_image_tpl = "\n".str_replace(array_keys($search), array_values($search), $group_image_tpl);
	}
	else
		$group_image_tpl = '';

	$admin_tpl = panther_template('edit_group.tpl');
	$search = array(
		'{group_settings}' => $lang_admin_groups['Group settings head'],
		'{form_action}' => get_link($panther_url['admin_groups']),
		'{save}' => $lang_admin_common['Save'],
		'{mode}' => $mode,
		'{csrf_token}' => generate_csrf_token(PANTHER_ADMIN_DIR.'/groups.php'),
		'{hidden_input}' => ($mode == 'edit') ? '<input type="hidden" name="group_id" value="'.$group_id.'" />' : '<input type="hidden" name="base_group" value="'.$base_group.'" />',
		'{settings_subhead}' => $lang_admin_groups['Group settings subhead'],
		'{settings_info}' => $lang_admin_groups['Group settings info'],
		'{group_title}' => $lang_admin_groups['Group title label'],
		'{title_value}' => ($mode == 'edit') ? panther_htmlspecialchars($group['g_title']) : '',
		'{user_title}' => $lang_admin_groups['User title label'],
		'{user_title_value}' => panther_htmlspecialchars($group['g_user_title']),
		'{user_title_help}' => sprintf($lang_admin_groups['User title help'], ($group['g_id'] != PANTHER_GUEST ? $lang_common['Member'] : $lang_common['Guest'])),
		'{group_colour}' => $lang_admin_groups['Group colour'],
		'{colour_value}' => panther_htmlspecialchars($group['g_colour']),
		'{colour_help}' => $lang_admin_groups['Group colour help'],
		'{additional_options}' => $additional_tpl,
		'{warn_text}' => ($group['g_moderator'] == '1') ? "\n\t\t\t\t\t\t".'<p class="warntext">'.$lang_admin_groups['Moderator info'].'</p>' : '',
		'{group_image}' => $group_image_tpl,
	);

	echo str_replace(array_keys($search), array_values($search), $admin_tpl);	
	require PANTHER_ROOT.'footer.php';
}
else if (isset($_POST['add_edit_group'])) // Add/edit a group (stage 2)
{
	confirm_referrer(PANTHER_ADMIN_DIR.'/groups.php');

	// Is this the original admin group? (special rules apply)
	$is_admin_group = (isset($_POST['group_id']) && $_POST['group_id'] == PANTHER_ADMIN) ? true : false;

	$title = isset($_POST['req_title']) ? panther_trim($_POST['req_title']) : '';
	$user_title = isset($_POST['user_title']) ? panther_trim($_POST['user_title']) : '';
	$group_colour = isset($_POST['group_colour']) ? panther_trim($_POST['group_colour']) : '';

	$promote_min_posts = isset($_POST['promote_min_posts']) ? intval($_POST['promote_min_posts']) : 0;
	$promote_next_group = (isset($_POST['promote_next_group']) && isset($groups[$_POST['promote_next_group']]) && !in_array($_POST['promote_next_group'], array(PANTHER_ADMIN, PANTHER_GUEST)) && $groups[$_POST['promote_next_group']]['g_admin'] != '1' && (!isset($_POST['group_id']) || $_POST['promote_next_group'] != $_POST['group_id'])) ? $_POST['promote_next_group'] : 0;

	$moderator = isset($_POST['moderator']) && $_POST['moderator'] == '1' ? '1' : '0';
	$global_moderator = $moderator == '1' && isset($_POST['global_moderator']) && $_POST['global_moderator'] == '1' ? '1' : '0';
	$mod_cp = $moderator == '1' && isset($_POST['mod_cp']) && $_POST['mod_cp'] == '1' ? '1' : '0';
	$admin = $moderator == '1' && isset($_POST['admin']) && $_POST['admin'] == '1' ? '1' : '0';
	$mod_edit_users = $moderator == '1' && isset($_POST['mod_edit_users']) && $_POST['mod_edit_users'] == '1' ? '1' : '0';
	$mod_rename_users = $moderator == '1' && isset($_POST['mod_rename_users']) && $_POST['mod_rename_users'] == '1' ? '1' : '0';
	$mod_change_passwords = $moderator == '1' && isset($_POST['mod_change_passwords']) && $_POST['mod_change_passwords'] == '1' ? '1' : '0';
	$mod_ban_users = $moderator == '1' && isset($_POST['mod_ban_users']) && $_POST['mod_ban_users'] == '1' ? '1' : '0';
	$mod_warn_users = $moderator == '1' && isset($_POST['mod_warn_users']) && $_POST['mod_warn_users'] == '1' ? '1' : '0';
	$mod_promote_users = $moderator == '1' && isset($_POST['mod_promote_users']) && $_POST['mod_promote_users'] == '1' ? '1' : '0';
	$read_board = isset($_POST['read_board']) ? intval($_POST['read_board']) : '1';
	$view_users = (isset($_POST['view_users']) && $_POST['view_users'] == '1') || $is_admin_group ? '1' : '0';
	$post_replies = isset($_POST['post_replies']) ? intval($_POST['post_replies']) : '1';
	$post_polls = isset($_POST['post_polls']) ? intval($_POST['post_polls']) : '1';
	$moderate_posts = isset($_POST['moderate_posts']) ? intval($_POST['moderate_posts']) : '0';
	$post_topics = isset($_POST['post_topics']) ? intval($_POST['post_topics']) : '1';
	$robot_test = isset($_POST['robot_test']) ? intval($_POST['robot_test']) : '0';
	$attach_files = isset($_POST['attach_files']) ? intval($_POST['attach_files']) : '0';
	$max_attachments = isset($_POST['max_attachments']) ? intval($_POST['max_attachments']) : '0';
	$max_size = isset($_POST['max_size']) ? intval($_POST['max_size']) : '0';
	$edit_posts = isset($_POST['edit_posts']) ? intval($_POST['edit_posts']) : ($is_admin_group) ? '1' : '0';
	$edit_subject = isset($_POST['edit_subject']) ? intval($_POST['edit_subject']) : ($is_admin_group) ? '1' : '0';
	$delete_posts = isset($_POST['delete_posts']) ? intval($_POST['delete_posts']) : ($is_admin_group) ? '1' : '0';
	$delete_topics = isset($_POST['delete_topics']) ? intval($_POST['delete_topics']) : ($is_admin_group) ? '1' : '0';
	$deledit_interval = isset($_POST['deledit_interval']) ? intval($_POST['deledit_interval']) : 0;
	$post_links = isset($_POST['post_links']) ? intval($_POST['post_links']) : '1';
	$set_title = isset($_POST['set_title']) ? intval($_POST['set_title']) : ($is_admin_group) ? '1' : '0';
	$search = isset($_POST['search']) ? intval($_POST['search']) : '1';
	$search_users = isset($_POST['search_users']) ? intval($_POST['search_users']) : '1';
	$send_email = (isset($_POST['send_email']) && $_POST['send_email'] == '1') || $is_admin_group ? '1' : '0';
	$post_flood = (isset($_POST['post_flood']) && $_POST['post_flood'] >= 0) ? intval($_POST['post_flood']) : '0';
	$search_flood = (isset($_POST['search_flood']) && $_POST['search_flood'] >= 0) ? intval($_POST['search_flood']) : '0';
	$email_flood = (isset($_POST['email_flood']) && $_POST['email_flood'] >= 0) ? intval($_POST['email_flood']) : '0';
	$report_flood = (isset($_POST['report_flood']) && $_POST['report_flood'] >= 0) ? intval($_POST['report_flood']) : '0';
	$reputation = isset($_POST['rep_enabled']) && intval($_POST['rep_enabled']) == '1' || $is_admin_group ? '1' : '0';
	$reputation_max = isset($_POST['g_rep_plus']) ? intval($_POST['g_rep_plus']) : '0';
	$reputation_min = isset($_POST['g_rep_minus']) ? intval($_POST['g_rep_minus']) : '0';
	$reputation_interval = isset($_POST['g_rep_interval']) ? intval($_POST['g_rep_interval']) : '0';
	$use_pm = isset($_POST['use_pm']) && $_POST['use_pm'] == '1' || $is_admin_group ? '1' : '0';
	$pm_limit = isset($_POST['pm_limit']) ? intval($_POST['pm_limit']) : '0';
	$folder_limit = isset($_POST['pm_folder_limit']) ? intval($_POST['pm_folder_limit']) : '0';

	if ($title == '')
		message($lang_admin_groups['Must enter title message']);

	if (!empty($group_colour) && !preg_match('/^#([a-fA-F0-9]){6}$/', $group_colour))
		message($lang_admin_groups['Invalid colour message']);
	
	$max_size = ($max_size > $panther_config['o_max_upload_size']) ? $panther_config['o_max_upload_size'] : $max_size;
	$user_title = ($user_title != '') ? $user_title : null;

	if ($_POST['mode'] == 'add')
	{
		$data = array(
			':title'	=>	$title,
		);

		$ps = $db->select('groups', 1, $data, 'g_title=:title');
		if ($ps->rowCount())
			message(sprintf($lang_admin_groups['Title already exists message'], panther_htmlspecialchars($title)));

		$insert = array(
			'g_title'				=>	$title,
			'g_user_title'			=>	$user_title,
			'g_promote_min_posts'	=>	$promote_min_posts,
			'g_promote_next_group'	=>	$promote_next_group,
			'g_moderator'			=>	$moderator,
			'g_mod_cp'				=>	$mod_cp,
			'g_admin'				=>	$admin,
			'g_global_moderator'	=>	$global_moderator,
			'g_mod_edit_users'		=>	$mod_edit_users,
			'g_mod_rename_users'	=>	$mod_rename_users,
			'g_mod_change_passwords'=>	$mod_change_passwords,
			'g_mod_warn_users'		=>	$mod_warn_users,
			'g_mod_ban_users'		=>	$mod_ban_users,
			'g_mod_promote_users'	=>	$mod_promote_users,
			'g_read_board'			=>	$read_board,
			'g_view_users'			=>	$view_users,
			'g_post_replies'		=>	$post_replies,
			'g_post_polls'			=>	$post_polls,
			'g_post_topics'			=>	$post_topics,
			'g_edit_posts'			=>	$edit_posts,
			'g_robot_test'			=>	$robot_test,
			'g_edit_subject'		=>	$edit_subject,
			'g_delete_posts'		=>	$delete_posts,
			'g_delete_topics'		=>	$delete_topics,
			'g_deledit_interval'	=>	$deledit_interval,
			'g_post_links'			=>	$post_links,
			'g_set_title'			=>	$set_title,
			'g_search'				=>	$search,
			'g_search_users'		=>	$search_users,
			'g_send_email'			=>	$send_email,
			'g_post_flood'			=>	$post_flood,
			'g_search_flood'		=>	$search_flood,
			'g_email_flood'			=>	$email_flood,
			'g_report_flood'		=>	$report_flood,
			'g_rep_enabled'			=>	$reputation,
			'g_rep_interval'		=>	$reputation_interval,
			'g_rep_plus'			=>	$reputation_max,
			'g_rep_minus'			=>	$reputation_min,
			'g_colour'				=>	$group_colour,
			'g_moderate_posts'		=>	$moderate_posts,
			'g_attach_files'		=>	$attach_files,
			'g_max_attachments'		=>	$max_attachments,
			'g_max_size'			=>	$max_size,
			'g_use_pm'				=>	$use_pm,
			'g_pm_limit'			=>	$pm_limit,
			'g_pm_folder_limit'		=>	$folder_limit,
		);

		$db->insert('groups', $insert);
		$new_group_id = $db->lastInsertId($db->prefix.'groups');

		$data = array(
			':id'	=>	isset($_POST['base_group']) ? intval($_POST['base_group']) : 0,
		);

		// Now let's copy the forum specific permissions from the group which this group is based on
		$ps = $db->select('forum_perms', 'forum_id, read_forum, post_replies, post_topics', $data, 'group_id=:id');

		foreach ($ps as $cur_forum_perm)
		{
			$insert = array(
				'group_id'	=>	$new_group_id,
				'forum_id'	=>	$cur_forum_perm['forum_id'],
				'read_forum'	=>	$cur_forum_perm['read_forum'],
				'post_replies'	=>	$cur_forum_perm['post_replies'],
				'post_topics'	=>	$cur_forum_perm['post_topics'],
			);

			$db->insert('forum_perms', $insert);
		}
	}
	else
	{
		$group_id = isset($_POST['group_id']) ? intval($_POST['group_id']) : 0;
		$data = array(
			':g_title'	=>	$title,
			':g_id'		=>	$group_id,
		);

		$ps = $db->select('groups', 1, $data, 'g_title=:g_title AND g_id!=:g_id');
		if ($ps->rowCount())
			message(sprintf($lang_admin_groups['Title already exists message'], panther_htmlspecialchars($title)));

		$update = array(
			'g_title'	=>	$title,
			'g_user_title'	=>	$user_title,
			'g_promote_min_posts'	=>	$promote_min_posts,
			'g_promote_next_group'	=>	$promote_next_group,
			'g_moderator'			=>	$moderator,
			'g_mod_cp'				=>	$mod_cp,
			'g_admin'				=>	$admin,
			'g_global_moderator'	=>	$global_moderator,
			'g_mod_edit_users'		=>	$mod_edit_users,
			'g_mod_rename_users'	=>	$mod_rename_users,
			'g_mod_change_passwords'=>	$mod_change_passwords,
			'g_mod_ban_users'		=>	$mod_ban_users,
			'g_mod_warn_users'		=>	$mod_warn_users,
			'g_mod_promote_users'	=>	$mod_promote_users,
			'g_read_board'			=>	$read_board,
			'g_view_users'			=>	$view_users,
			'g_post_replies'		=>	$post_replies,
			'g_post_polls'			=>	$post_polls,
			'g_post_topics'			=>	$post_topics,
			'g_robot_test'			=>	$robot_test,
			'g_edit_posts'			=>	$edit_posts,
			'g_edit_subject'		=>	$edit_subject,
			'g_delete_posts'		=>	$delete_posts,
			'g_delete_topics'		=>	$delete_topics,
			'g_deledit_interval'	=>	$deledit_interval,
			'g_post_links'			=>	$post_links,
			'g_set_title'			=>	$set_title,
			'g_search'				=>	$search,
			'g_search_users'		=>	$search_users,
			'g_send_email'			=>	$send_email,
			'g_post_flood'			=>	$post_flood,
			'g_search_flood'		=>	$search_flood,
			'g_email_flood'			=>	$email_flood,
			'g_report_flood'		=>	$report_flood,
			'g_rep_enabled'			=>	$reputation,
			'g_rep_interval'		=>	$reputation_interval,
			'g_rep_plus'			=>	$reputation_max,
			'g_rep_minus'			=>	$reputation_min,
			'g_colour'				=>	$group_colour,
			'g_moderate_posts'		=>	$moderate_posts,
			'g_attach_files'		=>	$attach_files,
			'g_max_attachments'		=>	$max_attachments,
			'g_max_size'			=>	$max_size,
			'g_use_pm'				=>	$use_pm,
			'g_pm_limit'			=>	$pm_limit,
			'g_pm_folder_limit'		=>	$folder_limit,
		);
		
		$data = array(
			':id'	=>	$group_id,
		);
		
		$db->update('groups', $update, 'g_id=:id', $data);

		// Promote all users who would be promoted to this group on their next post
		if ($promote_next_group)
		{
			$update = array(
				'group_id'	=>	$promote_next_group,
			);
			
			$data = array(
				':num_posts'	=>	$promote_min_posts,
				':gid'			=>	$group_id,
			);
	
			$db->update('users', $update, 'group_id=:gid AND num_posts>=:num_posts', $data);
		}
	}

	// Regenerate the quick jump cache
	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PANTHER_ROOT.'include/cache.php';

	generate_groups_cache();
	generate_config_cache();

	$group_id = $_POST['mode'] == 'add' ? $new_group_id : intval($_POST['group_id']);
	generate_quickjump_cache($group_id, $read_board);

	$redirect_msg = ($_POST['mode'] == 'edit') ? $lang_admin_groups['Group edited redirect'] : $lang_admin_groups['Group added redirect'];
	redirect(get_link($panther_url['admin_groups']), $redirect_msg);
}
else if (isset($_POST['set_default_group'])) // Set default group
{
	confirm_referrer(PANTHER_ADMIN_DIR.'/groups.php');
	$group_id = isset($_POST['default_group']) ? intval($_POST['default_group']) : 0;

	// Make sure it's not the admin or guest groups
	if ($group_id == PANTHER_ADMIN || $group_id == PANTHER_GUEST)
		message($lang_common['Bad request'], false, '404 Not Found');

	// Make sure it's not a moderator group
	if ($groups[$group_id]['g_moderator'] != 0)
		message($lang_common['Bad request'], false, '404 Not Found');

	$update = array(
		'conf_value' => $group_id,
	);
	
	$data = array(
		'conf_name' => 'o_default_user_group',
	);

	$db->update('config', $update);

	// Regenerate the config cache
	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PANTHER_ROOT.'include/cache.php';

	generate_config_cache();
	redirect(get_link($panther_url['admin_groups']), $lang_admin_groups['Default group redirect']);
}
else if (isset($_GET['delete_group'])) // Remove a group
{
	$group_id = isset($_POST['group_to_delete']) ? intval($_POST['group_to_delete']) : intval($_GET['delete_group']);
	if ($group_id < 5)
		message($lang_common['Bad request'], false, '404 Not Found');

	// Make sure we don't remove the default group
	if ($group_id == $panther_config['o_default_user_group'])
		message($lang_admin_groups['Cannot remove default message']);

	$data = array(
		':gid'	=>	$group_id,
	);

	// Check if this group has any members
	$ps = $db->run('SELECT g.g_title, COUNT(u.id) FROM '.$db->prefix.'groups AS g INNER JOIN '.$db->prefix.'users AS u ON g.g_id=u.group_id WHERE g.g_id=:gid GROUP BY g.g_id, g_title', $data);

	// If the group doesn't have any members or if we've already selected a group to move the members to
	if (!$ps->rowCount() || isset($_POST['del_group']))
	{
		if (isset($_POST['del_group_comply']) || isset($_POST['del_group']))
		{
			confirm_referrer(PANTHER_ADMIN_DIR.'/groups.php');

			if (isset($_POST['del_group']))
			{
				$move_to_group = intval($_POST['move_to_group']);
				$update = array(
					':gid'	=>	$move_to_group,
				);

				$data = array(
					':gid2'	=>	$group_id,
				);

				$db->update('users', $update, 'group_id=:gid2', $data);
			}

			$data = array(
				':gid'	=>	$group_id,
			);

			// Delete the group and any forum specific permissions
			$db->delete('groups', 'g_id=:gid', $data);
			$db->delete('forum_perms', 'group_id=:gid', $data);

			// Don't let users be promoted to this group
			$update = array(
				'g_promote_next_group' => 0,
			);

			$db->update('groups', $update, 'g_promote_next_group=:gid', $data);

			if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
				require PANTHER_ROOT.'include/cache.php';

			generate_groups_cache();
			redirect(get_link($panther_url['admin_groups']), $lang_admin_groups['Group removed redirect']);
		}
		else
		{
			$group_title = $panther_groups[$group_id]['g_title'];

			$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_admin_common['Admin'], $lang_admin_common['User groups']);
			define('PANTHER_ACTIVE_PAGE', 'admin');
			require PANTHER_ROOT.'header.php';

			generate_admin_menu('groups');
			$admin_tpl = panther_template('delete_group.tpl');
			$search = array(
				'{delete_head}' => $lang_admin_groups['Group delete head'],
				'{form_action}' => get_link($panther_url['del_group'], array($group_id)),
				'{group_id}' => $group_id,
				'{csrf_token}' => generate_csrf_token(PANTHER_ADMIN_DIR.'/groups.php'),
				'{confirm_delete}' => $lang_admin_groups['Confirm delete subhead'],
				'{delete_group}' => sprintf($lang_admin_groups['Confirm delete info'], panther_htmlspecialchars($group_title)),
				'{delete_warning}' => $lang_admin_groups['Confirm delete warn'],
				'{delete}' => $lang_admin_common['Delete'],
				'{go_back}' => $lang_admin_common['Go back'],
			);
			
			echo str_replace(array_keys($search), array_values($search), $admin_tpl);
			require PANTHER_ROOT.'footer.php';
		}
	}

	list($group_title, $group_members) = $ps->fetch(PDO::FETCH_NUM);

	$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_admin_common['Admin'], $lang_admin_common['User groups']);
	define('PANTHER_ACTIVE_PAGE', 'admin');
	require PANTHER_ROOT.'header.php';

	generate_admin_menu('groups');

	$group_options = array();
	foreach ($groups as $cur_group)
	{
		if ($cur_group['g_id'] != PANTHER_GUEST && $cur_group['g_id'] != $group_id)
			$group_options[] = "\t\t\t\t\t\t\t\t\t\t".'<option value="'.$cur_group['g_id'].'" '.(($cur_group['g_id'] == PANTHER_MEMBER) ? ' selected="selected"' : '').'>'.panther_htmlspecialchars($cur_group['g_title']).'</option>';
	}

	$admin_tpl = panther_template('move_group.tpl');
	$search = array(
		'{delete_group}' => $lang_admin_groups['Delete group head'],
		'{form_action}' => get_link($panther_url['del_group'], array($group_id)),
		'{csrf_token}' => generate_csrf_token(PANTHER_ADMIN_DIR.'/groups.php'),
		'{move_users_subhead}' => $lang_admin_groups['Move users subhead'],
		'{move_users_info}' => sprintf($lang_admin_groups['Move users info'], panther_htmlspecialchars($group_title), forum_number_format($group_members)),
		'{move_users_label}' => $lang_admin_groups['Move users label'],
		'{group_options}' => count($group_options) ? implode("\n", $group_options) : '',
		'{delete}' => $lang_admin_groups['Delete group'],
		'{go_back}' => $lang_admin_common['Go back'],
	);

	echo str_replace(array_keys($search), array_values($search), $admin_tpl);
	require PANTHER_ROOT.'footer.php';
}

$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_admin_common['Admin'], $lang_admin_common['User groups']);
define('PANTHER_ACTIVE_PAGE', 'admin');
require PANTHER_ROOT.'header.php';

generate_admin_menu('groups');
$group_options = array(
	0 => array(),
	1 => array(),
	2 => array(),
);

$cur_index = 5;
$row_tpl = panther_template('admin_groups_row.tpl');
foreach ($groups as $cur_group)
{
	if ($cur_group['g_id'] != PANTHER_ADMIN && $cur_group['g_id'] != PANTHER_GUEST)
		$group_options[0][] = "\t\t\t\t\t\t\t\t\t\t\t".'<option value="'.$cur_group['g_id'].'"'.(($cur_group['g_id'] == $panther_config['o_default_user_group']) ? ' selected="selected"' : '').'>'.panther_htmlspecialchars($cur_group['g_title']).'</option>';

	if ($cur_group['g_id'] > PANTHER_GUEST && $cur_group['g_moderator'] == 0)
		$group_options[1][] = "\t\t\t\t\t\t\t\t\t\t\t".'<option value="'.$cur_group['g_id'].'"'.(($cur_group['g_id'] == $panther_config['o_default_user_group']) ? ' selected="selected"' : '').'>'.panther_htmlspecialchars($cur_group['g_title']).'</option>';

	$search = array(
		'{edit_group}' => get_link($panther_url['edit_group'], $cur_group['g_id']),
		'{index}' => $cur_index++,
		'{edit_link}' => $lang_admin_groups['Edit link'],
		'{del_link}' => (($cur_group['g_id'] > PANTHER_MEMBER) ? ' | <a href="'.get_link($panther_url['del_group'], $cur_group['g_id']).'" tabindex="'.$cur_index++.'">'.$lang_admin_groups['Delete link'].'</a>' : ''),
		'{title}' => panther_htmlspecialchars($cur_group['g_title']),
	);

	$group_options[2][] = "\t\t\t\t\t\t\t\t".str_replace(array_keys($search), array_values($search), $row_tpl);
}

$admin_tpl = panther_template('admin_groups.tpl');
$search = array(
	'{add_groups_head}' => $lang_admin_groups['Add groups head'],
	'{form_action}' => get_link($panther_url['admin_groups']),
	'{csrf_token}' => generate_csrf_token(PANTHER_ADMIN_DIR.'/groups.php'),
	'{add_group_head}' => $lang_admin_groups['Add group subhead'],
	'{new_group_label}' => $lang_admin_groups['New group label'],
	'{add}' => $lang_admin_common['Add'],
	'{new_group_options}' => count($group_options[0]) ? implode("\n", $group_options[0]) : '',
	'{new_group_help}' => $lang_admin_groups['New group help'],
	'{default_group_subhead}' => $lang_admin_groups['Default group subhead'],
	'{default_group_label}' => $lang_admin_groups['Default group label'],
	'{save}' => $lang_admin_common['Save'],
	'{default_group_options}' => count($group_options[1]) ? implode("\n", $group_options[1]) : '',
	'{default_group_label}' => $lang_admin_groups['Default group help'],
	'{existing_groups_head}' => $lang_admin_groups['Existing groups head'],
	'{edit_groups_legend}' => $lang_admin_groups['Edit groups subhead'],
	'{edit_groups_info}' => $lang_admin_groups['Edit groups info'],
	'{deledit_groups}' => count($group_options[2]) ? implode("\n", $group_options[2]) : '',
);

echo str_replace(array_keys($search), array_values($search), $admin_tpl);
require PANTHER_ROOT.'footer.php';