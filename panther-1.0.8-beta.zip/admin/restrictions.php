<?php
/**
 * Copyright (C) 2015 Panther (https://www.pantherforum.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

// Tell header.php to use the admin template
define('PANTHER_ADMIN_CONSOLE', 1);

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/../');
	require PANTHER_ROOT.'include/common.php';
}

if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
	require PANTHER_ROOT.'include/cache.php';

require PANTHER_ROOT.'include/common_admin.php';

if (!$panther_user['is_admin'])
	message($lang_common['No permission']);

// Load the admin_restrictions.php language file
require PANTHER_ROOT.'lang/'.$admin_language.'/admin_restrictions.php';

if ($panther_user['id'] != '2')
{
	if(!is_null($admins[$panther_user['id']]['admin_restrictions']))
	{
		if ($admins[$panther_user['id']]['admin_restrictions'] == '0')
			message($lang_common['No permission'], false, '403 Forbidden');
	}
}

check_authentication();

$action = isset($_GET['action']) ? panther_htmlspecialchars($_GET['action']) : null;
$stage = isset($_GET['stage']) ? intval($_GET['stage']) : null;
$csrf_token = generate_csrf_token(PANTHER_ADMIN_DIR.'/restrictions.php');

if (($action == 'add' || $action == 'edit') && isset($_POST['form_sent']) && $stage == '3')
{
	confirm_referrer(PANTHER_ADMIN_DIR.'/restrictions.php');

	//Stage 3: Add/edit restrictions
	$user = isset($_POST['admin_id']) ? intval($_POST['admin_id']) : 0;
	if ($user < 1)
		message($lang_common['Bad request']);

	$board_config = isset($_POST['board_config']) ? intval($_POST['board_config']) : '1';
	$board_perms = isset($_POST['board_perms']) ? intval($_POST['board_perms']) : '1';	
	$board_cats = isset($_POST['board_cats']) ? intval($_POST['board_cats']) : '1';
	$board_forums = isset($_POST['board_forums']) ? intval($_POST['board_forums']) : '1';	
	$board_groups = isset($_POST['board_groups']) ? intval($_POST['board_groups']) : '1';
	$board_users = isset($_POST['board_users']) ? intval($_POST['board_users']) : '1';
	$board_censoring = isset($_POST['board_censoring']) ? intval($_POST['board_censoring']) : '1';
	$board_ranks = isset($_POST['board_ranks']) ? intval($_POST['board_ranks']) : '1';
	$board_moderate = isset($_POST['board_moderate']) ? intval($_POST['board_moderate']) : '1';
	$board_maintenance = isset($_POST['board_maintenance']) ? intval($_POST['board_maintenance']) : '0';
	$board_plugins = isset($_POST['board_plugins']) ? intval($_POST['board_plugins']) : '1';
	$board_restrictions = isset($_POST['board_restrictions']) ? intval($_POST['board_restrictions']) : '0';
	$board_updates = isset($_POST['board_updates']) ? intval($_POST['board_updates']) : '0';
	$board_archive = isset($_POST['board_archive']) ? intval($_POST['board_archive']) : '1';
	$board_smilies = isset($_POST['board_smilies']) ? intval($_POST['board_smilies']) : '1';
	$board_warnings = isset($_POST['board_warnings']) ? intval($_POST['board_warnings']) : '1';
	$board_attachments = isset($_POST['board_attachments']) ? intval($_POST['board_attachments']) : '1';
	$board_robots = isset($_POST['board_robots']) ? intval($_POST['board_robots']) : '1';
	$board_addons = isset($_POST['board_addons']) ? intval($_POST['board_addons']) : '1';

	$data = array(
		':id'	=>	$user,
		':admin' => PANTHER_ADMIN,
	);

	$ps = $db->run('SELECT 1 FROM '.$db->prefix.'users AS u INNER JOIN '.$db->prefix.'groups AS g ON u.group_id=g.g_id WHERE u.group_id=:id OR g.g_admin=1 OR g.g_id=:admin', $data);
	if (!$ps->rowCount())
		message($lang_admin_restrictions['no user']);

	$data = array(
		':id'	=>	$user,
	);

	$restrictions = array(
		'admin_options'		=>	$board_config,
		'admin_permissions'	=>	$board_perms,
		'admin_categories'	=>	$board_cats,
		'admin_forums'		=>	$board_forums,
		'admin_groups'		=>	$board_groups,
		'admin_censoring'	=>	$board_censoring,
		'admin_maintenance'	=>	$board_maintenance,
		'admin_plugins'		=>	$board_plugins,
		'admin_restrictions'=>	$board_restrictions,
		'admin_users'		=>	$board_users,
		'admin_moderate'	=>	$board_moderate,
		'admin_ranks'		=>	$board_ranks,
		'admin_updates'		=>	$board_updates,
		'admin_archive'		=>	$board_archive,
		'admin_smilies'		=>	$board_smilies,
		'admin_warnings'	=>	$board_warnings,
		'admin_attachments'	=>	$board_attachments,
		'admin_robots'		=>	$board_robots,
		'admin_addons'		=>	$board_addons,
	);

	$insert = array(
		'admin_id'	=>	$user,
		'restrictions'	=>	serialize($restrictions),
	);

	if ($action == 'add')
	{
		$db->insert('restrictions', $insert);
		$redirect_lang = $lang_admin_restrictions['added redirect'];
	}
	else
	{
		$data = array(
			':id'	=>	$user,
		);

		$db->update('restrictions', $insert, 'admin_id=:id', $data);
		$redirect_lang = $lang_admin_restrictions['edited redirect'];
	}

	generate_admin_restrictions_cache();
	redirect(get_link($panther_url['admin_restrictions']), $redirect_lang);
}
else if ($action == 'delete' && isset($_POST['form_sent']) && $stage == '3')
{
	confirm_referrer(PANTHER_ADMIN_DIR.'/restrictions.php');

	//Stage 3: Remove restrictions
	$user = isset($_POST['admin_id']) ? intval($_POST['admin_id']) : 0;
	$data = array(
		':id'	=>	$user,
	);

	$ps = $db->select('restrictions', 1, $data, 'admin_id=:id');

	if (!$ps->rowCount())
		message($lang_admin_restrictions['no restrictions']);

	$db->delete('restrictions', 'admin_id=:id', $data);

	generate_admin_restrictions_cache();
	redirect(get_link($panther_url['admin_restrictions']), $lang_admin_restrictions['removed redirect']);
}

$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_admin_common['Admin'], $lang_admin_common['Restrictions']);
define('PANTHER_ACTIVE_PAGE', 'admin');
require PANTHER_ROOT.'header.php';

if ($action == 'delete' && isset($_POST['form_sent']) && $stage == '2')
{
	//Stage 2: Confirm Removal of existing restrictions
	$user = isset($_POST['user']) ? intval($_POST['user']) : 0;
	$data = array(
		':id'	=>	$user,
	);

	$ps = $db->select('restrictions', 1, $data, 'admin_id=:id');

	if (!$ps->rowCount())
		message($lang_admin_restrictions['no restrictions']);

	generate_admin_menu('restrictions');
	$admin_tpl = panther_template('delete_restriction.tpl');
	$search = array(
		'{restrictions_head}' => $lang_admin_restrictions['restrictions head'],
		'{form_action}' => get_link($panther_url['admin_restrictions_query'], array('action=delete&stage=3')),
		'{csrf_token}' => $csrf_token,
		'{user}' => $user,
		'{delete_label}' => $lang_admin_restrictions['delete label'],
		'{delete}' => $lang_admin_restrictions['delete'],
		'{go_back}' => $lang_admin_restrictions['back'],
	);
	
	echo str_replace(array_keys($search), array_values($search), $admin_tpl);
}
else if (($action == 'edit' || $action == 'add') && isset($_POST['form_sent']) && $stage == '2')
{
	confirm_referrer(PANTHER_ADMIN_DIR.'/restrictions.php');

	//Stage 2: Edit existing restrictions
	$user = isset($_POST['user']) ? intval($_POST['user']) : 0;
	$data = array(
		':id'	=>	$user,
	);
	
	$ps = $db->select('users', 'username, group_id', $data, 'id=:id');
	if (!$ps->rowCount())
		message($lang_common['Bad request']);
	
	list($username, $group_id) = $ps->fetch(PDO::FETCH_NUM);
	
	if ($panther_groups[$group_id]['g_admin'] != '1' && $group_id != PANTHER_ADMIN)
		message($lang_common['Bad request']);

	// Then we're adding restrictions
	if (!isset($admins[$user]))
	{
		$admins[$user] = array(
			'admin_options'		=>	1,
			'admin_permissions'	=>	1,
			'admin_categories'	=>	1,
			'admin_forums'		=>	1,
			'admin_groups'		=>	1,
			'admin_censoring'	=>	1,
			'admin_maintenance'	=>	1,
			'admin_plugins'		=>	1,
			'admin_restrictions'=>	1,
			'admin_users'		=>	1,
			'admin_moderate'	=>	1,
			'admin_ranks'		=>	1,
			'admin_updates'		=>	1,
			'admin_archive'		=>	1,
			'admin_smilies'		=>	1,
			'admin_warnings'	=>	1,
			'admin_attachments'	=>	1,
			'admin_robots'		=>	1,
			'admin_addons'		=>	1,
		);
	}
	
	generate_admin_menu('restrictions');
	$admin_tpl = panther_template('edit_restrictions.tpl');
	$search = array(
		'{restrictions_head}' => $lang_admin_restrictions['restrictions head'],
		'{form_action}' => get_link($panther_url['admin_restrictions_query'], array('action='.$action.'&stage=3')),
		'{submit}' => $lang_common['Submit'],
		'{user}' => $user,
		'{csrf_token}' => $csrf_token,
		'{restrictions_subhead}' => sprintf($lang_admin_restrictions['restrictions for user x'], panther_htmlspecialchars($username)),
		'{admin_restrictions}' => $lang_admin_restrictions['admin restrictions'],
		'{board_config}' => $lang_admin_restrictions['board config'],
		'{options_1_checked}' => ($admins[$user]['admin_options'] == '1') ? ' checked="checked"' : '',
		'{options_0_checked}' => ($admins[$user]['admin_options'] == '0') ? ' checked="checked"' : '',
		'{yes}' => $lang_admin_common['Yes'],
		'{no}' => $lang_admin_common['No'],
		'{change_config_help}' => $lang_admin_restrictions['change config label'],
		'{board_archive}' => $lang_admin_restrictions['board archive'],
		'{archive_1_checked}' => ($admins[$user]['admin_archive'] == '1') ? ' checked="checked"' : '',
		'{archive_0_checked}' => ($admins[$user]['admin_archive'] == '0') ? ' checked="checked"' : '',
		'{change_archive_help}' => $lang_admin_restrictions['change archive label'],
		'{board_perms}' => $lang_admin_restrictions['board perms'],
		'{permissions_1_checked}' => ($admins[$user]['admin_permissions'] == '1') ? ' checked="checked"' : '',
		'{permissions_0_checked}' => ($admins[$user]['admin_permissions'] == '0') ? ' checked="checked"' : '',
		'{change_perms_help}' => $lang_admin_restrictions['change perms label'],
		'{board_categories}' => $lang_admin_restrictions['board cats'],
		'{categories_1_checked}' => ($admins[$user]['admin_categories'] == '1') ? ' checked="checked"' : '',
		'{categories_0_checked}' => ($admins[$user]['admin_categories'] == '0') ? ' checked="checked"' : '',
		'{change_categories_help}' => $lang_admin_restrictions['change cats label'],
		'{board_forums}' => $lang_admin_restrictions['board forums'],
		'{forums_1_checked}' => ($admins[$user]['admin_forums'] == '1') ? ' checked="checked"' : '',
		'{forums_0_checked}' => ($admins[$user]['admin_forums'] == '0') ? ' checked="checked"' : '',
		'{change_forums_help}' => $lang_admin_restrictions['change forums label'],
		'{board_groups}' => $lang_admin_restrictions['board groups'],
		'{groups_1_checked}' => ($admins[$user]['admin_groups'] == '1') ? ' checked="checked"' : '',
		'{groups_0_checked}' => ($admins[$user]['admin_groups'] == '0') ? ' checked="checked"' : '',
		'{change_groups_help}' => $lang_admin_restrictions['change groups label'],
		'{board_censoring}' => $lang_admin_restrictions['board censoring'],
		'{censoring_1_checked}' => ($admins[$user]['admin_censoring'] == '1') ? ' checked="checked"' : '',
		'{censoring_0_checked}' => ($admins[$user]['admin_censoring'] == '0') ? ' checked="checked"' : '',
		'{change_censoring_label}' => $lang_admin_restrictions['change censoring label'],
		'{board_ranks}' => $lang_admin_restrictions['board ranks'],
		'{ranks_1_checked}' => ($admins[$user]['admin_ranks'] == '1') ? ' checked="checked"' : '',
		'{ranks_0_checked}' => ($admins[$user]['admin_ranks'] == '0') ? ' checked="checked"' : '',
		'{change_ranks_help}' => $lang_admin_restrictions['change ranks label'],
		'{board_robots}' => $lang_admin_restrictions['board robots'],
		'{robots_1_checked}' => ($admins[$user]['admin_robots'] == '1') ? ' checked="checked"' : '',
		'{robots_0_checked}' => ($admins[$user]['admin_robots'] == '0') ? ' checked="checked"' : '',
		'{change_robots_help}' => $lang_admin_restrictions['change robots label'],
		'{board_smilies}' => $lang_admin_restrictions['board smilies'],
		'{smilies_1_checked}' => ($admins[$user]['admin_smilies'] == '1') ? ' checked="checked"' : '',
		'{smilies_0_checked}' => ($admins[$user]['admin_smilies'] == '0') ? ' checked="checked"' : '',
		'{change_smilies_help}' => $lang_admin_restrictions['change smilies label'],
		'{board_warnings}' => $lang_admin_restrictions['board warnings'],
		'{warnings_1_checked}' => ($admins[$user]['admin_warnings'] == '1') ? ' checked="checked"' : '',
		'{warnings_0_checked}' => ($admins[$user]['admin_warnings'] == '0') ? ' checked="checked"' : '',
		'{change_warnings_help}' => $lang_admin_restrictions['change warnings label'],
		'{board_moderate}' => $lang_admin_restrictions['board moderate'],
		'{moderate_1_checked}' => ($admins[$user]['admin_moderate'] == '1') ? ' checked="checked"' : '',
		'{moderate_0_checked}' => ($admins[$user]['admin_moderate'] == '0') ? ' checked="checked"' : '',
		'{change_moderation_help}' => $lang_admin_restrictions['change moderate label'],
		'{board_attachments}' => $lang_admin_restrictions['board attachments'],
		'{attachments_1_checked}' => ($admins[$user]['admin_attachments'] == '1') ? ' checked="checked"' : '',
		'{attachments_0_checked}' => ($admins[$user]['admin_attachments'] == '0') ? ' checked="checked"' : '',
		'{change_attachments_help}' => $lang_admin_restrictions['change attachments label'],
		'{board_restrictions}' => $lang_admin_restrictions['board restrictions'],
		'{restrictions_1_checked}' => ($admins[$user]['admin_restrictions'] == '1') ? ' checked="checked"' : '',
		'{restrictions_0_checked}' => ($admins[$user]['admin_restrictions'] == '0') ? ' checked="checked"' : '',
		'{change_restrictions_help}' => $lang_admin_restrictions['change restrictions label'],
		'{board_addons}' => $lang_admin_restrictions['board addons'],
		'{addons_1_checked}' => ($admins[$user]['admin_addons'] == '1') ? ' checked="checked"' : '',
		'{addons_0_checked}' => ($admins[$user]['admin_addons'] == '0') ? ' checked="checked"' : '',
		'{change_addons_help}' => $lang_admin_restrictions['change addons label'],
		'{board_maintenance}' => $lang_admin_restrictions['board maintenance'],
		'{maintenance_1_checked}' => ($admins[$user]['admin_maintenance'] == '1') ? ' checked="checked"' : '',
		'{maintenance_0_checked}' => ($admins[$user]['admin_maintenance'] == '0') ? ' checked="checked"' : '',
		'{change_maintenance_help}' => $lang_admin_restrictions['change maintenance label'],
		'{board_updates}' => $lang_admin_restrictions['board updates'],
		'{updates_1_checked}' => ($admins[$user]['admin_updates'] == '1') ? ' checked="checked"' : '',
		'{updates_0_checked}' => ($admins[$user]['admin_updates'] == '0') ? ' checked="checked"' : '',
		'{install_updates_help}' => $lang_admin_restrictions['install updates label'],
		'{board_plugins}' => $lang_admin_restrictions['board plugins'],
		'{plugins_1_checked}' => ($admins[$user]['admin_plugins'] == '1') ? ' checked="checked"' : '',
		'{plugins_0_checked}' => ($admins[$user]['admin_plugins'] == '0') ? ' checked="checked"' : '',
		'{change_plugins_help}' => $lang_admin_restrictions['change plugins label'],
		'{board_users}' => $lang_admin_restrictions['board users'],
		'{users_1_checked}' => ($admins[$user]['admin_users'] == '1') ? ' checked="checked"' : '',
		'{users_0_checked}' => ($admins[$user]['admin_users'] == '0') ? ' checked="checked"' : '',
		'{change_users_help}' => $lang_admin_restrictions['change users label'],
	);

	echo str_replace(array_keys($search), array_values($search), $admin_tpl);
}
else
{
	if (count(get_admin_ids()) < 2)
		message($lang_admin_restrictions['no admins available']);

	$cur_admins = $restrictions = array();
	$data = array(
		':admin'	=>	PANTHER_ADMIN,
	);

	$ps = $db->run('SELECT u.username, u.id FROM '.$db->prefix.'users AS u LEFT JOIN '.$db->prefix.'restrictions AS ar ON u.id=ar.admin_id INNER JOIN '.$db->prefix.'groups AS g ON u.group_id=g.g_id WHERE (u.group_id=:admin OR g.g_admin=1) AND u.id!=2 AND ar.admin_id IS NULL ORDER BY u.id ASC', $data);
	foreach ($ps as $admin)
		$cur_admins[] = '<option value="'.$admin['id'].'">'.panther_htmlspecialchars($admin['username']).'</option>';

	$ps = $db->run('SELECT u.username, u.id FROM '.$db->prefix.'users AS u LEFT JOIN '.$db->prefix.'restrictions AS ar ON u.id=ar.admin_id INNER JOIN '.$db->prefix.'groups AS g ON u.group_id=g.g_id WHERE (u.group_id=:admin OR g.g_admin=1) AND u.id!=2 AND ar.admin_id IS NOT NULL ORDER BY u.id ASC', $data);
	foreach ($ps as $admin)
		$restrictions[] = '<option value="'.$admin['id'].'">'.panther_htmlspecialchars($admin['username']).'</option>';

	if (count($cur_admins) < 1)
		$cur_admins[] = '<optgroup label="'.$lang_admin_restrictions['no other admins'].'"></optgroup>';
	
	if (count($restrictions) < 1)
		$restrictions[] = '<optgroup label="'.$lang_admin_restrictions['no other admins'].'"></optgroup>';

	generate_admin_menu('restrictions');
	$admin_tpl = panther_template('admin_restrictions.tpl');
	$search = array(
		'{restrictions_head}' => $lang_admin_restrictions['restrictions head'],
		'{add_action}' => get_link($panther_url['admin_restrictions_query'], array('action=add&stage=2')),
		'{csrf_token}' => $csrf_token,
		'{restriction_information}' => $lang_admin_restrictions['restriction information'],
		'{new_admin_list}' => implode("\n\t\t\t\t\t\t", $cur_admins),
		'{submit}' => $lang_common['Submit'],
		'{edit_action}' => get_link($panther_url['admin_restrictions_query'], array('action=edit&stage=2')),
		'{restrictions_edit}' => $lang_admin_restrictions['restriction information 2'],
		'{restriction_list}' => implode("\n\t\t\t\t\t\t", $restrictions),
		'{del_action}' => get_link($panther_url['admin_restrictions_query'], array('action=delete&stage=2')),
		'{restrictions_delete}' => $lang_admin_restrictions['restriction information 3'],
		'{delete}' => $lang_admin_restrictions['delete'],
	);
	
	echo str_replace(array_keys($search), array_values($search), $admin_tpl);
}
require PANTHER_ROOT.'footer.php';