<?php
/**
 * Copyright (C) 2015 Panther (https://www.pantherforum.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

// Tell header.php to use the admin template
define('PANTHER_ADMIN_CONSOLE', 1);

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/../');
	require PANTHER_ROOT.'include/common.php';
}
require PANTHER_ROOT.'include/common_admin.php';

if (!$panther_user['is_admin'])
	message($lang_common['No permission'], false, '403 Forbidden');

if ($panther_user['id'] != '2')
{
	if(!is_null($admins[$panther_user['id']]['admin_robots']))
	{
		if ($admins[$panther_user['id']]['admin_robots'] == '0')
			message($lang_common['No permission'], false, '403 Forbidden');
	}
}

check_authentication();

// Load the admin_robots.php language file
require PANTHER_ROOT.'lang/'.$admin_language.'/admin_robots.php';

// Add a robot test
if (isset($_POST['add_test']))
{
	confirm_referrer(PANTHER_ADMIN_DIR.'/robots.php');

	$question = panther_trim($_POST['new_question']);
	$answer = panther_trim($_POST['new_answer']);

	if ($question == '' || $answer == '')
		message($lang_admin_robots['Must enter question message']);

	$insert = array(
		'question'	=>	$question,
		'answer'	=>	$answer,
	);

	$db->insert('robots', $insert);

	// Regenerate the robots cache
	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PANTHER_ROOT.'include/cache.php';

	generate_robots_cache();
	redirect(get_link($panther_url['admin_robots']), $lang_admin_robots['Question added redirect']);
}

// Update a robot question
else if (isset($_POST['update']))
{
	confirm_referrer(PANTHER_ADMIN_DIR.'/robots.php');

	$id = intval(key($_POST['update']));

	$question = panther_trim($_POST['question'][$id]);
	$answer = panther_trim($_POST['answer'][$id]);

	if ($question == '' || $answer == '')
		message($lang_admin_robots['Must enter question message']);

	$update = array(
		'question'	=>	$question,
		'answer'	=>	$answer,
	);
	
	$data = array(
		':id'	=>	$id,
	);

	$db->update('robots', $update, 'id=:id', $data);

	// Regenerate the robots cache
	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PANTHER_ROOT.'include/cache.php';

	generate_robots_cache();
	redirect(get_link($panther_url['admin_robots']), $lang_admin_robots['Question updated redirect']);
}

// Remove a robot test
else if (isset($_POST['remove']))
{
	confirm_referrer(PANTHER_ADMIN_DIR.'/robots.php');
	$id = intval(key($_POST['remove']));
	$data = array(
		':id'	=>	$id,
	);

	$db->delete('robots', 'id=:id', $data);

	// Regenerate the robots cache
	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PANTHER_ROOT.'include/cache.php';

	generate_robots_cache();
	redirect(get_link($panther_url['admin_robots']),  $lang_admin_robots['Question removed redirect']);
}

$ps = $db->select('robots', 'id, question, answer', array(), '', 'id');

$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_admin_common['Admin'], $lang_admin_common['Robots']);
$focus_element = array('robots', 'new_question');
define('PANTHER_ACTIVE_PAGE', 'admin');
require PANTHER_ROOT.'header.php';

generate_admin_menu('robots');
if ($ps->rowCount())
{
	$robots = array();
	$robots_list_tpl = panther_template('robots_row.tpl');
	foreach ($ps as $cur_test)
	{
		$search = array(
			'{test_id}' => $cur_test['id'],
			'{question}' => panther_htmlspecialchars($cur_test['question']),
			'{answer}' => panther_htmlspecialchars($cur_test['answer']),
			'{update}' => $lang_admin_common['Update'],
			'{remove}' => $lang_admin_common['Remove'],
		);

		$robots[] = str_replace(array_keys($search), array_values($search), $robots_list_tpl);
	}

	$robots_tpl = panther_template('censoring_results.tpl');
	$search = array(
		'{censored_word}' => $lang_admin_robots['Question label'],
		'{replacement_word}' => $lang_admin_robots['Answer label'],
		'{censoring_results}' => implode("\n", $robots),
		'{action_label}' => $lang_admin_robots['Action label'],
	);

	$robots_list_tpl = str_replace(array_keys($search), array_values($search), $robots_tpl);
}
else
	$robots_list_tpl = "\t\t\t\t\t\t\t".'<p>'.$lang_admin_robots['No questions in list'].'</p>'."\n";

// Re-use the admin_censoring template (it's the same design anyway)
$admin_tpl = panther_template('admin_censoring.tpl');
$search = array(
	'{censoring_head}' => $lang_admin_robots['Robots head'],
	'{form_action}' => get_link($panther_url['admin_robots']),
	'{csrf_token}' => generate_csrf_token(PANTHER_ADMIN_DIR.'/robots.php'),
	'{add_word_subhead}' => $lang_admin_robots['Add question subhead'],
	'{censoring_info}' => $lang_admin_robots['Add question info'],
	'{censored_word}' => $lang_admin_robots['Question label'],
	'{replacement_word}' => $lang_admin_robots['Answer label'],
	'{action_label}' => $lang_admin_robots['Action label'],
	'{add_word}' => $lang_admin_common['Add'],
	'{edit_remove_subhead}' => $lang_admin_robots['Edit remove subhead'],
	'{censoring_list}' => $robots_list_tpl,
	'{new_search_for}' => 'new_question',
	'{new_replace_with}' => 'new_answer',
	'{add_word_field}' => 'add_test',
);

echo str_replace(array_keys($search), array_values($search), $admin_tpl);
require PANTHER_ROOT.'footer.php';