<?php
/**
 * Copyright (C) 2015 Panther (https://www.pantherforum.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/');
	require PANTHER_ROOT.'include/common.php';
}

// Tell header.php we should use the editor
define('POSTING', 1);

if ($panther_user['g_read_board'] == '0')
	message($lang_common['No view'], false, '403 Forbidden');

if ($panther_user['is_guest'])
	message($lang_common['No permission']);

if ($panther_config['o_private_messaging'] == '0')
	message($lang_common['No permission']);

require PANTHER_ROOT.'lang/'.$panther_user['language'].'/pms.php';

$action = isset($_GET['action']) ? panther_htmlspecialchars($_GET['action']) : '';
$tid = isset($_GET['tid']) ? intval($_GET['tid']) : 0;
$pid = isset($_GET['pid']) ? intval($_GET['pid']) : 0;

if ($tid < 1 && $pid < 1)
	message($lang_common['Bad request'], false, '404 Not Found');

if ($pid)
{
	$data = array(
		':id'	=>	$pid,
	);

	$ps = $db->select('messages', 'topic_id, posted', $data, 'id=:id');
	if (!$ps->rowCount())
		message($lang_common['Bad request'], false, '404 Not Found');

	list($tid, $posted) = $ps->fetch(PDO::FETCH_NUM);

	$data = array(
		':id'	=>	$tid,
		':posted'	=>	$posted,
	);

	// Determine on which page the post is located (depending on $panther_user['disp_posts'])
	$ps = $db->select('messages', 'COUNT(id)', $data, 'topic_id=:id AND posted<:posted');
	$num_posts = $ps->fetchColumn() + 1;

	$_GET['p'] = ceil($num_posts / $panther_user['disp_posts']);
}
else
{
	// If action=new, we redirect to the first new post (if any)
	if ($action == 'new')
	{
		$data = array(
			':uid'	=>	$panther_user['id'],
			':tid'	=>	$tid,
			':last_visit'	=>	$panther_user['last_visit'],
		);

		$ps = $db->select('messages', 'MIN(id)', $data, 'poster_id!=:uid AND topic_id=:tid AND posted>:last_visit');
		$first_new_post_id = $ps->fetchColumn();

		
		if ($first_new_post_id)
		{
			header('Location: '.get_link($panther_url['pms_post'], array($first_new_post_id)));
			exit;
		}

		$action = 'last';
	}
	
	// If action=last, we redirect to the last post
	if ($action == 'last')
	{
		$data = array(
			':id'	=>	$tid,
		);

		$ps = $db->select('messages', 'MAX(id)', $data, 'topic_id=:id');
		$last_post_id = $ps->fetchColumn();

		if ($last_post_id)
		{
			header('Location: '.get_link($panther_url['pms_post'], array($last_post_id)));
			exit;
		}
	}
}

$data = array(
	':uid'	=>	$panther_user['id'],
	':tid'	=>	$tid,
);

$ps = $db->run('SELECT c.subject, c.num_replies, f.name, f.id AS fid, cd.viewed FROM '.$db->prefix.'conversations AS c INNER JOIN '.$db->prefix.'pms_data AS cd ON c.id=cd.topic_id INNER JOIN '.$db->prefix.'folders AS f ON cd.folder_id=f.id WHERE c.id=:tid AND cd.user_id=:uid', $data);

if (!$ps->rowCount())
	message($lang_common['Bad request'], false, '404 Not Found');

$cur_topic = $ps->fetch();

$data = array(
	':tid'	=>	$tid,
	':uid'	=>	$panther_user['id'],
);

$ps = $db->select('pms_data', 1, $data, 'topic_id=:tid AND user_id=:uid AND deleted=1');
if ($ps->rowCount())	// Why are we still trying to view this if we've deleted it?
	message($lang_common['Bad request']);

$quickpost = false;
if ($panther_config['o_quickpost'] == '1' && $cur_topic['fid'] != '3')
{
	$quickpost = true;
	$required_fields = array('req_message' => $lang_common['Message']);
}

if ($cur_topic['viewed'] == '0')
{
	$update = array(
		'viewed'	=>	1,
	);

	$data = array(
		':tid'	=>	$tid,
		':uid'	=>	$panther_user['id'],
	);
	
	$db->update('pms_data', $update, 'topic_id=:tid AND user_id=:uid', $data);
}

require PANTHER_ROOT.'lang/'.$panther_user['language'].'/topic.php';

// Determine the post offset (based on $_GET['p'])
$num_pages = ceil(($cur_topic['num_replies'] + 1) / $panther_user['disp_posts']);

$p = (!isset($_GET['p']) || $_GET['p'] <= 1 || $_GET['p'] > $num_pages) ? 1 : intval($_GET['p']);
$start_from = $panther_user['disp_posts'] * ($p - 1);

// Generate paging links
$paging_links = '<span class="pages-label">'.$lang_common['Pages'].' </span>'.paginate($num_pages, $p, $panther_url['pms_view'], array($tid));

if ($panther_config['o_censoring'] == '1')
	$cur_topic['subject'] = censor_words($cur_topic['subject']);

require PANTHER_ROOT.'include/parser.php';

$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_common['PM'], panther_htmlspecialchars($cur_topic['subject']));
define('PANTHER_ALLOW_INDEX', 1);
define('PANTHER_ACTIVE_PAGE', 'pm');
require PANTHER_ROOT.'header.php';

$post_count = 0; // Keep track of post numbers
$data = array(
	':tid'	=>	$tid,
	':start'	=>	$start_from,
);

// Retrieve a list of post IDs, LIMIT is (really) expensive so we only fetch the IDs here then later fetch the remaining data
$ps = $db->select('messages', 'id', $data, 'topic_id=:tid ORDER BY id LIMIT :start,'.$panther_user['disp_posts']);

$markers = $post_ids = array();
$ps->setFetchMode(PDO::FETCH_COLUMN, 0);
foreach ($ps as $cur_post_id)
{
	$post_ids[] = $cur_post_id;
	$markers[] = '?';
}

$post_row_tpl = panther_template('pm_post.tpl');
$ps = $db->run('SELECT u.email, u.use_gravatar, u.title, u.url, u.location, u.signature, u.reputation, u.email_setting, u.num_posts, u.registered, u.admin_note, p.id, p.poster AS username, p.poster_id, p.message, p.hide_smilies, p.posted, p.poster_ip, p.edited, p.edited_by, g.g_id, g.g_user_title, g.g_image, o.user_id AS is_online FROM '.$db->prefix.'messages AS p LEFT JOIN '.$db->prefix.'users AS u ON u.id=p.poster_id LEFT JOIN '.$db->prefix.'groups AS g ON g.g_id=u.group_id LEFT JOIN '.$db->prefix.'online AS o ON (o.user_id=u.id AND o.user_id!=1 AND o.idle=0) WHERE p.id IN ('.implode(',', $markers).') ORDER BY p.id', $post_ids);
foreach ($ps as $cur_post)
{
	$post_count++;
	$user_avatar = '';
	$user_info = array();
	$user_contacts = array();
	$post_actions = array();
	$is_online = '';
	$signature = '';
	
	$user_title = get_title($cur_post);

	if ($panther_config['o_censoring'] == '1')
		$user_title = censor_words($user_title);

	$is_online = ($cur_post['is_online'] == $cur_post['poster_id']) ? '<strong>'.$lang_topic['Online'].'</strong>' : '<span>'.$lang_topic['Offline'].'</span>';
	
	if ($panther_config['o_avatars'] == '1' && $panther_user['show_avatars'] != '0')
		$user_avatar = generate_avatar_markup($cur_post['poster_id'], $cur_post['email'], $cur_post['use_gravatar']);

	// We only show location, register date, post count and the contact links if "Show user info" is enabled
	if ($panther_config['o_show_user_info'] == '1')
	{
		if ($cur_post['location'] != '')
		{
			if ($panther_config['o_censoring'] == '1')
				$cur_post['location'] = censor_words($cur_post['location']);

			$user_info[] = '<dd><span>'.$lang_topic['From'].' '.panther_htmlspecialchars($cur_post['location']).'</span></dd>';
		}

		$user_info[] = '<dd><span>'.$lang_topic['Registered'].' '.format_time($cur_post['registered'], true).'</span></dd>';

		if ($panther_config['o_show_post_count'] == '1' || $panther_user['is_admmod'])
			$user_info[] = '<dd><span>'.$lang_topic['Posts'].' '.forum_number_format($cur_post['num_posts']).'</span></dd>';

		// Now let's deal with the contact links (Email and URL)
		if ((($cur_post['email_setting'] == '0' && !$panther_user['is_guest']) || $panther_user['is_admmod']) && $panther_user['g_send_email'] == '1')
			$user_contacts[] = '<span class="email"><a href="mailto:'.panther_htmlspecialchars($cur_post['email']).'">'.$lang_common['Email'].'</a></span>';
		else if ($cur_post['email_setting'] == '1' && !$panther_user['is_guest'] && $panther_user['g_send_email'] == '1')
			$user_contacts[] = '<span class="email"><a href="'.get_link($panther_url['email'], array($cur_post['poster_id'])).'">'.$lang_common['Email'].'</a></span>';

		if ($cur_post['url'] != '')
		{
			if ($panther_config['o_censoring'] == '1')
				$cur_post['url'] = censor_words($cur_post['url']);

			$user_contacts[] = '<span class="website"><a href="'.panther_htmlspecialchars($cur_post['url']).'" rel="nofollow">'.$lang_topic['Website'].'</a></span>';
		}
	}

	if ($panther_user['is_admmod'])
	{
		$user_info[] = '<dd><span><a href="'.get_link($panther_url['get_host'], array($cur_post['poster_ip'])).'" title="'.panther_htmlspecialchars($cur_post['poster_ip']).'">'.$lang_topic['IP address logged'].'</a></span></dd>';

		if ($cur_post['admin_note'] != '')
			$user_info[] = '<dd><span>'.$lang_topic['Note'].' <strong>'.panther_htmlspecialchars($cur_post['admin_note']).'</strong></span></dd>';
	}
	
	if ($cur_post['g_image'] != '')
	{
		$image_dir = ($panther_config['o_image_group_dir'] != '') ? $panther_config['o_image_group_dir'] : panther_htmlspecialchars(get_base_url().'/'.$panther_config['o_image_group_path'].'/');
		$img_size = @getimagesize($panther_config['o_image_group_path'].'/'.$cur_post['g_id'].'.'.$cur_post['g_image']);
		$group_image = '<img src="'.$image_dir.$cur_post['g_id'].'.'.$cur_post['g_image'].'" '.$img_size[3].' alt="'.panther_htmlspecialchars($cur_post['g_user_title']).'" />';
	}
	else
		$group_image = '';

	if ($panther_config['o_reputation'] == '1')
	{
		switch(true)
		{
			case $cur_post['poster_id'] == 1:
				$type = 'zero';
			break;
			case $cur_post['reputation'] > '0':
				$type = 'positive';
			break;
			case $cur_post['reputation'] < '0':
				$type = 'negative';
			break;
			default:
				$type = 'zero';
			break;
		}
	}
	
	if ($cur_topic['fid'] != '3')	// If it's not archived
	{
		if ($cur_post['poster_id'] == $panther_user['id'] || $panther_user['is_admmod'])
		{
			$post_actions[] = '<li class="postdelete"><span><a href="'.get_link($panther_url['pms_delete'], array($cur_post['id'])).'">'.$lang_topic['Delete'].'</a></span></li>';

			if ($panther_user['g_edit_posts'] == '1')
				$post_actions[] = '<li class="postedit"><span><a href="'.get_link($panther_url['pms_edit'], array($cur_post['id'])).'">'.$lang_topic['Edit'].'</a></span></li>';

			if ($panther_user['g_post_replies'] == '1')
				$post_actions[] = '<li class="postquote"><span><a href="'.get_link($panther_url['pms_quote'], array($tid, $cur_post['id'])).'">'.$lang_topic['Quote'].'</a></span></li>';
		}
	}

	$cur_post['reputation'] = '<span class="reputation '.$type.'">'.sprintf($lang_topic['reputation'], $cur_post['reputation']).'</span><br /><br />';
	// Perform the main parsing of the message (BBCode, smilies, censor words etc)
	$cur_post['message'] = parse_message($cur_post['message'], $cur_post['hide_smilies']);

	// Do signature parsing/caching
	if ($panther_config['o_signatures'] == '1' && $cur_post['signature'] != '' && $panther_user['show_sig'] != '0')
	{
		if (isset($signature_cache[$cur_post['poster_id']]))
			$signature = $signature_cache[$cur_post['poster_id']];
		else
		{
			$signature = parse_signature($cur_post['signature']);
			$signature_cache[$cur_post['poster_id']] = $signature;
		}
	}
	
	$search = array(
		'{post_id}' => $cur_post['id'],
		'{post_type}' => ($post_count % 2 == 0) ? ' roweven' : ' rowodd'.(($post_count == 1) ? ' firstpost' : '').(($post_count == 1) ? ' blockpost1' : ''),
		'{post_no}' => ($start_from + $post_count),
		'{post_link}' => get_link($panther_url['pms_post'], array($cur_post['id'])),
		'{post_posted}' => format_time($cur_post['posted']),
		'{username}' => colourize_group($cur_post['username'], $cur_post['g_id'], $cur_post['poster_id']),
		'{user_title}' => $user_title,
		'{user_avatar}' => (($panther_config['o_reputation'] == '1') ? '<dd>'.$cur_post['reputation'].'</dd>'."\n\t\t\t\t\t\t" : '').(($user_avatar != '') ? '<dd class="postavatar">'.$user_avatar.'</dd>' : ''),
		'{group_image}' => ($group_image != '') ? '<dd class="postavatar">'.$group_image.'</dd>' : '',
		'{user_info}' => (count($user_info) ? implode("\n\t\t\t\t\t\t", $user_info)."\n\t\t\t\t\t\t" : '').(count($user_contacts) ? '<dd class="usercontacts">'.implode(' ', $user_contacts).'</dd>' : ''),
		'{subject}' => (($post_count != 1) ? $lang_topic['Re'].' ' : '').panther_htmlspecialchars($cur_topic['subject']),
		'{message}' => $cur_post['message'],
		'{edited}' => ($cur_post['edited'] != '') ? "\n\t\t\t\t\t\t".'<p class="postedit"><em>'.$lang_topic['Last edit'].' '.panther_htmlspecialchars($cur_post['edited_by']).' ('.format_time($cur_post['edited']).')</em></p>'."\n" : '',
		'{signature}' => ($signature != '') ? "\t\t\t\t\t".'<div class="postsignature postmsg"><hr />'.$signature.'</div>'."\n" : '',
		'{online_status}' => $is_online,
		'{post_actions}' => (count($post_actions) ? '<div class="postfootright">'."\n\t\t\t\t\t".'<ul>'."\n\t\t\t\t\t\t".implode("\n\t\t\t\t\t\t", $post_actions)."\n\t\t\t\t\t".'</ul>'."\n\t\t\t\t".'</div>' : ''),
	);
	
	$posts[] = str_replace(array_keys($search), array_values($search), $post_row_tpl);
}

$pm_tpl = panther_template('pm_topic.tpl');
$search = array(
	'{index_link}' => get_link($panther_url['index']),
	'{index}' => $lang_common['Index'],
	'{inbox_link}' => get_link($panther_url['inbox']),
	'{inbox}' => $lang_common['PM'],
	'{subject}' => panther_htmlspecialchars($cur_topic['subject']),
	'{paging_links}' => $paging_links,
	'{reply_link}' => ($cur_topic['fid'] != '3') ? '<a href="'.get_link($panther_url['pms_reply'], array($tid)).'">'.$lang_pm['Add reply'].'</a>' : '',
	'{pm_menu}' => generate_pm_menu($cur_topic['fid']),
	'{pm_content}' => count($posts) ? implode("\n", $posts) : '',
);

echo str_replace(array_keys($search), array_values($search), $pm_tpl);
if ($quickpost)
{
	$quickpost_tpl = panther_template('pm_quickpost.tpl');
	$cur_index = 1;
	$search = array(
		'{quick_post}' => $lang_topic['Quick post'],
		'{form_action}' => get_link($panther_url['pms_reply'], array($tid)),
		'{write_message_legend}' => $lang_common['Write message legend'],
		'{csrf_token}' => generate_csrf_token(),
		'{index_1}' => $cur_index++,
		'{bbcode_help}' => get_link($panther_url['help'], array('bbcode')),
		'{bbcode}' => $lang_common['BBCode'],
		'{bbcode_onoff}' => ($panther_config['p_message_bbcode'] == '1') ? $lang_common['on'] : $lang_common['off'],
		'{url_help}' => get_link($panther_url['help'], array('url')),
		'{url}' => $lang_common['url tag'],
		'{url_onoff}' => ($panther_config['p_message_bbcode'] == '1' && $panther_user['g_post_links'] == '1') ? $lang_common['on'] : $lang_common['off'],
		'{img_help}' => get_link($panther_url['help'], array('img')),
		'{img}' => $lang_common['img tag'],
		'{img_onoff}' => ($panther_config['p_message_bbcode'] == '1' && $panther_config['p_message_img_tag'] == '1') ? $lang_common['on'] : $lang_common['off'],
		'{smilies_help}' => get_link($panther_url['help'], array('smilies')),
		'{smilies}' => $lang_common['Smilies'],
		'{smilies_onoff}' => ($panther_config['o_smilies'] == '1') ? $lang_common['on'] : $lang_common['off'],
		'{index_2}' => $cur_index++,
		'{submit}' => $lang_common['Submit'],
		'{preview}' => $lang_topic['Preview'],
		'{index_3}' => $cur_index++,
	);

	echo str_replace(array_keys($search), array_values($search), $quickpost_tpl);
}
require PANTHER_ROOT.'footer.php';