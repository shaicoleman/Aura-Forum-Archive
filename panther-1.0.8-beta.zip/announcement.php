<?php
/**
 * Copyright (C) 2015 Panther (https://www.pantherforum.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/');
	require PANTHER_ROOT.'include/common.php';
}

require PANTHER_ROOT.'include/parser.php';

if ($panther_user['g_read_board'] == '0')
	message($lang_common['No view'], false, '403 Forbidden');

$fid = isset($_GET['fid']) && $_GET['fid'] > 0 ? intval($_GET['fid']) : key($panther_forums);
$id = isset($_GET['id']) ? intval($_GET['id']) : '0';
if ($id < 1)
	message($lang_common['Bad request'], false, '404 Not Found');

require PANTHER_ROOT.'lang/'.$panther_user['language'].'/topic.php';

if (file_exists(FORUM_CACHE_DIR.'cache_perms.php'))
	require FORUM_CACHE_DIR.'cache_perms.php';
else
{
	require PANTHER_ROOT.'include/cache.php';
	generate_perms_cache();
	require FORUM_CACHE_DIR.'cache_perms.php';
}

if (!isset($perms[$panther_user['g_id'].'_'.$fid]))
	$perms[$panther_user['g_id'].'_'.$fid] = $perms['_'];

if ($perms[$panther_user['g_id'].'_'.$fid]['read_forum'] == '0')
	message($lang_common['No permission']);

$data = array(
	':id'	=>	$id,
);

$ps = $db->select('announcements', 'forum_id', $data, 'id=:id');
$afid = $ps->fetchColumn();

$data = array(
	':id'	=>	$id,
);

if ($afid == 0)
{
	$data[':fid'] = $fid;
	$ps = $db->run('SELECT a.subject, a.forum_id, g.g_image, g.g_user_title, g.g_id, a.user_id, a.message, u.email_setting, u.email, u.use_gravatar, u.group_id, u.num_posts, u.username, u.title, u.url, u.location, u.registered, f.forum_name, f.parent_forum, u.reputation, f.id AS fid, f.password, pf.forum_name AS parent FROM '.$db->prefix.'announcements AS a INNER JOIN '.$db->prefix.'users AS u ON u.id=a.user_id INNER JOIN '.$db->prefix.'forums AS f ON f.id=:fid INNER JOIN '.$db->prefix.'groups AS g ON u.group_id=g.g_id INNER JOIN '.$db->prefix.'posts AS p ON p.poster_id=a.user_id LEFT JOIN '.$db->prefix.'forums AS pf ON f.parent_forum=pf.id WHERE a.id=:id', $data);
}
else
	$ps = $db->run('SELECT a.subject, a.forum_id, g.g_image, g.g_user_title, g.g_id, a.user_id, a.message, u.email_setting, u.email, u.use_gravatar, u.group_id, u.num_posts, u.username, u.title, u.url, u.location, u.registered, f.forum_name, f.parent_forum, u.reputation, f.id AS fid, f.password, pf.forum_name AS parent FROM '.$db->prefix.'announcements AS a INNER JOIN '.$db->prefix.'users AS u ON u.id=a.user_id INNER JOIN '.$db->prefix.'forums AS f ON f.id=a.forum_id INNER JOIN '.$db->prefix.'groups AS g ON u.group_id=g.g_id INNER JOIN '.$db->prefix.'posts AS p ON p.poster_id=a.user_id LEFT JOIN '.$db->prefix.'forums AS pf ON f.parent_forum=pf.id WHERE a.id=:id', $data);

if (!$ps->rowCount())
	message($lang_common['Bad request'], false, '404 Not Found');

$cur_announcement = $ps->fetch();

if ($cur_announcement['password'] != '')
	check_forum_login_cookie($cur_announcement['fid'], $cur_announcement['password']);

$user_avatar = '';
$user_info = $user_contacts = $post_actions = array();
if ($panther_user['is_admmod'] == '1' && $panther_user['g_mod_cp'] == '1' || $panther_user['is_admin'])
{
	$post_actions[] = '<li class="postdelete"><span><a href="'.get_link($panther_url['delete_announcement'], array($id)).'">'.$lang_topic['Delete'].'</a></span></li>';
	$post_actions[] = '<li class="postedit"><span><a href="'.get_link($panther_url['edit_announcement'], array($id)).'">'.$lang_topic['Edit'].'</a></span></li>';
}

$username = colourize_group($cur_announcement['username'], $cur_announcement['group_id'], $cur_announcement['user_id']);

$user_title = get_title($cur_announcement);

if ($panther_config['o_censoring'] == '1')
	$user_title = censor_words($user_title);

if ($panther_config['o_avatars'] == '1' && $panther_user['show_avatars'] != '0')
	$user_avatar = generate_avatar_markup($cur_announcement['user_id'], $cur_announcement['email'], $cur_announcement['use_gravatar']);

// We only show location, register date, post count and the contact links if "Show user info" is enabled
if ($panther_config['o_show_user_info'] == '1')
{
	if ($cur_announcement['location'] != '')
	{
		if ($panther_config['o_censoring'] == '1')
			$cur_announcement['location'] = censor_words($cur_announcement['location']);

		$user_info[] = '<dd><span>'.$lang_topic['From'].' '.panther_htmlspecialchars($cur_announcement['location']).'</span></dd>';
	}

	$user_info[] = '<dd><span>'.$lang_topic['Registered'].' '.format_time($cur_announcement['registered'], true).'</span></dd>';

	if ($panther_config['o_show_post_count'] == '1' || $panther_user['is_admmod'])
		$user_info[] = '<dd><span>'.$lang_topic['Posts'].' '.forum_number_format($cur_announcement['num_posts']).'</span></dd>';

	// Now let's deal with the contact links (Email and URL)
	if ((($cur_announcement['email_setting'] == '0' && !$panther_user['is_guest']) || $panther_user['is_admmod']) && $panther_user['g_send_email'] == '1')
		$user_contacts[] = '<span class="email"><a href="mailto:'.panther_htmlspecialchars($cur_announcement['email']).'">'.$lang_common['Email'].'</a></span>';
	else if ($cur_announcement['email_setting'] == '1' && !$panther_user['is_guest'] && $panther_user['g_send_email'] == '1')
		$user_contacts[] = '<span class="email"><a href="'.get_link($panther_url['email'], array($cur_announcement['poster_id'])).'">'.$lang_common['Email'].'</a></span>';

	if ($cur_announcement['url'] != '')
	{
		if ($panther_config['o_censoring'] == '1')
			$cur_announcement['url'] = censor_words($cur_announcement['url']);

		$user_contacts[] = '<span class="website"><a href="'.panther_htmlspecialchars($cur_announcement['url']).'" rel="nofollow">'.$lang_topic['Website'].'</a></span>';
	}
}

if ($panther_config['o_reputation'] == '1')
{
	switch(true)
	{
		case $cur_announcement['reputation'] > '0':
			$type = 'positive';
		break;
		case $cur_announcement['reputation'] < '0':
			$type = 'negative';
		break;
		default:
			$type = 'zero';
		break;
	}

	$cur_announcement['reputation'] = '<span class="reputation '.$type.'">'.sprintf($lang_topic['reputation'], $cur_announcement['reputation']).'</span><br /><br />';
}

if ($cur_announcement['g_image'] != '')
{
	$image_dir = ($panther_config['o_image_group_dir'] != '') ? $panther_config['o_image_group_dir'] : panther_htmlspecialchars(get_base_url().'/'.$panther_config['o_image_group_path'].'/');
	$img_size = @getimagesize($panther_config['o_image_group_path'].'/'.$cur_announcement['group_id'].'.'.$cur_announcement['g_image']);
	$group_image = '<img src="'.$image_dir.$cur_announcement['group_id'].'.'.$cur_announcement['g_image'].'" '.$img_size[3].' alt="'.panther_htmlspecialchars($cur_announcement['g_user_title']).'" />';
}
else
	$group_image = '';

$announcement_type = (($afid != '0') ? 'announcement_fid' : 'announcement');

$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), panther_htmlspecialchars($cur_announcement['forum_name']), panther_htmlspecialchars($cur_announcement['subject']));
define('PANTHER_ACTIVE_PAGE', 'index');
require PANTHER_ROOT.'header.php';
$announce_tpl = panther_template('announcement.tpl');
$search = array(
	'{index_link}' => get_link($panther_url['index']),
	'{index}' => $lang_common['Index'],
	'{parent_forum}' => ($cur_announcement['parent']) ? "\n".'<li><span>»&#160;</span><a href="'.get_link($panther_url['forum'], array($cur_announcement['parent_forum'], url_friendly($cur_announcement['parent']))).'">'.panther_htmlspecialchars($cur_announcement['parent']).'</a></li>' : '',
	'{forum_url}' => get_link($panther_url['forum'], array($cur_announcement['fid'], url_friendly($cur_announcement['forum_name']))),
	'{forum_name}' => panther_htmlspecialchars($cur_announcement['forum_name']),
	'{announcement_url}' => get_link($panther_url[$announcement_type], array($id, $cur_announcement['fid'], url_friendly($cur_announcement['subject']))),
	'{subject}' => panther_htmlspecialchars($cur_announcement['subject']),
	'{username}' => $username,
	'{user_title}' => $user_title,
	'{user_reputation}' => ($panther_config['o_reputation'] == '1') ? "\n\t\t\t\t\t\t".'<dd>'.$cur_announcement['reputation'].'</dd>' : '',
	'{user_avatar}' => ($user_avatar != '') ? "\t\t\t\t\t\t".'<dd class="postavatar">'.$user_avatar.'</dd>' : '',
	'{group_image}' => $group_image,
	'{user_info}' => (count($user_info)) ? "\n\t\t\t\t\t\t".implode("\n\t\t\t\t\t\t", $user_info)."\n" : '',
	'{user_contacts}' => (count($user_contacts)) ? "\n\t\t\t\t\t\t".'<dd class="usercontacts">'.implode(' ', $user_contacts).'</dd>' : '',
	'{announcement}' => parse_message($cur_announcement['message'], 0),
	'{post_actions}' => (count($post_actions)) ? "\n"."\t\t\t\t".'<div class="postfootright">'."\n\t\t\t\t\t".'<ul>'."\n\t\t\t\t\t\t".implode("\n\t\t\t\t\t\t", $post_actions)."\n\t\t\t\t\t".'</ul>'."\n\t\t\t\t".'</div>' : '',
);

echo str_replace(array_keys($search), array_values($search), $announce_tpl);
require PANTHER_ROOT.'footer.php';