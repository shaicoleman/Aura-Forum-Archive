<?php
/**
 * Copyright (C) 2015 Panther (https://www.pantherforum.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

if (isset($_GET['action']))
	define('PANTHER_QUIET_VISIT', 1);

if (!defined('PANTHER_ROOT'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/');
	require PANTHER_ROOT.'include/common.php';
}

// Load the misc.php language file
require PANTHER_ROOT.'lang/'.$panther_user['language'].'/misc.php';

$action = isset($_GET['action']) ? $_GET['action'] : null;

if ($action == 'rules')
{
	if ($panther_config['o_rules'] == '0' || ($panther_user['is_guest'] && $panther_user['g_read_board'] == '0' && $panther_config['o_regs_allow'] == '0'))
		message($lang_common['Bad request'], false, '404 Not Found');

	// Load the register.php language file
	require PANTHER_ROOT.'lang/'.$panther_user['language'].'/register.php';

	$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_register['Forum rules']);
	define('PANTHER_ACTIVE_PAGE', 'rules');
	require PANTHER_ROOT.'header.php';
	$rules_tpl = panther_template('forum_rules.tpl');
	$search = array(
		'{forum_rules}' => $lang_register['Forum rules'],
		'{rules_message}' => $panther_config['o_rules_message'],
	);
	
	echo str_replace(array_keys($search), array_values($search), $rules_tpl);
	require PANTHER_ROOT.'footer.php';
}
else if ($action == 'markread')
{
	if ($panther_user['is_guest'])
		message($lang_common['No permission'], false, '403 Forbidden');

	$update = array(
		'last_visit'	=>	$panther_user['logged'],
	);
	
	$data = array(
		':id'	=>	$panther_user['id'],
	);

	$db->update('users', $update, 'id=:id', $data);

	// Reset tracked topics
	set_tracked_topics(null);

	redirect(get_link($panther_url['index']), $lang_misc['Mark read redirect']);
}

// Mark the topics/posts in a forum as read?
else if ($action == 'markforumread')
{
	if ($panther_user['is_guest'])
		message($lang_common['No permission'], false, '403 Forbidden');

	$fid = isset($_GET['fid']) ? intval($_GET['fid']) : 0;
	if ($fid < 1)
		message($lang_common['Bad request'], false, '404 Not Found');
	
	$data = array(
		':id'	=>	$fid,
	);
	
	$ps = $db->select('forums', 'forum_name', $data, 'id=:id');
	$forum_name = url_friendly($ps->fetchColumn());

	$tracked_topics = get_tracked_topics();
	$tracked_topics['forums'][$fid] = time();
	set_tracked_topics($tracked_topics);

	redirect(get_link($panther_url['forum'], array($fid, $forum_name)), $lang_misc['Mark forum read redirect']);
}
else if (isset($_GET['email']))
{
	if ($panther_user['is_guest'] || $panther_user['g_send_email'] == '0')
		message($lang_common['No permission'], false, '403 Forbidden');

	$recipient_id = intval($_GET['email']);
	if ($recipient_id < 2)
		message($lang_common['Bad request'], false, '404 Not Found');
	
	$data = array(
		':id'	=>	$recipient_id,
	);
	
	$ps = $db->select('users', 'username, email, email_setting', $data, 'id=:id');
	if (!$ps->rowCount())
		message($lang_common['Bad request'], false, '404 Not Found');

	list($recipient, $recipient_email, $email_setting) = $ps->fetch(PDO::FETCH_NUM);

	if ($email_setting == 2 && !$panther_user['is_admmod'])
		message($lang_misc['Form email disabled']);


	if (isset($_POST['form_sent']))
	{
		confirm_referrer('misc.php');

		// Clean up message and subject from POST
		$subject = panther_trim($_POST['req_subject']);
		$message = panther_trim($_POST['req_message']);

		if ($subject == '')
			message($lang_misc['No email subject']);
		else if ($message == '')
			message($lang_misc['No email message']);
		// Here we use strlen() not panther_strlen() as we want to limit the post to PANTHER_MAX_POSTSIZE bytes, not characters
		else if (strlen($message) > PANTHER_MAX_POSTSIZE)
			message($lang_misc['Too long email message']);

		if ($panther_user['last_email_sent'] != '' && (time() - $panther_user['last_email_sent']) < $panther_user['g_email_flood'] && (time() - $panther_user['last_email_sent']) >= 0)
			message(sprintf($lang_misc['Email flood'], $panther_user['g_email_flood'], $panther_user['g_email_flood'] - (time() - $panther_user['last_email_sent'])));

		// Load the "form email" template
		$mail_tpl = trim(file_get_contents(PANTHER_ROOT.'lang/'.$panther_user['language'].'/mail_templates/form_email.tpl'));

		// The first row contains the subject
		$first_crlf = strpos($mail_tpl, "\n");
		$mail_subject = panther_trim(substr($mail_tpl, 8, $first_crlf-8));
		$mail_message = panther_trim(substr($mail_tpl, $first_crlf));

		$mail_subject = str_replace('<mail_subject>', $subject, $mail_subject);
		$mail_message = str_replace('<sender>', $panther_user['username'], $mail_message);
		$mail_message = str_replace('<board_title>', $panther_config['o_board_title'], $mail_message);
		$mail_message = str_replace('<mail_message>', $message, $mail_message);
		$mail_message = str_replace('<board_mailer>', $panther_config['o_board_title'], $mail_message);

		require_once PANTHER_ROOT.'include/email.php';

		panther_mail($recipient_email, $mail_subject, $mail_message, $panther_user['email'], $panther_user['username']);
		$update = array(
			'last_email_sent'	=>	time(),
		);

		$data = array(
			':id'	=>	$panther_user['id'],
		);

		$db->update('users', $update, 'id=:id', $data);

		// Try to determine if the data in redirect_url is valid (if not, we redirect to index.php after the email is sent)
		$redirect_url = validate_redirect($_POST['redirect_url'], get_link($panther_url['index']));

		redirect(panther_htmlspecialchars($redirect_url), $lang_misc['Email sent redirect']);
	}

	// Try to determine if the data in HTTP_REFERER is valid (if not, we redirect to the user's profile after the email is sent)
	if (!empty($_SERVER['HTTP_REFERER']))
		$redirect_url = validate_redirect($_SERVER['HTTP_REFERER'], null);

	if (!isset($redirect_url))
		$redirect_url = get_link($panther_url['profile'], array($recipient_id));
	else if (preg_match('%viewtopic\.php\?pid=(\d+)$%', $redirect_url, $matches))
		$redirect_url .= '#p'.$matches[1];

	$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_misc['Send email to'].' '.panther_htmlspecialchars($recipient));
	$required_fields = array('req_subject' => $lang_misc['Email subject'], 'req_message' => $lang_misc['Email message']);
	$focus_element = array('email', 'req_subject');
	define('PANTHER_ACTIVE_PAGE', 'index');
	require PANTHER_ROOT.'header.php';
	$email_tpl = panther_template('send_email.tpl');
	$search = array(
		'{send_to_head}' => sprintf($lang_misc['Send email to'], panther_htmlspecialchars($recipient)),
		'{form_action}' => get_link($panther_url['email'], array($recipient_id)),
		'{write_email}' => $lang_misc['Write email'],
		'{csrf_token}' => generate_csrf_token(),
		'{redirect_url}' => panther_htmlspecialchars($redirect_url),
		'{email_subject}' => $lang_misc['Email subject'],
		'{required}' => $lang_common['Required'],
		'{email_message}' => $lang_misc['Email message'],
		'{email_disclosure_note}' => $lang_misc['Email disclosure note'],
		'{submit}' => $lang_common['Submit'],
		'{go_back}' => $lang_common['Go back'],
	);

	echo str_replace(array_keys($search), array_values($search), $email_tpl);
	require PANTHER_ROOT.'footer.php';
}
else if (isset($_GET['report']))
{
	if ($panther_user['is_guest'])
		message($lang_common['No permission'], false, '403 Forbidden');

	$post_id = intval($_GET['report']);
	if ($post_id < 1)
		message($lang_common['Bad request'], false, '404 Not Found');

	if (isset($_POST['form_sent']))
	{
		// Make sure they got here from the site
		confirm_referrer('misc.php');
		
		// Clean up reason from POST
		$reason = panther_linebreaks(panther_trim($_POST['req_reason']));
		if ($reason == '')
			message($lang_misc['No reason']);
		else if (strlen($reason) > 65535) // TEXT field can only hold 65535 bytes
			message($lang_misc['Reason too long']);

		if ($panther_user['last_report_sent'] != '' && (time() - $panther_user['last_report_sent']) < $panther_user['g_report_flood'] && (time() - $panther_user['last_report_sent']) >= 0)
			message(sprintf($lang_misc['Report flood'], $panther_user['g_report_flood'], $panther_user['g_report_flood'] - (time() - $panther_user['last_report_sent'])));

		// Get the topic ID
		$data = array(
			':id'	=>	$post_id,
		);

		$ps = $db->select('posts', 'topic_id', $data, 'id=:id');
		if (!$ps->rowCount())
			message($lang_common['Bad request'], false, '404 Not Found');

		$topic_id = $ps->fetchColumn();
		$data = array(
			':id'	=>	$topic_id,
		);

		// Get the subject and forum ID
		$ps = $db->run('SELECT t.subject, t.forum_id, f.forum_name, f.password FROM '.$db->prefix.'topics AS t INNER JOIN '.$db->prefix.'forums AS f ON t.forum_id=f.id WHERE t.id=:id', $data);
		if (!$ps->rowCount())
			message($lang_common['Bad request'], false, '404 Not Found');

		list($subject, $forum_id, $forum_name, $forum_password) = $ps->fetch(PDO::FETCH_NUM);

		if ($forum_password != '')
			check_forum_login_cookie($forum_id, $forum_password);

		// Should we use the internal report handling?
		if ($panther_config['o_report_method'] == '0' || $panther_config['o_report_method'] == '2')
		{
			$insert = array(
				'post_id'	=>	$post_id,
				'topic_id'	=>	$topic_id,
				'forum_id'	=>	$forum_id,
				'reported_by'	=>	$panther_user['id'],
				'created'	=>	time(),
				'message'	=>	$reason,
			);
			
			$db->insert('reports', $insert);
		}

		// Should we email the report?
		if ($panther_config['o_report_method'] == '1' || $panther_config['o_report_method'] == '2')
		{
			// We send it to the complete mailing-list in one swoop
			if ($panther_config['o_mailing_list'] != '')
			{
				// Load the "new report" template
				$mail_tpl = trim(file_get_contents(PANTHER_ROOT.'lang/'.$panther_user['language'].'/mail_templates/new_report.tpl'));

				// The first row contains the subject
				$first_crlf = strpos($mail_tpl, "\n");
				$mail_subject = trim(substr($mail_tpl, 8, $first_crlf-8));
				$mail_message = trim(substr($mail_tpl, $first_crlf));

				$mail_subject = str_replace('<forum_id>', $forum_id, $mail_subject);
				$mail_subject = str_replace('<topic_subject>', $subject, $mail_subject);
				$mail_message = str_replace('<username>', $panther_user['username'], $mail_message);
				$mail_message = str_replace('<post_url>', get_link($panther_url['post'], array($post_id)), $mail_message);
				$mail_message = str_replace('<reason>', $reason, $mail_message);
				$mail_message = str_replace('<board_mailer>', $panther_config['o_board_title'], $mail_message);

				require PANTHER_ROOT.'include/email.php';
				panther_mail($panther_config['o_mailing_list'], $mail_subject, $mail_message);
			}
		}
		
		$update = array(
			'last_report_sent'	=>	time(),
		);
		
		$data = array(
			':id'	=>	$panther_user['id'],
		);

		$db->update('users', $update, 'id=:id', $data);

		redirect(get_link($panther_url['forum'], array($forum_id, url_friendly($forum_name))), $lang_misc['Report redirect']);
	}

	// Fetch some info about the post, the topic and the forum
	$data = array(
		':gid'	=>	$panther_user['g_id'],
		':pid'	=>	$post_id,
	);

	$ps = $db->run('SELECT f.id AS fid, f.forum_name, f.password, t.id AS tid, t.subject, t.archived FROM '.$db->prefix.'posts AS p INNER JOIN '.$db->prefix.'topics AS t ON t.id=p.topic_id INNER JOIN '.$db->prefix.'forums AS f ON f.id=t.forum_id LEFT JOIN '.$db->prefix.'forum_perms AS fp ON (fp.forum_id=f.id AND fp.group_id=:gid) WHERE (fp.read_forum IS NULL OR fp.read_forum=1) AND p.id=:pid', $data);
	if (!$ps->rowCount())
		message($lang_common['Bad request'], false, '404 Not Found');

	$cur_post = $ps->fetch();
	
	if ($cur_post['password'] != '')
		check_forum_login_cookie($cur_post['fid'], $cur_post['password']);

	if ($panther_config['o_censoring'] == '1')
		$cur_post['subject'] = censor_words($cur_post['subject']);
	
	if ($cur_post['archived'] == '1')
		message($lang_misc['Topic archived']);

	$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_misc['Report post']);
	$required_fields = array('req_reason' => $lang_misc['Reason']);
	$focus_element = array('report', 'req_reason');
	define('PANTHER_ACTIVE_PAGE', 'index');
	require PANTHER_ROOT.'header.php';
	$report_tpl = panther_template('report.tpl');
	$search = array(
		'{index_link}' => get_link($panther_url['index']),
		'{index}' => $lang_common['Index'],
		'{forum_link}' => get_link($panther_url['forum'], array($cur_post['fid'], url_friendly($cur_post['forum_name']))),
		'{forum_name}' => panther_htmlspecialchars($cur_post['forum_name']),
		'{post_link}' => get_link($panther_url['post'], array($post_id)),
		'{subject}' => panther_htmlspecialchars($cur_post['subject']),
		'{report_post}' => $lang_misc['Report post'],
		'{form_action}' => get_link($panther_url['report'], array($post_id)),
		'{reason_desc}' => $lang_misc['Reason desc'],
		'{csrf_token}' => generate_csrf_token(),
		'{reason}' => $lang_misc['Reason'],
		'{required}' => $lang_common['Required'],
		'{submit}' => $lang_common['Submit'],
		'{go_back}' => $lang_common['Go back'],
	);

	echo str_replace(array_keys($search), array_values($search), $report_tpl);
	require PANTHER_ROOT.'footer.php';
}
else if ($action == 'subscribe')
{
	if ($panther_user['is_guest'])
		message($lang_common['No permission'], false, '403 Forbidden');

	$topic_id = isset($_GET['tid']) ? intval($_GET['tid']) : 0;
	$forum_id = isset($_GET['fid']) ? intval($_GET['fid']) : 0;
	if ($topic_id < 1 && $forum_id < 1)
		message($lang_common['Bad request'], false, '404 Not Found');

	if ($topic_id)
	{
		if ($panther_config['o_topic_subscriptions'] != '1')
			message($lang_common['No permission'], false, '403 Forbidden');

		// Make sure the user can view the topic
		$data = array(
			':gid'	=>	$panther_user['g_id'],
			':tid'	=>	$topic_id,
		);

		$ps = $db->run('SELECT t.subject, f.password, f.id AS fid FROM '.$db->prefix.'topics AS t INNER JOIN '.$db->prefix.'forums AS f ON t.forum_id=f.id LEFT JOIN '.$db->prefix.'forum_perms AS fp ON (fp.forum_id=t.forum_id AND fp.group_id=:gid) WHERE (fp.read_forum IS NULL OR fp.read_forum=1) AND t.id=:tid AND t.moved_to IS NULL', $data);
		if (!$ps->rowCount())
			message($lang_common['Bad request'], false, '404 Not Found');
		else
			$cur_topic = $ps->fetch();
		
		if ($cur_topic['password'] != '')
			check_forum_login_cookie($cur_topic['fid'], $cur_topic['password']);
		
		$data = array(
			':id'	=>	$panther_user['id'],
			':tid'	=>	$topic_id,
		);

		$ps = $db->select('topic_subscriptions', 1, $data, 'user_id=:id AND topic_id=:tid');
		if ($ps->rowCount())
			message($lang_misc['Already subscribed topic']);
		
		$insert = array(
			'user_id'	=>	$panther_user['id'],
			'topic_id'	=>	$topic_id,
		);

		$db->insert('topic_subscriptions', $insert);
		redirect(get_link($panther_url['topic'], array($topic_id, url_friendly($cur_topic['subject']))), $lang_misc['Subscribe redirect']);
	}

	if ($forum_id)
	{
		if ($panther_config['o_forum_subscriptions'] != '1')
			message($lang_common['No permission'], false, '403 Forbidden');

		// Make sure the user can view the forum (and if a password is present, they know that too)
		$data = array(
			':gid'	=>	$panther_user['g_id'],
			':fid'	=>	$forum_id,
		);

		$ps = $db->run('SELECT f.forum_name, f.password FROM '.$db->prefix.'forums AS f LEFT JOIN '.$db->prefix.'forum_perms AS fp ON (fp.forum_id=f.id AND fp.group_id=:gid) WHERE (fp.read_forum IS NULL OR fp.read_forum=1) AND f.id=:fid', $data);
		if (!$ps->rowCount())
			message($lang_common['Bad request'], false, '404 Not Found');
		else
			$cur_forum = $ps->fetch();
		
		if ($cur_forum['password'] != '')
			check_forum_login_cookie($forum_id, $cur_post['password']);
		
		$data = array(
			':id'	=>	$panther_user['id'],
			':fid'	=>	$forum_id,
		);

		$ps = $db->select('forum_subscriptions', 1, $data, 'user_id=:id AND forum_id=:fid');
		if ($ps->rowCount())
			message($lang_misc['Already subscribed forum']);

		$insert = array(
			'user_id'	=>	$panther_user['id'],
			'forum_id'	=>	$forum_id,
		);

		$db->insert('forum_subscriptions', $insert);
		redirect(get_link($panther_url['forum'], array($forum_id, url_friendly($cur_forum['forum_name']))), $lang_misc['Subscribe redirect']);
	}
}
else if ($action == 'unsubscribe')
{
	if ($panther_user['is_guest'])
		message($lang_common['No permission'], false, '403 Forbidden');

	$topic_id = isset($_GET['tid']) ? intval($_GET['tid']) : 0;
	$forum_id = isset($_GET['fid']) ? intval($_GET['fid']) : 0;
	if ($topic_id < 1 && $forum_id < 1)
		message($lang_common['Bad request'], false, '404 Not Found');

	if ($topic_id)
	{
		if ($panther_config['o_topic_subscriptions'] != '1')
			message($lang_common['No permission'], false, '403 Forbidden');

		$data = array(
			':id'	=>	$topic_id,
		);
		
		$ps = $db->run('SELECT t.subject, f.password, f.id AS fid FROM '.$db->prefix.'topics AS t INNER JOIN '.$db->prefix.'forums AS f ON t.forum_id=f.id WHERE t.id=:id', $data);
		if (!$ps->rowCount())
			message($lang_common['Bad request']);
		else
			$cur_topic = $ps->fetch();
		
		if ($cur_topic['password'] != '')
			check_forum_login_cookie($cur_topic['fid'], $cur_topic['password']);
		
		$data = array(
			':id'	=>	$panther_user['id'],
			':tid'	=>	$topic_id,
		);

		$ps = $db->select('topic_subscriptions', 1, $data, 'user_id=:id AND topic_id=:tid');
		if (!$ps->rowCount())
			message($lang_misc['Not subscribed topic']);
		
		$data = array(
			':id'	=>	$panther_user['id'],
			':tid'	=>	$topic_id,
		);

		$db->delete('topic_subscriptions', 'user_id=:id AND topic_id=:tid', $data);
		redirect(get_link($panther_url['topic'], array($topic_id, url_friendly($cur_topic['subject']))), $lang_misc['Unsubscribe redirect']);
	}

	if ($forum_id)
	{
		if ($panther_config['o_forum_subscriptions'] != '1')
			message($lang_common['No permission'], false, '403 Forbidden');
		
		$data = array(
			':id'	=>	$forum_id
		);

		$ps = $db->select('forums', 'forum_name, password', $data, 'id=:id');
		if (!$ps->rowCount())
			message($lang_common['Bad request']);
		else
			$cur_forum = $ps->fetch();

		if ($cur_forum['password'] != '')
			check_forum_login_cookie($forum_id, $cur_forum['password']);

		$data = array(
			':id'	=>	$panther_user['id'],
			':fid'	=>	$forum_id,
		);

		$ps = $db->select('forum_subscriptions', 1, $data, 'user_id=:id AND forum_id=:fid');
		if (!$ps->rowCount())
			message($lang_misc['Not subscribed forum']);
		
		$data = array(
			':id'	=>	$panther_user['id'],
			':fid'	=>	$forum_id,
		);

		$db->delete('forum_subscriptions', 'user_id=:id AND forum_id=:fid', $data);
		redirect(get_link($panther_url['forum'], array($forum_id, url_friendly($cur_forum['forum_name']))), $lang_misc['Unsubscribe redirect']);
	}
}
else if ($action == 'leaders')
{
	if ($panther_user['g_read_board'] == '0')
		message($lang_common['No view'], false, '403 Forbidden');
	
	if ($panther_user['g_view_users'] == '0')
		message($lang_common['No permission'], false, '403 Forbidden');

	// Load the userlist.php language file
	require PANTHER_ROOT.'lang/'.$panther_user['language'].'/online.php';
	
	$data = array(
		':admin'	=>	PANTHER_ADMIN,
	);

	$ps = $db->run('SELECT u.id AS id, u.username, u.group_id, o.currently FROM '.$db->prefix.'users AS u INNER JOIN '.$db->prefix.'groups AS g ON u.group_id=g.g_id LEFT JOIN '.$db->prefix.'online AS o ON o.user_id=u.id WHERE u.group_id=:admin OR g.g_admin=1', $data);
	$ps1 = $db->run('SELECT u.id AS id, u.username, u.group_id, o.currently FROM '.$db->prefix.'users AS u INNER JOIN '.$db->prefix.'groups AS g ON u.group_id=g.g_id LEFT JOIN '.$db->prefix.'online AS o ON o.user_id=u.id WHERE g.g_moderator=1 AND g.g_global_moderator=1 AND g.g_admin=0');
	$ps2 = $db->run('SELECT u.id AS id, u.username, u.group_id, o.currently FROM '.$db->prefix.'users AS u INNER JOIN '.$db->prefix.'groups AS g ON u.group_id=g.g_id LEFT JOIN '.$db->prefix.'online AS o ON o.user_id=u.id WHERE g.g_moderator=1 AND g.g_global_moderator!=1 AND g.g_admin=0');
	
	$data = array(
		':id'	=>	$panther_user['g_id'],
	);

	$forums = array();
	$ps3 = $db->run('SELECT f.id AS fid, f.forum_name, f.moderators FROM '.$db->prefix.'categories AS c INNER JOIN '.$db->prefix.'forums AS f ON c.id=f.cat_id LEFT JOIN '.$db->prefix.'forum_perms AS fp ON (fp.forum_id=f.id AND fp.group_id=:id) WHERE fp.read_forum IS NULL OR fp.read_forum=1 ORDER BY c.disp_position, c.id, f.disp_position', $data);
	foreach ($ps3 as $cur_forum)
		$forums[] = $cur_forum;

	define('PANTHER_ACTIVE_PAGE', 'leaders');
	$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_common['User list'], $lang_online['the team']);
	require PANTHER_ROOT.'header.php';

	if ($panther_config['o_users_online'] == '1')
	{
		$online_row_tpl = panther_template('leaders_row_online.tpl');
		$online_tpl = panther_template('leaders_row_online_heading.tpl');
		$search = array(
			'{currently}' => $lang_online['currently 1'],
		);

		$online_tpl = "\n".str_replace(array_keys($search), array_values($search), $online_tpl);
	}
	else
		$online_tpl = $online_row_tpl = '';

	$administrators = $global_mods = $mods = array();
	$leaders_row_tpl = panther_template('leaders_row.tpl');
	foreach ($ps as $user_data)
	{
		if ($user_data['currently'] == '')
			$user_data['currently'] = '-';

		if ($panther_config['o_users_online'] == '1')
		{
			$search = array(
				'{currently}' => generate_user_location($user_data['currently'], $lang_online, $user_data['username']),
			);

			$online_row = "\n".str_replace(array_keys($search), array_values($search), $online_row_tpl);
		}

		$search = array(
			'{username}' => colourize_group($user_data['username'], $user_data['group_id'], $user_data['id']),
			'{all_forums}' => $lang_online['all forums'],
			'{currently}' => $online_row,
		);

		$administrators[] = str_replace(array_keys($search), array_values($search), $leaders_row_tpl);
	}

	$leaders_tpl = panther_template('leaders.tpl');
	$search = array(
		'{group_title}' => $lang_online['admin'],
		'{username}' => $lang_common['Username'],
		'{forums}' => $lang_online['forums'],
		'{online_column}' => $online_tpl,
		'{group_users}' => implode("\n", $administrators),
	);

	echo str_replace(array_keys($search), array_values($search), $leaders_tpl);
	if ($ps1->rowCount())
	{
		foreach ($ps1 as $user_data)
		{
			if ($user_data['currently'] == '')
				$user_data['currently'] = '-';

			if ($panther_config['o_users_online'] == '1')
			{
				$search = array(
					'{currently}' => generate_user_location($user_data['currently'], $lang_online, $user_data['username']),
				);

				$online_row = "\n".str_replace(array_keys($search), array_values($search), $online_row_tpl);
			}

			$search = array(
				'{username}' => colourize_group($user_data['username'], $user_data['group_id'], $user_data['id']),
				'{all_forums}' => $lang_online['all forums'],
				'{currently}' => $online_row,
			);

			$global_mods[] = str_replace(array_keys($search), array_values($search), $leaders_row_tpl);
		}

		$search = array(
			'{group_title}' => $lang_online['global mod'],
			'{username}' => $lang_common['Username'],
			'{forums}' => $lang_online['forums'],
			'{online_column}' => $online_tpl,
			'{group_users}' => implode("\n", $global_mods),
		);

		echo str_replace(array_keys($search), array_values($search), $leaders_tpl);
	}

	if ($ps2->rowCount())
	{
		$forum_tpl = panther_template('leaders_forum_options.tpl');
		foreach ($ps2 as $user_data)
		{
			if ($user_data['currently'] == '')
				$user_data['currently'] = '-';

			$total = 0;
			$mod_forums = array();
			foreach ($forums as $cur_forum)
			{
				$moderators = ($cur_forum['moderators'] != '') ? unserialize($cur_forum['moderators']) : array();
				if (in_array($user_data['id'], $moderators))
				{
					$mod_forums[] = '<option value="'.$cur_forum['fid'].'">'.panther_htmlspecialchars($cur_forum['forum_name']).'</option>';
					++$total;
				}
			}

			$search = array(
				'{action}' => get_link($panther_url['forum_noid']),
				'{location}' => get_link($panther_url['forum'], array("'+this.options[this.selectedIndex].value)+'", 'forum-name')),
				'{total_forums}' => sprintf($lang_online['total forums'], $total),
				'{forum_options}' => implode('', $mod_forums),
			);

			$forums = str_replace(array_keys($search), array_values($search), $forum_tpl);

			if ($panther_config['o_users_online'] == '1')
			{
				$search = array(
					'{currently}' => generate_user_location($user_data['currently'], $lang_online, $user_data['username']),
				);

				$online_row = "\n".str_replace(array_keys($search), array_values($search), $online_row_tpl);
			}

			$search = array(
				'{username}' => colourize_group($user_data['username'], $user_data['group_id'], $user_data['id']),
				'{all_forums}' => $forums,
				'{currently}' => $online_row,
			);

			$global_mods[] = str_replace(array_keys($search), array_values($search), $leaders_row_tpl);
		}

		$search = array(
			'{group_title}' => $lang_online['global mod'],
			'{username}' => $lang_common['Username'],
			'{forums}' => $lang_online['forums'],
			'{online_column}' => $online_tpl,
			'{group_users}' => implode("\n", $global_mods),
		);

		echo str_replace(array_keys($search), array_values($search), $leaders_tpl);
	}

	require PANTHER_ROOT.'footer.php';
}
else
	message($lang_common['Bad request'], false, '404 Not Found');