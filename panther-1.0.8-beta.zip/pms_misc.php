<?php
/**
 * Copyright (C) 2015 Panther (https://www.pantherforum.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/');
	require PANTHER_ROOT.'include/common.php';
}

if ($panther_user['g_read_board'] == '0')
	message($lang_common['No view'], false, '403 Forbidden');

if ($panther_user['is_guest'])
	message($lang_common['No permission']);

if ($panther_config['o_private_messaging'] == '0')
	message($lang_common['No permission']);

require PANTHER_ROOT.'lang/'.$panther_user['language'].'/pms.php';

// Load the post.php language file
require PANTHER_ROOT.'lang/'.$panther_user['language'].'/post.php';

$action = isset($_GET['action']) ? panther_htmlspecialchars($_GET['action']) : '';
$pid = isset($_GET['pid']) ? intval($_GET['pid']) : 0;

if ($action == 'edit')
{
	if ($pid < 1)
		message($lang_common['Bad request']);
	
	$data = array(
		':id'	=>	$pid,
		':uid'	=>	$panther_user['id']
	);

	$ps = $db->run('SELECT c.subject, c.first_post_id, c.id, cd.folder_id, m.message, m.hide_smilies, m.poster_id FROM '.$db->prefix.'messages AS m INNER JOIN '.$db->prefix.'conversations AS c ON m.topic_id=c.id INNER JOIN '.$db->prefix.'pms_data AS cd ON c.id=cd.topic_id WHERE m.id=:id AND cd.user_id=:uid AND cd.deleted=0', $data);
	if (!$ps->rowCount())
		message($lang_common['Bad request']);	// We've deleted it
	else
		$cur_topic = $ps->fetch();
	
	if (($panther_user['g_edit_posts'] == '0' || $cur_topic['poster_id'] != $panther_user['id']) && !$panther_user['is_admmod'])
		message($lang_common['No permission']);
	
	if ($cur_topic['folder_id'] == 3)	// Then we've archived it
		message($lang_common['Bad request']);
	
	$can_edit_subject = $pid == $cur_topic['first_post_id'] && $panther_user['g_edit_subject'] == '1';

	if (isset($_POST['form_sent']))
	{
		confirm_referrer('pms_misc.php');
		
		// If it's a topic it must contain a subject
		if ($can_edit_subject)
		{
			$subject = panther_trim($_POST['req_subject']);

			if ($panther_config['o_censoring'] == '1')
				$censored_subject = panther_trim(censor_words($subject));

			if ($subject == '')
				$errors[] = $lang_post['No subject'];
			else if ($panther_config['o_censoring'] == '1' && $censored_subject == '')
				$errors[] = $lang_post['No subject after censoring'];
			else if (panther_strlen($subject) > 70)
				$errors[] = $lang_post['Too long subject'];
			else if ($panther_config['p_subject_all_caps'] == '0' && is_all_uppercase($subject) && !$panther_user['is_admmod'])
				$errors[] = $lang_post['All caps subject'];
		}

		// Clean up message from POST
		$message = panther_linebreaks(panther_trim($_POST['req_message']));

		// Here we use strlen() not panther_strlen() as we want to limit the post to PANTHER_MAX_POSTSIZE bytes, not characters
		if (strlen($message) > PANTHER_MAX_POSTSIZE)
			$errors[] = sprintf($lang_post['Too long message'], forum_number_format(PANTHER_MAX_POSTSIZE));
		else if ($panther_config['p_message_all_caps'] == '0' && is_all_uppercase($message) && !$panther_user['is_admmod'])
			$errors[] = $lang_post['All caps message'];

		// Validate BBCode syntax
		if ($panther_config['p_message_bbcode'] == '1')
		{
			require PANTHER_ROOT.'include/parser.php';
			$message = preparse_bbcode($message, $errors);
		}

		if (empty($errors))
		{
			if ($message == '')
				$errors[] = $lang_post['No message'];
			else if ($panther_config['o_censoring'] == '1')
			{
				// Censor message to see if that causes problems
				$censored_message = panther_trim(censor_words($message));

				if ($censored_message == '')
					$errors[] = $lang_post['No message after censoring'];
			}
		}

		$hide_smilies = isset($_POST['hide_smilies']) ? '1' : '0';
		
		// Replace four-byte characters (MySQL cannot handle them)
		$message = strip_bad_multibyte_chars($message);
		
		if (empty($errors))
		{
			if ($can_edit_subject)
			{
				$update = array(
					'subject'	=>	$subject,
				);

				$data = array(
					':id'	=>	$cur_topic['id'],
				);

				// Update the topic and any redirect topics
				$db->update('conversations', $update, 'id=:id', $data);
			}

			$update = array(
				'message'	=>	$message,
				'hide_smilies'	=>	$hide_smilies,
			);
			
			if (!isset($_POST['silent']) || !$panther_user['is_admmod'])
			{
				$update['edited'] = time();
				$update['edited_by'] = $panther_user['username'];
			}
			
			$data = array(
				':id'	=>	$pid,
			);

			// Update the post
			$db->update('messages', $update, 'id=:id', $data);
			redirect(get_link($panther_url['pms_post'], array($pid)), $lang_post['Edit redirect']);
		}
	}
	
	// Tell header.php we should use the editor
	define('POSTING', 1);

	$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_common['PM'], $lang_pm['Edit message']);
	$required_fields = array('req_subject' => $lang_common['Subject'], 'req_message' => $lang_common['Message']);
	$focus_element = array('edit', 'req_message');
	define('PANTHER_ALLOW_INDEX', 1);
	define('PANTHER_ACTIVE_PAGE', 'index');
	require PANTHER_ROOT.'header.php';

	$cur_index = 1;
	if (!empty($errors))
	{
		$form_errors = array();
		foreach ($errors as $cur_error)
			$form_errors[] = "\t\t\t\t".'<li><strong>'.$cur_error.'</strong></li>'."\n";

		$error_tpl = panther_template('post_errors.tpl');
		$search = array(
			'{errors}' => $lang_post['Post errors'],
			'{errors_info}' => $lang_post['Post errors info'],
			'{error_list}' => implode("\n", $form_errors),
		);
		
		$error_tpl = "\n".str_replace(array_keys($search), array_values($search), $error_tpl);
	}
	else
		$error_tpl = '';
	
	$checkboxes = array();
	if ($panther_config['o_smilies'] == '1')
	{
		if (isset($_POST['hide_smilies']) || $cur_topic['hide_smilies'] == '1')
			$checkboxes[] = '<label><input type="checkbox" name="hide_smilies" value="1" checked="checked" tabindex="'.($cur_index++).'" />'.$lang_post['Hide smilies'].'<br /></label>';
		else
			$checkboxes[] = '<label><input type="checkbox" name="hide_smilies" value="1" tabindex="'.($cur_index++).'" />'.$lang_post['Hide smilies'].'<br /></label>';
	}

	if ($panther_user['is_admmod'])
	{
		if ((isset($_POST['form_sent']) && isset($_POST['silent'])) || !isset($_POST['form_sent']))
			$checkboxes[] = '<label><input type="checkbox" id="silent_edit" name="silent" value="1" tabindex="'.($cur_index++).'" checked="checked" />'.$lang_post['Silent edit'].'<br /></label>';
		else
			$checkboxes[] = '<label><input type="checkbox" id="silent_edit" name="silent" value="1" tabindex="'.($cur_index++).'" />'.$lang_post['Silent edit'].'<br /></label>';
	}

	if ($can_edit_subject)
	{
		$subject_tpl = panther_template('pm_subject.tpl');
		$search = array(
			'{subject}' => $lang_common['Subject'],
			'{required}' => $lang_common['Required'],
			'{index_1}' => $cur_index++,
			'{subject_value}' => panther_htmlspecialchars(isset($_POST['req_subject']) ? $_POST['req_subject'] : $cur_topic['subject']),
		);
		
		$subject_tpl = "\n".str_replace(array_keys($search), array_values($search), $subject_tpl);
	}
	else
		$subject_tpl = '';

	if (!empty($checkboxes))
	{
		$checkbox_tpl = panther_template('pm_checkboxes.tpl');
		$search = array(
			'{options}' => $lang_common['Options'],
			'{checkboxes}' => implode("\n\t\t\t\t\t\t\t", $checkboxes),
		);
		
		$checkbox_tpl = "\n".str_replace(array_keys($search), array_values($search), $checkbox_tpl);
	}
	else
		$checkbox_tpl = '';

	$pm_tpl = panther_template('pms_edit.tpl');
	$search = array(
		'{pm_menu}' => generate_pm_menu('send'),
		'{post_errors}' => $error_tpl,
		'{index_link}' => get_link($panther_url['index']),
		'{index}' => $lang_common['Index'],
		'{inbox}' => get_link($panther_url['inbox']),
		'{pm}' => $lang_common['PM'],
		'{post_link}' => get_link($panther_url['pms_post'], array($pid)),
		'{subject}' => panther_htmlspecialchars($cur_topic['subject']),
		'{edit_message}' => $lang_pm['Edit message'],
		'{edit_post}' => $lang_post['Edit post'],
		'{form_action}' => get_link($panther_url['pms_edit'], array($pid)),
		'{csrf_token}' => generate_csrf_token(),
		'{edit_post_legend}' => $lang_post['Edit post legend'],
		'{subject_field}' => $subject_tpl,
		'{message}' => $lang_common['Message'],
		'{required}' => $lang_common['Required'],
		'{index_1}' => $cur_index++,
		'{message}' => panther_htmlspecialchars(isset($_POST['req_message']) ? $message : $cur_topic['message']),
		'{bbcode_help}' => get_link($panther_url['help'], array('bbcode')),
		'{bbcode}' => $lang_common['BBCode'],
		'{bbcode_onoff}' => ($panther_config['p_message_bbcode'] == '1') ? $lang_common['on'] : $lang_common['off'],
		'{url_help}' => get_link($panther_url['help'], array('url')),
		'{url}' => $lang_common['url tag'],
		'{url_onoff}' => ($panther_config['p_message_bbcode'] == '1' && $panther_user['g_post_links'] == '1') ? $lang_common['on'] : $lang_common['off'],
		'{img_help}' => get_link($panther_url['help'], array('img')),
		'{img}' => $lang_common['img tag'],
		'{img_onoff}' => ($panther_config['p_message_bbcode'] == '1' && $panther_config['p_message_img_tag'] == '1') ? $lang_common['on'] : $lang_common['off'],
		'{smilies_help}' => get_link($panther_url['help'], array('smilies')),
		'{smilies}' => $lang_common['Smilies'],
		'{smilies_onoff}' => ($panther_config['o_smilies'] == '1') ? $lang_common['on'] : $lang_common['off'],
		'{checkboxes}' => $checkbox_tpl,
		'{submit}' => $lang_common['Submit'],
		'{go_back}' => $lang_common['Go back'],
	);

	echo str_replace(array_keys($search), array_values($search), $pm_tpl);
	require PANTHER_ROOT.'footer.php';
}
elseif ($action == 'delete')
{
	if ($pid < 1)
		message($lang_common['Bad request']);
	
	$data = array(
		':id'	=>	$pid,
		':uid'	=>	$panther_user['id']
	);

	$ps = $db->run('SELECT c.subject, c.id AS tid, cd.folder_id, m.poster, m.posted, c.first_post_id, c.num_replies, m.message, m.hide_smilies, m.poster_id FROM '.$db->prefix.'messages AS m INNER JOIN '.$db->prefix.'conversations AS c ON m.topic_id=c.id INNER JOIN '.$db->prefix.'pms_data AS cd ON c.id=cd.topic_id WHERE m.id=:id AND cd.user_id=:uid AND cd.deleted=0', $data);
	if (!$ps->rowCount())
		message($lang_common['Bad request']);	// We've deleted it
	else
		$cur_topic = $ps->fetch();
	
	$is_topic_post = ($pid == $cur_topic['first_post_id']) ? true : false;
	
	if ($cur_topic['poster_id'] != $panther_user['id'] && !$panther_user['is_admmod'])
		message($lang_common['No permission']);
	
	if ($cur_topic['folder_id'] == 3)	// Then we've archived it
		message($lang_common['Bad request']);
	
	require PANTHER_ROOT.'lang/'.$panther_user['language'].'/delete.php';
	
	if (isset($_POST['form_sent']))
	{
		confirm_referrer('pms_misc.php');
		if ($is_topic_post)	// Then we delete the entire topic only for us (unless everyone else has already)
		{
			$data = array(
				':tid'	=>	$cur_topic['tid'],
				':uid'	=>	$panther_user['id'],
			);
			
			$ps = $db->run('SELECT 1 FROM '.$db->prefix.'conversations AS c INNER JOIN '.$db->prefix.'pms_data AS cd ON c.id=cd.topic_id WHERE cd.topic_id=:tid AND cd.deleted=0 AND cd.user_id!=:uid', $data);
			if (!$ps->rowCount())	// Then there is no one else in the conversation
			{
				$data = array(
					':id'	=>	$cur_topic['tid'],
				);

				$db->delete('conversations', 'id=:id', $data);
				
				$data = array(
					':id'	=>	$pid,
				);

				$db->delete('messages', 'id=:id', $data);
			}
			else
			{
				$update = array(
					'deleted'	=>	1,
				);
				
				$db->update('pms_data', $update, 'topic_id=:tid AND user_id=:uid', $data);
			}
			
			$data = array(
				':amount'	=>	($cur_topic['num_replies'] + 1),	// Make sure we include the topic post
				':id'	=>	$panther_user['id'],
			);

			$db->run('UPDATE '.$db->prefix.'users SET num_pms=num_pms-:amount WHERE id=:id', $data);
			$redirect_msg = $lang_delete['Topic del redirect'];
			$link = get_link($panther_url['inbox']);
		}
		else	// Delete this post for all users
		{
			$data = array(
				':id'	=>	$pid,
			);

			$ps = $db->run('SELECT cd.user_id FROM '.$db->prefix.'messages AS m INNER JOIN '.$db->prefix.'conversations AS c ON m.topic_id=c.id INNER JOIN '.$db->prefix.'pms_data AS cd ON c.id=cd.topic_id WHERE m.id=:id AND cd.deleted=0', $data);
			if (!$ps->rowCount())	// Then we're the only person left
			{
				$data = array(
					':id'	=>	$pid,
				);

				$db->delete('messages', 'id=:id', $data);
				$data = array(
					':id'	=>	$panther_user['id'],
				);

				$db->run('UPDATE '.$db->prefix.'users SET num_pms=num_pms-1 WHERE id=:id', $data);
			}
			else
			{
				$ps->setFetchMode(PDO::FETCH_COLUMN, 0);
				foreach ($ps as $uid)
				{
					$data = array(
						':id'	=>	$uid,
					);
					
					$db->run('UPDATE '.$db->prefix.'users SET num_pms=num_pms-1 WHERE id=:id', $data);
				}
				
				$data = array(
					':id'	=>	$pid,
				);

				$db->delete('messages', 'id=:id', $data);
			}
			
			$data = array(
				':id'	=>	$cur_topic['tid'],
			);
			
			$ps = $db->select('messages', 'poster, posted, id', $data, 'topic_id=:id', 'id DESC LIMIT 1');
			$cur_post = $ps->fetch();
				
			$data = array(
				':poster'	=>	$cur_post['poster'],
				':posted'	=>	$cur_post['posted'],
				':last'		=>	$cur_post['id'],
				':id'		=>	$cur_topic['tid'],
			);
				
			$db->run('UPDATE '.$db->prefix.'conversations SET num_replies=num_replies-1, poster=:poster, last_post=:posted, last_post_id=:last WHERE id=:id', $data);

			$link = 'pms_view.php?pid='.$cur_post['id'].'#p'.$cur_post['id'];
			$redirect_msg = $lang_delete['Post del redirect'];
		}
		
		redirect($link, $redirect_msg);
	}
	
	$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_common['PM'], $lang_pm['Delete message']);
	define('PANTHER_ALLOW_INDEX', 1);
	define('PANTHER_ACTIVE_PAGE', 'index');
	require PANTHER_ROOT.'header.php';
	
	require PANTHER_ROOT.'include/parser.php';
	$cur_topic['message'] = parse_message($cur_topic['message'], $cur_topic['hide_smilies']);
	
	$del_tpl = panther_template('pm_delete.tpl');
	$search = array(
		'{delete_message}' => $lang_pm['Delete message'],
		'{form_action}' => get_link($panther_url['pms_delete'], array($pid)),
		'{csrf_token}' => generate_csrf_token(),
		'{poster_info}' => sprintf($is_topic_post ? $lang_delete['Topic by'] : $lang_delete['Reply by'], '<strong>'.panther_htmlspecialchars($cur_topic['poster']).'</strong>', format_time($cur_topic['posted'])),
		'{topic_post_info}' => ($is_topic_post) ? '<strong>'.$lang_delete['Topic warning'].'</strong>' : '<strong>'.$lang_delete['Warning'].'</strong>',
		'{delete_info}' => $lang_delete['Delete info'],
		'{delete}' => $lang_delete['Delete'],
		'{go_back}' => $lang_common['Go back'],
		'{poster}' => panther_htmlspecialchars($cur_topic['poster']),
		'{posted}' => format_time($cur_topic['posted']),
		'{message}' => $cur_topic['message'],
	);

	echo str_replace(array_keys($search), array_values($search), $del_tpl);
	require PANTHER_ROOT.'footer.php';
}
else if ($action == 'blocked')
{
	if (isset($_POST['add_block']))
	{
		$errors = array();
		$username = isset($_POST['req_username']) ? panther_trim($_POST['req_username']) : '';

		if ($username == $panther_user['username'])
			$errors[] = $lang_pm['No block self'];

		$data = array(
			':username'	=>	$username,
		);

		$ps = $db->select('users', 'group_id, id', $data, 'username=:username');
		if (!$ps->rowCount() || $username == $lang_common['Guest'])
			$errors[] = sprintf($lang_pm['No user x'], panther_htmlspecialchars($username));
		else
			list($group_id, $uid) = $ps->fetch(PDO::FETCH_NUM);

		if (empty($errors))
		{
			if ($panther_groups[$group_id]['g_id'] == '1')
				$errors[] = sprintf($lang_pm['User is admin'], panther_htmlspecialchars($username));
			elseif ($panther_groups[$group_id]['g_moderator'] == '1')
				$errors[] = sprintf($lang_pm['User is mod'], panther_htmlspecialchars($username));
				
			$data = array(
				':id'	=>	$uid,
			);
				
			$ps = $db->select('blocks', 1, $data, 'block_id=:id');
			if ($ps->rowCount())
				$errors[] = $lang_pm['Already blocked'];
		}

		if (empty($errors))
		{
			$insert = array(
				'user_id'	=>	$panther_user['id'],
				'block_id'	=>	$uid,
			);
			
			$db->insert('blocks', $insert);
			redirect(get_link($panther_url['pms_blocked']), $lang_pm['Block added redirect']);
		}
	}
	else if (isset($_POST['remove']))
	{
		$id = intval(key($_POST['remove']));
		$data = array(
			':id'	=>	$id,
			':uid'	=>	$panther_user['id'],
		);

		// Before we do anything, check we blocked this user
		$ps = $db->select('blocks', 1, $data, 'id=:id AND user_id=:uid');
		if (!$ps->rowCount())
			message($lang_common['No permission']);

		$db->delete('blocks', 'id=:id AND user_id=:uid', $data);
		redirect(get_link($panther_url['pms_blocked']), $lang_pm['Block del redirect']);
	}

	$data = array(
		':uid'	=>	$panther_user['id'],
	);

	$ps = $db->run('SELECT b.id, b.block_id, u.username, u.group_id FROM '.$db->prefix.'blocks AS b INNER JOIN '.$db->prefix.'users AS u ON b.block_id=u.id WHERE b.user_id=:uid', $data);
	
	$required_fields = array('req_username' => $lang_common['Username']);
	$focus_element = array('block', 'req_username');
	
	$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_common['PM'], $lang_pm['My blocked']);
	define('PANTHER_ALLOW_INDEX', 1);
	define('PANTHER_ACTIVE_PAGE', 'index');
	require PANTHER_ROOT.'header.php';
	
	echo generate_pm_menu('blocked');

	// If there are errors, we display them
	if (!empty($errors))
	{
		$form_errors = array();
		foreach ($errors as $cur_error)
			$form_errors[] = "\t\t\t\t".'<li><strong>'.$cur_error.'</strong></li>'."\n";

		$error_tpl = panther_template('inline_errors.tpl');
		$search = array(
			'{errors}' => $lang_pm['Block errors'],
			'{errors_info}' => $lang_pm['Block errors info'],
			'{error_list}' => implode("\n", $form_errors),
		);
		
		$error_tpl = str_replace(array_keys($search), array_values($search), $error_tpl).'<br />'."\n";
	}
	else
		$error_tpl = '';

	if ($ps->rowCount())
	{
		$blocked_rows = array();
		$blocked_row_tpl = panther_template('pm_blocked_row.tpl');
		foreach ($ps as $cur_block)
		{
			$data = array(
				':id'	=>	$cur_block['block_id'],
			);
			
			$search = array(
				'{name}' => colourize_group($cur_block['username'], $cur_block['group_id'], $cur_block['block_id']),
				'{id}' => $cur_block['id'],
				'{remove}' => $lang_pm['Remove'],
			);
			
			$blocked_rows[] = str_replace(array_keys($search), array_values($search), $blocked_row_tpl);
		}

		$blocked_tpl = panther_template('blocked_content.tpl');
		$search = array(
			'{form_action}' => get_link($panther_url['pms_blocked']),
			'{my_folders}' => $lang_pm['My blocked'],
			'{username}' => $lang_common['Username'],
			'{actions}' => $lang_pm['Actions'],
			'{blocked_content}' => implode("\n", $blocked_rows),
		);

		$blocked_tpl = str_replace(array_keys($search), array_values($search), $blocked_tpl);
	}
	else
		$blocked_tpl = '';

	$pm_tpl = panther_template('pm_blocked.tpl');
	$search = array(
		'{errors}' => $error_tpl,
		'{my_blocked}' => $lang_pm['My blocked'],
		'{form_action}' => get_link($panther_url['pms_blocked']),
		'{add_block}' => $lang_pm['Add block'],
		'{username}' => $lang_common['Username'],
		'{username_value}' => (isset($username)) ? panther_htmlspecialchars($username) : '',
		'{blocked_users}' => $blocked_tpl,
		'{add}' => $lang_pm['Add'],
	);

	echo str_replace(array_keys($search), array_values($search), $pm_tpl);
	require PANTHER_ROOT.'footer.php';	
}
else if ($action == 'folders')
{
	if (isset($_POST['add_folder']))
	{
		$errors = array();
		$folder = isset($_POST['req_folder']) ? panther_trim($_POST['req_folder']) : '';
		
		if ($panther_config['o_censoring'] == '1')
			$censored_folder = panther_trim(censor_words($folder));

		if ($folder == '')
			$errors[] = $lang_pm['No folder name'];
		else if (panther_strlen($folder) < 4)
			$errors[] = $lang_pm['Folder too short'];
		else if (panther_strlen($folder) > 30)
			$errors[] = $lang_pm['Folder too long'];
		else if ($panther_config['o_censoring'] == '1' && $folder == '')
			$errors[] = $lang_pm['No folder after censoring'];
		
		$data = array(
			':uid'	=>	$panther_user['id'],
		);

		if ($panther_user['g_pm_folder_limit'] != 0)
		{
			$ps = $db->select('folders', 'COUNT(id)', $data, 'user_id=:uid');
			$num_folders = $ps->fetchColumn();
			
			if ($num_folders >= $panther_user['g_pm_folder_limit'])
				$errors[] = sprintf($lang_pm['Folder limit'], $panther_user['g_pm_folder_limit']);
		}
		
		if (empty($errors))
		{
			$insert = array(
				'user_id'	=>	$panther_user['id'],
				'name'		=>	$folder,
			);
			
			$db->insert('folders', $insert);
			redirect(get_link($panther_url['pms_folders']), $lang_pm['Folder added']);
		}
	}
	else if (isset($_POST['update']))
	{
		$id = intval(key($_POST['update']));
		
		$errors = array();
		$folder = panther_trim($_POST['folder'][$id]);
		
		if ($panther_config['o_censoring'] == '1')
			$censored_folder = panther_trim(censor_words($folder));

		if ($folder == '')
			$errors[] = $lang_pm['No folder name'];
		else if (panther_strlen($folder) < 4)
			$errors[] = $lang_pm['Folder too short'];
		else if (panther_strlen($folder) > 30)
			$errors[] = $lang_pm['Folder too long'];
		else if ($panther_config['o_censoring'] == '1' && $folder == '')
			$errors[] = $lang_pm['No folder after censoring'];
		
		if (empty($errors))
		{
			$update = array(
				'name'	=>	$folder,
			);
			
			$data = array(
				':id'	=>	$id,
				':uid'	=>	$panther_user['id'],
			);

			$db->update('folders', $update, 'id=:id AND user_id=:uid', $data);
			redirect(get_link($panther_url['pms_folders']), $lang_pm['Folder edit redirect']);
		}
	}
	else if (isset($_POST['remove']))
	{
		$id = intval(key($_POST['remove']));
		$data = array(
			':id'	=>	$id,
			':uid'	=>	$panther_user['id'],
		);

		// Before we do anything, check we own this box
		$ps = $db->select('folders', 1, $data, 'id=:id AND user_id=:uid');
		if (!$ps->rowCount())
			message($lang_common['No permission']);

		$update = array(
			'folder_id'	=>	2,	// Send all potential conversations in this box back to the inbox upon deletion
		);

		$update_data = array(
			':id'	=>	$id,
		);

		$db->update('pms_data', $update, 'folder_id=:id', $update_data);
		$db->delete('folders', 'id=:id AND user_id=:uid', $data);
		redirect(get_link($panther_url['pms_folders']), $lang_pm['Folder del redirect']);
	}

	$data = array(
		':uid'	=>	$panther_user['id'],
	);

	$ps = $db->select('folders', 'name, id', $data, 'user_id=:uid');
	
	$required_fields = array('req_folder' => $lang_pm['Folder']);
	$focus_element = array('folder', 'req_folder');
	
	$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_common['PM'], $lang_pm['My folders 2']);
	define('PANTHER_ALLOW_INDEX', 1);
	define('PANTHER_ACTIVE_PAGE', 'index');
	require PANTHER_ROOT.'header.php';
	
	echo generate_pm_menu('folders');

	if (!empty($errors))
	{
		$form_errors = array();
		foreach ($errors as $cur_error)
			$form_errors[] = "\t\t\t\t".'<li><strong>'.$cur_error.'</strong></li>'."\n";

		$error_tpl = panther_template('inline_errors.tpl');
		$search = array(
			'{errors}' => $lang_pm['Folder errors'],
			'{errors_info}' => $lang_pm['Folder errors info'],
			'{error_list}' => implode("\n", $form_errors),
		);

		$error_tpl = str_replace(array_keys($search), array_values($search), $error_tpl).'<br />'."\n";
	}
	else
		$error_tpl = '';

	if ($ps->rowCount())
	{
		$folder_rows = array();
		$folder_row_tpl = panther_template('pm_folder_row.tpl');
		foreach ($ps as $cur_folder)
		{
			$search = array(
				'{name}' => panther_htmlspecialchars($cur_folder['name']),
				'{id}' => $cur_folder['id'],
				'{update}' => $lang_pm['Update'],
				'{remove}' => $lang_pm['Remove'],
			);

			$folder_rows[] = str_replace(array_keys($search), array_values($search), $folder_row_tpl);
		}

		$folder_tpl = panther_template('folders_content.tpl');
		$search = array(
			'{folder_name}' => $lang_pm['Folder name'],
			'{form_action}' => get_link($panther_url['pms_folders']),
			'{my_folders}' => $lang_pm['My folders'],
			'{username}' => $lang_common['Username'],
			'{actions}' => $lang_pm['Actions'],
			'{folder_content}' => implode("\n", $folder_rows),
		);

		$folder_tpl = str_replace(array_keys($search), array_values($search), $folder_tpl);
	}
	else
		$folder_tpl = '';

	$pm_tpl = panther_template('pm_folders.tpl');
	$search = array(
		'{errors}' => $error_tpl,
		'{my_folders}' => $lang_pm['My folders 2'],
		'{form_action}' => get_link($panther_url['pms_folders']),
		'{add_folder}' => $lang_pm['Add folder'],
		'{folder_name}' => $lang_pm['Folder name'],
		'{folder_value}' => (isset($folder)) ? panther_htmlspecialchars($folder) : '',
		'{folder_content}' => $folder_tpl,
		'{add}' => $lang_pm['Add'],
	);

	echo str_replace(array_keys($search), array_values($search), $pm_tpl);
	require PANTHER_ROOT.'footer.php';
}
else
	message($lang_common['Bad request']);