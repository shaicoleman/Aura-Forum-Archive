<?php
/**
 * Copyright (C) 2015 Panther (https://www.pantherforum.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/');
	require PANTHER_ROOT.'include/common.php';
}

if ($panther_user['g_read_board'] == '0')
	message($lang_common['No view'], false, '403 Forbidden');

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($id < 1)
	message($lang_common['Bad request'], false, '404 Not found');
	
// Fetch some info about the topic and/or the forum
$data = array(
	':gid'	=>	$panther_user['g_id'],
	':tid'	=>	$id,
);

$ps = $db->run('SELECT f.id AS fid, f.forum_name, f.redirect_url, f.password, t.poster, t.subject, t.approved, f.moderators FROM '.$db->prefix.'topics AS t INNER JOIN '.$db->prefix.'forums AS f ON f.id=t.forum_id LEFT JOIN '.$db->prefix.'forum_perms AS fp ON (fp.forum_id=f.id AND fp.group_id=:gid) WHERE (fp.read_forum IS NULL OR fp.read_forum=1) AND t.id=:tid', $data);
if (!$ps->rowCount())
	message($lang_common['Bad request'], false, '404 Not found');
	
$cur_posting = $ps->fetch();

$mods_array = ($cur_posting['moderators'] != '') ? unserialize($cur_posting['moderators']) : array();
$is_admmod = ($panther_user['is_admin'] || ($panther_user['g_moderator'] == '1' && $panther_user['g_global_moderator'] ||  array_key_exists($panther_user['username'], $mods_array))) ? true : false;

if ($panther_config['o_polls'] == '0' || (!$is_admmod && ($panther_user['g_post_polls'] == '0' || $cur_posting['poster'] != $panther_user['username'])))
	message($lang_common['No permission'], false, '403 Forbidden');

if ($cur_posting['redirect_url'] != '')
	message($lang_common['Bad request']);

if ($cur_posting['password'] != '')
		check_forum_login_cookie($cur_posting['fid'], $cur_posting['password']);

require PANTHER_ROOT.'lang/'.$panther_user['language'].'/poll.php';
require PANTHER_ROOT.'lang/'.$panther_user['language'].'/post.php';

if (isset($_POST['form_sent']))
{
	// Start with a clean slate
	$errors = array();

	$question = isset($_POST['req_question']) ? panther_trim($_POST['req_question']) : '';
	$options = isset($_POST['options']) && is_array($_POST['options']) ? array_map('panther_trim', $_POST['options']) : array();
	$type = isset($_POST['type']) ? 2 : 1;

	if ($question == '')
		$errors[] = $lang_poll['No question'];
	else if (panther_strlen($question) > 70)
		$errors[] = $lang_poll['Too long question'];
	else if ($panther_config['p_subject_all_caps'] == '0' && is_all_uppercase($question) && !$panther_user['is_admmod'])
		$errors[] = $lang_poll['All caps question'];

	if (empty($options))
		$errors[] = $lang_poll['No options'];

	$option_data = array();
	for ($i = 0; $i <= $panther_config['o_max_poll_fields']; $i++)
	{
		if (!empty($errors))
			break;

		if (panther_strlen($options[$i]) > 55)
			$errors[] = $lang_poll['Too long option'];
		else if ($panther_config['p_subject_all_caps'] == '0' && is_all_uppercase($options[$i]) && !$panther_user['is_admmod'])
			$errors[] = $lang_poll['All caps option'];
		else if ($options[$i] != '')
			$option_data[] = $options[$i];
	}

	if (count($option_data) < 2)
		$errors[] = $lang_poll['Low options'];

	$now = time();

	// Did everything go according to plan?
	if (empty($errors) && !isset($_POST['preview']))
	{
		$update = array(
			'question'	=>	$question,
		);

		$data = array(
			':id'	=>	$id,
		);

		$db->update('topics', $update, 'id=:id', $data);
		$insert = array(
			'topic_id'	=>	$id,
			'options'	=>	serialize($option_data),
			'type'		=>	$type,
		);

		$db->insert('polls', $insert);
		$new_pid = $db->lastInsertId($db->prefix.'polls');

		// Make sure we actually have a topic to go back to
		if ($cur_posting['approved'] == '0')
			redirect(get_link($panther_url['forum'], array($cur_posting['fid'], url_friendly($cur_posting['forum_name']))), $lang_post['Topic moderation redirect']);
		else
			redirect(get_link($panther_url['topic'], array($id, url_friendly($cur_posting['subject']))), $lang_post['Post redirect']);
	}
}

$cur_index = 1; 
$required_fields = array('req_question' => $lang_poll['Question'], 'req_subject' => $lang_common['Subject'], 'req_message' => $lang_common['Message']);
$focus_element = array('post');

if (!$panther_user['is_guest'])
	$focus_element[] = 'req_question';
else
{
	$required_fields['req_username'] = $lang_post['Guest name'];
	$focus_element[] = 'req_question';
}

$inputs = array();
for ($i = 0; $i <= $panther_config['o_max_poll_fields'] ; $i++)
{
	// Make sure this is indeed a valid option
	if (isset($option_data[$i]) && $option_data[$i] != '')
	{
		if (isset($_POST['preview']))
			$inputs[] = '<br />'.($type == 1 ? '<input name="vote" type="radio" value="'.$i.'" />' : '<input type="checkbox" />').' <span>'.panther_htmlspecialchars($option_data[$i]).'</span><br />';
	}
	else if (!isset($_POST['preview']))
		$inputs[] = '<label><strong>'.$lang_poll['Option'].'</strong><br /> <input type="text" name="options['.$i.']" value="'.((isset($options[$i])) ? panther_htmlspecialchars($options[$i]) : '').'" size="60" maxlength="55" tabindex="'.$cur_index++.'" /><br /></label>';
}

$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), panther_htmlspecialchars($lang_post['Post new topic']));
define('PANTHER_ACTIVE_PAGE', 'index');
require PANTHER_ROOT.'header.php';

// If there are errors, we display them
if (!empty($errors))
{
	$form_errors = array();
	foreach ($errors as $cur_error)
		$form_errors[] = "\t\t\t\t".'<li><strong>'.$cur_error.'</strong></li>'."\n";

	$error_tpl = panther_template('inline_errors.tpl');
	$search = array(
		'{errors}' => $lang_post['Post errors'],
		'{errors_info}' => $lang_post['Post errors info'],
		'{error_list}' => implode("\n", $form_errors),
	);

	$error_tpl = str_replace(array_keys($search), array_values($search), $error_tpl);
}
else if (isset($_POST['preview']))
{
	$preview_tpl = panther_template('poll_preview.tpl');
	$search = array(
		'{preview}' => $lang_poll['Poll preview'],
		'{inputs}' => implode("\n\t\t\t\t\t\t", $inputs),
	);	
	
	$preview_tpl = str_replace(array_keys($search), array_values($search), $preview_tpl);
	$error_tpl = panther_template('post_preview.tpl');
	$search = array(
		'{question}' => panther_htmlspecialchars($question),
		'{message}' => $preview_tpl,
	);

	$error_tpl = str_replace(array_keys($search), array_values($search), $error_tpl);
}
else
	$error_tpl = '';

$poll_tpl = panther_template('add_poll.tpl');
$search = array(
	'{index_link}' => get_link($panther_url['index']),
	'{index}' => $lang_common['Index'],
	'{forum_link}' => get_link($panther_url['forum'], array($cur_posting['fid'], url_friendly($cur_posting['forum_name']))),
	'{forum_name}' => panther_htmlspecialchars($cur_posting['forum_name']),
	'{post_new_topic}' => $lang_post['Post new topic'],
	'{post_errors}' => $error_tpl,
	'{post_new_topic}' => $lang_post['Post new topic'],
	'{form_action}' => get_link($panther_url['poll_add'], array($id)),
	'{new_poll_legend}' => $lang_poll['New poll legend'],
	'{question}' => $lang_poll['Question'],
	'{question_value}' => (isset($_POST['req_question'])) ? panther_htmlspecialchars($question) : '',
	'{index_1}' => $cur_index++,
	'{inputs}' => implode("\n\t\t\t\t\t\t", $inputs),
	'{options}' => $lang_common['Options'],
	'{index_2}' => ($cur_index++),
	'{multiple_checked}' => (isset($_POST['type']) ? ' checked="checked"' : ''),
	'{multi_select}' => $lang_poll['Allow multiselect'],
	'{submit}' => $lang_common['Submit'],
	'{index_3}' => $cur_index++,
	'{preview}' => $lang_post['Preview'],
	'{index_4}' => $cur_index++,
);

echo str_replace(array_keys($search), array_values($search), $poll_tpl);
require PANTHER_ROOT.'footer.php';