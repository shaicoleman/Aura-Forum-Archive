<?php
/**
 * Copyright (C) 2015 Panther (https://www.pantherforum.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

if (isset($_GET['action']))
	define('PANTHER_QUIET_VISIT', 1);

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/');
	require PANTHER_ROOT.'include/common.php';
}

if ($panther_user['is_bot'])	// I can't think of one valid reason why bots should be able to attempt to login
	message($lang_common['No permission']);

// Load the login.php language file
require PANTHER_ROOT.'lang/'.$panther_user['language'].'/login.php';

$action = isset($_GET['action']) ? $_GET['action'] : null;

$errors = array();
if (isset($_POST['form_sent']) && $action == 'in')
{
	flux_hook('login_before_validation');

	$form_username = isset($_POST['req_username']) ? panther_trim($_POST['req_username']) : '';
	$form_password = isset($_POST['req_password']) ?panther_trim($_POST['req_password']) : '';
	$save_pass = isset($_POST['save_pass']);

	if ($panther_config['o_login_queue'] == '1')
	{
		$data = array(
			':username'	=>	$form_username,
			':timeout'	=>	(TIMEOUT * 1000),
		);

		$ps = $db->select('login_queue', 'COUNT(*) AS overall, COUNT(IF(username = :username, TRUE, NULL)) AS user', $data, 'last_checked > NOW() - INTERVAL :timeout MICROSECOND');
		$count = $ps->fetch();
		
		if (!$count)
			message($lang_login['Unable to query size']);
		else if ($count['overall'] >= $panther_config['o_queue_size'] || $count['user'] >= $panther_config['o_max_attempts'])
			message($lang_login['Login queue exceeded']);	

		$insert = array(
			'ip_address'	=>	get_remote_address(),
			'username'		=>	$form_username,
		);

		$db->insert('login_queue', $insert) or message($lang_login['IP address in queue']);
		$attempt = $db->lastInsertId($db->prefix.'login_queue');

		// This time, it's actually in our favour. Yes, I know!
		while (!check_queue($form_username, $attempt, $db))
			usleep(250 * 1000);

		//Force delay between logins, remove dead attempts
		usleep(ATTEMPT_DELAY * 1000);
		
		$data = array(
			':id'	=>	$attempt,
			':timeout'	=>	(TIMEOUT * 1000),
		);
			
		$db->delete('login_queue', 'id=:id OR last_checked < NOW() - INTERVAL :timeout MICROSECOND', $data);
	}

	$data = array(
		':username'	=>	$form_username,
	);

	$ps = $db->select('users', 'password, salt, group_id, id, login_key', $data, 'username=:username');
	$cur_user = $ps->fetch();

	if (panther_hash($form_password.$cur_user['salt']) !== $cur_user['password'])
		$errors[] = sprintf($lang_login['Wrong user/pass'], ' <a href="'.get_link($panther_url['request_password']).'">'.$lang_login['Forgotten pass'].'</a>');

	flux_hook('login_after_validation');

	if (empty($errors))
	{
		// Update the status if this is the first time the user logged in
		if ($cur_user['group_id'] == PANTHER_UNVERIFIED)
		{
			$update = array(
				'group_id'	=>	$panther_config['o_default_user_group'],
			);
			
			$data = array(
				':id'	=>	$cur_user['id'],
			);
			$db->update('users', $update, 'id=:id', $data);

			// Regenerate the users info cache
			if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
				require PANTHER_ROOT.'include/cache.php';

			generate_users_info_cache();
		}

		// Remove this user's guest entry from the online list
		$data = array(
			':ident' => get_remote_address(),
		);
		$db->delete('online', 'ident=:ident', $data);

		$expire = ($save_pass == '1') ? time() + 1209600 : time() + $panther_config['o_timeout_visit'];
		panther_setcookie($cur_user['id'], $cur_user['login_key'], $expire);

		// Reset tracked topics
		set_tracked_topics(null);

		// Try to determine if the data in redirect_url is valid (if not, we redirect to index.php after login)
		$redirect_url = validate_redirect($_POST['redirect_url'], get_link($panther_url['index']));
		redirect(panther_htmlspecialchars($redirect_url), $lang_login['Login redirect']);
	}
}

else if ($action == 'out')
{
	if ($panther_user['is_guest'] || !isset($_GET['id']) || $_GET['id'] != $panther_user['id'] || !isset($_GET['csrf_token']) || $_GET['csrf_token'] != panther_hash($panther_user['id'].panther_hash(get_remote_address())))
	{
		header('Location: '.get_link($panther_url['index']));
		exit;
	}
	
	$data = array(
		':id'	=>	$panther_user['id'],
	);

	// Remove user from "users online" list
	$db->delete('online', 'user_id=:id', $data);
	generate_login_key();

	// Update last_visit (make sure there's something to update it with)
	if (isset($panther_user['logged']))
	{
		$update = array(
			'last_visit'	=>	$panther_user['logged'],
		);

		$data = array(
			':id'	=>	$panther_user['id'],
		);
		
		$db->update('users', $update, 'id=:id', $data);
	}

	panther_setcookie(1, panther_hash(uniqid(rand(), true)), time() + 31536000);
	redirect(get_link($panther_url['index']), $lang_login['Logout redirect']);
}

else if ($action == 'forget')
{
	if (!$panther_user['is_guest'])
	{
		header('Location: '.get_link($panther_url['index']));
		exit;
	}

	if (isset($_POST['form_sent']))
	{
		confirm_referrer('login.php');
		flux_hook('forget_password_before_validation');

		// Start with a clean slate
		$errors = array();

		require PANTHER_ROOT.'include/email.php';

		// Validate the email address
		$email = strtolower(panther_trim($_POST['req_email']));
		if (!is_valid_email($email))
			$errors[] = $lang_common['Invalid email'];

		flux_hook('forget_password_after_validation');

		// Did everything go according to plan?
		if (empty($errors))
		{
			$data = array(
				':email'	=>	$email,
			);

			$ps = $db->select('users', 'id, username, last_email_sent', $data, 'email=:email');
			if ($ps->rowCount())
			{
				// Load the "activate password" template
				$mail_tpl = trim(file_get_contents(PANTHER_ROOT.'lang/'.$panther_user['language'].'/mail_templates/activate_password.tpl'));

				// The first row contains the subject
				$first_crlf = strpos($mail_tpl, "\n");
				$mail_subject = trim(substr($mail_tpl, 8, $first_crlf-8));
				$mail_message = trim(substr($mail_tpl, $first_crlf));

				// Do the generic replacements first (they apply to all emails sent out here)
				$mail_message = str_replace('<base_url>', get_base_url().'/', $mail_message);
				$mail_message = str_replace('<board_mailer>', $panther_config['o_board_title'], $mail_message);

				// Loop through users we found
				foreach ($ps as $cur_hit)
				{
					if ($cur_hit['last_email_sent'] != '' && (time() - $cur_hit['last_email_sent']) < 3600 && (time() - $cur_hit['last_email_sent']) >= 0)
						message(sprintf($lang_login['Email flood'], intval((3600 - (time() - $cur_hit['last_email_sent'])) / 60)), true);

					// Generate a new password and a new password activation code
					$new_password = random_pass(12);
					$new_salt = random_pass(16);
					$new_password_key = random_pass(8);
					
					$update = array(
						'activate_string'	=>	panther_hash($new_password.$new_salt),
						'salt'	=>	$new_salt,
						'activate_key'	=>	$new_password_key,
						'last_email_sent'	=>	time(),
					);
					
					$data = array(
						':id'	=>	$cur_hit['id'],
					);

					$db->update('users', $update, 'id=:id', $data);

					// Do the user specific replacements to the template
					$cur_mail_message = str_replace('<username>', $cur_hit['username'], $mail_message);
					$cur_mail_message = str_replace('<activation_url>', get_link($panther_url['change_password_key'], array($cur_hit['id'], $new_password_key)), $cur_mail_message);
					$cur_mail_message = str_replace('<new_password>', $new_password, $cur_mail_message);

					panther_mail($email, $mail_subject, $cur_mail_message);
				}

				message($lang_login['Forget mail'].' <a href="mailto:'.panther_htmlspecialchars($panther_config['o_admin_email']).'">'.panther_htmlspecialchars($panther_config['o_admin_email']).'</a>.', true);
			}
			else
				$errors[] = $lang_login['No email match'].' '.panther_htmlspecialchars($email).'.';
			}
		}

	$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_login['Request pass']);
	$required_fields = array('req_email' => $lang_common['Email']);
	$focus_element = array('request_pass', 'req_email');

	flux_hook('forget_password_before_header');

	define ('PANTHER_ACTIVE_PAGE', 'login');
	require PANTHER_ROOT.'header.php';

	// If there are errors, we display them
	if (!empty($errors))
	{
		$form_errors = array();
		foreach ($errors as $cur_error)
			$form_errors[] = "\t\t\t\t".'<li><strong>'.$cur_error.'</strong></li>';
			
		$error_tpl = panther_template('inline_errors.tpl');
		$search = array(
			'{errors}' => $lang_login['New password errors'],
			'{errors_info}' => $lang_login['New passworderrors info'],
			'{error_list}' => implode("\n", $form_errors),
		);

		echo str_replace(array_keys($search), array_values($search), $error_tpl);
	}

	$login_tpl = panther_template('forgotten_password.tpl');

	$search = array(
		'{request_pass}' => $lang_login['Request pass'],
		'{form_url}' => get_link($panther_url['request_password']),
		'{request_pass_legend}' => $lang_login['Request pass legend'],
		'{csrf_token}' => generate_csrf_token(),
		'{email}' => $lang_common['Email'],
		'{required}' => $lang_common['Required'],
		'{request_pass_info}' => $lang_login['Request pass info'],
		'{forgot_password_hook}' => flux_hook('forget_password_before_submit'),
		'{submit}' => $lang_common['Submit'],
		'{go_back}' => (empty($errors)) ? '<a href="javascript:history.go(-1)">'.$lang_common['Go back'].'</a>' : '',
	);

	echo str_replace(array_keys($search), array_values($search), $login_tpl);
	require PANTHER_ROOT.'footer.php';
}

if (!$panther_user['is_guest'])
{
	header('Location: '.get_link($panther_url['index']));
	exit;
}

// Try to determine if the data in HTTP_REFERER is valid (if not, we redirect to index.php after login)
if (!empty($_SERVER['HTTP_REFERER']))
	$redirect_url = validate_redirect($_SERVER['HTTP_REFERER'], null);

if (!isset($redirect_url))
	$redirect_url = get_link($panther_url['index']);
else if (preg_match('%viewtopic\.php\?pid=(\d+)$%', $redirect_url, $matches))
	$redirect_url .= '#p'.$matches[1];

$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_common['Login']);
$required_fields = array('req_username' => $lang_common['Username'], 'req_password' => $lang_common['Password']);
$focus_element = array('login', 'req_username');

flux_hook('login_before_header');

define('PANTHER_ACTIVE_PAGE', 'login');
require PANTHER_ROOT.'header.php';

// If there are errors, we display them
if (!empty($errors))
{
	$form_errors = array();
	foreach ($errors as $cur_error)
		$form_errors[] = "\t\t\t\t".'<li><strong>'.$cur_error.'</strong></li>';
	
	$error_tpl = panther_template('inline_errors.tpl');
	$search = array(
		'{errors}' => $lang_login['Login errors'],
		'{errors_info}' => $lang_login['Login errors info'],
		'{error_list}' => implode("\n", $form_errors),
	);

	echo str_replace(array_keys($search), array_values($search), $error_tpl);
}

$login_tpl = panther_template('login.tpl');

$search = array(
	'{login}' => $lang_common['Login'],
	'{form_action}' => get_link($panther_url['login_in']),
	'{login_legend}' => $lang_login['Login legend'],
	'{redirect_url}' => panther_htmlspecialchars($redirect_url),
	'{username}' => $lang_common['Username'],
	'{required}' => $lang_common['Required'],
	'{password}' => $lang_common['Password'],
	'{remember_me}' => $lang_login['Remember me'],
	'{login_info}' => $lang_login['Login info'],
	'{register_link}' => get_link($panther_url['register']),
	'{not_registered}' => $lang_login['Not registered'],
	'{request_password_link}' => get_link($panther_url['request_password']),
	'{forgotten_pass}' => $lang_login['Forgotten pass'],
	'{login_hook}' => flux_hook('login_before_submit'),
);

echo str_replace(array_keys($search), array_values($search), $login_tpl);
require PANTHER_ROOT.'footer.php';