<?php
/**
 * Copyright (C) 2015 Panther (http://panther.strongholdnation.co.uk/)
 * based on code by Rickard Andersson copyright (C) 2002-2008 PunBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/');
	require PANTHER_ROOT.'include/common.php';
}

if ($panther_user['is_bot'])
	message($lang_common['No permission']);

// Include UTF-8 function
require PANTHER_ROOT.'include/utf8/substr_replace.php';
require PANTHER_ROOT.'include/utf8/ucwords.php'; // utf8_ucwords needs utf8_substr_replace
require PANTHER_ROOT.'include/utf8/strcasecmp.php';

$action = isset($_GET['action']) ? $_GET['action'] : null;
$section = isset($_GET['section']) ? $_GET['section'] : null;
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($id < 2)
	message($lang_common['Bad request'], false, '404 Not Found');

if ($action != 'change_pass' || !isset($_GET['key']))
{
	if ($panther_user['g_read_board'] == '0')
		message($lang_common['No view'], false, '403 Forbidden');
	else if ($panther_user['g_view_users'] == '0' && ($panther_user['is_guest'] || $panther_user['id'] != $id))
		message($lang_common['No permission'], false, '403 Forbidden');
}

// Load the prof_reg.php language file
require PANTHER_ROOT.'lang/'.$panther_user['language'].'/prof_reg.php';

// Load the profile.php language file
require PANTHER_ROOT.'lang/'.$panther_user['language'].'/profile.php';

if ($action == 'change_pass')
{
	if (isset($_GET['key']))
	{
		// If the user is already logged in we shouldn't be here :)
		if (!$panther_user['is_guest'])
		{
			header('Location: '.get_link($panther_url['index']));
			exit;
		}

		$key = $_GET['key'];

		$data = array(
			':id'	=>	$id,
		);

		$ps = $db->select('users', 'activate_string, activate_key, salt', $data, 'id=:id');
		$cur_user = $ps->fetch();

		if ($key == '' || $key != $cur_user['activate_key'])
			message($lang_profile['Pass key bad'].' <a href="mailto:'.panther_htmlspecialchars($panther_config['o_admin_email']).'">'.panther_htmlspecialchars($panther_config['o_admin_email']).'</a>.');
		else
		{
			$data = array(
				':password'	=>	$cur_user['activate_string'],
				':id'	=>	$id,
			);

			$db->run('UPDATE '.$db->prefix.'users SET password=:password, activate_string=NULL, activate_key=NULL WHERE id=:id', $data);
			message($lang_profile['Pass updated'], true);
		}
	}

	// Make sure we are allowed to change this user's password
	if ($panther_user['id'] != $id)
	{
		if (!$panther_user['is_admmod']) // A regular user trying to change another user's password?
			message($lang_common['No permission'], false, '403 Forbidden');
		else if ($panther_user['g_moderator'] == '1') // A moderator trying to change a user's password?
		{
			$ps = $db->select('SELECT u.group_id, g.g_moderator, g.g_admin FROM '.$db->prefix.'users AS u INNER JOIN '.$db->prefix.'groups AS g ON (g.g_id=u.group_id) WHERE u.id=:id', array(':id'=>$id));
			if (!$ps->rowCount())
				message($lang_common['Bad request'], false, '404 Not Found');

			list($group_id, $is_moderator) = $ps->fetch(PDO::FETCH_NUM);

			if ($panther_user['g_mod_edit_users'] == '0' || $panther_user['g_mod_change_passwords'] == '0' || $group_id == PANTHER_ADMIN || $is_admin == '1' || $is_moderator == '1')
				message($lang_common['No permission'], false, '403 Forbidden');
		}
	}

	if (isset($_POST['form_sent']))
	{
		// Make sure they got here from the site
		confirm_referrer('profile.php');

		$old_password = isset($_POST['req_old_password']) ? panther_trim($_POST['req_old_password']) : '';
		$new_password1 = panther_trim($_POST['req_new_password1']);
		$new_password2 = panther_trim($_POST['req_new_password2']);

		if ($new_password1 != $new_password2)
			message($lang_prof_reg['Pass not match']);
		if (panther_strlen($new_password1) < 6)
			message($lang_prof_reg['Pass too short']);
		
		$data = array(
			':id'	=>	$id,
		);

		$ps = $db->select('users', 'password, salt', $data, 'id=:id');
		$cur_user = $ps->fetch();

		$authorized = false;
		if (!empty($cur_user['password']))
		{
			$old_password_hash = panther_hash($old_password.$cur_user['salt']);
			if ($cur_user['password'] == $old_password_hash || $panther_user['is_admmod'])
				$authorized = true;
		}

		if (!$authorized)
			message($lang_profile['Wrong pass']);

		$new_salt = random_pass(16);
		$new_password_hash = panther_hash($new_password1.$new_salt);

		$update = array(
			'password'	=>	$new_password_hash,
			'salt'		=>	$new_salt,
		);
		
		$data = array(
			':id'	=>	$id,
		);
		
		$db->update('users', $update, 'id=:id', $data);

		if ($panther_user['id'] == $id)
			panther_setcookie($panther_user['id'], $new_password_hash, time() + $panther_config['o_timeout_visit']);

		redirect(get_link($panther_url['profile_essentials'], array($id)), $lang_profile['Pass updated redirect']);
	}

	$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_common['Profile'], $lang_profile['Change pass']);
	$required_fields = array('req_old_password' => $lang_profile['Old pass'], 'req_new_password1' => $lang_profile['New pass'], 'req_new_password2' => $lang_profile['Confirm new pass']);
	$focus_element = array('change_pass', ((!$panther_user['is_admmod']) ? 'req_old_password' : 'req_new_password1'));
	define('PANTHER_ACTIVE_PAGE', 'profile');
	require PANTHER_ROOT.'header.php';
?>
<div class="blockform">
	<h2><span><?php echo $lang_profile['Change pass'] ?></span></h2>
	<div class="box">
		<form id="change_pass" method="post" action="<?php echo get_link($panther_url['change_password'], array($id)); ?>" onsubmit="return process_form(this)">
			<div class="inform">
				<input type="hidden" name="form_sent" value="1" />
				<input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>" />
				<fieldset>
					<legend><?php echo $lang_profile['Change pass legend'] ?></legend>
					<div class="infldset">
<?php if (!$panther_user['is_admmod']): ?>						<label class="required"><strong><?php echo $lang_profile['Old pass'] ?> <span><?php echo $lang_common['Required'] ?></span></strong><br />
						<input type="password" name="req_old_password" size="16" /><br /></label>
<?php endif; ?>						<label class="conl required"><strong><?php echo $lang_profile['New pass'] ?> <span><?php echo $lang_common['Required'] ?></span></strong><br />
						<input type="password" name="req_new_password1" size="16" /><br /></label>
						<label class="conl required"><strong><?php echo $lang_profile['Confirm new pass'] ?> <span><?php echo $lang_common['Required'] ?></span></strong><br />
						<input type="password" name="req_new_password2" size="16" /><br /></label>
						<p class="clearb"><?php echo $lang_profile['Pass info'] ?></p>
					</div>
				</fieldset>
			</div>
			<p class="buttons"><input type="submit" name="update" value="<?php echo $lang_common['Submit'] ?>" /> <a href="javascript:history.go(-1)"><?php echo $lang_common['Go back'] ?></a></p>
		</form>
	</div>
</div>
<?php
	require PANTHER_ROOT.'footer.php';
}
else if ($action == 'change_email')
{
	// Make sure we are allowed to change this user's email
	if ($panther_user['id'] != $id)
	{
		if (!$panther_user['is_admmod']) // A regular user trying to change another user's email?
			message($lang_common['No permission'], false, '403 Forbidden');
		else if ($panther_user['g_moderator'] == '1') // A moderator trying to change a user's email?
		{
			$ps = $db->run('SELECT u.group_id, g.g_moderator, g.g_admin FROM '.$db->prefix.'users AS u INNER JOIN '.$db->prefix.'groups AS g ON (g.g_id=u.group_id) WHERE u.id=:id', array(':id'=>$id));
			if (!$ps->rowCount())
				message($lang_common['Bad request'], false, '404 Not Found');

			list($group_id, $is_moderator, $is_admin) = $ps->fetch(PDO::FETCH_NUM);

			if ($panther_user['g_mod_edit_users'] == '0' || $group_id == PANTHER_ADMIN || $is_admin == '1' || $is_moderator == '1')
				message($lang_common['No permission'], false, '403 Forbidden');
		}
	}

	if (isset($_GET['key']))
	{
		$key = $_GET['key'];
		$update = array(
			':id'	=>	$id,
		);
		
		$ps = $db->select('users', 'activate_string, activate_key', $data, 'id=:id');
		list($new_email, $new_email_key) = $ps->fetch(PDO::FETCH_NUM);

		if ($key == '' || $key != $new_email_key)
			message($lang_profile['Email key bad'].' <a href="mailto:'.panther_htmlspecialchars($panther_config['o_admin_email']).'">'.panther_htmlspecialchars($panther_config['o_admin_email']).'</a>.');
		else
		{
			$data = array(
				':id'	=>	$id,
			);

			$db->run('UPDATE '.$db->prefix.'users SET email=activate_string, activate_string=NULL, activate_key=NULL WHERE id=:id', $data);
			message($lang_profile['Email updated'], true);
		}
	}
	else if (isset($_POST['form_sent']))
	{
		if (panther_hash($_POST['req_password'].$panther_user['salt']) !== $panther_user['password'])
			message($lang_profile['Wrong pass']);
			
		// Make sure they got here from the site
		confirm_referrer('profile.php');

		require PANTHER_ROOT.'include/email.php';

		// Validate the email address
		$new_email = strtolower(panther_trim($_POST['req_new_email']));
		if (!is_valid_email($new_email))
			message($lang_common['Invalid email']);

		// Check if it's a banned email address
		if (is_banned_email($new_email))
		{
			if ($panther_config['p_allow_banned_email'] == '0')
				message($lang_prof_reg['Banned email']);
			else if ($panther_config['o_mailing_list'] != '')
			{
				// Load the "banned email change" template
				$mail_tpl = trim(file_get_contents(PANTHER_ROOT.'lang/'.$panther_user['language'].'/mail_templates/banned_email_change.tpl'));

				// The first row contains the subject
				$first_crlf = strpos($mail_tpl, "\n");
				$mail_subject = trim(substr($mail_tpl, 8, $first_crlf-8));
				$mail_message = trim(substr($mail_tpl, $first_crlf));

				$mail_message = str_replace('<username>', $panther_user['username'], $mail_message);
				$mail_message = str_replace('<email>', $new_email, $mail_message);
				$mail_message = str_replace('<profile_url>', get_link($panther_url['profile_essentials'], array($id)), $mail_message);
				$mail_message = str_replace('<board_mailer>', $panther_config['o_board_title'], $mail_message);

				panther_mail($panther_config['o_mailing_list'], $mail_subject, $mail_message);
			}
		}

		// Check if someone else already has registered with that email address
		$data = array(
			':email'	=>	$new_email,
		);

		$ps = $db->select('users', 'id, username', $data, 'email=:email');
		if ($ps->rowCount())
		{
			if ($panther_config['p_allow_dupe_email'] == '0')
				message($lang_prof_reg['Dupe email']);
			else if ($panther_config['o_mailing_list'] != '')
			{
				$ps->setFetchMode(PDO::FETCH_COLUMN, 0);
				foreach ($ps as $cur_dupe)
					$dupe_list[] = $cur_dupe;

				// Load the "dupe email change" template
				$mail_tpl = trim(file_get_contents(PANTHER_ROOT.'lang/'.$panther_user['language'].'/mail_templates/dupe_email_change.tpl'));

				// The first row contains the subject
				$first_crlf = strpos($mail_tpl, "\n");
				$mail_subject = trim(substr($mail_tpl, 8, $first_crlf-8));
				$mail_message = trim(substr($mail_tpl, $first_crlf));

				$mail_message = str_replace('<username>', $panther_user['username'], $mail_message);
				$mail_message = str_replace('<dupe_list>', implode(', ', $dupe_list), $mail_message);
				$mail_message = str_replace('<profile_url>', get_link($panther_url['profile_essentials'], array($id)), $mail_message);
				$mail_message = str_replace('<board_mailer>', $panther_config['o_board_title'], $mail_message);

				panther_mail($panther_config['o_mailing_list'], $mail_subject, $mail_message);
			}
		}

		$new_email_key = random_pass(8);
		$update = array(
			'activate_string'	=>	$new_email,
			'activate_key'	=>	$new_email_key,
		);
		
		$data = array(
			':id'	=>	$id,
		);
		
		$db->update('users', $update, 'id=:id', $data);

		// Load the "activate email" template
		$mail_tpl = trim(file_get_contents(PANTHER_ROOT.'lang/'.$panther_user['language'].'/mail_templates/activate_email.tpl'));

		// The first row contains the subject
		$first_crlf = strpos($mail_tpl, "\n");
		$mail_subject = trim(substr($mail_tpl, 8, $first_crlf-8));
		$mail_message = trim(substr($mail_tpl, $first_crlf));

		$mail_message = str_replace('<username>', $panther_user['username'], $mail_message);
		$mail_message = str_replace('<base_url>', get_base_url(true), $mail_message);
		$mail_message = str_replace('<activation_url>', get_link($panther_url['change_email_key'], array($id, $new_email_key)), $mail_message);
		$mail_message = str_replace('<board_mailer>', $panther_config['o_board_title'], $mail_message);

		panther_mail($new_email, $mail_subject, $mail_message);
		message($lang_profile['Activate email sent'].' <a href="mailto:'.panther_htmlspecialchars($panther_config['o_admin_email']).'">'.panther_htmlspecialchars($panther_config['o_admin_email']).'</a>.', true);
	}

	$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_common['Profile'], $lang_profile['Change email']);
	$required_fields = array('req_new_email' => $lang_profile['New email'], 'req_password' => $lang_common['Password']);
	$focus_element = array('change_email', 'req_new_email');
	define('PANTHER_ACTIVE_PAGE', 'profile');
	require PANTHER_ROOT.'header.php';
?>
<div class="blockform">
	<h2><span><?php echo $lang_profile['Change email'] ?></span></h2>
	<div class="box">
		<form id="change_email" method="post" action="<?php echo get_link($panther_url['change_email'], array($id)) ?>" onsubmit="return process_form(this)">
			<div class="inform">
				<fieldset>
					<legend><?php echo $lang_profile['Email legend'] ?></legend>
					<div class="infldset">
						<input type="hidden" name="form_sent" value="1" />
						<input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>" />
						<label class="required"><strong><?php echo $lang_profile['New email'] ?> <span><?php echo $lang_common['Required'] ?></span></strong><br /><input type="text" name="req_new_email" size="50" maxlength="80" /><br /></label>
						<label class="required"><strong><?php echo $lang_common['Password'] ?> <span><?php echo $lang_common['Required'] ?></span></strong><br /><input type="password" name="req_password" size="16" /><br /></label>
						<p><?php echo $lang_profile['Email instructions'] ?></p>
					</div>
				</fieldset>
			</div>
			<p class="buttons"><input type="submit" name="new_email" value="<?php echo $lang_common['Submit'] ?>" /> <a href="javascript:history.go(-1)"><?php echo $lang_common['Go back'] ?></a></p>
		</form>
	</div>
</div>
<?php
	require PANTHER_ROOT.'footer.php';
}
else if ($action == 'use_gravatar')
{
	if ($panther_config['o_avatars'] == '0')
		message($lang_profile['Avatars disabled']);

	if ($panther_user['id'] != $id && !$panther_user['is_admmod'])
		message($lang_common['No permission']);

	confirm_referrer('profile.php');
	$data = array(
		':id'	=>	$id,
	);

	$ps = $db->select('users', 'use_gravatar', $data, 'id=:id');
	$use_gravatar = $ps->fetchColumn();
	
	if (!$use_gravatar)
		delete_avatar($id);

	$redirect_msg = ($use_gravatar) ? $lang_profile['Gravatar disabled redirect'] : $lang_profile['Gravatar enabled redirect'];
	$update = array(
		'use_gravatar'	=>	(($use_gravatar == 0) ? 1 : 0)
	);

	$db->update('users', $update, 'id=:id', $data);
	redirect(get_link($panther_url['profile_personality'], array($id)), $redirect_msg);
}
else if ($action == 'upload_avatar')
{
	if ($panther_config['o_avatars'] == '0')
		message($lang_profile['Avatars disabled']);
	
	if ($panther_config['o_avatar_upload'] == '0')
		message($lang_profile['Avatars disabled']);

	if ($panther_user['id'] != $id && !$panther_user['is_admmod'])
		message($lang_common['No permission'], false, '403 Forbidden');

	if (isset($_POST['form_sent']))
	{
		if (!isset($_FILES['req_file']))
			message($lang_profile['No file']);
			
		// Make sure they got here from the site
		confirm_referrer('profile.php');

		$uploaded_file = $_FILES['req_file'];

		// Make sure the upload went smooth
		if (isset($uploaded_file['error']))
		{
			switch ($uploaded_file['error'])
			{
				case 1: // UPLOAD_ERR_INI_SIZE
				case 2: // UPLOAD_ERR_FORM_SIZE
					message($lang_profile['Too large ini']);
					break;

				case 3: // UPLOAD_ERR_PARTIAL
					message($lang_profile['Partial upload']);
					break;

				case 4: // UPLOAD_ERR_NO_FILE
					message($lang_profile['No file']);
					break;

				case 6: // UPLOAD_ERR_NO_TMP_DIR
					message($lang_profile['No tmp directory']);
					break;

				default:
					// No error occured, but was something actually uploaded?
					if ($uploaded_file['size'] == 0)
						message($lang_profile['No file']);
					break;
			}
		}

		if (is_uploaded_file($uploaded_file['tmp_name']))
		{
			// Preliminary file check, adequate in most cases
			$allowed_types = array('image/gif', 'image/jpeg', 'image/pjpeg', 'image/png', 'image/x-png');
			if (!in_array($uploaded_file['type'], $allowed_types))
				message($lang_profile['Bad type']);

			// Make sure the file isn't too big
			if ($uploaded_file['size'] > $panther_config['o_avatars_size'])
				message($lang_profile['Too large'].' '.forum_number_format($panther_config['o_avatars_size']).' '.$lang_profile['bytes'].'.');

			// Move the file to the avatar directory. We do this before checking the width/height to circumvent open_basedir restrictions
			if (!@move_uploaded_file($uploaded_file['tmp_name'], $panther_config['o_avatars_path'].'/'.$id.'.tmp'))
				message($lang_profile['Move failed'].' <a href="mailto:'.panther_htmlspecialchars($panther_config['o_admin_email']).'">'.panther_htmlspecialchars($panther_config['o_admin_email']).'</a>.');

			list($width, $height, $type,) = @getimagesize($panther_config['o_avatars_path'].'/'.$id.'.tmp');

			// Determine type
			if ($type == IMAGETYPE_GIF)
				$extension = '.gif';
			else if ($type == IMAGETYPE_JPEG)
				$extension = '.jpg';
			else if ($type == IMAGETYPE_PNG)
				$extension = '.png';
			else
			{
				// Invalid type
				@unlink($panther_config['o_avatars_path'].'/'.$id.'.tmp');
				message($lang_profile['Bad type']);
			}

			// Now check the width/height
			if (empty($width) || empty($height) || $width > $panther_config['o_avatars_width'] || $height > $panther_config['o_avatars_height'])
			{
				@unlink($panther_config['o_avatars_path'].'/'.$id.'.tmp');
				message($lang_profile['Too wide or high'].' '.$panther_config['o_avatars_width'].'x'.$panther_config['o_avatars_height'].' '.$lang_profile['pixels'].'.');
			}

			// Delete any old avatars and put the new one in place
			delete_avatar($id);
			@rename($panther_config['o_avatars_path'].'/'.$id.'.tmp', $panther_config['o_avatars_path'].'/'.$id.$extension);
			compress_image($panther_config['o_avatars_path'].'/'.$id.$extension);
			@chmod($panther_config['o_avatars_path'].'/'.$id.$extension, 0644);
			
			// Disable Gravatar
			$update = array(
				'use_gravatar'	=>	0,
			);
			
			$data = array(
			':id'	=>	$id,
			);

			$db->update('users', $update, 'id=:id', $data);
		}
		else
			message($lang_profile['Unknown failure']);

		redirect(get_link($panther_url['profile_personality'], array($id)), $lang_profile['Avatar upload redirect']);
	}

	$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_common['Profile'], $lang_profile['Upload avatar']);
	$required_fields = array('req_file' => $lang_profile['File']);
	$focus_element = array('upload_avatar', 'req_file');
	define('PANTHER_ACTIVE_PAGE', 'profile');
	require PANTHER_ROOT.'header.php';
?>
<div class="blockform">
	<h2><span><?php echo $lang_profile['Upload avatar'] ?></span></h2>
	<div class="box">
		<form id="upload_avatar" method="post" enctype="multipart/form-data" action="<?php echo get_link($panther_url['upload_avatar'], array($id, generate_csrf_token())) ?>" onsubmit="return process_form(this)">
			<div class="inform">
				<fieldset>
					<legend><?php echo $lang_profile['Upload avatar legend'] ?></legend>
					<div class="infldset">
						<input type="hidden" name="form_sent" value="1" />
						<input type="hidden" name="MAX_FILE_SIZE" value="<?php echo $panther_config['o_avatars_size'] ?>" />
						<input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>" />
						<label class="required"><strong><?php echo $lang_profile['File'] ?> <span><?php echo $lang_common['Required'] ?></span></strong><br /><input name="req_file" type="file" size="40" /><br /></label>
						<p><?php echo $lang_profile['Avatar desc'].' '.$panther_config['o_avatars_width'].' x '.$panther_config['o_avatars_height'].' '.$lang_profile['pixels'].' '.$lang_common['and'].' '.forum_number_format($panther_config['o_avatars_size']).' '.$lang_profile['bytes'].' ('.file_size($panther_config['o_avatars_size']).').' ?></p>
					</div>
				</fieldset>
			</div>
			<p class="buttons"><input type="submit" name="upload" value="<?php echo $lang_profile['Upload'] ?>" /> <a href="javascript:history.go(-1)"><?php echo $lang_common['Go back'] ?></a></p>
		</form>
	</div>
</div>
<?php
	require PANTHER_ROOT.'footer.php';
}
else if ($action == 'delete_avatar')
{
	if ($panther_user['id'] != $id && !$panther_user['is_admmod'])
		message($lang_common['No permission'], false, '403 Forbidden');

	confirm_referrer('profile.php');

	delete_avatar($id);
	redirect(get_link($panther_url['profile_personality'], array($id)), $lang_profile['Avatar deleted redirect']);
}

else if (isset($_POST['update_group_membership']))
{
	if (!$panther_user['is_admin'])
		message($lang_common['No permission'], false, '403 Forbidden');

	confirm_referrer('profile.php');
	$new_group_id = intval($_POST['group_id']);
	$select = array(
		':id'	=>	$id,
	);

	$ps = $db->select('users', 'group_id', $select, 'id=:id');
	$old_group_id = $ps->fetchColumn();
	
	$update = array(
		'group_id'	=>	$new_group_id,
	);
	
	$data = array(
		':id'	=>	$id,
	);

	$db->update('users', $update, 'id=:id', $data);

	// Regenerate the users info cache
	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PANTHER_ROOT.'include/cache.php';

	generate_users_info_cache();

	if ($old_group_id == PANTHER_ADMIN || $new_group_id == PANTHER_ADMIN || $panther_groups[$old_group_id]['g_admin'] == '1' || $panther_groups[$new_group_id]['g_admin'] == '1')
		generate_admins_cache();
	
	$data = array(
		':id'	=>	$new_group_id
	);

	$ps = $db->select('groups', 'g_moderator', $data, 'g_id=:id');
	$new_group_mod = $ps->fetchColumn();

	// If the user was a moderator or an administrator, we remove him/her from the moderator list in all forums as well
	if ($new_group_id != PANTHER_ADMIN && $new_group_mod != '1')
	{
		$ps = $db->select('forums', 'id, moderators');
		foreach ($ps as $cur_forum)
		{
			$cur_moderators = ($cur_forum['moderators'] != '') ? unserialize($cur_forum['moderators']) : array();
			if (in_array($id, $cur_moderators))
			{
				$username = array_search($id, $cur_moderators);
				unset($cur_moderators[$username]);
				unset($cur_moderators['groups'][$id]);
				if (empty($cur_moderators['groups']))
					unset($cur_moderators['groups']);
				$cur_moderators = (!empty($cur_moderators)) ? serialize($cur_moderators) : NULL;
				$update = array(
					'moderators'	=>	$cur_moderators,
				);
				
				$data = array(
					':id'	=>	$cur_forum['id'],
				);

				$db->update('forums', $update, 'id=:id', $data);
			}
		}
	}
	else	// Else update moderator's group_id
	{
		$ps = $db->select('forums', 'id, moderators');
		foreach ($ps as $cur_forum)
		{
			$cur_moderators = ($cur_forum['moderators'] != '') ? unserialize($cur_forum['moderators']) : array();
			if (in_array($id, $cur_moderators))
			{
				$cur_moderators['groups'][$id] = $new_group_id;
				$update = array(
					'moderators'	=>	serialize($cur_moderators),
				);
				
				$data = array(
					':id'	=>	$cur_forum['id'],
				);
				
				$db->update('forums', $update, 'id=:id', $data);
			}
		}
	}
	redirect(get_link($panther_url['profile_admin'], array($id)), $lang_profile['Group membership redirect']);
}
else if (isset($_POST['update_forums']))
{
	if (!$panther_user['is_admin'])
		message($lang_common['No permission'], false, '403 Forbidden');

	confirm_referrer('profile.php');

	// Get the username of the user we are processing
	$data = array(
		':id'	=>	$id,
	);

	$ps = $db->select('users', 'username, group_id', $data, 'id=:id');
	list($username, $group_id) = $ps->fetch(PDO::FETCH_NUM);
	$moderator_in = (isset($_POST['moderator_in'])) ? array_keys($_POST['moderator_in']) : array();

	// Loop through all forums
	$ps = $db->select('forums', 'id, moderators');
	foreach ($ps as $cur_forum)
	{
		$cur_moderators = ($cur_forum['moderators'] != '') ? unserialize($cur_forum['moderators']) : array();
		// If the user should have moderator access (and he/she doesn't already have it)
		if (in_array($cur_forum['id'], $moderator_in) || in_array($id, $cur_moderators))
		{
			if (!isset($cur_moderators['groups']))
				$cur_moderators['groups'] = array();
			$cur_moderators['groups'][$id] = $group_id;
		}

		if (in_array($cur_forum['id'], $moderator_in) && !in_array($id, $cur_moderators))
		{
			$cur_moderators[$username] = $id;
			uksort($cur_moderators, 'utf8_strcasecmp');

			$update = array(
				'moderators'	=>	serialize($cur_moderators),
			);
			
			$data = array(
				':id'	=>	$cur_forum['id'],
			);

			$db->update('forums', $update, 'id=:id', $data);
		}
		// If the user shouldn't have moderator access (and he/she already has it)
		else if (!in_array($cur_forum['id'], $moderator_in) && in_array($id, $cur_moderators))
		{
			unset($cur_moderators[$username]);
			unset($cur_moderators['groups'][$id]);
			if (empty($cur_moderators['groups']))
					unset($cur_moderators['groups']);

			$cur_moderators = (!empty($cur_moderators)) ? serialize($cur_moderators) : NULL;
			$update = array(
				'moderators'	=>	$cur_moderators,
			);
			
			$data = array(
				':id'	=>	$cur_forum['id'],
			);
			
			$db->update('forums', $update, 'id=:id', $data);
		}
		elseif (in_array($cur_forum['id'], $moderator_in) || in_array($id, $cur_moderators))
		{
			$update = array(
				'moderators'	=>	$cur_moderators,
			);
			
			$data = array(
				':id'	=>	$cur_forum['id'],
			);
			
			$db->update('forums', $update, 'id=:id', $data);
		}
	}

	redirect(get_link($panther_url['profile_admin'], array($id)), $lang_profile['Update forums redirect']);
}
else if (isset($_POST['update_posting_ban']))
{
	if (!$panther_user['is_admin'])
		message($lang_common['No permission']);

	confirm_referrer('profile.php');
	$data = array(
		':id'	=>	$id,
	);

	$ps = $db->select('users', 'username, group_id', $data, 'id=:id');
	$cur_user = $ps->fetch();

	if ($panther_groups[$cur_user['group_id']]['g_admin'] == '1' || $cur_user['group_id'] == PANTHER_ADMIN)
		message(sprintf($lang_profile['posting ban admin'], panther_htmlspecialchars($user['username'])));

	if ($panther_groups[$cur_user['group_id']]['g_moderator'] == '1')
		message(sprintf($lang_profile['posting ban moderator'], panther_htmlspecialchars($user['username'])));

	$expiration_time = isset($_POST['expiration_time']) ? intval($_POST['expiration_time']) : 0;
	$expiration_unit = isset($_POST['expiration_unit']) ? panther_trim($_POST['expiration_unit']) : $lang_profile['Days'];
	$delete_ban = isset($_POST['remove_ban']) ? '1' : '0';
	$time = ($delete_ban == '1') ? '0' : (time() + get_expiration_time($expiration_time, $expiration_unit)); 

	$update = array(
		'posting_ban'	=>	$time,
	);
	
	$db->update('users', $update, 'id=:id', $data);
	redirect(get_link($panther_url['profile_admin'], array($id)), $lang_profile['Update posting ban redirect']);
}
else if (isset($_POST['ban']))
{
	if (!$panther_user['is_admin'] && ($panther_user['g_moderator'] != '1' || $panther_user['g_mod_ban_users'] == '0'))
		message($lang_common['No permission'], false, '403 Forbidden');

	// Get the username of the user we are banning
	$data = array(
		':id'	=>	$id,
	);

	$ps = $db->select('users', 'username', $data, 'id=:id');
	$username = $ps->fetchColumn();

	// Check whether user is already banned
	$data = array(
		':username'	=>	$username,
	);
	$ps = $db->select('bans', 'id', $data, 'username=:username', 'expire IS NULL DESC, expire DESC LIMIT 1');
	if ($ps->rowCount())
	{
		$ban_id = $ps->fetchColumn();
		redirect(get_link($panther_url['edit_ban'], array($ban_id)), $lang_profile['Ban redirect']);
	}
	else
		redirect(get_link($panther_url['admin_bans_add'], array($id)), $lang_profile['Ban redirect']);
}
else if ($action == 'promote')
{
	if (!$panther_user['is_admin'] && ($panther_user['g_moderator'] != '1' || $panther_user['g_mod_promote_users'] == '0'))
		message($lang_common['No permission']);

	$pid = isset($_GET['pid']) ? intval($_GET['pid']) : 0;
	$data = array(
		':id'	=>	$id,
	);

	$ps = $db->run('SELECT g.g_promote_next_group FROM '.$db->prefix.'groups AS g INNER JOIN '.$db->prefix.'users AS u ON u.group_id=g.g_id WHERE u.id=:id AND g.g_promote_next_group>0', $data);

	if (!$ps->rowCount())
		message($lang_common['Bad request'], false, '404 Not Found');

	$update = array(
		'group_id'	=>	$ps->fetchColumn(),
	);
	
	$data = array(
		':id'	=>	$id,
	);

	$db->update('users', $update, 'id=:id', $data);
	redirect(get_link($panther_url['post'], array($pid)), $lang_profile['User promote redirect']);
}
else if (isset($_POST['delete_user']) || isset($_POST['delete_user_comply']))
{
	if ($panther_user['g_id'] != PANTHER_ADMIN && $panther_user['g_admin'] != '1')
		message($lang_common['No permission'], false, '403 Forbidden');

	confirm_referrer('profile.php');
	
	if (file_exists(FORUM_CACHE_DIR.'cache_restrictions.php'))
		require FORUM_CACHE_DIR.'cache_restrictions.php';
	else
	{
		if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
			require PANTHER_ROOT.'include/cache.php';

		generate_admin_restrictions_cache();
		require FORUM_CACHE_DIR.'cache_restrictions.php';
	}

	if (!isset($admins[$panther_user['id']]) || $panther_user['id'] == '2')
		$admins[$panther_user['id']] = array('admin_users' => '1');	
	
	if ($admins[$panther_user['id']]['admin_users'] == '0')
		message($lang_common['No permission']);

	// Get the username and group of the user we are deleting
	$data = array(
	':id'	=>	$id,
	);

	$ps = $db->select('users', 'group_id, username', $data, 'id=:id');
	list($group_id, $username) = $ps->fetch(PDO::FETCH_NUM);

	if ($group_id == PANTHER_ADMIN || $panther_groups[$group_id]['g_admin'] == '1')
		message($lang_profile['No delete admin message']);

	if (isset($_POST['delete_user_comply']))
	{
		// If the user is a moderator or an administrator, we remove him/her from the moderator list in all forums as well7
		$data = array(
			':id'	=>	$group_id,
		);
		$ps = $db->select('groups', 'g_moderator', $data, 'g_id=:id');
		$group_mod = $ps->fetchColumn();

		if ($group_id == PANTHER_ADMIN || $group_mod == '1')
		{
			$ps = $db->select('forums', 'id, moderators');
			foreach ($ps as $cur_forum)
			{
				$cur_moderators = ($cur_forum['moderators'] != '') ? unserialize($cur_forum['moderators']) : array();
				if (in_array($id, $cur_moderators))
				{
					unset($cur_moderators[$username]);
					$cur_moderators = (!empty($cur_moderators)) ? serialize($cur_moderators) : NULL;
					$update = array(
						'moderators'	=>	$cur_moderators,
					);
					
					$data = array(
						':id'	=>	$cur_forum['id'],
					);
					
					$db->update('forums', $update, 'id=:id', $data);
				}
			}
		}
		
		$data = array(
			':id'	=>	$id,
		);

		// Delete any subscriptions
		$db->delete('topic_subscriptions', 'user_id=:id', $data);
		$db->delete('forum_subscriptions', 'user_id=:id', $data);
		
		// Remove any issued warnings
		$db->delete('warnings', 'user_id=:id', $data);

		// Remove them from the online list (if they happen to be logged in)
		$db->delete('online', 'user_id=:id', $data);

		// Should we delete all posts made by this user?
		if (isset($_POST['delete_posts']))
		{
			require PANTHER_ROOT.'include/search_idx.php';
			@set_time_limit(0);

			// Find all posts made by this user
			$ps = $db->run('SELECT p.id, p.topic_id, t.forum_id FROM '.$db->prefix.'posts AS p INNER JOIN '.$db->prefix.'topics AS t ON t.id=p.topic_id INNER JOIN '.$db->prefix.'forums AS f ON f.id=t.forum_id WHERE p.poster_id=:id', $data);
			if ($ps->rowCount())
			{
				foreach ($ps as $cur_post)
				{
					// Determine whether this post is the "topic post" or not
					$select = array(
						':id'	=>	$cur_post['topic_id'],
					);

					$ps1 = $db->select('posts', 'id', $select, 'topic_id=:id', 'posted LIMIT 1');
					if ($ps1->fetchColumn() == $cur_post['id'])
						delete_topic($cur_post['topic_id']);
					else
						delete_post($cur_post['id'], $cur_post['topic_id']);
					
					$delete = array(
						':id'	=>	$cur_post['id'],
					);
					
					$db->delete('reputation', 'post_id=:id', $delete);

					update_forum($cur_post['forum_id']);
				}
			}
		}
		else	// Set all his/her posts to guest
		{
			$update = array(
				'poster_id'	=>	1,
			);

			$db->update('posts', $update, 'poster_id=:id', $data);
		}

		// Delete user avatar
		delete_avatar($id);

		// Delete the user
		$db->delete('users', 'id=:id', $data);

		// Regenerate the users info cache
		if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
			require PANTHER_ROOT.'include/cache.php';

		generate_users_info_cache();

		if ($group_id == PANTHER_ADMIN || $panther_groups[$group_id]['g_admin'] == '1')
		{
			generate_admins_cache();
			generate_admin_restrictions_cache();
		}

		redirect(get_link($panther_url['index']), $lang_profile['User delete redirect']);
	}

	$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_common['Profile'], $lang_profile['Confirm delete user']);
	define('PANTHER_ACTIVE_PAGE', 'profile');
	require PANTHER_ROOT.'header.php';
?>
<div class="blockform">
	<h2><span><?php echo $lang_profile['Confirm delete user'] ?></span></h2>
	<div class="box">
		<form id="confirm_del_user" method="post" action="<?php echo get_link($panther_url['profile'], array($id)) ?>">
			<div class="inform">
				<fieldset>
					<legend><?php echo $lang_profile['Confirm delete legend'] ?></legend>
					<div class="infldset">
						<p><?php echo $lang_profile['Confirmation info'].' <strong>'.panther_htmlspecialchars($username).'</strong>.' ?></p>
						<div class="rbox">
							<label><input type="checkbox" name="delete_posts" value="1" checked="checked" /><?php echo $lang_profile['Delete posts'] ?><br /></label>
							<input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>" />
						</div>
						<p class="warntext"><strong><?php echo $lang_profile['Delete warning'] ?></strong></p>
					</div>
				</fieldset>
			</div>
			<p class="buttons"><input type="submit" name="delete_user_comply" value="<?php echo $lang_profile['Delete'] ?>" /> <a href="javascript:history.go(-1)"><?php echo $lang_common['Go back'] ?></a></p>
		</form>
	</div>
</div>
<?php
	require PANTHER_ROOT.'footer.php';
}
else if (isset($_POST['form_sent']))
{
	$data = array(
		':id'	=>	$id,
	);
	
	// Fetch the user group of the user we are editing
	$ps = $db->run('SELECT u.username, u.group_id, g.g_moderator FROM '.$db->prefix.'users AS u LEFT JOIN '.$db->prefix.'groups AS g ON (g.g_id=u.group_id) WHERE u.id=:id', $data);
	if (!$ps->rowCount())
		message($lang_common['Bad request'], false, '404 Not Found');

	list($old_username, $group_id, $is_moderator) = $ps->fetch(PDO::FETCH_NUM);

	if ($panther_user['id'] != $id && !in_array($section, array('rep_received', 'rep_given')) &&																	// If we aren't the user (i.e. editing your own profile) and we aren't viewing what rep they have
		(!$panther_user['is_admmod'] ||																	// and we are not an admin or mod
		(!$panther_user['is_admin'] &&															// or we aren't an admin and ...
		($panther_user['g_mod_edit_users'] == '0' ||													// mods aren't allowed to edit users
		$group_id == PANTHER_ADMIN ||																	// or the user is an admin
		$is_moderator))))																			// or the user is another mod
		message($lang_common['No permission'], false, '403 Forbidden');

	// Make sure they got here from the site
	confirm_referrer('profile.php');

	$username_updated = false;

	// Validate input depending on section
	switch ($section)
	{
		case 'essentials':
		{
			$form = array(
				'timezone'		=> floatval($_POST['form']['timezone']),
				'dst'			=> isset($_POST['form']['dst']) ? '1' : '0',
				'time_format'	=> intval($_POST['form']['time_format']),
				'date_format'	=> intval($_POST['form']['date_format']),
			);

			// Make sure we got a valid language string
			if (isset($_POST['form']['language']))
			{
				$languages = forum_list_langs();
				$form['language'] = panther_trim($_POST['form']['language']);
				if (!in_array($form['language'], $languages))
					message($lang_common['Bad request'], false, '404 Not Found');
			}

			if ($panther_user['is_admmod'])
			{
				$form['admin_note'] = panther_trim($_POST['admin_note']);

				// Are we allowed to change usernames?
				if ($panther_user['is_admin'] || ($panther_user['g_moderator'] == '1' && $panther_user['g_mod_rename_users'] == '1'))
				{
					$form['username'] = panther_trim($_POST['req_username']);

					if ($form['username'] != $old_username)
					{
						// Check username
						require PANTHER_ROOT.'lang/'.$panther_user['language'].'/register.php';

						$errors = array();
						check_username($form['username'], $id);
						if (!empty($errors))
							message($errors[0]);

						$username_updated = true;
					}
				}

				// We only allow administrators to update the post count
				if ($panther_user['is_admin'])
					$form['num_posts'] = intval($_POST['num_posts']);
			}

			if ($panther_config['o_regs_verify'] == '0' || $panther_user['is_admmod'])
			{
				require PANTHER_ROOT.'include/email.php';

				// Validate the email address
				$form['email'] = strtolower(panther_trim($_POST['req_email']));
				if (!is_valid_email($form['email']))
					message($lang_common['Invalid email']);
			}

			break;
		}

		case 'personal':
		{
			$form = array(
				'realname'		=> isset($_POST['form']['realname']) ? panther_trim($_POST['form']['realname']) : '',
				'url'			=> isset($_POST['form']['url']) ? panther_trim($_POST['form']['url']) : '',
				'location'		=> isset($_POST['form']['location']) ? panther_trim($_POST['form']['location']) : '',
			);

			// Add http:// if the URL doesn't contain it already (while allowing https://, too)
			if ($panther_user['g_post_links'] == '1')
			{
				if ($form['url'] != '')
				{
					$url = url_valid($form['url']);

					if ($url === false)
						message($lang_profile['Invalid website URL']);

					$form['url'] = $url['url'];
				}
			}
			else
			{
				if (!empty($form['url']))
					message($lang_profile['Website not allowed']);

				$form['url'] = '';
			}

			if ($panther_user['is_admin'])
				$form['title'] = panther_trim($_POST['title']);
			else if ($panther_user['g_set_title'] == '1')
			{
				$form['title'] = panther_trim($_POST['title']);

				if ($form['title'] != '')
				{
					// A list of words that the title may not contain
					// If the language is English, there will be some duplicates, but it's not the end of the world
					$forbidden = array('member', 'moderator', 'administrator', 'banned', 'guest', utf8_strtolower($lang_common['Member']), utf8_strtolower($lang_common['Moderator']), utf8_strtolower($lang_common['Administrator']), utf8_strtolower($lang_common['Banned']), utf8_strtolower($lang_common['Guest']));

					if (in_array(utf8_strtolower($form['title']), $forbidden))
						message($lang_profile['Forbidden title']);
				}
			}

			break;
		}

		case 'messaging':
		{
			$form = array(
				'facebook'		=> panther_trim($_POST['form']['facebook']),
				'steam'			=> panther_trim($_POST['form']['steam']),
				'msn'			=> panther_trim($_POST['form']['msn']),
				'google'		=> panther_trim($_POST['form']['google']),
				'twitter'		=> panther_trim($_POST['form']['twitter']),
			);

			break;
		}

		case 'personality':
		{
			$form = array();

			// Clean up signature from POST
			if ($panther_config['o_signatures'] == '1')
			{
				$form['signature'] = panther_linebreaks(panther_trim($_POST['signature']));

				// Validate signature
				if (panther_strlen($form['signature']) > $panther_config['p_sig_length'])
					message(sprintf($lang_prof_reg['Sig too long'], $panther_config['p_sig_length'], panther_strlen($form['signature']) - $panther_config['p_sig_length']));
				else if (substr_count($form['signature'], "\n") > ($panther_config['p_sig_lines']-1))
					message(sprintf($lang_prof_reg['Sig too many lines'], $panther_config['p_sig_lines']));
				else if ($form['signature'] && $panther_config['p_sig_all_caps'] == '0' && is_all_uppercase($form['signature']) && !$panther_user['is_admmod'])
					$form['signature'] = utf8_ucwords(utf8_strtolower($form['signature']));

				// Validate BBCode syntax
				if ($panther_config['p_sig_bbcode'] == '1')
				{
					require PANTHER_ROOT.'include/parser.php';

					$errors = array();
					$form['signature'] = preparse_bbcode($form['signature'], $errors, true);

					if(count($errors) > 0)
						message('<ul><li>'.implode('</li><li>', $errors).'</li></ul>');
				}
			}

			break;
		}

		case 'display':
		{
			$form = array(
				'disp_topics'		=> panther_trim($_POST['form']['disp_topics']),
				'disp_posts'		=> panther_trim($_POST['form']['disp_posts']),
				'show_smilies'		=> isset($_POST['form']['show_smilies']) ? '1' : '0',
				'show_img'			=> isset($_POST['form']['show_img']) ? '1' : '0',
				'show_img_sig'		=> isset($_POST['form']['show_img_sig']) ? '1' : '0',
				'show_avatars'		=> isset($_POST['form']['show_avatars']) ? '1' : '0',
				'show_sig'			=> isset($_POST['form']['show_sig']) ? '1' : '0',
				'use_editor'		=> isset($_POST['form']['use_editor']) ? '1' : '0',
			);

			if ($form['disp_topics'] != '')
			{
				$form['disp_topics'] = intval($form['disp_topics']);
				if ($form['disp_topics'] < 3)
					$form['disp_topics'] = 3;
				else if ($form['disp_topics'] > 75)
					$form['disp_topics'] = 75;
			}

			if ($form['disp_posts'] != '')
			{
				$form['disp_posts'] = intval($form['disp_posts']);
				if ($form['disp_posts'] < 3)
					$form['disp_posts'] = 3;
				else if ($form['disp_posts'] > 75)
					$form['disp_posts'] = 75;
			}

			// Make sure we got a valid style string
			if (isset($_POST['form']['style']))
			{
				$styles = forum_list_styles();
				$form['style'] = panther_trim($_POST['form']['style']);
				if (!in_array($form['style'], $styles))
					message($lang_common['Bad request'], false, '404 Not Found');
			}

			break;
		}

		case 'privacy':
		{
			$form = array(
				'email_setting'			=> intval($_POST['form']['email_setting']),
				'notify_with_post'		=> isset($_POST['form']['notify_with_post']) ? '1' : '0',
				'auto_notify'			=> isset($_POST['form']['auto_notify']) ? '1' : '0',
				'pm_enabled'			=> isset($_POST['form']['pm_enabled']) ? '1' : '0',
				'pm_notify'				=> isset($_POST['form']['pm_notify']) ? '1' : '0',
			);

			if ($form['email_setting'] < 0 || $form['email_setting'] > 2)
				$form['email_setting'] = $panther_config['o_default_email_setting'];

			break;
		}

		default:
			message($lang_common['Bad request'], false, '404 Not Found');
	}

	// Single quotes around non-empty values and NULL for empty values
	$temp = $data = array();
	foreach ($form as $key => $input)
	{
		$value = ($input !== '') ? $input : NULL;

		$temp[] = $key.'= ?';
		$data[] = $value;
	}

	if (empty($temp))
		message($lang_common['Bad request'], false, '404 Not Found');

	$data[] = $id;
	$db->run('UPDATE '.$db->prefix.'users SET '.implode(',', $temp).' WHERE id=?', $data);

	// If we changed the username we have to update some stuff
	if ($username_updated)
	{
		$update = array(
			'username'	=>	$form['username'],
		);
		
		$data = array(
			':user'	=>	$old_username,
		);

		$rows = $db->update('bans', $update, 'username=:user', $data);

		// If any bans were updated, we will need to know because the cache will need to be regenerated.
		if ($rows > 0)
			$bans_updated = true;
		
		$update = array(
			'poster'	=>	$form['username'],
		);

		$data = array(
			':id'	=>	$id,
		);
		
		$db->update('posts', $update, 'poster_id=:id', $data);

		$data = array(
			':username'	=>	$old_username,
		);
		
		$db->update('topics', $update, 'poster=:username', $data);

		$update = array(
			'edited_by'	=>	$form['username'],
		);
		
		$db->update('posts', $update, 'edited_by=:username', $data);
		
		$update = array(
			'last_poster'	=>	$form['username'],
		);
		
		$db->update('topics', $update, 'last_poster=:username', $data);
		$db->update('topics', $update, 'last_poster=:username', $data);
		$db->update('forums', $update, 'last_poster=:username', $data);
		
		$update = array(
			'ident'	=>	$form['username'],
		);

		$db->update('online', $update, 'ident=:username', $data);

		// If the user is a moderator or an administrator we have to update the moderator lists
		$data = array(
			':id'	=>	$id,
		);
		$ps = $db->select('users', 'group_id', $data, 'id=:id');
		$group_id = $ps->fetchColumn();

		if ($group_id == PANTHER_ADMIN || $panther_groups[$group_id]['g_moderator'] == '1')
		{
			$ps = $db->select('forums', 'id, moderators');
			foreach ($ps as $cur_forum)
			{
				$cur_moderators = ($cur_forum['moderators'] != '') ? unserialize($cur_forum['moderators']) : array();
				if (in_array($id, $cur_moderators))
				{
					unset($cur_moderators[$old_username]);
					$cur_moderators[$form['username']] = $id;
					uksort($cur_moderators, 'utf8_strcasecmp');

					$update = array(
						'moderators'	=>	serialize($cur_moderators),
					);
					
					$data = array(
						':id'	=>	$cur_forum['id'],
					);
					
					$db->update('forums', $update, 'id=:id', $data);
				}
			}
		}

		// Regenerate the users info cache
		if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
			require PANTHER_ROOT.'include/cache.php';

		generate_users_info_cache();

		// Check if the bans table was updated and regenerate the bans cache when needed
		if (isset($bans_updated))
			generate_bans_cache();
	}

	redirect(get_link($panther_url['profile_'.strtolower($section)], array($id)), $lang_profile['Profile redirect']);
}

flux_hook('profile_after_form_handling');
$data = array(
	':id'	=>	$id,
);

$ps = $db->run('SELECT u.username, u.email, u.title, u.realname, u.url, u.facebook, u.steam, u.msn, u.google, u.twitter, u.location, u.signature, u.disp_topics, u.disp_posts, u.email_setting, u.notify_with_post, u.auto_notify, u.use_editor, u.pm_enabled, u.pm_notify, u.use_gravatar, u.show_smilies, u.show_img, u.show_img_sig, u.show_avatars, u.show_sig, u.timezone, u.dst, u.language, u.style, u.num_posts, u.last_post, u.last_visit, u.registered, u.registration_ip, u.reputation, u.admin_note, u.date_format, u.time_format, u.last_visit, u.posting_ban, g.g_id, g.g_user_title, g.g_moderator, g.g_use_pm, g.g_admin FROM '.$db->prefix.'users AS u LEFT JOIN '.$db->prefix.'groups AS g ON g.g_id=u.group_id WHERE u.id=:id', $data);
if (!$ps->rowCount())
	message($lang_common['Bad request'], false, '404 Not Found');
else
	$user = $ps->fetch();

$last_post = format_time($user['last_post']);
if ($user['signature'] != '')
{
	require PANTHER_ROOT.'include/parser.php';
	$parsed_signature = parse_signature($user['signature']);
}

// View or edit?
if ($panther_user['id'] != $id && !in_array($section, array('rep_received', 'rep_given')) && 																	// If we aren't the user (i.e. editing your own profile) and we aren't viewing what rep they have
	(!$panther_user['is_admmod'] ||																	// and we are not an admin or mod
	(!$panther_user['is_admin'] &&															// or we aren't an admin and ...
	($panther_user['g_mod_edit_users'] == '0' ||													// mods aren't allowed to edit users
	$user['g_id'] == PANTHER_ADMIN ||																// or the user is an admin
	$user['g_moderator'] == '1'))))																// or the user is another mod
{
	$user_personal = array();

	if ($panther_config['o_users_online'] == '1')
	{
		require PANTHER_ROOT.'lang/'.$panther_user['language'].'/online.php';
		$data = array(
			':id'	=>	$id,
		);
		
		$ps = $db->select('online', 'currently', $data, 'user_id=:id');
		$online = $ps->fetch();
	
		if ($online['currently'] == NULL || $online['currently'] == '')
		{
			$icon = 'status_offline';
			$status = $lang_online['user is offline'];
			$location = $lang_online['not online'];
		}
		else
		{
			$icon = 'status_online';
			$status = $lang_online['user is online'];
			$location = generate_user_location($online['currently']);
		}
	}
	$user_personal[] = '<dt>'.$lang_common['Username'].'</dt>';
	$user_personal[] = '<dd><img src="'.$panther_config['o_image_dir'].$icon.'.png" title="'.$status.'" />'.colourize_group($user['username'], $user['g_id']).'</dd>';

	$user_title_field = get_title($user);
	$user_personal[] = '<dt>'.$lang_common['Title'].'</dt>';
	$user_personal[] = '<dd>'.(($panther_config['o_censoring'] == '1') ? censor_words($user_title_field) : $user_title_field).'</dd>';

	if ($user['realname'] != '')
	{
		$user_personal[] = '<dt>'.$lang_profile['Realname'].'</dt>';
		$user_personal[] = '<dd>'.panther_htmlspecialchars(($panther_config['o_censoring'] == '1') ? censor_words($user['realname']) : $user['realname']).'</dd>';
	}

	if ($user['location'] != '')
	{
		$user_personal[] = '<dt>'.$lang_profile['Location'].'</dt>';
		$user_personal[] = '<dd>'.panther_htmlspecialchars(($panther_config['o_censoring'] == '1') ? censor_words($user['location']) : $user['location']).'</dd>';
	}

	if ($user['url'] != '')
	{
		$user['url'] = panther_htmlspecialchars(($panther_config['o_censoring'] == '1') ? censor_words($user['url']) : $user['url']);
		$user_personal[] = '<dt>'.$lang_profile['Website'].'</dt>';
		$user_personal[] = '<dd><span class="website"><a href="'.$user['url'].'" rel="nofollow">'.panther_htmlspecialchars($user['url']).'</a></span></dd>';
	}

	if ($user['email_setting'] == '0' && !$panther_user['is_guest'] && $panther_user['g_send_email'] == '1')
		$email_field = '<a href="mailto:'.panther_htmlspecialchars($user['email']).'">'.panther_htmlspecialchars($user['email']).'</a>';
	else if ($user['email_setting'] == '1' && !$panther_user['is_guest'] && $panther_user['g_send_email'] == '1')
		$email_field = '<a href="'.get_link($panther_url['email'], array($id)).'">'.$lang_common['Send email'].'</a>';
	else
		$email_field = '';
	if ($email_field != '')
	{
		$user_personal[] = '<dt>'.$lang_common['Email'].'</dt>';
		$user_personal[] = '<dd><span class="email">'.$email_field.'</span></dd>';
	}

	$user_personal[] = '<dt>'.$lang_online['currently'].'</dt>';
	$user_personal[] = '<dd>'.$location.'</dd>';
	$user_messaging = array();

	if ($user['facebook'] != '')
	{
		$user_messaging[] = '<dt>'.$lang_profile['Facebook'].'</dt>';
		$user_messaging[] = '<dd>'.panther_htmlspecialchars(($panther_config['o_censoring'] == '1') ? censor_words($user['facebook']) : $user['facebook']).'</dd>';
	}

	if ($user['steam'] != '')
	{
		$user_messaging[] = '<dt>'.$lang_profile['Steam'].'</dt>';
		$user_messaging[] = '<dd>'.$user['steam'].'</dd>';
	}

	if ($user['msn'] != '')
	{
		$user_messaging[] = '<dt>'.$lang_profile['MSN'].'</dt>';
		$user_messaging[] = '<dd>'.panther_htmlspecialchars(($panther_config['o_censoring'] == '1') ? censor_words($user['msn']) : $user['msn']).'</dd>';
	}

	if ($user['twitter'] != '')
	{
		$user_messaging[] = '<dt>'.$lang_profile['Twitter'].'</dt>';
		$user_messaging[] = '<dd>'.panther_htmlspecialchars(($panther_config['o_censoring'] == '1') ? censor_words($user['twitter']) : $user['twitter']).'</dd>';
	}
	
	if ($user['google'] != '')
	{
		$user_messaging[] = '<dt>'.$lang_profile['Google'].'</dt>';
		$user_messaging[] = '<dd>'.panther_htmlspecialchars(($panther_config['o_censoring'] == '1') ? censor_words($user['google']) : $user['google']).'</dd>';
	}

	$user_personality = array();

	if ($panther_config['o_avatars'] == '1')
	{
		$avatar_field = generate_avatar_markup($id);
		if ($avatar_field != '')
		{
			$user_personality[] = '<dt>'.$lang_profile['Avatar'].'</dt>';
			$user_personality[] = '<dd>'.$avatar_field.'</dd>';
		}
	}

	if ($panther_config['o_signatures'] == '1')
	{
		if (isset($parsed_signature))
		{
			$user_personality[] = '<dt>'.$lang_profile['Signature'].'</dt>';
			$user_personality[] = '<dd><div class="postsignature postmsg">'.$parsed_signature.'</div></dd>';
		}
	}

	$user_activity = array();

	$posts_field = '';
	if ($panther_config['o_show_post_count'] == '1' || $panther_user['is_admmod'])
		$posts_field = forum_number_format($user['num_posts']);
	if ($panther_user['g_search'] == '1')
	{
		if ($panther_user['is_admmod'] && $panther_config['o_warnings'] == '1')
		{
			// Load the warnings.php language file
			require PANTHER_ROOT.'lang/'.$panther_user['language'].'/warnings.php';

			// Does the user have active warnings?
			$data = array(
				':id'	=>	$id,
				':time'	=>	time(),
			);

			$ps = $db->select('warnings', 'SUM(points)', $data, 'user_id=:id AND (date_expire>:time OR date_expire=0)');
			$has_active = $ps->fetchColumn();

			if ($has_active)
			{
				$warning_level = '<strong>'.$lang_warnings['Warning level'].'</strong>';
				$points_active = '<strong>'.$has_active.'</strong>';
			}
			else
				$warning_level = $lang_warnings['Warning level'];
		}


		if (($panther_user['is_admin'] || ($panther_user['is_admmod'] && $panther_user['g_mod_warn_users'] == '1')) && $panther_config['o_warnings'] == '1')
		{
			$user_activity[] = '<dt>'.$warning_level.'</dt>';
			$user_activity[] = '<dd>'.$points_active.' - <a href="'.get_link($panther_url['warning_view'], array($id)).'">'.$lang_warnings['Show all warnings'].'</a> - <a href="'.get_link($panther_url['warn_user'], array($id)).'">'.$lang_warnings['Warn user'].'</a>'.'</dd>';
		}
		else if ($panther_user['is_admmod'] && $panther_config['o_warnings'] == '1')
		{
			$user_activity[] = '<dt>'.$warning_level.'</dt>';
			$user_activity[] = '<dd>'.$points_active.'</dd>';
		}

		$quick_searches = array();
		if ($user['num_posts'] > 0)
		{
			$quick_searches[] = '<a href="'.get_link($panther_url['search_user_topics'], array($id)).'">'.$lang_profile['Show topics'].'</a>';
			$quick_searches[] = '<a href="'.get_link($panther_url['search_user_posts'], array($id)).'">'.$lang_profile['Show posts'].'</a>';
		}
		if ($panther_user['is_admmod'] && $panther_config['o_topic_subscriptions'] == '1')
			$quick_searches[] = '<a href="'.get_link($panther_url['search_subscriptions'], array($id)).'">'.$lang_profile['Show subscriptions'].'</a>';

		if (!empty($quick_searches))
			$posts_field .= (($posts_field != '') ? ' - ' : '').implode(' - ', $quick_searches);
	}
	if ($posts_field != '')
	{
		$user_activity[] = '<dt>'.$lang_common['Posts'].'</dt>';
		$user_activity[] = '<dd>'.$posts_field.'</dd>';
	}

	if ($user['num_posts'] > 0)
	{
		$user_activity[] = '<dt>'.$lang_common['Last post'].'</dt>';
		$user_activity[] = '<dd>'.$last_post.'</dd>';
	}

	$user_activity[] = '<dt>'.$lang_profile['Last visit'].'</dt>';
	$user_activity[] = '<dd>'.format_time($user['last_visit']).'</dd>';

	$user_activity[] = '<dt>'.$lang_common['Registered'].'</dt>';
	$user_activity[] = '<dd>'.format_time($user['registered'], true).'</dd>';

	if ($panther_config['o_reputation'] == '1')
	{
		switch(true)
		{
			case $user['reputation'] > '0':
				$type = 'positive';
			break;
			case $user['reputation'] < '0':
				$type = 'negative';
			break;
			default:
				$type = 'zero';
			break;
		}

		$user_reputation = '<span class="reputation '.$type.'">'.$lang_profile['Reputation'].': '.$user['reputation'].'</span><br /><br />';
	}

	$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), sprintf($lang_profile['Users profile'], panther_htmlspecialchars($user['username'])));
	define('PANTHER_ALLOW_INDEX', 1);
	define('PANTHER_ACTIVE_PAGE', 'index');
	require PANTHER_ROOT.'header.php';
?>
<div id="viewprofile" class="block">
	<h2><span><?php echo $lang_common['Profile'] ?></span></h2>
	<div class="box">
		<div class="fakeform">
			<div class="inform">
				<fieldset>
				<legend><?php echo $lang_profile['Section personal'] ?></legend>
					<div class="infldset">
						<dl>
							<?php echo implode("\n\t\t\t\t\t\t\t", $user_personal)."\n" ?>
						</dl>
						<div class="clearer"></div>
					</div>
				</fieldset>
			</div>
<?php if ($panther_config['o_reputation'] == '1'): ?>
			<div class="inform">
				<fieldset>
					<legend><?php echo $lang_profile['Reputation'] ?></legend>
					<br />
					<div class="infldset">
						<?php echo $user_reputation; ?>
						<label><a href="<?php echo get_link($panther_url['profile_rep_received'], array($id)); ?>"><?php echo $lang_profile['Rep_received'] ?></a><br /></label>
						<label><a href="<?php echo get_link($panther_url['profile_rep_given'], array($id)); ?>"><?php echo $lang_profile['Rep_given'] ?></a><br /></label>
					</div>
				</fieldset>
			</div>
<?php endif; if (!empty($user_messaging)): ?>			<div class="inform">
				<fieldset>
				<legend><?php echo $lang_profile['Section messaging'] ?></legend>
					<div class="infldset">
						<dl>
							<?php echo implode("\n\t\t\t\t\t\t\t", $user_messaging)."\n" ?>
						</dl>
						<div class="clearer"></div>
					</div>
				</fieldset>
			</div>
<?php endif; if (!empty($user_personality)): ?>			<div class="inform">
				<fieldset>
				<legend><?php echo $lang_profile['Section personality'] ?></legend>
					<div class="infldset">
						<dl>
							<?php echo implode("\n\t\t\t\t\t\t\t", $user_personality)."\n" ?>
						</dl>
						<div class="clearer"></div>
					</div>
				</fieldset>
			</div>
<?php endif; ?>			<div class="inform">
				<fieldset>
				<legend><?php echo $lang_profile['User activity'] ?></legend>
					<div class="infldset">
						<dl>
							<?php echo implode("\n\t\t\t\t\t\t\t", $user_activity)."\n" ?>
						</dl>
						<div class="clearer"></div>
					</div>
				</fieldset>
			</div>
		</div>
	</div>
</div>
<?php
	require PANTHER_ROOT.'footer.php';
}
else
{
	if (!$section || $section == 'essentials')
	{
		if ($panther_user['is_admmod'])
		{
			if ($panther_user['is_admin'] || $panther_user['g_mod_rename_users'] == '1')
				$username_field = '<label class="required"><strong>'.$lang_common['Username'].' <span>'.$lang_common['Required'].'</span></strong><br /><input type="text" name="req_username" value="'.panther_htmlspecialchars($user['username']).'" size="25" maxlength="25" /><br /></label>'."\n";
			else
				$username_field = '<p>'.sprintf($lang_profile['Username info'], panther_htmlspecialchars($user['username'])).'</p>'."\n";

			$email_field = '<label class="required"><strong>'.$lang_common['Email'].' <span>'.$lang_common['Required'].'</span></strong><br /><input type="text" name="req_email" value="'.panther_htmlspecialchars($user['email']).'" size="40" maxlength="80" /><br /></label><p><span class="email"><a href="'.get_link($panther_url['email'], array($id)).'">'.$lang_common['Send email'].'</a></span></p>'."\n";
		}
		else
		{
			$username_field = '<p>'.$lang_common['Username'].': '.panther_htmlspecialchars($user['username']).'</p>'."\n";

			if ($panther_config['o_regs_verify'] == '1')
				$email_field = '<p>'.sprintf($lang_profile['Email info'], panther_htmlspecialchars($user['email']).' - <a href="'.get_link($panther_url['change_email'], array($id)).'">'.$lang_profile['Change email'].'</a>').'</p>'."\n";
			else
				$email_field = '<label class="required"><strong>'.$lang_common['Email'].' <span>'.$lang_common['Required'].'</span></strong><br /><input type="text" name="req_email" value="'.$user['email'].'" size="40" maxlength="80" /><br /></label>'."\n";
		}

		$posts_field = '';
		$posts_actions = array();

		if ($panther_user['is_admin'])
			$posts_field .= '<label>'.$lang_common['Posts'].'<br /><input type="text" name="num_posts" value="'.$user['num_posts'].'" size="8" maxlength="8" /><br /></label>';
		else if ($panther_config['o_show_post_count'] == '1' || $panther_user['is_admmod'])
			$posts_actions[] = sprintf($lang_profile['Posts info'], forum_number_format($user['num_posts']));

		if ($panther_user['g_search'] == '1' || $panther_user['is_admin'])
		{
			$posts_actions[] = '<a href="'.get_link($panther_url['search_user_topics'], array($id)).'">'.$lang_profile['Show topics'].'</a>';
			$posts_actions[] = '<a href="'.get_link($panther_url['search_user_posts'], array($id)).'">'.$lang_profile['Show posts'].'</a>';

			if ($panther_config['o_topic_subscriptions'] == '1')
				$posts_actions[] = '<a href="'.get_link($panther_url['search_subscriptions'], array($id)).'">'.$lang_profile['Show subscriptions'].'</a>';
		}

		$posts_field .= (!empty($posts_actions) ? '<p class="actions">'.implode(' - ', $posts_actions).'</p>' : '')."\n";
		require PANTHER_ROOT.'lang/'.$panther_user['language'].'/warnings.php';
		
		// Does the user have active warnings?
		$data = array(
			':id'	=>	$id,
			':time'	=>	time(),
		);

		$ps = $db->select('warnings', 'SUM(points)', $data, 'user_id=:id AND (date_expire>:time OR date_expire=0)');
		$has_active = $ps->fetchColumn();

		if ($has_active)
			$warning_level = '<strong>'.$lang_warnings['Warning level'].': '.$has_active.'</strong>';
		else
			$warning_level = $lang_warnings['Warning level'].': '.$has_active;

		$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_common['Profile'], $lang_profile['Section essentials']);
		$required_fields = array('req_username' => $lang_common['Username'], 'req_email' => $lang_common['Email']);
		define('PANTHER_ACTIVE_PAGE', 'profile');
		require PANTHER_ROOT.'header.php';

		generate_profile_menu('essentials');
?>
	<div class="blockform">
		<h2><span><?php echo panther_htmlspecialchars($user['username']).' - '.$lang_profile['Section essentials'] ?></span></h2>
		<div class="box">
			<form id="profile1" method="post" action="<?php echo get_link($panther_url['profile_essentials'], array($id)) ?>" onsubmit="return process_form(this)">
				<div class="inform">
					<fieldset>
						<legend><?php echo $lang_profile['Username and pass legend'] ?></legend>
						<div class="infldset">
							<input type="hidden" name="form_sent" value="1" />
							<input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>" />
							<?php echo $username_field ?>
<?php if ($panther_user['id'] == $id || $panther_user['is_admin'] || ($user['g_moderator'] == '0' && $panther_user['g_mod_change_passwords'] == '1')): ?>							<p class="actions"><span><a href="<?php echo get_link($panther_url['change_password'], array($id)) ?>"><?php echo $lang_profile['Change pass'] ?></a></span></p>
<?php endif; ?>						</div>
					</fieldset>
				</div>
				<div class="inform">
					<fieldset>
						<legend><?php echo $lang_prof_reg['Email legend'] ?></legend>
						<div class="infldset">
							<?php echo $email_field ?>
						</div>
					</fieldset>
				</div>
				<div class="inform">
					<fieldset>
						<legend><?php echo $lang_prof_reg['Localisation legend'] ?></legend>
						<div class="infldset">
							<p><?php echo $lang_prof_reg['Time zone info'] ?></p>
							<label><?php echo $lang_prof_reg['Time zone']."\n" ?>
							<br /><select name="form[timezone]">
								<option value="-12"<?php if ($user['timezone'] == -12) echo ' selected="selected"' ?>><?php echo $lang_prof_reg['UTC-12:00'] ?></option>
								<option value="-11"<?php if ($user['timezone'] == -11) echo ' selected="selected"' ?>><?php echo $lang_prof_reg['UTC-11:00'] ?></option>
								<option value="-10"<?php if ($user['timezone'] == -10) echo ' selected="selected"' ?>><?php echo $lang_prof_reg['UTC-10:00'] ?></option>
								<option value="-9.5"<?php if ($user['timezone'] == -9.5) echo ' selected="selected"' ?>><?php echo $lang_prof_reg['UTC-09:30'] ?></option>
								<option value="-9"<?php if ($user['timezone'] == -9) echo ' selected="selected"' ?>><?php echo $lang_prof_reg['UTC-09:00'] ?></option>
								<option value="-8.5"<?php if ($user['timezone'] == -8.5) echo ' selected="selected"' ?>><?php echo $lang_prof_reg['UTC-08:30'] ?></option>
								<option value="-8"<?php if ($user['timezone'] == -8) echo ' selected="selected"' ?>><?php echo $lang_prof_reg['UTC-08:00'] ?></option>
								<option value="-7"<?php if ($user['timezone'] == -7) echo ' selected="selected"' ?>><?php echo $lang_prof_reg['UTC-07:00'] ?></option>
								<option value="-6"<?php if ($user['timezone'] == -6) echo ' selected="selected"' ?>><?php echo $lang_prof_reg['UTC-06:00'] ?></option>
								<option value="-5"<?php if ($user['timezone'] == -5) echo ' selected="selected"' ?>><?php echo $lang_prof_reg['UTC-05:00'] ?></option>
								<option value="-4"<?php if ($user['timezone'] == -4) echo ' selected="selected"' ?>><?php echo $lang_prof_reg['UTC-04:00'] ?></option>
								<option value="-3.5"<?php if ($user['timezone'] == -3.5) echo ' selected="selected"' ?>><?php echo $lang_prof_reg['UTC-03:30'] ?></option>
								<option value="-3"<?php if ($user['timezone'] == -3) echo ' selected="selected"' ?>><?php echo $lang_prof_reg['UTC-03:00'] ?></option>
								<option value="-2"<?php if ($user['timezone'] == -2) echo ' selected="selected"' ?>><?php echo $lang_prof_reg['UTC-02:00'] ?></option>
								<option value="-1"<?php if ($user['timezone'] == -1) echo ' selected="selected"' ?>><?php echo $lang_prof_reg['UTC-01:00'] ?></option>
								<option value="0"<?php if ($user['timezone'] == 0) echo ' selected="selected"' ?>><?php echo $lang_prof_reg['UTC'] ?></option>
								<option value="1"<?php if ($user['timezone'] == 1) echo ' selected="selected"' ?>><?php echo $lang_prof_reg['UTC+01:00'] ?></option>
								<option value="2"<?php if ($user['timezone'] == 2) echo ' selected="selected"' ?>><?php echo $lang_prof_reg['UTC+02:00'] ?></option>
								<option value="3"<?php if ($user['timezone'] == 3) echo ' selected="selected"' ?>><?php echo $lang_prof_reg['UTC+03:00'] ?></option>
								<option value="3.5"<?php if ($user['timezone'] == 3.5) echo ' selected="selected"' ?>><?php echo $lang_prof_reg['UTC+03:30'] ?></option>
								<option value="4"<?php if ($user['timezone'] == 4) echo ' selected="selected"' ?>><?php echo $lang_prof_reg['UTC+04:00'] ?></option>
								<option value="4.5"<?php if ($user['timezone'] == 4.5) echo ' selected="selected"' ?>><?php echo $lang_prof_reg['UTC+04:30'] ?></option>
								<option value="5"<?php if ($user['timezone'] == 5) echo ' selected="selected"' ?>><?php echo $lang_prof_reg['UTC+05:00'] ?></option>
								<option value="5.5"<?php if ($user['timezone'] == 5.5) echo ' selected="selected"' ?>><?php echo $lang_prof_reg['UTC+05:30'] ?></option>
								<option value="5.75"<?php if ($user['timezone'] == 5.75) echo ' selected="selected"' ?>><?php echo $lang_prof_reg['UTC+05:45'] ?></option>
								<option value="6"<?php if ($user['timezone'] == 6) echo ' selected="selected"' ?>><?php echo $lang_prof_reg['UTC+06:00'] ?></option>
								<option value="6.5"<?php if ($user['timezone'] == 6.5) echo ' selected="selected"' ?>><?php echo $lang_prof_reg['UTC+06:30'] ?></option>
								<option value="7"<?php if ($user['timezone'] == 7) echo ' selected="selected"' ?>><?php echo $lang_prof_reg['UTC+07:00'] ?></option>
								<option value="8"<?php if ($user['timezone'] == 8) echo ' selected="selected"' ?>><?php echo $lang_prof_reg['UTC+08:00'] ?></option>
								<option value="8.75"<?php if ($user['timezone'] == 8.75) echo ' selected="selected"' ?>><?php echo $lang_prof_reg['UTC+08:45'] ?></option>
								<option value="9"<?php if ($user['timezone'] == 9) echo ' selected="selected"' ?>><?php echo $lang_prof_reg['UTC+09:00'] ?></option>
								<option value="9.5"<?php if ($user['timezone'] == 9.5) echo ' selected="selected"' ?>><?php echo $lang_prof_reg['UTC+09:30'] ?></option>
								<option value="10"<?php if ($user['timezone'] == 10) echo ' selected="selected"' ?>><?php echo $lang_prof_reg['UTC+10:00'] ?></option>
								<option value="10.5"<?php if ($user['timezone'] == 10.5) echo ' selected="selected"' ?>><?php echo $lang_prof_reg['UTC+10:30'] ?></option>
								<option value="11"<?php if ($user['timezone'] == 11) echo ' selected="selected"' ?>><?php echo $lang_prof_reg['UTC+11:00'] ?></option>
								<option value="11.5"<?php if ($user['timezone'] == 11.5) echo ' selected="selected"' ?>><?php echo $lang_prof_reg['UTC+11:30'] ?></option>
								<option value="12"<?php if ($user['timezone'] == 12) echo ' selected="selected"' ?>><?php echo $lang_prof_reg['UTC+12:00'] ?></option>
								<option value="12.75"<?php if ($user['timezone'] == 12.75) echo ' selected="selected"' ?>><?php echo $lang_prof_reg['UTC+12:45'] ?></option>
								<option value="13"<?php if ($user['timezone'] == 13) echo ' selected="selected"' ?>><?php echo $lang_prof_reg['UTC+13:00'] ?></option>
								<option value="14"<?php if ($user['timezone'] == 14) echo ' selected="selected"' ?>><?php echo $lang_prof_reg['UTC+14:00'] ?></option>
							</select>
							<br /></label>
							<div class="rbox">
								<label><input type="checkbox" name="form[dst]" value="1"<?php if ($user['dst'] == '1') echo ' checked="checked"' ?> /><?php echo $lang_prof_reg['DST'] ?><br /></label>
							</div>
							<label><?php echo $lang_prof_reg['Time format'] ?>

							<br /><select name="form[time_format]">
<?php
								foreach (array_unique($forum_time_formats) as $key => $time_format)
								{
									echo "\t\t\t\t\t\t\t\t".'<option value="'.$key.'"';
									if ($user['time_format'] == $key)
										echo ' selected="selected"';
									echo '>'. format_time(time(), false, null, $time_format, true, true);
									if ($key == 0)
										echo ' ('.$lang_prof_reg['Default'].')';
									echo "</option>\n";
								}
								?>
							</select>
							<br /></label>
							<label><?php echo $lang_prof_reg['Date format'] ?>

							<br /><select name="form[date_format]">
<?php
								foreach (array_unique($forum_date_formats) as $key => $date_format)
								{
									echo "\t\t\t\t\t\t\t\t".'<option value="'.$key.'"';
									if ($user['date_format'] == $key)
										echo ' selected="selected"';
									echo '>'. format_time(time(), true, $date_format, null, false, true);
									if ($key == 0)
										echo ' ('.$lang_prof_reg['Default'].')';
									echo "</option>\n";
								}
								?>
							</select>
							<br /></label>
<?php
		$languages = forum_list_langs();

		// Only display the language selection box if there's more than one language available
		if (count($languages) > 1)
		{
?>
							<label><?php echo $lang_prof_reg['Language'] ?>
							<br /><select name="form[language]">
<?php
			foreach ($languages as $temp)
			{
				if ($user['language'] == $temp)
					echo "\t\t\t\t\t\t\t\t".'<option value="'.$temp.'" selected="selected">'.$temp.'</option>'."\n";
				else
					echo "\t\t\t\t\t\t\t\t".'<option value="'.$temp.'">'.$temp.'</option>'."\n";
			}
?>
							</select>
							<br /></label>
<?php
		}
?>
						</div>
					</fieldset>
				</div>
				<div class="inform">
					<fieldset>
						<legend><?php echo $lang_profile['User activity'] ?></legend>
						<div class="infldset">
							<p><?php printf($lang_profile['Registered info'], format_time($user['registered'], true).(($panther_user['is_admmod']) ? ' (<a href="'.get_link($panther_url['get_host'], array(panther_htmlspecialchars($user['registration_ip']))).'">'.panther_htmlspecialchars($user['registration_ip']).'</a>)' : '')) ?></p>
							<p><?php printf($lang_profile['Last post info'], $last_post) ?></p>
							<p><?php printf($lang_profile['Last visit info'], format_time($user['last_visit'])) ?></p>
							<?php echo $posts_field;
if (($panther_user['is_admin'] || ($panther_user['is_admmod'] && $panther_users['g_mod_warn_users'] == '1')) && $panther_config['o_warnings'] == '1')
	echo "\t\t\t\t\t\t\t".'<p>'.$warning_level.' - <a href="'.get_link($panther_url['warning_view'], array($id)).'">'.$lang_warnings['Show all warnings'].'</a> - <a href="'.get_link($panther_url['warn_user'], array($id)).'">'.$lang_warnings['Warn user'].'</a></p>';
else if (($panther_config['o_warning_status'] == '0' || $panther_user['is_admmod'] || ($panther_config['o_warning_status'] == '1' && $has_active)) && $panther_config['o_warnings'] == '1')
	echo "\t\t\t\t\t\t\t".'<p>'.$warning_level.' - <a href="'.get_link($panther_url['warning_view'], array($id)).'">'.$lang_warnings['Show all warnings'].'</a></p>';

if ($panther_user['is_admmod']): ?>							<label><?php echo $lang_profile['Admin note'] ?><br />
							<input id="admin_note" type="text" name="admin_note" value="<?php echo panther_htmlspecialchars($user['admin_note']) ?>" size="30" maxlength="30" /><br /></label>
<?php endif; ?>						</div>
					</fieldset>
				</div>
				<p class="buttons"><input type="submit" name="update" value="<?php echo $lang_common['Submit'] ?>" /> <?php echo $lang_profile['Instructions'] ?></p>
			</form>
		</div>
	</div>
<?php
	}
	else if ($section == 'personal')
	{
		if ($panther_user['g_set_title'] == '1')
			$title_field = '<label>'.$lang_common['Title'].' <em>('.$lang_profile['Leave blank'].')</em><br /><input type="text" name="title" value="'.panther_htmlspecialchars($user['title']).'" size="30" maxlength="50" /><br /></label>'."\n";

		$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_common['Profile'], $lang_profile['Section personal']);
		define('PANTHER_ACTIVE_PAGE', 'profile');
		require PANTHER_ROOT.'header.php';

		generate_profile_menu('personal');
?>
	<div class="blockform">
		<h2><span><?php echo panther_htmlspecialchars($user['username']).' - '.$lang_profile['Section personal'] ?></span></h2>
		<div class="box">
			<form id="profile2" method="post" action="<?php echo get_link($panther_url['profile_personal'], array($id)) ?>">
				<div class="inform">
					<fieldset>
						<legend><?php echo $lang_profile['Personal details legend'] ?></legend>
						<div class="infldset">
							<input type="hidden" name="form_sent" value="1" />
							<input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>" />
							<label><?php echo $lang_profile['Realname'] ?><br /><input type="text" name="form[realname]" value="<?php echo panther_htmlspecialchars($user['realname']) ?>" size="40" maxlength="40" /><br /></label>
<?php if (isset($title_field)): ?>							<?php echo $title_field ?>
<?php endif; ?>							<label><?php echo $lang_profile['Location'] ?><br /><input type="text" name="form[location]" value="<?php echo panther_htmlspecialchars($user['location']) ?>" size="30" maxlength="30" /><br /></label>
<?php if ($panther_user['g_post_links'] == '1' || $panther_user['is_admin']) : ?>							<label><?php echo $lang_profile['Website'] ?><br /><input type="text" name="form[url]" value="<?php echo panther_htmlspecialchars($user['url']) ?>" size="50" maxlength="80" /><br /></label>
<?php endif; ?>
						</div>
					</fieldset>
				</div>
				<p class="buttons"><input type="submit" name="update" value="<?php echo $lang_common['Submit'] ?>" /> <?php echo $lang_profile['Instructions'] ?></p>
			</form>
		</div>
	</div>
<?php
	}
	else if ($section == 'messaging')
	{
		$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_common['Profile'], $lang_profile['Section messaging']);
		define('PANTHER_ACTIVE_PAGE', 'profile');
		require PANTHER_ROOT.'header.php';

		generate_profile_menu('messaging');
?>
	<div class="blockform">
		<h2><span><?php echo panther_htmlspecialchars($user['username']).' - '.$lang_profile['Section messaging'] ?></span></h2>
		<div class="box">
			<form id="profile3" method="post" action="<?php echo get_link($panther_url['profile_messaging'], array($id)) ?>">
				<div class="inform">
					<fieldset>
						<legend><?php echo $lang_profile['Contact details legend'] ?></legend>
						<div class="infldset">
							<input type="hidden" name="form_sent" value="1" />
							<input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>" />
							<label><?php echo $lang_profile['Facebook'] ?><br /><input id="facebook" type="text" name="form[facebook]" value="<?php echo panther_htmlspecialchars($user['facebook']) ?>" size="40" maxlength="75" /><br /></label>
							<label><?php echo $lang_profile['Steam'] ?><br /><input id="steam" type="text" name="form[steam]" value="<?php echo $user['steam'] ?>" size="12" maxlength="12" /><br /></label>
							<label><?php echo $lang_profile['MSN'] ?><br /><input id="msn" type="text" name="form[msn]" value="<?php echo panther_htmlspecialchars($user['msn']) ?>" size="40" maxlength="50" /><br /></label>
							<label><?php echo $lang_profile['Twitter'] ?><br /><input id="twitter" type="text" name="form[twitter]" value="<?php echo panther_htmlspecialchars($user['twitter']) ?>" size="20" maxlength="30" /><br /></label>
							<label><?php echo $lang_profile['Google'] ?><br /><input id="google" type="text" name="form[google]" value="<?php echo panther_htmlspecialchars($user['google']) ?>" size="20" maxlength="30" /><br /></label>
						</div>
					</fieldset>
				</div>
				<p class="buttons"><input type="submit" name="update" value="<?php echo $lang_common['Submit'] ?>" /> <?php echo $lang_profile['Instructions'] ?></p>
			</form>
		</div>
	</div>
<?php
	}
	else if ($section == 'personality')
	{
		if ($panther_config['o_avatars'] == '0' && $panther_config['o_signatures'] == '0')
			message($lang_common['Bad request'], false, '404 Not Found');

		if ($panther_config['o_avatar_upload'] == '1')
			$avatar_field = '<span><a href="'.get_link($panther_url['upload_avatar'], array($id, generate_csrf_token())).'">'.$lang_profile['Change avatar'].'</a></span>';
		else
			$avatar_field = '';

		$user_avatar = generate_avatar_markup($id, $user['email'], $user['use_gravatar']);
		if (stristr($user_avatar, '1.'.$panther_config['o_avatar']) === false && $user['use_gravatar'] == '0')
			$avatar_field .= ' <span><a href="'.get_link($panther_url['delete_avatar'], array($id, generate_csrf_token())).'">'.$lang_profile['Delete avatar'].'</a></span>';
		else
		{
			if ($panther_config['o_avatar_upload'] == '1')
				$avatar_field = '<span><a href="'.get_link($panther_url['upload_avatar'], array($id, generate_csrf_token())).'">'.$lang_profile['Upload avatar'].'</a></span>';
		}

		$avatar_field .= '<span><a href="'.get_link($panther_url['use_gravatar'], array($id, generate_csrf_token())).'">'.(($user['use_gravatar'] == '1') ? $lang_profile['Disable gravatar'] : $lang_profile['Use gravatar']).'</a></span>';

		if ($user['signature'] != '')
			$signature_preview = '<p>'.$lang_profile['Sig preview'].'</p>'."\n\t\t\t\t\t\t\t".'<div class="postsignature postmsg">'."\n\t\t\t\t\t\t\t\t".'<hr />'."\n\t\t\t\t\t\t\t\t".$parsed_signature."\n\t\t\t\t\t\t\t".'</div>'."\n";
		else
			$signature_preview = '<p>'.$lang_profile['No sig'].'</p>'."\n";

		$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_common['Profile'], $lang_profile['Section personality']);
		define('POSTING', 1);
		define('PANTHER_ACTIVE_PAGE', 'profile');
		require PANTHER_ROOT.'header.php';

		generate_profile_menu('personality');
?>
	<div class="blockform">
		<h2><span><?php echo panther_htmlspecialchars($user['username']).' - '.$lang_profile['Section personality'] ?></span></h2>
		<div class="box">
			<form id="profile4" method="post" action="<?php echo get_link($panther_url['profile_personality'], array($id)) ?>">
				<div><input type="hidden" name="form_sent" value="1" /><input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>" /></div>
<?php if ($panther_config['o_avatars'] == '1'): ?>				<div class="inform">
					<fieldset id="profileavatar">
						<legend><?php echo $lang_profile['Avatar legend'] ?></legend>
						<div class="infldset">
<?php if ($user_avatar): ?>							<div class="useravatar"><?php echo $user_avatar ?></div>
<?php endif; ?>							<p><?php echo $lang_profile['Avatar info'] ?></p>
							<p class="clearb actions"><?php echo $avatar_field ?></p>
						</div>
					</fieldset>
				</div>
<?php endif; if ($panther_config['o_signatures'] == '1'): ?>				<div class="inform">
					<fieldset>
						<legend><?php echo $lang_profile['Signature legend'] ?></legend>
						<div class="infldset">
							<p><?php echo $lang_profile['Signature info'] ?></p>
							<div class="txtarea">
								<label><?php printf($lang_profile['Sig max size'], forum_number_format($panther_config['p_sig_length']), $panther_config['p_sig_lines']) ?><br />
								<textarea name="signature" class="scedit_bbcode"<?php if ($panther_user['use_editor'] == '1') echo ' onclick="$(\'.scedit_bbcode\').sceditor(\'instance\').updateOriginal();"'; ?> rows="6" cols="65"><?php echo panther_htmlspecialchars($user['signature']) ?></textarea><br /></label>
							</div>
							<ul class="bblinks">
								<li><span><a href="<?php echo get_link($panther_url['help'], array('bbcode')); ?>" onclick="window.open(this.href); return false;"><?php echo $lang_common['BBCode'] ?></a> <?php echo ($panther_config['p_sig_bbcode'] == '1') ? $lang_common['on'] : $lang_common['off']; ?></span></li>
								<li><span><a href="<?php echo get_link($panther_url['help'], array('url')); ?>" onclick="window.open(this.href); return false;"><?php echo $lang_common['url tag'] ?></a> <?php echo ($panther_config['p_sig_bbcode'] == '1' && $panther_user['g_post_links'] == '1') ? $lang_common['on'] : $lang_common['off']; ?></span></li>
								<li><span><a href="<?php echo get_link($panther_url['help'], array('img')); ?>" onclick="window.open(this.href); return false;"><?php echo $lang_common['img tag'] ?></a> <?php echo ($panther_config['p_sig_bbcode'] == '1' && $panther_config['p_sig_img_tag'] == '1') ? $lang_common['on'] : $lang_common['off']; ?></span></li>
								<li><span><a href="<?php echo get_link($panther_url['help'], array('smilies')); ?>" onclick="window.open(this.href); return false;"><?php echo $lang_common['Smilies'] ?></a> <?php echo ($panther_config['o_smilies_sig'] == '1') ? $lang_common['on'] : $lang_common['off']; ?></span></li>
							</ul>
							<?php echo $signature_preview ?>
						</div>
					</fieldset>
				</div>
<?php endif; ?>				<p class="buttons"><input type="submit" name="update" value="<?php echo $lang_common['Submit'] ?>" /> <?php echo $lang_profile['Instructions'] ?></p>
			</form>
		</div>
	</div>
<?php
	}
	else if ($section == 'display')
	{
		$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_common['Profile'], $lang_profile['Section display']);
		define('PANTHER_ACTIVE_PAGE', 'profile');
		require PANTHER_ROOT.'header.php';

		generate_profile_menu('display');
?>
	<div class="blockform">
		<h2><span><?php echo panther_htmlspecialchars($user['username']).' - '.$lang_profile['Section display'] ?></span></h2>
		<div class="box">
			<form id="profile5" method="post" action="<?php echo get_link($panther_url['profile_display'], array($id)) ?>">
				<div><input type="hidden" name="form_sent" value="1" /><input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>" /></div>
<?php
		$styles = forum_list_styles();

		// Only display the style selection box if there's more than one style available
		if (count($styles) == 1)
			echo "\t\t\t".'<div><input type="hidden" name="form[style]" value="'.$styles[0].'" /></div>'."\n";
		else if (count($styles) > 1)
		{
?>
				<div class="inform">
					<fieldset>
						<legend><?php echo $lang_profile['Style legend'] ?></legend>
						<div class="infldset">
							<label><?php echo $lang_profile['Styles'] ?><br />
							<select name="form[style]">
<?php
			foreach ($styles as $temp)
			{
				if ($user['style'] == $temp)
					echo "\t\t\t\t\t\t\t\t".'<option value="'.$temp.'" selected="selected">'.str_replace('_', ' ', $temp).'</option>'."\n";
				else
					echo "\t\t\t\t\t\t\t\t".'<option value="'.$temp.'">'.str_replace('_', ' ', $temp).'</option>'."\n";
			}
?>
							</select>
							<br /></label>
						</div>
					</fieldset>
				</div>
<?php
		}
?>
				<div class="inform">
					<fieldset>
						<legend><?php echo $lang_profile['Post display legend'] ?></legend>
						<div class="infldset">
							<p><?php echo $lang_profile['Post display info'] ?></p>
							<div class="rbox">
<?php if ($panther_config['o_smilies'] == '1' || $panther_config['o_smilies_sig'] == '1'): ?>								<label><input type="checkbox" name="form[show_smilies]" value="1"<?php if ($user['show_smilies'] == '1') echo ' checked="checked"' ?> /><?php echo $lang_profile['Show smilies'] ?><br /></label>
<?php endif; if ($panther_config['o_signatures'] == '1'): ?>								<label><input type="checkbox" name="form[show_sig]" value="1"<?php if ($user['show_sig'] == '1') echo ' checked="checked"' ?> /><?php echo $lang_profile['Show sigs'] ?><br /></label>
<?php endif; if ($panther_config['o_avatars'] == '1'): ?>								<label><input type="checkbox" name="form[show_avatars]" value="1"<?php if ($user['show_avatars'] == '1') echo ' checked="checked"' ?> /><?php echo $lang_profile['Show avatars'] ?><br /></label>
<?php endif; if ($panther_config['p_message_bbcode'] == '1' && $panther_config['p_message_img_tag'] == '1'): ?>								<label><input type="checkbox" name="form[show_img]" value="1"<?php if ($user['show_img'] == '1') echo ' checked="checked"' ?> /><?php echo $lang_profile['Show images'] ?><br /></label>
<?php endif; if ($panther_config['o_signatures'] == '1' && $panther_config['p_sig_bbcode'] == '1' && $panther_config['p_sig_img_tag'] == '1'): ?>								<label><input type="checkbox" name="form[show_img_sig]" value="1"<?php if ($user['show_img_sig'] == '1') echo ' checked="checked"' ?> /><?php echo $lang_profile['Show images sigs'] ?><br /></label><?php endif; ?>
								<label><input type="checkbox" name="form[use_editor]" value="1"<?php if ($user['use_editor'] == '1') echo ' checked="checked"' ?> /><?php echo $lang_profile['Use editor'] ?><br /></label>
							</div>
						</div>
					</fieldset>
				</div>
				<div class="inform">
					<fieldset>
						<legend><?php echo $lang_profile['Pagination legend'] ?></legend>
						<div class="infldset">
							<label class="conl"><?php echo $lang_profile['Topics per page'] ?><br /><input type="text" name="form[disp_topics]" value="<?php echo $user['disp_topics'] ?>" size="6" maxlength="2" /><br /></label>
							<label class="conl"><?php echo $lang_profile['Posts per page'] ?><br /><input type="text" name="form[disp_posts]" value="<?php echo $user['disp_posts'] ?>" size="6" maxlength="2" /><br /></label>
							<p class="clearb"><?php echo $lang_profile['Paginate info'] ?> <?php echo $lang_profile['Leave blank'] ?></p>
						</div>
					</fieldset>
				</div>
<?php if ($panther_config['o_reputation'] == '1')
	{
		switch(true)
		{
			case $user['reputation'] > '0':
				$type = 'positive';
			break;
			case $user['reputation'] < '0':
				$type = 'negative';
			break;
			default:
				$type = 'zero';
			break;
		}

		$user_reputation = '<span class="reputation '.$type.'">'.$lang_profile['Reputation'].': '.$user['reputation'].'</span><br /><br />';
?>
				<div class="inform">
                    <fieldset>
                        <legend><?php echo $lang_profile['Reputation'] ?></legend>
                        <div class="infldset">
<?php echo $user_reputation; ?>
                       <label><a href="<?php echo get_link($panther_url['profile_rep_received'], array($id)); ?>"><?php echo $lang_profile['Rep_received'] ?></a><br /></label>
                       <label><a href="<?php echo get_link($panther_url['profile_rep_given'], array($id)); ?>"><?php echo $lang_profile['Rep_given'] ?></a><br /></label>
                        </div>
                    </fieldset>
				</div>
<?php } ?>
				<p class="buttons"><input type="submit" name="update" value="<?php echo $lang_common['Submit'] ?>" /> <?php echo $lang_profile['Instructions'] ?></p>
			</form>
		</div>
	</div>
<?php
	}
	elseif ($section == 'rep_received' || $section == 'rep_given')
	{
		if ($panther_config['o_reputation'] == '0')
			message($lang_common['Bad request']);

		define('REPUTATION', 1);
		$page = (!isset($_GET['p']) || $_GET['p'] <= '1') ? '1' : intval($_GET['p']);
		$data = array(
			':id'	=>	$id,
		);

		if ($section == 'rep_received')
			$sql = "SELECT COUNT(r.id) FROM ".$db->prefix."reputation AS r LEFT JOIN ".$db->prefix."posts AS p ON r.post_id=p.id WHERE p.poster_id=:id";
		else
			$sql = "SELECT COUNT(id) FROM ".$db->prefix."reputation WHERE given_by=:id";

		$ps = $db->run($sql, $data);
		$total = $ps->fetchColumn();

		//What page are we on?
		$num_pages = ceil($total/$panther_config['o_disp_topics_default']);
		if ($page > $num_pages) $page = 1;
		$start_from = intval($panther_config['o_disp_topics_default'])*($page-1);
		$limit = $start_from.','.$panther_config['o_disp_topics_default'];

		switch ($section)
		{
			case 'rep_received':
				$data[':id1'] = $id;
			
				$sql = "SELECT r.id, r.given_by, u.group_id, u.username, r.time_given, r.post_id, r.vote, p.topic_id, t.subject, :id1 AS given_to FROM ".$db->prefix."reputation AS r LEFT JOIN ".$db->prefix."users AS u ON u.id = r.given_by LEFT JOIN ".$db->prefix."posts AS p ON p.id = r.post_id LEFT JOIN ".$db->prefix."topics AS t ON t.id = p.topic_id WHERE p.poster_id=:id ORDER BY r.id DESC LIMIT ".$limit;
				$ps = $db->run($sql, $data);
				
				if (!$ps->rowCount())
					message($lang_profile['No received reputation']);
			break;
			default:
				$sql = "SELECT r.id, p.poster_id AS given_to, u.group_id, r.given_by, r.time_given, r.post_id, r.vote, u.username, p.topic_id, t.subject FROM ".$db->prefix."reputation AS r LEFT JOIN ".$db->prefix."posts AS p ON p.id = r.post_id LEFT JOIN ".$db->prefix."users AS u ON u.id = p.poster_id LEFT JOIN ".$db->prefix."topics AS t ON t.id = p.topic_id WHERE r.given_by=:id ORDER BY r.id DESC LIMIT ".$limit;
				$ps = $db->run($sql, $data); 
				
				if (!$ps->rowCount())
					message($lang_profile['No given reputation']);
			break;
		}

		define('PANTHER_ACTIVE_PAGE', 'profile');
		$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_common['Profile'], panther_htmlspecialchars($user['username']), $lang_profile['Reputation']);
		require PANTHER_ROOT.'header.php';
		$rep_count = '0';
?>
<div class="linkst">
	<div class="inbox crumbsplus">
		<ul class="crumbs">
			<li><a href="<?php echo get_link($panther_url['index']); ?>"><?php echo $lang_common['Index'] ?></a></li>
			<li><span>»&#160;</span><a href="<?php echo get_link($panther_url['profile'], array($id)) ?>"><?php echo sprintf($lang_profile['User rep link'], panther_htmlspecialchars($user['username'])); ?></a></li>
			<li><span>»&#160;</span><strong><?php echo $lang_profile[ucfirst($section)] ?></strong></li>
		</ul>
		<div class="pagepost"><p class="pagelink conl"><span class="pages-label"><?php echo $lang_common['Pages'].' '.paginate($num_pages, $page, $panther_url['profile_'.strtolower($section)], array($id)) ?></span></p>
</div>
		<div class="clearer"></div>
	</div>
</div>
<div id="vf" class="blocktable">
	<h2><span><?php echo $lang_profile[ucfirst($section)]; ?></span></h2>
	<div class="box">
		<div class="inbox">
			<table cellspacing="0">
			<thead>
				<tr>
					<th class="tc2" scope="col"><?php echo $lang_profile['Rep type']; ?></th>
					<th class="tc2" scope="col"><?php echo (($section == 'rep_received') ? $lang_profile['Given by'] : $lang_profile['Given to']); ?></th>
					<th class="tc2" scope="col"><?php echo $lang_profile['Date rep given']; ?></th>
					<th class="tc2" scope="col"><?php echo $lang_profile['Rep post topic']; ?></th>
					<?php if ($panther_user['is_admmod'] && ($panther_user['g_mod_edit_users'] == '1' || $panther_user['is_admin'])): ?>
					<th class="tc3" scope="col"><?php echo $lang_profile['Remove reputation']; ?></th>
					<?php endif; ?>
				</tr>
			</thead>
			<tbody>
<?php
		foreach ($ps as $reputation)
		{
			if ($reputation['username'] == '')
			{
				$reputation['username'] = $lang_profile['Deleted user'];
				$reputation['group_id'] = PANTHER_GUEST;
			}

			if ($reputation['given_by'] == '')
				$reputation['given_by'] = PANTHER_GUEST;
				
			if ($reputation['given_to'] == '')
				$reputation['given_to'] = PANTHER_GUEST;

			if ($reputation['subject'] == '')
				$subject = $lang_profile['Deleted post'];
			else
				$subject = '<a href="'.get_link($panther_url['post'], array($reputation['post_id'])).'">'.panther_htmlspecialchars($reputation['subject']).'</a>';

			if ($panther_user['g_view_users'] == '0')
				$profile_link = colourize_group($reputation['username'], $reputation['group_id']);
			else
			{
				if ($section == 'rep_received')
						$profile_link = colourize_group($reputation['username'], $reputation['group_id'], $reputation['given_by']);
				else
						$profile_link = colourize_group($reputation['username'], $reputation['group_id'], $reputation['given_to']);
			}
?>
				<tr class="<?php echo ($rep_count % 2 == 0) ? 'roweven' : 'rowodd'; ?>">
					<td class="tc1"><img src="img/<?php echo (($reputation['vote'] == '1') ? 'plus' : 'minus') ?>.png" width="16" height="16">&nbsp;<?php echo (($reputation['vote'] == '1') ? $lang_profile['Positive'] : $lang_profile['Negative']) ?></td>
					<td class="tc2"><?php echo $profile_link ?></td>
					<td class="tc2"><?php echo format_time($reputation['time_given']); ?></td>
					<td class="tc2"><?php echo $subject; ?></td>
				<?php if ($panther_user['is_admmod'] && ($panther_user['g_mod_edit_users'] == '1' || $panther_user['is_admin'])): ?>
					<td class="tc3"><a href="javascript:remove_reputation(<?php echo $reputation['id']; ?>, <?php echo $id ?>, <?php echo $page ?>, '<?php echo $section; ?>');"><?php echo $lang_profile['Remove reputation']; ?></a></td>
				<?php endif; ?>
				</tr>
<?php 
		}
?>
				</div>
				</tbody>
			</table>
		</div>
	</div>
</div>
<div class="linksb">
	<div class="inbox crumbsplus">
		<div class="pagepost">
			<p class="pagelink conl"><span class="pages-label"><?php echo $lang_common['Pages'].' '.paginate($num_pages, $page, $panther_url['profile_'.strtolower($section)], array($id)); ?></span></p>
		</div>
	</div>
</div>
	<div class="inbox crumbsplus">
		<ul class="crumbs">
			<li><a href="<?php echo get_link($panther_url['index']); ?>"><?php echo $lang_common['Index'] ?></a></li>
			<li><span>»&#160;</span><a href="<?php echo get_link($panther_url['profile'], array($id)) ?>"><?php echo sprintf($lang_profile['User rep link'], panther_htmlspecialchars($user['username'])); ?></a></li>
			<li><span>»&#160;</span><strong><?php echo $lang_profile[ucfirst($section)] ?></strong></li>
		</ul>
				<div class="clearer"></div>
	</div>
<?php
	}
	else if ($section == 'privacy')
	{
		$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_common['Profile'], $lang_profile['Section privacy']);
		define('PANTHER_ACTIVE_PAGE', 'profile');
		require PANTHER_ROOT.'header.php';

		generate_profile_menu('privacy');
?>
	<div class="blockform">
		<h2><span><?php echo panther_htmlspecialchars($user['username']).' - '.$lang_profile['Section privacy'] ?></span></h2>
		<div class="box">
			<form id="profile6" method="post" action="<?php echo get_link($panther_url['profile_privacy'], array($id)) ?>">
				<div class="inform">
					<fieldset>
						<legend><?php echo $lang_prof_reg['Privacy options legend'] ?></legend>
						<div class="infldset">
							<input type="hidden" name="form_sent" value="1" />
							<input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>" />
							<p><?php echo $lang_prof_reg['Email setting info'] ?></p>
							<div class="rbox">
								<label><input type="radio" name="form[email_setting]" value="0"<?php if ($user['email_setting'] == '0') echo ' checked="checked"' ?> /><?php echo $lang_prof_reg['Email setting 1'] ?><br /></label>
								<label><input type="radio" name="form[email_setting]" value="1"<?php if ($user['email_setting'] == '1') echo ' checked="checked"' ?> /><?php echo $lang_prof_reg['Email setting 2'] ?><br /></label>
								<label><input type="radio" name="form[email_setting]" value="2"<?php if ($user['email_setting'] == '2') echo ' checked="checked"' ?> /><?php echo $lang_prof_reg['Email setting 3'] ?><br /></label>
							</div>
						</div>
					</fieldset>
				</div>
<?php if ($panther_config['o_forum_subscriptions'] == '1' || $panther_config['o_topic_subscriptions'] == '1'): ?>				<div class="inform">
					<fieldset>
						<legend><?php echo $lang_profile['Subscription legend'] ?></legend>
						<div class="infldset">
							<div class="rbox">
								<label><input type="checkbox" name="form[notify_with_post]" value="1"<?php if ($user['notify_with_post'] == '1') echo ' checked="checked"' ?> /><?php echo $lang_profile['Notify full'] ?><br /></label>
<?php if ($panther_config['o_topic_subscriptions'] == '1'): ?>								<label><input type="checkbox" name="form[auto_notify]" value="1"<?php if ($user['auto_notify'] == '1') echo ' checked="checked"' ?> /><?php echo $lang_profile['Auto notify full'] ?><br /></label>
<?php endif; ?>
							</div>
						</div>
					</fieldset>
				</div>
<?php endif; if ($panther_config['o_private_messaging'] == '1' && $user['g_use_pm'] == '1'): ?>
				<div class="inform">
					<fieldset>
						<legend><?php echo $lang_profile['Private messaging'] ?></legend>
						<div class="infldset">
							<input type="hidden" name="form_sent" value="1" />
							<input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>" />
							<div class="rbox">
								<label><input type="checkbox" name="form[pm_enabled]" value="1"<?php if ($user['pm_enabled'] == '1') echo ' checked="checked"' ?> /><?php echo $lang_profile['PM enabled'] ?><br /></label>
								<label><input type="checkbox" name="form[pm_notify]" value="1"<?php if ($user['pm_notify'] == '1') echo ' checked="checked"' ?> /><?php echo $lang_profile['PM notify'] ?><br /></label>
							</div>
						</div>
					</fieldset>
				</div>
				<?php endif; ?>
				<p class="buttons"><input type="submit" name="update" value="<?php echo $lang_common['Submit'] ?>" /> <?php echo $lang_profile['Instructions'] ?></p>
			</form>
		</div>
	</div>
<?php
	}
	else if ($section == 'admin')
	{
		if (!$panther_user['is_admmod'] || ($panther_user['g_moderator'] == '1' && $panther_user['g_mod_ban_users'] == '0'))
			message($lang_common['Bad request'], false, '403 Forbidden');

		$posting_ban = format_posting_ban_expiration(($user['posting_ban'] - time()), $lang_profile);
		$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_common['Profile'], $lang_profile['Section admin']);

		flux_hook('profile_admin_before_header');

		define('PANTHER_ACTIVE_PAGE', 'profile');
		require PANTHER_ROOT.'header.php';

		generate_profile_menu('admin');
?>
	<div class="blockform">
		<h2><span><?php echo panther_htmlspecialchars($user['username']).' - '.$lang_profile['Section admin'] ?></span></h2>
		<div class="box">
			<form id="profile7" method="post" action="<?php echo get_link($panther_url['profile_admin'], array($id)) ?>">
				<div class="inform">
				<input type="hidden" name="form_sent" value="1" />
				<input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>" />
<?php if ($user['g_moderator'] == '0' && $user['g_id'] != PANTHER_ADMIN && $user['g_admin'] == '0' && ($panther_user['is_admin'] == '1')): ?>
					<fieldset>
						<legend><?php echo $lang_profile['restrictions']; ?></legend>
						<div class="infldset">
						<p><?php echo $lang_profile['Posting ban'].(($posting_ban[2] != $lang_profile['Never']) ? sprintf($lang_profile['current ban'], format_time($user['posting_ban'])) : ''); ?></p>
						<p><input type="checkbox" name="remove_ban" value="1"><?php echo $lang_profile['posting ban delete']; ?></p>
<input type="text" name="expiration_time" size="5" maxlength="5" value="<?php echo $posting_ban[0]; ?>" tabindex="3" />
						<select name="expiration_unit">
							<option value="minutes"<?php if ($posting_ban[2] == $lang_profile['Minutes']) echo 'selected="selected" '; ?>><?php echo $lang_profile['Minutes']; ?></option>
							<option value="hours"<?php if ($posting_ban[2] == $lang_profile['Hours']) echo 'selected="selected" '; ?>><?php echo $lang_profile['Hours']; ?></option>
							<option value="days"<?php if ($posting_ban[2] == $lang_profile['Days'] || $posting_ban[2] == $lang_profile['Never']) echo 'selected="selected" '; ?>><?php echo $lang_profile['Days']; ?></option>
							<option value="months"<?php if ($posting_ban[2] == $lang_profile['Months']) echo 'selected="selected" '; ?>><?php echo $lang_profile['Months']; ?></option>
						</select>
							<input type="submit" name="update_posting_ban" value="<?php echo $lang_profile['Save'] ?>" />		</div>
					</fieldset>
<?php endif; ?>
					<fieldset>
<?php
		// If we're just a moderator
		if ($panther_user['g_moderator'] == '1' && $panther_user['g_admin'] == '0')
		{
?>
						<legend><?php echo $lang_profile['Delete ban legend'] ?></legend>
						<div class="infldset">
							<p><input type="submit" name="ban" value="<?php echo $lang_profile['Ban user'] ?>" /></p>
						</div>
					</fieldset>
				</div>
<?php
		}
		else
		{
			if (file_exists(FORUM_CACHE_DIR.'cache_restrictions.php'))
				require FORUM_CACHE_DIR.'cache_restrictions.php';
			else
			{
				if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
					require PANTHER_ROOT.'include/cache.php';

				generate_admin_restrictions_cache();
				require FORUM_CACHE_DIR.'cache_restrictions.php';
			}

			if (!isset($admins[$panther_user['id']]) || $panther_user['id'] == '2')
				$admins[$panther_user['id']] = array('admin_users' => '1');

			if ($panther_user['id'] != $id && $admins[$panther_user['id']]['admin_users'] == '1')
			{

?>
						<legend><?php echo $lang_profile['Group membership legend'] ?></legend>
						<div class="infldset">
							<select id="group_id" name="group_id">
<?php
				foreach ($panther_groups as $cur_group)
				{
					if ($cur_group['g_id'] != PANTHER_GUEST)
					{
						if ($cur_group['g_id'] == $user['g_id'] || ($cur_group['g_id'] == $panther_config['o_default_user_group'] && $user['g_id'] == ''))
							echo "\t\t\t\t\t\t\t\t".'<option value="'.$cur_group['g_id'].'" selected="selected">'.panther_htmlspecialchars($cur_group['g_title']).'</option>'."\n";
						else
							echo "\t\t\t\t\t\t\t\t".'<option value="'.$cur_group['g_id'].'">'.panther_htmlspecialchars($cur_group['g_title']).'</option>'."\n";
					}
				}

?>
							</select>
							<input type="submit" name="update_group_membership" value="<?php echo $lang_profile['Save'] ?>" />
						</div>
					</fieldset>
				</div>
				<div class="inform">
					<fieldset>
<?php
			}

			$delete = ($admins[$panther_user['id']]['admin_users'] == '1') ? '<input type="submit" name="delete_user" value="'.$lang_profile['Delete user'].'" /> ' : '';
?>
						<legend><?php echo $lang_profile['Delete ban legend'] ?></legend>
						<div class="infldset">
							<p><?php echo $delete; ?><input type="submit" name="ban" value="<?php echo $lang_profile['Ban user'] ?>" /></p>
						</div>
					</fieldset>
				</div>
<?php
			if ($user['g_moderator'] == '1' || $user['g_id'] == PANTHER_ADMIN)
			{
?>
				<div class="inform">
					<fieldset>
						<legend><?php echo $lang_profile['Set mods legend'] ?></legend>
						<div class="infldset">
							<p><?php echo $lang_profile['Moderator in info'] ?></p>
<?php
				$cur_category = 0;
				$ps = $db->run('SELECT c.id AS cid, c.cat_name, f.id AS fid, f.forum_name, f.moderators FROM '.$db->prefix.'categories AS c INNER JOIN '.$db->prefix.'forums AS f ON c.id=f.cat_id WHERE f.redirect_url IS NULL ORDER BY c.disp_position, c.id, f.disp_position');
				foreach ($ps as $cur_forum)
				{
					if ($cur_forum['cid'] != $cur_category) // A new category since last iteration?
					{
						if ($cur_category)
							echo "\n\t\t\t\t\t\t\t\t".'</div>';

						if ($cur_category != 0)
							echo "\n\t\t\t\t\t\t\t".'</div>'."\n";

						echo "\t\t\t\t\t\t\t".'<div class="conl">'."\n\t\t\t\t\t\t\t\t".'<p><strong>'.panther_htmlspecialchars($cur_forum['cat_name']).'</strong></p>'."\n\t\t\t\t\t\t\t\t".'<div class="rbox">';
						$cur_category = $cur_forum['cid'];
					}

					$moderators = ($cur_forum['moderators'] != '') ? unserialize($cur_forum['moderators']) : array();

					echo "\n\t\t\t\t\t\t\t\t\t".'<label><input type="checkbox" name="moderator_in['.$cur_forum['fid'].']" value="1"'.((in_array($id, $moderators)) ? ' checked="checked"' : '').' />'.panther_htmlspecialchars($cur_forum['forum_name']).'<br /></label>'."\n";
				}
?>
								</div>
							</div>
							<br class="clearb" /><input type="submit" name="update_forums" value="<?php echo $lang_profile['Update forums'] ?>" />
						</div>
					</fieldset>
				</div>
<?php
			}
		}
?>
			</form>
<?php flux_hook('profile_admin_after_form') ?>
		</div>
	</div>
<?php
	}
	else
		message($lang_common['Bad request'], false, '404 Not Found');
?>
	<div class="clearer"></div>
</div>
<?php
	require PANTHER_ROOT.'footer.php';
}