<?php
/**
 * Copyright (C) 2015 Panther (http://panther.strongholdnation.co.uk/)
 * based on code by Rickard Andersson copyright (C) 2002-2008 PunBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

// Tell header.php to use the admin template
define('PANTHER_ADMIN_CONSOLE', 1);

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/');
	require PANTHER_ROOT.'include/common.php';
}
require PANTHER_ROOT.'include/common_admin.php';

if (!$panther_user['is_admin'])
	message($lang_common['No permission'], false, '403 Forbidden');

if ($panther_user['id'] != '2')
{
	if(!is_null($admins[$panther_user['id']]['admin_robots']))
	{
		if ($admins[$panther_user['id']]['admin_robots'] == '0')
			message($lang_common['No permission'], false, '403 Forbidden');
	}
}

check_authentication();

// Load the admin_robots.php language file
require PANTHER_ROOT.'lang/'.$admin_language.'/admin_robots.php';

// Add a robot test
if (isset($_POST['add_test']))
{
	confirm_referrer('admin_robots.php');

	$question = panther_trim($_POST['new_question']);
	$answer = panther_trim($_POST['new_answer']);

	if ($question == '' || $answer == '')
		message($lang_admin_robots['Must enter question message']);

	$insert = array(
		'question'	=>	$question,
		'answer'	=>	$answer,
	);

	$db->insert('robots', $insert);

	// Regenerate the robots cache
	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PANTHER_ROOT.'include/cache.php';

	generate_robots_cache();
	redirect(get_link($panther_url['admin_robots']), $lang_admin_robots['Question added redirect']);
}

// Update a robot question
else if (isset($_POST['update']))
{
	confirm_referrer('admin_robots.php');

	$id = intval(key($_POST['update']));

	$question = panther_trim($_POST['question'][$id]);
	$answer = panther_trim($_POST['answer'][$id]);

	if ($question == '' || $answer == '')
		message($lang_admin_robots['Must enter question message']);

	$update = array(
		'question'	=>	$question,
		'answer'	=>	$answer,
	);
	
	$data = array(
		':id'	=>	$id,
	);

	$db->update('robots', $update, 'id=:id', $data);

	// Regenerate the robots cache
	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PANTHER_ROOT.'include/cache.php';

	generate_robots_cache();
	redirect(get_link($panther_url['admin_robots']), $lang_admin_robots['Question updated redirect']);
}

// Remove a robot test
else if (isset($_POST['remove']))
{
	confirm_referrer('admin_robots.php');
	$id = intval(key($_POST['remove']));
	$data = array(
		':id'	=>	$id,
	);

	$db->delete('robots', 'id=:id', $data);

	// Regenerate the robots cache
	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PANTHER_ROOT.'include/cache.php';

	generate_robots_cache();
	redirect(get_link($panther_url['admin_robots']),  $lang_admin_robots['Question removed redirect']);
}

$ps = $db->select('robots', 'id, question, answer', array(), '', 'id');

$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_admin_common['Admin'], $lang_admin_common['Robots']);
$focus_element = array('robots', 'new_question');
define('PANTHER_ACTIVE_PAGE', 'admin');
require PANTHER_ROOT.'header.php';

generate_admin_menu('robots');
?>
	<div class="blockform">
		<h2><span><?php echo $lang_admin_robots['Robots head'] ?></span></h2>
		<div class="box">
			<form id="censoring" method="post" action="<?php echo get_link($panther_url['admin_robots']); ?>">
				<input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>" />
				<div class="inform">
					<fieldset>
						<legend><?php echo $lang_admin_robots['Add question subhead'] ?></legend>
						<div class="infldset">
							<p><?php echo $lang_admin_robots['Add question info'] ?></p>
							<table>
							<thead>
								<tr>
									<th class="tcl" scope="col"><?php echo $lang_admin_robots['Question label'] ?></th>
									<th class="tc2" scope="col"><?php echo $lang_admin_robots['Answer label'] ?></th>
									<th class="hidehead" scope="col"><?php echo $lang_admin_robots['Action label'] ?></th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td class="tcl"><input type="text" name="new_question" size="24" maxlength="90" tabindex="1" /></td>
									<td class="tc2"><input type="text" name="new_answer" size="24" maxlength="60" tabindex="2" /></td>
									<td><input type="submit" name="add_test" value="<?php echo $lang_admin_common['Add'] ?>" tabindex="3" /></td>
								</tr>
							</tbody>
							</table>
						</div>
					</fieldset>
				</div>
				<div class="inform">
					<fieldset>
						<legend><?php echo $lang_admin_robots['Edit remove subhead'] ?></legend>
						<div class="infldset">
<?php
if ($ps->rowCount())
{
?>
							<table>
							<thead>
								<tr>
									<th class="tcl" scope="col"><?php echo $lang_admin_robots['Question label'] ?></th>
									<th class="tc2" scope="col"><?php echo $lang_admin_robots['Answer label'] ?></th>
									<th class="hidehead" scope="col"><?php echo $lang_admin_robots['Action label'] ?></th>
								</tr>
							</thead>
							<tbody>
<?php
	foreach ($ps as $cur_test)
		echo "\t\t\t\t\t\t\t\t".'<tr><td class="tcl"><input type="text" name="question['.$cur_test['id'].']" value="'.panther_htmlspecialchars($cur_test['question']).'" size="24" maxlength="90" /></td><td class="tc2"><input type="text" name="answer['.$cur_test['id'].']" value="'.panther_htmlspecialchars($cur_test['answer']).'" size="24" maxlength="60" /></td><td><input type="submit" name="update['.$cur_test['id'].']" value="'.$lang_admin_common['Update'].'" />&#160;<input type="submit" name="remove['.$cur_test['id'].']" value="'.$lang_admin_common['Remove'].'" /></td></tr>'."\n";
?>
							</tbody>
							</table>
<?php
}
else
	echo "\t\t\t\t\t\t\t".'<p>'.$lang_admin_robots['No questions in list'].'</p>'."\n";
?>
						</div>
					</fieldset>
				</div>
			</form>
		</div>
	</div>
	<div class="clearer"></div>
</div>
<?php
require PANTHER_ROOT.'footer.php';