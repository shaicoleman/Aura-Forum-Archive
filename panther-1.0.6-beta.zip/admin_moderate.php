<?php
/**
 * Copyright (C) 2014 StrongholdNation (http://www.strongholdnation.co.uk)
 * based on code by Panther copyright (C) 2015 Panther (http://panther.strongholdnation.co.uk/)
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

// Tell header.php to use the admin template
define('PANTHER_ADMIN_CONSOLE', 1);

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/');
	require PANTHER_ROOT.'include/common.php';
}
require PANTHER_ROOT.'include/common_admin.php';
$action = isset($_GET['action']) ? panther_htmlspecialchars($_GET['action']) : null;
$id = isset($_GET['id']) ? intval($_GET['id']) : '0';
$page = (!isset($_GET['p']) || $_GET['p'] <= '1') ? '1' : intval($_GET['p']);

if (!$panther_user['is_admin'])
	message($lang_common['No permission'], false, '403 Forbidden');

if ($panther_user['id'] != '2')
{
	if(!is_null($admins[$panther_user['id']]['admin_moderate']))
	{
		if ($admins[$panther_user['id']]['admin_moderate'] == '0')
			message($lang_common['No permission'], false, '403 Forbidden');
	}
}

check_authentication();

// Load the admin_moderate.php language file
require PANTHER_ROOT.'lang/'.$admin_language.'/admin_moderate.php';

if (isset($_POST['form_sent']))
{
	if ($action == 'add')
	{
		$message = isset($_POST['message']) ? panther_trim($_POST['message']) : null;
		$title = isset($_POST['title']) ? panther_trim($_POST['title']) : null;
		$add_start = isset($_POST['add_start']) ? utf8_ltrim($_POST['add_start']) : null;
		$add_end = isset($_POST['add_end']) ? utf8_rtrim($_POST['add_end']) : null;
		$increment = isset($_POST['increment']) ? intval($_POST['increment']) : '0';
		$send_email = isset($_POST['send_email']) ? intval($_POST['send_email']) : '0';
		
		if (strlen($title) > 50)
			message($lang_admin_moderate['title too long']);
			
		if (strlen($add_start) > 50 || strlen($add_end) > 50)
			message($lang_admin_moderate['addition too long']);

		if (strlen($title) < 1)
			message($lang_common['Bad request']);
	
		$close = isset($_POST['close']) ? intval($_POST['close']) : '2';
		$stick = isset($_POST['stick']) ? intval($_POST['stick']) : '2';
		$move = isset($_POST['forum']) ? intval($_POST['forum']) : '0';
		$leave_redirect = isset($_POST['redirect']) ? intval($_POST['redirect']) : '0';
		$reply = isset($_POST['reply']) ? intval($_POST['reply']) : '0';
	
		$insert = array(
			'title'	=>	$title,
			'close'	=>	$close,
			'stick'	=>	$stick,
			'move'	=>	$move,
			'leave_redirect'	=>	$leave_redirect,
			'add_reply'	=>	$reply,
			'reply_message'	=>	$message,
			'add_start'	=>	$add_start,
			'add_end'	=>	$add_end,
			'send_email'	=>	$send_email,
			'increment_posts'	=>	$increment,
		);

		$db->insert('multi_moderation', $insert);
		redirect(get_link($panther_url['admin_moderate']), $lang_admin_moderate['added redirect']);
	}
	elseif ($action == 'edit' && $id > '0')
	{
		
		$message = isset($_POST['message']) ? panther_trim($_POST['message']) : null;
		$title = isset($_POST['title']) ? panther_trim($_POST['title']) : null;
		$add_start = isset($_POST['add_start']) ? utf8_ltrim($_POST['add_start']) : null;
		$add_end = isset($_POST['add_end']) ? utf8_rtrim($_POST['add_end']) : null;

		if (strlen($title) > 50)
			message($lang_admin_moderate['title too long']);
			
		if (strlen($add_start) > 50 || strlen($add_end) > 50)
			message($lang_admin_moderate['addition too long']);
	
		if (strlen($title) < 1)
			message($lang_common['Bad request']);
	
		$close = isset($_POST['close']) ? intval($_POST['close']) : '2';
		$stick = isset($_POST['stick']) ? intval($_POST['stick']) : '2';
		$move = isset($_POST['forum']) ? intval($_POST['forum']) : '0';
		$leave_redirect = isset($_POST['redirect']) ? intval($_POST['redirect']) : '0';
		$reply = isset($_POST['reply']) ? intval($_POST['reply']) : '0';
		$increment = isset($_POST['increment']) ? intval($_POST['increment']) : '0';
		$send_email = isset($_POST['send_email']) ? intval($_POST['send_email']) : '0';
		
		$update = array(
			'title'	=>	$title,
			'close'	=>	$close,
			'stick'	=>	$stick,
			'move'	=>	$move,
			'leave_redirect'	=>	$leave_redirect,
			'add_reply'	=>	$reply,
			'reply_message'	=>	$message,
			'add_start'	=>	$add_start,
			'add_end'	=>	$add_end,
			'send_email'	=>	$send_email,
			'increment_posts'	=>	$increment,
		);
		
		$data = array(
			':id'	=>	$id,
		);

		$db->update('multi_moderation', $update, 'id=:id', $data);
		redirect('admin_moderate.php', $lang_admin_moderate['edit redirect']);
	}
	elseif ($action == 'delete' && $id > '0')
	{
		$data = array(
			':id'	=>	$id,
		);

		$rows = $db->delete('multi_moderation', 'id=:id', $data);
		if (!$rows)
			message($lang_common['Bad request']);	// If there are no rows returned we've either attempted to URL hack or something is wrong with the database (which will be displayed)

		redirect(get_link($panther_url['admin_moderate']), $lang_admin_moderate['delete redirect']);
	}
}

$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_admin_common['Admin'], $lang_admin_common['Moderate']);
define('PANTHER_ACTIVE_PAGE', 'admin');
require PANTHER_ROOT.'header.php';
	
generate_admin_menu('moderate'); 
if (!$action)
{
	$ps = $db->select('multi_moderation', 'COUNT(id)');
	$total = $ps->fetchColumn();
	
	$num_pages = ceil($total/15);
	if ($page > $num_pages) $page = 1;
	$start_from = 15*($page-1);
	
	$ps = $db->select('multi_moderation', 'title, id', array(), '', 'id DESC LIMIT '.$start_from.', '.$panther_config['o_disp_topics_default']);
?>
<div id="vf" class="blocktable">
	<div class="blockform">
		<h2><span><?php echo $lang_admin_moderate['actions'] ?></span> <span class="pages-label"><?php echo $lang_common['Pages'].' '.paginate($num_pages, $page, $panther_url['admin_moderate'].'?') ?></span></h2>
		<div class="box">
<div class="fakeform">
				<div class="inform">
					<fieldset>
						<legend><?php echo $lang_admin_moderate['title']; ?></legend>
						<div class="infldset">
							<table cellspacing="0">
<tr><th scope="row"><a href="<?php echo get_link($panther_url['admin_moderate_add']); ?>" tabindex="1"><?php echo $lang_admin_moderate['add new']; ?></a></th><td><?php echo $lang_admin_moderate['add new label']; ?></td></tr>
<?php
	foreach ($ps as $action)
	{
?>
								<tr><th scope="row"><a href="<?php echo get_link($panther_url['admin_moderate_edit'], array($action['id'])); ?>" tabindex="9"><?php echo $lang_admin_moderate['edit action']; ?></a> | <a href="<?php echo get_link($panther_url['admin_moderate_delete'], array($action['id'])); ?>" tabindex="10"><?php echo $lang_admin_moderate['delete action 2']; ?></a></th><td><strong><?php echo $action['title']; ?></strong></td></tr>
<?php } ?>
							</table>
						</div>
					</fieldset>
				</div>
			</div>
		</div>
	</div>
	<div class="clearer"></div>
</div>
</div>
</div>
<?php
}
elseif ($action == 'add')
{
	// Display all the categories and forums
	$ps = $db->run('SELECT c.id AS cid, c.cat_name, f.id AS fid, f.forum_name FROM '.$db->prefix.'categories AS c INNER JOIN '.$db->prefix.'forums AS f ON c.id = f.cat_id WHERE f.redirect_url IS NULL ORDER BY c.disp_position, c.id, f.disp_position');
	if ($ps->rowCount())
	{
		$count = 0;
		$cur_index = 4;
		$cur_category = 0;
		$select = null;
		foreach ($ps as $cur_forum)
		{
			if ($cur_forum['cid'] != $cur_category) // A new category since last iteration?
			{
				$select .= '</optgroup>';
				$select .= "\t\t\t\t\t\t".'<optgroup label="'.panther_htmlspecialchars($cur_forum['cat_name']).'">'."\n";
				$cur_category = $cur_forum['cid'];
			}
				$select .= '<option value="'.$cur_forum['fid'].'">'.panther_htmlspecialchars($cur_forum['forum_name']).'</option>'."\n";
		}
			$select .= "\t\t\t\t\t\t".'</optgroup>'."\n\t\t\t\t\t".'</select>'."\n";
	}
?>
	<div class="blockform">
		<h2><span><?php echo $lang_admin_moderate['actions'] ?></span></h2>
		<div class="box">
			<form id="restrictions2" method="post" action="<?php echo get_link($panther_url['admin_moderate_add']); ?>">
				<input type="hidden" name="form_sent" value="1" />
				<div class="inform">
					<fieldset>
						<legend><?php echo $lang_admin_moderate['action header']; ?></legend>
						<div class="infldset">
							<table class="aligntop" cellspacing="0">
								<tr>
									<th scope="row"><?php echo $lang_admin_moderate['title'] ?></th>
									<td>
										<input type="text" name="title" size="45" maxlength="50" tabindex="1" />
										<span><?php echo $lang_admin_moderate['title help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_moderate['add start'] ?></th>
									<td>
										<input type="text" name="add_start" size="30" maxlength="50" tabindex="1" />
										<span><?php echo $lang_admin_moderate['add start help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_moderate['add end'] ?></th>
									<td>
										<input type="text" name="add_end" size="30" maxlength="50" tabindex="1" />
										<span><?php echo $lang_admin_moderate['add end help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_moderate['forum'] ?></th>
									<td>
										<select name="forum">
											<option value="0"><?php echo $lang_admin_moderate['do not move'] ?></option>
											<?php echo $select; ?>
										</select>
										<span><?php echo $lang_admin_moderate['forum help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_moderate['leave redirect'] ?></th>
									<td>
										<select name="redirect">
											<option value="0"><?php echo $lang_admin_moderate['no redirect'] ?></option>
											<option value="1"><?php echo $lang_admin_moderate['do redirect'] ?></option>

										</select>
										<span><?php echo $lang_admin_moderate['redirect help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_moderate['close'] ?></th>
									<td>
										<select name="close">
											<option value="2"><?php echo $lang_admin_moderate['do not alter'] ?></option>
											<option value="1"><?php echo $lang_admin_moderate['close topic'] ?></option>
											<option value="0"><?php echo $lang_admin_moderate['open topic'] ?></option>
										</select>
										<span><?php echo $lang_admin_moderate['close help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_moderate['stick'] ?></th>
									<td>
										<select name="stick">
											<option value="2"><?php echo $lang_admin_moderate['do not alter'] ?></option>
											<option value="1"><?php echo $lang_admin_moderate['stick topic'] ?></option>
											<option value="0"><?php echo $lang_admin_moderate['unstick topic'] ?></option>
										</select>
										<span><?php echo $lang_admin_moderate['stick help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_moderate['increment post count'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="increment" value="1" checked="checked" tabindex="37" />&#160;<strong><?php echo $lang_admin_common['Yes']; ?></strong></label>
										<label class="conl"><input type="radio" name="increment" value="0" tabindex="38" />&#160;<strong><?php echo $lang_admin_common['No']; ?></strong></label>
										<span><?php echo $lang_admin_moderate['increment help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_moderate['email'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="send_email" value="1" checked="checked" tabindex="37" />&#160;<strong><?php echo $lang_admin_common['Yes']; ?></strong></label>
										<label class="conl"><input type="radio" name="send_email" value="0" tabindex="38" />&#160;<strong><?php echo $lang_admin_common['No']; ?></strong></label>
										<span><?php echo $lang_admin_moderate['email help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_moderate['add reply'] ?></th>
									<td>
										<select name="reply">
											<option value="1"><?php echo $lang_admin_moderate['add reply post'] ?></option>
											<option value="0"><?php echo $lang_admin_moderate['no reply post'] ?></option>
										</select>
										<span><?php echo $lang_admin_moderate['add reply help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_moderate['message'] ?></th>
									<td>
										<textarea rows="20" cols="80" name="message"></textarea>
										<span><?php echo $lang_admin_moderate['message help'] ?></span>
									</td>
								</tr>

							</table>
						</div>
					</fieldset>
				</div>
				<p class="submitend"><input type="submit" name="submit" value="<?php echo $lang_common['Submit']; ?>" tabindex="43" /></p>
			</form>
		</div>
	</div>
	<div class="clearer"></div>
</div>
</div>
<?php 
}
elseif($action == 'edit' && $id > '0')
{
	$data = array(
		':id'	=>	$id,
	);

	$ps = $db->select('multi_moderation', 'close, stick, move, leave_redirect, add_reply, reply_message, title, add_start, add_end, send_email, increment_posts', $data, 'id=:id');
	$cur_action = $ps->fetch();

	$ps = $db->run('SELECT c.id AS cid, c.cat_name, f.id AS fid, f.forum_name FROM '.$db->prefix.'categories AS c INNER JOIN '.$db->prefix.'forums AS f ON c.id = f.cat_id WHERE f.redirect_url IS NULL ORDER BY c.disp_position, c.id, f.disp_position');
	if ($ps->rowCount())
	{
		$count = 0;
		$cur_index = 4;
		$cur_category = 0;
		$select = '';
		foreach ($ps as $cur_forum)
		{
			if ($cur_forum['cid'] != $cur_category) // A new category since last iteration?
			{
				$select .= '</optgroup>';
				$select .= "\t\t\t\t\t\t".'<optgroup label="'.panther_htmlspecialchars($cur_forum['cat_name']).'">'."\n";
				$cur_category = $cur_forum['cid'];
			}
				$select .= '<option value="'.$cur_forum['fid'].'"'.(($cur_forum['fid'] == $cur_action['move']) ? ' selected="selected"' : null).'>'.panther_htmlspecialchars($cur_forum['forum_name']).'</option>'."\n";
		}
			$select .= "\t\t\t\t\t\t".'</optgroup>'."\n\t\t\t\t\t".'</select>'."\n";
	}
	?>
	<div class="blockform">
		<h2><span><?php echo $lang_admin_moderate['actions'] ?></span></h2>
		<div class="box">
			<form id="restrictions2" method="post" action="<?php echo get_link($panther_url['admin_moderate_edit'], array($id)); ?>">
				<input type="hidden" name="form_sent" value="1" />
				<div class="inform">
					<fieldset>
						<legend><?php echo $lang_admin_moderate['action header']; ?></legend>
						<div class="infldset">
							<table class="aligntop" cellspacing="0">
								<tr>
									<th scope="row"><?php echo $lang_admin_moderate['title'] ?></th>
									<td>
										<input type="text" value="<?php echo panther_htmlspecialchars($cur_action['title']); ?>" name="title" size="45" maxlength="50" tabindex="1" />
										<span><?php echo $lang_admin_moderate['title help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_moderate['add start'] ?></th>
									<td>
										<input type="text" value="<?php echo $cur_action['add_start']; ?>" name="add_start" size="30" maxlength="50" tabindex="1" />
										<span><?php echo $lang_admin_moderate['add start help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_moderate['add end'] ?></th>
									<td>
										<input type="text" value="<?php echo $cur_action['add_end']; ?>" name="add_end" size="30" maxlength="50" tabindex="1" />
										<span><?php echo $lang_admin_moderate['add end help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_moderate['forum'] ?></th>
									<td>
										<select name="forum">
											<option value="0"><?php echo $lang_admin_moderate['do not move'] ?></option>
											<?php echo $select; ?>
										</select>
										<span><?php echo $lang_admin_moderate['forum help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_moderate['leave redirect'] ?></th>
									<td>
										<select name="redirect">
											<option value="0"<?php if ($cur_action['leave_redirect'] == '0') echo ' selected="selected"'; ?>><?php echo $lang_admin_moderate['no redirect'] ?></option>
											<option value="1"<?php if ($cur_action['leave_redirect'] == '1') echo ' selected="selected"'; ?>><?php echo $lang_admin_moderate['do redirect'] ?></option>

										</select>
										<span><?php echo $lang_admin_moderate['redirect help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_moderate['close'] ?></th>
									<td>
										<select name="close">
											<option value="2"<?php if ($cur_action['close'] == '2') echo ' selected="selected"'; ?>><?php echo $lang_admin_moderate['do not alter'] ?></option>
											<option value="1"<?php if ($cur_action['close'] == '1') echo ' selected="selected"'; ?>><?php echo $lang_admin_moderate['close topic'] ?></option>
											<option value="0"<?php if ($cur_action['close'] == '0') echo ' selected="selected"'; ?>><?php echo $lang_admin_moderate['open topic'] ?></option>
										</select>
										<span><?php echo $lang_admin_moderate['close help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_moderate['stick'] ?></th>
									<td>
										<select name="stick">
											<option value="2"<?php if ($cur_action['stick'] == '2') echo ' selected="selected"'; ?>><?php echo $lang_admin_moderate['do not alter'] ?></option>
											<option value="1"<?php if ($cur_action['stick'] == '1') echo ' selected="selected"'; ?>><?php echo $lang_admin_moderate['stick topic'] ?></option>
											<option value="0"<?php if ($cur_action['stick'] == '0') echo ' selected="selected"'; ?>><?php echo $lang_admin_moderate['unstick topic'] ?></option>
										</select>
										<span><?php echo $lang_admin_moderate['stick help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_moderate['increment post count'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="increment" value="1"<?php if ($cur_action['increment_posts'] == '1') echo ' checked="checked"'; ?> tabindex="37" />&#160;<strong><?php echo $lang_admin_common['Yes']; ?></strong></label>
										<label class="conl"><input type="radio" name="increment" value="0"<?php if ($cur_action['increment_posts'] == '0') echo ' checked="checked"'; ?> tabindex="38" />&#160;<strong><?php echo $lang_admin_common['No']; ?></strong></label>
										<span><?php echo $lang_admin_moderate['increment help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_moderate['email'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="send_email" value="1"<?php if ($cur_action['send_email'] == '1') echo ' checked="checked"'; ?> tabindex="37" />&#160;<strong><?php echo $lang_admin_common['Yes']; ?></strong></label>
										<label class="conl"><input type="radio" name="send_email" value="0"<?php if ($cur_action['send_email'] == '0') echo ' checked="checked"'; ?> tabindex="38" />&#160;<strong><?php echo $lang_admin_common['No']; ?></strong></label>
										<span><?php echo $lang_admin_moderate['email help'] ?></span>
									</td>
								</tr>								
								<tr>
									<th scope="row"><?php echo $lang_admin_moderate['add reply'] ?></th>
									<td>
										<select name="reply">
											<option value="1"<?php if ($cur_action['add_reply'] == '1') echo ' selected="selected"'; ?>><?php echo $lang_admin_moderate['add reply post'] ?></option>
											<option value="0"<?php if ($cur_action['add_reply'] == '0') echo ' selected="selected"'; ?>><?php echo $lang_admin_moderate['no reply post'] ?></option>
										</select>
										<span><?php echo $lang_admin_moderate['add reply help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_moderate['message'] ?></th>
									<td>
										<textarea rows="20" cols="80" name="message"><?php echo $cur_action['reply_message']; ?></textarea>
										<span><?php echo $lang_admin_moderate['message help'] ?></span>
									</td>
								</tr>

							</table>
						</div>
					</fieldset>
				</div>
				<p class="submitend"><input type="submit" name="submit" value="<?php echo $lang_common['Submit']; ?>" tabindex="43" /></p>
			</form>
		</div>
	</div>
	<div class="clearer"></div>
</div>
</div>
<?php
}
elseif ($action == 'delete' && $id > '0')
{
?>
	<div class="blockform">
		<h2><span><?php echo $lang_admin_moderate['actions'] ?></span></h2>
		<div class="box">
			<form id="restrictions2" method="post" action="<?php echo get_link($panther_url['admin_moderate_delete'], array($id)); ?>">
				<input type="hidden" name="form_sent" value="1" />
				<div class="inform">
						<div class="infldset">
							<div class="forminfo">
								<p><strong><?php echo $lang_admin_moderate['delete action']; ?></strong></p>
							</div>		
						</div>
				</div>
				<p class="buttons"><input type="submit" name="delete" value="<?php echo $lang_admin_common['Delete']; ?>" /> <a href="javascript:history.go(-1)"><?php echo $lang_common['Go back']; ?></a></p>
			</form>
		</div>
	</div>
	<div class="clearer"></div>
</div>
</div>
<?php
}
require PANTHER_ROOT.'footer.php';