<?php

// Language definitions used in admin_addons.php
$lang_admin_addons = array(

'No addons'	=>	'You must select at least one addon to remove.',
'Addon removed redirect'	=>	'Addon removed. Redirecting …',

'No file'			=>	'You did not select a file for upload.',
'Bad type'			=>	'The file you tried to upload is not of an allowed type. Allowed types are php.',
'Move failed'			=>	'The server was unable to save the uploaded file.',
'Unknown failure'		=>	'An unknown error occurred. Please try again.',
'Too large ini'			=>	'The selected file was too large to upload. The server didn\'t allow the upload.',
'Partial upload'		=>	'The selected file was only partially uploaded. Please try again.',
'No tmp directory'		=>	'PHP was unable to save the uploaded file to a temporary location.',
'Successful Upload'		=>	'Addon uploaded. Redirecting …',
'Current Addons'		=>	'Current Addons',
'List Addons'			=>	'Addons list',
'Addon filename'		=>	'Addon Name',
'Delete'			=>	'Delete',
'List Addons'			=>	'Addons list',
'List Addons'			=>	'Addons list',
'Add Addon'			=>	'Upload Addon',
'Addon upload warning'		=>	'Uploading addons poses an extreme security risk to your forum. The code present in addons will be executed on the server like a standard file. Only upload addons you know are completely secure.',
'Warning'			=>	'Warning:',
'Upload'			=>	'Upload',
'Delete selected'		=>	'Delete selected addons',
);
