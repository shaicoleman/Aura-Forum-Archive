<?php
/**
 * Copyright (C) 2015 Panther (http://panther.strongholdnation.co.uk/)
 * based on code by Rickard Andersson copyright (C) 2002-2008 PunBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

// Tell header.php to use the admin template
define('PANTHER_ADMIN_CONSOLE', 1);

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/');
	require PANTHER_ROOT.'include/common.php';
}
require PANTHER_ROOT.'include/common_admin.php';

if (!$panther_user['is_admin'])
	message($lang_common['No permission'], false, '403 Forbidden');

if ($panther_user['id'] != '2')
{
	if(!is_null($admins[$panther_user['id']]['admin_options']))
	{
		if ($admins[$panther_user['id']]['admin_options'] == '0')
			message($lang_common['No permission'], false, '403 Forbidden');
	}
}

check_authentication();

// Load the admin_options.php language file
require PANTHER_ROOT.'lang/'.$admin_language.'/admin_options.php';
$max_file_size = str_replace('M', '', @ini_get('upload_max_filesize')) * pow(1024,2);

if (isset($_POST['form_sent']))
{
	confirm_referrer('admin_options.php', $lang_admin_options['Bad HTTP Referer message']);

	$form = array(
		'board_title'			=> panther_trim($_POST['form']['board_title']),
		'board_desc'			=> panther_trim($_POST['form']['board_desc']),
		'base_url'				=> panther_trim($_POST['form']['base_url']),
		'default_timezone'		=> floatval($_POST['form']['default_timezone']),
		'default_dst'			=> $_POST['form']['default_dst'] != '1' ? '0' : '1',
		'default_lang'			=> panther_trim($_POST['form']['default_lang']),
		'default_style'			=> panther_trim($_POST['form']['default_style']),
		'time_format'			=> panther_trim($_POST['form']['time_format']),
		'date_format'			=> panther_trim($_POST['form']['date_format']),
		'timeout_visit'			=> (intval($_POST['form']['timeout_visit']) > 0) ? intval($_POST['form']['timeout_visit']) : 1,
		'timeout_online'		=> (intval($_POST['form']['timeout_online']) > 0) ? intval($_POST['form']['timeout_online']) : 1,
		'redirect_delay'		=> (intval($_POST['form']['redirect_delay']) >= 0) ? intval($_POST['form']['redirect_delay']) : 0,
		'user_tags_max'			=> (intval($_POST['form']['user_tags_max']) > 0) ? intval($_POST['form']['user_tags_max']) : 5,
		'cookie_secure'			=> $_POST['form']['cookie_secure'] != '1' ? '0' : '1',
		'force_ssl'				=> $_POST['form']['force_ssl'] != '1' ? '0' : '1',
		'cookie_name'			=> panther_trim($_POST['form']['cookie_name']),
		'cookie_seed'			=> panther_trim($_POST['form']['cookie_seed']),
		'cookie_domain'			=> panther_trim($_POST['form']['cookie_domain']),
		'cookie_path'			=> panther_trim($_POST['form']['cookie_path']),
		'debug_mode'			=> $_POST['form']['debug_mode'] != '1' ? '0' : '1',
		'archiving'				=> $_POST['form']['archive'] != '1' ? '0' : '1',
		'download_updates'		=> $_POST['form']['download_updates'] != '1' ? '0' : '1',
		'show_queries'			=> $_POST['form']['show_queries'] != '1' ? '0' : '1',
		'login_queue'			=> $_POST['form']['login_queue'] != '1' ? '0' : '1',
		'queue_size'			=> (intval($_POST['form']['queue_size']) > 5) ? intval($_POST['form']['queue_size']) : 30,
		'max_attempts'			=> (intval($_POST['form']['max_attempts']) > 1) ? intval($_POST['form']['max_attempts']) : 5,
		'show_version'			=> $_POST['form']['show_version'] != '1' ? '0' : '1',
		'show_user_info'		=> $_POST['form']['show_user_info'] != '1' ? '0' : '1',
		'show_post_count'		=> $_POST['form']['show_post_count'] != '1' ? '0' : '1',
		'smilies'				=> $_POST['form']['smilies'] != '1' ? '0' : '1',
		'smilies_width'			=> intval($_POST['form']['smilies_width']),
		'smilies_height'		=> intval($_POST['form']['smilies_height']),
		'smilies_size'			=> intval($_POST['form']['smilies_size']),
		'private_messaging'		=> intval($_POST['form']['private_messaging']),
		'smilies_sig'			=> $_POST['form']['smilies_sig'] != '1' ? '0' : '1',
		'make_links'			=> $_POST['form']['make_links'] != '1' ? '0' : '1',
		'topic_review'			=> (intval($_POST['form']['topic_review']) >= 0) ? intval($_POST['form']['topic_review']) : 0,
		'disp_topics_default'	=> intval($_POST['form']['disp_topics_default']),
		'disp_posts_default'	=> intval($_POST['form']['disp_posts_default']),
		'indent_num_spaces'		=> (intval($_POST['form']['indent_num_spaces']) >= 0) ? intval($_POST['form']['indent_num_spaces']) : 0,
		'quote_depth'			=> (intval($_POST['form']['quote_depth']) > 0) ? intval($_POST['form']['quote_depth']) : 1,
		'quickpost'				=> $_POST['form']['quickpost'] != '1' ? '0' : '1',
		'attachments'			=> $_POST['form']['attachments'] != '1' ? '0' : '1',
		'create_orphans'		=> $_POST['form']['create_orphans'] != '1' ? '0' : '1',
		'max_upload_size'		=> intval($_POST['form']['max_upload_size']) ? intval($_POST['form']['max_upload_size']) : 10485760,
		'attachment_images'		=> panther_trim($_POST['form']['attachment_images']),
		'attachment_extensions'	=> panther_trim($_POST['form']['attachment_extensions']),
		'sfs_api'				=> panther_trim($_POST['form']['sfs_api']),
		'tinypng_api'			=> panther_trim($_POST['form']['tinypng_api']),
		'cloudflare_api'		=> panther_trim($_POST['form']['cloudflare_api']),
		'http_authentication'	=> $_POST['form']['http_authentication'] != '1' ? '0' : '1',
		'popular_topics'		=> (intval($_POST['form']['popular_topics']) > 0) ? intval($_POST['form']['popular_topics']) : 25,
		'max_pm_receivers'		=> (intval($_POST['form']['max_pm_receivers']) > 0) ? intval($_POST['form']['max_pm_receivers']) : 15,
		'url_type'				=> panther_trim($_POST['form']['url_type']),
		'always_deny'			=> panther_trim($_POST['form']['always_deny']),
		'users_online'			=> $_POST['form']['users_online'] != '1' ? '0' : '1',
		'delete_full'			=> $_POST['form']['delete_full'] != '1' ? '0' : '1',
		'attachments_dir'		=> panther_trim($_POST['form']['attachments_dir']),
		'warnings'				=> $_POST['form']['warnings'] != '1' ? '0' : '1',
		'custom_warnings'		=> $_POST['form']['custom_warnings'] != '1' ? '0' : '1',
		'warning_status'		=> (in_array($_POST['form']['warning_status'], array(0, 1, 2))) ? intval($_POST['form']['warning_status']) : 1,
		'censoring'				=> $_POST['form']['censoring'] != '1' ? '0' : '1',
		'signatures'			=> $_POST['form']['signatures'] != '1' ? '0' : '1',
		'polls'					=> $_POST['form']['polls'] != '1' ? '0' : '1',
		'ranks'					=> $_POST['form']['ranks'] != '1' ? '0' : '1',
		'reputation'			=> $_POST['form']['reputation'] != '1' ? '0' : '1',
		'rep_abuse'				=> (intval($_POST['form']['rep_abuse']) > 0) ? intval($_POST['form']['rep_abuse']) : 5,
		'max_poll_fields'		=> (intval($_POST['form']['max_poll_fields']) > 0) ? intval($_POST['form']['max_poll_fields']) : 20,
		'show_dot'				=> $_POST['form']['show_dot'] != '1' ? '0' : '1',
		'rep_type'				=> (in_array($_POST['form']['rep_type'], array(1, 2, 3))) ? intval($_POST['form']['rep_type']) : 1,
		'topic_views'			=> $_POST['form']['topic_views'] != '1' ? '0' : '1',
		'ban_email'				=> $_POST['form']['ban_email'] != '1' ? '0' : '1',
		'quickjump'				=> $_POST['form']['quickjump'] != '1' ? '0' : '1',
		'gzip'					=> $_POST['form']['gzip'] != '1' ? '0' : '1',
		'search_all_forums'		=> $_POST['form']['search_all_forums'] != '1' ? '0' : '1',
		'additional_navlinks'	=> panther_trim($_POST['form']['additional_navlinks']),
		'feed_type'				=> intval($_POST['form']['feed_type']),
		'feed_ttl'				=> intval($_POST['form']['feed_ttl']),
		'report_method'			=> intval($_POST['form']['report_method']),
		'mailing_list'			=> panther_trim($_POST['form']['mailing_list']),
		'avatars'				=> $_POST['form']['avatars'] != '1' ? '0' : '1',
		'avatar_upload'			=> $_POST['form']['avatar_upload'] != '1' ? '0' : '1',
		'avatars_dir'			=> panther_trim($_POST['form']['avatars_dir']),
		'avatars_path'			=> panther_trim($_POST['form']['avatars_path']),
		'image_dir'				=> panther_trim($_POST['form']['image_dir']),
		'image_path'			=> panther_trim($_POST['form']['image_path']),
		'js_dir'				=> panther_trim($_POST['form']['js_dir']),
		'smilies_dir'			=> panther_trim($_POST['form']['smilies_dir']),
		'smilies_path'			=> panther_trim($_POST['form']['smilies_path']),
		'image_group_width'		=> (intval($_POST['form']['image_group_width']) > 0) ? intval($_POST['form']['image_group_width']) : 1,
		'image_group_height'	=> (intval($_POST['form']['image_group_height']) > 0) ? intval($_POST['form']['image_group_height']) : 1,
		'image_group_size'		=> (intval($_POST['form']['image_group_size']) > 0) ? intval($_POST['form']['image_group_size']) : 1,
		'image_group_dir'		=> panther_trim($_POST['form']['image_group_dir']),
		'image_group_path'		=> panther_trim($_POST['form']['image_group_path']),
		'avatars_width'			=> (intval($_POST['form']['avatars_width']) > 0) ? intval($_POST['form']['avatars_width']) : 1,
		'avatars_height'		=> (intval($_POST['form']['avatars_height']) > 0) ? intval($_POST['form']['avatars_height']) : 1,
		'avatars_size'			=> (intval($_POST['form']['avatars_size']) > 0) ? intval($_POST['form']['avatars_size']) : 1,
		'attachment_icon_dir'	=> panther_trim($_POST['form']['attachment_icon_dir']),
		'attachment_icon_path'	=> panther_trim($_POST['form']['attachment_icon_path']),
		'attachment_icons'		=> $_POST['form']['attachment_icons'] != '1' ? '0' : '1',
		'email_name'			=> panther_trim($_POST['form']['email_name']),
		'admin_email'			=> strtolower(panther_trim($_POST['form']['admin_email'])),
		'webmaster_email'		=> strtolower(panther_trim($_POST['form']['webmaster_email'])),
		'forum_subscriptions'	=> $_POST['form']['forum_subscriptions'] != '1' ? '0' : '1',
		'topic_subscriptions'	=> $_POST['form']['topic_subscriptions'] != '1' ? '0' : '1',
		'smtp_host'				=> panther_trim($_POST['form']['smtp_host']),
		'smtp_user'				=> panther_trim($_POST['form']['smtp_user']),
		'smtp_ssl'				=> $_POST['form']['smtp_ssl'] != '1' ? '0' : '1',
		'regs_allow'			=> $_POST['form']['regs_allow'] != '1' ? '0' : '1',
		'regs_verify'			=> $_POST['form']['regs_verify'] != '1' ? '0' : '1',
		'regs_report'			=> $_POST['form']['regs_report'] != '1' ? '0' : '1',
		'rules'					=> $_POST['form']['rules'] != '1' ? '0' : '1',
		'rules_message'			=> panther_trim($_POST['form']['rules_message']),
		'default_email_setting'	=> intval($_POST['form']['default_email_setting']),
		'announcement'			=> $_POST['form']['announcement'] != '1' ? '0' : '1',
		'announcement_message'	=> panther_trim($_POST['form']['announcement_message']),
		'maintenance'			=> $_POST['form']['maintenance'] != '1' ? '0' : '1',
		'maintenance_message'	=> panther_trim($_POST['form']['maintenance_message']),
	);

	if ($form['board_title'] == '')
		message($lang_admin_options['Must enter title message']);

	// Make sure base_url doesn't end with a slash
	if (substr($form['base_url'], -1) == '/')
		$form['base_url'] = substr($form['base_url'], 0, -1);
	
	$form['email_name'] = panther_trim(preg_replace('/[^a-zA-Z0-9 ]/', '', $form['email_name']));
	if ($form['email_name'] == '')
		message($lang_admin_options['Email name problem']);
	
	if ($form['image_dir'] != '')
	{
		// Make sure this ends with a trailing slash if it's set
		if (substr($form['image_dir'], -1) != '/')
			$form['image_dir'] .= '/';
	}
	else
		$form['image_dir'] = $form['base_url'].'/img/';
	
	if ($form['js_dir'] != '')
	{
		if (substr($form['js_dir'], -1) != '/')
			$form['js_dir'] .= '/';
	}
	else
		$form['js_dir'] = $form['base_url'].'/js/';
	
	if (isset($_FILES['favicon']))
	{
		$favicon = $_FILES['favicon'];
		switch ($favicon['error'])
		{
			case 1:	// UPLOAD_ERR_INI_SIZE
			case 2:	// UPLOAD_ERR_FORM_SIZE
				message($lang_admin_options['Too large ini']);
				break;

			case 3:	// UPLOAD_ERR_PARTIAL
				message($lang_admin_options['Partial upload']);
				break;

			case 4:	// UPLOAD_ERR_NO_FILE
				break;
			case 6:	// UPLOAD_ERR_NO_TMP_DIR
				message($lang_admin_options['No tmp directory']);
				break;

			default:
				break;
		}
		
		if (is_uploaded_file($favicon['tmp_name']))
		{
			$allowed_types = array('image/x-icon', 'image/ico', 'image/png', 'image/jpg', 'image/jpeg', 'image/pjpeg', 'image/gif');
			if (!in_array($favicon['type'], $allowed_types))
				message($lang_admin_options['Bad type']);

			if (!@move_uploaded_file($favicon['tmp_name'], $panther_config['o_image_path'].'favicon.ico'))
				message($lang_admin_options['Move failed'].' <a href="mailto:'.panther_htmlspecialchars($panther_config['o_admin_email']).'">'.panther_htmlspecialchars($panther_config['o_admin_email']).'</a>.');

			$form['favicon'] = $favicon['name'];
		}
	}

	if (isset($_FILES['avatar']))
	{
		$avatar = $_FILES['avatar'];
		switch ($avatar['error'])
		{
			case 1:	// UPLOAD_ERR_INI_SIZE
			case 2:	// UPLOAD_ERR_FORM_SIZE
				message($lang_admin_options['Too large ini']);
				break;

			case 3:	// UPLOAD_ERR_PARTIAL
				message($lang_admin_options['Partial upload']);
				break;

			case 4:	// UPLOAD_ERR_NO_FILE
				break;
			case 6:	// UPLOAD_ERR_NO_TMP_DIR
				message($lang_admin_options['No tmp directory']);
				break;

			default:
				break;
		}

		if (is_uploaded_file($avatar['tmp_name']))
		{
			$allowed_types = array('image/gif', 'image/jpeg', 'image/pjpeg', 'image/png', 'image/x-png');
			if (!in_array($avatar['type'], $allowed_types))
				message($lang_admin_options['Bad type']);
			
			if ($avatar['size'] > $panther_config['o_avatars_size'])
				message(sprintf($lang_admin_options['Too large'], forum_number_format($panther_config['o_avatars_size'])));

			// Move the file to the avatar directory. We do this before checking the width/height to circumvent open_basedir restrictions
			if (!@move_uploaded_file($avatar['tmp_name'], $panther_config['o_avatars_path'].'/1.tmp'))
				message('1'.$lang_admin_options['Move failed'].' <a href="mailto:'.panther_htmlspecialchars($panther_config['o_admin_email']).'">'.panther_htmlspecialchars($panther_config['o_admin_email']).'</a>.');

			list($width, $height, $type,) = @getimagesize($panther_config['o_avatars_path'].'/1.tmp');

			// Determine type
			if ($type == IMAGETYPE_GIF)
				$extension = 'gif';
			else if ($type == IMAGETYPE_JPEG)
				$extension = 'jpg';
			else if ($type == IMAGETYPE_PNG)
				$extension = 'png';
			else
			{
				// Invalid type
				@unlink($panther_config['o_avatars_path'].'/1.tmp');
				message($lang_profile['Bad type']);
			}

			// Now check the width/height
			if (empty($width) || empty($height) || $width > $panther_config['o_avatars_width'] || $height > $panther_config['o_avatars_height'])
			{
				@unlink($panther_config['o_avatars_path'].'/1.tmp');
				message(sprintf($lang_admin_options['Too wide or high'], $panther_config['o_avatars_width'], $panther_config['o_avatars_height']));
			}

			// Delete the old default avatar
			@unlink($panther_config['o_avatars_path'].'/1.'.$panther_config['o_avatar']);
			@rename($panther_config['o_avatars_path'].'/1.tmp', $panther_config['o_avatars_path'].'/1.'.$extension);
			compress_image($panther_config['o_avatars_path'].'/1.'.$extension);
			@chmod($panther_config['o_avatars_path'].'/1.'.$extension, 0644);

			$form['avatar'] = $extension;
		}
	}

	// Convert IDN to Punycode if needed
	if (preg_match('/[^\x00-\x7F]/', $form['base_url']))
	{
		if (!function_exists('idn_to_ascii'))
			message($lang_admin_options['Base URL problem']);
		else
			$form['base_url'] = idn_to_ascii($form['base_url']);
	}

	$max_file_size = return_bytes(@ini_get('upload_max_filesize'));
	$max_post_size = return_bytes(@ini_get('post_max_size'));

	$comparison = ($max_file_size > $max_post_size) ? $max_post_size : $max_file_size;
	if ($form['max_upload_size'] > $comparison)
		$form['max_upload_size'] = $comparison;

	$languages = forum_list_langs();
	if (!in_array($form['default_lang'], $languages))
		message($lang_common['Bad request'], false, '404 Not Found');

	$styles = forum_list_styles();
	if (!in_array($form['default_style'], $styles))
		message($lang_common['Bad request'], false, '404 Not Found');

	if ($form['time_format'] == '')
		$form['time_format'] = 'H:i:s';

	if ($form['date_format'] == '')
		$form['date_format'] = 'd-m-Y';

	require PANTHER_ROOT.'include/email.php';

	if (!is_valid_email($form['admin_email']))
		message($lang_admin_options['Invalid e-mail message']);

	if (!is_valid_email($form['webmaster_email']))
		message($lang_admin_options['Invalid webmaster e-mail message']);

	if ($form['mailing_list'] != '')
		$form['mailing_list'] = strtolower(preg_replace('%\s%S', '', $form['mailing_list']));

	// Make sure avatars_path doesn't end with a slash
	if (substr($form['avatars_path'], -1) == '/')
		$form['avatars_path'] = substr($form['avatars_path'], 0, -1);

	// Make sure avatars_dir ends with a slash
	if (substr($form['avatars_dir'], -1) != '/' && $form['avatars_dir'] != '')
		$form['avatars_dir'] .= '/';

	// Make sure smilies_path doesn't end with a slash
	if (substr($form['smilies_path'], -1) == '/')
		$form['smilies_path'] = substr($form['smilies_path'], 0, -1);

	// Make sure smilies_dir ends with a slash
	if (substr($form['smilies_dir'], -1) != '/' && $form['smilies_dir'] != '')
		$form['smilies_dir'] .= '/';
	
	// Make sure image_group_path doesn't end with a slash
	if (substr($form['image_group_path'], -1) == '/')
		$form['image_group_path'] = substr($form['image_group_path'], 0, -1);

	// Make sure image_group_dir ends with a slash
	if (substr($form['image_group_dir'], -1) != '/' && $form['image_group_dir'] != '')
		$form['image_group_dir'] .= '/';
	
	// Make sure image_path doesn't end with a slash
	if (substr($form['image_path'], -1) == '/')
		$form['image_path'] = substr($form['image_path'], 0, -1);

	// Make sure attachment_icon_path doesn't end with a slash
	if (substr($form['attachment_icon_path'], -1) == '/')
		$form['attachment_icon_path'] = substr($form['attachment_icon_path'], 0, -1);

	// Make sure attachment_icon_dir ends with a slash
	if (substr($form['attachment_icon_dir'], -1) != '/' && $form['attachment_icon_dir'] != '')
		$form['attachment_icon_dir'] .= '/';

	if ($form['additional_navlinks'] != '')
		$form['additional_navlinks'] = panther_trim(panther_linebreaks($form['additional_navlinks']));

	// Change or enter a SMTP password
	if (isset($_POST['form']['smtp_change_pass']))
	{
		$smtp_pass1 = isset($_POST['form']['smtp_pass1']) ? panther_trim($_POST['form']['smtp_pass1']) : '';
		$smtp_pass2 = isset($_POST['form']['smtp_pass2']) ? panther_trim($_POST['form']['smtp_pass2']) : '';

		if ($smtp_pass1 == $smtp_pass2)
			$form['smtp_pass'] = $smtp_pass1;
		else
			message($lang_admin_options['SMTP passwords did not match']);
	}

	if ($form['announcement_message'] != '')
		$form['announcement_message'] = panther_linebreaks($form['announcement_message']);
	else
	{
		$form['announcement_message'] = $lang_admin_options['Enter announcement here'];
		$form['announcement'] = '0';
	}

	if ($form['rules_message'] != '')
		$form['rules_message'] = panther_linebreaks($form['rules_message']);
	else
	{
		$form['rules_message'] = $lang_admin_options['Enter rules here'];
		$form['rules'] = '0';
	}

	if ($form['maintenance_message'] != '')
		$form['maintenance_message'] = panther_linebreaks($form['maintenance_message']);
	else
	{
		$form['maintenance_message'] = $lang_admin_options['Default maintenance message'];
		$form['maintenance'] = '0';
	}

	// Make sure the number of displayed topics and posts is between 3 and 75
	if ($form['disp_topics_default'] < 3)
		$form['disp_topics_default'] = 3;
	else if ($form['disp_topics_default'] > 75)
		$form['disp_topics_default'] = 75;

	if ($form['disp_posts_default'] < 3)
		$form['disp_posts_default'] = 3;
	else if ($form['disp_posts_default'] > 75)
		$form['disp_posts_default'] = 75;

	if ($form['feed_type'] < 0 || $form['feed_type'] > 2)
		message($lang_common['Bad request'], false, '404 Not Found');

	if ($form['feed_ttl'] < 0)
		message($lang_common['Bad request'], false, '404 Not Found');

	if ($form['report_method'] < 0 || $form['report_method'] > 2)
		message($lang_common['Bad request'], false, '404 Not Found');

	if ($form['default_email_setting'] < 0 || $form['default_email_setting'] > 2)
		message($lang_common['Bad request'], false, '404 Not Found');

	if ($form['timeout_online'] >= $form['timeout_visit'])
		message($lang_admin_options['Timeout error message']);

	if ($form['archiving'] == 0 && $panther_config['o_archiving'] != $form['archiving'])	// If we've disabled archiving then we need to unarchive every topic
	{
		$update = array(
			'archived'	=>	0,
		);

		$db->update('topics', $update);
	}

	foreach ($form as $key => $input)
	{
		// Only update values that have changed
		if (array_key_exists('o_'.$key, $panther_config) && $panther_config['o_'.$key] != $input)
		{
			if ($input != '' || is_int($input))
				$value = $input;
			else
				$value = null;
			
			$update = array(
				'conf_value'	=>	$value,
			);

			$data = array(
				':conf_name'	=>	'o_'.$key,
			);

			$db->update('config', $update, 'conf_name=:conf_name', $data);
		}
	}

	// Regenerate the config cache
	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PANTHER_ROOT.'include/cache.php';

	generate_config_cache();
	clear_feed_cache();
	
	if ($form['url_type'] != $panther_config['o_url_type'])
	{
		if ($form['url_type'] != 'default')
		{
			if (!file_exists(PANTHER_ROOT.'.htaccess'))
			{
				// If the file doesn't already exist then it must be under a different name
				if (!rename(PANTHER_ROOT.'.htaccess.bak', PANTHER_ROOT.'.htaccess'))
					message($lang_admin_options['Unable to create htaccess']);
			}
		}
		else
			@rename(PANTHER_ROOT.'.htaccess', PANTHER_ROOT.'.htaccess.bak');
		
		//Load new URL pack to avoid 404 error after redirecting
		if (file_exists(PANTHER_ROOT.'include/url/'.$form['url_type'].'.php'))
			require PANTHER_ROOT.'include/url/'.$form['url_type'].'.php';
		else
			require PANTHER_ROOT.'include/url/default.php';
		
		generate_quickjump_cache();
	}

	redirect(get_link($panther_url['admin_options']), $lang_admin_options['Options updated redirect']);
}

$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_admin_common['Admin'], $lang_admin_common['Options']);
define('PANTHER_ACTIVE_PAGE', 'admin');
require PANTHER_ROOT.'header.php';

generate_admin_menu('options');
?>
	<div class="blockform">
		<h2><span><?php echo $lang_admin_options['Options head'] ?></span></h2>
		<div class="box">
			<form method="post" action="<?php echo get_link($panther_url['admin_options']); ?>" enctype="multipart/form-data">
				<p class="submittop"><input type="submit" name="save" value="<?php echo $lang_admin_common['Save changes'] ?>" /></p>
				<div class="inform">
					<input type="hidden" name="form_sent" value="1" />
					<input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>" />
					<fieldset>
						<legend><?php echo $lang_admin_options['Essentials subhead'] ?></legend>
						<div class="infldset">
							<table class="aligntop">
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Board title label'] ?></th>
									<td>
										<input type="text" name="form[board_title]" size="50" maxlength="255" value="<?php echo panther_htmlspecialchars($panther_config['o_board_title']) ?>" />
										<span><?php echo $lang_admin_options['Board title help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Board desc label'] ?></th>
									<td>
										<textarea name="form[board_desc]" cols="60" rows="3"><?php echo panther_htmlspecialchars($panther_config['o_board_desc']) ?></textarea>
										<span><?php echo $lang_admin_options['Board desc help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Favicon label'] ?></th>
									<td>
										<input type="hidden" name="MAX_FILE_SIZE" value="<?php echo $max_file_size; ?>" /><input type="file" name="favicon" size="30" /><br />
										<span><?php echo $lang_admin_options['Favicon help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Default avatar label'] ?></th>
									<td>
										<input type="hidden" name="MAX_FILE_SIZE" value="<?php echo $max_file_size; ?>" /><input type="file" name="avatar" size="30" /><br />
										<span><?php echo $lang_admin_options['Default avatar help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Base URL label'] ?></th>
									<td>
										<input type="text" name="form[base_url]" size="50" maxlength="100" value="<?php echo panther_htmlspecialchars($panther_config['o_base_url']) ?>" />
										<span><?php echo $lang_admin_options['Base URL help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Timezone label'] ?></th>
									<td>
										<select name="form[default_timezone]">
											<option value="-12"<?php if ($panther_config['o_default_timezone'] == -12) echo ' selected="selected"' ?>><?php echo $lang_admin_options['UTC-12:00'] ?></option>
											<option value="-11"<?php if ($panther_config['o_default_timezone'] == -11) echo ' selected="selected"' ?>><?php echo $lang_admin_options['UTC-11:00'] ?></option>
											<option value="-10"<?php if ($panther_config['o_default_timezone'] == -10) echo ' selected="selected"' ?>><?php echo $lang_admin_options['UTC-10:00'] ?></option>
											<option value="-9.5"<?php if ($panther_config['o_default_timezone'] == -9.5) echo ' selected="selected"' ?>><?php echo $lang_admin_options['UTC-09:30'] ?></option>
											<option value="-9"<?php if ($panther_config['o_default_timezone'] == -9) echo ' selected="selected"' ?>><?php echo $lang_admin_options['UTC-09:00'] ?></option>
											<option value="-8.5"<?php if ($panther_config['o_default_timezone'] == -8.5) echo ' selected="selected"' ?>><?php echo $lang_admin_options['UTC-08:30'] ?></option>
											<option value="-8"<?php if ($panther_config['o_default_timezone'] == -8) echo ' selected="selected"' ?>><?php echo $lang_admin_options['UTC-08:00'] ?></option>
											<option value="-7"<?php if ($panther_config['o_default_timezone'] == -7) echo ' selected="selected"' ?>><?php echo $lang_admin_options['UTC-07:00'] ?></option>
											<option value="-6"<?php if ($panther_config['o_default_timezone'] == -6) echo ' selected="selected"' ?>><?php echo $lang_admin_options['UTC-06:00'] ?></option>
											<option value="-5"<?php if ($panther_config['o_default_timezone'] == -5) echo ' selected="selected"' ?>><?php echo $lang_admin_options['UTC-05:00'] ?></option>
											<option value="-4"<?php if ($panther_config['o_default_timezone'] == -4) echo ' selected="selected"' ?>><?php echo $lang_admin_options['UTC-04:00'] ?></option>
											<option value="-3.5"<?php if ($panther_config['o_default_timezone'] == -3.5) echo ' selected="selected"' ?>><?php echo $lang_admin_options['UTC-03:30'] ?></option>
											<option value="-3"<?php if ($panther_config['o_default_timezone'] == -3) echo ' selected="selected"' ?>><?php echo $lang_admin_options['UTC-03:00'] ?></option>
											<option value="-2"<?php if ($panther_config['o_default_timezone'] == -2) echo ' selected="selected"' ?>><?php echo $lang_admin_options['UTC-02:00'] ?></option>
											<option value="-1"<?php if ($panther_config['o_default_timezone'] == -1) echo ' selected="selected"' ?>><?php echo $lang_admin_options['UTC-01:00'] ?></option>
											<option value="0"<?php if ($panther_config['o_default_timezone'] == 0) echo ' selected="selected"' ?>><?php echo $lang_admin_options['UTC'] ?></option>
											<option value="1"<?php if ($panther_config['o_default_timezone'] == 1) echo ' selected="selected"' ?>><?php echo $lang_admin_options['UTC+01:00'] ?></option>
											<option value="2"<?php if ($panther_config['o_default_timezone'] == 2) echo ' selected="selected"' ?>><?php echo $lang_admin_options['UTC+02:00'] ?></option>
											<option value="3"<?php if ($panther_config['o_default_timezone'] == 3) echo ' selected="selected"' ?>><?php echo $lang_admin_options['UTC+03:00'] ?></option>
											<option value="3.5"<?php if ($panther_config['o_default_timezone'] == 3.5) echo ' selected="selected"' ?>><?php echo $lang_admin_options['UTC+03:30'] ?></option>
											<option value="4"<?php if ($panther_config['o_default_timezone'] == 4) echo ' selected="selected"' ?>><?php echo $lang_admin_options['UTC+04:00'] ?></option>
											<option value="4.5"<?php if ($panther_config['o_default_timezone'] == 4.5) echo ' selected="selected"' ?>><?php echo $lang_admin_options['UTC+04:30'] ?></option>
											<option value="5"<?php if ($panther_config['o_default_timezone'] == 5) echo ' selected="selected"' ?>><?php echo $lang_admin_options['UTC+05:00'] ?></option>
											<option value="5.5"<?php if ($panther_config['o_default_timezone'] == 5.5) echo ' selected="selected"' ?>><?php echo $lang_admin_options['UTC+05:30'] ?></option>
											<option value="5.75"<?php if ($panther_config['o_default_timezone'] == 5.75) echo ' selected="selected"' ?>><?php echo $lang_admin_options['UTC+05:45'] ?></option>
											<option value="6"<?php if ($panther_config['o_default_timezone'] == 6) echo ' selected="selected"' ?>><?php echo $lang_admin_options['UTC+06:00'] ?></option>
											<option value="6.5"<?php if ($panther_config['o_default_timezone'] == 6.5) echo ' selected="selected"' ?>><?php echo $lang_admin_options['UTC+06:30'] ?></option>
											<option value="7"<?php if ($panther_config['o_default_timezone'] == 7) echo ' selected="selected"' ?>><?php echo $lang_admin_options['UTC+07:00'] ?></option>
											<option value="8"<?php if ($panther_config['o_default_timezone'] == 8) echo ' selected="selected"' ?>><?php echo $lang_admin_options['UTC+08:00'] ?></option>
											<option value="8.75"<?php if ($panther_config['o_default_timezone'] == 8.75) echo ' selected="selected"' ?>><?php echo $lang_admin_options['UTC+08:45'] ?></option>
											<option value="9"<?php if ($panther_config['o_default_timezone'] == 9) echo ' selected="selected"' ?>><?php echo $lang_admin_options['UTC+09:00'] ?></option>
											<option value="9.5"<?php if ($panther_config['o_default_timezone'] == 9.5) echo ' selected="selected"' ?>><?php echo $lang_admin_options['UTC+09:30'] ?></option>
											<option value="10"<?php if ($panther_config['o_default_timezone'] == 10) echo ' selected="selected"' ?>><?php echo $lang_admin_options['UTC+10:00'] ?></option>
											<option value="10.5"<?php if ($panther_config['o_default_timezone'] == 10.5) echo ' selected="selected"' ?>><?php echo $lang_admin_options['UTC+10:30'] ?></option>
											<option value="11"<?php if ($panther_config['o_default_timezone'] == 11) echo ' selected="selected"' ?>><?php echo $lang_admin_options['UTC+11:00'] ?></option>
											<option value="11.5"<?php if ($panther_config['o_default_timezone'] == 11.5) echo ' selected="selected"' ?>><?php echo $lang_admin_options['UTC+11:30'] ?></option>
											<option value="12"<?php if ($panther_config['o_default_timezone'] == 12) echo ' selected="selected"' ?>><?php echo $lang_admin_options['UTC+12:00'] ?></option>
											<option value="12.75"<?php if ($panther_config['o_default_timezone'] == 12.75) echo ' selected="selected"' ?>><?php echo $lang_admin_options['UTC+12:45'] ?></option>
											<option value="13"<?php if ($panther_config['o_default_timezone'] == 13) echo ' selected="selected"' ?>><?php echo $lang_admin_options['UTC+13:00'] ?></option>
											<option value="14"<?php if ($panther_config['o_default_timezone'] == 14) echo ' selected="selected"' ?>><?php echo $lang_admin_options['UTC+14:00'] ?></option>
										</select>
										<span><?php echo $lang_admin_options['Timezone help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['DST label'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="form[default_dst]" value="1"<?php if ($panther_config['o_default_dst'] == '1') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['Yes'] ?></strong></label>
										<label class="conl"><input type="radio" name="form[default_dst]" value="0"<?php if ($panther_config['o_default_dst'] == '0') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['No'] ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_options['DST help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['URL type label'] ?></th>
									<td>
										<select name="form[url_type]">
											<option value="default"<?php if ($panther_config['o_url_type'] == 'default') echo ' selected="selected"' ?>><?php echo $lang_admin_options['Default'] ?></option>
											<option value="file_based"<?php if ($panther_config['o_url_type'] == 'file_based') echo ' selected="selected"' ?>><?php echo $lang_admin_options['File based'] ?></option>
											<option value="file_based_fancy"<?php if ($panther_config['o_url_type'] == 'file_based_fancy') echo ' selected="selected"' ?>><?php echo $lang_admin_options['File based fancy'] ?></option>
											<option value="folder_based"<?php if ($panther_config['o_url_type'] == 'folder_based') echo ' selected="selected"' ?>><?php echo $lang_admin_options['Folder based'] ?></option>
											<option value="folder_based_fancy"<?php if ($panther_config['o_url_type'] == 'folder_based_fancy') echo ' selected="selected"' ?>><?php echo $lang_admin_options['Folder based fancy'] ?></option>
											</select>
										<span class="clearb"><?php echo $lang_admin_options['URL type help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Language label'] ?></th>
									<td>
										<select name="form[default_lang]">
<?php

		$languages = forum_list_langs();

		foreach ($languages as $temp)
		{
			if ($panther_config['o_default_lang'] == $temp)
				echo "\t\t\t\t\t\t\t\t\t\t\t".'<option value="'.$temp.'" selected="selected">'.$temp.'</option>'."\n";
			else
				echo "\t\t\t\t\t\t\t\t\t\t\t".'<option value="'.$temp.'">'.$temp.'</option>'."\n";
		}

?>
										</select>
										<span><?php echo $lang_admin_options['Language help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Default style label'] ?></th>
									<td>
										<select name="form[default_style]">
<?php

		$styles = forum_list_styles();

		foreach ($styles as $temp)
		{
			if ($panther_config['o_default_style'] == $temp)
				echo "\t\t\t\t\t\t\t\t\t\t\t".'<option value="'.$temp.'" selected="selected">'.str_replace('_', ' ', $temp).'</option>'."\n";
			else
				echo "\t\t\t\t\t\t\t\t\t\t\t".'<option value="'.$temp.'">'.str_replace('_', ' ', $temp).'</option>'."\n";
		}

?>
										</select>
										<span><?php echo $lang_admin_options['Default style help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Ban email label'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="form[ban_email]" value="1"<?php if ($panther_config['o_ban_email'] == '1') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['Yes'] ?></strong></label>
										<label class="conl"><input type="radio" name="form[ban_email]" value="0"<?php if ($panther_config['o_ban_email'] == '0') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['No'] ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_options['Ban email help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Img path label'] ?></th>
									<td>
										<input type="text" name="form[image_path]" size="35" value="<?php echo panther_htmlspecialchars($panther_config['o_image_path']); ?>" />
										<span class="clearb"><?php echo $lang_admin_options['Img path help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Img directory label'] ?></th>
									<td>
										<input type="text" name="form[image_dir]" size="35" value="<?php echo ($panther_config['o_image_dir'] != $panther_config['o_base_url'].'/img/') ? panther_htmlspecialchars($panther_config['o_image_dir']) : ''; ?>" />
										<span class="clearb"><?php echo $lang_admin_options['Img directory help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['JS directory label'] ?></th>
									<td>
										<input type="text" name="form[js_dir]" size="35" value="<?php echo ($panther_config['o_js_dir'] != $panther_config['o_base_url'].'/js/') ? panther_htmlspecialchars($panther_config['o_js_dir']) : ''; ?>" />
										<span class="clearb"><?php echo $lang_admin_options['JS directory help'] ?></span>
									</td>
								</tr>
							</table>
						</div>
					</fieldset>
				</div>
				<div class="inform">
					<fieldset>
						<legend><?php echo $lang_admin_options['Cookie subhead'] ?></legend>
						<div class="infldset">
							<table class="aligntop" cellspacing="0">
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Cookie name label'] ?></th>
									<td>
										<input type="text" name="form[cookie_name]" size="25" maxlength="25" value="<?php echo panther_htmlspecialchars($panther_config['o_cookie_name']) ?>" />
										<span><?php echo $lang_admin_options['Cookie name help']; ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Cookie domain label'] ?></th>
									<td>
										<input type="text" name="form[cookie_domain]" size="25" maxlength="25" value="<?php echo panther_htmlspecialchars($panther_config['o_cookie_domain']) ?>" />
										<span><?php echo $lang_admin_options['Cookie domain help']; ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Cookie seed label'] ?></th>
									<td>
										<input type="text" name="form[cookie_seed]" size="25" maxlength="25" value="<?php echo panther_htmlspecialchars($panther_config['o_cookie_seed']) ?>" />
										<span><?php echo $lang_admin_options['Cookie seed help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Cookie secure label'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="form[cookie_secure]" value="1"<?php if ($panther_config['o_cookie_secure'] == '1') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['Yes'] ?></strong></label>
										<label class="conl"><input type="radio" name="form[cookie_secure]" value="0"<?php if ($panther_config['o_cookie_secure'] == '0') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['No'] ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_options['Cookie secure help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Cookie path label'] ?></th>
									<td>
										<input type="text" name="form[cookie_path]" size="25" maxlength="25" value="<?php echo panther_htmlspecialchars($panther_config['o_cookie_path']) ?>" />
										<span><?php echo $lang_admin_options['Cookie path help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Force ssl label'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="form[force_ssl]" value="1"<?php if ($panther_config['o_force_ssl'] == '1') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['Yes'] ?></strong></label>
										<label class="conl"><input type="radio" name="form[force_ssl]" value="0"<?php if ($panther_config['o_force_ssl'] == '0') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['No'] ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_options['Force ssl help'] ?></span>
									</td>
								</tr>
							</table>
						</div>
					</fieldset>
				</div>
<?php

	$diff = ($panther_user['timezone'] + $panther_user['dst']) * 3600;
	$timestamp = time() + $diff;

?>
				<div class="inform">
					<fieldset>
						<legend><?php echo $lang_admin_options['Timeouts subhead'] ?></legend>
						<div class="infldset">
							<table class="aligntop">
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Time format label'] ?></th>
									<td>
										<input type="text" name="form[time_format]" size="25" maxlength="25" value="<?php echo panther_htmlspecialchars($panther_config['o_time_format']) ?>" />
										<span><?php printf($lang_admin_options['Time format help'], gmdate($panther_config['o_time_format'], $timestamp), '<a href="http://www.php.net/manual/en/function.date.php">'.$lang_admin_options['PHP manual'].'</a>') ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Date format label'] ?></th>
									<td>
										<input type="text" name="form[date_format]" size="25" maxlength="25" value="<?php echo panther_htmlspecialchars($panther_config['o_date_format']) ?>" />
										<span><?php printf($lang_admin_options['Date format help'], gmdate($panther_config['o_date_format'], $timestamp), '<a href="http://www.php.net/manual/en/function.date.php">'.$lang_admin_options['PHP manual'].'</a>') ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Visit timeout label'] ?></th>
									<td>
										<input type="text" name="form[timeout_visit]" size="5" maxlength="5" value="<?php echo $panther_config['o_timeout_visit'] ?>" />
										<span><?php echo $lang_admin_options['Visit timeout help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Online timeout label'] ?></th>
									<td>
										<input type="text" name="form[timeout_online]" size="5" maxlength="5" value="<?php echo $panther_config['o_timeout_online'] ?>" />
										<span><?php echo $lang_admin_options['Online timeout help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Redirect time label'] ?></th>
									<td>
										<input type="text" name="form[redirect_delay]" size="3" maxlength="3" value="<?php echo $panther_config['o_redirect_delay'] ?>" />
										<span><?php echo $lang_admin_options['Redirect time help'] ?></span>
									</td>
								</tr>
							</table>
						</div>
					</fieldset>
				</div>
				<div class="inform">
					<fieldset>
						<legend><?php echo $lang_admin_options['Display subhead'] ?></legend>
						<div class="infldset">
							<table class="aligntop">
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Version number label'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="form[show_version]" value="1"<?php if ($panther_config['o_show_version'] == '1') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['Yes'] ?></strong></label>
										<label class="conl"><input type="radio" name="form[show_version]" value="0"<?php if ($panther_config['o_show_version'] == '0') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['No'] ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_options['Version number help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Info in posts label'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="form[show_user_info]" value="1"<?php if ($panther_config['o_show_user_info'] == '1') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['Yes'] ?></strong></label>
										<label class="conl"><input type="radio" name="form[show_user_info]" value="0"<?php if ($panther_config['o_show_user_info'] == '0') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['No'] ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_options['Info in posts help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Post count label'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="form[show_post_count]" value="1"<?php if ($panther_config['o_show_post_count'] == '1') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['Yes'] ?></strong></label>
										<label class="conl"><input type="radio" name="form[show_post_count]" value="0"<?php if ($panther_config['o_show_post_count'] == '0') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['No'] ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_options['Post count help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Smilies label'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="form[smilies]" value="1"<?php if ($panther_config['o_smilies'] == '1') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['Yes'] ?></strong></label>
										<label class="conl"><input type="radio" name="form[smilies]" value="0"<?php if ($panther_config['o_smilies'] == '0') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['No'] ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_options['Smilies help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Smilies path label'] ?></th>
									<td>
										<input type="text" name="form[smilies_path]" size="35" maxlength="50" value="<?php echo panther_htmlspecialchars($panther_config['o_smilies_path']) ?>" />
										<span class="clearb"><?php echo $lang_admin_options['Smilies path help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Smilies directory label'] ?></th>
									<td>
										<input type="text" name="form[smilies_dir]" size="35" maxlength="50" value="<?php echo panther_htmlspecialchars($panther_config['o_smilies_dir']) ?>" />
										<span class="clearb"><?php echo $lang_admin_options['Smilies directory help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Max width smilies label'] ?></th>
									<td>
										<input type="text" name="form[smilies_width]" size="5" maxlength="5" value="<?php echo $panther_config['o_smilies_width'] ?>" />
										<span><?php echo $lang_admin_options['Max width smilies help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Max height smilies label'] ?></th>
									<td>
										<input type="text" name="form[smilies_height]" size="5" maxlength="5" value="<?php echo $panther_config['o_smilies_height'] ?>" />
										<span><?php echo $lang_admin_options['Max height smilies help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Max size smilies label'] ?></th>
									<td>
										<input type="text" name="form[smilies_size]" size="6" maxlength="6" value="<?php echo $panther_config['o_smilies_size'] ?>" />
										<span><?php echo $lang_admin_options['Max size smilies help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Smilies sigs label'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="form[smilies_sig]" value="1"<?php if ($panther_config['o_smilies_sig'] == '1') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['Yes'] ?></strong></label>
										<label class="conl"><input type="radio" name="form[smilies_sig]" value="0"<?php if ($panther_config['o_smilies_sig'] == '0') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['No'] ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_options['Smilies sigs help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Clickable links label'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="form[make_links]" value="1"<?php if ($panther_config['o_make_links'] == '1') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['Yes'] ?></strong></label>
										<label class="conl"><input type="radio" name="form[make_links]" value="0"<?php if ($panther_config['o_make_links'] == '0') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['No'] ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_options['Clickable links help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Topic review label'] ?></th>
									<td>
										<input type="text" name="form[topic_review]" size="3" maxlength="3" value="<?php echo $panther_config['o_topic_review'] ?>" />
										<span><?php echo $lang_admin_options['Topic review help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Topics per page label'] ?></th>
									<td>
										<input type="text" name="form[disp_topics_default]" size="3" maxlength="2" value="<?php echo $panther_config['o_disp_topics_default'] ?>" />
										<span><?php echo $lang_admin_options['Topics per page help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Posts per page label'] ?></th>
									<td>
										<input type="text" name="form[disp_posts_default]" size="3" maxlength="2" value="<?php echo $panther_config['o_disp_posts_default'] ?>" />
										<span><?php echo $lang_admin_options['Posts per page help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Indent label'] ?></th>
									<td>
										<input type="text" name="form[indent_num_spaces]" size="3" maxlength="3" value="<?php echo $panther_config['o_indent_num_spaces'] ?>" />
										<span><?php echo $lang_admin_options['Indent help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Quote depth label'] ?></th>
									<td>
										<input type="text" name="form[quote_depth]" size="3" maxlength="3" value="<?php echo $panther_config['o_quote_depth'] ?>" />
										<span><?php echo $lang_admin_options['Quote depth help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['User tags label'] ?></th>
									<td>
										<input type="text" name="form[user_tags_max]" size="5" maxlength="2" value="<?php echo $panther_config['o_user_tags_max'] ?>" />
										<span><?php echo $lang_admin_options['User tags help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Image group path label'] ?></th>
									<td>
										<input type="text" name="form[image_group_path]" size="35" maxlength="50" value="<?php echo panther_htmlspecialchars($panther_config['o_image_group_path']) ?>" />
										<span class="clearb"><?php echo $lang_admin_options['Image group path help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Image group dir label'] ?></th>
									<td>
										<input type="text" name="form[image_group_dir]" size="35" maxlength="50" value="<?php echo panther_htmlspecialchars($panther_config['o_image_group_dir']) ?>" />
										<span class="clearb"><?php echo $lang_admin_options['Image group dir help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Max width label'] ?></th>
									<td>
										<input type="text" name="form[image_group_width]" size="5" maxlength="5" value="<?php echo $panther_config['o_image_group_width'] ?>" />
										<span><?php echo $lang_admin_options['Max width group help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Max height label'] ?></th>
									<td>
										<input type="text" name="form[image_group_height]" size="5" maxlength="5" value="<?php echo $panther_config['o_image_group_height'] ?>" />
										<span><?php echo $lang_admin_options['Max height group help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Max size label'] ?></th>
									<td>
										<input type="text" name="form[image_group_size]" size="6" maxlength="6" value="<?php echo $panther_config['o_image_group_size'] ?>" />
										<span><?php echo $lang_admin_options['Max size group help'] ?></span>
									</td>
								</tr>
							</table>
						</div>
					</fieldset>
				</div>
				<div class="inform">
					<fieldset>
						<legend><?php echo $lang_admin_options['Features subhead'] ?></legend>
						<div class="infldset">
							<table class="aligntop">
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Quick post label'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="form[quickpost]" value="1"<?php if ($panther_config['o_quickpost'] == '1') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['Yes'] ?></strong></label>
										<label class="conl"><input type="radio" name="form[quickpost]" value="0"<?php if ($panther_config['o_quickpost'] == '0') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['No'] ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_options['Quick post help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Users online label'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="form[users_online]" value="1"<?php if ($panther_config['o_users_online'] == '1') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['Yes'] ?></strong></label>
										<label class="conl"><input type="radio" name="form[users_online]" value="0"<?php if ($panther_config['o_users_online'] == '0') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['No'] ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_options['Users online help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Popular topic label'] ?></th>
									<td>
										<input type="text" name="form[popular_topics]" size="3" maxlength="3" value="<?php echo $panther_config['o_popular_topics'] ?>" />
										<span><?php echo $lang_admin_options['Popular topic help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['http authentication label'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="form[http_authentication]" value="1"<?php if ($panther_config['o_http_authentication'] == '1') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['Yes'] ?></strong></label>
										<label class="conl"><input type="radio" name="form[http_authentication]" value="0"<?php if ($panther_config['o_http_authentication'] == '0') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['No'] ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_options['http authentication help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><a name="censoring"></a><?php echo $lang_admin_options['Censor words label'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="form[censoring]" value="1"<?php if ($panther_config['o_censoring'] == '1') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['Yes'] ?></strong></label>
										<label class="conl"><input type="radio" name="form[censoring]" value="0"<?php if ($panther_config['o_censoring'] == '0') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['No'] ?></strong></label>
										<span class="clearb"><?php printf($lang_admin_options['Censor words help'], '<a href="'.get_link($panther_url['admin_censoring']).'">'.$lang_admin_common['Censoring'].'</a>') ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><a name="archiving"></a><?php echo $lang_admin_options['Archive label'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="form[archive]" value="1"<?php if ($panther_config['o_archiving'] == '1') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['Yes'] ?></strong></label>
										<label class="conl"><input type="radio" name="form[archive]" value="0"<?php if ($panther_config['o_archiving'] == '0') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['No'] ?></strong></label>
										<span class="clearb"><?php printf($lang_admin_options['Archive help'], get_link($panther_url['admin_archive'])) ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Warning label'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="form[warnings]" value="1"<?php if ($panther_config['o_warnings'] == '1') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['Yes'] ?></strong></label>
										<label class="conl"><input type="radio" name="form[warnings]" value="0"<?php if ($panther_config['o_warnings'] == '0') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['No'] ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_options['Warning help']; ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Warning custom label'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="form[custom_warnings]" value="1"<?php if ($panther_config['o_custom_warnings'] == '1') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['Yes'] ?></strong></label>
										<label class="conl"><input type="radio" name="form[custom_warnings]" value="0"<?php if ($panther_config['o_custom_warnings'] == '0') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['No'] ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_options['Warning help']; ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Warning status label'] ?></th>
									<td>
										<select name="form[warning_status]">
											<option value="1"<?php if ($panther_config['o_warning_status'] == '0') echo ' selected="selected"' ?>><?php echo $lang_admin_options['All users'] ?></option>
											<option value="2"<?php if ($panther_config['o_warning_status'] == '1') echo ' selected="selected"' ?>><?php echo $lang_admin_options['Moderators and warned'] ?></option>
											<option value="3"<?php if ($panther_config['o_warning_status'] == '2') echo ' selected="selected"' ?>><?php echo $lang_admin_options['Moderators only'] ?></option>
										</select>
										<span class="clearb"><?php echo $lang_admin_options['Warning status help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['delete full label'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="form[delete_full]" value="1"<?php if ($panther_config['o_delete_full'] == '1') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['Yes'] ?></strong></label>
										<label class="conl"><input type="radio" name="form[delete_full]" value="0"<?php if ($panther_config['o_delete_full'] == '0') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['No'] ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_options['delete full help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><a name="signatures"></a><?php echo $lang_admin_options['Signatures label'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="form[signatures]" value="1"<?php if ($panther_config['o_signatures'] == '1') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['Yes'] ?></strong></label>
										<label class="conl"><input type="radio" name="form[signatures]" value="0"<?php if ($panther_config['o_signatures'] == '0') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['No'] ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_options['Signatures help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Attachments label'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="form[attachments]" value="1"<?php if ($panther_config['o_attachments'] == '1') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['Yes'] ?></strong></label>
										<label class="conl"><input type="radio" name="form[attachments]" value="0"<?php if ($panther_config['o_attachments'] == '0') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['No'] ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_options['Attachments help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Attachments orphans label'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="form[create_orphans]" value="1"<?php if ($panther_config['o_create_orphans'] == '1') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['Yes'] ?></strong></label>
										<label class="conl"><input type="radio" name="form[create_orphans]" value="0"<?php if ($panther_config['o_create_orphans'] == '0') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['No'] ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_options['Attachments orphans help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Attachment deny label'] ?></th>
									<td>
										<input type="text" name="form[always_deny]" size="70" value="<?php echo panther_htmlspecialchars($panther_config['o_always_deny']); ?>" />
										<span class="clearb"><?php echo $lang_admin_options['Attachment deny help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Attachment icons label'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="form[attachment_icons]" value="1"<?php if ($panther_config['o_attachment_icons'] == '1') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['Yes'] ?></strong></label>
										<label class="conl"><input type="radio" name="form[attachment_icons]" value="0"<?php if ($panther_config['o_attachment_icons'] == '0') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['No'] ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_options['Attachment icons help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Attach basefolder label'] ?></th>
									<td>
										<label class="conl"><input type="text" name="form[attachments_dir]" value="<?php echo panther_htmlspecialchars($panther_config['o_attachments_dir']); ?>" tabindex="5" size="50" /></label>
										<span class="clearb"><?php echo $lang_admin_options['Attach basefolder help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['File extensions label']; ?></th>
									<td>
										<input type="text" name="form[attachment_extensions]" value="<?php echo panther_htmlspecialchars($panther_config['o_attachment_extensions']); ?>" tabindex="5" size="50" /><?php echo $lang_admin_options['Extensions']; ?><br />
										<input type="text" name="form[attachment_images]" value="<?php echo panther_htmlspecialchars($panther_config['o_attachment_images']); ?>" tabindex="6" size="50" /><?php echo $lang_admin_options['Icons']; ?>	
										<span><?php echo $lang_admin_options['Icon options']; ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Attachment icon folder label'] ?></th>
									<td>
										<input type="text" name="form[attachment_icon_path]" value="<?php echo panther_htmlspecialchars($panther_config['o_attachment_icon_path']); ?>" />
										<span class="clearb"><?php echo $lang_admin_options['Attachment icon folder help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Attachment icon dir label'] ?></th>
									<td>
										<input type="text" name="form[attachment_icon_dir]" value="<?php echo panther_htmlspecialchars($panther_config['o_attachment_icon_dir']); ?>" />
										<span class="clearb"><?php echo $lang_admin_options['Attachment icon dir help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Max attachments label'] ?></th>
									<td>
										<input type="text" name="form[max_upload_size]" size="10" value="<?php echo $panther_config['o_max_upload_size'] ?>" />
										<span class="clearb"><?php echo $lang_admin_options['Max attachments help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><a name="ranks"></a><?php echo $lang_admin_options['User ranks label'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="form[ranks]" value="1"<?php if ($panther_config['o_ranks'] == '1') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['Yes'] ?></strong></label>
										<label class="conl"><input type="radio" name="form[ranks]" value="0"<?php if ($panther_config['o_ranks'] == '0') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['No'] ?></strong></label>
										<span class="clearb"><?php printf($lang_admin_options['User ranks help'], '<a href="'.get_link($panther_url['admin_ranks']).'">'.$lang_admin_common['Ranks'].'</a>') ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Polls label'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="form[polls]" value="1"<?php if ($panther_config['o_polls'] == '1') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['Yes'] ?></strong></label>
										<label class="conl"><input type="radio" name="form[polls]" value="0"<?php if ($panther_config['o_polls'] == '0') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['No'] ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_options['Polls help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Polls max label'] ?></th>
									<td>
										<input type="text" name="form[max_poll_fields]" value="<?php echo $panther_config['o_max_poll_fields']; ?>" />
										<span class="clearb"><?php echo $lang_admin_options['Polls max help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Reputation label'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="form[reputation]" value="1"<?php if ($panther_config['o_reputation'] == '1') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['Yes'] ?></strong></label>
										<label class="conl"><input type="radio" name="form[reputation]" value="0"<?php if ($panther_config['o_reputation'] == '0') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['No'] ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_options['Reputation help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Rep type label'] ?></th>
									<td>
										<select name="form[rep_type]">
											<option value="1"<?php if ($panther_config['o_rep_type'] == '1') echo ' selected="selected"' ?>><?php echo $lang_admin_options['Positive and negative'] ?></option>
											<option value="2"<?php if ($panther_config['o_rep_type'] == '2') echo ' selected="selected"' ?>><?php echo $lang_admin_options['Positive only'] ?></option>
											<option value="3"<?php if ($panther_config['o_rep_type'] == '3') echo ' selected="selected"' ?>><?php echo $lang_admin_options['Negative only'] ?></option>
										</select>
										<span class="clearb"><?php echo $lang_admin_options['Rep type help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Rep abuse label'] ?></th>
									<td>
										<input type="text" name="form[rep_abuse]" size="3" maxlength="3" value="<?php echo $panther_config['o_rep_abuse'] ?>" />
										<span><?php echo $lang_admin_options['Rep abuse help']; ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['PM label'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="form[private_messaging]" value="1"<?php if ($panther_config['o_private_messaging'] == '1') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['Yes'] ?></strong></label>
										<label class="conl"><input type="radio" name="form[private_messaging]" value="0"<?php if ($panther_config['o_private_messaging'] == '0') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['No'] ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_options['PM help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['PM receiver label'] ?></th>
									<td>
										<input type="text" name="form[max_pm_receivers]" size="3" maxlength="2" value="<?php echo $panther_config['o_max_pm_receivers'] ?>" />
										<span class="clearb"><?php echo $lang_admin_options['PM receiver help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['User has posted label'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="form[show_dot]" value="1"<?php if ($panther_config['o_show_dot'] == '1') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['Yes'] ?></strong></label>
										<label class="conl"><input type="radio" name="form[show_dot]" value="0"<?php if ($panther_config['o_show_dot'] == '0') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['No'] ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_options['User has posted help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Login queue label'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="form[login_queue]" value="1"<?php if ($panther_config['o_login_queue'] == '1') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['Yes'] ?></strong></label>
										<label class="conl"><input type="radio" name="form[login_queue]" value="0"<?php if ($panther_config['o_login_queue'] == '0') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['No'] ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_options['Login queue help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Queue size label'] ?></th>
									<td>
										<input type="text" name="form[queue_size]" size="5" maxlength="5" value="<?php echo $panther_config['o_queue_size'] ?>" />
										<span class="clearb"><?php echo $lang_admin_options['Queue size help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Max attempts label'] ?></th>
									<td>
										<input type="text" name="form[max_attempts]" size="5" maxlength="5" value="<?php echo $panther_config['o_max_attempts'] ?>" />
										<span class="clearb"><?php echo $lang_admin_options['Max attempts help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Download updates label'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="form[download_updates]" value="1"<?php if ($panther_config['o_download_updates'] == '1') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['Yes'] ?></strong></label>
										<label class="conl"><input type="radio" name="form[download_updates]" value="0"<?php if ($panther_config['o_download_updates'] == '0') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['No'] ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_options['Download updates help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Debug mode label'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="form[debug_mode]" value="1"<?php if ($panther_config['o_debug_mode'] == '1') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['Yes'] ?></strong></label>
										<label class="conl"><input type="radio" name="form[debug_mode]" value="0"<?php if ($panther_config['o_debug_mode'] == '0') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['No'] ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_options['Debug mode help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Show queries label'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="form[show_queries]" value="1"<?php if ($panther_config['o_show_queries'] == '1') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['Yes'] ?></strong></label>
										<label class="conl"><input type="radio" name="form[show_queries]" value="0"<?php if ($panther_config['o_show_queries'] == '0') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['No'] ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_options['Show queries help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Topic views label'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="form[topic_views]" value="1"<?php if ($panther_config['o_topic_views'] == '1') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['Yes'] ?></strong></label>
										<label class="conl"><input type="radio" name="form[topic_views]" value="0"<?php if ($panther_config['o_topic_views'] == '0') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['No'] ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_options['Topic views help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Quick jump label'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="form[quickjump]" value="1"<?php if ($panther_config['o_quickjump'] == '1') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['Yes'] ?></strong></label>
										<label class="conl"><input type="radio" name="form[quickjump]" value="0"<?php if ($panther_config['o_quickjump'] == '0') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['No'] ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_options['Quick jump help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['GZip label'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="form[gzip]" value="1"<?php if ($panther_config['o_gzip'] == '1') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['Yes'] ?></strong></label>
										<label class="conl"><input type="radio" name="form[gzip]" value="0"<?php if ($panther_config['o_gzip'] == '0') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['No'] ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_options['GZip help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Search all label'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="form[search_all_forums]" value="1"<?php if ($panther_config['o_search_all_forums'] == '1') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['Yes'] ?></strong></label>
										<label class="conl"><input type="radio" name="form[search_all_forums]" value="0"<?php if ($panther_config['o_search_all_forums'] == '0') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['No'] ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_options['Search all help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['SFS api key'] ?></th>
									<td>
										<input type="text" name="form[sfs_api]" size="25" maxlength="25" value="<?php echo panther_htmlspecialchars($panther_config['o_sfs_api']) ?>" />
										<span><?php echo $lang_admin_options['SFS api key help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Tinypng api'] ?></th>
									<td>
										<input type="text" name="form[tinypng_api]" size="25" value="<?php echo panther_htmlspecialchars($panther_config['o_tinypng_api']) ?>" />
										<span><?php echo $lang_admin_options['Tinypng api help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Cloudflare api'] ?></th>
									<td>
										<input type="text" name="form[cloudflare_api]" size="25" value="<?php echo panther_htmlspecialchars($panther_config['o_cloudflare_api']) ?>" />
										<span><?php echo $lang_admin_options['Cloudflare api help'] ?></span>
									</td>
								</tr>

								<tr>
									<th scope="row"><?php echo $lang_admin_options['Menu items label'] ?></th>
									<td>
										<textarea name="form[additional_navlinks]" rows="3" cols="55"><?php echo panther_htmlspecialchars($panther_config['o_additional_navlinks']) ?></textarea>
										<span><?php echo $lang_admin_options['Menu items help'] ?></span>
									</td>
								</tr>
							</table>
						</div>
					</fieldset>
				</div>
				<div class="inform">
					<fieldset>
						<legend><?php echo $lang_admin_options['Feed subhead'] ?></legend>
						<div class="infldset">
							<table class="aligntop">
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Default feed label'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="form[feed_type]" value="0"<?php if ($panther_config['o_feed_type'] == '0') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_options['None'] ?></strong></label>
										<label class="conl"><input type="radio" name="form[feed_type]" value="1"<?php if ($panther_config['o_feed_type'] == '1') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_options['RSS'] ?></strong></label>
										<label class="conl"><input type="radio" name="form[feed_type]" value="2"<?php if ($panther_config['o_feed_type'] == '2') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_options['Atom'] ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_options['Default feed help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Feed TTL label'] ?></th>
									<td>
										<select name="form[feed_ttl]">
											<option value="0"<?php if ($panther_config['o_feed_ttl'] == '0') echo ' selected="selected"'; ?>><?php echo $lang_admin_options['No cache'] ?></option>
<?php

		$times = array(5, 15, 30, 60);

		foreach ($times as $time)
			echo "\t\t\t\t\t\t\t\t\t\t\t".'<option value="'.$time.'"'.($panther_config['o_feed_ttl'] == $time ? ' selected="selected"' : '').'>'.sprintf($lang_admin_options['Minutes'], $time).'</option>'."\n";

?>
										</select>
										<span><?php echo $lang_admin_options['Feed TTL help'] ?></span>
									</td>
								</tr>
							</table>
						</div>
					</fieldset>
				</div>
				<div class="inform">
					<fieldset>
						<legend><?php echo $lang_admin_options['Reports subhead'] ?></legend>
						<div class="infldset">
							<table class="aligntop">
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Reporting method label'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="form[report_method]" value="0"<?php if ($panther_config['o_report_method'] == '0') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_options['Internal'] ?></strong></label>
										<label class="conl"><input type="radio" name="form[report_method]" value="1"<?php if ($panther_config['o_report_method'] == '1') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_options['By e-mail'] ?></strong></label>
										<label class="conl"><input type="radio" name="form[report_method]" value="2"<?php if ($panther_config['o_report_method'] == '2') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_options['Both'] ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_options['Reporting method help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Mailing list label'] ?></th>
									<td>
										<textarea name="form[mailing_list]" rows="5" cols="55"><?php echo panther_htmlspecialchars($panther_config['o_mailing_list']) ?></textarea>
										<span><?php echo $lang_admin_options['Mailing list help'] ?></span>
									</td>
								</tr>
							</table>
						</div>
					</fieldset>
				</div>
				<div class="inform">
					<fieldset>
						<legend><?php echo $lang_admin_options['Avatars subhead'] ?></legend>
						<div class="infldset">
							<table class="aligntop">
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Use avatars label'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="form[avatars]" value="1"<?php if ($panther_config['o_avatars'] == '1') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['Yes'] ?></strong></label>
										<label class="conl"><input type="radio" name="form[avatars]" value="0"<?php if ($panther_config['o_avatars'] == '0') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['No'] ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_options['Use avatars help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Avatar upload label'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="form[avatar_upload]" value="1"<?php if ($panther_config['o_avatar_upload'] == '1') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['Yes'] ?></strong></label>
										<label class="conl"><input type="radio" name="form[avatar_upload]" value="0"<?php if ($panther_config['o_avatar_upload'] == '0') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['No'] ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_options['Avatar upload help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Avatars path label'] ?></th>
									<td>
										<input type="text" name="form[avatars_path]" size="35" maxlength="50" value="<?php echo panther_htmlspecialchars($panther_config['o_avatars_path']) ?>" />
										<span class="clearb"><?php echo $lang_admin_options['Avatars path help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Upload directory label'] ?></th>
									<td>
										<input type="text" name="form[avatars_dir]" size="35" maxlength="50" value="<?php echo panther_htmlspecialchars($panther_config['o_avatars_dir']) ?>" />
										<span><?php echo $lang_admin_options['Upload directory help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Max width label'] ?></th>
									<td>
										<input type="text" name="form[avatars_width]" size="5" maxlength="5" value="<?php echo $panther_config['o_avatars_width'] ?>" />
										<span><?php echo $lang_admin_options['Max width help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Max height label'] ?></th>
									<td>
										<input type="text" name="form[avatars_height]" size="5" maxlength="5" value="<?php echo $panther_config['o_avatars_height'] ?>" />
										<span><?php echo $lang_admin_options['Max height help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Max size label'] ?></th>
									<td>
										<input type="text" name="form[avatars_size]" size="6" maxlength="6" value="<?php echo $panther_config['o_avatars_size'] ?>" />
										<span><?php echo $lang_admin_options['Max size help'] ?></span>
									</td>
								</tr>
							</table>
						</div>
					</fieldset>
				</div>
				<div class="inform">
					<fieldset>
						<legend><?php echo $lang_admin_options['E-mail subhead'] ?></legend>
						<div class="infldset">
							<table class="aligntop">
								<tr>
									<th scope="row"><?php echo $lang_admin_options['E-mail name label'] ?></th>
									<td>
										<input type="text" name="form[email_name]" size="50" maxlength="50" value="<?php echo panther_htmlspecialchars($panther_config['o_email_name']) ?>" />
										<span><?php echo $lang_admin_options['E-mail name help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Admin e-mail label'] ?></th>
									<td>
										<input type="text" name="form[admin_email]" size="50" maxlength="80" value="<?php echo panther_htmlspecialchars($panther_config['o_admin_email']) ?>" />
										<span><?php echo $lang_admin_options['Admin e-mail help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Webmaster e-mail label'] ?></th>
									<td>
										<input type="text" name="form[webmaster_email]" size="50" maxlength="80" value="<?php echo panther_htmlspecialchars($panther_config['o_webmaster_email']) ?>" />
										<span><?php echo $lang_admin_options['Webmaster e-mail help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Forum subscriptions label'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="form[forum_subscriptions]" value="1"<?php if ($panther_config['o_forum_subscriptions'] == '1') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['Yes'] ?></strong></label>
										<label class="conl"><input type="radio" name="form[forum_subscriptions]" value="0"<?php if ($panther_config['o_forum_subscriptions'] == '0') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['No'] ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_options['Forum subscriptions help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Topic subscriptions label'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="form[topic_subscriptions]" value="1"<?php if ($panther_config['o_topic_subscriptions'] == '1') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['Yes'] ?></strong></label>
										<label class="conl"><input type="radio" name="form[topic_subscriptions]" value="0"<?php if ($panther_config['o_topic_subscriptions'] == '0') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['No'] ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_options['Topic subscriptions help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['SMTP address label'] ?></th>
									<td>
										<input type="text" name="form[smtp_host]" size="30" maxlength="100" value="<?php echo panther_htmlspecialchars($panther_config['o_smtp_host']) ?>" />
										<span><?php echo $lang_admin_options['SMTP address help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['SMTP username label'] ?></th>
									<td>
										<input type="text" name="form[smtp_user]" size="25" maxlength="50" value="<?php echo panther_htmlspecialchars($panther_config['o_smtp_user']) ?>" />
										<span><?php echo $lang_admin_options['SMTP username help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['SMTP password label'] ?></th>
									<td>
										<label><input type="checkbox" name="form[smtp_change_pass]" value="1" />&#160;<?php echo $lang_admin_options['SMTP change password help'] ?></label>
<?php $smtp_pass = !empty($panther_config['o_smtp_pass']) ? random_key(panther_strlen($panther_config['o_smtp_pass']), true) : ''; ?>
										<input type="password" name="form[smtp_pass1]" size="25" maxlength="50" value="<?php echo $smtp_pass ?>" />
										<input type="password" name="form[smtp_pass2]" size="25" maxlength="50" value="<?php echo $smtp_pass ?>" />
										<span><?php echo $lang_admin_options['SMTP password help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['SMTP SSL label'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="form[smtp_ssl]" value="1"<?php if ($panther_config['o_smtp_ssl'] == '1') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['Yes'] ?></strong></label>
										<label class="conl"><input type="radio" name="form[smtp_ssl]" value="0"<?php if ($panther_config['o_smtp_ssl'] == '0') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['No'] ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_options['SMTP SSL help'] ?></span>
									</td>
								</tr>
							</table>
						</div>
					</fieldset>
				</div>
				<div class="inform">
					<fieldset>
						<legend><?php echo $lang_admin_options['Registration subhead'] ?></legend>
						<div class="infldset">
							<table class="aligntop">
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Allow new label'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="form[regs_allow]" value="1"<?php if ($panther_config['o_regs_allow'] == '1') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['Yes'] ?></strong></label>
										<label class="conl"><input type="radio" name="form[regs_allow]" value="0"<?php if ($panther_config['o_regs_allow'] == '0') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['No'] ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_options['Allow new help'] ?></span>
									</td> 
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Verify label'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="form[regs_verify]" value="1"<?php if ($panther_config['o_regs_verify'] == '1') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['Yes'] ?></strong></label>
										<label class="conl"><input type="radio" name="form[regs_verify]" value="0"<?php if ($panther_config['o_regs_verify'] == '0') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['No'] ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_options['Verify help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Report new label'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="form[regs_report]" value="1"<?php if ($panther_config['o_regs_report'] == '1') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['Yes'] ?></strong></label>
										<label class="conl"><input type="radio" name="form[regs_report]" value="0"<?php if ($panther_config['o_regs_report'] == '0') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['No'] ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_options['Report new help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Use rules label'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="form[rules]" value="1"<?php if ($panther_config['o_rules'] == '1') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['Yes'] ?></strong></label>
										<label class="conl"><input type="radio" name="form[rules]" value="0"<?php if ($panther_config['o_rules'] == '0') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['No'] ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_options['Use rules help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Rules label'] ?></th>
									<td>
										<textarea name="form[rules_message]" rows="10" cols="55"><?php echo panther_htmlspecialchars($panther_config['o_rules_message']) ?></textarea>
										<span><?php echo $lang_admin_options['Rules help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['E-mail default label'] ?></th>
									<td>
										<span><?php echo $lang_admin_options['E-mail default help'] ?></span>
										<label><input type="radio" name="form[default_email_setting]" id="form_default_email_setting_0" value="0"<?php if ($panther_config['o_default_email_setting'] == '0') echo ' checked="checked"' ?> />&#160;<?php echo $lang_admin_options['Display e-mail label'] ?></label>
										<label><input type="radio" name="form[default_email_setting]" id="form_default_email_setting_1" value="1"<?php if ($panther_config['o_default_email_setting'] == '1') echo ' checked="checked"' ?> />&#160;<?php echo $lang_admin_options['Hide allow form label'] ?></label>
										<label><input type="radio" name="form[default_email_setting]" id="form_default_email_setting_2" value="2"<?php if ($panther_config['o_default_email_setting'] == '2') echo ' checked="checked"' ?> />&#160;<?php echo $lang_admin_options['Hide both label'] ?></label>
									</td>
								</tr>
							</table>
						</div>
					</fieldset>
				</div>
				<div class="inform">
					<fieldset>
						<legend><?php echo $lang_admin_options['Announcement subhead'] ?></legend>
						<div class="infldset">
							<table class="aligntop">
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Display announcement label'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="form[announcement]" value="1"<?php if ($panther_config['o_announcement'] == '1') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['Yes'] ?></strong></label>
										<label class="conl"><input type="radio" name="form[announcement]" value="0"<?php if ($panther_config['o_announcement'] == '0') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['No'] ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_options['Display announcement help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Announcement message label'] ?></th>
									<td>
										<textarea name="form[announcement_message]" rows="5" cols="55"><?php echo panther_htmlspecialchars($panther_config['o_announcement_message']) ?></textarea>
										<span><?php echo $lang_admin_options['Announcement message help'] ?></span>
									</td>
								</tr>
							</table>
						</div>
					</fieldset>
				</div>
				<div class="inform">
					<fieldset>
						<legend><?php echo $lang_admin_options['Maintenance subhead'] ?></legend>
						<div class="infldset">
							<table class="aligntop">
								<tr>
									<th scope="row"><a name="maintenance"></a><?php echo $lang_admin_options['Maintenance mode label'] ?></th>
									<td>
										<label class="conl"><input type="radio" name="form[maintenance]" value="1"<?php if ($panther_config['o_maintenance'] == '1') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['Yes'] ?></strong></label>
										<label class="conl"><input type="radio" name="form[maintenance]" value="0"<?php if ($panther_config['o_maintenance'] == '0') echo ' checked="checked"' ?> />&#160;<strong><?php echo $lang_admin_common['No'] ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_options['Maintenance mode help'] ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_options['Maintenance message label'] ?></th>
									<td>
										<textarea name="form[maintenance_message]" rows="5" cols="55"><?php echo panther_htmlspecialchars($panther_config['o_maintenance_message']) ?></textarea>
										<span><?php echo $lang_admin_options['Maintenance message help'] ?></span>
									</td>
								</tr>
							</table>
						</div>
					</fieldset>
				</div>
				<p class="submitend"><input type="submit" name="save" value="<?php echo $lang_admin_common['Save changes'] ?>" /></p>
			</form>
		</div>
	</div>
	<div class="clearer"></div>
</div>
<?php

require PANTHER_ROOT.'footer.php';
