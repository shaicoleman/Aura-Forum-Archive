<?php
class template
{
	public $header = array();
	public $footer = array();
	protected $manager;
	public function __construct($registry)
	{
		$this->registry = $registry;
		$this->cache = $registry->cache;
		$this->lang = $registry->lang;

		require AURA_ROOT.'include/lib/Twig/Autoloader.php';

		// Register Twig autoloader
		Twig_Autoloader::register();

		$loader = new Twig_Loader_Filesystem(INSTALL_ROOT.'include/templates');
		$loader->addPath(INSTALL_ROOT.'include/templates/', 'install');

		$this->manager = new Twig_Environment($loader, 
			array(
				'cache' => $this->cache->cache_dir.'templates/install/',
				'debug' => false,
			)
		);
	}

	public function output($tpl_file, $data = array(), $header = true, $footer = true)
	{
		if ($header)
			$this->execute_header();

		$tpl = $this->manager->loadTemplate('@install/'.$tpl_file.'.tpl');
		echo $tpl->render(
			array_merge(
				array(
					'lang' => $this->lang,
					'language' => installer::$language,
					'base_url' => installer::$base_url.'install/',
					'next_step' => installer::$next_step,
					'csrf_token' => installer::$data['csrf_token'],
				), $data
			)
		); 

		if ($footer)
			$this->execute_footer();
	}

	public function execute_header()
	{
		registry::send_headers();

		$header = array_merge(
			$this->header, array(
				'title' => installer::$section,
				'base_url' => installer::$base_url,
			)
		);

		$this->output('header', $header, false, false);
	}

	public function execute_footer()
	{
		$footer = array_merge(
			$this->footer, array(
				'progress' => installer::$progress,
				'page' => installer::$section,
				'default_lang' => installer::$data['language'],
				'languages' => $this->cache->get('locales'),
				'SESSION' => $_SESSION,
			)
		);

		$this->output('footer', $footer, false, false);
	}
}