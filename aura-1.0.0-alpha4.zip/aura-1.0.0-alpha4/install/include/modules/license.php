<?php
if (!defined('INSTALL_ROOT'))
	exit;

class module_license extends installer
{
	function run()
	{
		$data = array(
			'license' => file_get_contents(AURA_ROOT.'LICENSE.md'),
		);

		$this->template->output('license', $data);
	}
}