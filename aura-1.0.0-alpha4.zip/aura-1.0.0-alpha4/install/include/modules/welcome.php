<?php
if (!defined('INSTALL_ROOT'))
	exit;

class module_welcome extends installer
{
	function run()
	{
		$this->cache->clear();

		$data = array(
			'drivers' => installation::$drivers,
			'versions' => installation::$versions,
		);

		$this->template->output('welcome', $data);
	}
}