<?php
if (!defined('INSTALL_ROOT'))
	exit;

class module_settings extends installer
{
	function run()
	{
		$errors = array();
		$styles = new \Aura\styles($this->registry);
		if (isset($_POST['form_sent']))
		{
			$csrf_token = isset($_POST['csrf_token']) ? utf8_trim($_POST['csrf_token']) : '';
			if (!aura_hash_equals(self::$data['csrf_token'], $csrf_token))
				throw new Exception($this->lang('Invalid csrf token'));

			$settings = array(
				'title' => isset($_POST['title']) ? utf8_trim($_POST['title']) : '',
				'description' => isset($_POST['description']) ? utf8_trim($_POST['description']) : '',
				'base_url' => isset($_POST['base_url']) ? utf8_trim($_POST['base_url']) : '',
				'default_lang' => isset($_POST['default_lang']) ? utf8_trim($_POST['default_lang']) : '',
				'default_style' => isset($_POST['default_style']) ? utf8_trim($_POST['default_style']) : '',
				'email_title' => isset($_POST['email_name']) ? utf8_trim($_POST['email_name']) : '',
			);

			// Make sure base_url doesn't end with a slash
			if (substr($settings['base_url'], -1) == '/')
				$settings['base_url'] = substr($settings['base_url'], 0, -1);

			if ($settings['title'] == '')
				$errors[] = $this->lang->t('No board title');

			if (!\Aura\lang::language_exists($settings['default_lang']))
				$errors[] = $this->lang->t('Error default language');

			if (!\Aura\styles::style_exists($settings['default_style']))
				$errors[] = $this->lang->t('Error default style');

			if ($settings['email_title'] == '')
				$errors[] = $this->lang->t('No email name');

			if (empty($errors))
			{
				installer::add_progress(9);
				self::$data = array_merge($settings, self::$data);

				header('Location: '.self::$base_url.'install/?act=advanced');
				exit;
			}
		}

		$data = array(
			'errors' => $errors,
			'SESSION' => $_SESSION,
			'languages' => \Aura\lang::get_language_locales(),
			'default_lang' => installation::DEFAULT_LANG,
			'default_style' => installation::DEFAULT_STYLE,
			'styles' => \Aura\styles::get_style_names(),
		);

		$this->template->output('settings', $data);
	}
}