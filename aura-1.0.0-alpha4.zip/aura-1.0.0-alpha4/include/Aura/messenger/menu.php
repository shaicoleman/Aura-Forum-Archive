<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

namespace Aura\messenger;
use AuraClass;

class menu extends AuraClass
{
	//
	// Display PM menu
	//
	function generate($page = 2) // Default to inbox
	{
		static $folders;

		$percent = ($this->user['g_pm_limit'] != '0') ? round(ceil($this->user['num_pms'] / $this->user['g_pm_limit']*100), 0) : 0;
		$limit = ($this->user['g_pm_limit'] == '0') ? '&infin;' : $this->user['g_pm_limit'];
		
		$data = array(
			':uid' => $this->user['id'],
		);

		$folders = array();
		$ps = $this->db->select('folders', 'name, id', $data, 'user_id=:uid OR user_id=1', 'id, user_id ASC');
		foreach ($ps as $folder)
		{
			$data = array(
				':id' => $folder['id'],
				':uid' => $this->user['id'],
			);

			$ps1 = $this->db->select('pms_data', 'COUNT(topic_id)', $data, 'user_id=:uid AND deleted=0 AND (folder_id=:id '.(($folder['id'] == 1) ? 'OR viewed=0)' : ')'));
			$amount = $ps1->fetchColumn();

			$folders[] = array(
				'id' => $folder['id'],
				'link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['box'], array($folder['id'])),
				'name' => $folder['name'],
				'amount' => $amount,
			);
		}
		
		$tpl = $this->template->load('pm_sidebar.tpl');
		return $tpl->render(
			array(
				'lang' => $this->lang,
				'folders' => $folders,
				'percent' => $percent,
				'num_pms' => $this->functions->forum_number_format($this->user['num_pms']),
				'limit' => $this->functions->forum_number_format($limit),
				'blocked_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['pms_blocked']),
				'folders_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['pms_folders']),
				'page' => $page,
			)
		);
	}
}