<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
namespace Aura;
use AuraClass;
use Aura;

if (!defined('config::SESSION'))
	exit;

class online extends AuraClass
{
	//
	// Update "Users online"
	//
	function update_users_online()
	{
		$online['users'] = $online['guests'] = array();

		$join = array(
			array(
				'type' => 'LEFT',
				'table' => 'users',
				'as' => 'u',
				'on' => 'o.user_id=u.id',
			),
		);

		// Fetch all online list entries that are older than "o_timeout_online"
		$ps = $this->db->join('online', 'o', $join, 'o.user_id, o.ident, o.logged, o.idle, u.group_id');
		foreach ($ps as $cur_user)
		{
			if ($cur_user['logged'] < (CURRENT_TIMESTAMP - $this->config['o_timeout_online']))
			{
				// If the entry is a guest, delete it
				if ($cur_user['user_id'] == '1')
				{
					$data = array(
						':ident' => $cur_user['ident']
					);

					$this->db->delete('online', 'ident=:ident', $data);
				}
				else
				{
					// If the entry is older than "o_timeout_visit", update last_visit for the user in question, then delete him/her from the online list
					if ($cur_user['logged'] < (CURRENT_TIMESTAMP - $this->config['o_timeout_visit']))
					{
						$update = array(
							'last_visit' => $cur_user['logged'],
						);
						
						$data = array(
							':id' => $cur_user['user_id'],
						);
						
						$this->db->update('users', $update, 'id=:id', $data);
						$this->db->delete('online', 'user_id=:id', $data);
					}
				}
			}
			else
			{
				if ($cur_user['user_id'] == 1)
					$online['guests'][] = array('ident' => $cur_user['ident'], 'group_id' => AURA_GUEST);
				else
					$online['users'][$cur_user['user_id']] = array('username' => $cur_user['ident'], 'group_id' => $cur_user['group_id'], 'id' => $cur_user['user_id']);
			}
		}

		if (!$this->user['is_bot'])
		{
			$update = array(
				'currently'	=> $this->generate_location(),
			);

			$data = array();
			if ($this->user['is_guest'])
			{
				$field = 'ident';
				$data[':ident'] = get_remote_address();
			}
			else
			{
				$field = 'user_id';
				$data[':ident'] = $this->user['id'];
			}

			$this->db->update('online', $update, $field.'=:ident', $data);
		}

		return $online;
	}

	//
	// Present the user with a nicely-formatted location string of where this user is
	//
	function fetch_user_location($location, $permissions = null)
	{
		static $permissions;

		if (is_null($permissions))
			$permissions = $this->cache->get('perms');

		$location = explode('|', $location);
		switch ($location[0])
		{
			case null:
				return $this->lang->t('Unavailable');
			case '':
				return $this->lang->t('Not online');
			case 'index':
				return $this->lang->t('Viewing index');
			case 'userlist':
				return $this->lang->t('Viewing userlist');
			case 'search':
				return $this->lang->t('Searching');
			case 'online':
				return $this->lang->t('Viewing users online');
			case 'rules':
				return $this->lang->t('Viewing board rules');
			case 'posting':
				return $this->lang->t('Posting');
			case 'help':
				return $this->lang->t('Viewing help');
			case 'admin':
				return $this->lang->t('In administration');
			case 'pm':
				return $this->lang->t('Using personal messaging');
			case 'login':
				return $this->lang->t('Logging in');
			case 'moderate':
				return $this->lang->t('Moderating');
			case 'register':
				return $this->lang->t('Registering');
			case 'moderators':
				return $this->lang->t('Viewing the team');
			case 'profile':
				$data = array(
					':id' => $location[1],
				);

				$ps = $this->db->select('users', 'username, group_id', $data, 'id=:id');
				$cur_user = $ps->fetch();

				return array('lang' => $this->lang->t('Viewing profile'), 'name' => $this->functions->colourise_group($cur_user['username'], $cur_user['group_id'], $location[1]));
			case 'forum':
				if (isset($location[2])) // Then we're actually viewing a topic
				{
					$data = array(
						':id' => $location[3],
					);

					$ps = $this->db->select('topics', 'subject, forum_id AS fid', $data, 'id=:id');
					$cur_topic = $ps->fetch();

					if (!isset($permissions[$this->user['g_id'].'_'.$cur_topic['fid']]))
						$permissions[$this->user['g_id'].'_'.$cur_topic['fid']] = $permissions['_'];

					if ($permissions[$this->user['g_id'].'_'.$cur_topic['fid']]['read_forum'] == '1' || is_null($permissions[$this->user['g_id'].'_'.$cur_topic['fid']]['read_forum']))
						return array('href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['topic'], array($location[3], \Aura\url\url::replace($cur_topic['subject']))), 'name' => $cur_topic['subject'], 'lang' => $this->lang->t('Viewing topic'));
				}
				else // Or it is actually a forum
				{
					$data = array(
						':id' => $location[1],
					);

					$ps = $this->db->select('forums', 'forum_name', $data, 'id=:id');
					$forum_name = $ps->fetchColumn();

					if (!isset($permissions[$this->user['g_id'].'_'.$location[1]]))
						$permissions[$this->user['g_id'].'_'.$location[1]] = $permissions['_'];
					
					if ($permissions[$this->user['g_id'].'_'.$location[1]]['read_forum'] == '1' || is_null($permissions[$this->user['g_id'].'_'.$location[1]]['read_forum']))
						return array('href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['forum'], array($location[1], \Aura\url\url::replace($forum_name))), 'name' => $forum_name, 'lang' => $this->lang->t('Viewing forum'));
				}

				return $this->lang->t('Viewing hidden forum');
			case 'post-topic':
				$data = array(
					':id' => $location[1],
				);

				$ps = $this->db->select('forums', 'forum_name', $data, 'id=:id');
				$forum_name = $ps->fetchColumn();

				if (!isset($permissions[$this->user['g_id'].'_'.$location[1]]))
					$permissions[$this->user['g_id'].'_'.$location[1]] = $permissions['_'];
				
				if ($permissions[$this->user['g_id'].'_'.$location[1]]['read_forum'] == '1' || is_null($permissions[$this->user['g_id'].'_'.$location[1]]['read_forum']))
					return array('href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['forum'], array($location[1], \Aura\url\url::replace($forum_name))), 'name' => $forum_name, 'lang' => $this->lang->t('Posting topic'));

				return $this->lang->t('Viewing hidden forum');
			case 'post-reply':
				$data = array(
					':id' => $location[1],
				);

				$ps = $this->db->select('topics', 'subject, forum_id AS fid', $data, 'id=:id');
				$cur_topic = $ps->fetch();	

				if (!isset($permissions[$this->user['g_id'].'_'.$cur_topic['fid']]))
					$permissions[$this->user['g_id'].'_'.$cur_topic['fid']] = $permissions['_'];

				if ($permissions[$this->user['g_id'].'_'.$cur_topic['fid']]['read_forum'] == '1' || is_null($permissions[$this->user['g_id'].'_'.$cur_topic['fid']]['read_forum']))
					return array('href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['topic'], array($location[1], \Aura\url\url::replace($cur_topic['subject']))), 'name' => $cur_topic['subject'], 'lang' => $this->lang->t('Replying to topic'));

				return $this->lang->t('Viewing hidden forum');
			case 'edit':
				$join = array(
					array(
						'type' => 'INNER',
						'table' => 'topics',
						'as' => 't',
						'on' => 'p.topic_id=t.id',
					),
				);

				$data = array(
					':id' => $location[1],
				);

				$ps = $this->db->join('posts', 'p', $join, 't.subject, t.forum_id AS fid', $data, 'p.id=:id');
				$cur_topic = $ps->fetch();

				if (!isset($permissions[$this->user['g_id'].'_'.$cur_topic['fid']]))
					$permissions[$this->user['g_id'].'_'.$cur_topic['fid']] = $permissions['_'];

				if ($permissions[$this->user['g_id'].'_'.$cur_topic['fid']]['read_forum'] == '1' || is_null($permissions[$this->user['g_id'].'_'.$cur_topic['fid']]['read_forum']))
					return array('href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['post'], array($id)), 'name' => $cur_topic['subject'], 'lang' => $this->lang->t('Editing post'));

				return $this->lang->t('Viewing hidden forum');
			case 'delete':
				$join = array(
					array(
						'type' => 'INNER',
						'table' => 'topics',
						'as' => 't',
						'on' => 'p.topic_id=t.id',
					),
				);

				$data = array(
					':id' => $location[1],
				);

				$ps = $this->db->join('posts', 'p', $join, 't.subject, t.forum_id AS fid', $data, 'p.id=:id');
				$cur_topic = $ps->fetch();

				if (!isset($perms[$this->user['g_id'].'_'.$cur_topic['fid']]))
					$perms[$this->user['g_id'].'_'.$cur_topic['fid']] = $perms['_'];

				if ($perms[$this->user['g_id'].'_'.$cur_topic['fid']]['read_forum'] == '1' || is_null($perms[$this->user['g_id'].'_'.$cur_topic['fid']]['read_forum']))
					return array('href' => $this->registry->get('\links')->aura_link($this->rewrite->url['post'], array($location[1])), 'name' => $cur_topic['subject'], 'lang' => $this->lang->t('Deleting post'));

				return $this->lang->t('Viewing hidden forum');
			default:
				// In case any custom locations are added
				$location = $this->registry->get('\Aura\extensions\hooks')->fire('online.location.generate', $location);
			break;
		}

		// If all else fails, just return the location string
		return $location[0];
	}

	//
	// Fetch an easy-to-use location of where the user is on the forum based on a URL
	//
	function generate_location()
	{
		$app = isset($_GET['app']) ? $_GET['app'] : Aura::DEFAULT_APP;
		$action = isset($_GET['act']) ? $_GET['act'] : Aura::DEFAULT_ACT;

		switch ($app.'|'.$action)
		{
			case 'members|userlist':
				return 'userlist';
			break;
			case 'search|index':
			case 'search|search':
				return 'search';
			break;
			case 'forums|online':
				return 'online';
			break;
			case 'forums|help':
				return 'help';
			break;
			case 'misc|leaders':
				return 'moderators';
			break;
			case 'forums|viewforum':
				$id = filter_var($_GET['id'], FILTER_SANITIZE_NUMBER_INT);
				return 'forum|'.$id;
			break;
			case 'forums|viewtopic':
				if (isset($_GET['pid']))
				{
					$pid = filter_var($_GET['pid'], FILTER_SANITIZE_NUMBER_INT);
					$join = array(
						array(
							'type' => 'INNER',
							'table' => 'topics',
							'as' => 't',
							'on' => 'p.topic_id=t.id',
						),
					);

					$data = array(
						':id' => $pid,
					);

					$ps = $this->db->join('posts', 'p', $join, 't.id AS tid, t.forum_id AS fid', $data, 'p.id=:id');
					$cur_post = $ps->fetch();

					return 'forum|'.$cur_post['fid'].'|topic|'.$cur_post['tid'];
				}
				else
				{
					$id = filter_var($_GET['id'], FILTER_SANITIZE_NUMBER_INT);
					$data = array(
						':id' => $id,
					);

					$ps = $this->db->select('topics', 'forum_id', $data, 'id=:id');
					$forum_id = $ps->fetchColumn();

					return 'forum|'.$forum_id.'|topic|'.$id;
				}
			break;
			case 'misc|rules':
				return 'rules';
			break;
			case 'forums|post':
				if (isset($_GET['fid']))
				{
					$fid = filter_var($_GET['fid'], FILTER_SANITIZE_NUMBER_INT);
					return 'post-topic|'.$fid;
				}
				else
				{
					$tid = filter_var($_GET['tid'], FILTER_SANITIZE_NUMBER_INT);
					return 'post-reply|'.$tid;
				}
			break;
			case 'modcp|':
			case 'admin':
				return 'admin';
			break;
			case 'messenger|index':
			case 'messenger|folders':
			case 'messenger|blocked':
			case 'messenger|delete':
			case 'messenger|edit':
			case 'messenger|send':
			case 'messenger|view':
				return 'pm';
			break;
			case 'members|login':
				return 'login';
			break;
			case 'moderate|forum':
			case 'moderate|get_host':
			case 'moderate|index':
			case 'moderate|topic':
				return 'moderate';
			break;
			case 'members|register':
				return 'register';
			break;
			case 'profile|index':
			case 'profile|admin':
			case 'profile|essentials':
			case 'profile|attachments':
			case 'profile|change_email':
			case 'profile|change_pass':
			case 'profile|delete_avatar':
			case 'profile|display':
			case 'profile|messaging':
			case 'profile|personal':
			case 'profile|personality':
			case 'profile|privacy':
			case 'profile|promote':
			case 'profile|reputation':
			case 'profile|upload_avatar':
			case 'profile|use_gravatar':
				$id = filter_var($_GET['id'], FILTER_SANITIZE_NUMBER_INT);
				return 'profile|'.$id;
			break;
			case 'forums|edit':
				$id = filter_var($_GET['id'], FILTER_SANITIZE_NUMBER_INT);

				$join = array(
					array(
						'type' => 'INNER',
						'table' => 'topics',
						'as' => 't',
						'on' => 'p.topic_id=t.id',
					),
				);

				$data = array(
					':id' => $id,
				);

				$ps = $this->db->join('posts', 'p', $join, 't.id', $data, 'p.id=:id');
				$topic_id = $ps->fetchColumn();

				return 'edit|'.$topic_id;
			break;
			case 'forums|delete':
				$id = filter_var($_GET['id'], FILTER_SANITIZE_NUMBER_INT);

				$join = array(
					array(
						'type' => 'INNER',
						'table' => 'topics',
						'as' => 't',
						'on' => 'p.topic_id=t.id',
					),
				);

				$data = array(
					':id' => $id,
				);

				$ps = $this->db->join('posts', 'p', $join, 't.id', $data, 'p.id=:id');
				$topic_id = $ps->fetchColumn();

				return 'delete|'.$topic_id;
			break;
			default:
				$location = 'index';
				$location = $this->registry->get('\Aura\extensions\hooks')->fire('online.location.find', $location);
				
				return $location;
			break;
		}
	}
}