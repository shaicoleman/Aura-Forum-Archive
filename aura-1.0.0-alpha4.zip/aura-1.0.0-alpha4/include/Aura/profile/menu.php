<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

namespace Aura\profile;
use AuraClass;

class menu extends AuraClass
{
	//
	// Display the profile navigation menu
	//
	function generate($id, $page = '')
	{
		$sections = array(
			array('page' => 'essentials', 'link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['profile_essentials'], array($id)), 'lang' => $this->lang->t('Section essentials')),
			array('page' => 'personal', 'link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['profile_personal'], array($id)), 'lang' => $this->lang->t('Section personal')),
			array('page' => 'messaging', 'link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['profile_messaging'], array($id)), 'lang' => $this->lang->t('Section messaging')),
		);

		if ($this->config['o_avatars'] == '1' || $this->config['o_signatures'] == '1')
			$sections[] = array('page' => 'personality', 'link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['profile_personality'], array($id)), 'lang' => $this->lang->t('Section personality'));

		$sections[] = array('page' => 'display', 'link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['profile_display'], array($id)), 'lang' => $this->lang->t('Section display'));
		$sections[] = array('page' => 'privacy', 'link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['profile_privacy'], array($id)), 'lang' => $this->lang->t('Section privacy'));

		if ($this->config['o_attachments'] == '1')
			$sections[] = array('page' => 'attachments', 'link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['profile_attachments'], array($id)), 'lang' => $this->lang->t('Section attachments'));

		$sections[] = array('page' => 'view', 'link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['profile_view'], array($id)), 'lang' => $this->lang->t('Section view'));

		if ($this->user['is_admin'] || ($this->user['g_moderator'] == '1' && $this->user['g_mod_ban_users'] == '1'))
			$sections[] = array('page' => 'admin', 'link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['profile_admin'], array($id)), 'lang' => $this->lang->t('Section admin'));

		$tpl = $this->template->load('profile_sidebar.tpl');
		return $this->template->render($tpl,
			array(
				'sections' => $sections,
				'page' => $page,
			), false, false
		);
	}
}