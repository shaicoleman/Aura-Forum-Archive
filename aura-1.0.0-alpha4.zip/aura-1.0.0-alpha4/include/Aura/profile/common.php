<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */


namespace Aura\profile;
use PDO;
use Aura\styles;
use config;

/**
 * Helper class to load a user profile
 */
class common
{
	protected $id;
	public function __construct($registry)
	{
		$this->registry = $registry;
		$this->user = $registry->user;
		$this->lang = $registry->lang;
		$this->db = $registry->db;
		$this->config = $registry->config;
		$this->rewrite = $registry->rewrite;
		$this->functions = $registry->functions;
		$this->template = $registry->template;
		$this->cache = $registry->cache;

		if ($this->user['is_bot'])
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'));

		// Include UTF-8 function
		require AURA_ROOT.'include/lib/utf8/substr_replace.php';
		require AURA_ROOT.'include/lib/utf8/ucwords.php'; // utf8_ucwords needs utf8_substr_replace
		require AURA_ROOT.'include/lib/utf8/strcasecmp.php';

		$action = isset($_GET['act']) ? $_GET['act'] : null;
		$this->do = isset($_GET['do']) ? $_GET['do'] : null;
		$this->id = isset($_GET['id']) ? intval($_GET['id']) : 0;
		if ($this->id < 2)
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		if ($action != 'change_pass' || !isset($_GET['key']))
		{
			if ($this->user['g_read_board'] == '0')
				$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No view'), false, '403 Forbidden');
			else if ($this->user['g_view_users'] == '0' && ($this->user['is_guest'] || $this->user['id'] != $this->id))
				$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');
		}

		// Load the profile/register language file
		$this->lang->load('prof_reg');

		// Load the profile language file
		$this->lang->load('profile');
	}

	public function update_profile($action)
	{
		$this->registry->get('\Aura\auth\csrf')->confirm('profile');
		$join = array(
			array(
				'type' => 'LEFT',
				'table' => 'groups',
				'as' => 'g',
				'on' => '(g.g_id=u.group_id)',
			),
		);

		$data = array(
			':id' => $this->id,
		);

		// Fetch the user group of the user we are editing
		$ps = $this->db->join('users', 'u', $join, 'u.username, u.group_id, g.g_moderator', $data, 'u.id=:id');
		if (!$ps->rowCount())
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		list($old_username, $group_id, $is_moderator) = $ps->fetch(PDO::FETCH_NUM);

		if ($this->user['id'] != $this->id && !in_array($this->do, array('received', 'given')) && // If we aren't the user (i.e. editing your own profile) and we aren't viewing what rep they have
			(!$this->user['is_admmod'] ||	// and we are not an admin or mod
			(!$this->user['is_admin'] && // or we aren't an admin and ...
			($this->user['g_mod_edit_users'] == '0' || // mods in this group aren't allowed to edit users
			$group_id == config::USER_ADMIN || // or the user is an admin
			$is_moderator)))) // or the user is another mod
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		$username_updated = false;

		// Validate input depending on section
		switch ($action)
		{
			case 'essentials':
			{
				$form = array(
					'timezone'		=> floatval($_POST['form']['timezone']),
					'dst'			=> isset($_POST['form']['dst']) ? '1' : '0',
					'time_format'	=> intval($_POST['form']['time_format']),
					'date_format'	=> intval($_POST['form']['date_format']),
				);

				// Make sure we got a valid language string
				if (isset($_POST['language']))
				{
					$form['language'] = utf8_trim($_POST['language']);
					if (!\Aura\lang::language_exists($form['language']))
						$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');
				}
				else
					$form['language'] = $this->config['o_default_lang'];

				if ($this->user['is_admmod'])
				{
					$form['admin_note'] = utf8_trim($_POST['admin_note']);

					// Are we allowed to change usernames?
					if ($this->user['is_admin'] || ($this->user['g_moderator'] == '1' && $this->user['g_mod_rename_users'] == '1'))
					{
						$form['username'] = utf8_trim($_POST['req_username']);
						if ($form['username'] != $old_username)
						{
							// Check username
							$this->lang->load('register');

							$errors = $this->registry->get('\Aura\auth\register')->check_username($form['username'], array(), $this->id);
							if (!empty($errors))
								$this->registry->get('\Aura\handlers\message')->show($errors[0]);

							$username_updated = true;
						}
					}

					// We only allow administrators to update the post count
					if ($this->user['is_admin'])
						$form['num_posts'] = intval($_POST['num_posts']);
				}

				if ($this->config['o_regs_verify'] == '0' || $this->user['is_admmod'])
				{
					// Validate the email address
					$form['email'] = strtolower(utf8_trim($_POST['req_email']));
					if (!is_valid_email($form['email']))
						$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Invalid email'));
				}

				break;
			}

			case 'personal':
			{
				$form = array(
					'realname'		=> isset($_POST['form']['realname']) ? utf8_trim($_POST['form']['realname']) : '',
					'url'			=> isset($_POST['form']['url']) ? utf8_trim($_POST['form']['url']) : '',
					'location'		=> isset($_POST['form']['location']) ? utf8_trim($_POST['form']['location']) : '',
				);

				// Add http:// if the URL doesn't contain it already (while allowing https://, too)
				if ($this->user['g_post_links'] == '1')
				{
					if ($form['url'] != '')
					{
						$url = url_valid($form['url']);

						if ($url === false)
							$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Invalid website URL'));

						$form['url'] = $url['url'];
					}
				}
				else
				{
					if (!empty($form['url']))
						$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Website not allowed'));

					$form['url'] = '';
				}

				if ($this->user['is_admin'])
					$form['title'] = utf8_trim($_POST['title']);
				else if ($this->user['g_set_title'] == '1')
				{
					$form['title'] = utf8_trim($_POST['title']);

					if ($form['title'] != '')
					{
						// A list of words that the title may not contain
						// If the language is English, there will be some duplicates, but it's not the end of the world
						$forbidden = array('member', 'moderator', 'administrator', 'banned', 'guest', utf8_strtolower($this->lang->t('Member')), utf8_strtolower($this->lang->t('Moderator')), utf8_strtolower($this->lang->t('Administrator')), utf8_strtolower($this->lang->t('Banned')), utf8_strtolower($this->lang->t('Guest')));

						if (in_array(utf8_strtolower($form['title']), $forbidden))
							$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Forbidden title'));
					}
				}

				break;
			}

			case 'messaging':
			{
				$form = array(
					'facebook'		=> utf8_trim($_POST['form']['facebook']),
					'steam'			=> utf8_trim($_POST['form']['steam']),
					'skype'			=> utf8_trim($_POST['form']['skype']),
					'google'		=> utf8_trim($_POST['form']['google']),
					'twitter'		=> utf8_trim($_POST['form']['twitter']),
				);

				break;
			}

			case 'personality':
			{
				$form = array();

				// Clean up signature from POST
				if ($this->config['o_signatures'] == '1')
				{
					$form['signature'] = isset($_POST['signature']) ? aura_linebreaks(utf8_trim($_POST['signature'])) : '';

					// Validate signature
					if (aura_strlen($form['signature']) > $this->config['p_sig_length'])
						$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Sig too long', $this->config['p_sig_length'], aura_strlen($form['signature']) - $this->config['p_sig_length']));
					else if (substr_count($form['signature'], "\n") > ($this->config['p_sig_lines']-1))
						$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Sig too many lines', $this->config['p_sig_lines']));
					else if ($form['signature'] && $this->config['p_sig_all_caps'] == '0' && is_all_uppercase($form['signature']) && !$this->user['is_admmod'])
						$form['signature'] = utf8_ucwords(utf8_strtolower($form['signature']));

					// Validate BBCode syntax
					if ($this->config['p_sig_bbcode'] == '1')
					{
						$parser = $this->registry->get('\Aura\message\parser');

						$errors = array();
						$form['signature'] = $parser->preparse_bbcode($form['signature'], $errors, true);

						if (!empty($errors))
							$this->registry->get('\Aura\handlers\message')->show('<ul><li>'.implode('</li><li>', $errors).'</li></ul>');
					}
				}

				break;
			}

			case 'display':
			{
				$form = array(
					'disp_topics'		=> utf8_trim($_POST['form']['disp_topics']),
					'disp_posts'		=> utf8_trim($_POST['form']['disp_posts']),
					'use_editor'		=> isset($_POST['form']['use_editor']) ? '1' : '0',
				);

				if ($this->config['o_smilies'] == '1' || $this->config['o_smilies_sig'] == '1')
					$form['show_smilies'] = isset($_POST['form']['show_smilies']) ? '1' : '0';

				if ($this->config['p_message_bbcode'] == '1' && $this->config['p_message_img_tag'] == '1')
					$form['show_img'] = isset($_POST['form']['show_img']) ? '1' : '0';

				if ($this->config['o_signatures'] == '1' && $this->config['p_sig_bbcode'] == '1' && $this->config['p_sig_img_tag'] == '1')
					$form['show_img_sig'] = isset($_POST['form']['show_img_sig']) ? '1' : '0';

				if ($this->config['o_avatars'] == '1')
					$form['show_avatars'] = isset($_POST['form']['show_avatars']) ? '1' : '0';

				if ($this->config['o_signatures'] == '1')
					$form['show_sig'] = isset($_POST['form']['show_sig']) ? '1' : '0';

				if ($form['disp_topics'] != '')
				{
					$form['disp_topics'] = intval($form['disp_topics']);
					if ($form['disp_topics'] < 3)
						$form['disp_topics'] = 3;
					else if ($form['disp_topics'] > 75)
						$form['disp_topics'] = 75;
				}

				if ($form['disp_posts'] != '')
				{
					$form['disp_posts'] = intval($form['disp_posts']);
					if ($form['disp_posts'] < 3)
						$form['disp_posts'] = 3;
					else if ($form['disp_posts'] > 75)
						$form['disp_posts'] = 75;
				}

				// Make sure we got a valid style string
				if (isset($_POST['form']['style']))
				{
					$styles = styles::get_styles_list();
					$form['style'] = utf8_trim($_POST['form']['style']);
					if (!in_array($form['style'], $styles))
						$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');
				}
				else
					$form['style'] = $this->config['o_default_style'];

				break;
			}

			case 'privacy':
			{
				$form = array(
					'email_setting'			=> intval($_POST['form']['email_setting']),
					'notify_with_post'		=> isset($_POST['form']['notify_with_post']) ? '1' : '0',
					'auto_notify'			=> isset($_POST['form']['auto_notify']) ? '1' : '0',
					'pm_enabled'			=> isset($_POST['form']['pm_enabled']) ? '1' : '0',
					'pm_notify'				=> isset($_POST['form']['pm_notify']) ? '1' : '0',
				);

				if ($form['email_setting'] < 0 || $form['email_setting'] > 2)
					$form['email_setting'] = $this->config['o_default_email_setting'];

				break;
			}

			default:
				$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');
		}

		// Single quotes around non-empty values and NULL for empty values
		$temp = $data = array();
		foreach ($form as $key => $input)
		{
			$value = ($input !== '') ? $input : NULL;

			$temp[] = $key.'= ?';
			$data[] = $value;
		}

		if (empty($temp))
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		$data[] = $this->id;
		$this->db->run('UPDATE '.$this->db->prefix.'users SET '.implode(',', $temp).' WHERE id=?', $data);

		// If we changed the username we have to update some stuff
		if ($username_updated)
		{
			$update = array(
				'username' => $form['username'],
			);

			$data = array(
				':user' => $old_username,
			);

			$rows = $this->db->update('bans', $update, 'username=:user', $data);

			// If any bans were updated, we will need to know because the cache will need to be regenerated.
			if ($rows > 0)
				$bans_updated = true;

			$update = array(
				'poster' => $form['username'],
			);

			$data = array(
				':id' => $this->id,
			);

			$this->db->update('posts', $update, 'poster_id=:id', $data);

			$data = array(
				':username'	=> $old_username,
			);

			$this->db->update('topics', $update, 'poster=:username', $data);
			$this->db->update('conversations', $update, 'poster=:username', $data);
			$this->db->update('messages', $update, 'poster=:username', $data);

			$update = array(
				'edited_by'	=> $form['username'],
			);

			$this->db->update('posts', $update, 'edited_by=:username', $data);
			$this->db->update('messages', $update, 'edited_by=:username', $data);

			$update = array(
				'last_poster' => $form['username'],
			);

			$this->db->update('topics', $update, 'last_poster=:username', $data);
			$this->db->update('forums', $update, 'last_poster=:username', $data);

			$this->db->update('conversations', $update, 'last_poster=:username', $data);

			$update = array(
				'ident'	=> $form['username'],
			);

			$this->db->update('online', $update, 'ident=:username', $data);

			// If the user is a moderator or an administrator we have to update the moderator lists
			$data = array(
				':id' => $this->id,
			);

			$ps = $this->db->select('users', 'group_id', $data, 'id=:id');
			$group_id = $ps->fetchColumn();

			$groups = $this->cache->get('groups');
			if ($group_id == AURA_ADMIN || $groups[$group_id]['g_moderator'] == '1')
			{
				$update = array(
					'username' => $form['username'],
				);

				$data = array(
					':id' => $this->id,
				);

				$this->db->update('moderators', $update, 'user_id=:id', $data);
				$this->cache->generate('moderators');
			}

			// Regenerate the users info cache
			$this->cache->generate('stats');

			// Check if the bans table was updated and regenerate the bans cache when needed
			if (isset($bans_updated))
				$this->cache->generate('bans');
		}

		$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['profile_'.strtolower($action)], array($this->id)), $this->lang->t('Profile redirect'));		
	}

	public function fetch_id()
	{
		return $this->id;
	}

	public function fetch_user()
	{
		$join = array(
			array(
				'type' => 'LEFT',
				'table' => 'groups',
				'as' => 'g',
				'on' => 'g.g_id=u.group_id',
			),
		);

		$data = array(
			':id' => $this->id,
		);

		$ps = $this->db->join('users', 'u', $join, 'u.username, u.email, u.title, u.realname, u.url, u.facebook, u.steam, u.skype, u.google, u.twitter, u.location, u.signature, u.disp_topics, u.disp_posts, u.email_setting, u.notify_with_post, u.auto_notify, u.use_editor, u.pm_enabled, u.pm_notify, u.use_gravatar, u.show_smilies, u.show_img, u.show_img_sig, u.show_avatars, u.show_sig, u.timezone, u.dst, u.language, u.style, u.num_posts, u.last_post, u.last_visit, u.registered, u.registration_ip, u.reputation, u.admin_note, u.date_format, u.time_format, u.last_visit, u.posting_ban, g.g_id, g.g_user_title, g.g_moderator, g.g_use_pm, g.g_admin', $data, 'u.id=:id');
		if (!$ps->rowCount())
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');
		else
			$user = $ps->fetch();


	// View or edit?
	if ($this->user['id'] != $this->id && !in_array($this->do, array('received', 'given', 'view')) && // If we aren't the user (i.e. editing your own profile) and we aren't viewing what rep they have
		(!$this->user['is_admmod'] ||	// and we are not an admin or mod
		(!$this->user['is_admin'] &&	// or we aren't an admin and ...
		($this->user['g_mod_edit_users'] == '0' ||	// mods aren't allowed to edit users
		$user['g_id'] == config::USER_ADMIN ||	// or the user is an admin
		$user['g_moderator'] == '1'))) || $this->do == 'view')	// or the user is another mod
			$this->view_profile($user, $this->id);

		return $user;
	}

	public function view_profile($user)
	{
		$icon = $status = '';
		$user_personal = array();
		if ($this->config['o_users_online'] == '1')
		{
			$this->lang->load('online');
			$data = array(
				':id' => $this->id,
			);
			
			$ps = $this->db->select('online', 'currently', $data, 'user_id=:id');
			$online = $ps->fetch();
		
			if ($online['currently'] == null || $online['currently'] == '')
			{
				$icon = 'status_offline';
				$status = $this->lang->t('User is offline');
				$location = $this->lang->t('Not online');
			}
			else
			{
				$icon = 'status_online';
				$status = $this->lang->t('user is online');
				$location = $this->registry->get('\Aura\online')->fetch_user_location($online['currently']);
			}
		}

		$user_personal[] = array('title' => $this->lang->t('Username'));
		$user_personal[] = array('data' => $this->functions->colourise_group($user['username'], $user['g_id']), 'raw' => true, 'icon' => $this->config['o_image_dir'].$icon.'.png', 'icon_title' => $status);

		$user_title_field = $this->registry->get('\Aura\topics\title')->get_title($user);
		$user_personal[] = array('title' => $this->lang->t('Title'));
		$user_personal[] = array('data' => (($this->config['o_censoring'] == '1') ? $this->registry->get('\Aura\message\bbcode')->censor_words($user_title_field) : $user_title_field));

		if ($user['realname'] != '')
		{
			$user_personal[] = array('title' => $this->lang->t('Realname'));
			$user_personal[] = array('data' => (($this->config['o_censoring'] == '1') ? $this->registry->get('\Aura\message\bbcode')->censor_words($user['realname']) : $user['realname']));
		}

		if ($user['location'] != '')
		{
			$user_personal[] = array('title' => $this->lang->t('Location'));
			$user_personal[] = array('data' => (($this->config['o_censoring'] == '1') ? $this->registry->get('\Aura\message\bbcode')->censor_words($user['location']) : $user['location']));
		}

		if ($user['url'] != '')
		{
			$user['url'] = ($this->config['o_censoring'] == '1') ? $this->registry->get('\Aura\message\bbcode')->censor_words($user['url']) : $user['url'];
			$user_personal[] = array('title' => $this->lang->t('Website'));
			$user_personal[] = array('data' => $user['url'], 'class' => 'website', 'href' => true, 'lang' => $user['url']);
		}

		if ($user['email_setting'] == '0' && !$this->user['is_guest'] && $this->user['g_send_email'] == '1')
			$email_field = array('data' => 'mailto:'.$user['email'], 'class' => 'email', 'href' => true, 'lang' => $user['email']);
		else if ($user['email_setting'] == '1' && !$this->user['is_guest'] && $this->user['g_send_email'] == '1')
			$email_field = array('data' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['email'], array($this->id)), 'class' => 'email', 'href' => true, 'lang' => $this->lang->t('Send email'));

		if ($this->config['o_private_messaging'] == '1' && $this->user['g_use_pm'] == '1' && $this->user['pm_enabled'] && $user['g_use_pm'] && $user['pm_enabled'])
			$user_contacts[] = array('class' => 'email', 'href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['send_pm'], array($this->id)), 'title' => $this->lang->t('Send PM'));

		if (isset($email_field))
		{
			$user_personal[] = array('title' => $this->lang->t('Email'));
			$user_personal[] = $email_field;
		}

		if ($this->config['o_users_online'] == '1')
		{
			$user_personal[] = array('title' => $this->lang->t('Currently'));
			$user_personal[] = array('online' => $location);
		}

		$user_messaging = array();
		if ($user['facebook'] != '')
		{
			$user_messaging[] = array('title' => $this->lang->t('Facebook'));
			$user_messaging[] = array('data' => (($this->config['o_censoring'] == '1') ? $this->registry->get('\Aura\message\bbcode')->censor_words($user['facebook']) : $user['facebook']));
		}

		if ($user['steam'] != '')
		{
			$user_messaging[] = array('title' => $this->lang->t('Steam'));
			$user_messaging[] = array('data' => $user['steam']);
		}

		if ($user['skype'] != '')
		{
			$user_messaging[] = array('title' => $this->lang->t('Skype'));
			$user_messaging[] = array('data' => (($this->config['o_censoring'] == '1') ? $this->registry->get('\Aura\message\bbcode')->censor_words($user['skype']) : $user['skype']));
		}

		if ($user['twitter'] != '')
		{
			$user_messaging[] = array('title' => $this->lang->t('Twitter'));
			$user_messaging[] = array('data' => (($this->config['o_censoring'] == '1') ? $this->registry->get('\Aura\message\bbcode')->censor_words($user['twitter']) : $user['twitter']));
		}

		if ($user['google'] != '')
		{
			$user_messaging[] = array('title' => $this->lang->t('Google'));
			$user_messaging[] = array('data' => (($this->config['o_censoring'] == '1') ? $this->registry->get('\Aura\message\bbcode')->censor_words($user['google']) : $user['google']));
		}

		$user_personality = array();
		if ($this->config['o_avatars'] == '1')
		{
			$user_personality[] = array('title' => $this->lang->t('Avatar'));
			$user_personality[] = array('data' => $this->registry->get('\Aura\avatar')->generate($this->id, $user['email'], $user['use_gravatar']));
		}

		if ($this->config['o_signatures'] == '1')
		{
			if ($user['signature'] != '')
			{
				$parser = $this->registry->get('\Aura\message\parser');

				$user_personality[] = array('title' => $this->lang->t('Signature'));
				$user_personality[] = array('data' => $parser->parse_signature($user['signature']), 'signature' => true);
			}
		}

		$user_activity = $quick_searches = array();
		if ($this->config['o_show_post_count'] == '1' || $this->user['is_admmod'])
			$quick_searches[]['data'] = $this->functions->forum_number_format($user['num_posts']);
		if ($this->user['g_search'] == '1')
		{
			if ($this->user['is_admmod'] && $this->config['o_warnings'] == '1')
			{
				// Load the warnings language file
				$this->lang->load('warnings');

				// Does the user have active warnings?
				$data = array(
					':id'	=>	$this->id,
					':time'	=>	CURRENT_TIMESTAMP,
				);

				$ps = $this->db->select('warnings', 'SUM(points)', $data, 'user_id=:id AND (date_expire>:time OR date_expire=0)');
				$has_active = $ps->fetchColumn();

				if ($has_active)
				{
					$warning_level = $this->lang->t('Warning level');
					$points_active = $has_active;
				}
				else
				{
					$warning_level = $this->lang->t('Warning level');
					$points_active = '0';
				}
			}

			if (($this->user['is_admin'] || ($this->user['is_admmod'] && $this->user['g_mod_warn_users'] == '1')) && $this->config['o_warnings'] == '1')
			{
				$user_activity[] = array('title' => $warning_level);
				$user_activity[] = array('data' => $points_active, 'href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['warning_view'], array($this->id)), 'lang' => $this->lang->t('Show all warnings'), 'href2' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['warn_user'], array($this->id)), 'lang2' => $this->lang->t('Warn user'));
			}
			else if ($this->user['is_admmod'] && $this->config['o_warnings'] == '1')
			{
				$user_activity[] = array('title' => $warning_level);
				$user_activity[] = array('data' => $points_active);
			}

			$quick_searches = array();
			if ($user['num_posts'] > 0)
			{
				$quick_searches[] = array($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['search_user_topics'], array($this->id)), $this->lang->t('Show topics'));
				$quick_searches[] = array($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['search_user_posts'], array($this->id)), $this->lang->t('Show posts'));
			}
			if ($this->user['is_admmod'] && $this->config['o_topic_subscriptions'] == '1')
				$quick_searches[] = array($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['search_subscriptions'], array($this->id)), $this->lang->t('Show subscriptions'));
		}

		if (!empty($quick_searches))
		{
			$user_activity[] = array('title' => $this->lang->t('Posts'));
			$user_activity[] = array('implode' => true, 'data' => $quick_searches);
		}

		if ($user['num_posts'] > 0)
		{
			$user_activity[] = array('title' => $this->lang->t('Last post'));
			$user_activity[] = array('data' => $this->registry->get('\Aura\aura_time')->format($user['last_post']));
		}

		$user_activity[] = array('title' => $this->lang->t('User last visit'));
		$user_activity[] = array('data' => $this->registry->get('\Aura\aura_time')->format($user['last_visit']));

		$user_activity[] = array('title' => $this->lang->t('Registered'));
		$user_activity[] = array('data' => $this->registry->get('\Aura\aura_time')->format($user['registered'], true));

		$render = array(
			'user_personal' => $user_personal,
			'user_messaging' => $user_messaging,
			'user_personality' => $user_personality,
			'user_activity' => $user_activity,
			'profile_menu' => ($this->user['id'] == $this->id || $this->user['is_admmod'] && ($this->user['is_admin'] || $this->user['g_mod_edit_users'] == '1')) ? $this->registry->get('\Aura\profile\menu')->generate($this->id, 'view') : '',
		);

		if ($this->config['o_reputation'] == '1')
		{
			switch(true)
			{
				case $user['reputation'] > '0':
					$type = 'positive';
				break;
				case $user['reputation'] < '0':
					$type = 'negative';
				break;
				default:
					$type = 'zero';
				break;
			}

			$render['reputation'] = array('type' => $type, 'value' => $this->functions->forum_number_format($user['reputation']), 'link_received' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['profile_rep_received'], array($this->id)), 'link_given' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['profile_rep_given'], array($this->id)));
		}

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Users profile', $user['username'])),
			'allow_index' => true,
			'active_page' => 'userlist',
		);

		$tpl = $this->template->load('view_profile.tpl');
		$this->template->output($tpl, $render);
		exit;
	}
}