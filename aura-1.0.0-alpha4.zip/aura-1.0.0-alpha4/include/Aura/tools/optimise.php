<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

namespace Aura\tools;
use AuraClass;
use Exception;

class optimise extends AuraClass
{

	//
	// Compress image using TinyPNG compression API
	//
	function compress_image($image)
	{
		if ($this->config['o_tinypng_api'] == '')
			return;

		if (substr($image, strrpos($image, '.')+1) == 'gif') // Then it can't be compressed, and will return nothing causing the error handler
		{
			$key = max(array_keys(explode('/', $image)));
			cache_cloudflare($image[$key]);
			return;
		}

		if (is_callable('curl_init'))
		{
			$request = curl_init();
			curl_setopt_array($request, array(
				CURLOPT_URL => "https://api.tinypng.com/shrink",
				CURLOPT_USERPWD => "api:".$this->config['o_tinypng_api'],
				CURLOPT_POSTFIELDS => file_get_contents($image),
				CURLOPT_BINARYTRANSFER => true,
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_HEADER => true,
				CURLOPT_SSL_VERIFYPEER => true
			));

			$response = curl_exec($request);
			if (curl_getinfo($request, CURLINFO_HTTP_CODE) === 201)
			{
				$headers = substr($response, 0, curl_getinfo($request, CURLINFO_HEADER_SIZE));
				foreach (explode("\r\n", $headers) as $header)
				{
					if (substr($header, 0, 10) === "Location: ")
					{
						$request = curl_init();
						curl_setopt_array($request, array(
							CURLOPT_URL => substr($header, 10),
							CURLOPT_RETURNTRANSFER => true,
							CURLOPT_SSL_VERIFYPEER => true
						));

						// Replace the image with the compressed one
						file_put_contents($image, curl_exec($request));
					}
				}
			}
			else
				throw new Exception(curl_error($request));
				
			// We only want this doing if the first one works
			$key = max(array_keys(explode('/', $image)));
			$this->cache_cloudflare($image[$key]);
		}
	}

	//
	// Cache images through CloudFlare API
	//
	function cache_cloudflare($file)
	{
		if ($this->config['o_cloudflare_api'] != '')
			return;

		if (is_callable('curl_init'))
		{
			$request = curl_init("https://www.cloudflare.com/api_json.html");
			curl_setopt($request, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($request, CURLOPT_FOLLOWLOCATION, 1);
			curl_setopt($request, CURLOPT_SSL_VERIFYPEER, false);

			$params = array(
				'a' => 'zone_file_purge',
				'tkn' => $this->config['o_cloudflare_api'],
				'email' => $this->config['o_clouflare_email'],
				'z' => $this->config['o_clouflare_domain'],
				'url' => $this->config['o_clouflare_domain'].$file,
			);
			curl_setopt($request, CURLOPT_POST, 1);
			curl_setopt($request, CURLOPT_POSTFIELDS, http_build_query($params));
			$response = curl_exec($request);
			if (curl_getinfo($request, CURLINFO_HTTP_CODE) === 201)
			{
				$result = json_decode($response, true);
				curl_close($request);

				if ($result['msg'] != 'success')
					throw new Exception($result['msg']);

				return true;
			}
		}
	}
}