<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
namespace Aura;
 
if (!defined('config::SESSION'))
	exit;

class functions
{
	public function __construct($registry)
	{
		$this->registry = $registry;
		$this->config = $registry->config;
		$this->lang = $registry->lang;
		$this->db = $registry->db;
		$this->user = $registry->user;
		$this->bans = $registry->bans;
		$this->cache = $registry->cache;
		$this->style = $registry->style;
		$this->rewrite = $registry->rewrite;
		$this->template = $registry->template;
	}

	//
	// Fetch the base_url, optionally support HTTPS and HTTP
	//
	function get_base_url($support_https = true)
	{
		static $base_url;

		if (!$support_https)
			return $this->config['o_base_url'];

		if (!isset($base_url))
		{
			// Make sure we are using the correct protocol
			$base_url = str_replace(array('http://', 'https://'), get_current_protocol().'://', $this->config['o_base_url']);
		}

		return $base_url;
	}

	//
	// Generate browser's title
	//
	function generate_page_title($page_title, $p = null)
	{
		if (!is_array($page_title))
			$page_title = array($page_title);

		$page_title = array_reverse($page_title);

		if ($p > 1)
			$page_title[0] .= ' ('.$this->lang->t('Page', $this->forum_number_format($p)).')';

		$crumbs = implode($this->lang->t('Title separator'), $page_title);

		return $crumbs;
	}

	function colourise_group($username, $gid, $user_id = 1)
	{
		static $colourise_cache = array();

		if (!isset($colourise_cache[$username]))
		{
			$name = $this->registry->get('\Aura\message\bbcode')->style_html('user_group_name', array($gid, aura_htmlspecialchars($username)));

			if ($this->user['g_view_users'] == 1 && $user_id > 1)
				$colourise_cache[$username] = $this->registry->get('\Aura\message\bbcode')->style_html('username_link', array($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['profile'], array($user_id, \Aura\url\url::replace($username))), $name));
			else
				$colourise_cache[$username] = $name;
		}

		return $colourise_cache[$username];
	}

	//
	// A wrapper for PHP's number_format function
	//
	function forum_number_format($number, $decimals = 0)
	{
		return is_numeric($number) ? number_format($number, $decimals, $this->lang->t('lang_decimal_point'), $this->lang->t('lang_thousands_sep')) : $number;
	}

	function file_size($size)
	{
		$units = array('B', 'KiB', 'MiB', 'GiB', 'TiB', 'PiB', 'EiB');

		for ($i = 0; $size > 1024; $i++)
			$size /= 1024;

		return $this->lang->t('Size unit '.$units[$i], round($size, 2));
	}

	//
	// Display executed queries (if enabled)
	//
	function display_saved_queries()
	{
		// Get the queries so that we can print them out
		$saved_queries = $this->db->get_saved_queries();

		$queries = array();
		$query_time_total = 0.0;
		foreach ($saved_queries as $cur_query)
		{
			$query_time_total += $cur_query[1];
			$queries[] = array(
				'sql' => $cur_query[0],
				'time' => $cur_query[1],
			);
		}

		$tpl = $this->template->load('debug.tpl');
		return $this->template->render($tpl,
			array(
				'query_time_total' => $query_time_total,
				'queries' => $queries,
			)
		);
	}
}