<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

namespace Aura\topics;
use AuraClass;

class delete_topic extends AuraClass
{
	//
	// Delete a topic and all of its posts
	//
	function delete_topic_comply($topic_id)
	{
		// Delete the topic and any redirect topics
		$this->registry->get('\Aura\topics\attachment')->attach_delete_thread($topic_id);
		$data = array(
			':id'	=>	$topic_id,
		);

		$topic = array(
			':id'	=>	$topic_id,
			':moved_to'	=>	$topic_id,
		);

		$update = array(
			'deleted'	=>	1,
		);

		$post_ids = array();
		$this->db->update('topics', $update, 'id=:id OR moved_to=:moved_to', $topic);
		$this->db->delete('polls', 'topic_id=:id', $data);

		// Get all post IDs from this topic.
		$markers = array();
		$ps = $this->db->select('posts', 'id', $data, 'topic_id=:id');
		foreach ($ps as $cur_post)
		{
			$post_ids[] = $cur_post['id'];
			$markers[] = '?';
		}

		// Make sure we have a list of post IDs
		if (!empty($post_ids))
		{
			$idx = $this->registry->get('\Aura\search\idx');
			$idx->strip_search_index($post_ids);
			$this->db->update('posts', $update, 'topic_id=:id', $data);

			$this->db->delete('reputation', 'post_id IN ('.implode(', ', $markers).')', $post_ids);
		}

		if ($this->config['o_delete_full'] == '1')
			$this->permanently_delete_topic($topic_id);
	}

	//
	// Permanently delete a topic
	//
	function permanently_delete_topic($id)
	{
		$data = array(
			':id'	=>	$id,
			':moved_to'	=>	$id,
		);

		$this->db->delete('topics', '(id=:id OR moved_to=:moved_to) AND deleted=1', $data);
		unset($data[':moved_to']);
		$this->db->delete('posts', 'topic_id=? AND deleted=1', array_values($data));

		// Delete any subscriptions for this topic
		$this->db->delete('topic_subscriptions', 'topic_id=?', array_values($data));
	}
}