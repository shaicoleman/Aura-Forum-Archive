<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
namespace Aura;

class styles
{
	protected static $style_root;
	protected static $style_path;
	protected static $default_style = 'aura';
	protected static $core_dir = 'core';
	protected static $user_style;
	public function __construct($registry)
	{
		$this->registry = $registry;
		$this->user = $registry->user;
		$this->config = $registry->config;
		$this->functions = $registry->functions;

		self::$style_root = (($this->config['o_style_dir']) != '' ? $this->config['o_style_dir'] : $this->functions->get_base_url().'/styles/');
		self::$style_path = (($this->config['o_style_path'] != 'styles') ? $this->config['o_style_path'] : AURA_ROOT.$this->config['o_style_path']);
	}

	public static function get_style_names()
	{
		static $names = array();

		$styles = self::get_styles_list();
		foreach ($styles as $style)
		{
			if (file_exists(self::$style_path.'/'.$style.'/config.txt'))
				$names[$style] = file_get_contents(self::$style_path.'/'.$style.'/config.txt');
			else
				$names[$style] = null;
		}

		return $names;
	}

	public static function get_styles_list()
	{
		static $list = null;

		if (!isset($list))
		{
			$list = array();
			foreach (glob(self::$style_path.'/*', GLOB_ONLYDIR) as $dir)
			{
				$dirs = explode('/', $dir);
				$style = end($dirs);

				if ($style != self::$core_dir)
					$list[] = $style;
			}
		}

		return $list;
	}

	public static function set_style($style)
	{
		if (self::style_exists($style))
			self::$user_style = $style;
		else
			self::$user_style = self::$default_style;
	}

	public static function get_default_style()
	{
		return self::$default_style;
	}

	public static function style_exists($style)
	{
		return in_array($style, self::get_styles_list());
	}

	public static function theme_exists($theme, $style)
	{
		return in_array($theme, self::get_themes_list($style));
	}

	public static function get_themes_list($style)
	{
		static $list = array();

		if (!isset($list[$style]))
		{
			$list[$style] = array();
			foreach (glob(self::$style_path.'/'.$style.'/themes/*.{css}', GLOB_BRACE) as $file)
			{
				$dirs = explode('/', $file);
				$list[$style][] = end($dirs);
			}
		}

		return $list[$style];
	}

	public static function get_custom_file($file)
	{
		if (file_exists(self::$style_path.'/'.self::$user_style.'/'.$file))
			return self::$style_root.self::$user_style.'/'.$file;
		else
			return self::$style_root.'core/'.$file;
	}

	public static function get_core_path()
	{
		return self::$style_root.self::$core_dir;
	}

	public static function get_style_path()
	{
		return self::$style_path;
	}

	public static function get_style_root()
	{
		return self::$style_root;
	}
}