<?php
namespace Aura\extensions;
use config;

// Main extensions manager
class manager
{
	protected static $extensions;
	public function __construct($registry)
	{
		$this->registry = $registry;
		$this->cache = $registry->cache;

		self::$extensions = $this->cache->get('extensions');
	}

	public function load_extensions()
	{
		foreach (self::$extensions as $id => $extension)
		{
			require config::EXTENSIONS_DIR.$extension.'/extension.php';

			$class = '\extensions\\'.$extension;
			$extension = new $class($this->registry);
			$extension->run();
		}
	}

	public function install($name)
	{
		$class = '\extensions\\'.$name;
		if (!class_exists($class))
			require config::EXTENSIONS_DIR.$name.'/extension.php';

		$extension = new $class($this->registry);
		$extension->install();
	}

	public function uninstall($name)
	{
		$class = '\extensions\\'.$name;

		$extension = new $class($this->registry);
		$extension->uninstall();
	}

	public function load_plugin($name)
	{
		require config::PLUGINS_DIR.$name.'.php';

		$class_name = '\Aura\extensions\\'.$name;
		if (!class_exists($class_name))
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Plugin failed message', $name));

		// Initiate the plugin
		$this->registry->get($class_name)->initiate();
	}
}