<?php
namespace Aura\extensions;

abstract class base_plugin implements \Aura\interfaces\plugin_interface
{
	final public function __construct($registry)
	{
		$this->registry = $registry;
		$this->user = $registry->user;
		$this->config = $registry->config;
		$this->cache = $registry->cache;
		$this->lang = $registry->lang;
		$this->db = $registry->db;
		$this->rewrite = $registry->rewrite;
		$this->template = $registry->template;
		$this->functions = $registry->functions;
		$this->manager = $registry->manager;
		$this->tasks = $registry->tasks;

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Admin'), str_replace('_', ' ', substr(get_class($this), strpos(get_class($this), '_') +1))),
			'active_page' => 'admin',
			'admin_console' => true,
		);

		$this->template->footer = array(
			'admin_console' => true,
		);
	}

	abstract function initiate();
}