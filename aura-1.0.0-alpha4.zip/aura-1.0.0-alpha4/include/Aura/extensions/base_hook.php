<?php
namespace Aura\extensions;

// Base Hook for extensions
abstract class base_hook
{
	final public function __construct($registry)
	{
		$this->registry = $registry;
	}

	abstract function fire($name);
	abstract function bind($name, $callable);
}

