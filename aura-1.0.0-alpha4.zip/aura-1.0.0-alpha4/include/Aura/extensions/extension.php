<?php
namespace Aura\extensions;

abstract class extension implements \Aura\interfaces\extension_interface
{
	final public function __construct($registry)
	{
		$this->registry = $registry;
		$this->user = $registry->user;
		$this->config = $registry->config;
		$this->cache = $registry->cache;
		$this->lang = $registry->lang;
		$this->db = $registry->db;
		$this->rewrite = $registry->rewrite;
		$this->template = $registry->template;
		$this->functions = $registry->functions;
		$this->manager = $registry->manager;
		$this->tasks = $registry->tasks;
	}

	abstract function run();
	abstract function install();
	abstract function uninstall();
}