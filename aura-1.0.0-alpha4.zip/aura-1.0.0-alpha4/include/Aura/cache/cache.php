<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
namespace Aura\cache;
use \Aura\lang;
use PDO;
use Exception;

// Make sure no one attempts to run this script "directly"
if (!defined('config::SESSION'))
	exit;

class cache implements \Aura\interfaces\cache_interface
{
	public $cache_dir = 'include/cache/';
	protected $prefix = 'cache_';
	protected $loaded_resources = array();
	public function __construct($registry)
	{
		if (defined('AURA_CACHE_DIR'))
			$this->cache_dir = AURA_CACHE_DIR;
		else
			$this->cache_dir = AURA_ROOT.$this->cache_dir;

		if (!is_readable($this->cache_dir))
			throw new Exception('Unable to read or find cache directory '.$this->cache_dir);

		$this->registry = $registry;
		$this->db = $registry->db;
		$this->template = $registry->template;
		$this->functions = $registry->functions;
		$this->rewrite = $registry->rewrite;
		$this->user = $registry->user;
	}

	//
	// Retrieve a cache file if it exists, if not attempt to write it
	//
	public function get($file, $args = array(), $generate = true, $language = false, $refresh = false)
	{
		// Make sure we don't load it twice
		if (in_array($file, $this->loaded_resources) && !$refresh)
			return;

		if ($file != 'language')
			$this->loaded_resources[] = $file;

		if (file_exists($this->cache_dir.$this->prefix.$file.'.php') && !$language)
			return require $this->cache_dir.$this->prefix.$file.'.php';
		else if (is_callable(array($this, $file)) && $generate)
		{
			if (!empty($args))
				$data = call_user_func_array(array($this, $file), $args);
			else
				$data = call_user_func(array($this, $file));

			if ($language)
				return $data;
			else
				return require $this->cache_dir.$this->prefix.$file.'.php';
		}
		else
			throw new Exception('Unable to load resource \''.$file.'\'!');
	}

	//
	// Wrapper method to refresh the cache but not return it
	//
	public function generate($file, $args = array(), $return = false)
	{
		$output = $this->get($file, $args, true, true, true);
		if ($return)
			return $output;
	}

	//
	// Delete every .php file in the forum's cache directory
	//
	public function clear()
	{
		$files = array_diff(scandir($this->cache_dir), array('.', '..'));
		foreach ($files as $file)
		{
			if (substr($file, -4) == '.php')
				@unlink($this->cache_dir.$file);
		}

		delete_directory($this->cache_dir.'/templates');
		delete_directory($this->cache_dir.'/languages');
	}

	//
	// Delete specific cache
	//
	public function delete($file)
	{
		$file = $this->cache_dir.$this->prefix.$file.'.php';
		if (file_exists($file))
			unlink($file);

		$this->invalidate($file);
	}

	//
	// Check if a specific cache file exists
	//
	public function exists($file)
	{
		return file_exists($this->cache_dir.$this->prefix.$file.'.php') ? true : false;
	}

	//
	// Delete all feed caches
	//
	public function clear_feeds()
	{
		$files = array_diff(scandir($this->cache_dir), array('.', '..'));
		foreach ($files as $file)
		{
			if (substr($file, 0, 10) == $this->prefix.'feed' && substr($file, -4) == '.php')
			{
				unlink($this->cache_dir.$file);
				$this->invalidate($this->cache_dir.$file);
			}
		}
	}

	//
	// Safely write out a cache file.
	//
	protected function write($file, $content)
	{
		$fh = @fopen($this->cache_dir.$file, 'wb');
		if (!$fh)
			throw new Exception('Unable to write cache file '.$file.' to cache directory. Please make sure PHP has write access to the directory \''.$this->cache_dir.'\'');

		flock($fh, LOCK_EX);
		ftruncate($fh, 0);

		fwrite($fh, '<?php'."\n\n".'if (!defined(\'config::SESSION\'))'."\n\t".'exit;'."\n\n".$content."\n");

		flock($fh, LOCK_UN);
		fclose($fh);

		$this->invalidate($this->cache_dir.$file);
	}

	//
	// Invalidate updated php files that are cached by an opcache
	//
	protected function invalidate($file)
	{
		if (function_exists('opcache_invalidate'))
			opcache_invalidate($file, true);
		else if (function_exists('apc_delete_file'))
			@apc_delete_file($file);		
	}

	//
	// Generate a custom cache
	//
	public function custom($name, $data)
	{
		$content = 'return '.var_export($data, true).';';
		$this->write($this->prefix.$name, $content);
	}

	//
	// Generate the config cache PHP script
	//
	private function config($aura_config)
	{
		$style = '';
		$ps = $this->db->select('groups', 'g_id, g_colour, g_global_moderator', array(), '', 'g_id ASC');
		$group_style = array();
		foreach ($ps as $cur_group)
		{
			$group_style = array();
			if (!empty($cur_group['g_colour']))
				$group_style[] = $this->registry->get('\Aura\message\bbcode')->style_html('group_colour', array($cur_group['g_colour']));

				// Any group except default user group
			if ($cur_group['g_id'] != $aura_config['o_default_user_group'])
				$group_style[] = $this->registry->get('\Aura\message\bbcode')->style_html('members_css');

				// Global moderators and admins should be italic
			if ($cur_group['g_global_moderator'] == '1' || $cur_group['g_id'] == AURA_ADMIN)
				$group_style[] = $this->registry->get('\Aura\message\bbcode')->style_html('global_permissions_css');

			if (!empty($group_style))
				$style .= $this->registry->get('\Aura\message\bbcode')->style_html('group_style', array($cur_group['g_id'], implode('; ', $group_style)));
		}

		$update = array(
			'conf_value' => $style,
		);

		$this->db->update('config', $update, "conf_name = 'o_colourise_groups'");

		$output = array();
		$ps = $this->db->select('config');
		foreach ($ps as $cur_item)
			$output[$cur_item['conf_name']] = $cur_item['conf_value'];

		// Output config as PHP code
		$content = 'return '.var_export($output, true).';';
		$this->write($this->prefix.'config.php', $content);
	}

	//
	// Generate the groups cache PHP script
	//
	private function groups()
	{
		$output = '$groups = array();'."\n\n";
		$ps = $this->db->select('groups', '*', array(), '', 'g_id ASC');
		foreach ($ps as $cur_group)
			$output .= '$groups[\''.$cur_group['g_id'].'\'] = '.var_export($cur_group, true).';'."\n\n";

		$output .= 'return $groups;';
		$this->write($this->prefix.'groups.php', $output);
	}

	//
	// Generate the bans cache PHP script
	//
	private function bans()
	{
		$output = array();
		$ps = $this->db->select('bans');
		foreach ($ps as $cur_ban)
			$output[] = $cur_ban;

		// Output ban list as PHP code
		$content = 'return '.var_export($output, true).';';
		$this->write($this->prefix.'bans.php', $content);
	}

	//
	// Generate the ranks cache PHP script
	//
	private function ranks()
	{
		$output = array();
		$ps = $this->db->select('ranks', 'id, rank, min_posts', array(), '', 'min_posts');
		foreach ($ps as $cur_rank)
			$output[] = $cur_rank;

		$output = 'return '.var_export($output, true).';';
		$this->write($this->prefix.'ranks.php', $output);
	}

	//
	// Generate the robot questions cache PHP script
	//
	private function robots()
	{
		$output = array();
		$ps = $this->db->select('robots', 'id, question, answer', array(), '', 'id');
		foreach ($ps as $cur_test)
			$output[$cur_test['id']] = $cur_test;

		$output = 'return '.var_export($output, true).';';
		$this->write($this->prefix.'robots.php', $output);
	}

	//
	// Generate forum cache script
	//
	private function forums()
	{
		$output = '$forums = array();'."\n";
		$ps = $this->db->select('forums');
		foreach ($ps as $cur_forum)
			$output .= '$forums[\''.$cur_forum['id'].'\'] = '.var_export($cur_forum, true).';'."\n\n";

		$output .= 'return $forums;';
		$this->write($this->prefix.'forums.php', $output);
	}

	//
	// Generate moderators cache script
	//
	private function moderators()
	{
		$output = '$moderators = array();'."\n";
		$ps = $this->db->select('moderators', 'forum_id, user_id, username, group_id, group_title', array(), 'forum_id>0 ORDER BY forum_id ASC');
		foreach ($ps as $cur_moderator)
			$output .= '$moderators[\''.$cur_moderator['forum_id'].'\'][\''.(($cur_moderator['user_id']) ? 'u'.$cur_moderator['user_id'] : 'g'.$cur_moderator['group_id']).'\'] = '.var_export($cur_moderator, true).';'."\n\n";

		$output .= 'return $moderators;';
		$this->write($this->prefix.'moderators.php', $output);
	}

	//
	// Generate quick jump cache PHP scripts
	//
	private function quickjump($group_id = false, $read_board = 1)
	{
		$aura_groups = array();
		$ps = $this->db->select('groups');
		foreach ($ps as $cur_group)
			$aura_groups[$cur_group['g_id']] = $cur_group;

		$groups = array();
		$base_url = $this->functions->get_base_url();
		// If a group_id was supplied, we generate the quick jump cache for that group only
		if ($group_id !== false)
			$groups[$group_id] = isset($aura_groups[$group_id]['g_read_board']) ? $aura_groups[$group_id]['g_read_board'] : $read_board;
		else
		{
			// A group_id was not supplied, so we generate the quick jump cache for all groups
			foreach ($aura_groups as $cur_group)
				$groups[$cur_group['g_id']] = $cur_group['g_read_board'];
		}

		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'forums',
				'as' => 'f',
				'on' => 'c.id=f.cat_id',
			),
			array(
				'type' => 'LEFT',
				'table' => 'forum_perms',
				'as' => 'fp',
				'on' => '(fp.forum_id=f.id AND fp.group_id=:id)',
			),
		);

		// Loop through the groups in $groups and output the cache for each of them
		foreach ($groups as $group_id => $read_board)
		{
			// Output quickjump as PHP code
			$output = '$forum_id = isset($this->data[\'forum_id\']) ? $this->data[\'forum_id\'] : 0;'."\n\n".'?>';
			if ($read_board == '1')
			{
				$data = array(
					':id' => $group_id,
				);

				$categories = $forums = array();
				$ps = $this->db->join('categories', 'c', $join, 'c.id AS cid, c.cat_name, f.id AS fid, f.forum_name, f.redirect_url, f.parent_forum', $data, 'f.quickjump=1 AND (fp.read_forum IS NULL OR fp.read_forum=1)', 'c.disp_position, c.id, f.disp_position');
				if ($ps->rowCount())
				{
					$tpl = $this->template->load('quickjump.tpl');
					foreach ($ps as $cur_forum)
					{
						if (!isset($categories[$cur_forum['cid']]))
							$categories[$cur_forum['cid']] = array(
								'id' => $cur_forum['cid'],
								'name' => $cur_forum['cat_name'],
							);

						$forums[] = array(
							'id' => $cur_forum['fid'],
							'category_id' => $cur_forum['cid'],
							'name' => $cur_forum['forum_name'],
							'redirect_url' => $cur_forum['redirect_url'],
							'parent_forum' => $cur_forum['parent_forum'],
							'url' => \Aura\url\url::replace($cur_forum['forum_name']),
						);
					}

					$output .= $this->template->render($tpl,
						array(
							'base_url' => $base_url,
							'categories' => $categories,
							'forums' => $forums,
							'forum_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['forum'], array("'+this.options[this.selectedIndex].value)+'", '\'+this.options[this.selectedIndex].getAttribute(\'data-name\')+\'')),
						)
					);
				}
			}

			$this->write('templates/'.$this->user['style'].'/'.$this->prefix.'quickjump_'.$group_id.'.php', $output);
		}

		return $output;
	}

	//
	// Generate the smilies cache PHP script
	//
	private function smilies()
	{
		$smilies = array();
		$ps = $this->db->select('smilies', 'image, code', array(), '', 'disp_position');
		foreach ($ps as $smiley)
			$smilies[$smiley['code']] = $smiley['image'];

		$content = 'return '.var_export($smilies, true).';';
		$this->write($this->prefix.'smilies.php', $content);
	}

	//
	// Generate the censoring cache PHP script
	//
	private function censoring()
	{
		$ps = $this->db->select('censoring', 'search_for, replace_with');
		$num_words = $ps->rowCount();

		$search_for = $replace_with = array();
		for ($i = 0; $i < $num_words; $i++)
		{
			list($search_for[$i], $replace_with[$i]) = $ps->fetch(PDO::FETCH_NUM);
			$search_for[$i] = '%(?<=[^\p{L}\p{N}])('.str_replace('\*', '[\p{L}\p{N}]*?', preg_quote($search_for[$i], '%')).')(?=[^\p{L}\p{N}])%iu';
		}

		// Output censored words as PHP code
		$content = '$search_for = '.var_export($search_for, true).';'."\n\n".'$replace_with = '.var_export($replace_with, true).';'."\n\n".'return array($search_for, $replace_with);';
		$this->write($this->prefix.'censoring.php', $content);
	}

	//
	// Generate the stopwords cache PHP script
	//
	private function stopwords()
	{
		$stopwords = \Aura\lang::get_language_stopwords();

		// Tidy up and filter the stopwords
		$stopwords = array_map('utf8_trim', $stopwords);
		$stopwords = array_filter($stopwords);

		// Output stopwords as PHP code
		$content = '$cache_id = \''.$this->registry->get('\Aura\cache\stopwords')->generate_stopwords_cache_id().'\';'."\n".'if ($cache_id != $this->registry->get(\'\Aura\cache\stopwords\')->generate_stopwords_cache_id()) return false;'."\n\n".'return '.var_export($stopwords, true).';';
		$this->write($this->prefix.'stopwords.php', $content);
	}

	//
	// Load some information about the latest registered users
	//
	private function stats()
	{
		$stats = array();
		$data = array(
			':id' => AURA_UNVERIFIED,
		);

		$ps = $this->db->select('users', 'COUNT(id)-1', $data, 'group_id!=:id');
		$stats['total_users'] = $ps->fetchColumn();

		$ps = $this->db->select('users', 'id, username, group_id', $data, 'group_id!=:id', 'registered DESC LIMIT 1');
		$stats['last_user'] = $ps->fetch();

		// Output users info as PHP code
		$content = 'return '.var_export($stats, true).';';
		$this->write($this->prefix.'stats.php', $content);
	}

	//
	// Generate the announcement cache (forum view)
	//
	private function announcements()
	{
		$output = array();
		$ps = $this->db->select('forums', 'id', array(), 'redirect_url IS NULL', 'disp_position');
		$ps->setFetchMode(PDO::FETCH_COLUMN, 0);
		foreach ($ps as $cur_fid)
		{
			// One forum can have many announcements
			if (!isset($output[$cur_fid]))
				$output[$cur_fid] = array();

			$ps1 = $this->db->select('announcements', 'subject, id, forum_id, user_id, message', array(), '', 'id DESC');
			if (!$ps1->rowCount())
				continue;

			foreach ($ps1 as $cur_announce)
			{
				$forums = explode(',', $cur_announce['forum_id']);
				if (in_array($cur_fid, $forums) || in_array(0, $forums))
				{
					// Cache the preg_replace now to avoid it from eating up valuable time when displaying the forum
					$cur_announce['url_subject'] = \Aura\url\url::replace($cur_announce['subject']);
					$output[$cur_fid][] = $cur_announce;
				}
			}
		}

		$content = 'return '.var_export($output, true).';';
		$this->write($this->prefix.'announcements.php', $content);
	}

	//
	// Generate the admins cache PHP script
	//
	private function admins()
	{
		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'groups',
				'as' => 'g',
				'on' => 'u.group_id=g.g_id',
			),
		);

		$data = array(
			':id' => AURA_ADMIN,
		);

		$output = array();
		$ps = $this->db->join('users', 'u', $join, 'id', $data, 'u.group_id=:id OR g.g_admin=1');
		foreach ($ps as $cur_admin)
			$output[] = $cur_admin['id'];

		// Output admin list as PHP code
		$content = 'return '.var_export($output, true).';';
		$this->write($this->prefix.'admins.php', $content);
	}

	//
	// Generate forum permissions cache script
	//
	private function perms()
	{
		$groups = array();
		$output = '$perms = array();'."\n\n";

		$join = array(
			array(
				'type' => 'LEFT',
				'table' => 'forum_perms',
				'as' => 'fp',
				'on' => 'g.g_id=fp.group_id',
			),
		);

		// Generate the permission cache for all groups
		$ps = $this->db->join('groups', 'g', $join, 'g.g_read_board, fp.group_id, fp.forum_id, fp.read_forum, fp.post_replies, fp.post_topics', array(), '', 'fp.group_id ASC');
		foreach ($ps as $cur_group)
		{
			$groups = array(
				'read_board' => $cur_group['g_read_board'],
				'forum_id' => $cur_group['forum_id'],
				'read_forum' => $cur_group['read_forum'],
				'post_replies' => $cur_group['post_replies'],
				'post_topics' => $cur_group['post_topics']
			);

			$output .= '$perms[\''.$cur_group['group_id'].'_'.$cur_group['forum_id'].'\'] = '.var_export($groups, true).';'."\n\n";
		}

		$output .= 'return $perms;';
		$this->write($this->prefix.'perms.php', $output);
	}

	//
	// Generate admin restrictions cache script
	//
	private function restrictions()
	{
		$output = '$admins = array();'."\n\n";
		$data = array(
			':id' => AURA_ADMIN,
		);

		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'restrictions',
				'as' => 'a',
				'on' => 'u.id=a.admin_id',
			),
			array(
				'type' => 'INNER',
				'table' => 'groups',
				'as' => 'g',
				'on' => 'u.group_id=g.g_id',
			),
		);

		$ps = $this->db->join('users', 'u', $join, 'u.id, a.restrictions', $data, '(u.group_id=:id OR g.g_admin=1)AND u.id!=2', 'u.id ASC');
		foreach ($ps as $cur_admin)
			$output .= '$admins[\''.$cur_admin['id'].'\'] = '.var_export(unserialize($cur_admin['restrictions']), true).';'."\n\n";

		$output .= 'return $admins;'."\n\n";
		$this->write($this->prefix.'restrictions.php', $output);
	}

	//
	// Check for updates to the forum
	//
	private function updates($lang, $view_message = false)
	{
		$output = utf8_trim(@file_get_contents('https://www.get-aura.org/api?module=updates&act=core'));
		if (empty($output) && $view_message)
			$this->registry->get('\Aura\handlers\message')->show($lang->t('Upgrade check failed message'));
		else if (empty($output))
			$failed = true;
		else
			$failed = false;

		// Decode the response and set it as the new cache
		$output = json_decode($output, true);
		$output['cached'] = CURRENT_TIMESTAMP;
		$output['failed'] = $failed;

		ksort($output);
		$content = 'return '.var_export($output, true).';';
		$this->write($this->prefix.'updates.php', $content);

		return $output;
	}

	//
	// Lock the forum during upgrades
	//
	private function upgrade_lock($timeout = 900)
	{
		$content = 'return '.(CURRENT_TIMESTAMP + $timeout).';';
		$this->write($this->prefix.'upgrade_lock.php', $content);
	}

	//
	// Generate the tasks cache
	//
	private function tasks()
	{
		$output = '$tasks = array();'."\n";
		$ps = $this->db->select('tasks');
		foreach ($ps as $cur_task)
			$output .= '$tasks['.$cur_task['id'].'] = '.var_export($cur_task, true).';'."\n\n";

		$output .= 'return $tasks;';
		$this->write($this->prefix.'tasks.php', $output);
	}

	//
	// Generate the tasks cache
	//
	private function extensions()
	{
		$output = '$extensions = array();'."\n\n";
		$ps = $this->db->select('extensions', 'id, unique_name', array(), 'enabled=1'); // If it's not even enabled, then why even attempt to run it and add extra work?
		foreach ($ps as $cur_extension)
			$output .= '$extensions[\''.$cur_extension['id'].'\'] = \''.addslashes($cur_extension['unique_name']).'\';'."\n\n";

		$output .= 'return $extensions;';
		$this->write($this->prefix.'extensions.php', $output);	
	}

	//
	// Generate the language locale cache
	//
	private function locales()
	{
		$output = '$locales = array();'."\n";
		$locales = lang::get_language_locales();
		foreach ($locales as $language => $locale)
			$output .= '$locales[\''.addslashes($language).'\'] = \''.addslashes($locale).'\';'."\n\n";

		$output .= 'return $locales;';
		$this->write($this->prefix.'locales.php', $output);
	}

	//
	// Generate the config cache for styles (parts of HTML which can't be separated into templates because they're too small)
	//
	private function style($aura_config, $aura_user)
	{
		$style_root = (($aura_config['o_style_path'] != 'styles') ? $aura_config['o_style_path'] : AURA_ROOT.$aura_config['o_style_path']).'/'.$aura_user['style'].'/';
		if (file_exists($this->cache_dir.'/templates/'.$aura_user['style'].'/'.$this->prefix.'style.php'))
			return require $this->cache_dir.'/templates/'.$aura_user['style'].'/'.$this->prefix.'style.php';
		else if (file_exists($this->cache_dir.'/'.$this->prefix.'style.php') && !file_exists($style_root.'config.xml'))
			return require $this->cache_dir.'/'.$this->prefix.'style.php';
		else
		{
			$file_exists = false;
			if (file_exists($style_root.'config.xml')) // Only if it exists for this file
			{
				$file_exists = true;
				$file = $style_root.'config.xml';
			}
			else // Fallback on the default
				$file = AURA_ROOT.'include/styles.xml';

			$parser = new \Aura\xml\parser;
			$parser->load($file);
			$style = $parser->fetch_array();

			$config = array();
			foreach ($style['style'] as $name => $item)
			{
				if ($name == 'data' || $name == '#comment')
					continue;

				$config[$name] = isset($item['data']) ? utf8_trim($item['data']) : '';
			}

			$output = '$style = array();'."\n\n";
			foreach ($config as $name => $item)
				$output .= '$style[\''.addslashes($name).'\'] = \''.str_replace("'", "\\'", $item).'\';'."\n";

			$output .= "\n".'return $style;';

			$path = ($file_exists) ? 'templates/'.$aura_user['style'].'/' : '';
			$this->write($path.$this->prefix.'style.php', $output);

			return require $this->cache_dir.'/'.$path.$this->prefix.'style.php';
		}
	}

	//
	// Generate a language file cache
	//
	private function language($language, $filename, $path)
	{
		if (!file_exists($this->cache_dir.'/languages/'.$language.'/'.$filename.'.php'))
		{
			if (!forum_is_writable($this->cache_dir))
				throw new Exception('The directory '.$this->cache_dir.' is not writable');

			// We need to make sure these folders actually exist first ...
			if (!file_exists($this->cache_dir.'/languages'))
				mkdir($this->cache_dir.'/languages');

			if (!file_exists($this->cache_dir.'/languages/'.$language))
				mkdir($this->cache_dir.'/languages/'.$language);

			$trans_cache = array();
			$content = file_get_contents($path.'/'.$language.'/'.$filename.'.po');

			// Remove header information, unescape quotes .etc
			$content = substr($content, strpos($content, "\n\n"));
			$content = str_replace('\"', '"', $content);
			preg_match_all('/msgid\s+"(.+?)"\s*(msgid_plural\s+"(.+?)"\s*)?((msgstr(\[\d+\])?\s+?"(.+?)"\s*)+)/is', $content, $locale_matches, PREG_SET_ORDER);
			foreach ($locale_matches as $locale_match)
			{
				if (strpos($locale_match[2], 'msgid_plural') !== false)
				{
					$plurals = array();
					preg_match_all('/msgid\s+"(.+?)"\s*(msgid_plural\s+"(.+?)"\s*)?((msgstr(\[\d+\])?\s+?"(.+?)"\s*)+)(#|msg)/is', $locale_match[4], $plural_matches, PREG_SET_ORDER);
					foreach ($plural_matches as $plural_match)
						$plurals[] = str_replace("\"\n\"", '', $plural_match[2]);

					$trans_cache[$locale_match[1]] = $plurals;
				}
				else
					$trans_cache[$locale_match[1]] = str_replace("\"\n\"", '', $locale_match[7]);
			}

			$output = 'return '.var_export($trans_cache, true).';';
			$this->write('/languages/'.$language.'/'.$filename.'.php', $output);

			return $trans_cache;
		}

		return require $this->cache_dir.'/languages/'.$language.'/'.$filename.'.php';
	}
}