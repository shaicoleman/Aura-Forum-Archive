<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

namespace Aura\cache;
use Aura\lang;

class stopwords
{
	//
	// Generate a cache ID based on the last modification time for all stopwords files
	//
	function generate_stopwords_cache_id()
	{
		$files = \Aura\lang::get_language_stopwords();
		if ($files === false)
			return 'cache_id_error';

		$hash = array();
		foreach ($files as $file)
		{
			$hash[] = $file;
			$hash[] = filemtime($file);
		}

		return aura_hash(implode('|', $hash));
	}
}