<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

namespace Aura;
use AuraClass;

if (!defined('config::SESSION'))
	exit;

class avatar extends AuraClass
{
	protected $gravatar_url = 'https://www.gravatar.com/avatar.php?gravatar_id=%s&amp;size=%s';

	//
	// Deletes any avatars owned by the specified user ID
	//
	public function delete_avatar($user_id)
	{
		$filetypes = array('jpg', 'gif', 'png');
		$avatar_path = ($this->config['o_avatars_dir'] != '') ? $this->config['o_avatars_path'] : AURA_ROOT.$this->config['o_avatars_path'];

		// Delete user avatar
		foreach ($filetypes as $cur_type)
		{
			if (file_exists($avatar_path.$user_id.'.'.$cur_type))
				@unlink($avatar_path.$user_id.'.'.$cur_type);
		}
	}

	//
	// Outputs markup to display a user's avatar
	//
	public function generate($user_id, $user_email, $use_gravatar = 0, $size = array())
	{
		static $user_avatar_cache = array();

		if (!isset($user_avatar_cache[$user_id]))
		{
			$avatar_path = ($this->config['o_avatars_dir'] != '') ? $this->config['o_avatars_path'] : AURA_ROOT.$this->config['o_avatars_path'];
			$avatar_dir = ($this->config['o_avatars_dir'] != '') ? $this->config['o_avatars_dir'] : $this->functions->get_base_url().'/'.$this->config['o_avatars_path'];

			if ($use_gravatar == 1)
			{
				$params = count($size) == 2 ? array($size[0], $size[1]) : array($this->config['o_avatars_width'], $this->config['o_avatars_height']);
				$avatar = array(sprintf($this->gravatar_url, md5(strtolower($user_email)), $params[0]), $params[0], $params[1], '');
			}
			else if ($this->config['o_avatar_upload'] == '1')
			{
				$filetypes = array('jpg', 'gif', 'png');
				foreach ($filetypes as $cur_type)
				{
					$path = $avatar_path.$user_id.'.'.$cur_type;
					$url = $avatar_dir.$user_id.'.'.$cur_type;
					if (file_exists($path) && $img_size = getimagesize($path))
					{
						$size = count($size) == 2 ? array($size[0], $size[1]) : array($img_size[0], $img_size[1]);
						$avatar = array($url.'?m='.filemtime($path), $size[0], $size[1], '');
						break;
					}
				}
			}

			// If there's no avatar set, we mustn't have one uploaded. Set the default!
			if (!isset($avatar))
			{
				$path = $avatar_path.'1.'.$this->config['o_avatar'];
				$url = $avatar_dir.'1.'.$this->config['o_avatar'];
				$img_size = getimagesize($path);

				$size = count($size) == 2 ? array($size[0], $size[1]) : array($img_size[0], $img_size[1]);
				$avatar = array($url.'?m='.filemtime($path), $size[0], $size[1], '');
			}

			$user_avatar_cache[$user_id] = $this->registry->get('\Aura\message\bbcode')->style_html('avatar_string', $avatar);
		}

		return $user_avatar_cache[$user_id];
	}
}