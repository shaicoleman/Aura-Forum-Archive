<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher

-----------------------------------------------------------------------------

  INSTRUCTIONS

  This script is used to include information about your board from
  pages outside the forums and to syndicate news about recent
  discussions via RSS/Atom/XML. The script displays a list of topics
  in a forum, or posts from a single topic.

  The scripts behaviour is controlled via variables supplied in the
  URL to the script. The different variables are: show (how many items
  to display), fid (the ID or IDs of the forum(s) to poll for topics),
  nfid (the ID or IDs of forums that should be excluded), tid (the ID
  of the topic from which to display posts) and type (output as HTML or
  RSS). Possible/default values are:

	act:   rss - output as RSS 2.0
			atom - output as Atom 1.0
			xml - output as XML
			html - output as HTML (<li>'s)

	fid:    One or more forum IDs (comma-separated). If ignored,
			topics from all readable forums will be pulled.

	nfid:   One or more forum IDs (comma-separated) that are to be
			excluded, e.g. the ID of a test forum.

	tid:    A topic ID from which to show posts. If a tid is supplied,
			fid and nfid are ignored.

	show:   Any integer value between 1 and 50. The default is 15.

	order:  last_post - show topics ordered by when they were last
						posted in, giving information about the reply.
			posted - show topics ordered by when they were first
					 posted, giving information about the original post.

-----------------------------------------------------------------------------*/

namespace Aura;
use AuraClass;

class feed
{
	/**
	 * Construct a few variables
	 */
	public function __construct($registry)
	{
		$this->registry = $registry;
		$this->user = $registry->user;
		$this->lang = $registry->lang;
		$this->db = $registry->db;
		$this->config = $registry->config;
		$this->functions = $registry->functions;
		$this->cache = $registry->cache;
		$this->rewrite = $registry->rewrite;

		// If we're a guest and we've sent a username/pass, we can try to authenticate using those details
		if ($this->user['is_guest'] && isset($_SERVER['PHP_AUTH_USER']))
			$this->authenticate_user($_SERVER['PHP_AUTH_USER'], $_SERVER['PHP_AUTH_PW']);

		if ($this->user['g_read_board'] == '0')
		{
			$this->http_authenticate_user();
			exit($this->lang->t('No view'));
		}
	}

	/**
	 * Attempt to authenticate the user
	 */
	protected function authenticate_user($user, $password, $password_is_hash = false)
	{
		$field = (is_int($user) ? 'u.id' : 'u.username');

		$ps = $this->db->run('SELECT u.*, g.*, o.logged, o.idle FROM '.$this->db->prefix.'users AS u INNER JOIN '.$this->db->prefix.'groups AS g ON g.g_id=u.group_id LEFT JOIN '.$this->db->prefix.'online AS o ON o.user_id=u.id WHERE '.$field.'=?', array($user));
		// Check if there's a user matching $user and $password
		$this->user = $ps->fetch();

		if (!isset($this->user['id']) ||
			($password_is_hash && !aura_hash_equals($password, $this->user['password'])) ||
			(!$password_is_hash && !aura_hash_equals($password, $this->user['password'])))
			$this->functions->set_default_user();
		else
			$this->user['is_guest'] = false;
	}
 
	/**
	 * Sends the proper headers for Basic HTTP Authentication
	 */
	protected function http_authenticate_user()
	{
		if (!$this->user['is_guest'])
			return;

		header('WWW-Authenticate: Basic realm="'.$this->config['o_board_title'].' External Syndication"');
		header('HTTP/1.0 401 Unauthorized');
	}

	/**
	 * Fetch the feed for a single topic ID
	 */
	protected function fetch_topic_feed($tid, $show)
	{
		// Fetch topic subject
		$data = array(
			':gid'	=>	$this->user['g_id'],
			':tid'	=>	$tid,
		);

		$ps = $this->db->run('SELECT t.subject, t.first_post_id, t.forum_id FROM '.$this->db->prefix.'topics AS t LEFT JOIN '.$this->db->prefix.'forum_perms AS fp ON (fp.forum_id=t.forum_id AND fp.group_id=:gid) WHERE (fp.read_forum IS NULL OR fp.read_forum=1) AND t.moved_to IS NULL AND t.id=:tid', $data);
		if (!$ps->rowCount())
		{
			$this->http_authenticate_user();
			exit($this->lang->t('Bad request'));
		}

		$cur_topic = $ps->fetch();
		if (!isset($this->forums[$cur_topic['forum_id']]) || $this->forums[$cur_topic['forum_id']]['password'] != '' && $this->registry->get('\auth\cookie')->check_forum_login_cookie($cur_topic['forum_id'], $this->forums[$cur_topic['forum_id']]['password'], true) === false || $this->forums[$cur_topic['forum_id']]['protected'] == '1' && !$this->user['is_admmod'])
			exit($this->lang->t('Bad request'));

		if ($this->config['o_censoring'] == '1')
			$cur_topic['subject'] = $this->registry->get('\Aura\message\bbcode')->censor_words($cur_topic['subject']);

		// Setup the feed
		$feed = array(
			'title' 		=>	$this->config['o_board_title'].$this->lang->t('Title separator').$cur_topic['subject'],
			'link'			=>	aura_htmlspecialchars_decode($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['topic'], array($tid, \Aura\url\url::replace($cur_topic['subject'])))),
			'description'	=>	$this->lang->t('RSS description topic', $cur_topic['subject']),
			'items'			=>	array(),
			'type'			=>	'posts'
		);

		// Fetch $show posts
		$data = array(
			':tid'	=>	$tid,
		);

		$ps = $this->db->run('SELECT p.id, p.poster, p.message, p.hide_smilies, p.posted, p.poster_id, u.email_setting, u.email, p.poster_email FROM '.$this->db->prefix.'posts AS p INNER JOIN '.$this->db->prefix.'users AS u ON u.id=p.poster_id WHERE p.topic_id=:tid ORDER BY p.posted DESC LIMIT '.$show, $data);
		foreach ($ps as $cur_post)
		{
			$cur_post['message'] = $this->parser->parse_message($cur_post['message'], $cur_post['hide_smilies']);
			$item = array(
				'id'			=>	$cur_post['id'],
				'title'			=>	$cur_topic['first_post_id'] == $cur_post['id'] ? $cur_topic['subject'] : $this->lang->t('RSS reply').$cur_topic['subject'],
				'link'			=>	$this->registry->get('\links')->aura_link($this->rewrite->url['post'], array($cur_post['id'])),
				'description'		=>	$cur_post['message'],
				'author'		=>	array(
					'name'	=> $cur_post['poster'],
				),
				'pubdate'		=>	$cur_post['posted']
			);

			if ($cur_post['poster_id'] > 1)
			{
				if ($cur_post['email_setting'] == '0' && !$this->user['is_guest'])
					$item['author']['email'] = $cur_post['email'];

				$item['author']['uri'] = $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['profile'], array($cur_post['poster_id'], \Aura\url\url::replace($cur_post['poster'])));
			}
			else if ($cur_post['poster_email'] != '' && !$this->user['is_guest'])
				$item['author']['email'] = $cur_post['poster_email'];

			$feed['items'][] = $item;
		}

		return $feed;
	}

	/**
	 * Build the feed and take into account as many factors that are provided to us
	 */
	protected function build_feed($show)
	{
		$order_posted = isset($_GET['order']) && strtolower($_GET['order']) == 'posted';
		$forum_name = '';
		$forum_sql = '';

		// Were any forum IDs supplied?
		$select = array($this->user['g_id']);
		if (isset($_GET['fid']) && is_scalar($_GET['fid']) && $_GET['fid'] != '')
		{
			$fids = explode(',', utf8_trim($_GET['fid']));
			$fids = array_map('intval', $fids);

			$markers = array();
			if (!empty($fids))
			{
				for ($i = 0; $i < count($fids); $i++)
				{
					if (!isset($this->forums[$fids[$i]]))
					{
						$count = count($fids);
						unset($fids[$i]);
						if ($count == 1)
							exit($this->lang->t('Bad request'));
						else
							continue;
					}
					else if ($this->forums[$fids[$i]]['password'] != '' && $this->registry->get('\Aura\auth\cookie')->check_forum_login_cookie($fids[$i], $this->forums[$fids[$i]]['password'], true) === false || $this->forums[$fids[$i]]['protected'] == '1' && !$this->user['is_admmod'])
					{
						// Artificially set the query string for no view forums
						if (!isset($_GET['nfid']))
							$_GET['nfid'] = '';

						$_GET['nfid'] = (empty($_GET['nfid']) ? $fids[$i] : ','.$fids[$i]);
						continue;
					}

					$markers[] = '?';
					$select[] = $fids[$i];
				}

				if (!empty($markers))
					$forum_sql .= ' AND t.forum_id IN('.implode(',', $markers).')';
			}

			if (count($fids) == 1)
			{
				// Fetch forum name
				$data = array(
					':gid'	=>	$this->user['g_id'],
					':fid'	=>	$fids[0],
				);

				$ps = $this->db->run('SELECT f.forum_name FROM '.$this->db->prefix.'forums AS f LEFT JOIN '.$this->db->prefix.'forum_perms AS fp ON (fp.forum_id=f.id AND fp.group_id=:gid) WHERE (fp.read_forum IS NULL OR fp.read_forum=1) AND f.id=:fid', $data);
				if ($ps->rowCount())
					$forum_name = $this->lang->t('Title separator').$ps->fetchColumn();
			}
		}

		// Any forum IDs to exclude?
		$data = array();
		if (isset($_GET['nfid']) && is_scalar($_GET['nfid']) && $_GET['nfid'] != '')
		{
			$nfids = (strpos($_GET['nfid'], ',') !== false) ? explode(',', utf8_trim($_GET['nfid'])) : array($_GET['nfid']);
			$nfids = array_map('intval', $nfids);

			if (!empty($nfids))
			{
				$markers = array();
				for ($i = 0; $i < count($nfids); $i++)
				{
					$markers[] = '?';
					$data[] = $nfids[$i];
				}

				$forum_sql .= ' AND t.forum_id NOT IN('.implode(',', $markers).')';
			}
		}

		// Only attempt to cache if caching is enabled and we have all or a single forum
		if ($this->config['o_feed_ttl'] > 0 && ($forum_sql == '' || ($forum_name != '' && !isset($_GET['nfid']))))
			$cache_id = 'feed'.sha1($this->user['g_id'].'|'.$this->lang->t('lang_identifier').'|'.($order_posted ? '1' : '0').($forum_name == '' ? '' : '|'.$fids[0]));

		// Load cached feed
		if (isset($cache_id) && file_exists($cache->cache_dir.'cache_'.$cache_id.'.php'))
			include $cache->cache_dir.'cache_'.$cache_id.'.php';

		if (!isset($feed) || $cache_expire < CURRENT_TIMESTAMP)
		{
			// Setup the feed
			$feed = array(
				'title' 		=>	$this->config['o_board_title'].$forum_name,
				'link'			=>	$this->registry->get('\Aura\links')->aura_link($this->rewrite->url['index']),
				'description'	=>	$this->lang->t('RSS description', $this->config['o_board_title']),
				'items'			=>	array(),
				'type'			=>	'topics'
			);

			// Fetch $show topics
			$select = array_merge($select, $data);
			$ps = $this->db->run('SELECT t.id, t.poster, t.subject, t.forum_id, t.posted, t.last_post, t.last_poster, p.message, p.hide_smilies, u.email_setting, u.email, p.poster_id, p.poster_email FROM '.$this->db->prefix.'topics AS t INNER JOIN '.$this->db->prefix.'posts AS p ON p.id='.($order_posted ? 't.first_post_id' : 't.last_post_id').' INNER JOIN '.$this->db->prefix.'users AS u ON u.id=p.poster_id LEFT JOIN '.$this->db->prefix.'forum_perms AS fp ON (fp.forum_id=t.forum_id AND fp.group_id=?) WHERE (fp.read_forum IS NULL OR fp.read_forum=1) AND t.moved_to IS NULL'.$forum_sql.' ORDER BY '.($order_posted ? 't.posted' : 't.last_post').' DESC LIMIT '.(isset($cache_id) ? 50 : $show), $select);
			foreach ($ps as $cur_topic)
			{
				if ($this->forums[$cur_topic['forum_id']]['password'] != '' && $this->registry->get('\Aura\auth\cookie')->check_forum_login_cookie($cur_topic['forum_id'], $this->forums[$cur_topic['forum_id']]['password'], true) === false || $this->forums[$cur_topic['forum_id']]['protected'] == '1' && !$this->user['is_admmod'])
					continue;

				if ($this->config['o_censoring'] == '1')
					$cur_topic['subject'] = $this->registry->get('\Aura\message\bbcode')->censor_words($cur_topic['subject']);

				$cur_topic['message'] = $this->parser->parse_message($cur_topic['message'], $cur_topic['hide_smilies']);
				$item = array(
					'id'			=>	$cur_topic['id'],
					'title'			=>	$cur_topic['subject'],
					'link'			=>	aura_htmlspecialchars_decode($this->registry->get('\Aura\links')->aura_link($this->rewrite->url[(($order_posted) ? 'topic' : 'topic_new_posts')], array($cur_topic['id'], \Aura\url\url::replace($cur_topic['subject'])))),
					'description'	=>	$cur_topic['message'],
					'author'		=>	array(
						'name'	=> $order_posted ? $cur_topic['poster'] : $cur_topic['last_poster']
					),
					'pubdate'		=>	$order_posted ? $cur_topic['posted'] : $cur_topic['last_post']
				);

				if ($cur_topic['poster_id'] > 1)
				{
					if ($cur_topic['email_setting'] == '0' && !$this->user['is_guest'])
						$item['author']['email'] = $cur_topic['email'];

					$item['author']['uri'] = $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['profile'], array($cur_topic['poster_id'], \Aura\url\url::replace($cur_topic['poster'])));
				}
				else if ($cur_topic['poster_email'] != '' && !$this->user['is_guest'])
					$item['author']['email'] = $cur_topic['poster_email'];

				$feed['items'][] = $item;
			}

			// Output feed as PHP code
			if (isset($cache_id))
			{
				$content = '<?php'."\n\n".'$feed = '.var_export($feed, true).';'."\n\n".'$cache_expire = '.(CURRENT_TIMESTAMP + ($this->config['o_feed_ttl'] * 60)).';'."\n\n".'?>';
				$cache->write('cache_'.$cache_id.'.php', $content);
			}
		}

		// If we only want to show a few items but due to caching we have too many
		if (count($feed['items']) > $show)
			$feed['items'] = array_slice($feed['items'], 0, $show);

		// Prepend the current base URL onto some links. Done after caching to handle http/https correctly
		$feed['link'] = $feed['link'];

		foreach ($feed['items'] as $key => $item)
		{
			$feed['items'][$key]['link'] = aura_htmlspecialchars_decode($item['link']);

			if (isset($item['author']['uri']))
				$feed['items'][$key]['author']['uri'] = $item['author']['uri'];
		}

		return $feed;
	}

	/**
	 * Generate the feed and return the response to render
	 */
	public function generate_feed()
	{
		$this->parser = $this->registry->get('\Aura\message\parser');
		$show = isset($_GET['show']) ? intval($_GET['show']) : 15;
		if ($show < 1 || $show > 50)
			$show = 15;

		$this->forums = $this->cache->get('forums');

		// Was a topic ID supplied?
		if (isset($_GET['tid']))
		{
			$tid = intval($_GET['tid']);
			return $this->fetch_topic_feed($tid, $show);
		}
		else
			return $this->build_feed($show);
	}

	/**
	 * Escape CDATA
	 */
	public function escape_cdata($str)
	{
		return str_replace(']]>', ']]&gt;', $str);
	}
}