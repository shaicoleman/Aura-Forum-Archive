<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

namespace Aura\upgrade;
use lang;

class manual extends \Aura\upgrade\core_upgrader implements \Aura\interfaces\upgrader_interface
{
	public function run()
	{
		$uploaded_file = isset($_FILES['package']) ? $_FILES['package'] : array('error' => 0, 'size' => 0, 'name' => '', 'tmp_name' => '');

		// Make sure the upload went smooth
		if (isset($uploaded_file['error']))
		{
			switch ($uploaded_file['error'])
			{
				case 1: // UPLOAD_ERR_INI_SIZE
				case 2: // UPLOAD_ERR_FORM_SIZE
					return array('state' => false, 'attempted' => false, 'lang' => $this->lang->t('Too large ini'));
					break;

				case 3: // UPLOAD_ERR_PARTIAL
					return array('state' => false, 'attempted' => false, 'lang' => $this->lang->t('Partial upload'));
					break;

				case 4: // UPLOAD_ERR_NO_FILE
					return array('state' => false, 'attempted' => false, 'lang' => $this->lang->t('No file'));
					break;

				case 6: // UPLOAD_ERR_NO_TMP_DIR
					return array('state' => false, 'attempted' => false, 'lang' => $this->lang->t('No tmp directory'));
					break;

				default:
					// No error occured, but was something actually uploaded?
					if ($uploaded_file['size'] == 0)
						return array('state' => false, 'attempted' => false, 'lang' => $this->lang->t('No file'));
					break;
			}
		}

		if (is_dir($this->cache->cache_dir.$this->temporary_location))
			delete_directory($this->cache->cache_dir.$this->temporary_location);

		if (is_uploaded_file($uploaded_file['tmp_name']))
		{
			if (!@mkdir($this->cache->cache_dir.$this->temporary_location))
				return array('state' => false, 'attempted' => true, 'lang' => $this->lang->t('Upgrade folder creation failed', $this->cache->cache_dir.$this->temporary_location));

			// First get the updates
			$upgrade = $this->cache->get('updates', array($this->lang));
			$info = $this->db->get_version();

			if (substr($uploaded_file['name'], -4) !== '.zip')
				return array('state' => false, 'attempted' => false, 'lang' => $this->lang->t('Invalid package'));

			// Move the file to the updates directory
			if (!@move_uploaded_file($uploaded_file['tmp_name'], $this->cache->cache_dir.$this->temporary_location.DIRECTORY_SEPARATOR.$upgrade['package']))
				return array('state' => false, 'attempted' => false, 'lang' => $this->lang->t('Move failed', $this->config['o_admin_email']));

			@chmod($this->cache->cache_dir.$this->temporary_location.DIRECTORY_SEPARATOR.$uploaded_file['name'], $this->file_permissions);
			@set_time_limit(0);

			// We DO want to upgrade major versions, if we're doing it manually
			$this->upgrade_major = true;

			if (version_compare(PHP_VERSION, $upgrade['php_version'], '<'))
				return array('state' => false, 'attempted' => false, 'lang' => $this->lang->t('Discontinued PHP version', PHP_VERSION, $upgrade['version'], $upgrade['php_version']));
			else if (!in_array($info['name'], $upgrade['drivers']))
				return array('state' => false, 'attempted' => false, 'lang' => $this->lang->t('Discontinued database driver', $info['name'], $upgrade['version']));
			else if (!$this->should_upgrade($upgrade['version']))
				return array('state' => false, 'attempted' => false, 'lang' => $this->lang->t('No upgrade necessary', $upgrade['version']));

			// Has the default language been updated?
			if (!\Aura\lang::language_exists($upgrade['default_lang']))
				$this->update_language = true;

			// Lock the upgrader so we can continue
			if (!$this->lock_upgrader())
				return array('state' => false, 'attempted' => false, 'lang' => $this->lang->t('Upgrader locked'));

			$package = $this->download_package($this->cache->cache_dir.$upgrade['package']);
			if (!$package['state'])
			{
				$this->unlock_upgrader();
				return array('state' => false, 'attempted' => true, 'lang' => $package['lang']);
			}

			$package = $this->unarchive_package(realpath($this->cache->cache_dir.$this->temporary_location).DIRECTORY_SEPARATOR, $upgrade['package'], file_get_contents($this->cache->cache_dir.$this->temporary_location.DIRECTORY_SEPARATOR.$upgrade['package']), $upgrade['version']);
			if (!$package['state'])
			{
				$this->unlock_upgrader();
				return array('state' => false, 'attempted' => true, 'lang' => $package['lang']);
			}

			$package = $this->install_package($package['location'], AURA_ROOT, $upgrade['default_lang']);
			if (!$package['state'])
			{
				$this->unlock_upgrader();
				return array('state' => false, 'attempted' => true, 'lang' => $package['lang']);
			}

			// Finally, update the database
			if (!$this->update_database($upgrade['version'], $upgrade['default_lang']))
			{
				$this->unlock_upgrader();
				return array('state' => false, 'attempted' => true, 'lang' => $this->lang->t('Database upgrade failed'));
			}

			delete_directory($this->cache->cache_dir.$this->temporary_location);

			$this->unlock_upgrader();
			return array('state' => true, 'attempted' => true, 'lang' => $this->lang->t('Upgrade completed'));
		}
	}
}