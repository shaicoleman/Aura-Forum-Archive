<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

namespace Aura\upgrade;
use config;
use ZipArchive;
use Aura\styles;

class core_upgrader
{
	/**
	 * Whether to upgrade a minor release of the forum (e.g. 1.1.3 => 1.1.4)
	 */
	protected $upgrade_minor = true;

	/**
	 * Whether to upgrade major releases (e.g. 1.1.x => 1.2.x)
	 */
	protected $upgrade_major = false;

	/**
	 * Whether to upgrade a developer release
	 */
	protected $upgrade_developer = true;

	/**
	 * Whether the default language of the forum has changed
	 */
	protected $update_language = false;

	/**
	 * The amount of time the upgrader remains locked (in seconds) when used
	 */
	protected $lock_duration = 900;

	/**
	 * The location used to store upgrade packages
	 */
	protected $upgrade_location = 'include/upgrade/';

	/**
	 * The cache location used to store manually upgraded packages
	 */
	protected $temporary_location = 'upgrade';

	/**
	 * Whether to attempt to delete the package after unarchiving
	 */
	protected $delete_archive = true;

	/**
	 * Directory permissions
	 */
	protected $directory_permissions = 0755;

	/**
	 * File permissions
	 */
	protected $file_permissions = 0644;

	/**
	 * Default admin directory name
	 */
	protected $admin_directory = 'admin';

	/**
	 * Default install directory name
	 */
	protected $install_directory = 'install';

	/**
	 * Default styles directory name
	 */
	protected $styles_directory = 'styles';

	/**
	 * Default avatars directory
	 */
	protected $avatars_directory = 'assets/images/avatars/';

	/**
	 * Default avatars directory
	 */
	protected $group_directory = 'assets/images/group/';

	/**
	 * Default avatars directory
	 */
	protected $smilies_directory = 'assets/images/smilies';

	/**
	 * Constructor - initialise some objects
	 */
	final public function __construct($registry)
	{
		$this->registry = $registry;
		$this->config = $registry->config;
		$this->lang = $registry->lang;
		$this->cache = $registry->cache;
		$this->db = $registry->db;

		$this->lang->load('admin_update');
	}

	/**
	 * Fetches the branch of the release from the version (e.g. 1.1)
	 */
	protected static function fetch_branch($version)
	{
		return implode('.', array_slice(preg_split('/[.-]/', $version), 0, 2));
	}

	/**
	 * Checks to see whether the forum should be upgraded based on a particular version
	 */
	protected function should_upgrade($version)
	{
		$new_branch = self::fetch_branch($version);
		$current_branch = self::fetch_branch($this->config['o_cur_version']);
		$developer_release = (bool) strpos($this->config['o_cur_version'], '-');

		// If it's the same version, abort
		if ($this->config['o_cur_version'] == $version)
			return false;

		// If it's a previous version, that's a definite no
		if (version_compare($this->config['o_cur_version'], $version, '>'))
			return false;

		// Double check the version, and make sure it's not a previous branch
		if (version_compare($new_branch, $current_branch, '<'))
			return false;

		// Are we running a developer/alpha/beta release?
		if ($developer_release)
		{
			if ($this->upgrade_developer)
				return true;

			return false;
		}

		// If it's a minor upgrade
		if ($current_branch == $new_branch)
		{
			if ($this->upgrade_minor)
				return true;

			return false;
		}

		// Major upgrade - a new branch of the forum
		if (version_compare($new_branch, $current_branch, '>'))
		{
			if ($this->upgrade_major)
				return true;

			return false;
		}

		// And ... if for some reason we're still here, abort
		return false;
	}

	/**
	 * Enables/disables Maintenance mode of the forum
	 */
	protected function maintenance($type)
	{
		$update = array(
			'conf_value' => $type,
		);

		$data = array(
			':conf_name' => 'o_maintenance',
		);

		$this->db->update('config', $update, 'conf_name=:conf_name', $data);
	}

	/**
	 * Locks the upgrader so it cannot be used twice
	 */
	protected function lock_upgrader()
	{
		if ($this->cache->exists('upgrade_lock'))
		{
			// Grab the timeout and see if it expired
			$timeout = $this->cache->get('upgrade_lock');

			if ($timeout < CURRENT_TIMESTAMP)
			{
				$this->unlock_upgrader();
				return true;
			}

			return false;
		}

		if ($this->config['o_maintenance'] != '1')
		{
			$this->maintenance(1);
			$this->cache->generate('config', array($this->config));
		}

		$this->cache->generate('upgrade_lock', array($this->lock_duration));
		return true;
	}

	/**
	 * Unlocks the upgrader after completion or a problem occurs
	 */
	protected function unlock_upgrader()
	{
		$this->cache->delete('upgrade_lock');
		$this->maintenance(0);

		$this->cache->clear();
	}

	/**
	 * Attempts to download the upgrade package provided
	 */
	protected function download_package($package)
	{
		if (empty($package))
			return array('state' => false, 'lang' => $this->lang->t('No package provided'));

		// Maybe it's a local package?
		if (!preg_match('!^(http|https|ftp)://!i', $package) && file_exists($package))
			return array('state' => true, 'archive' => $package);

		// Try to use cURL if available
		if (is_callable('curl_init'))
		{
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $package);
			curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
			$downloaded_package = curl_exec($ch);
			curl_close($ch);
		}
		else if (function_exists('file_get_contents')) // Not preferred, but file_get_contents?
		{
			$downloaded_package = file_get_contents($package);
			if ($downloaded_package === false)
				return array('state' => false, 'lang' => $this->lang->t('Package download failed'));
		}
		else // If there is no availability for downloading remote files, just abort
			return array('state' => false, 'lang' => $this->lang->t('No download method exists'));

		return array('state' => true, 'archive' => $downloaded_package);
	}

	/**
	 * Attempts to unarchive the downloaded package
	 */
	protected function unarchive_package($upgrade_location, $package_name, $downloaded_package, $version)
	{
		$package = $upgrade_location.$package_name;

		// If the location already exists, delete it and re-create it
		delete_directory($upgrade_location);

		if (!@mkdir($upgrade_location, $this->file_permissions))
			return array('state' => false, 'lang' => $this->lang->t('Unable to make storage location', $upgrade_location));

		// Only it it doesn't already exist and we can't write it there
		if (!@file_put_contents($package, $downloaded_package))
			return array('state' => false, 'lang' => $this->lang->t('Unable to store upgrade', $package));

		// Now attempt to validate the checksum of the package
		if (function_exists('sha1_file'))
		{
			$type = 'sha1';
			$function = 'sha1_file';
		}
		else if (function_exists('md5_file')) // Fallback to MD5, if it exists
		{
			$type = 'md5';
			$function = 'md5_file';
		}
		else // Nothing else we can use, so abort
			return array('state' => false, 'lang' => $this->lang->t('Unable to use checksums'));

		$checksum = @file_get_contents('https://www.get-aura.org/api?module=core&act=checksum&id='.$version.'&hash='.$type);
		if ($checksum === false)
			return array('state' => false, 'lang' => $this->lang->t('Unable to retrieve checksum'));
		else if (!aura_hash_equals($checksum, $function($package)))
			return array('state' => false, 'lang' => $this->lang->t('Upgrade checksum invalid'));

		$package_name = basename($package, '.zip');
		if (class_exists('ZipArchive'))
		{
			$zip = new ZipArchive;
			if ($zip->open($package, ZIPARCHIVE::CHECKCONS))
			{
				$zip->extractTo($upgrade_location);
				$zip->close();
			}
			else
				return array('state' => false, 'lang' => $this->lang->t('Archive failure'));
		}
		else
			return array('state' => false, 'lang' => $this->lang->t('Unable to unarchive files'));

		if ($this->delete_archive)
		{
			if (!@unlink($package)) // If we can't delete it, this isn't a good sign, best to abort
				return array('state' => false, 'lang' => $this->lang->t('Unable to remove old archive'));
		}

		return array('state' => true, 'location' => $upgrade_location.$package_name);
	}

	/**
	 * Attempts to install the upgrade
	 */
	protected function install_package($source, $destination, $default_language)
	{
		$files = array_diff(scandir($source), array('.', '..'));
		if (empty($files))
			return array('state' => false, 'lang' => $this->lang->t('No files found'));

		if (!is_dir($destination))
		{
			if (!@mkdir($destination)) // We'd better abort if we can't create it
				return array('state' => false, 'lang' => $this->lang->t('Unable to create destination', $destination));
		}

		$result = $this->clear_destination($destination);
		if (!$result['state'])
			return array('state' => false, 'lang' => $result['lang']);

		// ... And copy the new
		$this->copy_dir($source, $destination);

		delete_directory($source);
		delete_directory(AURA_ROOT.$this->upgrade_location);
		delete_directory(AURA_ROOT.$this->install_directory); // Delete the new install directory

		// If the new admin directory is not named the default we need to rename it
		if (file_exists(AURA_ROOT.$this->admin_directory) && config::ADMIN_DIR !== $this->admin_directory)
		{
			if (!@rename(AURA_ROOT.$this->admin_directory, AURA_ROOT.config::ADMIN_DIR))
			{
				// If it failed, chmod it and try again
				@chmod($destination.DIRECTORY_SEPARATOR.$file, $this->file_permissions);
				if (!@rename(AURA_ROOT.$this->admin_directory, AURA_ROOT.config::ADMIN_DIR)) // And if we still can't, abort
					throw new Exception('Unable to rename directory \''.$this->admin_directory.'\' to '.config::ADMIN_DIR);
			}
		}

		// If we have a custom styles path, then we need to update the styles in there
		if ($this->config['o_style_path'] != $this->styles_directory)
		{
			$this->copy_dir(AURA_ROOT.$this->styles_directory, $this->config['o_style_path']);
			delete_directory(AURA_ROOT.$this->styles_directory);
		}

		// The default style has been removed
		if (!is_dir(\Aura\styles::get_style_root().DIRECTORY_SEPARATOR.$this->config['o_default_style']))
		{
			$styles = \Aura\styles::get_style_names();
			if (!empty($styles)) // No styles???
			{
				$update = array(
					'conf_value' => key($styles), // Go for the first available style
				);

				$data = array(
					':conf_name' => 'o_default_style',
				);

				$this->db->update('config', $update, 'conf_name=:conf_name', $data);
			}
		}

		// Update the avatars ...
		if ($this->config['o_avatars_path'] != $this->avatars_directory)
		{
			$this->copy_dir(AURA_ROOT.$this->avatars_directory, $this->config['o_avatars_path']);
			delete_directory(AURA_ROOT.$this->avatars_directory);
		}

		// Update the group images ...
		if ($this->config['o_image_group_path'] != $this->group_directory)
		{
			$this->copy_dir(AURA_ROOT.$this->group_directory, $this->config['o_image_group_path']);
			delete_directory(AURA_ROOT.$this->group_directory);
		}

		// Update the emoticons ...
		if ($this->config['o_smilies_path'] != $this->smilies_directory)
		{
			$this->copy_dir(AURA_ROOT.$this->smilies_directory, $this->config['o_smilies_path']);
			delete_directory(AURA_ROOT.$this->smilies_directory);
		}

		// If we want to update the new default language
		if ($this->update_language)
		{
			$update = array(
				'conf_value' => $default_language,
			);

			$data = array(
				':conf_name' => 'o_default_lang',
			);

			$this->db->update('config', $update, 'conf_name=:conf_name', $data);
		}

		return array('state' => true);
	}

	/**
	 * Attempts to clear the destination of the new version
	 */
	protected function clear_destination($location)
	{
		$unwritable = array();
		$destination_files = array_diff(scandir($location), array('.', '..'));
		foreach ($destination_files as $file)
		{
			if (!is_writable($location.$file)) // If it's not writable, chmod it and try again
			{
				$permission = (is_dir($location.$file)) ? $this->directory_permissions : $this->file_permissions;
				@chmod($location.$file, $permission);

				// If it's still not writable, we'd better keep a record of it
				if (!is_writable($location.$file))
					$unwritable[] = $location.$file;
			}
		}

		if (!empty($unwritable))
			return array('state' => false, 'lang' => $this->lang->t('Unwritable files', implode(', ', $unwritable)));

		// If we haven't used a custom cache directory
		if (!defined('AURA_CACHE_DIR'))
			$cache = 'include/cache';
		else
			$cache = basename($this->cache->cache_dir);

		// Here we check if both the default extensions and defualt plugins directories exist
		if (is_dir(AURA_ROOT.'include/extensions'))
			$extensions = 'include/extensions';
		else
			$extensions = basename(config::EXTENSIONS_DIR);

		if (is_dir(AURA_ROOT.'include/plugins'))
			$plugins = 'include/plugins';
		else
			$plugins = basename(config::PLUGINS_DIR);

		$skip_list = array(
			'.htaccess', // If we have URL rewriting enabled, better not lose all that
			basename($this->config['o_attachments_dir']),
			basename($this->config['o_style_path']),
			$extensions,
			$plugins,
			$cache,
			$this->upgrade_location, // We certainly don't want to remove the new version!
			'include/config.php',
			'include/tasks',
			$this->config['o_avatars_path'],
			$this->config['o_image_group_path'],
		);

		// Delete the old files
		self::delete_files($location, $skip_list);
		return array('state' => true);
	}

	/**
	 * Delete the files from the forum
	 */
	protected static function delete_files($destination, $skip_list = array())
	{
		$files = array_diff(scandir($destination), array('.', '..'));
		foreach ($files as $file)
		{
			if (in_array($file, $skip_list))
				continue;

			if (is_dir($destination.$file))
			{
				$sub_skip_list = array();
				foreach ($skip_list as $skip_file)
				{
					if (strpos($skip_file, $file.'/') === 0)
						$sub_skip_list[] = preg_replace('!^'.preg_quote($file, '!').'/!i', '', $skip_file);
				}

				self::delete_files($destination.$file.'/', $sub_skip_list);
			}
			else
				@unlink($destination.$file);
		}

		if (file_exists($destination) && is_dir($destination))
			@rmdir($destination);
	}

	/**
	 * Copy an entire directory to somewhere else
	 */
	protected function copy_dir($source, $destination)
	{
		$files = array_diff(scandir($source), array('.', '..'));
		foreach ($files as $file)
		{
			if (!is_dir($source.DIRECTORY_SEPARATOR.$file))
			{
				if (!@copy($source.DIRECTORY_SEPARATOR.$file, $destination.DIRECTORY_SEPARATOR.$file))
				{
					// If it failed, chmod the file and try again
					@chmod($destination.DIRECTORY_SEPARATOR.$file, $this->file_permissions);
					if (!@copy($source.DIRECTORY_SEPARATOR.$file, $destination.DIRECTORY_SEPARATOR.$file))
						throw new Exception('Unable to copy file '.$file.' when copying directory '.$source.' to '.$destination);
				}

				@chmod($destination.DIRECTORY_SEPARATOR.$file, $this->file_permissions); // Chmod it to prevent it being writable in the new location
			}
			else
			{
				if (!is_dir($destination.DIRECTORY_SEPARATOR.$file))
				{
					if (!@mkdir($destination.DIRECTORY_SEPARATOR.$file, $this->directory_permissions))
						throw new Exception('Unable to create directory '.$destination.$file);
				}

				$this->copy_dir($source.DIRECTORY_SEPARATOR.$file, $destination.DIRECTORY_SEPARATOR.$file);
			}
		}
	}

	/**
	 * Performs any database updates which are required for this new version
	 */
	protected function update_database($version, $language)
	{
		$update = array(
			'conf_value' => $version,
		);

		$data = array(
			':conf_name' => 'o_cur_version',
		);

		$this->db->update('config', $update, 'conf_name=:conf_name', $data);

		// If we've updated the language we need to change this
		if ($this->update_language)
		{
			$update = array(
				'language' => $language,
			);

			$this->db->update('users', $update); // First all users

			// And then the same for the default language
			$update = array(
				'conf_value' => $language,
			);

			$data = array(
				':conf_name' => 'o_default_lang',
			);

			$this->db->update('config', $update, 'conf_name=:conf_name', $data);
		}

		// Only if the database has actually changed do we want to update anything else
		if (file_exists(AURA_ROOT.'include/db_update.xml'))
		{
			// DomDocument is a pain to work with here, so we load it and then use our customised method to fetch the data instead
			$parser = new \Aura\xml\parser;
			$parser->load(AURA_ROOT.'include/db_update.xml');
			$raw_xml = $parser->saveXML();

			// We now want to convert the XML into readable array data
			$xml = $this->registry->get('\Aura\xml\convert')->fetch_array($raw_xml);

			if (!isset($xml['update']))
				return false;

			// Rename any tables
			if (isset($xml['update']['rename']['table']))
			{
				if (!is_array(current($xml['update']['rename']['table'])))
					$xml['update']['rename']['table'] = array($xml['update']['rename']['table']);

				// Rename the tables
				foreach ($xml['update']['rename']['table'] as $data)
					$this->db->rename_table($data['from'], $data['to']);
			}

			// Alter any fields
			if (isset($xml['update']['alter']['field']))
			{
				if (!is_array(current($xml['update']['alter']['field'])))
					$xml['update']['alter']['field'] = array($xml['update']['alter']['field']);

				// Alter the fields
				foreach ($xml['update']['alter']['field'] as $data)
				{
					if ($data['allow_null'] == 'true')
						$data['allow_null'] = true;
					else
						$data['allow_null'] = false;

					if ($data['default_value'] == 'null')
						$data['default_value'] = null;
					else
						$data['default_value'] = '\''.$data['default_value'].'\'';

					if ($data['after_field'] == 'null')
						$data['after_field'] = null;

					$this->db->alter_field($data['table'], $data['field_name'], $data['field_type'], $data['allow_null'], $data['default_value'], $data['after_field']);
				}
			}

			// Perform any delete queries
			if (isset($xml['update']['delete']['query']))
			{
				if (!is_array(current($xml['update']['delete']['query'])))
					$xml['update']['delete']['query'] = array($xml['update']['delete']['query']);

				// Delete the data
				foreach ($xml['update']['delete'] as $data)
				{
					foreach ($data as $delete)
					{
						$where = eval(utf8_trim($delete['where']));
						$parameters = eval(utf8_trim($delete['parameters']));
						$this->db->delete($delete['table'], $where, $parameters);
					}
				}
			}

			// Drop any database tables 
			if (isset($xml['update']['delete']['table']))
			{
				if (!is_array(current($xml['update']['delete']['table'])))
					$xml['update']['delete']['table'] = array($xml['update']['delete']['table']);

				// Drop the tables
				foreach ($xml['update']['delete']['table'] as $data)
				{
					foreach ($data as $table)
						$this->db->drop_table($table);
				}
			}

			// Drop any database fields
			if (isset($xml['update']['delete']['field']))
			{
				if (!is_array(current($xml['update']['delete']['field'])))
					$xml['update']['delete']['field'] = array($xml['update']['delete']['field']);

				// Drop the tables
				foreach ($xml['update']['delete']['field'] as $data)
					$this->db->drop_field($data['table'], $data['field']);
			}

			// Drop any database indexes
			if (isset($xml['update']['delete']['index']))
			{
				if (!is_array(current($xml['update']['delete']['index'])))
					$xml['update']['delete']['index'] = array($xml['update']['delete']['index']);

				// Drop the indexes
				foreach ($xml['update']['delete']['index'] as $data)
					$this->db->drop_index($data['table'], $data['index']);
			}

			// Add any new database fields
			if (isset($xml['update']['add']['field']))
			{
				if (!is_array(current($xml['update']['add']['field'])))
					$xml['update']['add']['field'] = array($xml['update']['add']['field']);

				// Add the fields
				foreach ($xml['update']['add']['field'] as $data)
				{
					if ($data['allow_null'] == '1')
						$data['allow_null'] = true;
					else
						$data['allow_null'] = false;

					if ($data['default_value'] == 'null')
						$data['default_value'] = null;
					else
						$data['default_value'] = '\''.$data['default_value'].'\'';

					if ($data['after_field'] == 'null')
						$data['after_field'] = null;

					$this->db->add_field($data['table'], $data['field_name'], $data['field_type'], $data['allow_null'], $data['default_value'], $data['after_field']);
				}
			}

			// Add the indexes
			if (isset($xml['update']['add']['index']))
			{
				if (!is_array(current($xml['update']['add']['index'])))
					$xml['update']['add']['index'] = array($xml['update']['add']['index']);

				// Add the indexes
				foreach ($xml['update']['add']['index'] as $data)
				{
					$data['index_fields'] = explode(',', $data['index_fields']);

					if ($data['unique'] == '1')
						$data['unique'] = true;
					else
						$data['unique'] = false;

					$this->db->add_index($data['table_name'], $data['index_name'], $data['index_fields'], $data['unique']);
				}
			}

			// Create any new tables
			if (isset($xml['update']['create']))
			{
				if (!is_array(current($xml['update']['create']['table'])))
					$xml['update']['create']['table'] = array($xml['update']['create']['table']);

				// Create the tables
				foreach ($xml['update']['create'] as $data)
				{
					foreach ($data as $create)
					{
						$schema = eval(utf8_trim($create['content']));
						$this->db->create_table($create['attributes']['name'], $schema);
					}
				}
			}

			// Insert any new records
			if (isset($xml['update']['insert']['query']))
			{
				if (!is_array(current($xml['update']['insert']['query'])))
					$xml['update']['insert']['query'] = array($xml['update']['insert']['query']);

				// Insert the data
				foreach ($xml['update']['insert'] as $data)
				{
					foreach ($data as $insert)
					{
						$fields = eval(utf8_trim($insert['fields']));
						$this->db->insert($insert['table'], $fields);
					}
				}
			}

			// Handle the replace queries
			if (isset($xml['update']['replace']['query']))
			{
				if (!is_array(current($xml['update']['replace']['query']))) // If we only have one replace query
					$xml['update']['replace']['query'] = array($xml['update']['replace']['query']);

				// Replace the data
				foreach ($xml['update']['replace'] as $data)
				{
					foreach ($data as $replace)
					{
						$fields = eval(utf8_trim($replace['fields']));
						$this->db->replace($replace['table'], $fields);
					}
				}
			}

			// Perform the update query/queries
			if (isset($xml['update']['update']['query']))
			{
				if (!is_array(current($xml['update']['update']['query'])))
					$xml['update']['update']['query'] = array($xml['update']['update']['query']);

				// Update the data
				foreach ($xml['update']['update'] as $data)
				{
					foreach ($data as $update)
					{
						$fields = eval(utf8_trim($update['fields']));
						$where = eval(utf8_trim($update['where']));
						$parameters = eval(utf8_trim($update['parameters']));
						$this->db->update($update['table'], $fields, $where, $parameters);
					}
				}
			}

			@unlink(AURA_ROOT.'include/db_update.xml');
		}

		return true;
	}
}