<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

namespace Aura\admin;
use AuraClass;
use config;

class misc extends AuraClass
{
	//
	// Delete topics from $forum_id that are "older than" $prune_date (if $prune_sticky is 1, sticky topics will also be deleted)
	//
	public function prune($forum_id, $prune_sticky, $prune_date)
	{
		$data = array(
			':id'	=>	$forum_id,
		);

		$where_cond = 'forum_id=:id';
		if ($prune_date != -1)
		{
			$where_cond .= ' And last_post<:last_post';
			$data[':last_post'] = $prune_date;
		}

		if (!$prune_sticky)
			$where_cond .= ' AND sticky=0';

		// Fetch topics to prune
		$ps = $this->db->select('topics', 'id', $data, $where_cond);

		$topic_ids = array();
		foreach ($ps as $cur_topic)
		{
			$topic_ids[] = $cur_topic['id'];
			$placeholders[] = '?';
		}

		if (!empty($topic_ids))
		{
			$post_ids = array(); // Fetch posts to prune
			$ps = $this->db->select('posts', 'id', $topic_ids, 'topic_id IN('.implode(',', $placeholders).')'); 
			foreach ($ps as $cur_post)
			{
				$markers[] = '?';
				$post_ids[] = $cur_post['id'];
			}

			if ($post_ids != '')
			{
				$this->db->delete('topics', 'id IN('.implode(',', $placeholders).')', $topic_ids);
				$this->db->delete('topic_subscriptions', 'topic_id IN('.implode(',', $placeholders).')', $topic_ids);
				$this->db->delete('posts', 'id IN('.implode(',', $markers).')', $post_ids);

				// We removed a bunch of posts, so now we have to update the search index
				$idx = new \Aura\search\idx($this->registry);

				$idx->strip_search_index($post_ids);
			}
		}
	}

	//
	// Fetch a list of available admin plugins
	//
	public function forum_list_plugins($is_admin)
	{
		$plugins = array();
		$files = array_diff(scandir(config::PLUGINS_DIR), array('.', '..'));
		foreach ($files as $entry)
		{
			$prefix = substr($entry, 0, strpos($entry, '_'));
			$suffix = substr($entry, strlen($entry) - 4);

			if ($suffix == '.php' && ((!$is_admin && $prefix == 'AMP') || ($is_admin && ($prefix == 'AP' || $prefix == 'AMP'))))
				$plugins[substr($entry, 0, -4)] = substr($entry, strpos($entry, '_') + 1, -4);
		}

		natcasesort($plugins);
		return $plugins;
	}

	public function generate_htaccess()
	{
		$base = '/';
		$parsed = parse_url($this->config['o_base_url']);
		$parsed['path'] = isset($parsed['path']) ? $parsed['path'] : '/';
		$base = str_replace('%2F', '/', rawurlencode(str_replace('index.php', '', str_replace('/'.AURA_ROOT, '', preg_replace( "#/$#", "", $parsed['path'])))));

		return "<IfModule mod_rewrite.c>\n\tOptions -MultiViews\n\tAllow from all\n\n\tRewriteEngine On\n\tRewriteBase ".$base."/\n\n\tRewriteCond %{REQUEST_FILENAME} !-f\n\tRewriteCond %{REQUEST_FILENAME} !-d\n\tRewriteCond %{REQUEST_URI} !^/install(/|$)\n\tRewriteCond %{REQUEST_URI} !^/convert(/|$)\n\tRewriteRule . index.php [L]\n\n\t<IfModule mod_autoindex.c>\n\t\tOptions -Indexes\n\t</IfModule>\n\n\tAddDefaultCharset utf-8\n\tAddCharset utf-8 .html .css .js .xml .json .rss\n\n\t<IfModule mod_setenvif.c>\n\t\t<IfModule mod_headers.c>\n\t\t\tBrowserMatch MSIE ie\n\t\t\tHeader set X-UA-Compatible \"IE=Edge,chrome=1\" env=ie\n\t\t</IfModule>\n\t</IfModule>\n\n\t<IfModule mod_headers.c>\n\t\tHeader append Vary User-Agent\n\t</IfModule>\n</IfModule>";
	}
}