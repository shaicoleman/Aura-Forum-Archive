<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

namespace Aura\admin;
use AuraClass;
use config;

class extension extends AuraClass
{
	//
	// Validate an Extension schema when installing it into the Amin panel
	//
	public function validate($extension, $errors)
	{
		if (!isset($extension['extension']))
			$errors[] = $this->lang->t('Extension tag missing', 'extension');

		if (empty($errors))
		{
			// First off start by validating the Engine
			$extension = $extension['extension'];
			if (!isset($extension['attributes']['engine']))
				$errors[] = $this->lang->t('Extension attribute missing', 'engine');
			else if ($extension['attributes']['engine'] < '1.2')
				$errors[] = $this->lang->t('Extension engine incompatible', $this->config['o_cur_version']);
			else if ($extension['attributes']['engine'] != '1.2')
				$errors[] = $this->lang->t('Extension engine invalid');

			// Next, validate we have an appropriate title
			else if (!isset($extension['title']))
				$errors[] = $this->lang->t('Extension tag missing', 'title');
			else if (utf8_strlen($extension['title']) <= 5)
				$errors[] = $this->lang->t('Extension title too short');

			// Validate the extension version
			if (!isset($extension['version']))
				$errors[] = $this->lang->t('Extension tag missing', 'version');
			else if (!is_numeric($extension['version']))
				$errors[] = $this->lang->t('Extension version invalid');

			else if (!isset($extension['unique_name']))
			{
				// We don't actually want an error at this point, because it's a duplicate of existing error above when the extension engine is incompatible
			}
			// The class name of the extension
			else if (utf8_strlen($extension['unique_name']) < 5 || preg_match('/[^a-z0-9_]/s', $extension['unique_name']))
				$errors[] = $this->lang->t('Extension class name invalid');

			// Description for the extension
			else if (!isset($extension['description']))
				$errors[] = $this->lang->t('Extension tag missing', 'description');
			else if (utf8_strlen($extension['description']) <= 20)
				$errors[] = $this->lang->t('Extension description too short');

			// Validate the extension author
			else if (!isset($extension['author']))
				$errors[] = $this->lang->t('Extension tag missing', 'author');
			else if (utf8_strlen($extension['author']) <= 3)
				$errors[] = $this->lang->t('Extension author too short');

			// Check out all extension versions
			else if (!isset($extension['supported_versions']))
				$errors[] = $this->lang->t('Extension tag missing', 'supported_versions');
			else
			{
				$versions = explode(',', $extension['supported_versions']);
				if (empty($versions))
					$errors[] = $this->lang->t('Extension supported versions empty');
				else if (count(array_filter($versions)) != count($versions))
					$errors[] = $this->lang->t('Extension supported versions markup invalid');
			}

			// Validate the extension executable data
			if (empty($errors))
			{
				if (!isset($extension['executable']))
					$errors[] = $this->lang->t('Extension tag missing', 'executable');
				else if (utf8_trim($extension['executable']) == '' || utf8_strlen($extension['executable']) < 50)
					$errors[] = $this->lang->t('Extension hook missing content', 'executable');
			}

			// Optional: validate the install tag
			if (empty($errors) && isset($extension['install']))
			{
				if (empty($extension['install']))
					$errors[] = $this->lang->t('Invalid or unused extension tag', 'install');

				// If we're installing additional templates when we install this extension
				if (isset($extension['install']['templates']))
				{
					if (!isset($extension['install']['templates']['template']))
						$errors[] = $this->lang->t('Extension tag missing', 'template');
					else if (!is_array($extension['install']['templates']['template']))
						$errors[] = $this->lang->t('Extension template missing');
					else
					{
						// Hacky solution to only having one template
						if (isset($extension['install']['templates']['template']['content']))
						{
							$extension['install']['templates']['template'][0] = $extension['install']['templates']['template'];
							unset($extension['install']['templates']['template']['content']);
							unset($extension['install']['templates']['template']['attributes']);
						}

						$templates = array();
						foreach ($extension['install']['templates']['template'] as $template)
						{
							if (!isset($template['attributes']['id']))
							{
								$errors[] = $this->lang->t('Extension attribute missing', 'id');
								break;
							}
							else if (utf8_strlen($template['attributes']['id']) < 5 || !preg_match('/([a-z]+).tpl/s', $template['attributes']['id']))
							{
								$errors[] = $this->lang->t('Invalid template attribute', $template['attributes']['id']);
								break;
							}
							else if (!isset($template['content']) || utf8_trim($template['content']) == '')
							{
								$errors[] = $this->lang->t('Extension template missing content', $template['attributes']['id']);
								break;
							}

							$templates[] = $template['attributes']['id'];
						}

						// Check for duplicate template files being installed in the extension
						if (count($templates) !== count(array_unique($templates)))
							$errors[] = $this->lang->t('Template names not unique');
					}
				}

				// Do we have a 'class name' component which already is used?
				if (is_dir(config::EXTENSIONS_DIR.$extension['unique_name']))
					$errors[] = $this->lang->t('Plugin folder already used');

				// If we're installing additional plugin files with this extension
				if (empty($errors) && isset($extension['install']['plugins']))
				{
					if (!isset($extension['install']['plugins']['plugin']))
						$errors[] = $this->lang->t('Extension tag missing', 'plugin');
					else if (!is_array($extension['install']['plugins']['plugin']))
						$errors[] = $this->lang->t('Extension plugin missing');
					else
					{
						// Hacky solution to only having one plugin
						if (isset($extension['install']['plugins']['plugin']['content']))
						{
							$extension['install']['plugins']['plugin'][0] = $extension['install']['plugins']['plugin'];
							unset($extension['install']['plugins']['plugin']['content']);
							unset($extension['install']['plugins']['plugin']['attributes']);
						}

						$plugins = array();
						foreach ($extension['install']['plugins']['plugin'] as $plugin)
						{
							if (!isset($plugin['attributes']['id']))
							{
								$errors[] = $this->lang->t('Extension attribute missing', 'id');
								break;
							}
							else if (utf8_strlen($plugin['attributes']['id']) < 5 || !preg_match('/(AP_|AMP_)([A-Za-z0-9_]+).php/s', $plugin['attributes']['id']))
							{
								$errors[] = $this->lang->t('Invalid plugin attribute', $plugin['attributes']['id']);
								break;
							}
							else if (!isset($plugin['content']) || utf8_trim($plugin['content']) == '')
							{
								$errors[] = $this->lang->t('Extension plugin missing content', $plugin['attributes']['id']);
								break;
							}

							$plugins[] = $plugin['attributes']['id'];
						}

						// Check for duplicate plugin files in this extension
						if (count($plugins) !== count(array_unique($plugins)))
							$errors[] = $this->lang->t('Plugin names not unique');

						// Then look through to make sure we're not going to be overwriting anything that already exists
						foreach ($plugins as $plugin)
						{
							if (file_exists(config::PLUGINS_DIR.$plugin))
							{
								$errors[] = $this->lang->t('Plugin already exists', $plugin);
								break;
							}
						}
					}
				}

				// If we're installing additional languages along with this extension
				if (empty($errors) && isset($extension['install']['languages']))
				{
					if (!isset($extension['install']['languages']['language']))
						$errors[] = $this->lang->t('Extension tag missing', 'language');
					else if (!is_array($extension['install']['languages']['language']))
						$errors[] = $this->lang->t('Extension language missing');
					else
					{
						// Hacky solution to only having one language
						if (isset($extension['install']['languages']['language']['content']))
						{
							$extension['install']['languages']['language'][0] = $extension['install']['languages']['language'];
							unset($extension['install']['languages']['language']['content']);
							unset($extension['install']['languages']['language']['attributes']);
						}

						$languages = array();
						foreach ($extension['install']['languages']['language'] as $language)
						{
							if (!isset($language['attributes']['id']))
							{
								$errors[] = $this->lang->t('Extension attribute missing', 'id');
								break;
							}
							else if (utf8_strlen($language['attributes']['id']) < 5 || !preg_match('/([a-z_]+).po/s', $language['attributes']['id']))
							{
								$errors[] = $this->lang->t('Invalid language attribute', $language['attributes']['id']);
								break;
							}
							if (!isset($language['attributes']['iso']))
							{
								$errors[] = $this->lang->t('Extension attribute missing', 'iso');
								break;
							}
							else if (!preg_match('/([a-z]{2})_([A-Z]{2})/s', $language['attributes']['iso']))
							{
								$errors[] = $this->lang->t('Invalid language attribute', $language['attributes']['iso']);
								break;
							}
							else if (!isset($language['content']) || utf8_trim($language['content']) == '')
							{
								$errors[] = $this->lang->t('Extension language missing content', $language['attributes']['id']);
								break;
							}

							$languages[] = $language['attributes']['id'].'_'.$language['attributes']['iso'];
						}

						// Check for duplicate language files being installed in the extension
						if (count($languages) !== count(array_unique($languages)))
							$errors[] = $this->lang->t('Language files not unique');
					}
				}

				// If we're installing additional files with this extension
				if (empty($errors) && isset($extension['install']['files']))
				{
					if (!isset($extension['install']['files']['file']))
						$errors[] = $this->lang->t('Extension tag missing', 'file');
					else if (!is_array($extension['install']['files']['file']))
						$errors[] = $this->lang->t('Extension file missing');
					else
					{
						// Hacky solution to only having one file
						if (isset($extension['install']['files']['file']['content']))
						{
							$extension['install']['files']['file'][0] = $extension['install']['files']['file'];
							unset($extension['install']['files']['file']['content']);
							unset($extension['install']['files']['file']['attributes']);
						}

						$files = array();
						foreach ($extension['install']['files']['file'] as $file)
						{
							if (!isset($file['attributes']['name']))
							{
								$errors[] = $this->lang->t('Extension attribute missing', 'name');
								break;
							}
							else if (utf8_strlen($file['attributes']['name']) < 5 || !preg_match('/([a-z]+).php/s', $file['attributes']['name']))
							{
								$errors[] = $this->lang->t('Invalid file attribute', $file['attributes']['name']);
								break;
							}
							else if (!isset($file['content']) || utf8_trim($file['content']) == '')
							{
								$errors[] = $this->lang->t('Extension file missing content', $file['attributes']['name']);
								break;
							}

							$files[] = $file['attributes']['name'];
						}

						// Check for duplicate files in this extension
						if (count($files) !== count(array_unique($files)))
							$errors[] = $this->lang->t('File names not unique');
					}
				}

				// If we're installing additional tasks along with this extension
				if (empty($errors) && isset($extension['install']['tasks']))
				{
					
				}

				// If we're installing additional styles along with this extension
				if (empty($errors) && isset($extension['install']['styles']))
				{
					
				}
			}

			// Optional: validate the uninstall tag
			if (empty($errors) && isset($extension['uninstall']))
			{
				if (empty($extension['uninstall']))
					$errors[] = $this->lang->t('Invalid or unused extension tag', 'uninstall');
				else if (isset($extension['uninstall']['note']) && utf8_strlen($extension['uninstall']['note']) <= 5)
					$errors[] = $this->lang->t('Uninstall note too short');
			}
		}

		return array($extension, $errors);
	}

	public static function str_replace_first($from, $to, $content)
	{
		$from = '/'.preg_quote($from, '/').'/';

		return preg_replace($from, $to, $content, 1);
	}
}