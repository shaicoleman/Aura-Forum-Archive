<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

namespace Aura\admin;

class common
{
	public function __construct($registry)
	{
		$this->registry = $registry;
		$this->cache = $registry->cache;
		$this->config = $registry->config;
		$this->lang = $registry->lang;
		$this->user = $registry->user;
		$this->rewrite = $registry->rewrite;
		$this->template = $registry->template;

		$this->lang->load('admin_common');

		$this->restrictions = $this->cache->get('restrictions');
		if (!isset($this->restrictions[$this->user['id']]) || $this->user['id'] == '2')
			$this->restrictions[$this->user['id']] = array(
				'admin_options' => 1,
				'admin_permissions' => 1,
				'admin_categories' => 1,
				'admin_forums' => 1,
				'admin_groups' => 1,
				'admin_censoring' => 1,
				'admin_maintenance' => 1,
				'admin_plugins' => 1,
				'admin_restrictions' => 1,
				'admin_users' => 1,
				'admin_moderate' => 1,
				'admin_ranks' => 1,
				'admin_updates' => 1,
				'admin_archive' => 1,
				'admin_smilies' => 1,
				'admin_warnings' => 1,
				'admin_attachments' => 1,
				'admin_robots' => 1,
				'admin_extensions' => 1,
				'admin_tasks' => 1,
			);
	}

	/**
	 * Display the admin navigation menu
	 */
	public function generate_menu($page = '')
	{
		$admin_menu = array();
		if ($this->user['is_admin'])
		{
			if ($this->restrictions[$this->user['id']]['admin_options'] == '1')
				$admin_menu[] = array('page' => 'options', 'href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_options']), 'title' => $this->lang->t('Options'));

			if ($this->restrictions[$this->user['id']]['admin_archive'] == '1')
				$admin_menu[] = array('page' => 'archive', 'href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_archive']), 'title' => $this->lang->t('Archive'));

			if ($this->restrictions[$this->user['id']]['admin_permissions'] == '1')
				$admin_menu[] = array('page' => 'permissions', 'href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_permissions']), 'title' => $this->lang->t('Permissions'));

			if ($this->restrictions[$this->user['id']]['admin_categories'] == '1')
				$admin_menu[] = array('page' => 'categories', 'href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_categories']), 'title' => $this->lang->t('Categories'));

			if ($this->restrictions[$this->user['id']]['admin_forums'] == '1')
				$admin_menu[] = array('page' => 'forums', 'href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_forums']), 'title' => $this->lang->t('Forums'));

			if ($this->restrictions[$this->user['id']]['admin_groups'] == '1')
				$admin_menu[] = array('page' => 'groups', 'href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_groups']), 'title' => $this->lang->t('User groups'));

			if ($this->restrictions[$this->user['id']]['admin_censoring'] == '1')
				$admin_menu[] = array('page' => 'censoring', 'href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_censoring']), 'title' => $this->lang->t('Censoring'));

			if ($this->restrictions[$this->user['id']]['admin_ranks'] == '1') 
				$admin_menu[] = array('page' => 'ranks', 'href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_ranks']), 'title' => $this->lang->t('Ranks')); 

			if ($this->restrictions[$this->user['id']]['admin_robots'] == '1')
				$admin_menu[] = array('page' => 'robots', 'href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_robots']), 'title' => $this->lang->t('Robots'));

			if ($this->restrictions[$this->user['id']]['admin_smilies'] == '1' && $this->config['o_smilies'] == '1')
				$admin_menu[] = array('page' => 'smilies', 'href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_smilies']), 'title' => $this->lang->t('Smilies'));

			if ($this->restrictions[$this->user['id']]['admin_warnings'] == '1' && $this->config['o_warnings'] == '1')
				$admin_menu[] = array('page' => 'warnings', 'href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_warnings']), 'title' => $this->lang->t('Warnings'));

			if ($this->restrictions[$this->user['id']]['admin_moderate'] == '1')
				$admin_menu[] = array('page' => 'moderate', 'href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_moderate']), 'title' => $this->lang->t('Moderate'));

			if ($this->restrictions[$this->user['id']]['admin_attachments'] == '1' && $this->config['o_attachments'] == '1')
				$admin_menu[] = array('page' => 'attachments', 'href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_attachments']), 'title' => $this->lang->t('Attachments'));

			if ($this->restrictions[$this->user['id']]['admin_restrictions'] == '1')
				$admin_menu[] = array('page' => 'restrictions', 'href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_restrictions']), 'title' => $this->lang->t('Restrictions'));

			if ($this->restrictions[$this->user['id']]['admin_tasks'] == '1')
				$admin_menu[] = array('page' => 'tasks', 'href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_tasks']), 'title' => $this->lang->t('Tasks'));

			if ($this->restrictions[$this->user['id']]['admin_extensions'] == '1')
				$admin_menu[] = array('page' => 'extensions', 'href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_extensions']), 'title' => $this->lang->t('Extensions'));

			if ($this->restrictions[$this->user['id']]['admin_maintenance'] == '1')
				$admin_menu[] = array('page' => 'maintenance', 'href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_maintenance']), 'title' => $this->lang->t('Maintenance'));

			if ($this->restrictions[$this->user['id']]['admin_updates'] == '1')
				$admin_menu[] = array('page' => 'updates', 'href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_update']), 'title' => $this->lang->t('Updates'));
		}

		$plugin_menu = array();
		$plugins = $this->registry->get('\Aura\admin\misc')->forum_list_plugins($this->user['is_admin']);
		if (!empty($plugins) && ($this->restrictions[$this->user['id']]['admin_plugins'] == '1'))
		{
			foreach ($plugins as $plugin_name => $plugin)
				$plugin_menu[] = array('page' => $plugin_name, 'href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_loader'], array($plugin_name)), 'title' => str_replace('_', ' ', $plugin));
		}

		$tpl = $this->template->load('admin/sidebar.tpl');
		return $this->template->render($tpl,
			array(
				'page' => $page,
				'ban_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_bans']),
				'index_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_index']),
				'about_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['about_aura']),
				'users_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_users']),
				'announce_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_announcements']),
				'posts_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_posts']),
				'reports_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_reports']),
				'deleted_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_deleted']),
				'admin_menu' => $admin_menu,
				'plugin_menu' => $plugin_menu,
			), false, false
		);
	}

	/**
	 * Check the restrictive access level of a user
	 */
	public function check_user($key)
	{
		if ($this->user['id'] != '2')
		{
			if (!is_null($this->restrictions[$this->user['id']][$key]))
			{
				if ($this->restrictions[$this->user['id']][$key] == '0')
					$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');
			}
		}
	}

	/**
	 * Do we have any restrictions for a specific user?
	 */
	public function fetch_restrictions($user_id)
	{
		return isset($this->restrictions[$user_id]) ? $this->restrictions[$user_id] : array();
	}
}