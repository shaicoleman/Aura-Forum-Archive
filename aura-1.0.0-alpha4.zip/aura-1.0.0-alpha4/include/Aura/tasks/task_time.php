<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

namespace Aura\tasks;

// Make sure no one attempts to run this script "directly"
if (!defined('config::SESSION'))
	exit;

/**
 * A helper class to fetch the next run of a task
 */
class task_time
{
	/**
	 * Get the next run time for a task!
	 */
	public function next_run($minute, $hour, $day, $month, $week_day)
	{
		$this->current = array(
			'minute' => gmdate('i', CURRENT_TIMESTAMP),
			'hour' => gmdate('H', CURRENT_TIMESTAMP),
			'day' => gmdate('j', CURRENT_TIMESTAMP),
			'month' => gmdate('m', CURRENT_TIMESTAMP),
			'week_day' => gmdate('w', CURRENT_TIMESTAMP),
			'year' => gmdate('Y', CURRENT_TIMESTAMP),
		);

		$this->run = $this->current;

		// Determine whether it should be ran today
		$next_day = ($week_day == '*' && $month == '*') ? 1 : 0;
		$next_minute = ($minute == '*') ? 1 : 0;

		// Sort out the hours
		if ((string) $hour == '*')
		{
			if ($minute !== '*')
				$this->add_hour();
			else
				$this->run['hour'] = $this->current['hour'];
		}
		else
			$this->run['hour'] = $hour;

		// Sort out the days
		if ($day == '*')
		{
			if ($this->run['hour'] < $this->current['hour'])
				$this->add_day();
			else
				$this->run['day'] = $this->current['day'];
		}
		else
			$this->run['day'] = $day;

		// Sort out the months
		if ($month == '*')
		{
			if ($this->run['day'] < $this->current['day'])
				$this->add_month();
			else
				$this->run['month'] = $this->current['month'];
		}
		else
			$this->run['month'] = $month;

		if ($this->run['day'] < $this->current['day'] && $this->run['month'] <= $this->current['month'])
			$this->add_month();

		// Sort out the week days
		if ($week_day !== '*')
		{
			if ($month == '*')
			{
				if ($day == '*')
				{
					$this->run['day'] = $this->current['day'] + ($week_day - $this->current['week_day']);
					if ($this->run['day'] > gmdate('t', CURRENT_TIMESTAMP))
						$this->run['day'] = ($this->run['day'] - gmdate('t', CURRENT_TIMESTAMP));

					if ($this->run['day'] < $this->current['day'])
						$this->add_day(7);
				}
				else
					$this->run['day'] = $day + ($week_day - ($this->current['week_day']));
			}
			else
			{
				if ($day == '*')
				{
					$this->run['day'] = $this->current['day'] + ($week_day - $this->current['week_day']);
					if ($this->run['day'] > gmdate('t', CURRENT_TIMESTAMP))
						$this->run['day'] = ($this->run['day'] - gmdate('t', CURRENT_TIMESTAMP));

					$next_year = false;
					if ($this->run['day'] < $this->current['day'] && $this->run['month'] <= $this->current['month'])
					{
						$next_year = true;
						$this->run['year']++;
						
						$week_days = array('Sunday', 'Monday', '');
						
						$month_name = date('F', mktime(0, 0, 0, $this->run['month'], $this->run['year']));
						$days = array(
							'Sunday',
							'Monday',
							'Tuesday',
							'Wednesday',
							'Thursday',
							'Friday',
							'Saturday'
						);

						$this->run['day'] = date('t', strtotime('first '.$days[$week_day].' of '.$month_name.' '.$this->run['year']));
					}

					if ($this->run['day'] < $this->current['day'] && !$next_year)
						$this->add_day(7);
				}
				else
				{
					// Make sure using a day already past in this year isn't possible
					if ($this->run['day'] < $day && $this->run['month'] < $this->current['month'] && $this->run['year'] == $this->current['year'])
						$this->run['year']++;

					$this->found = false;
					while (!$this->found)
					{
						if (date('w', mktime(0, 0, 0, $month, $day, $this->run['year'])) == $week_day) // We have a match!
						{
							$this->found = true;
							break;
						}
						else
							$this->run['year']++;
					}
				}
			}
		}

		// Sort out the minutes
		if ((string) $minute == '*')
		{
			if ((string) $hour == '*')
			{
				if ($this->run['month'] != $this->current['month'])
					$this->run['minute'] = 0;
				else
					$this->add_minute();
			}
			else
				$this->run['minute'] = 0;
		}
		else
		{
			if ($hour == '*' && !$next_day)
				$this->add_minute($minute);
			else
				$this->run['minute'] = $minute;
		}

		// Check things to make sure the time actually ended up in the future
		if ($this->run['month'] < $this->current['month'] && $this->run['year'] <= $this->current['year'])
			$this->run['year']++;

		if ($this->run['hour'] <= $this->current['hour'] && $this->run['day'] == $this->current['day'] && $this->run['month'] <= $this->current['month'] && $this->run['year'] <= $this->current['year'])
		{
			if ($hour == '*')
			{
				if ($this->run['hour'] == $this->current['hour'] && $this->run['minute'] <= $this->current['minute'])
					$this->add_hour();
			}
 			else
				$this->add_day();
		}

		return gmmktime($this->run['hour'], $this->run['minute'], 0, $this->run['month'], $this->run['day'], $this->run['year']);
	}

	/**
	 * Add a month onto the time
	 */
	protected function add_month()
	{
		if ($this->current['month'] == 12)
		{
			$this->run['month'] = 1;
			$this->run['year']++;
		}
		else
			$this->run['month']++;
	}

	/**
	 * Add a day onto the time
	 */
	protected function add_day($days = 1)
	{
		if ($this->current['week_day'] >= (gmdate('t', CURRENT_TIMESTAMP) - $days))
		{
			$this->run['day'] = ($this->current['month'] + $days) - date('t', CURRENT_TIMESTAMP);
			$this->add_month();
		}
		else
			$this->run['day'] += $days;
	}

	/**
	 * Add a hour onto the time
	 */
	protected function add_hour($hour = 1)
	{
		if ($this->current['hour'] >= (24 - $hour))
		{
			$this->run['hour'] = ($this->current['hour'] + $hour) - 24;
			$this->add_day();
		}
		else
			$this->run['hour'] += $hour;
	}

	/**
	 * Add a minute onto the time
	 */
	protected function add_minute($minutes = 1)
	{
		if ($this->current['minute'] >= (60 - $minutes))
		{
			$this->run['minute'] = ($this->current['minute'] + $minutes) - 60;
			$this->add_hour();
		}
		else
			$this->run['minute'] += $minutes;
	}
}