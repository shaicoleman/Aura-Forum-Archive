<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
namespace Aura;
use AuraClass;

if (!defined('config::SESSION'))
	exit;

class links extends AuraClass
{
	// Generate link to another page on the forum
	function aura_link($link, $args = null)
	{
		static $base_url;
		$base_url = (!$base_url) ? $this->functions->get_base_url() : $base_url;

		$gen_link = $link;
		if ($args == null)
			$gen_link = $base_url.'/'.$link;
		else if (!is_array($args))
			$gen_link = $base_url.'/'.str_replace('$1', $args, $link);
		else
		{
			for ($i = 0; isset($args[$i]); ++$i)
				$gen_link = str_replace('$'.($i + 1), $args[$i], $gen_link);

			$gen_link = $base_url.'/'.$gen_link;
		}

		return $gen_link;
	}

	// Generate a hyperlink with parameters and anchor and a subsection such as a subpage
	function aura_sublink($link, $sublink, $subarg, $args = null)
	{
		static $base_url = null;

		$base_url = (!$base_url) ? $this->functions->get_base_url() : $base_url;

		// If there is only one page, then return the canonical url with no page numbers attached
		if ($sublink == $this->rewrite->url['page'] && $subarg == 1)
		{
			if (isset($this->rewrite->url['insertion_find']))
				return str_replace($this->rewrite->url['insertion_find'], '', $this->aura_link($link, $args));
			else
				return $this->aura_link($link, $args);
		}

		$gen_link = $link;
		if (!is_array($args) && $args != null)
			$gen_link = str_replace('$1', $args, $link);
		else
		{
			for ($i = 0; isset($args[$i]); ++$i)
				$gen_link = str_replace('$'.($i + 1), $args[$i], $gen_link);
		}

		if (isset($this->rewrite->url['insertion_find']))
			$gen_link = $base_url.'/'.str_replace($this->rewrite->url['insertion_find'], str_replace('$1', str_replace('$1', $subarg, $sublink), $this->rewrite->url['insertion_replace']), $gen_link);
		else
			$gen_link = $base_url.'/'.$gen_link.str_replace('$1', $subarg, $sublink);

		return $gen_link;
	}
}