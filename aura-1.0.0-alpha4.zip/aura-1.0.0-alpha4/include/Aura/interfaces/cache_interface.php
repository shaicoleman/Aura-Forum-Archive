<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

namespace Aura\interfaces;

interface cache_interface
{
	/**
	 * Get the cache file
	 */
	public function get($file, $args = array(), $generate = true, $language = false, $refresh = false);

	/**
	 * Generate a cache object without returning it
	 */
	public function generate($file, $args = array(), $return = false);

	/**
	 * Clear all the cache files
	 */
	public function clear();

	/**
	 * Delete a cache file from the system
	 */
	public function delete($file);

	/**
	 * Check whether a specific cache file exists
	 */
	public function exists($file);

	/**
	 * Delete all feed caches
	 */
	public function clear_feeds();

	/**
	 * Generate a custom cache
	 */
	public function custom($name, $data);
}