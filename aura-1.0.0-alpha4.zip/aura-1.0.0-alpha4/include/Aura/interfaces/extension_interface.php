<?php
namespace Aura\interfaces;

interface extension_interface
{
	public function run();
}