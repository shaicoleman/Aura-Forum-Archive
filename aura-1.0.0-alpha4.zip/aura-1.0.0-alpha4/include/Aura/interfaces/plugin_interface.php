<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

namespace Aura\interfaces;

interface plugin_interface
{
	public function initiate();
}