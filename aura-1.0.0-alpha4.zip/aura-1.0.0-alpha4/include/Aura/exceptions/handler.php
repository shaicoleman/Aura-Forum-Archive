<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

namespace Aura\exceptions;
use registry;
use Aura\styles;

// Make sure no one attempts to run this script "directly"
if (!defined('config::SESSION'))
	exit;

class handler
{
	/**
	 * What type of error do we have? 0 for exceptions, 1 for database, 2 for templates
	 */
	protected $error_type = 0;

	/**
	 * Holds the language strings for the exception handler
	 */
	protected $language = array();

	/**
	 * Have we failed on a premature exception- i.e. before all resources have loaded?
	 */
	protected $premature_exception = false;

	/**
	 * Setup the constructor for the exception handler
	 */
	public function __construct($registry = null)
	{
		if (!is_null($registry))
		{
			$this->registry = $registry;
			$this->config = $registry->config;
			$this->user = $registry->user;
			$this->url = $registry->url;
			$this->lang = $registry->lang;
			$this->functions = $registry->functions;
			$this->template = $registry->template;

			$this->lang->load('exception');
		}
		else
		{
			if (empty($this->config))
			{
				// Make an educated guess regarding base_url
				$base_url  = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') ? 'https://' : 'http://';	// protocol
				$base_url .= preg_replace('%:(80|443)$%', '', $_SERVER['HTTP_HOST']);							// host[:port]
				$base_url .= str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));							// path

				if (substr($base_url, -1) == '/')
					$base_url = substr($base_url, 0, -1);

				$this->config = array(
					'o_board_title'	=> 'Aura',
					'o_gzip'		=> '0',
					'o_debug_mode'	=>	'1',
					'o_webmaster_email'	=>	$_SERVER['SERVER_ADMIN'],
					'o_default_style'	=>	\Aura\styles::get_default_style(),
					'o_base_url'	=>	$base_url,
					'o_style_dir' => 'styles/',
					'o_style_path' => '/styles/',
				);

				$this->premature_exception = true;
			}

			if (empty($this->user))
			{
				$aura_user = array(
					'style' => $this->config['o_default_style'],
					'is_admin' => false,
					'is_admmod' => false,
					'is_guest' => true,
				);

				$this->premature_exception = true;
			}

			if (empty($this->url))
			{
				$this->url = new \Aura\url\packs\standard();
				$this->premature_exception = true;
			}

			if (empty($this->lang))
			{
				$this->lang = new \Aura\lang(new registry);

				$this->premature_exception = true;
			}

			// There's no choice but to hard-code the language in here if we can;'t even load up the resources to get them ......
			$this->language = array(
				'lang_identifier' => 'en',
				'Server' => 'server',
				'Database' => 'database',
				'Database error' => 'Database Error',
				'Server error' => 'Server Error',
				'Exception trace' => '%s in %s on line %s',
				'Request aborted' => 'The request was aborted: A %s error was encountered.',
				'Database error line 1' => 'The server encountered a database error, we\'ve been unable to display the page you requested. Please try again.',
				'Database error line 2' => 'If the issue persists, contact the server administrator and inform them of the time the error occured, along with anything you may have done which could have caused the error.',
				'Database reported' => 'Database Reported:',
				'Failed sql' => 'Failed SQL:',
				'Parameters' => 'Parameters:',
				'Contact admin' => 'Contact server administrator',
				'Try again' => 'Try again',
				'Back to index' => 'Back to the index',
				'Server error line 1' => 'The server encountered an internal error or misconfiguration, we\'ve been unable to display the page you requested.',
				'Server error line 2' => 'We apologise for the inconvenience this may have caused, use the link below to try again, alternatively you can return to the board index.',
				'Server error line 3' => 'Errno [%s] %s in  %s on line %s',
			);

			$this->lang->add_translations($this->language);
		}
	}

	/**
	 * Main entry point - Errors, Exceptions and Fatal errors all get routed here
	 */
	public function handle($errno = 0, $errstr = 'Error', $errfile = 'unknown', $errline = 0)
	{
		if (error_reporting() == 0) // If we want to supress errors
			return;

	    if ($errno instanceof Error)
		{
		    $errstr = $errno->getMessage();
		    $errfile = $errno->getFile();
		    $errline = $errno->getLine();
		}

		// First we check for exceptions rather than errors
		if (!is_int($errno))
		{
			list(, $errstr, $errfile, $errline) = $this->parse_exception($errno);

			if (is_json($errstr)) // Then we check if it's specifically a database exception, these are generated differently
			{
				$error = json_decode($errstr, true);

				$errstr = $error['message'];
				$errsql = $error['sql'];
				$errparameters = $error['parameters'];
				$errfile = isset($error['trace'][1]['file']) ? $error['trace'][1]['file'] : $error['trace']['file'];
				$errline = isset($error['trace'][1]['line']) ? $error['trace'][1]['line'] : $error['trace']['line'];

				$this->error_type = 1;
			}
			else // A template exception?
			{
				switch (true)
				{
					case get_class($errno) == 'Twig_Error_Syntax':
					case get_class($errno) == 'Twig_Error_Loader':
						$errstr = $errno->getRawMessage();
						$errfile = $errno->getTemplateFile();
						$errline = $errno->getTemplateLine();
						$errno = $errno->getCode();

						$this->error_type = 2;
					break;
					case get_class($errno) == 'Twig_Error_Loader':
						$errstr = $errno->getRawMessage();
						$errfile = $errno->getFile();
						$errline = $errno->getLine();
						$errno = $errno->getCode();

						$this->error_type = 2;
					break;
					default:
						// A standard Exception, just do nothing
						$errno = $errno->getCode();
					break;
				}
			}

			$errno = E_ERROR;
		}
		else
			$this->error_type = 0;

		// Stop register_shutdown_function interfering in normal circumstances
		$error = error_get_last();
		if ($errno < E_ERROR && $error['type'] !== E_ERROR)
			registry::terminate();

		// Check if we're dealing with a fatal error (these must be handled seperately with register_shutdown_function)
		if ($error['type'] == E_ERROR)
		{
			$errno = $error['type'];
			$errstr = $error['message'];
			$errfile = $error['file'];
			$errline = $error['line'];
		}

		// We don't want to expose anything other than the forum structure
		$errfile = substr(str_replace(realpath(AURA_ROOT), '', $errfile), 1);

		// Empty all output buffers and stop buffering (only if we've started)
		if (ob_get_level() > 0 && ob_get_length())
			@ob_clean();

		// If we've failed on an AJAX request, it's a premature exception, or we're using the CLI interface, we'd better not send HTML
		if (defined('AURA_AJAX_REQUEST') || $this->premature_exception || substr(PHP_SAPI, 0, 3) == 'cli')
		{
			if ($this->config['o_debug_mode'] == '1')
				registry::terminate($this->lang->t('Exception trace', $errstr, $errfile, $errline));

			switch ($this->error_type)
			{
				case 2:
					$title = $this->lang->t('Template');
				break;
				case 1:
					$title = $this->lang->t('Database');
				break;
				default:
				case 0:
					$title = $this->lang->t('Server');
				break;
			}

			registry::terminate($this->lang->t('Request aborted', $title));
		}
		else if (!headers_sent()) // Ticket #YCZ-278-40842 - Headers sporadically messing with error handling of AJAX requests
		{
			// "Restart" output buffering if we are using ob_gzhandler (since the gzip header is already sent)
			if ($this->config['o_gzip'] && extension_loaded('zlib') && !ob_get_length())
				ob_start('ob_gzhandler');

			// Send no-cache headers
			registry::send_headers('html');
		}

		// Send headers telling people we're down
		registry::custom_header('503 Service Temporarily Unavailable');

		switch ($this->error_type)
		{
			case 2:
				$title = $this->lang->t('Template error');
			break;
			case 1:
				$title = $this->lang->t('Database error');
			break;
			default:
			case 0:
				$title = $this->lang->t('Server error');
			break;
		}

		// Check and see if we have a custom error style for this style, otherwise fallback to the core error style
		$args = array(
			'lang' => $this->lang,
			'error_style' => \Aura\styles::get_custom_file('error.css'),
			'includes_dir' => \Aura\styles::get_core_path(),
			'page_title' => $this->functions->generate_page_title(array($this->config['o_board_title'], $title)),
			'errno' => $errno,
			'errstr' => $errstr,
			'errfile' => $errfile,
			'errline' => $errline,
			'index' => $this->registry->get('\Aura\links')->aura_link($this->url['index']),
		);

		if ($this->error_type == '1')
		{
			ob_start();
			dump($errparameters);
			$debug = trim(ob_get_contents());
			ob_end_clean();

			$tpl = $this->template->load('db_error.tpl');
			$this->template->output($tpl,
				array_merge(
					$args, array(
						'error' => $errstr,
						'sql' => $errsql,
						'debug' => $debug,
					)
				), false, false
			);
		}
		else
		{	$file = ($this->error_type == '0') ? 'server_error.tpl' : 'template_error.tpl';
			$tpl = $this->template->load($file);
			$this->template->output($tpl, $args, false, false);
		}

		registry::terminate();
	}

	protected function parse_exception($str)
	{
		if (preg_match("/message '(.*)' in (.*):([0-9]+)/", $str, $matches))
			return $matches;

		return 'unknown exception';
	}
}