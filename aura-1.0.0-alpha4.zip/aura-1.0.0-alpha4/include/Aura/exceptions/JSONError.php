<?php
namespace Aura\exceptions;
use Exception;

class JSONError extends Exception
{
	public function __construct($message, $sql = '', $parameters = array())
	{
		$message = array(
			'message' => $message,
			'sql' => $sql,
			'parameters' => $parameters,
			'trace' => $this->getTrace(),
		);

		parent::__construct(json_encode($message), $this->getCode(), $this->getPrevious());
	}
}