<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

namespace Aura\handlers;
use AuraClass;
use styles;
use registry;

class redirect extends AuraClass implements \Aura\interfaces\redirect_interface
{
	//
	// Display $message and redirect user to $destination_url
	//
	public function show($destination_url, $message)
	{
		// Prefix with base_url (unless there's already a valid URI)
		if (strpos($destination_url, 'http://') !== 0 && strpos($destination_url, 'https://') !== 0 && strpos($destination_url, '/') !== 0)
			$destination_url = $this->functions->get_base_url().'/'.$destination_url;

		// Do a little spring cleaning
		$destination_url = preg_replace('%([\r\n])|(\%0[ad])|(;\s*data\s*:)%i', '', $destination_url);

		// If the delay is 0 seconds, we might as well skip the redirect all together
		if ($this->config['o_redirect_delay'] == '0')
		{
			$this->db->end_transaction();

			registry::send_header('Location: '.str_replace('&amp;', '&', $destination_url));
			registry::terminate();
		}

		// Send no-cache headers
		registry::send_headers();

		$this->template->header = array(
			'active_page' => 'redirect',
		);

		$tpl = $this->template->load('redirect.tpl');
		$this->template->output($tpl,
			array(
				'destination_url' => $destination_url,
				'message' => $message,
				'queries' => ($this->config['o_show_queries'] == '1') ? $this->display_saved_queries() : '',
				'style_core' => \Aura\styles::get_core_path(),
				'page_title' => $this->functions->generate_page_title(array($this->config['o_board_title'], $this->lang->t('Redirecting'))),
				'css_url' => \Aura\styles::get_style_root().$this->user['style'],
			), false, false
		);
		
		$this->db->end_transaction();

		registry::terminate();
	}
}