<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

namespace Aura\handlers;
use AuraClass;
use styles;

class maintenance extends AuraClass implements Aura\interfaces\maintenance_interface
{
	//
	// Display a message when board is in maintenance mode
	//
	public function show()
	{
		registry::custom_header('503 Service Unavailable');
		registry::send_headers('html');

		// Deal with newlines, tabs and multiple spaces
		$pattern = array("\t", '  ', '  ');
		$replace = array('&#160; &#160; ', '&#160; ', ' &#160;');
		$message = str_replace($pattern, $replace, $this->config['o_maintenance_message']);

		$tpl = $this->template->load('maintenance.tpl');
		$this->template->output($tpl,
			array(
				'message' => $message,
				'style_core' => \Aura\styles::get_core_path(),
				'page_title' => $this->functions->generate_page_title(array($this->config['o_board_title'], $this->lang->t('Maintenance'))),
				'style' => \Aura\styles::get_style_root().$this->user['style'],
			), false, false
		);

		// End the transaction
		$this->db->end_transaction();

		registry::terminate();
	}
}