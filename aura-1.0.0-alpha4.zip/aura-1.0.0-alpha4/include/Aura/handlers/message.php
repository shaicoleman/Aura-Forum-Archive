<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

namespace Aura\handlers;
use AuraClass;
use registry;

class message extends AuraClass implements \Aura\interfaces\message_interface
{
	//
	// Display a message
	//
	public function show($message, $no_back_link = false, $http_status = null, $admin_console = false)
	{
		// Did we receive a custom header?
		if (!is_null($http_status))
			registry::custom_header($http_status);

		// If we failed on an AJAX request, we don't want to send HTML
		if (defined('AURA_AJAX_REQUEST'))
			registry::terminate($message);

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Info')),
			'active_page' => 'index',
			'admin_console' => $admin_console,
		);

		$this->template->footer = array(
			'admin_console' => $admin_console,
		);

		$tpl = $this->template->load('message.tpl');
		$this->template->output($tpl, 
			array(
				'message' => $message,
				'no_back_link' => $no_back_link,
			)
		);

		registry::terminate();
	}
}