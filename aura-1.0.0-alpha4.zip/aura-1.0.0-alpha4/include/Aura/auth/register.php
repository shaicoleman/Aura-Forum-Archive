<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

namespace Aura\auth;
use AuraClass;

class register extends AuraClass
{
	//
	// Check username
	//
	function check_username($username, $errors, $exclude_id = null)
	{
		// Include UTF-8 function
		require_once AURA_ROOT.'include/lib/utf8/strcasecmp.php';

		// Convert multiple whitespace characters into one (to prevent people from registering with indistinguishable usernames)
		$username = preg_replace('%\s+%s', ' ', $username);

		// Validate username
		if (aura_strlen($username) < 2)
			$errors[] = $this->lang->t('Username too short');
		else if (aura_strlen($username) > 25) // This usually doesn't happen since the form element only accepts 25 characters
			$errors[] = $this->lang->t('Username too long');
		else if (!strcasecmp($username, 'Guest') || !utf8_strcasecmp($username, $this->lang->t('Guest')))
			$errors[] = $this->lang->t('Username guest');
		else if (preg_match('%[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}%', $username) || preg_match('%((([0-9A-Fa-f]{1,4}:){7}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){6}:[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){5}:([0-9A-Fa-f]{1,4}:)?[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){4}:([0-9A-Fa-f]{1,4}:){0,2}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){3}:([0-9A-Fa-f]{1,4}:){0,3}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){2}:([0-9A-Fa-f]{1,4}:){0,4}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){6}((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|(([0-9A-Fa-f]{1,4}:){0,5}:((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|(::([0-9A-Fa-f]{1,4}:){0,5}((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|([0-9A-Fa-f]{1,4}::([0-9A-Fa-f]{1,4}:){0,5}[0-9A-Fa-f]{1,4})|(::([0-9A-Fa-f]{1,4}:){0,6}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){1,7}:))%', $username))
			$errors[] = $this->lang->t('Username IP');
		else if ((strpos($username, '[') !== false || strpos($username, ']') !== false) && strpos($username, '\'') !== false && strpos($username, '"') !== false)
			$errors[] = $this->lang->t('Username reserved chars');
		else if (preg_match('%(?:\[/?(?:b|u|s|ins|del|em|i|h|colou?r|quote|code|img|url|email|list|\*|topic|post|forum|user)\]|\[(?:img|url|quote|list)=)%i', $username))
			$errors[] = $this->lang->t('Username BBCode');

		// Check username for any censored words
		if ($this->config['o_censoring'] == '1' && $this->registry->get('\Aura\message\bbcode')->censor_words($username) != $username)
			$errors[] = $this->lang->t('Username censor');

		$where_cond = '(UPPER(username)=UPPER(:username) OR UPPER(username)=UPPER(:username2)) AND id>1';

		$data = array(
			':username'	=> $username,
			':username2' => ucp_preg_replace('%[^\p{L}\p{N}]%u', '', $username),
		);

		// Check that the username (or a too similar username) is not already registered
		if (!is_null($exclude_id))
		{
			$where_cond .= ' AND id!=:id';
			$data[':id'] = $exclude_id;
		}

		$ps = $this->db->select('users', 'username', $data, $where_cond);
		if ($ps->rowCount())
		{
			$busy = $ps->fetchColumn();
			$errors[] = $this->lang->t('Username dupe 1').' '.$busy.'. '.$this->lang->t('Username dupe 2');
		}

		// Check username for any banned usernames
		foreach ($this->registry->bans as $cur_ban)
		{
			if ($cur_ban['username'] != '' && utf8_strtolower($username) == utf8_strtolower($cur_ban['username']))
			{
				$errors[] = $this->lang->t('Banned username');
				break;
			}
		}

		return $errors;
	}

	//
	// Validates a password against the forum password requirements
	//
	function validate_password($password1, $password2)
	{
		$errors = array();
		if (aura_strlen($password1) < $this->config['o_password_min_length'])
			$errors[] = $this->lang->t('Password too short', $this->config['o_password_min_length']);
		else if (!aura_hash_equals($password1, $password2))
			$errors[] = $this->lang->t('Passwords do not match');
		else if (aura_strlen(preg_replace('/[^0-9]/', '', $password1)) < $this->config['o_password_min_digits'])
			$errors[] = $this->lang->t('Password no digits', $this->config['o_password_min_digits']);
		else if (aura_strlen(preg_replace('/[^A-Z]/', '', $password1)) < $this->config['o_password_min_uppercase'])
			$errors[] = $this->lang->t('Password no uppercase', $this->config['o_password_min_uppercase']);
		else if (utf8_strlen(preg_replace('/[0-9A-Za-z]/', '', $password1)) < $this->config['o_password_min_symbols'])
			$errors[] = $this->lang->t('Password no symbols', $this->config['o_password_min_symbols']);

		return $errors;
	}
}