<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

namespace Aura\auth;
use AuraClass;

class forum extends AuraClass
{
	//
	// For forum passwords, show this...
	//
	public function show_forum_login_box($id)
	{
		$required_fields = array('req_password' => $this->lang->t('Password'));
		$focus_element = array('request_pass', 'req_password');

		$data = array(
			':id'	=>	$id,
		);
		
		$ps = $this->db->select('forums', 'forum_name', $data, 'id=:id');
		$forum_name = \Aura\url\url::replace($ps->fetchColumn());
		
		$redirect_url = $this->registry->get('\Aura\auth\login')->validate_redirect(get_current_url(), null);

		if (!isset($redirect_url))
			$redirect_url = $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['forum'], array($id, $forum_name));
		else if (preg_match('%index\.php\?app=forums&act=viewtopic&pid=(\d+)$%', $redirect_url, $matches))
			$redirect_url .= '#p'.$matches[1];

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Info')),
			'active_page' => 'index',
		);

		$tpl = $this->template->load('forum_password.tpl');
		$this->template->output($tpl,
			array(
				'form_action' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['forum'], array($id, $forum_name)),
				'csrf_token' => $this->registry->get('\Aura\auth\csrf')->generate('viewforum'),
				'redirect_url' => $redirect_url,
			)
		);

		registry::terminate();
	}

	//
	// Check if given forum password is indeed valid
	//
	public function validate_login_attempt($id)
	{
		$this->registry->get('\Aura\auth\csrf')->confirm('viewforum');

		$password = isset($_POST['req_password']) ? utf8_trim($_POST['req_password']) : '';
		$redirect_url = $this->registry->get('\Aura\auth\login')->validate_redirect($_POST['redirect_url'], $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['index'])); // If we've tampered, or maybe something just went wrong, send them back to the board index
		$data = array(
			':id' => $id,
		);

		$ps = $this->db->select('forums', 'password, salt, forum_name AS name', $data, 'id=:id');
		$cur_forum = $ps->fetch();

		if ($this->config['o_login_queue'] == '1')
		{
			$data = array(
				':username' => $cur_forum['name'],
				':timeout' => (TIMEOUT * 1000),
			);

			$ps = $this->db->select('login_queue', 'COUNT(*) AS overall, COUNT(IF(username = :username, TRUE, NULL)) AS user', $data, 'last_checked > NOW() - INTERVAL :timeout MICROSECOND');
			$count = $ps->fetch();

			if (!$count)
				$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Unable to query size'));
			else if ($count['overall'] >= $this->config['o_queue_size'] || $count['user'] >= $this->config['o_max_attempts'])
				$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Login queue exceeded'));	

			$insert = array(
				'ip_address' => get_remote_address(),
				'username' => $cur_forum['name'],
			);

			$this->db->insert('login_queue', $insert) or $this->registry->get('\handlers\message')->show($this->lang->t('IP address in queue'));
			$attempt = $this->db->lastInsertId($this->db->prefix.'login_queue');

			// This time, while() is actually in our favour. Yes, I know!
			while (!$this->registry->get('\Aura\auth\login')->check_queue($cur_forum['name'], $attempt))
				usleep(250 * 1000);

			//Force delay between logins, remove dead attempts
			usleep(ATTEMPT_DELAY * 1000);

			$data = array(
				':id' => $attempt,
				':timeout' => (TIMEOUT * 1000),
			);

			$this->db->delete('login_queue', 'id=:id OR last_checked < NOW() - INTERVAL :timeout MICROSECOND', $data);
		}

		if (aura_hash_equals($cur_forum['password'], aura_hash($password.aura_hash($cur_forum['salt']))))
		{
			$this->registry->get('\Aura\cookie\cookie')->set_forum_login_cookie($id, $cur_forum['password']);
			$this->registry->get('\Aura\handlers\redirect')->show($redirect_url, $this->lang->t('Forum password redirect'));
		}
		else
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Incorrect password'));
	}
}