<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

namespace Aura\auth;
use AuraClass;
use registry;

class http_auth extends AuraClass
{
	public function check_authentication()
	{
		if ($this->config['o_http_authentication'] == '1')
		{
			if (!isset($_SERVER['PHP_AUTH_USER']) && !isset($_SERVER['PHP_AUTH_PW']))
				$this->send_authentication();
			else if (isset($_SERVER['PHP_AUTH_USER']) && isset($_SERVER['PHP_AUTH_PW']))
			{
				$form_username = utf8_trim($_SERVER['PHP_AUTH_USER']);
				$form_password = utf8_trim($_SERVER['PHP_AUTH_PW']);
				
				$data = array(
					':id' => $this->user['id'],
					':username'	=> $form_username,
				);

				$ps = $this->db->select('users', 'password, salt', $data, 'username=:username AND id=:id');
				if (!$ps->rowCount())
					$this->send_authentication();
				else
				{
					$cur_user = $ps->fetch();
					if (!aura_hash_equals($cur_user['password'], aura_hash($form_password.$cur_user['salt'])))
						$this->send_authentication();
				}
			}
		}
	}

	public function send_authentication()
	{
		registry::send_header('WWW-Authenticate: Basic realm="'.$this->lang->t('Aura admin CP').'"');
		registry::custom_header('401 Unauthorized');

		$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Unauthorised'));
	}
}