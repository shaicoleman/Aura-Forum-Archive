<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

namespace Aura\auth;
use AuraClass;

class login extends AuraClass
{
	//
	// Validate the given redirect URL, use the fallback otherwise
	//
	function validate_redirect($redirect_url, $fallback_url)
	{
		$referrer = parse_url(strtolower($redirect_url));

		// Make sure the host component exists
		if (!isset($referrer['host']))
			$referrer['host'] = '';

		// Remove www subdomain if it exists
		if (strpos($referrer['host'], 'www.') === 0)
			$referrer['host'] = substr($referrer['host'], 4);

		// Make sure the path component exists
		if (!isset($referrer['path']))
			$referrer['path'] = '';

		$valid = parse_url(strtolower($this->functions->get_base_url()));

		// Remove www subdomain if it exists
		if (strpos($valid['host'], 'www.') === 0)
			$valid['host'] = substr($valid['host'], 4);

		// Make sure the path component exists
		if (!isset($valid['path']))
			$valid['path'] = '';

		if ($referrer['host'] == $valid['host'] && preg_match('%^'.preg_quote($valid['path'], '%').'/(.*?)\.php%i', $referrer['path']))
			return $redirect_url;
		else
			return $fallback_url;
	}

	//
	//	Generate a one time use login key to set in the cookie
	//
	function generate_login_key($uid = 1)
	{
		$key = $this->registry->get('\Aura\auth\password')->generate(60);

		$data = array(
			':key'	=>	$key,
		);
		
		$ps = $this->db->select('users', 1, $data, 'login_key=:key');
		if ($ps->rowCount()) // There is already a key with this string (keys are unique)
			$this->generate_login_key();
		else
		{
			$data = array(
				':id'	=>	($uid !=1) ? $uid : $this->user['id'],
			);
			
			$update = array(
				'login_key'	=>	$key,
			);

			$this->db->update('users', $update, 'id=:id', $data);
			return $key;
		}
	}

	/*
	 * Review the login queue and update it
	 */
	function check_queue($form_username, $attempt)
	{
		$data = array(
			':timeout' => (TIMEOUT * 1000),
			':username' => $form_username,
		);

		$ps = $this->db->select('login_queue', 'id', $data, 'last_checked > NOW() - INTERVAL :timeout MICROSECOND AND username=:username', 'id ASC LIMIT 1');
		$id = $ps->fetchColumn();

		// Due to the fact we're not updating with data, we can't use the update() method. Instead, we have to use run() to avoid the string 'CURRENT_TIMESTAMP' being the value entered.
		$this->db->run('UPDATE '.$this->db->prefix.'login_queue SET last_checked = CURRENT_TIMESTAMP WHERE id=? LIMIT 1', array($attempt));
		return ($id == $attempt) ? true : false;
	}
}