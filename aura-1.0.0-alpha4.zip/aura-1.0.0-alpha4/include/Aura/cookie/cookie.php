<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

namespace Aura\cookie;
use AuraClass;

class cookie extends AuraClass
{
	//
	// Set a cookie, Aura style!
	// Wrapper for forum_setcookie
	//
	function aura_setcookie($user_id, $password_hash, $expire)
	{
		$this->forum_setcookie($this->config['o_cookie_name'], $user_id.'|'.hash_hmac('sha512', $password_hash, $this->config['o_cookie_seed'].'_password_hash').'|'.$expire.'|'.hash_hmac('sha512', $user_id.'|'.$expire, $this->config['o_cookie_seed'].'_cookie_hash'), $expire);
	}

	//
	// Set a cookie, Aura style!
	//
	function forum_setcookie($name, $value, $expire)
	{
		if ($expire - CURRENT_TIMESTAMP - $this->config['o_timeout_visit'] < 1)
			$expire = 0;

		// Enable sending of a P3P header
		header('P3P: CP="CUR ADM"');
		setcookie($name, $value, $expire, $this->config['o_cookie_path'], $this->config['o_cookie_domain'], $this->config['o_cookie_secure'], true);
	}

	/**
	 * Set a forum login cookie
	 */
	function set_forum_login_cookie($id, $forum_password)
	{
		$cookie_data = isset($_COOKIE[$this->config['o_cookie_name'].'_forums']) ? $_COOKIE[$this->config['o_cookie_name'].'_forums'] : '';
		if (!$cookie_data || strlen($cookie_data) > FORUM_MAX_COOKIE_SIZE)
			$cookie_data = '';

		$cookie_data = unserialize($cookie_data);
		$salt = random_key(64, true);
		$cookie_hash = aura_hash($forum_password.aura_hash($salt));
		$cookie_data[$id] = array('hash' => $cookie_hash, 'salt' => $salt);

		$this->forum_setcookie($this->config['o_cookie_name'].'_forums', serialize($cookie_data), CURRENT_TIMESTAMP + $this->config['o_timeout_visit']);
		$_COOKIE[$this->config['o_cookie_name'].'_forums'] = serialize($cookie_data);
	}

	/**
	 * Check a forum login cookie
	 */
	public function check_forum_login_cookie($id, $forum_password, $return = false)
	{
		$cookie_data = isset($_COOKIE[$this->config['o_cookie_name'].'_forums']) ? $_COOKIE[$this->config['o_cookie_name'].'_forums'] : '';
		if (!$cookie_data || strlen($cookie_data) > FORUM_MAX_COOKIE_SIZE)
			$cookie_data = '';

		// If it's empty, define as a blank array to avoid 'must be a boolean' error
		$cookie_data = ($cookie_data !== '') ? unserialize($cookie_data) : array();
		if (!isset($cookie_data[$id]))
		{
			if (!$return)
				$this->registry->get('\Aura\auth\forum')->show_forum_login_box($id);
			else
				return false;
		}
		else
		{
			if ($cookie_data[$id]['hash'] !== aura_hash($forum_password.aura_hash($cookie_data[$id]['salt'])))
			{
				if (!$return)
					$this->registry->get('\Aura\auth\forum')->show_forum_login_box($id);
				else
					return false;
			}
			else
				return true;
		}
	}
}