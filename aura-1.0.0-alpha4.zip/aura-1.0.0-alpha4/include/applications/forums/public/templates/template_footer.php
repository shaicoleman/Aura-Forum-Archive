<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

namespace Aura\templates;
use template_element;
use registry;
use Aura\styles;

// Make sure no one attempts to run this script "directly"
if (!defined('config::SESSION'))
	exit;

class template_footer extends template_element implements \Aura\interfaces\template_element_interface
{
	public function fetch_data()
	{
		$controls = $links = array();
		if (isset($this->data['footer_style']) && ($this->data['footer_style'] == 'viewforum' || $this->data['footer_style'] == 'viewtopic') && $this->data['is_admmod'])
		{
			$this->data['p'] = isset($this->data['p']) ? $this->data['p'] : '';
			if ($this->data['footer_style'] == 'viewforum')
				$controls[] = array('link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['moderate_forum_p'], array($this->data['forum_id'], $this->data['p'])), 'lang' => $this->lang->t('Moderate forum'));
			else if ($this->data['footer_style'] == 'viewtopic')
			{
				if ($this->data['cur_topic']['archived'] != '1')
				{
					$controls[] = array('link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['moderate_topic_p'], array($this->data['forum_id'], $this->data['id'], $this->data['p'])), 'lang' => $this->lang->t('Moderate topic'), 'num_pages' => $this->data['num_pages'], 'moderate_all' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['moderate_all'], array($this->data['forum_id'], $this->data['id'])), 'all' => $this->lang->t('All'));
					$controls[] = array('link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['move'], array($this->data['forum_id'], $this->data['id'], $this->data['csrf_token'])), 'lang' => $this->lang->t('Move topic'));

					if ($this->data['cur_topic']['closed'] == '1')
						$controls[] = array('link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['open'], array($this->data['forum_id'], $this->data['id'], $this->data['csrf_token'])), 'lang' => $this->lang->t('Open topic'));
					else
						$controls[] = array('link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['close'], array($this->data['forum_id'], $this->data['id'], $this->data['csrf_token'])), 'lang' => $this->lang->t('Close topic'));

					if ($this->data['cur_topic']['sticky'] == '1')
						$controls[] = array('link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['unstick'], array($this->data['forum_id'], $this->data['id'], $this->data['csrf_token'])), 'lang' => $this->lang->t('Unstick topic'));
					else
						$controls[] = array('link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['stick'], array($this->data['forum_id'], $this->data['id'], $this->data['csrf_token'])), 'lang' => $this->lang->t('Stick topic'));

					$controls[] = array('link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['archive'], array($this->data['forum_id'], $this->data['id'], $this->data['csrf_token'])), 'lang' => $this->lang->t('Archive topic'));
					$controls[] = array('link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['moderate_multi'], array($this->data['forum_id'], $this->data['id'], $this->data['csrf_token'])), 'lang' => $this->lang->t('More moderation actions'));
				}
				else if ($this->user['is_admin'])
					$controls[] = array('link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['unarchive'], array($this->data['forum_id'], $this->data['id'], $this->data['csrf_token'])), 'lang' => $this->lang->t('Unarchive topic'));
			}
		}

		// Display the "Jump to" drop list
		if ($this->config['o_quickjump'] == '1')
		{
			ob_start();
			// Load cached quick jump
			$this->cache->get('quickjump', array($this->user['g_id']), true, true);
			require $this->cache->cache_dir.'/templates/'.$this->user['style'].'/cache_quickjump_'.$this->user['g_id'].'.php';

			$quickjump_tpl = trim(ob_get_contents());
			ob_end_clean();
		}
		else
			$quickjump_tpl = '';

		$feed = array();
		if (isset($this->data['footer_style']) && $this->data['footer_style'] == 'warnings')
		{
			$links[] = array('url' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['warnings']), 'lang' => $this->lang->t('Show warning types'));
			
			if ($this->user['is_admmod'])
				$links[] = array('url' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['warnings_recent']), 'lang' => $this->lang->t('Show recent warnings'));
		}
		elseif (isset($this->data['footer_style']) && ($this->data['footer_style'] == 'index' || $this->data['footer_style'] == 'viewforum' || $this->data['footer_style'] == 'viewtopic') && ($this->config['o_feed_type'] == '1' || $this->config['o_feed_type'] == '2'))
		{
			switch ($this->data['footer_style'])
			{
				case 'index':
					if ($this->config['o_feed_type'] == '1')
					{
						$feed = array(
							'type' => 'rss',
							'link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['index_rss']),
							'lang' => $this->lang->t('RSS active topics feed'),
						);
					}
					else if ($this->config['o_feed_type'] == '2')
					{
						$feed = array(
							'type' => 'atom',
							'link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['index_atom']),
							'lang' => $this->lang->t('Atom active topics feed'),
						);
					}
				break;
				case 'viewforum':
					if ($this->config['o_feed_type'] == '1')
					{
						$feed = array(
							'type' => 'rss',
							'link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['forum_rss'], array($this->data['id'])),
							'lang' => $this->lang->t('RSS forum feed'),
						);
					}
					else if ($this->config['o_feed_type'] == '2')
					{
						$feed = array(
							'type' => 'atom',
							'link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['forum_atom'], array($this->data['id'])),
							'lang' => $this->lang->t('Atom forum feed'),
						);
					}			
				break;
				case 'viewtopic':
					if ($this->config['o_feed_type'] == '1')
					{
						$feed = array(
							'type' => 'rss',
							'link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['topic_rss'], array($this->data['id'])),
							'lang' => $this->lang->t('RSS topic feed'),
						);
					}
					else if ($this->config['o_feed_type'] == '2')
					{
						$feed = array(
							'type' => 'atom',
							'link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['topic_atom'], array($this->data['id'])),
							'lang' => $this->lang->t('Atom topic feed'),
						);
					}			
				break;
			}
		}

		// Display debug info (if enabled/defined)
		if ($this->config['o_debug_mode'] == '1')
		{
			// Calculate script generation time
			$time_diff = sprintf('%.3f', microtime(true) - registry::$aura_start);
			$debug_info = $this->lang->t('Querytime', $time_diff, $this->db->get_num_queries());

			if (function_exists('memory_get_usage'))
			{
				$debug_info .= ' - '.$this->lang->t('Memory usage', $this->functions->file_size(memory_get_usage()));

				if (function_exists('memory_get_peak_usage'))
					$debug_info .= ' '.$this->lang->t('Peak usage', $this->functions->file_size(memory_get_peak_usage()));
			}
		}
		else
			$debug_info = '';

		$queries = ($this->config['o_show_queries'] == '1') ? $this->functions->display_saved_queries() : '';

		// End the transaction
		$this->db->end_transaction();

		$style_path = \Aura\styles::get_style_path().'/'.$this->user['style'].'/templates/';
		$tpl = (isset($this->data['admin_console']) && $this->data['admin_console'] && (file_exists($style_path.'admin/footer.tpl') || $this->user['style'] == $this->config['o_default_style'] && !file_exists($style_path)) ? 'admin/footer.tpl' : 'footer.tpl');

		return array(
			'tpl_file' => $tpl,
			'footer_style' => isset($this->data['footer_style']) ? $this->data['footer_style'] : '',
			'controls' => $controls,
			'quickjump' => $quickjump_tpl,
			'links' => $links,
			'feed' => $feed,
			'debug_info' => $debug_info,
			'queries' => $queries,
			'admin_console' => isset($this->data['admin_console']) && $this->data['admin_console'] ? true : false,
		);
	}
}