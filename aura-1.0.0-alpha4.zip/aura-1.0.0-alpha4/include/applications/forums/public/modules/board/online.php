<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class online_controller extends base_controller
{
	/**
	 * Main entry point- run the app!
	 */
	public function execute()
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('online.immediate');

		if ($this->user['g_read_board'] == '0')
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No view'), false, '403 Forbidden');

		if ($this->user['is_bot'])
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'));

		// Load the online language file
		$this->lang->load('online');

		// Load the search language file
		$this->lang->load('search');

		if ($this->user['g_view_users'] == '0')
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		$this->registry->get('\Aura\extensions\hooks')->fire('online.authorised');

		$ps = $this->db->select('online', 'COUNT(user_id)', array(), 'idle=0');
		$num_online = $ps->fetchColumn();

		// Determine the post offset (based on $_GET['p'])
		$num_pages = ceil(($num_online) / $this->user['disp_posts']);

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Viewing users online')),
			'active_page' => 'online',
			'p' => (!isset($_GET['p']) || $_GET['p'] <= 1 || $_GET['p'] > $num_pages) ? 1 : intval($_GET['p']),
		);

		$this->template->header = $this->registry->get('\Aura\extensions\hooks')->fire('online.header', $this->template->header);

		// Grab the users online
		$start_from = $this->user['disp_posts'] * ($this->template->header['p'] - 1);
		$online = $this->fetch_users_online($start_from);

		$args = $this->registry->get('\Aura\extensions\hooks')->fire('online.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('online.tpl');
		$this->template->output($tpl,
			array_merge(
				array(
					'pagination' => $this->registry->get('\Aura\pagination')->paginate($num_pages, $this->template->header['p'], $this->rewrite->url['online']),
					'users_online' => $online,
					'num_pages' => $num_pages,
				),
				$args
			)
		);
	}

	/**
	 * Fetch a list of the current users online
	 */
	protected function fetch_users_online($start_from)
	{
		$bots = $online = array();
		$data = array(
			':start' => $start_from,
			':limit' => $this->user['disp_posts'],
		);

		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'users',
				'as' => 'u',
				'on' => 'o.user_id=u.id',
			),
		);

		$ps = $this->db->join('online', 'o', $join, 'o.user_id, o.ident, o.currently, o.logged, u.group_id', $data, 'o.idle=0 LIMIT :start,:limit');
		foreach ($ps as $user_online)
		{
			if (strpos($user_online['ident'], '[Bot]') !== false)
			{
				$name = explode('[Bot]', $user_online['ident']);
				if (empty($bots[$name[1]])) $bots[$name[1]] = 1;
					else ++$bots[$name[1]];

				foreach ($bots as $online_name => $online_id)
				   $ident = $online_name.' [Bot]';
			}
			else
			{
				if ($user_online['user_id'] == 1)
					$ident = ucfirst($this->lang->t('Guest'));
				else
					$ident = $user_online['ident'];
			}

			$time = $this->registry->get('\Aura\aura_time')->format_time_difference($user_online['logged']);
			$online[] = array(
				'username' => $this->functions->colourise_group($ident, $user_online['group_id'], $user_online['user_id']),
				'location' => $this->registry->get('\Aura\online')->fetch_user_location($user_online['currently']),
				'last_active' => ($time > 0 ? $time : $this->lang->t('Just now')),
			);

			$online = $this->registry->get('\Aura\extensions\hooks')->fire('online.header', $online);
		}

		return $online;
	}
}