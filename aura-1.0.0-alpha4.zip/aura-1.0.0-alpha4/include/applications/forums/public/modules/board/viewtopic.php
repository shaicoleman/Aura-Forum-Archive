<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class viewtopic_controller extends base_controller
{
	/*
	 * Main entry point of the app- view the topic
	 */
	public function execute()
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('viewtopic.immediate');

		if ($this->user['g_read_board'] == '0')
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No view'), false, '403 Forbidden');

		$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
		$pid = isset($_GET['pid']) ? intval($_GET['pid']) : 0;
		if ($id < 1 && $pid < 1)
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		// Load the viewtopic language file
		$this->lang->load('topic');

		// If a post ID is specified we determine topic ID and page number so we can redirect to the correct message
		if ($pid)
		{
			$data = array(
				':id' => $pid,
			);

			$ps = $this->db->select('posts', 'topic_id, posted', $data, 'id=:id AND approved=1 AND deleted=0');
			if (!$ps->rowCount())
				$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');
			else
				list($id, $posted) = $ps->fetch(PDO::FETCH_NUM);

			$data = array(
				':id' => $id,
				':posted' => $posted,
			);

			// Determine on which page the post is located (depending on $this->user['disp_posts'])
			$ps = $this->db->select('posts', 'COUNT(id)', $data, 'topic_id=:id AND posted<:posted AND approved=1 AND deleted=0');
			$num_posts = $ps->fetchColumn() + 1;

			$_GET['p'] = ceil($num_posts / $this->user['disp_posts']);
		}

		$cur_topic = $this->fetch_topic($id);

		// Sort out who the moderators are and if we are currently a moderator (or an admin)
		$moderators = $this->cache->get('moderators');
		$is_admmod = ($this->user['is_admin'] || ($this->user['g_moderator'] == '1' && $this->user['g_global_moderator'] == '1' || isset($moderators[$cur_topic['forum_id']]['u'.$this->user['id']]) || isset($moderators[$cur_topic['forum_id']]['g'.$this->user['g_id']]))) ? true : false;

		$admin_ids = ($is_admmod) ? $this->cache->get('admins') : array();

		if ($cur_topic['password'] != '')
				$this->registry->get('\Aura\cookie\cookie')->check_forum_login_cookie($cur_topic['forum_id'], $cur_topic['password']);

		if ($cur_topic['protected'] == '1' && $this->user['username'] != $cur_topic['poster'] && !$is_admmod)
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'));

		if ($this->config['o_archiving'] == '1' && $cur_topic['archived'] == '0')
		{
			if ($cur_topic['archived'] !== '2')
			{
				$archive_rules = unserialize($this->config['o_archive_rules']);
				$cur_topic['archived'] = $this->registry->get('\Aura\topics\archive')->check_archive_rules($archive_rules, $id);
			}
		}

		// Add/update this topic in our list of tracked topics
		if (!$this->user['is_guest'])
		{
			$tracked_topics = $this->registry->get('\Aura\cookie\tracked')->get_tracked_topics();
			$tracked_topics['topics'][$id] = CURRENT_TIMESTAMP;
			$this->registry->get('\Aura\cookie\tracked')->set_tracked_topics($tracked_topics);
		}

		// Preg replace is slow!
		$url_subject = \Aura\url\url::replace($cur_topic['subject']);
		$url_forum = \Aura\url\url::replace($cur_topic['forum_name']);

		// Determine the post offset (based on $_GET['p'])
		$num_pages = ceil(($cur_topic['num_replies'] + 1) / $this->user['disp_posts']);

		if ($this->config['o_censoring'] == '1')
			$cur_topic['subject'] = $this->registry->get('\Aura\message\bbcode')->censor_words($cur_topic['subject']);

		// Add relationship meta tags
		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $cur_topic['forum_name'], $cur_topic['subject']),
			'canonical' => array('href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['topic'], array($id, $url_subject)), 'rel' => 'canonical'),
			'p' => (!isset($_GET['p']) || $_GET['p'] <= 1 || $_GET['p'] > $num_pages) ? 1 : intval($_GET['p']),
			'allow_index' => true,
			'active_page' => 'index',
			'reputation' => true,
			'posting' => true,
		);

		$start_from = $this->user['disp_posts'] * ($this->template->header['p'] - 1);

		$quickpost = false;
		if ($this->config['o_quickpost'] == '1' && $cur_topic['archived'] != '1' && ($cur_topic['post_replies'] == '1' || ($cur_topic['post_replies'] == '' && $this->user['g_post_replies'] == '1')) && ($cur_topic['closed'] == '0' || $is_admmod))
		{
			// Load the post language file
			$this->lang->load('post');

			$this->template->header['required_fields'] = array('req_message' => $this->lang->t('Message'));
			if ($this->user['is_guest'])
			{
				$this->template->header['required_fields']['req_username'] = $this->lang->t('Guest name');
				if ($this->config['p_force_guest_email'] == '1')
					$this->template->header['required_fields']['req_email'] = $this->lang->t('Email');
			}

			$quickpost = true;
		}

		if (!$this->user['is_guest'] && $this->config['o_topic_subscriptions'] == '1')
		{
			if ($cur_topic['is_subscribed'])
				$subscription = $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['topic_unsubscribe'], array($id, $this->registry->get('\Aura\auth\csrf')->generate('unsubscribe')));
			else
				$subscription = $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['topic_subscribe'], array($id, $this->registry->get('\Aura\auth\csrf')->generate('subscribe')));
		}
		else
			$subscription = '';

		if ($num_pages > 1)
		{
			if ($this->template->header['p'] > 1)
				$this->template->header['prev'] = array('href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['topic_page'], array($id, $url_subject, ($this->template->header['p'] - 1))), 'rel' => 'prev');
			if ($this->template->header['p'] < $num_pages)
				$this->template->header['next'] = array('href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['topic_page'], array($id, $url_subject, ($this->template->header['p'] + 1))), 'rel' => 'next');
		}

		if ($this->config['o_feed_type'] == '1')
			$this->template->header['feed'] = array('href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['topic_rss'], array($id)), 'type' => 'application/rss+xml', 'rel' => 'alternate', 'title' => $this->lang->t('RSS topic feed'));
		else if ($this->config['o_feed_type'] == '2')
			$this->template->header['feed'] = array('href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['topic_atom'], array($id)), 'type' => 'application/atom+xml', 'rel' => 'alternate', 'title' => $this->lang->t('Atom topic feed'));

		$this->template->header = $this->registry->get('\Aura\extensions\hooks')->fire('viewtopic.header', $this->template->header);
		$csrf_token = $this->registry->get('\Aura\auth\csrf')->generate('viewtopic');
		list($placeholders, $post_ids) = $this->fetch_topic_posts($id, $start_from);

		$render = array (
			'cur_topic' => $cur_topic,
			'is_admmod' => $is_admmod,
			'reply_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['new_reply'], array($id)),
			'csrf_token' => $csrf_token,
			'id' => $id,
			'index_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['index']),
			'forum_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['forum'], array($cur_topic['forum_id'], $url_forum)),
			'topic_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['topic'], array($id, $url_subject)),
			'pagination' => $this->registry->get('\Aura\pagination')->paginate($num_pages, $this->template->header['p'], $this->rewrite->url['topic_paginate'], array($id, $url_subject)),
			'subscription_link' => $subscription,
			'quickpost' => $quickpost,
		);

		// Retrieve the posts (and their respective poster/online status)
		$render = array_merge($render, $this->fetch_polls($id, $cur_topic, $is_admmod));

		$results = array();
		$download = false;
		if ($this->config['o_attachments'] == '1')
		{
			if ($this->user['is_admin'])
				$download = true;
			else if ($cur_topic['download'] != 0 || is_null($cur_topic['download']))
				$download = true;

			$download = $this->registry->get('\Aura\extensions\hooks')->fire('viewtopic.download', $download);
			if ($download)
			{
				$ps = $this->db->select('attachments', 'id, filename, post_id, size, downloads', $post_ids, 'post_id IN ('.implode(',', $placeholders).')', 'post_id');
				foreach ($ps as $cur_attach)
				{
					if (!isset($results[$cur_attach['post_id']]))
						$results[$cur_attach['post_id']] = array();

					$results[$cur_attach['post_id']][$cur_attach['id']] = $cur_attach;
				}
			}
		}

		// Fetch the actual post data for the topic
		$posts = $this->fetch_posts($id, $placeholders, $post_ids, $cur_topic, $is_admmod, $download, $start_from, $admin_ids, $csrf_token);

		$render['posts'] = $posts;
		if ($cur_topic['parent'])
			$render['parent_link'] = $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['forum'], array($cur_topic['parent_forum'], \Aura\url\url::replace($cur_topic['parent'])));

		// Fetch the users online
		$render = array_merge($render, $this->fetch_users_online($cur_topic, $id));

		// Display quick post if enabled
		if ($quickpost)
		{
			$render['quickpost_links'] = array(
				'form_action' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['new_reply'], array($id)),
				'csrf_token' => $this->registry->get('\Aura\auth\csrf')->generate('post'),
				'bbcode' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['help'], array('bbcode')),
				'url' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['help'], array('url')),
				'img' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['help'], array('img')),
				'smilies' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['help'], array('smilies')),
			);
		}

		// Increment "num_views" for topic
		if ($this->config['o_topic_views'] == '1')
			$this->db->run('UPDATE '.$this->db->prefix.'topics SET num_views=num_views+1 WHERE id=:id', array($id));

		$this->template->footer = array(
			'forum_id' => $cur_topic['forum_id'],
			'footer_style' => 'viewtopic',
			'is_admmod' => $is_admmod,
			'id' => $id,
			'num_pages' => $num_pages,
			'cur_topic' => $cur_topic,
			'csrf_token' => $csrf_token,
		);

		$this->template->footer = $this->registry->get('\Aura\extensions\hooks')->fire('viewtopic.footer', $this->template->footer);
		$render = $this->registry->get('\Aura\extensions\hooks')->fire('viewtopic.render', $render);

		$tpl = $this->template->load('topic.tpl');
		$this->template->output($tpl, $render);
	}

	/*
	 * Attempt to locate the newest post (or redirect to the last if we're a guest)
	 */
	 public function unread()
	 {
		if (!$this->user['is_guest'])
		{
			// We need to check if this topic has been viewed recently by the user
			$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
			$tracked_topics = $this->registry->get('\Aura\cookie\tracked')->get_tracked_topics();
			$last_viewed = isset($tracked_topics['topics'][$id]) ? $tracked_topics['topics'][$id] : $this->user['last_visit'];

			$data = array(
				':id'	=>	$id,
				':posted' => $last_viewed,
			);

			$ps = $this->db->select('posts', 'MIN(id)', $data, 'topic_id=:id AND posted>:posted AND approved=1 AND deleted=0');
			$first_new_post_id = $ps->fetchColumn();

			$first_new_post_id = $this->registry->get('\Aura\extensions\hooks')->fire('viewtopic.unreadposts', $first_new_post_id);

			if ($first_new_post_id)
			{
				header('Location: '.$this->registry->get('\Aura\links')->aura_link($this->rewrite->url['post'], array($first_new_post_id)));
				exit;
			}
		}

		$this->registry->get('\Aura\extensions\hooks')->fire('viewtopic.nounreadposts');

		// If there is no unread post, we go straight to the last post
		$this->last();
	}

	/*
	 * Fetch the latest post ID in the topic and redirect back to that post
	 */
	public function last()
	{
		$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
		$data = array(
			':id' => $id,
		);

		$ps = $this->db->select('posts', 'MAX(id)', $data, 'topic_id=:id AND approved=1 AND deleted=0');
		$last_post_id = $ps->fetchColumn();

		$last_post_id = $this->registry->get('\Aura\extensions\hooks')->fire('viewtopic.lastpostid', $last_post_id);
		if ($last_post_id)
		{
			header('Location: '.$this->registry->get('\Aura\links')->aura_link($this->rewrite->url['post'], array($last_post_id)));
			exit;
		}
	}

	/*
	 * Fetch the topic info
	 */
	protected function fetch_topic($id)
	{
		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'forums',
				'as' => 'f',
				'on' => 'f.id=t.forum_id',
			),
			array(
				'type' => 'LEFT',
				'table' => 'topic_subscriptions',
				'as' => 's',
				'on' => '(t.id=s.topic_id AND s.user_id=:id)',
			),
			array(
				'type' => 'LEFT',
				'table' => 'forum_perms',
				'as' => 'fp',
				'on' => '(fp.forum_id=f.id AND fp.group_id=:gid)',
			),
			array(
				'type' => 'LEFT',
				'table' => 'forums',
				'as' => 'pf',
				'on' => 'f.parent_forum=pf.id',
			),
			array(
				'type' => 'LEFT',
				'table' => 'polls',
				'as' => 'p',
				'on' => 't.id=p.topic_id',
			),
		);

		$data = array(
			':gid' => $this->user['g_id'],
			':tid' => $id,
		);

		// Fetch some info about the topic
		if (!$this->user['is_guest'])
		{
			$data[':id'] = $this->user['id'];
			$ps = $this->db->join('topics', 't', $join, 'pf.forum_name AS parent, f.parent_forum, f.protected, t.subject, t.poster, t.closed, t.archived, t.question, t.num_replies, t.sticky, t.first_post_id, t.last_post, p.type, p.options, p.votes, p.voters, p.posted, f.id AS forum_id, f.forum_name, f.use_reputation, f.password, fp.post_replies, fp.download, s.user_id AS is_subscribed', $data, '(fp.read_forum IS NULL OR fp.read_forum=1) AND t.id=:tid AND t.moved_to IS NULL AND t.approved=1 AND t.deleted=0');
		}
		else
		{
			unset($join[1]);
			$ps = $this->db->join('topics', 't', $join, 'pf.forum_name AS parent, f.parent_forum, f.protected, t.subject, t.poster, t.closed, t.archived, t.question, t.num_replies, t.sticky, t.first_post_id, t.last_post, p.type, p.options, p.votes, p.voters, p.posted, f.id AS forum_id, f.forum_name, f.use_reputation, f.password, fp.post_replies, fp.download, 0 AS is_subscribed', $data, '(fp.read_forum IS NULL OR fp.read_forum=1) AND t.id=:tid AND t.moved_to IS NULL AND t.approved=1 AND t.deleted=0');
		}

		if (!$ps->rowCount())
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');
		else
			$cur_topic = $ps->fetch();

		$cur_topic = $this->registry->get('\Aura\extensions\hooks')->fire('viewtopic.fetchtopicinfo', $cur_topic);

		return $cur_topic;
	}

	protected function fetch_topic_posts($id, $start_from)
	{
		$data = array(
			':id' => $id,
		);

		// Retrieve a list of post IDs, LIMIT is (really) expensive so we only fetch the IDs here then later fetch the remaining data
		$ps = $this->db->select('posts', 'id', $data, 'topic_id=:id AND approved=1 AND deleted=0', 'id LIMIT '.$start_from.','.$this->user['disp_posts']);

		$post_ids = array();
		$ps->setFetchMode(PDO::FETCH_COLUMN, 0);
		foreach ($ps as $cur_post_id)
		{
			$post_ids[] = $cur_post_id;
			$placeholders[] = '?';
		}

		$content = array();
		if (empty($post_ids))
			throw new Exception('The post table and topic table are out of sync');

		return array($placeholders, $post_ids);
	}

	protected function fetch_polls($id, $cur_topic, $is_admmod)
	{
		$render = array();
		if ($cur_topic['question'] != '')
		{
			$this->lang->load('poll');

			// Make sure stuff is declared properly
			$options = ($cur_topic['options'] != '') ? unserialize($cur_topic['options']) : array();
			$voters = ($cur_topic['voters'] != '') ? unserialize($cur_topic['voters']) : array();
			$votes = ($cur_topic['votes'] != '') ? unserialize($cur_topic['votes']) : array();
			$total_votes = count($voters);
			$total = $percent = 0;

			$poll_actions = array();
			if ($this->user['username'] == $cur_topic['poster'] && $this->user['g_edit_polls'] == '1' || $is_admmod)
			{
				$poll_actions[] = array('href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['poll_delete'], array($id)), 'class' => 'delete', 'lang' => $this->lang->t('Delete'));
				$poll_actions[] = array('href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['poll_edit'], array($id)), 'class' => 'edit', 'lang' => $this->lang->t('Edit'));

				if ($is_admmod)
					$poll_actions[] = array('href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['poll_reset'], array($id)), 'class' => 'edit', 'lang' => $this->lang->t('Reset'));
			}

			// Check and make sure we can vote
			$can_vote = (!$this->user['is_guest'] && !in_array($this->user['id'], $voters)) ? true : false;

			// Grab the total amount of percent
			for ($i = 0; $i < count($options); $i++)
				$total += (isset($votes[$i])) ? $votes[$i] : 0;

			$render['can_vote'] = $can_vote;
			$render['poll_actions'] = $poll_actions;
			if ($can_vote)
			{
				$render['options'] = $options;
				$render['poll_action'] = $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['poll_vote'], array($id));
			}
			else
			{
				foreach ($options as $key => $value)
				{
					// Prevent division by zero
					if (isset($votes[$key]) && $total != 0)
					{
						$percent =  ($votes[$key] * 100) / $total;
						$percent = floor($percent);
					}
					else
						$percent = 0;

					$percent_int = (isset($votes[$key]) && $percent != 0) ? $percent : 1;
					$percent_vote = (isset($votes[$key])) ? array($percent, $votes[$key]) : array(0, 0);
					$render['options'][$key] = array(
						'value' => $value,
						'percent' => $percent_int,
						'vote' => $percent_vote,
					);

					$render['options'][$key] = $this->registry->get('\Aura\extensions\hooks')->fire('viewtopic.polls.options', $render['options'][$key]);
				}

				$render['total_voters'] = $total_votes;
			}

			$render = $this->registry->get('\Aura\extensions\hooks')->fire('viewtopic.polls.render', $render);
		}

		return $render;
	}

	protected function fetch_posts($id, $placeholders, $post_ids, $cur_topic, $is_admmod, $download, $start_from, $admin_ids, $csrf_token)
	{
		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'users',
				'as' => 'u',
				'on' => 'u.id=p.poster_id',
			),
			array(
				'type' => 'INNER',
				'table' => 'groups',
				'as' => 'g',
				'on' => 'g.g_id=u.group_id',
			),
			array(
				'type' => 'LEFT',
				'table' => 'online',
				'as' => 'o',
				'on' => '(o.user_id=u.id AND o.user_id!=1 AND o.idle=0)',
			),
		);

		$posts = array();
		$parser = $this->registry->get('\Aura\message\parser');
		$post_count = 0; // Keep track of post numbers
		$ps = $this->db->join('posts', 'p', $join, 'u.email, u.use_gravatar, u.title, u.url, u.location, u.signature, u.email_setting, u.num_posts, u.registered, u.admin_note, u.pm_enabled, u.reputation AS poster_reputation, p.id, p.reputation, p.poster AS username, p.poster_id, p.poster_ip, p.poster_email, p.message, p.hide_smilies, p.posted, p.edited, p.edit_reason, p.edited_by, g.g_id, g.g_user_title, g_image, g.g_promote_next_group, g.g_use_pm, o.user_id AS is_online', $post_ids, 'p.id IN ('.implode(',', $placeholders).')', 'p.id');
		foreach ($ps as $cur_post)
		{
			$cur_post = $this->registry->get('\Aura\extensions\hooks')->fire('viewtopic.posts.immediate', $cur_post);

			$user_avatar = '';
			$user_info = array();
			$user_contacts = array();
			$post_actions = array();
			$actions = array();
			$signature = '';

			// If the poster is a registered user
			if ($cur_post['poster_id'] > 1)
			{
				$username = $this->functions->colourise_group($cur_post['username'], $cur_post['g_id'], $cur_post['poster_id']);
				$user_title = $this->registry->get('\Aura\topics\title')->get_title($cur_post);

				if ($this->config['o_censoring'] == '1')
					$user_title = $this->registry->get('\Aura\message\bbcode')->censor_words($user_title);

				if ($this->config['o_avatars'] == '1' && $this->user['show_avatars'] != '0')
					$user_avatar = $this->registry->get('\Aura\avatar')->generate($cur_post['poster_id'], $cur_post['email'], $cur_post['use_gravatar']);

				// We only show location, register date, post count and the contact links if "Show user info" is enabled
				if ($this->config['o_show_user_info'] == '1')
				{
					if ($cur_post['location'] != '')
					{
						if ($this->config['o_censoring'] == '1')
							$cur_post['location'] = $this->registry->get('\Aura\message\bbcode')->censor_words($cur_post['location']);

						$user_info[] = array('title' => $this->lang->t('From'), 'value' => $cur_post['location']);
					}

					$user_info[] = array('title' => $this->lang->t('Registered'), 'value' => $this->registry->get('\Aura\aura_time')->format($cur_post['registered'], true));

					if ($this->config['o_show_post_count'] == '1' || $this->user['is_admmod'])
						$user_info[] = array('title' => $this->lang->t('Posts'), 'value' => $this->functions->forum_number_format($cur_post['num_posts']));

					// Now let's deal with the contact links (Email, URL & PM)
					if ((($cur_post['email_setting'] == '0' && !$this->user['is_guest']) || $this->user['is_admmod']) && $this->user['g_send_email'] == '1')
						$user_contacts[] = array('class' => 'email', 'href' => 'mailto:'.$cur_post['email'], 'title' => $this->lang->t('Email'));
					else if ($cur_post['email_setting'] == '1' && !$this->user['is_guest'] && $this->user['g_send_email'] == '1')
						$user_contacts[] = array('class' => 'email', 'href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['email'], array($cur_post['poster_id'])), 'title' => $this->lang->t('Email'));

					if ($this->config['o_private_messaging'] == '1' && $this->user['g_use_pm'] == '1' && $this->user['pm_enabled'] && $cur_post['g_use_pm'] && $cur_post['pm_enabled'] && $this->user['id'] != $cur_post['poster_id'])
						$user_contacts[] = array('class' => 'email', 'href' =>$this->registry->get('\Aura\links')->aura_link($this->rewrite->url['send_pm'], array($cur_post['poster_id'])), 'title' => $this->lang->t('Send PM'));

					if ($cur_post['url'] != '')
					{
						if ($this->config['o_censoring'] == '1')
							$cur_post['url'] = $this->registry->get('\Aura\message\bbcode')->censor_words($cur_post['url']);

						$user_contacts[] = array('class' => 'website', 'href' => $cur_post['url'], 'rel' => 'nofollow', 'title' => $this->lang->t('Website'));
					}
				}

				$user_contacts = $this->registry->get('\Aura\extensions\hooks')->fire('viewtopic.posts.usercontacts', $user_contacts);
				if ($this->user['is_admin'] || ($this->user['g_moderator'] == '1' && $this->user['g_mod_promote_users'] == '1'))
				{
					if ($cur_post['g_promote_next_group'])
						$user_info[] = array('title' => $this->lang->t('Promote user'), 'href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['profile_promote'], array($cur_post['poster_id'], $cur_post['id'], $csrf_token)));
				}

				if ($this->user['is_admmod'])
				{
					$user_info[] = array('title' => $this->lang->t('IP address logged'), 'href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['get_host'], array($cur_post['id'])), 'label' => $cur_post['poster_ip']);

					if ($cur_post['admin_note'] != '')
						$user_info[] = array('title' => $this->lang->t('Note'), 'value' => $cur_post['admin_note']);
				}

				$user_info = $this->registry->get('\Aura\extensions\hooks')->fire('viewtopic.posts.userinfo', $user_info);
				if ($this->config['o_reputation'] == '1')
				{
					switch(true)
					{
						case $cur_post['poster_id'] == 1:
							$type = 'zero';
						break;
						case $cur_post['poster_reputation'] > '0':
							$type = 'positive';
						break;
						case $cur_post['poster_reputation'] < '0':
							$type = 'negative';
						break;
						default:
							$type = 'zero';
						break;
					}

					$cur_post['poster_reputation'] = array('type' => $type, 'title' => $this->lang->t('reputation', $this->functions->forum_number_format($cur_post['poster_reputation'])));
					if ($cur_topic['use_reputation'] == '1')
					{
						switch(true)
						{
							case $cur_post['reputation'] > '0':
								$type = 'positive';
							break;
							case $cur_post['reputation'] < '0':
								$type = 'negative';
							break;
							default:
								$type = 'zero';
							break;
						}

						if ($cur_post['poster_id'] != 1)
						{
							if ($cur_post['poster_id'] != $this->user['id'] && $this->user['g_rep_enabled'] == '1' && $cur_topic['archived'] !== '1' && ($cur_topic['closed'] == '0' || $is_admmod) && $cur_topic['archived'] != '1')
							{
								$actions = array();
								if ($this->config['o_rep_type'] != 3)
									$actions[] = array('class' => 'voterep votemore', 'src' => 'plus.png', 'onclick' => 1);

								if ($this->config['o_rep_type'] != 2)
									$actions[] = array('class' => 'voterep voteless', 'src' => 'minus.png', 'onclick' => -1);

								if (count($actions) > 0)
									$post_actions[] = array('class' => 'helpful', 'actions' => true, 'title' => (($cur_topic['first_post_id'] == $cur_post['id']) ? $this->lang->t('topic helpful') : $this->lang->t('post helpful')));
							}

							$post_actions[] = array('class' => 'rep', 'span_id' => 'post_rep_'.$cur_post['id'], 'span_class' => 'reputation '.$type, 'title' => $cur_post['reputation']);
						}
					}
				}
			}
			// If the poster is a guest (or a user that has been deleted)
			else
			{
				$username = $this->functions->colourise_group($cur_post['username'], $cur_post['g_id']);
				$user_title = $this->registry->get('\Aura\topics\title')->get_title($cur_post);

				if ($this->user['is_admmod'])
					$user_info[] = array('title' => $this->lang->t('IP address logged'), 'href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['get_host'], array($cur_post['id'])), 'label' => $cur_post['poster_ip']);

				$user_info = $this->registry->get('\Aura\extensions\hooks')->fire('viewtopic.posts.userinfo', $user_info);
				if ($this->config['o_show_user_info'] == '1' && $cur_post['poster_email'] != '' && !$this->user['is_guest'] && $this->user['g_send_email'] == '1')
					$user_contacts[] = array('class' => 'email', 'href' => 'mailto:'.$cur_post['poster_email'], 'title' => $this->lang->t('Email'));

				$user_contacts = $this->registry->get('\Aura\extensions\hooks')->fire('viewtopic.posts.usercontacts', $user_contacts);
			}
			
			if ($cur_post['g_image'] != '')
			{
				$image_path = ($this->config['o_image_group_dir'] != '') ? $this->config['o_image_group_path'] : AURA_ROOT.$this->config['o_image_group_path'].'/';
				$image_dir = ($this->config['o_image_group_dir'] != '') ? $this->config['o_image_group_dir'] : $this->functions->get_base_url().'/'.$this->config['o_image_group_path'].'/';
				$img_size = getimagesize($image_path.$cur_post['g_id'].'.'.$cur_post['g_image']);
				$group_image = array('src' => $image_dir.$cur_post['g_id'].'.'.$cur_post['g_image'], 'size' => $img_size[3], 'alt' => $cur_post['g_user_title']);

				$group_image = $this->registry->get('\Aura\extensions\hooks')->fire('viewtopic.posts.groupimage', $group_image);
			}
			else
				$group_image = array();

			// Generation post action array (quote, edit, delete etc.)
			if ($cur_topic['archived'] != '1')
			{
				if (!$is_admmod)
				{
					if (!$this->user['is_guest'] && $cur_topic['archived'] == '0')
						$post_actions[] = array('class' => 'report', 'href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['report'], array($cur_post['id'])), 'title' => $this->lang->t('Report'));

					if ($cur_topic['closed'] == '0' && $cur_topic['archived'] == '0')
					{
						if ($cur_post['poster_id'] == $this->user['id'] && ($this->user['g_deledit_interval'] == '0' || CURRENT_TIMESTAMP - $cur_post['posted'] < $this->user['g_deledit_interval']))
						{
							if ((($start_from + $post_count) == 1 && $this->user['g_delete_topics'] == '1') || (($start_from + $post_count) > 1 && $this->user['g_delete_posts'] == '1'))
								$post_actions[] = array('class' => 'delete', 'href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['delete'], array($cur_post['id'])), 'title' => $this->lang->t('Delete'));
							if ($this->user['g_edit_posts'] == '1')
								$post_actions[] = array('class' => 'edit', 'href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['edit'], array($cur_post['id'])), 'title' => $this->lang->t('Edit'));
						}

						if (($cur_topic['post_replies'] == '' && $this->user['g_post_replies'] == '1') || $cur_topic['post_replies'] == '1')
							$post_actions[] = array('class' => 'quote', 'href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['quote'], array($id, $cur_post['id'])), 'title' => $this->lang->t('Quote'));
					}
				}
				else
				{
					$post_actions[] = array('class' => 'report', 'href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['report'], array($cur_post['id'])), 'title' => $this->lang->t('Report'));
					if ($this->user['is_admin'] || $this->user['g_mod_edit_admin_posts'] == '1' || !in_array($cur_post['poster_id'], $admin_ids))
					{
						if ($this->config['o_warnings'] == '1' && (!in_array($cur_post['poster_id'], $admin_ids)) && $this->user['id'] != $cur_post['poster_id'] && $cur_post['poster_id'] > 1 && ($this->user['is_admin'] || $this->user['g_mod_warn_users'] == '1'))
							$post_actions[] = array('class' => 'delete', 'href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['warn_pid'], array($cur_post['poster_id'], $cur_post['id'])), 'title' => $this->lang->t('Warn'));

						$post_actions[] = array('class' => 'unapproved', 'href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['unapprove'], array($cur_topic['forum_id'], $cur_post['id'], $csrf_token)), 'title' => $this->lang->t('Unapprove')); 
						$post_actions[] = array('class' => 'delete', 'href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['delete'], array($cur_post['id'])), 'title' => $this->lang->t('Delete'));
						$post_actions[] = array('class' => 'edit', 'href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['edit'], array($cur_post['id'])), 'title' => $this->lang->t('Edit'));
					}

					$post_actions[] = array('class' => 'quote', 'href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['quote'], array($id, $cur_post['id'])), 'title' => $this->lang->t('Quote'));
				}
			}

			$post_actions = $this->registry->get('\Aura\extensions\hooks')->fire('viewtopic.posts.postactions', $post_actions);

			// Perform the main parsing of the message (BBCode, smilies, censor words etc)
			$cur_post['message'] = $parser->parse_message($cur_post['message'], $cur_post['hide_smilies']);

			// Do signature parsing/caching
			if ($this->config['o_signatures'] == '1' && $cur_post['signature'] != '' && $this->user['show_sig'] != '0')
			{
				if (isset($signature_cache[$cur_post['poster_id']]))
					$signature = $signature_cache[$cur_post['poster_id']];
				else
				{
					$signature = $parser->parse_signature($cur_post['signature']);
					$signature_cache[$cur_post['poster_id']] = $signature;

					$signature_cache = $this->registry->get('\Aura\extensions\hooks')->fire('viewtopic.posts.signatures', $signature_cache);
				}
			}
			else
				$signature = '';

			$attachments = array();
			if ($download && isset($results[$cur_post['id']]) && !empty($results[$cur_post['id']]))
			{
				foreach ($results[$cur_post['id']] as $cur_attach)
				{
					$attachments[] = array('icon' => $this->registry->get('\Aura\topics\attachment')->attach_icon($this->registry->get('\Aura\topics\attachment')->attach_get_extension($cur_attach['filename'])), 'link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['attachment'], array($cur_attach['id'])), 'name' => $cur_attach['filename'], 'size' => $this->lang->t('Attachment size', $this->functions->file_size($cur_attach['size'])), 'downloads' => $this->lang->t('Attachment downloads', $this->functions->forum_number_format($cur_attach['downloads'])));
					$attachments = $this->registry->get('\Aura\extensions\hooks')->fire('viewtopic.posts.attachments', $attachments);
				}
			}

			$posts[] = array(
				'id' => $cur_post['id'],
				'count' => $post_count++,
				'number' => ($start_from + $post_count),
				'link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['post'], array($cur_post['id'])),
				'posted' => $this->registry->get('\Aura\aura_time')->format($cur_post['posted']),
				'username' => $username,
				'user_title' => $user_title,
				'poster_id' => $cur_post['poster_id'],
				'poster_reputation' => $cur_post['poster_reputation'],
				'user_avatar' => $user_avatar,
				'group_image' => $group_image,
				'edited' => $cur_post['edited'] ? $this->registry->get('\Aura\aura_time')->format($cur_post['edited']) : '',
				'edited_by' => $cur_post['edited_by'],
				'edit_reason' => $cur_post['edit_reason'],
				'attachments' => $attachments,
				'message' => $cur_post['message'],
				'signature' => $signature,
				'is_online' => $cur_post['is_online'],
				'user_info' => $user_info,
				'user_contacts' => $user_contacts,
				'group_image' => $group_image,
				'post_actions' => $post_actions,
				'actions' => $actions,
			);

			$posts = $this->registry->get('\Aura\extensions\hooks')->fire('viewtopic.posts.render', $posts);
		}

		return $posts;
	}

	protected function fetch_users_online($cur_topic, $id)
	{
		if ($this->config['o_users_online'] == '1')
		{
			$users = array();
			$guests_in_topic = 0;
			$this->lang->load('online');

			$data = array(
				':topic' => 'forum|'.$cur_topic['forum_id'].'|topic|'.$id,
			);

			$join = array(
				array(
					'type' => 'INNER',
					'table' => 'users',
					'as' => 'u',
					'on' => 'o.user_id=u.id',
				),
			);

			$ps = $this->db->join('online', 'o', $join, 'o.user_id, o.ident, o.currently, o.logged, u.group_id', $data, 'o.currently=:topic AND o.idle=0');
			foreach ($ps as $user_online)
			{
				if ($user_online['user_id'] == 1)
					++$guests_in_topic;
				else
					$users[] = $this->functions->colourise_group($user_online['ident'], $user_online['group_id'], $user_online['user_id']);

				$users = $this->registry->get('\Aura\extensions\hooks')->fire('viewtopic.online.users', $users);
			}

			$render['guests'] = $guests_in_topic;
			$render['users'] = (count($users) > 0) ? implode(', ', $users) : $this->lang->t('no users');
		}

		$render = $this->registry->get('\Aura\extensions\hooks')->fire('viewtopic.online.render', $render);
		return $render;
	}
}