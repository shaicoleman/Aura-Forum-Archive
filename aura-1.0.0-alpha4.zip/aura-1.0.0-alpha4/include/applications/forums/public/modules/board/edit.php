<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class edit_controller extends base_controller
{
	public function execute()
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('edit.immediate');

		if ($this->user['g_read_board'] == '0')
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No view'), false, '403 Forbidden');

		$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
		if ($id < 1)
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		if ($this->user['is_bot'])
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'));

		// Fetch some info about the post, the topic and the forum
		$cur_post = $this->fetch_post($id);

		// Sort out who the moderators are and if we are currently a moderator (or an admin)
		$moderators = $this->cache->get('moderators');
		$is_admmod = ($this->user['is_admin'] || ($this->user['g_moderator'] == '1' && $this->user['g_global_moderator'] == '1' || isset($moderators[$cur_post['fid']]['u'.$this->user['id']]) || isset($moderators[$cur_post['fid']]['g'.$this->user['g_id']]))) ? true : false;

		$can_edit_subject = $id == $cur_post['first_post_id'] && $this->user['g_edit_subject'] == '1';

		if ($this->config['o_censoring'] == '1')
		{
			$cur_post['subject'] = $this->registry->get('\Aura\message\bbcode')->censor_words($cur_post['subject']);
			$cur_post['message'] = $this->registry->get('\Aura\message\bbcode')->censor_words($cur_post['message']);
		}

		// Do we have permission to edit this post?
		if (($this->user['g_edit_posts'] == '0' || $cur_post['poster_id'] != $this->user['id'] || $cur_post['closed'] == '1' || $this->user['g_deledit_interval'] != 0 && (CURRENT_TIMESTAMP - $cur_post['pposted']) > $this->user['g_deledit_interval']) && !$is_admmod)
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		if ($is_admmod && (!$this->user['is_admin'] && (in_array($cur_post['poster_id'], $this->cache->get('admins')) && $this->user['g_mod_edit_admin_posts'] == '0')))
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		// Load the post language file
		$this->lang->load('post');
		$this->registry->get('\Aura\auth\bans')->check_posting_ban();

		if ($cur_post['archived'] == '1')
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Topic archived'));

		if ($cur_post['password'] != '')
			$this->registry->get('\Aura\cookie\cookie')->check_forum_login_cookie($cur_post['fid'], $cur_post['password']);

		$this->registry->get('\Aura\extensions\hooks')->fire('edit.authorised');

		// Start with a clean slate
		$errors = array();
		if (isset($_POST['form_sent']))
			$errors = $this->edit_post($can_edit_subject, $is_admmod, $cur_post, $id);

		$max_size = 1;
		$can_delete = false;
		$can_upload = false;
		$attachments = array();
		if ($this->config['o_attachments'] == '1')
		{
			if ($this->user['is_admin'])
			{
				$can_delete = true;
				$can_upload = true;
			}
			else
			{
				$can_delete = (($is_admmod || $this->user['g_delete_posts'] == '1') && ($cur_post['delete_files'] == '1' || $cur_post['delete_files'] == '')) ? true : false;
				$can_upload = ($this->user['g_attach_files'] == '1' && ($cur_post['upload'] == '1' || $cur_post['upload'] == '')) ? true : false;
			}

			$can_delete = $this->registry->get('\Aura\extensions\hooks')->fire('edit.attachment.delete', $can_delete);
			$can_upload = $this->registry->get('\Aura\extensions\hooks')->fire('edit.attachment.upload', $can_upload);

			if ($can_delete || $can_upload)
			{
				$max_size = ($this->user['g_max_size'] == '0' && $this->user['g_attach_files'] == '1') ? $this->config['o_max_upload_size'] : $this->user['g_max_size'];
				$data = array(
						':id'	=>	$id,
				);

				$ps = $this->db->select('attachments', 'id, owner, filename, extension, size, downloads', $data, 'post_id=:id');
				foreach ($ps as $attachment)
				{
					$attachments[] = array('id' => $attachment['id'], 'icon' => $this->registry->get('\Aura\topics\attachment')->attach_icon($attachment['extension']), 'link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['attachment'], array($attachment['id'])), 'name' => $attachment['filename'], 'size' => $this->lang->t('Attachment size', $this->functions->file_size($attachment['size'])), 'downloads' => $this->lang->t('Attachment downloads', $this->functions->forum_number_format($attachment['downloads'])));
					$attachments = $this->registry->get('\Aura\extensions\hooks')->fire('edit.attachments', $attachments);
				}
			}
		}

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Edit post')),
			'required_fields' => array('req_subject' => $this->lang->t('Subject'), 'req_message' => $this->lang->t('Message')),
			'focus_element' => array('edit', 'req_message'),
			'active_page' => 'index',
			'posting' => true,
		);

		$this->template->header = $this->registry->get('\Aura\extensions\hooks')->fire('edit.header', $this->template->header);

		$checkboxes = array();
		if ($can_edit_subject && $is_admmod)
			$checkboxes[] = array('name' => 'stick_topic', 'title' => $this->lang->t('Stick topic'), 'checked' => ((isset($_POST['form_sent']) && isset($_POST['stick_topic']) || !isset($_POST['form_sent']) && $cur_post['sticky'] == '1') ? true : false),);

		if ($can_edit_subject && $cur_post['post_polls'] != '0' && $this->user['g_post_polls'] == '1' && $this->config['o_polls'] == '1')
			$checkboxes[] = array('name' => 'add_poll', 'title' => $this->lang->t('Add poll'), 'checked' => (isset($_POST['add_poll']) ? true : false));

		if ($this->config['o_smilies'] == '1')
			$checkboxes[] = array('name' => 'hide_smilies', 'title' => $this->lang->t('Hide smilies'), 'checked' => ((isset($_POST['form_sent']) && isset($_POST['hide_smilies']) || !isset($_POST['form_sent']) && $cur_post['hide_smilies'] == '1') ? true : false));

		if ($is_admmod)
			$checkboxes[] = array('id' => 'silent_edit', 'name' => 'silent', 'title' => $this->lang->t('Silent edit'), 'checked' => ((isset($_POST['form_sent']) && isset($_POST['silent'])) || !isset($_POST['form_sent']) ? true : false));

		$checkboxes = $this->registry->get('\Aura\extensions\hooks')->fire('edit.checkboxes', $checkboxes);
		$render = array(
			'errors' => $errors,
			'preview' => (isset($_POST['preview'])) ? true : false,
			'can_edit_subject' => $can_edit_subject,
			'subject' => isset($_POST['req_subject']) ? $_POST['req_subject'] : $cur_post['subject'],
			'can_upload' => $can_upload,
			'can_delete' => $can_delete,
			'aura_user' => $this->user,
			'max_size' => $max_size,
			'attachments' => $attachments,
			'is_admmod' => $is_admmod,
			'edit_reason' => isset($_POST['edit_reason']) ? $_POST['edit_reason'] : $cur_post['edit_reason'],
			'checkboxes' => $checkboxes,
			'index_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['index']),
			'forum_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['forum'], array($cur_post['fid'], \Aura\url\url::replace($cur_post['forum_name']))),
			'cur_post' => $cur_post,
			'topic_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['topic'], array($cur_post['tid'], \Aura\url\url::replace($cur_post['subject']))),
			'form_action' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['edit_edit'], array($id)),
			'csrf_token' => $this->registry->get('\Aura\auth\csrf')->generate('edit'),
			'message' => isset($_POST['req_message']) ? $message : $cur_post['message'],
			'quickpost_links' => array(
				'form_action' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['new_reply'], array($id)),
				'csrf_token' => $this->registry->get('\Aura\auth\csrf')->generate('post'),
				'bbcode' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['help'], array('bbcode')),
				'url' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['help'], array('url')),
				'img' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['help'], array('img')),
				'smilies' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['help'], array('smilies')),
			),
		);

		if (isset($_POST['preview']))
		{
			$parser = $this->registry->get('\Aura\message\parser');
			$render['preview'] = $parser->parse_message($message, $hide_smilies);
		}

		$render = $this->registry->get('\Aura\extensions\hooks')->fire('edit.render', $render);

		$tpl = $this->template->load('edit.tpl');
		$this->template->output($tpl, $render);
	}

	/**
	 * Fetches a post to edit
	 */
	protected function fetch_post($id)
	{
		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'topics',
				'as' => 't',
				'on' => 't.id=p.topic_id',
			),
			array(
				'type' => 'INNER',
				'table' => 'forums',
				'as' => 'f',
				'on' => 'f.id=t.forum_id',
			),
			array(
				'type' => 'LEFT',
				'table' => 'forum_perms',
				'as' => 'fp',
				'on' => '(fp.forum_id=f.id AND fp.group_id=:gid)',
			),
		);

		$data = array(
			':gid' => $this->user['g_id'],
			':id' => $id,
		);

		$ps = $this->db->join('posts', 'p', $join, 'f.id AS fid, f.forum_name, f.password, f.redirect_url, f.last_topic_id, fp.post_replies, fp.post_polls, fp.post_topics, fp.upload, fp.delete_files, t.id AS tid, t.subject, t.archived, t.posted, t.first_post_id, t.sticky, t.closed, p.poster, p.posted AS pposted, p.poster_id, p.message, p.edit_reason, p.hide_smilies', $data, '(fp.read_forum IS NULL OR fp.read_forum=1) AND p.id=:id');
		if (!$ps->rowCount())
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		$cur_post = $ps->fetch();

		$cur_post = $this->registry->get('\Aura\extensions\hooks')->fire('edit.post', $cur_post);
		return $cur_post;
	}

	/**
	 * Edit a post
	 */
	protected function edit_post($can_edit_subject, $is_admmod, $cur_post, $id)
	{
		// Make sure they got here from the site
		$this->registry->get('\Aura\auth\csrf')->confirm('edit');

		$errors = array();

		// If it's a topic it must contain a subject
		if ($can_edit_subject)
		{
			$subject = isset($_POST['req_subject']) ? utf8_trim($_POST['req_subject']) : '';

			if ($this->config['o_censoring'] == '1')
				$censored_subject = utf8_trim($this->registry->get('\Aura\message\bbcode')->censor_words($subject));

			if ($subject == '')
				$errors[] = $this->lang->t('No subject');
			else if ($this->config['o_censoring'] == '1' && $censored_subject == '')
				$errors[] = $this->lang->t('No subject after censoring');
			else if (aura_strlen($subject) > 70)
				$errors[] = $this->lang->t('Too long subject');
			else if ($this->config['p_subject_all_caps'] == '0' && is_all_uppercase($subject) && !$this->user['is_admmod'])
				$errors[] = $this->lang->t('All caps subject');

			$errors = $this->registry->get('\Aura\extensions\hooks')->fire('edit.validatesubject', $errors);
		}

		// Clean up message from POST
		$message = isset($_POST['req_message']) ? aura_linebreaks(utf8_trim($_POST['req_message'])) : '';

		// Here we use strlen() not aura_strlen() as we want to limit the post to AURA_MAX_POSTSIZE bytes, not characters
		if (strlen($message) > AURA_MAX_POSTSIZE)
			$errors[] = $this->lang->t('Too long message', $this->functions->forum_number_format(AURA_MAX_POSTSIZE));
		else if ($this->config['p_message_all_caps'] == '0' && is_all_uppercase($message) && !$this->user['is_admmod'])
			$errors[] = $this->lang->t('All caps message');

		$errors = $this->registry->get('\Aura\extensions\hooks')->fire('edit.validatemessage', $errors);

		// Validate BBCode syntax
		if ($this->config['p_message_bbcode'] == '1')
		{
			$parser = $this->registry->get('\Aura\message\parser');
			$message = $parser->preparse_bbcode($message, $errors);
		}

		if (empty($errors))
		{
			if ($message == '')
				$errors[] = $this->lang->t('No message');
			else if ($this->config['o_censoring'] == '1')
			{
				// Censor message to see if that causes problems
				$censored_message = utf8_trim($this->registry->get('\Aura\message\bbcode')->censor_words($message));

				if ($censored_message == '')
					$errors[] = $this->lang->t('No message after censoring');
			}
		}

		$hide_smilies = isset($_POST['hide_smilies']) ? '1' : '0';
		$stick_topic = isset($_POST['stick_topic']) ? '1' : '0';
		$add_poll = isset($_POST['add_poll']) && $cur_post['post_polls'] != '0' && $this->user['g_post_polls'] == '1' && $this->config['o_polls'] == '1' ? '1' : '0';

		if (!$is_admmod)
			$stick_topic = $cur_post['sticky'];

		$this->registry->get('\Aura\extensions\hooks')->fire('edit.variables');

		// Replace four-byte characters (MySQL cannot handle them)
		$message = strip_bad_multibyte_chars($message);

		// Did everything go according to plan?
		if (empty($errors) && !isset($_POST['preview']))
		{
			$edit_reason = (isset($_POST['edit_reason']) && $is_admmod) ? utf8_trim($_POST['edit_reason']): $cur_post['edit_reason'];
			$idx = $this->registry->get('\Aura\search\idx');

			if ($can_edit_subject)
			{
				$update = array(
					'subject' => $subject,
					'sticky' => $stick_topic,
				);

				$data = array(
					':id' => $cur_post['tid'],
					':moved' => $cur_post['tid'],
				);

				// Update the topic and any redirect topics
				$this->db->update('topics', $update, 'id=:id OR moved_to=:moved', $data);

				// We changed the subject, so we need to take that into account when we update the search words
				$idx->update_search_index('edit', $id, $message, $subject);

				// If this is the last topic in the forum, and we've changed the subject, we need to update that
				if ($cur_post['last_topic_id'] == $cur_post['tid'] && $subject != $cur_post['subject'])
					$this->registry->get('\Aura\forum\forum')->update($cur_post['fid']);

				$this->registry->get('\Aura\extensions\hooks')->fire('edit.updatesubject');
			}
			else
				$idx->update_search_index('edit', $id, $message);

			$update = array(
				'message' => $message,
				'edit_reason' => $edit_reason,
				'hide_smilies' => $hide_smilies,
			);

			if (!isset($_POST['silent']) || !$is_admmod)
			{
				$update['edited'] = CURRENT_TIMESTAMP;
				$update['edited_by'] = $this->user['username'];
			}

			$data = array(
				':id'	=>	$id,
			);

			$update = $this->registry->get('\Aura\extensions\hooks')->fire('edit.update', $update);
			// Update the post
			$this->db->update('posts', $update, 'id=:id', $data);
			if ($this->config['o_attachments'] == '1')
				$this->handle_attachments($data);

			$this->registry->get('\Aura\extensions\hooks')->fire('edit.beforeredirect');

			if ($add_poll)
			{
				$this->registry->get('\Aura\extensions\hooks')->fire('edit.addpoll');
				$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['poll_add'], array($cur_post['tid'])), $this->lang->t('Edit redirect'));
			}
			else
				$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['post'], array($id)), $this->lang->t('Edit redirect'));
		}
	}

	/**
	 * Checks all the old attachments and then uploads any new ones we want
	 */
	protected function handle_attachments($data)
	{
		$ps = $this->db->select('attachments', 'COUNT(id)', $data, 'post_id=:id');
		if ($ps->rowCount())
		{
			$num_attachments = $ps->fetchColumn();
			for ($i = 0; $i < $num_attachments; $i++)
			{
				if (isset($_POST['attach_delete'][$i]))
				{
					$attach_id = intval($_POST['attach_delete'][$i]);
					$data = array(
						':id' => $attach_id,
					);

					$ps = $this->db->select('attachments', 'owner', $data, 'id=:id', 1);
					if ($ps->rowCount() || $is_admmod)
					{
						$owner = $ps->fetchColumn();
						$can_delete = false;

						if ($this->user['is_admin'])
							$can_delete = true;
						else
							$can_delete = (($is_admmod || $this->user['g_delete_posts'] == '1' && $owner == $this->user['id']) && ($cur_post['delete_files'] == '1' || $cur_post['delete_files'] == '')) ? true : false;

						$can_delete = $this->registry->get('\Aura\extensions\hooks')->fire('edit.attachment.delete', $can_delete);

						if ($can_delete)
						{
							if (!$this->functions->delete_attachment($attach_id))
								$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Unable to delete'));
						}
						else
							$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No delete'));
					}
					else
						$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No attachments'));
				}
			}
		}

		if (isset($_FILES['attached_file']))
		{
			if (isset($_FILES['attached_file']['error']) && $_FILES['attached_file']['error'] != 0 && $_FILES['attached_file']['error'] != 4)
				throw new Exception(file_upload_error_message($_FILES['attached_file']['error']));

			if ($_FILES['attached_file']['size'] != 0 && is_uploaded_file($_FILES['attached_file']['tmp_name']))
				$this->upload_new_file();
		}	
	}

	/**
	 * Handle a new attachment upload
	 */
	protected function upload_new_file()
	{
		$can_upload = false;
		if ($this->user['is_admin'])
			$can_upload = true;
		else
		{
			$data = array(
				':id' => $id,
			);

			$ps = $this->db->select('attachments', 'COUNT(id)', $data, 'post_id=:id GROUP BY post_id', 1);
			$num_attachments = $ps->fetchColumn();

			$can_upload = ($this->user['g_attach_files'] == '1' && ($cur_post['upload'] == '1' || $cur_post['upload'] == '')) ? true : false;

			if ($can_upload && $num_attachments == $this->user['g_max_attachments'])
				$can_upload = false;

			$max_size = ($this->user['g_max_size'] == '0' && $this->user['g_attach_files'] == '1') ? $this->config['o_max_upload_size'] : $this->user['g_max_size'];
			if ($can_upload && $_FILES['attached_file']['size'] > $max_size)
				$can_upload = false;

			if (!$this->registry->get('\Aura\topics\attachment')->check_file_extension($_FILES['attached_file']['name']))
				$can_upload = false;
		}

		$can_upload = $this->registry->get('\Aura\extensions\hooks')->fire('edit.attachment.upload', $can_upload);

		if ($can_upload)
		{
			if (!$this->registry->get('\Aura\topics\attachment')->create_attachment($_FILES['attached_file']['name'], $_FILES['attached_file']['type'], $_FILES['attached_file']['size'], $_FILES['attached_file']['tmp_name'], $id, strlen($message)))
				$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Attachment error'));
		}
		else // Remove file as it's either dangerous or they've attempted to URL hack. Either way, there's no need for it.
			unlink($_FILES['attached_file']['tmp_name']);
	}
}