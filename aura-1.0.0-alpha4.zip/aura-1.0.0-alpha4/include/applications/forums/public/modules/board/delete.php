<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class delete_controller extends base_controller
{
	/**
	 * Main class entry point, we want to load the form
	 */
	public function execute()
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('delete.immediate');

		if ($this->user['g_read_board'] == '0')
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No view'), false, '403 Forbidden');

		$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
		if ($id < 1)
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		if ($this->user['is_bot'])
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'));

		// Fetch some info about the post, the topic and the forum
		$cur_post = $this->fetch_post_info($id);

		if ($this->config['o_censoring'] == '1')
			$cur_post['subject'] = $this->registry->get('\Aura\message\bbcode')->censor_words($cur_post['subject']);

		// Sort out who the moderators are and if we are currently a moderator (or an admin)
		$moderators = $this->cache->get('moderators');
		$is_admmod = ($this->user['is_admin'] || ($this->user['g_moderator'] == '1' && $this->user['g_global_moderator'] == '1' || isset($moderators[$cur_post['fid']]['u'.$this->user['id']]) || isset($moderators[$cur_post['fid']]['g'.$this->user['g_id']]))) ? true : false;

		$is_topic_post = ($id == $cur_post['first_post_id']) ? true : false;

		// Do we have permission to edit this post?
		if (($this->user['g_delete_posts'] == '0' || ($this->user['g_delete_topics'] == '0' && $is_topic_post) || $cur_post['poster_id'] != $this->user['id'] || $cur_post['closed'] == '1' || $this->user['g_deledit_interval'] != 0 && (CURRENT_TIMESTAMP - $cur_post['posted']) > $this->user['g_deledit_interval']) && !$is_admmod)
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		if ($is_admmod && (!$this->user['is_admin'] && (in_array($cur_post['poster_id'], $cache->get('admins')) && $this->user['g_mod_edit_admin_posts'] == '0')))
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		// Load the delete language file
		$this->lang->load('delete');

		if ($cur_post['password'] != '')
			$this->registry->get('\Aura\cookie\cookie')->check_forum_login_cookie($cur_post['fid'], $cur_post['password']);

		$this->registry->get('\Aura\auth\bans')->check_posting_ban();

		if ($cur_post['archived'] == '1')
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Topic archived'));

		$this->registry->get('\Aura\extensions\hooks')->fire('delete.authorised');

		if (isset($_POST['delete']))
			$this->delete_post($cur_post, $id, $is_topic_post);

		$parser = $this->registry->get('\Aura\message\parser');
		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Delete post')),
			'active_page' => 'index',
		);

		$this->template->header = $this->registry->get('\Aura\extensions\hooks')->fire('delete.header', $this->template->header);
		$args = $this->registry->get('\Aura\extensions\hooks')->fire('delete.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('delete.tpl');
		$this->template->output($tpl,
			array_merge(
				array(
					'index_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['index']),
					'forum_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['forum'], array($cur_post['fid'], \Aura\url\url::replace($cur_post['forum_name']))),
					'post_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['post'], array($id)),
					'cur_post' => $cur_post,
					'form_action' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['delete'], array($id)),
					'csrf_token' => $this->registry->get('\Aura\auth\csrf')->generate('delete'),
					'is_topic_post' => $is_topic_post,
					'posted' => $this->registry->get('\Aura\aura_time')->format($cur_post['posted']),
					'is_admmod' => $is_admmod,
					'message' => $parser->parse_message($cur_post['message'], $cur_post['hide_smilies']),
				),
				$args
			)
		);
	}

	/**
	 * Fetch some information about the post
	 */
	protected function fetch_post_info($id)
	{
		$data = array(
			':gid' => $this->user['g_id'],
			':id' => $id,
		);

		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'topics',
				'as' => 't',
				'on' => 't.id=p.topic_id',
			),
			array(
				'type' => 'INNER',
				'table' => 'forums',
				'as' => 'f',
				'on' => 'f.id=t.forum_id',
			),
			array(
				'type' => 'LEFT',
				'table' => 'forum_perms',
				'as' => 'fp',
				'on' => '(fp.forum_id=f.id AND fp.group_id=:gid)',
			),
		);

		$ps = $this->db->join('posts', 'p', $join, 'f.id AS fid, f.forum_name, f.password, f.redirect_url, fp.post_replies, fp.post_topics, t.id AS tid, t.subject, t.archived, t.first_post_id, t.closed, p.posted, p.poster, p.poster_id, p.poster_ip, p.message, p.hide_smilies, p.poster_email', $data, '(fp.read_forum IS NULL OR fp.read_forum=1) AND p.id=:id AND p.approved=1 AND p.deleted=0');
		if (!$ps->rowCount())
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		$cur_post = $ps->fetch();

		$cur_post = $this->registry->get('\Aura\extensions\hooks')->fire('delete.post', $cur_post);
		return $cur_post;
	}

	/**
	 * Delete the post
	 */
	protected function delete_post($cur_post, $id, $is_topic_post)
	{
		// Make sure they got here from the site
		$this->registry->get('\Aura\auth\csrf')->confirm('delete');

		if ($this->user['is_admmod'] && ($this->user['g_mod_sfs_report'] == '1' || $this->user['is_admin']))
			$this->sfs_report($cur_post);

		if ($is_topic_post)
			$this->delete_topic_post($cur_post);
		else
			$this->delete_single_post($cur_post, $id);
	}

	/**
	 * This is a topic post, so delete the whole topic
	 */
	protected function delete_topic_post($cur_post)
	{
		// Delete the topic and all of its posts
		$this->registry->get('\Aura\topics\delete_topic')->delete_topic_comply($cur_post['tid']);
		$this->registry->get('\Aura\forum\forum')->update($cur_post['fid']);

		$this->registry->get('\Aura\extensions\hooks')->fire('delete.topic.beforeredirect');
		$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['forum'], array($cur_post['fid'], \Aura\url\url::replace($cur_post['forum_name']))), $this->lang->t('Topic del redirect'));		
	}

	/**
	 * This is a single post, so just delete it
	 */
	protected function delete_single_post($cur_post, $id)
	{
		// Delete just this one post
		$this->registry->get('\Aura\topics\delete_post')->delete_post_comply($id, $cur_post['tid']);
		$this->registry->get('\Aura\forum\forum')->update($cur_post['fid']);

		// Redirect towards the previous post
		$data = array(
			':tid'	=>	$cur_post['tid'],
			':id'	=>	$id,
		);

		$ps = $this->db->select('posts', 'id', $data, 'topic_id=:tid AND id<:id AND approved=1 AND deleted=0', 'id DESC LIMIT 1');
		$post_id = $ps->fetchColumn();

		$this->registry->get('\Aura\extensions\hooks')->fire('delete.post.beforeredirect');
		$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['post'], array($post_id)), $this->lang->t('Post del redirect'));
	}

	/**
	 * Report the post to StopForumSpam
	 */
	protected function sfs_report($cur_post)
	{
		$sfs_report = isset($_POST['sfs_report']) ? intval($_POST['sfs_report']) : '0';
		if ($sfs_report == '1' && $this->config['o_sfs_api'] != '')
		{
				//If the user wasn't a guest we need to get the email from the users table
			if ($cur_post['poster_email'] == '' && $cur_post['poster_id'] != 1)
			{
				$data = array(
					':id'	=>	$cur_post['poster_id'],
				);

				$ps = $this->db->select('users', 'email', $data, 'id=:id');
				$email= $ps->fetchColumn();
			}
			else
				$email = $cur_post['poster_email'];

			$this->registry->get('\Aura\extensions\hooks')->fire('delete.stopforumspam');

			//Reporting now made fun =)
			if (!$this->registry->get('\Aura\stopforumspam')->report($this->config['o_sfs_api'], $cur_post['poster_ip'], $email, $cur_post['poster'], $cur_post['message']))
				$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Unable to add spam data'));
		}
	}
}