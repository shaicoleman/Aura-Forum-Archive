<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class announcement_controller extends base_controller
{
	/*
	 * Do we want to hide smilies in the message?
	 */
	protected $hide_smilies = 0;

	/*
	 * Main entry point of the app- run the announcement!
	 */
	public function execute()
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('announcement.immediate');

		$parser = $this->registry->get('\Aura\message\parser');

		if ($this->user['g_read_board'] == '0')
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No view'), false, '403 Forbidden');

		$aura_forums = $this->cache->get('forums');
		$fid = isset($_GET['fid']) && $_GET['fid'] > 0 ? intval($_GET['fid']) : key($aura_forums);
		$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

		if ($id < 1)
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		$this->lang->load('topic');

		$perms = $this->cache->get('perms');
		if (!isset($perms[$this->user['g_id'].'_'.$fid]))
			$perms[$this->user['g_id'].'_'.$fid] = $perms['_'];

		if ($perms[$this->user['g_id'].'_'.$fid]['read_forum'] == '0')
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'));

		$this->registry->get('\Aura\extensions\hooks')->fire('announcement.authorised');
		list($cur_announcement, $user_avatar, $post_actions, $user_info, $user_contacts, $group_image) = $this->fetch_announcement($id, $fid);

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $cur_announcement['forum_name'], $cur_announcement['subject']),
			'active_page' => 'index',
		);

		$this->template->header = $this->registry->get('\Aura\extensions\hooks')->fire('announcement.header', $this->template->header);


		$render = array(
			'index_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['index']),
			'lang' => $this->lang,
			'forum_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['forum'], array($cur_announcement['fid'], \Aura\url\url::replace($cur_announcement['forum_name']))),
			'announce_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['announcement'], array($id, $cur_announcement['fid'], \Aura\url\url::replace($cur_announcement['subject']))),
			'cur_announcement' => $cur_announcement,
			'username' => $this->functions->colourise_group($cur_announcement['username'], $cur_announcement['group_id'], $cur_announcement['user_id']),
			'user_title' => $this->registry->get('\Aura\topics\title')->get_title($cur_announcement),
			'user_avatar' => $user_avatar,
			'message' => $parser->parse_message($cur_announcement['message'], $this->hide_smilies),
			'this->config' => $this->config,
			'post_actions' => $post_actions,
			'user_info' => $user_info,
			'user_contacts' => $user_contacts,
			'group_image' => $group_image,
		);

		if ($cur_announcement['parent'])
			$render['parent_link'] = $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['forum'], array($cur_announcement['parent_forum'], \Aura\url\url::replace($cur_announcement['parent'])));

		$render = $this->registry->get('\Aura\extensions\hooks')->fire('announcement.render', $render);

		$tpl = $this->template->load('announcement.tpl');
		$this->template->output($tpl, $render);
	}

	/*
	 * Fetches the announcement and surrounding data
	 */
	protected function fetch_announcement($id, $fid)
	{
		$data = array(
			':id' => $id,
		);

		$ps = $this->db->select('announcements', 'forum_id', $data, 'id=:id');
		$afid = $ps->fetchColumn();

		$data = array(
			':id' => $id,
		);

		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'users',
				'as' => 'u',
				'on' => 'u.id=a.user_id',
			),
			array(
				'type' => 'INNER',
				'table' => 'forums',
				'as' => 'f',
				'on' => 'f.id=a.forum_id',
			),
			array(
				'type' => 'INNER',
				'table' => 'groups',
				'as' => 'g',
				'on' => 'u.group_id=g.g_id',
			),
			array(
				'type' => 'LEFT',
				'table' => 'posts',
				'as' => 'p',
				'on' => 'p.poster_id=a.user_id',
			),
			array(
				'type' => 'LEFT',
				'table' => 'forums',
				'as' => 'pf',
				'on' => 'f.parent_forum=pf.id',
			),
		);

		// We need the ON clause changing to the forum ID parameter we are viewing it from
		if ($afid == 0)
		{
			$data[':fid'] = $fid;
			$join[1]['on'] = 'f.id=:fid';
		}

		$ps = $this->db->join('announcements', 'a', $join, 'a.subject, a.forum_id, g.g_image, g.g_user_title, g.g_id, a.user_id, a.message, u.email_setting, u.email, u.use_gravatar, u.group_id, u.num_posts, u.username, u.title, u.url, u.location, u.registered, f.forum_name, f.parent_forum, u.reputation, f.id AS fid, f.password, pf.forum_name AS parent', $data, 'a.id=:id');
		if (!$ps->rowCount())
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		$cur_announcement = $ps->fetch();

		$cur_announcement = $this->registry->get('\Aura\extensions\hooks')->fire('announcement.announcement', $cur_announcement);
		if ($cur_announcement['password'] != '')
			$this->registry->get('\Aura\cookie\cookie')->check_forum_login_cookie($cur_announcement['fid'], $cur_announcement['password']);

		$user_avatar = '';
		$user_info = $user_contacts = $post_actions = array();
		if ($this->user['is_admmod'] == '1' && $this->user['g_mod_cp'] == '1' || $this->user['is_admin'])
		{
			$post_actions[] = array('class' => 'delete', 'href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['delete_announcement'], array($id)), 'title' => $this->lang->t('Delete'));
			$post_actions[] = array('class' => 'edit', 'href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['edit_announcement'], array($id)), 'title' => $this->lang->t('Edit'));
		}

		$post_actions = $this->registry->get('\Aura\extensions\hooks')->fire('announcement.postactions', $post_actions);
		$cur_announcement['user_title'] = $this->registry->get('\Aura\topics\title')->get_title($cur_announcement);
		if ($this->config['o_censoring'] == '1')
			$cur_announcement['user_title'] = $this->registry->get('\Aura\message\bbcode')->censor_words($cur_announcement['user_title']);

		if ($this->config['o_avatars'] == '1' && $this->user['show_avatars'] != '0')
			$user_avatar = $this->registry->get('\Aura\avatar')->generate($cur_announcement['user_id'], $cur_announcement['email'], $cur_announcement['use_gravatar']);

		// We only show location, register date, post count and the contact links if "Show user info" is enabled
		if ($this->config['o_show_user_info'] == '1')
		{
			if ($cur_announcement['location'] != '')
			{
				if ($this->config['o_censoring'] == '1')
					$cur_announcement['location'] = $this->registry->get('\Aura\message\bbcode')->censor_words($cur_announcement['location']);

				$user_info[] = array('title' => $this->lang->t('From'), 'value' => $cur_announcement['location']);
			}

			$user_info[] = array('title' => $this->lang->t('Registered'), 'value' => $this->registry->get('\Aura\aura_time')->format($cur_announcement['registered'], true));

			if ($this->config['o_show_post_count'] == '1' || $this->user['is_admmod'])
				$user_info[] = array('title' => $this->lang->t('Posts'), 'value' => $this->functions->forum_number_format($cur_announcement['num_posts']));

			$user_info = $this->registry->get('\Aura\extensions\hooks')->fire('announcement.userinfo', $user_info);
			// Now let's deal with the contact links (Email and URL)
			if ((($cur_announcement['email_setting'] == '0' && !$this->user['is_guest']) || $this->user['is_admmod']) && $this->user['g_send_email'] == '1')
				$user_contacts[] = array('class' => 'email', 'href' => 'mailto:'.$cur_announcement['email'], 'title' => $this->lang->t('Email'));
			else if ($cur_announcement['email_setting'] == '1' && !$this->user['is_guest'] && $this->user['g_send_email'] == '1')
				$user_contacts[] = array('class' => 'email', 'href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['email'], array($cur_announcement['user_id'])), 'title' => $this->lang->t('Email'));

			if ($cur_announcement['url'] != '')
			{
				if ($this->config['o_censoring'] == '1')
					$cur_announcement['url'] = $this->registry->get('\Aura\message\bbcode')->censor_words($cur_announcement['url']);

				$user_contacts[] = array('class' => 'website', 'href' => $cur_announcement['url'], 'rel' => 'nofollow', 'title' => $this->lang->t('Website'));
			}

			$user_contacts = $this->registry->get('\Aura\extensions\hooks')->fire('announcement.usercontacts', $user_contacts);
		}

		if ($this->config['o_reputation'] == '1')
		{
			switch(true)
			{
				case $cur_announcement['reputation'] > '0':
					$type = 'positive';
				break;
				case $cur_announcement['reputation'] < '0':
					$type = 'negative';
				break;
				default:
					$type = 'zero';
				break;
			}

			$cur_announcement['reputation'] = array('type' => $type, 'title' => $this->lang->t('reputation', $this->functions->forum_number_format($cur_announcement['reputation'])));
		}

		if ($cur_announcement['g_image'] != '')
		{
			$image_dir = ($this->config['o_image_group_dir'] != '') ? $this->config['o_image_group_dir'] : $this->functions->get_base_url().'/'.$this->config['o_image_group_path'].'/';
			$img_size = @getimagesize($this->config['o_image_group_path'].'/'.$cur_announcement['group_id'].'.'.$cur_announcement['g_image']);
			$group_image = array('src' => $image_dir.$cur_announcement['group_id'].'.'.$cur_announcement['g_image'], 'size' => $img_size[3], 'alt' => $cur_announcement['g_user_title']);

			$group_image = $this->registry->get('\Aura\extensions\hooks')->fire('announcement.groupimage', $group_image);
		}
		else
			$group_image = array();

		return array($cur_announcement, $user_avatar, $post_actions, $user_info, $user_contacts, $group_image);
	}
}