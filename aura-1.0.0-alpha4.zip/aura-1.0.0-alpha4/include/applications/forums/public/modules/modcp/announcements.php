<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class announcements_controller extends base_controller
{
	/**
	 * Main App entry point
	 */
	public function execute()
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('modcp.announcements.immediate');
		$this->configure_page();

		list($announcements, $page, $num_pages) = $this->fetch_announcements();

		$args = $this->registry->get('\Aura\extensions\hooks')->fire('modcp.announcements.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('admin/announcements.tpl');
		$this->template->output($tpl,
			array_merge(
				array(
					'admin_menu' => $this->admin->generate_menu('announcements'),
					'pagination' => $this->registry->get('\Aura\pagination')->paginate($num_pages, $page, $this->rewrite->url['admin_announcements']),
					'add_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['add_announcement']),
					'announcements' => $announcements,
				),
				$args
			)
		);
	}

	/**
	 * Setup a few things here that we need to use on each page
	 */
	protected function configure_page()
	{
		$this->admin = $this->registry->get('\Aura\admin\common');

		if (($this->user['is_admmod'] && $this->user['g_mod_cp'] == '0' && !$this->user['is_admin']) || !$this->user['is_admmod'])
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		$this->registry->get('\Aura\auth\http_auth')->check_authentication();

		// Load the admin_announcements language file
		$this->lang->load('admin_announcements');

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Admin'), $this->lang->t('Announcements')),
			'active_page' => 'admin',
			'admin_console' => true,
		);

		$this->template->header = $this->registry->get('\Aura\extensions\hooks')->fire('modcp.announcements.header', $this->template->header);
		$this->template->footer = array(
			'admin_console' => true,
		);

		$this->template->footer = $this->registry->get('\Aura\extensions\hooks')->fire('modcp.announcements.footer', $this->template->footer);
	}

	/**
	 * Fetch the announcements we have on the board
	 */
	protected function fetch_announcements()
	{
		$page = (!isset($_GET['p']) || $_GET['p'] <= '1') ? '1' : intval($_GET['p']);

		$ps = $this->db->select('announcements', 'COUNT(id)');
		$total = $ps->fetchColumn();

		$num_pages = ceil($total/$this->config['o_disp_topics_default']);
		if ($page > $num_pages)
			$page = 1;

		$start_from = intval($this->config['o_disp_topics_default'])*($page-1);

		$data = array(
			':start' => $start_from,
			':limit' => $this->config['o_disp_topics_default'],
		);

		$join = array(
			array(
				'type' => 'LEFT',
				'table' => 'users',
				'as' => 'u',
				'on' => 'a.user_id=u.id',
			),
		);

		$announcements = array();
		$ps = $this->db->join('announcements', 'a', $join, 'a.subject, a.forum_id, a.user_id, u.username, u.group_id, a.id', $data, '', 'a.id DESC LIMIT :start, :limit');
		foreach ($ps as $announcement)
		{
			$forum_names = array();
			$ids = explode(',', $announcement['forum_id']);
			foreach ($ids as $id)
			{
				$data = array(
					':id'	=>	$id,
				);

				$ps1 = $this->db->select('forums', 'forum_name', $data, 'id=:id');
				$forum_names[] = $ps1->fetchColumn();
			}

			$announcements[] = array(
				'edit_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['edit_announcement'], array($announcement['id'])),
				'delete_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['delete_announcement'], array($announcement['id'])),
				'subject' => $announcement['subject'],
				'poster' => $this->functions->colourise_group($announcement['username'], $announcement['group_id'], $announcement['user_id']),
			);
		}

		$announcements = $this->registry->get('\Aura\extensions\hooks')->fire('modcp.announcements.announcements', $announcements);
		return array($announcements, $page, $num_pages);
	}

	/**
	 * Add a new announcement to the board
	 */
	public function add()
	{
		$this->configure_page();

		if (isset($_POST['form_sent']))
			$this->add_announcement();

		list($categories, $forums) = $this->fetch_categories();

		$args = $this->registry->get('\Aura\extensions\hooks')->fire('modcp.announcements.add.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('admin/modify_announcement.tpl');
		$this->template->output($tpl,
			array_merge(
				array(
					'admin_menu' => $this->admin->generate_menu('announcements'),
					'form_action' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['add_announcement']),
					'csrf_token' => $this->registry->get('\Aura\auth\csrf')->generate('admin_announcements'),
					'categories' => $categories,
					'forums' => $forums,
				),
				$args
			)
		);
	}

	/**
	 * Edit the announcement
	 */
	public function edit()
	{
		$this->configure_page();

		$id = isset($_GET['id']) ? intval($_GET['id']) : '0';
		if ($id < 1)
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'));

		$data = array(
			':id' => $id,
		);

		$ps = $this->db->select('announcements', 'message, forum_id, subject', $data, 'id=:id');
		if (!$ps->rowCount())
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'));

		$cur_announcement = $ps->fetch();

		$cur_announcement = $this->registry->get('\Aura\extensions\hooks')->fire('modcp.announcements.edit.render', $cur_announcement);
		if (isset($_POST['form_sent']))
			$this->edit_announcement($id);

		$id_list = explode(',', $cur_announcement['forum_id']);
		list($categories, $forums) = $this->fetch_categories($id_list);

		$args = $this->registry->get('\Aura\extensions\hooks')->fire('modcp.announcements.edit.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('admin/modify_announcement.tpl');
		$this->template->output($tpl,
			array_merge(
				array(
					'admin_menu' => $this->admin->generate_menu('announcements'),
					'form_action' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['edit_announcement'], array($id)),
					'csrf_token' => $this->registry->get('\Aura\auth\csrf')->generate('admin_announcements'),
					'cur_announce' => $cur_announcement,
					'categories' => $categories,
					'forums' => $forums,
				),
				$args
			)
		);
	}

	/**
	 * Edit the announcement in the database
	 */
	protected function edit_announcement($id)
	{
		$this->registry->get('\Aura\auth\csrf')->confirm('admin_announcements');

		list($forums, $announcement, $title) = $this->validate_announcement();

		$update = array(
			'message' => $announcement,
			'forum_id' => implode(',', $forums),
			'subject' => $title,
		);

		$data = array(
			':id' => $id,
		);

		$this->db->update('announcements', $update, 'id=:id', $data);

		$this->cache->generate('announcements');
		$forum = current($this->cache->get('forums'));
		$forum_id = ($forums[0] != '0') ? $forums[0] : $forum['id'];

		$this->registry->get('\Aura\extensions\hooks')->fire('modcp.announcements.edit.beforeredirect');
		$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['announcement'], array($id, $forum_id, \Aura\url\url::replace($title))), $this->lang->t('Edit redirect'));
	}

	/**
	 * Delete the announcement
	 */
	public function delete()
	{
		$this->configure_page();

		$id = isset($_GET['id']) ? intval($_GET['id']) : '0';
		if ($id < 1)
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'));

		$data = array(
			':id' => $id,
		);

		$ps = $this->db->select('announcements', 1, $data, 'id=:id');
		if (!$ps->rowCount())
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'));

		if (isset($_POST['form_sent']))
			$this->delete_announcement($id);

		$args = $this->registry->get('\Aura\extensions\hooks')->fire('modcp.announcements.delete.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('admin/delete_announcement.tpl');
		$this->template->output($tpl,
			array_merge(
				array(
					'admin_menu' => $this->admin->generate_menu('announcements'),
					'form_action' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['delete_announcement'], array($id)),
					'csrf_token' => $this->registry->get('\Aura\auth\csrf')->generate('admin_announcements'),
				),
				$args
			)
		);
	}

	/**
	 * Delete the announcement from the database
	 */
	protected function delete_announcement($id)
	{
		$this->registry->get('\Aura\auth\csrf')->confirm('admin_announcements');

		$data = array(
			':id' => $id,
		);

		$this->db->delete('announcements', 'id=:id', $data);

		$this->cache->generate('announcements');

		$this->registry->get('\Aura\extensions\hooks')->fire('modcp.announcements.delete.beforeredirect');
		$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_announcements']), $this->lang->t('Deleted redirect'));		
	}

	/**
	 * Add a new announcement to the database
	 */
	protected function add_announcement()
	{
		$this->registry->get('\Aura\auth\csrf')->confirm('admin_announcements');

		list($forums, $announcement, $title) = $this->validate_announcement();

		$insert = array(
			'message' => $announcement,
			'forum_id' => implode(',', $forums),
			'user_id' => $this->user['id'],
			'subject' => $title,
		);

		$this->db->insert('announcements', $insert);
		$id = $this->db->lastInsertId($this->db->prefix.'announcements');

		$this->cache->generate('announcements');
		$forum = current($this->cache->get('forums'));
		$forum_id = ($forums[0] != '0') ? $forums[0] : $forum['id'];

		$this->registry->get('\Aura\extensions\hooks')->fire('modcp.announcements.add.beforeredirect');
		$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['announcement'], array($id, $forum_id, \Aura\url\url::replace($title))), $this->lang->t('Added redirect'));
	}

	/**
	 * Validate the announcement
	 */
	protected function validate_announcement()
	{
		$forums = isset($_POST['forums']) && is_array($_POST['forums']) ? array_map('intval', $_POST['forums']) : array();

		if (empty($forums))
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'));

		$announcement = isset($_POST['message']) ? utf8_trim($_POST['message']) : '';
		$title = isset($_POST['title']) ? utf8_trim($_POST['title']) : '';

		if (strlen($title) > 50)
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Title too long'));

		if (strlen($announcement) < 1 || strlen($title) < 1)
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'));

		$this->registry->get('\Aura\extensions\hooks')->fire('modcp.announcements.modify.validate');

		return array($forums, $announcement, $title);
	}

	/**
	 * Fetches a list of the categories and forums
	 */
	protected function fetch_categories($id_list = array())
	{
		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'forums',
				'as' => 'f',
				'on' => 'c.id=f.cat_id',
			),
		);

		// Display all the categories and forums
		$categories = $forums = array();
		$ps = $this->db->join('categories', 'c', $join, 'c.id AS cid, c.cat_name, f.id AS fid, f.forum_name', array(), 'f.redirect_url IS NULL', 'c.disp_position, c.id, f.disp_position');
		foreach ($ps as $cur_forum)
		{
			if (!isset($categories[$cur_forum['cid']]))
				$categories[$cur_forum['cid']] = array(
					'cat_name' => $cur_forum['cat_name'],
					'id' => $cur_forum['cid'],
				);
					
			$forums[] = array(
				'id' => $cur_forum['fid'],
				'forum_name' => $cur_forum['forum_name'],
				'category_id' => $cur_forum['cid'],
				'selected' => ((in_array($cur_forum['fid'], $id_list)) ? true : false),
			);
		}

		$categories = $this->registry->get('\Aura\extensions\hooks')->fire('modcp.announcements.categories', $categories);
		$forums = $this->registry->get('\Aura\extensions\hooks')->fire('modcp.announcements.categories', $forums);

		return array($categories, $forums);
	}
}