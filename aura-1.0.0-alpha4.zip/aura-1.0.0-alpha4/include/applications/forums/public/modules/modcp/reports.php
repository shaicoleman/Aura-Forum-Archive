<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class reports_controller extends base_controller
{
	/**
	 * Main class entry point
	 */
	public function execute()
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('modcp.reports.immediate');
		$admin = $this->registry->get('\Aura\admin\common');

		if (!$this->user['is_admin'])
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		$admin->check_user('admin_reports');

		$this->registry->get('\Aura\auth\http_auth')->check_authentication();

		// Load the admin-reports language file
		$this->lang->load('admin_reports');

		if (isset($_POST['zap_id'])) // Zap a report
			$this->zap_reports();

		list($reports, $zapped) = $this->fetch_reports();

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Admin'), $this->lang->t('Reports')),
			'active_page' => 'admin',
			'admin_console' => true,
		);

		$this->template->header = $this->registry->get('\Aura\extensions\hooks')->fire('modcp.reports.header', $this->template->header);
		$this->template->footer = array(
			'admin_console' => true,
		);

		$this->template->footer = $this->registry->get('\Aura\extensions\hooks')->fire('modcp.reports.footer', $this->template->footer);
		$args = $this->registry->get('\Aura\extensions\hooks')->fire('modcp.reports.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('admin/reports.tpl');
		$this->template->output($tpl,
			array_merge(
				array(
					'admin_menu' => $admin->generate_menu('reports'),
					'form_action' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_reports']),
					'csrf_token' => $this->registry->get('\Aura\auth\csrf')->generate('admin_reports'),
					'reports' => $reports,
					'zapped' => $zapped,
				),
				$args
			)
		);
	}

	/**
	 * We've read a report and want to mark it as read
	 */
	protected function zap_reports()
	{
		$this->registry->get('\Aura\auth\csrf')->confirm('admin_reports');

		$zap_id = intval(key($_POST['zap_id']));
		$data = array(
			':id'	=>	$zap_id,
		);

		$ps = $this->db->select('reports', 'zapped', $data, 'id=:id');
		$zapped = $ps->fetchColumn();

		if ($zapped == '')
		{
			$update = array(
				'zapped' => CURRENT_TIMESTAMP,
				'zapped_by' => $this->user['id'],
			);

			$data = array(
				':id'	=>	$zap_id
			);

			$this->db->update('reports', $update, 'id=:id', $data);
			$this->registry->get('\Aura\extensions\hooks')->fire('modcp.reports.zapped');
		}

		// Delete old reports (which cannot be viewed anyway)
		$ps = $this->db->select('reports', 'zapped', array(), 'zapped IS NOT NULL ORDER BY zapped DESC LIMIT 10, 1');
		if ($ps->rowCount())
		{
			$data = array(
				':zapped' => $ps->fetchColumn(),
			);

			$this->db->delete('reports', 'zapped <= :zapped', $data);
			$this->registry->get('\Aura\extensions\hooks')->fire('modcp.reports.deleted');
		}

		$this->registry->get('\Aura\extensions\hooks')->fire('modcp.reports.zapped.beforeredirect');
		$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_reports']), $this->lang->t('Report zapped redirect'));
	}

	/**
	 * Fetch all the reports
	 */
	protected function fetch_reports()
	{
		$join = array(
			array(
				'type' => 'LEFT',
				'table' => 'posts',
				'as' => 'p',
				'on' => 'r.post_id=p.id',
			),
			array(
				'type' => 'LEFT',
				'table' => 'topics',
				'as' => 't',
				'on' => 'r.topic_id=t.id',
			),
			array(
				'type' => 'LEFT',
				'table' => 'forums',
				'as' => 'f',
				'on' => 'r.forum_id=f.id',
			),
			array(
				'type' => 'LEFT',
				'table' => 'users',
				'as' => 'u',
				'on' => 'r.reported_by=u.id',
			),
		);

		$reports = array();
		$ps = $this->db->join('reports', 'r', $join, 'r.id, r.topic_id, r.forum_id, r.reported_by, r.created, r.message, p.id AS pid, t.subject, f.forum_name, u.username AS reporter', array(), 'r.zapped IS NULL', 'created DESC');
		foreach ($ps as $cur_report)
		{
			$cur_report = $this->registry->get('\Aura\extensions\hooks')->fire('modcp.reports.reports', $cur_report);

			$reports[] = array(
				'posted' => $this->registry->get('\Aura\aura_time')->format($cur_report['created']),
				'id' => $cur_report['id'],
				'message' => str_replace("\n", $this->registry->get('\Aura\message\bbcode')->style_html('line_break'), $cur_report['message']),
				'forum' =>  ($cur_report['forum_name'] != '') ? array('href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['forum'], array($cur_report['forum_id'], \Aura\url\url::replace($cur_report['forum_name']))), 'title' => $cur_report['forum_name']) : '',
				'topic' => ($cur_report['subject'] != '') ? array('href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['topic'], array($cur_report['topic_id'], \Aura\url\url::replace($cur_report['subject']))), 'title' => $cur_report['subject']) : '',
				'post' => ($cur_report['pid'] != '') ? array('href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['post'], array($cur_report['pid'])), 'title' => $this->lang->t('Post ID', $cur_report['pid'])) : '',
				'reporter' => ($cur_report['reporter'] != '') ? array('href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['profile'], array($cur_report['reported_by'], \Aura\url\url::replace($cur_report['reporter']))), 'username' => $cur_report['reporter']) : ''
			);
		}

		$join[4] = array(
			'type' => 'LEFT',
			'table' => 'users',
			'as' => 'u2',
			'on' => 'r.zapped_by=u2.id',
		);

		// Now get the zapped reports
		$zapped = array();
		$ps = $this->db->join('reports', 'r', $join, 'r.id, r.topic_id, r.forum_id, r.reported_by, r.message, r.zapped, r.zapped_by AS zapped_by_id, p.id AS pid, t.subject, f.forum_name, u.username AS reporter, u2.username AS zapped_by', array(), 'r.zapped IS NOT NULL', 'zapped DESC LIMIT 10');
		foreach ($ps as $cur_report)
		{
			$cur_report = $this->registry->get('\Aura\extensions\hooks')->fire('modcp.reports.zapped', $cur_report);

			$zapped[] = array(
				'zapped' => $this->registry->get('\Aura\aura_time')->format($cur_report['zapped']),
				'id' => $cur_report['id'],
				'message' => str_replace("\n", $this->registry->get('\Aura\message\bbcode')->style_html('line_break'), $cur_report['message']),
				'forum' =>  ($cur_report['forum_name'] != '') ? array('href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['forum'], array($cur_report['forum_id'], \Aura\url\url::replace($cur_report['forum_name']))), 'title' => $cur_report['forum_name']) : '',
				'topic' => ($cur_report['subject'] != '') ? array('href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['topic'], array($cur_report['topic_id'], \Aura\url\url::replace($cur_report['subject']))), 'title' => $cur_report['subject']) : '',
				'post' => ($cur_report['pid'] != '') ? array('href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['post'], array($cur_report['pid'])), 'title' => $this->lang->t('Post ID', $cur_report['pid'])) : '',
				'reporter' => ($cur_report['reporter'] != '') ? array('href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['profile'], array($cur_report['reported_by'], \Aura\url\url::replace($cur_report['reporter']))), 'username' => $cur_report['reporter']) : '',
				'zapped_by' => $cur_report['zapped_by'],
			);
		}

		return array($reports, $zapped);
	}
}