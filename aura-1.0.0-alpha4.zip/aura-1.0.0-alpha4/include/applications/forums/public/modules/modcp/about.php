<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class about_controller extends base_controller
{
	/**
	 * Main App entry point
	 */
	public function execute()
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('modcp.about.immediate');
		$admin = $this->registry->get('\Aura\admin\common');

		if (($this->user['is_admmod'] && $this->user['g_mod_cp'] == '0' && !$this->user['is_admin']) || !$this->user['is_admmod'])
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		$this->registry->get('\Aura\auth\http_auth')->check_authentication();

		// Load the admin_about language file
		$this->lang->load('admin_about');

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Admin'), $this->lang->t('About')),
			'active_page' => 'admin',
			'admin_console' => true,
		);

		$this->template->header = $this->registry->get('\Aura\extensions\hooks')->fire('modcp.about.header', $this->template->header);
		$this->template->footer = array(
			'admin_console' => true,
		);

		$this->template->footer = $this->registry->get('\Aura\extensions\hooks')->fire('modcp.about.footer', $this->template->footer);
		$args = $this->registry->get('\Aura\extensions\hooks')->fire('modcp.about.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('admin/about.tpl');
		$this->template->output($tpl,
			array_merge(
				array(
					'admin_menu' => $admin->generate_menu('about'),
				),
				$args
			)
		);
	}
}