<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class search_controller extends base_controller
{
	/*
	 * Main entry point- do the search!
	 */
	public function execute()
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('search.searching.immediate');

		$this->configure_search();

		// Figure out what to do :-)
		$aura_forums = $this->cache->get('forums');
		if (isset($_GET['perform']) || isset($_GET['search_id']))
		{
			$action = (isset($_GET['perform'])) ? $_GET['perform'] : null;
			$url_forums = isset($_GET['forums']) ? (is_array($_GET['forums']) ? $_GET['forums'] : array_filter(explode(',', $_GET['forums']))) : (isset($_GET['forum']) ? array($_GET['forum']) : array());
			$sort_dir = (isset($_GET['sort_dir']) && $_GET['sort_dir'] == 'DESC') ? 'DESC' : 'ASC';
			$forum_sql = '';
			$url_forums = array_map('intval', $url_forums);

			// If a search_id was supplied
			if (isset($_GET['search_id']))
			{
				$search_id = intval($_GET['search_id']);
				if ($search_id < 1)
					$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

				$this->registry->get('\Aura\extensions\hooks')->fire('search.searching.searchid.immediate');
			}
			// If it's a regular search (keywords and/or author)
			else if ($action == 'search')
			{
				$keywords = (isset($_GET['keywords'])) ? utf8_strtolower(utf8_trim($_GET['keywords'])) : null;
				$author = (isset($_GET['author'])) ? utf8_strtolower(utf8_trim($_GET['author'])) : null;

				if (preg_match('%^[\*\%]+$%', $keywords) || (aura_strlen(str_replace(array('*', '_'), array('%', '\\_'), $keywords)) < AURA_SEARCH_MIN_WORD && !$this->idx->is_cjk($keywords)))
					$keywords = '';

				if (preg_match('%^[\*\%]+$%', $author) || aura_strlen(str_replace(array('*', '_'), array('%', '\\_'), $author)) < 2)
					$author = '';

				if (!$keywords && !$author)
					$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No terms'));

				if ($author)
					$author = str_replace('*', '%', $author);

				$show_as = (isset($_GET['show_as']) && $_GET['show_as'] == 'topics') ? 'topics' : 'posts';
				$sort_by = (isset($_GET['sort_by'])) ? intval($_GET['sort_by']) : 0;
				$search_in = (!isset($_GET['search_in']) || $_GET['search_in'] == '0') ? 0 : (($_GET['search_in'] == '1') ? 1 : -1);

				$this->registry->get('\Aura\extensions\hooks')->fire('search.searching.search.immediate');
			}
			// If it's a user search (by ID)
			else if ($action == 'show_user_posts' || $action == 'show_user_topics' || $action == 'show_subscriptions')
			{
				$user_id = (isset($_GET['user_id'])) ? intval($_GET['user_id']) : $this->user['id'];
				if ($user_id < 2)
					$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

				// Subscribed topics can only be viewed by admins, moderators and the users themselves
				if ($action == 'show_subscriptions' && !$this->user['is_admmod'] && $user_id != $this->user['id'])
					$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

				$this->registry->get('\Aura\extensions\hooks')->fire('search.searching.posts.immediate');
			}
			else if ($action == 'show_recent')
				$interval = isset($_GET['interval']) ? intval($_GET['interval']) : 86400;
			else if ($action == 'show_replies')
			{
				if ($this->user['is_guest'])
					$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

				$this->registry->get('\Aura\extensions\hooks')->fire('search.searching.replies.immediate');
			}
			else if ($action != 'show_new' && $action != 'show_unanswered')
			{
				$this->registry->get('\Aura\extensions\hooks')->fire('search.searching.badrequest');
				$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');
			}

			// If a valid search_id was supplied we attempt to fetch the search results from the db
			if (isset($search_id))
			{
				$ident = ($this->user['is_guest']) ? get_remote_address() : $this->user['username'];
				$data = array(
					':id' => $search_id,
					':ident' => $ident,
				);

				$ps = $this->db->select('search_cache', 'search_data', $data, 'id=:id AND ident=:ident');
				if ($row = $ps->fetch())
				{
					$placeholders = array();
					$temp = unserialize($row['search_data']);

					$search_ids = unserialize($temp['search_ids']);
					$num_hits = $temp['num_hits'];
					$sort_by = $temp['sort_by'];
					$sort_dir = $temp['sort_dir'];
					$show_as = $temp['show_as'];
					$search_type = $temp['search_type'];

					for ($i = 0; $i < count($search_ids); $i++)
						$markers[] = '?';

					unset($temp);
				}
				else
					$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No hits'));
			}
			else
			{
				$keyword_results = $author_results = $forums = $no_view = $no_forums = array();

				// Search a specific forum?
				if (!empty($url_forums) || (empty($url_forums) && $this->config['o_search_all_forums'] == '0' && !$this->user['is_admmod']))
				{
					for ($i = 0; $i < count($url_forums); $i++)
					{
						if ($aura_forums[$url_forums[$i]]['password'] != '' && $this->registry->get('\Aura\cookie\cookie')->check_forum_login_cookie($url_forums[$i], $aura_forums[$url_forums[$i]]['password'], true) === false || $aura_forums[$url_forums[$i]]['protected'] == '1' && !$this->user['is_admmod'])
						{
							$no_view[] = '?';
							$no_forums[] = $url_forums[$i];
							continue;
						}

						$forums[] = $url_forums[$i];
						$markers[] = '?';
					}

					$forums = $this->registry->get('\Aura\extensions\hooks')->fire('search.searching.specificforums', $forums);
					$markers = $this->registry->get('\Aura\extensions\hooks')->fire('search.searching.specificmarkers', $markers);
					
					$no_forums = $this->registry->get('\Aura\extensions\hooks')->fire('search.searching.noforums', $no_forums);
					$no_view = $this->registry->get('\Aura\extensions\hooks')->fire('search.searching.nomarkers', $no_view);

					$forums = array_merge($forums, $no_forums);
					$forum_sql = (!empty($markers) ? ' AND t.forum_id IN ('.implode(',', $markers).')' : '').(!empty($no_view) ? ' AND t.forum_id NOT IN ('.implode(',', $no_view).')' : '');
				}
				else // If there are no specific forums selected, we need to ensure that there are no 'protected' forums we can't view
				{
					foreach($aura_forums as $cur_forum)
					{
						if ($aura_forums[$cur_forum['id']]['password'] != '' && $this->registry->get('\Aura\cookie\cookie')->check_forum_login_cookie($cur_forum['id'], $aura_forums[$cur_forum['id']]['password'], true) === false || $aura_forums[$cur_forum['id']]['protected'] == '1' && !$this->user['is_admmod'])
						{
							$no_view[] = '?';
							$forums[] = $cur_forum['id'];
						}
					}

					$forums = $this->registry->get('\Aura\extensions\hooks')->fire('search.searching.noforums', $forums);
					$no_view = $this->registry->get('\Aura\extensions\hooks')->fire('search.searching.nomarkers', $no_view);

					$forum_sql = (!empty($no_view) ? ' AND t.forum_id NOT IN ('.implode(',', $no_view).')' : '');
				}

				if (!empty($author) || !empty($keywords))
				{
					$this->registry->get('\Aura\extensions\hooks')->fire('search.searching.floodprotection');

					// Flood protection
					if ($this->user['last_search'] && (CURRENT_TIMESTAMP - $this->user['last_search']) < $this->user['g_search_flood'] && (CURRENT_TIMESTAMP - $this->user['last_search']) >= 0)
						$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Search flood', $this->user['g_search_flood'], $this->user['g_search_flood'] - (CURRENT_TIMESTAMP - $this->user['last_search'])));

					$update = array(
						'last_search' => CURRENT_TIMESTAMP,
					);

					$data = array(
						':id' => (($this->user['is_guest']) ? get_remote_address() : $this->user['username']),
					);

					if (!$this->user['is_guest'])
						$this->db->update('users', $update, 'id=:id', $data);
					else
						$this->db->update('online', $update, 'ident=:id', $data);

					switch ($sort_by)
					{
						case 1:
							$sort_by_sql = ($show_as == 'topics') ? 't.poster' : 'p.poster';
							$sort_type = SORT_STRING;
							break;

						case 2:
							$sort_by_sql = 't.subject';
							$sort_type = SORT_STRING;
							break;

						case 3:
							$sort_by_sql = 't.forum_id';
							$sort_type = SORT_NUMERIC;
							break;

						case 4:
							$sort_by_sql = 't.last_post';
							$sort_type = SORT_NUMERIC;
							break;

						default:
							$sort_by_sql = ($show_as == 'topics') ? 't.last_post' : 'p.posted';
							$sort_type = SORT_NUMERIC;
							break;
					}

					// If it's a search for keywords
					if ($keywords)
					{
						// split the keywords into words
						$keywords_array = $this->idx->split_words($keywords, false);

						if (empty($keywords_array))
							$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No hits'));

						// Should we search in message body or topic subject specifically?
						$search_in_cond = ($search_in) ? (($search_in > 0) ? ' AND m.subject_match = 0' : ' AND m.subject_match = 1') : '';

						$word_count = 0;
						$match_type = 'and';

						$sort_data = array();
						foreach ($keywords_array as $cur_word)
						{
							$data = array();
							$data[] = $this->user['g_id'];
							switch ($cur_word)
							{
								case 'and':
								case 'or':
								case 'not':
									$match_type = $cur_word;
									break;

								default:
								{
									$where_cond = str_replace('*', '%', $cur_word);
									$data[] = '%'.$where_cond.'%';

									if ($this->idx->is_cjk($cur_word))
									{
										if ($search_in)
										{
											if ($search_in > 0)
												$where_cond = 'p.message LIKE ?';
											else
												$where_cond = 't.subject LIKE ?';
										}
										else
										{
											$data[] = '%'.$where_cond.'%';
											$where_cond = 'p.message LIKE ? OR t.subject LIKE ?';
										}

										$data = array_merge($data, $forums);	// Now merge the forums in with the other data
										$ps = $this->db->run('SELECT p.id AS post_id, p.topic_id, '.$sort_by_sql.' AS sort_by FROM '.$this->db->prefix.'posts AS p INNER JOIN '.$this->db->prefix.'topics AS t ON t.id=p.topic_id LEFT JOIN '.$this->db->prefix.'forum_perms AS fp ON (fp.forum_id=t.forum_id AND fp.group_id=?) WHERE (p.approved=1 AND t.deleted=0 AND '.$where_cond.') AND (fp.read_forum IS NULL OR fp.read_forum=1) '.$forum_sql, $data);
									}
									else
									{
										$data = array_merge($data, $forums);	
										$ps = $this->db->run('SELECT m.post_id, p.topic_id, '.$sort_by_sql.' AS sort_by FROM '.$this->db->prefix.'search_words AS w INNER JOIN '.$this->db->prefix.'search_matches AS m ON m.word_id=w.id INNER JOIN '.$this->db->prefix.'posts AS p ON p.id=m.post_id INNER JOIN '.$this->db->prefix.'topics AS t ON t.id=p.topic_id LEFT JOIN '.$this->db->prefix.'forum_perms AS fp ON (fp.forum_id=t.forum_id AND fp.group_id=?) WHERE p.approved=1 AND p.deleted=0 AND w.word LIKE ?'.$search_in_cond.' AND (fp.read_forum IS NULL OR fp.read_forum=1) '.$forum_sql, $data);
									}

									$row = array();
									foreach ($ps as $temp)
									{
										$row[$temp['post_id']] = $temp['topic_id'];

										if (!$word_count)
										{
											$keyword_results[$temp['post_id']] = $temp['topic_id'];
											$sort_data[$temp['post_id']] = $temp['sort_by'];
										}
										else if ($match_type == 'or')
										{
											$keyword_results[$temp['post_id']] = $temp['topic_id'];
											$sort_data[$temp['post_id']] = $temp['sort_by'];
										}
										else if ($match_type == 'not')
										{
											unset($keyword_results[$temp['post_id']]);
											unset($sort_data[$temp['post_id']]);
										}
									}

									if ($match_type == 'and' && $word_count)
									{
										foreach ($keyword_results as $post_id => $topic_id)
										{
											if (!isset($row[$post_id]))
											{
												unset($keyword_results[$post_id]);
												unset($sort_data[$post_id]);
											}
										}
									}

									++$word_count;
									$this->db->free_result($ps);

									break;
								}
							}
						}

						// Sort the results - annoyingly array_multisort re-indexes arrays with numeric keys, so we need to split the keys out into a separate array then combine them again after
						$post_ids = array_keys($keyword_results);
						$topic_ids = array_values($keyword_results);

						array_multisort(array_values($sort_data), $sort_dir == 'DESC' ? SORT_DESC : SORT_ASC, $sort_type, $post_ids, $topic_ids);

						// combine the arrays back into a key=>value array (array_combine is PHP5 only unfortunately)
						$num_results = count($keyword_results);
						$keyword_results = array();
						for ($i = 0;$i < $num_results;$i++)
							$keyword_results[$post_ids[$i]] = $topic_ids[$i];

						unset($sort_data, $post_ids, $topic_ids);
					}

					// If it's a search for author name (and that author name isn't Guest)
					if ($author && $author != 'guest' && $author != utf8_strtolower($this->lang->t('Guest')))
					{
						$data = array(
							':username'	=>	$author
						);
						
						$ps = $this->db->select('users', 'id', $data, 'username LIKE :username');
						if ($ps->rowCount())
						{
							$user_ids = $data = $markers = array();
							$ps->setFetchMode(PDO::FETCH_COLUMN, 0);
							
							$data[] = $this->user['g_id'];
							foreach ($ps as $uid)
							{
								$data[] = $uid;
								$markers[] = '?';
							}

							$data = array_merge($data, $forums);
							$ps = $this->db->run('SELECT p.id AS post_id, p.topic_id FROM '.$this->db->prefix.'posts AS p INNER JOIN '.$this->db->prefix.'topics AS t ON t.id=p.topic_id LEFT JOIN '.$this->db->prefix.'forum_perms AS fp ON (fp.forum_id=t.forum_id AND fp.group_id=?) WHERE (fp.read_forum IS NULL OR fp.read_forum=1) AND p.approved=1 AND p.deleted=0 AND p.poster_id IN('.implode(',', $markers).')'.$forum_sql.' ORDER BY '.$sort_by_sql.' '.$sort_dir, $data);
							foreach ($ps as $temp)
								$author_results[$temp['post_id']] = $temp['topic_id'];

							$this->db->free_result($ps);
						}
					}

					// If we searched for both keywords and author name we want the intersection between the results
					if ($author && $keywords)
					{
						$search_ids = array_intersect_assoc($keyword_results, $author_results);
						$search_type = array('both', array($keywords, utf8_trim($_GET['author'])), implode(',', $forums), $search_in);
					}
					else if ($keywords)
					{
						$search_ids = $keyword_results;
						$search_type = array('keywords', $keywords, implode(',', $forums), $search_in);
					}
					else
					{
						$search_ids = $author_results;
						$search_type = array('author', utf8_trim($_GET['author']), implode(',', $forums), $search_in);
					}

					unset($keyword_results, $author_results);
					$search_ids = ($show_as == 'topics') ? array_values($search_ids) : array_keys($search_ids);

					$markers = array();
					$search_ids = array_unique($search_ids);
					for ($i= 0; $i < count($search_ids); $i++)
						$markers[] = '?';

					$num_hits = count($search_ids);
					if (!$num_hits)
						$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No hits'));
				}
				else if ($action == 'show_new' || $action == 'show_recent' || $action == 'show_replies' || $action == 'show_user_posts' || $action == 'show_user_topics' || $action == 'show_subscriptions' || $action == 'show_unanswered')
				{
					$search_type = array('action', $action);
					$show_as = 'topics';
					// We want to sort things after last post
					$sort_by = 0;
					$sort_dir = 'DESC';

					// If it's a search for new posts since last visit
					if ($action == 'show_new')
					{
						if ($this->user['is_guest'])
							$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

						$fid = isset($_GET['fid']) ? intval($_GET['fid']) : null;
						$data = array($this->user['g_id'], $this->user['last_visit']);

						if ($fid != '')
						{
							if (!isset($aura_forums[$fid]))
								$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'));
							
							if ($aura_forums[$fid]['password'] != '')
								$this->registry->get('\Aura\cookie\cookie')->check_forum_login_cookie($fid, $aura_forums[$fid]['password']);

							$forum_sql = ' AND t.forum_id = ?';
							$data[] = $fid;
						}
						else
							$data = array_merge($data, $forums);

						$ps = $this->db->run('SELECT t.id FROM '.$this->db->prefix.'topics AS t LEFT JOIN '.$this->db->prefix.'forum_perms AS fp ON (fp.forum_id=t.forum_id AND fp.group_id = ?) WHERE (fp.read_forum IS NULL OR fp.read_forum=1) AND t.approved=1 AND t.deleted=0 AND t.last_post>? AND t.moved_to IS NULL'.$forum_sql.' ORDER BY t.last_post DESC', $data);
						$num_hits = $ps->rowCount();

						if (!$num_hits)
							$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No new posts'));
					}
					// If it's a search for recent posts (in a certain time interval)
					else if ($action == 'show_recent')
					{
						$fid = isset($_GET['fid']) ? intval($_GET['fid']) : null;
						$data = array($this->user['g_id'], (CURRENT_TIMESTAMP - $interval));
						
						if ($fid != '')
						{
							$forum_sql .= ' AND t.forum_id = ?';
							$data[] = $fid;
						}

						$data = array_merge($data, $forums);
						$ps = $this->db->run('SELECT t.id FROM '.$this->db->prefix.'topics AS t LEFT JOIN '.$this->db->prefix.'forum_perms AS fp ON (fp.forum_id=t.forum_id AND fp.group_id=?) WHERE (fp.read_forum IS NULL OR fp.read_forum=1) AND t.approved=1 AND t.deleted=0 AND t.last_post>? AND t.moved_to IS NULL'.$forum_sql.' ORDER BY t.last_post DESC', $data);
						$num_hits = $ps->rowCount();

						if (!$num_hits)
							$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No recent posts'));
					}
					// If it's a search for topics in which the user has posted
					else if ($action == 'show_replies')
					{
						$data = array($this->user['g_id'], $this->user['id']);
						$ps = $this->db->run('SELECT t.id FROM '.$this->db->prefix.'topics AS t INNER JOIN '.$this->db->prefix.'posts AS p ON t.id=p.topic_id LEFT JOIN '.$this->db->prefix.'forum_perms AS fp ON (fp.forum_id=t.forum_id AND fp.group_id=?) WHERE (fp.read_forum IS NULL OR fp.read_forum=1) AND t.approved=1 AND t.deleted=0 AND p.poster_id=? GROUP BY t.id ORDER BY t.last_post DESC', $data);
						$num_hits = $ps->rowCount();

						if (!$num_hits)
							$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No user posts'));
					}
					// If it's a search for posts by a specific user ID
					else if ($action == 'show_user_posts')
					{
						$show_as = 'posts';

						$data = array($this->user['g_id'], $user_id);
						$ps = $this->db->run('SELECT p.id FROM '.$this->db->prefix.'posts AS p INNER JOIN '.$this->db->prefix.'topics AS t ON p.topic_id=t.id LEFT JOIN '.$this->db->prefix.'forum_perms AS fp ON (fp.forum_id=t.forum_id AND fp.group_id=?) WHERE (fp.read_forum IS NULL OR fp.read_forum=1) AND p.approved=1 AND p.deleted=0 AND p.poster_id=? ORDER BY p.posted DESC', $data);
						$num_hits = $ps->rowCount();

						if (!$num_hits)
							$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No user posts'));

						// Pass on the user ID so that we can later know whose posts we're searching for
						$search_type[2] = $user_id;
					}
					// If it's a search for topics by a specific user ID
					else if ($action == 'show_user_topics')
					{
						$data = array($this->user['g_id'], $user_id);
						$ps = $this->db->run('SELECT t.id FROM '.$this->db->prefix.'topics AS t INNER JOIN '.$this->db->prefix.'posts AS p ON t.first_post_id=p.id LEFT JOIN '.$this->db->prefix.'forum_perms AS fp ON (fp.forum_id=t.forum_id AND fp.group_id=?) WHERE (fp.read_forum IS NULL OR fp.read_forum=1) AND t.approved=1 AND t.deleted=0 AND p.poster_id=? ORDER BY t.last_post DESC', $data);
						$num_hits = $ps->rowCount();

						if (!$num_hits)
							$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No user topics'));

						// Pass on the user ID so that we can later know whose topics we're searching for
						$search_type[2] = $user_id;
					}
					// If it's a search for subscribed topics
					else if ($action == 'show_subscriptions')
					{
						if ($this->user['is_guest'])
							$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');
						
						$data = array($user_id, $this->user['g_id']);
						$ps = $this->db->run('SELECT t.id FROM '.$this->db->prefix.'topics AS t INNER JOIN '.$this->db->prefix.'topic_subscriptions AS s ON (t.id=s.topic_id AND s.user_id=?) LEFT JOIN '.$this->db->prefix.'forum_perms AS fp ON (fp.forum_id=t.forum_id AND fp.group_id=?) WHERE (fp.read_forum IS NULL OR fp.read_forum=1) AND t.approved=1 AND t.deleted=0 ORDER BY t.last_post DESC', $data);
						$num_hits = $ps->rowCount();

						if (!$num_hits)
							$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No subscriptions'));

						// Pass on user ID so that we can later know whose subscriptions we're searching for
						$search_type[2] = $user_id;
					}
					// If it's a search for unanswered posts
					else
					{
						$data = array($this->user['g_id']);
						$ps = $this->db->run('SELECT t.id FROM '.$this->db->prefix.'topics AS t LEFT JOIN '.$this->db->prefix.'forum_perms AS fp ON (fp.forum_id=t.forum_id AND fp.group_id=?) WHERE (fp.read_forum IS NULL OR fp.read_forum=1) AND t.approved=1 AND t.deleted=0 AND t.num_replies=0 AND t.moved_to IS NULL ORDER BY t.last_post DESC', $data);
						$num_hits = $ps->rowCount();

						if (!$num_hits)
							$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No unanswered'));
					}

					$search_ids = $markers = array();
					foreach ($ps as $row)
					{
						$markers[] = '?';
						$search_ids[] = $row['id'];
					}

					$this->db->free_result($ps);
				}
				else
				{
					$this->registry->get('\Aura\extensions\hooks')->fire('search.searching.customsearch');
					$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');
				}

				// Prune "old" search results
				$old_searches = $placeholders = array();
				$ps = $this->db->select('online', 'ident');
				if ($ps->rowCount())
				{
					$ps->setFetchMode(PDO::FETCH_COLUMN, 0);
					foreach ($ps as $cur_ident)
					{
						$placeholders[] = '?';
						$old_searches[] = $cur_ident;
					}

					$this->db->delete('search_cache', 'ident NOT IN('.implode(',', $placeholders).')', $old_searches);
				}

				// Fill an array with our results and search properties
				$temp = serialize(array(
					'search_ids'		=> serialize($search_ids),
					'num_hits'			=> $num_hits,
					'sort_by'			=> $sort_by,
					'sort_dir'			=> $sort_dir,
					'show_as'			=> $show_as,
					'search_type'		=> $search_type
				));

				$search_id = mt_rand(1, 2147483647);

				$ident = ($this->user['is_guest']) ? get_remote_address() : $this->user['username'];
				$insert = array(
					'id'	=>	$search_id,
					'ident'	=>	$ident,
					'search_data'	=>	$temp,
				);

				$this->db->insert('search_cache', $insert);
				if ($search_type[0] != 'action')
				{
					//$this->db->end_transaction();

					// Redirect the user to the cached result page
					header('Location: '.$this->registry->get('\Aura\links')->aura_link($this->rewrite->url['search_cache'], array($search_id)));
					exit;
				}
			}

			$forum_actions = array();
			if (!$this->user['is_guest'] && $search_type[0] == 'action' && $search_type[1] == 'show_new')
			{
				// If we're just viewing the new posts for a single forum
				if (isset($fid))
					$forum_actions[] = array('href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['mark_forum_read'], array($fid, $this->registry->get('\Aura\auth\csrf')->generate('viewforum'))), 'title' => $this->lang->t('Mark forum read'));
				else
					$forum_actions[] = array('href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['mark_read'], $this->registry->get('\Aura\auth\csrf')->generate('index')), 'title' => $this->lang->t('Mark all as read'));

				$forum_actions = $this->registry->get('\Aura\extensions\hooks')->fire('search.searching.forumactions', $forum_actions);
			}

			// Fetch results to display
			if (!empty($search_ids))
			{
				switch ($sort_by)
				{
					case 1:
						$sort_by_sql = ($show_as == 'topics') ? 't.poster' : 'p.poster';
						break;

					case 2:
						$sort_by_sql = 't.subject';
						break;

					case 3:
						$sort_by_sql = 't.forum_id';
						break;

					default:
						$sort_by_sql = ($show_as == 'topics') ? 't.last_post' : 'p.posted';
						break;
				}

				// Determine the topic or post offset (based on $_GET['p'])
				$per_page = ($show_as == 'posts') ? $this->user['disp_posts'] : $this->user['disp_topics'];
				$num_pages = ceil($num_hits / $per_page);

				$p = (!isset($_GET['p']) || $_GET['p'] <= 1 || $_GET['p'] > $num_pages) ? 1 : intval($_GET['p']);
				$start_from = $per_page * ($p - 1);

				// throw away the first $start_from of $search_ids, only keep the top $per_page of $search_ids
				$search_ids = array_slice($search_ids, $start_from, $per_page);
				$markers = array();
				for ($i = 0; $i < count($search_ids); $i++)
					$markers[] = '?';

				// Run the query and fetch the results
				if ($show_as == 'posts')
					$ps = $this->db->run('SELECT u.group_id, p.id AS pid, p.poster AS pposter, p.posted AS pposted, p.poster_id, p.message, p.hide_smilies, t.id AS tid, t.poster, t.subject, t.question, t.first_post_id, t.last_post, t.last_post_id, t.last_poster, t.num_replies, t.forum_id, f.forum_name FROM '.$this->db->prefix.'posts AS p INNER JOIN '.$this->db->prefix.'topics AS t ON t.id=p.topic_id INNER JOIN '.$this->db->prefix.'forums AS f ON f.id=t.forum_id LEFT JOIN '.$this->db->prefix.'users AS u ON (p.poster_id=u.id) WHERE p.id IN('.implode(',', $markers).') ORDER BY '.$sort_by_sql.' '.$sort_dir, $search_ids);
				else
					$ps = $this->db->run('SELECT u.id AS uid, u.group_id, u.use_gravatar, u.email, up.id AS up_id, up.group_id AS up_group_id, t.id AS tid, t.poster, t.subject, t.question, t.last_post, t.last_post_id, t.last_poster, t.num_replies, t.closed, t.sticky, t.forum_id, f.forum_name FROM '.$this->db->prefix.'topics AS t INNER JOIN '.$this->db->prefix.'forums AS f ON f.id=t.forum_id LEFT JOIN '.$this->db->prefix.'users AS u ON (t.last_poster=u.username) LEFT JOIN '.$this->db->prefix.'users AS up ON (t.poster=up.username) WHERE t.id IN('.implode(',', $markers).') ORDER BY '.$sort_by_sql.' '.$sort_dir, $search_ids);

				$search_set = array();
				foreach($ps as $row)
					$search_set[] = $row;

				$crumbs_text = array();
				$crumbs_text['show_as'] = $this->lang->t('Search');

				if ($search_type[0] == 'action')
				{
					if ($search_type[1] == 'show_user_topics')
						$crumbs_text['search_type'] = array('href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['search_user_topics'], array($search_type[2])), 'title' => $this->lang->t('Quick search show_user_topics', $search_set[0]['poster']));
					else if ($search_type[1] == 'show_user_posts')
						$crumbs_text['search_type'] = array('href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['search_user_posts'], array($search_type[2])), 'title' => $this->lang->t('Quick search show_user_posts', $search_set[0]['pposter']));
					else if ($search_type[1] == 'show_subscriptions')
					{
						// Fetch username of subscriber
						$subscriber_id = $search_type[2];
						$data = array(
							':id'	=>	$subscriber_id,
						);
						$ps = $this->db->select('users', 'username', $data, 'id=:id');
						if ($ps->rowCount())
							$subscriber_name = $ps->fetchColumn();
						else
							$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

						$crumbs_text['search_type'] = array('href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['search_subscriptions'], array($subscriber_id)), 'title' => $this->lang->t('Quick search show_subscriptions', $subscriber_name));
					}
					else
					{
						switch ($search_type[1])
						{
							case 'show_replies':
								$link = $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['search_replies']);
							break;
							case 'show_new':
								$link = $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['search_new']);
							break;
							case 'show_recent':
								$link = $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['search_recent']);
							break;
							case 'show_unanswered':
								$link = $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['search_unanswered']);
							break;
						}

						$crumbs_text['search_type'] = array('href' => $link, 'title' => $this->lang->t('Quick search '.$search_type[1]));
					}
				}
				else
				{
					$keywords = $author = '';
					if ($search_type[0] == 'both')
					{
						list ($keywords, $author) = $search_type[1];
						$crumbs_text['search_type'] = $this->lang->t('By both show as '.$show_as, $keywords, $author);
					}
					else if ($search_type[0] == 'keywords')
					{
						$keywords = $search_type[1];
						$crumbs_text['search_type'] = $this->lang->t('By keywords show as '.$show_as, $keywords);
					}
					else if ($search_type[0] == 'author')
					{
						$author = $search_type[1];
						$crumbs_text['search_type'] = $this->lang->t('By user show as '.$show_as, $author);
					}

					$crumbs_text['search_type'] = array('href' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['search_result'], array(urlencode($keywords), urlencode($author), $search_type[2], $search_type[3], $sort_by, $sort_dir, $show_as)), 'title' => $crumbs_text['search_type']);
				}

				$this->lang->load('topic');
				$this->template->header = array(
					'page_title' => array($this->config['o_board_title'], $this->lang->t('Search results')),
					'active_page' => 'search',
				);

				$this->template->header = $this->registry->get('\Aura\extensions\hooks')->fire('search.searching.header', $this->template->header);
				if ($show_as == 'topics')
					$topic_count = 0;
				else if ($show_as == 'posts')
				{
					$parser = $this->registry->get('\Aura\message\parser');
					$post_count = 0;
				}

				// Get topic/forum tracking data
				if (!$this->user['is_guest'])
					$tracked_topics = $this->registry->get('\Aura\cookie\tracked')->get_tracked_topics();

				$results = array();
				foreach ($search_set as $cur_search)
				{
					if ($this->config['o_censoring'] == '1')
						$cur_search['subject'] = $this->registry->get('\Aura\message\bbcode')->censor_words($cur_search['subject']);

					if ($show_as == 'posts')
					{
						++$post_count;
						if ($this->config['o_censoring'] == '1')
							$cur_search['message'] = $this->registry->get('\Aura\message\bbcode')->censor_words($cur_search['message']);

						$results[] = array(
							'pid' => $cur_search,
							'message' => $parser->parse_message($cur_search['message'], $cur_search['hide_smilies']),
							'posted' => $this->registry->get('\Aura\aura_time')->format($cur_search['pposted']),
							'topic_url' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['topic'], array($cur_search['tid'], \Aura\url\url::replace($cur_search['subject']))),
							'post_url' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['post'], array($cur_search['pid'])),
							'post_no' => ($start_from + $post_count),
							'post_count' => $post_count,
							'forum' => array('url' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['forum'], array($cur_search['forum_id'], \Aura\url\url::replace($cur_search['forum_name']))), 'name' => $cur_search['forum_name']),
							'subject' => $cur_search['subject'],
							'poster' => ($cur_search['poster_id'] > 1) ? $this->functions->colourise_group($cur_search['pposter'], $cur_search['group_id'], $cur_search['poster_id']) : '',
							'post_id' => $cur_search['pid'],
							'first_post_id' => $cur_search['first_post_id'],
							'num_replies' => $this->functions->forum_number_format($cur_search['num_replies']),
							'viewed' => (!$this->user['is_guest'] && $cur_search['last_post'] > $this->user['last_visit'] && (!isset($tracked_topics['topics'][$cur_search['tid']]) || $tracked_topics['topics'][$cur_search['tid']] < $cur_search['last_post']) && (!isset($tracked_topics['forums'][$cur_search['forum_id']]) || $tracked_topics['forums'][$cur_search['forum_id']] < $cur_search['last_post'])) ? false : true,
						);

						$results = $this->registry->get('\Aura\extensions\hooks')->fire('search.searching.showas.posts', $results);
					}
					else
					{
						++$topic_count;
						$url_subject = \Aura\url\url::replace($cur_search['subject']);
						$num_pages_topic = ceil(($cur_search['num_replies'] + 1) / $this->user['disp_posts']);

						$results[$cur_search['tid']] = array(
							'count' => ++$topic_count,
							'topic_count' => $this->functions->forum_number_format($topic_count + $start_from),
							'cur_search' => $cur_search,
							'topic_poster' => ($cur_search['up_id'] > 1) ? $this->functions->colourise_group($cur_search['poster'], $cur_search['up_group_id'], $cur_search['up_id']) : $this->functions->colourise_group($cur_search['poster'], AURA_GUEST),
							'subject' => $cur_search['subject'],
							'sticky' => $cur_search['sticky'],
							'closed' => $cur_search['closed'],
							'question' => $cur_search['question'],
							'topic_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['topic'], array($cur_search['tid'], $url_subject)),
							'num_pages' => $num_pages_topic,
							'pagination' => $this->registry->get('\Aura\pagination')->paginate($num_pages_topic, -1, $this->rewrite->url['topic_paginate'], array($cur_search['tid'], $url_subject)),
							'new' => (!$this->user['is_guest'] && $cur_search['last_post'] > $this->user['last_visit'] && (!isset($tracked_topics['topics'][$cur_search['tid']]) || $tracked_topics['topics'][$cur_search['tid']] < $cur_search['last_post']) && (!isset($tracked_topics['forums'][$cur_search['forum_id']]) || $tracked_topics['forums'][$cur_search['forum_id']] < $cur_search['last_post'])) ? '1' : '0',
							'last_post_avatar' => $this->registry->get('\Aura\avatar')->generate($cur_search['uid'], $cur_search['email'], $cur_search['use_gravatar'], array(32, 32)),
							'last_post_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['post'], array($cur_search['last_post_id'])),
							'last_post' => $this->registry->get('\Aura\aura_time')->format($cur_search['last_post']),
							'last_poster' => ($cur_search['uid'] > 1) ? $this->functions->colourise_group($cur_search['last_poster'], $cur_search['group_id'], $cur_search['uid']) : $this->functions->colourise_group($cur_search['last_poster'], AURA_GUEST),
							'num_replies' => $this->functions->forum_number_format($cur_search['num_replies']),
							'forum' => array('url' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['forum'], array($cur_search['forum_id'], \Aura\url\url::replace($cur_search['forum_name']))), 'name' => $cur_search['forum_name']),
						);

						if ($results[$cur_search['tid']]['new'] == '1')
							$results[$cur_search['tid']]['new_link'] = $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['topic_new_posts'], array($cur_search['tid'], $url_subject));

						$results = $this->registry->get('\Aura\extensions\hooks')->fire('search.searching.showas.topics', $results);
					}
				}

				$args = $this->registry->get('\Aura\extensions\hooks')->fire('search.searching.render');
				$args = (is_array($args) ? $args : array());

				$tpl = $this->template->load('search_results.tpl');
				$this->template->output($tpl,
					array_merge(
						array(
							'forum_actions' => $forum_actions,
							'index_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['index']),
							'search_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['search']),
							'show_as' => $show_as,
							'pagination' => $this->registry->get('\Aura\pagination')->paginate($num_pages, $p, $this->rewrite->url['search_pagination'], array($search_id)),
							'crumbs_text' => $crumbs_text,
							'results' => $results,
						),
						$args
					)
				);
			}
			else
				$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No hits'));
		}
	}

	/*
	 * Setup and review a few things before we start
	 */
	protected function configure_search()
	{
		$this->lang->load('search');
		$this->lang->load('forum');

		if ($this->user['g_read_board'] == '0')
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No view'), false, '403 Forbidden');
		else if ($this->user['g_search'] == '0')
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No search permission'), false, '403 Forbidden');

		$this->idx = $this->registry->get('\Aura\search\idx');

		$this->registry->get('\Aura\extensions\hooks')->fire('search.configure');
	}
}