<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class rss_controller extends base_controller
{
	/**
	 * App entry point, run the controller and output the RSS feed
	 */
	public function execute()
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('feed.immediate');

		$generator = $this->registry->get('\Aura\feed');
		$feed = $generator->generate_feed();

		// Send XML/no cache headers
		header('Content-Type: application/xml; charset=utf-8');
		header('Expires: '.gmdate('D, d M Y H:i:s').' GMT');
		header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
		header('Pragma: public');

		echo '<?xml version="1.0" encoding="utf-8"?>'."\n";
		echo '<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom">'."\n";
		echo "\t".'<channel>'."\n";
		echo "\t\t".'<atom:link href="'.aura_htmlspecialchars(get_current_url()).'" rel="self" type="application/rss+xml" />'."\n";
		echo "\t\t".'<title><![CDATA['.$generator->escape_cdata($feed['title']).']]></title>'."\n";
		echo "\t\t".'<link>'.aura_htmlspecialchars($feed['link']).'</link>'."\n";
		echo "\t\t".'<description><![CDATA['.$generator->escape_cdata($feed['description']).']]></description>'."\n";
		echo "\t\t".'<lastBuildDate>'.gmdate('r', count($feed['items']) ? $feed['items'][0]['pubdate'] : CURRENT_TIMESTAMP).'</lastBuildDate>'."\n";

		if ($this->config['o_show_version'] == '1')
			echo "\t\t".'<generator>Aura Web Software '.$this->config['o_cur_version'].'</generator>'."\n";
		else
			echo "\t\t".'<generator>Aura Web Software</generator>'."\n";

		foreach ($feed['items'] as $item)
		{
			echo "\t\t".'<item>'."\n";
			echo "\t\t\t".'<title><![CDATA['.$generator->escape_cdata($item['title']).']]></title>'."\n";
			echo "\t\t\t".'<link>'.aura_htmlspecialchars($item['link']).'</link>'."\n";
			echo "\t\t\t".'<description><![CDATA['.$generator->escape_cdata($item['description']).']]></description>'."\n";
			echo "\t\t\t".'<author><![CDATA['.(isset($item['author']['email']) ? $generator->escape_cdata($item['author']['email']) : 'email@example.com').' ('.$generator->escape_cdata($item['author']['name']).')]]></author>'."\n";
			echo "\t\t\t".'<pubDate>'.gmdate('r', $item['pubdate']).'</pubDate>'."\n";
			echo "\t\t\t".'<guid>'.aura_htmlspecialchars($item['link']).'</guid>'."\n";

			echo "\t\t".'</item>'."\n";

			$this->registry->get('\Aura\extensions\hooks')->fire('feed.rss.output');
		}

		echo "\t".'</channel>'."\n";
		echo '</rss>'."\n";
	}
}