<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class atom_controller extends base_controller
{
	/**
	 * App entry point, run the controller and output the Atom feed
	 */
	public function execute()
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('feed.immediate');

		$generator = $this->registry->get('\Aura\feed');
		$feed = $generator->generate_feed();

		// Send XML/no cache headers
		header('Content-Type: application/atom+xml; charset=utf-8');
		header('Expires: '.gmdate('D, d M Y H:i:s').' GMT');
		header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
		header('Pragma: public');

		echo '<?xml version="1.0" encoding="utf-8"?>'."\n";
		echo '<feed xmlns="http://www.w3.org/2005/Atom">'."\n";

		echo "\t".'<title type="html"><![CDATA['.$generator->escape_cdata($feed['title']).']]></title>'."\n";
		echo "\t".'<link rel="self" href="'.aura_htmlspecialchars(get_current_url()).'"/>'."\n";
		echo "\t".'<link href="'.aura_htmlspecialchars($feed['link']).'"/>'."\n";
		echo "\t".'<updated>'.gmdate('Y-m-d\TH:i:s\Z', count($feed['items']) ? $feed['items'][0]['pubdate'] : CURRENT_TIMESTAMP).'</updated>'."\n";

		if ($this->config['o_show_version'] == '1')
			echo "\t".'<generator version="'.$this->config['o_cur_version'].'">Aura</generator>'."\n";
		else
			echo "\t".'<generator>Aura</generator>'."\n";

		echo "\t".'<id>'.aura_htmlspecialchars($feed['link']).'</id>'."\n";

		$content_tag = ($feed['type'] == 'posts') ? 'content' : 'summary';

		foreach ($feed['items'] as $item)
		{
			echo "\t".'<entry>'."\n";
			echo "\t\t".'<title type="html"><![CDATA['.$generator->escape_cdata($item['title']).']]></title>'."\n";
			echo "\t\t".'<link rel="alternate" href="'.aura_htmlspecialchars($item['link']).'"/>'."\n";
			echo "\t\t".'<'.$content_tag.' type="html"><![CDATA['.$generator->escape_cdata($item['description']).']]></'.$content_tag.'>'."\n";
			echo "\t\t".'<author>'."\n";
			echo "\t\t\t".'<name><![CDATA['.$generator->escape_cdata($item['author']['name']).']]></name>'."\n";

			if (isset($item['author']['email']))
				echo "\t\t\t".'<email><![CDATA['.$generator->escape_cdata($item['author']['email']).']]></email>'."\n";

			if (isset($item['author']['uri']))
				echo "\t\t\t".'<uri>'.aura_htmlspecialchars($item['author']['uri']).'</uri>'."\n";

			echo "\t\t".'</author>'."\n";
			echo "\t\t".'<updated>'.gmdate('Y-m-d\TH:i:s\Z', $item['pubdate']).'</updated>'."\n";

			echo "\t\t".'<id>'.aura_htmlspecialchars($item['link']).'</id>'."\n";
			echo "\t".'</entry>'."\n";

			$this->registry->get('\Aura\extensions\hooks')->fire('feed.atom.output');
		}

		echo '</feed>'."\n";
	}
}