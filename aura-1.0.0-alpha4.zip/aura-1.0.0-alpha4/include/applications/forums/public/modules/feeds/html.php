<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class html_controller extends base_controller
{
	/**
	 * App entry point, run the controller and output the HTML feed
	 */
	public function execute()
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('feed.immediate');

		$generator = $this->registry->get('\Aura\feed');
		$feed = $generator->generate_feed();

		// The length at which topic subjects will be truncated (for HTML output)
		if (!defined('FORUM_EXTERN_MAX_SUBJECT_LENGTH'))
			define('FORUM_EXTERN_MAX_SUBJECT_LENGTH', 30);

		// Send the Content-type header in case the web server is setup to send something else
		header('Content-type: text/html; charset=utf-8');
		header('Expires: '.gmdate('D, d M Y H:i:s').' GMT');
		header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
		header('Pragma: public');

		foreach ($feed['items'] as $item)
		{
			if (utf8_strlen($item['title']) > FORUM_EXTERN_MAX_SUBJECT_LENGTH)
				$subject_truncated = aura_htmlspecialchars(utf8_trim(utf8_substr($item['title'], 0, (FORUM_EXTERN_MAX_SUBJECT_LENGTH - 5)))).' …';
			else
				$subject_truncated = aura_htmlspecialchars($item['title']);

			echo '<li><a href="'.aura_htmlspecialchars($item['link']).'" title="'.aura_htmlspecialchars($item['title']).'">'.$subject_truncated.'</a></li>'."\n";

			$this->registry->get('\Aura\extensions\hooks')->fire('feed.html.output');
		}
	}
}