<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class index_controller extends base_controller
{
	/**
	 *  Main entry point- display the inbox
	 */
	public function execute()
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('messenger.index.immediate');

		if ($this->user['g_read_board'] == '0')
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No view'), false, '403 Forbidden');

		if ($this->user['is_guest'])
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'));

		if ($this->config['o_private_messaging'] == '0' || $this->user['g_use_pm'] == '0' || $this->user['pm_enabled'] == '0')
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'));

		$this->registry->get('\Aura\extensions\hooks')->fire('messenger.authorised');
		$this->lang->load('pms');

		$box_id = isset($_GET['id']) ? intval($_GET['id']) : 2;	// Default to your inbox

		if (isset($_POST['delete']))
			$this->delete_messages();
		elseif (isset($_POST['move']))
			$this->move_messages();

		list($box_name, $messages) = $this->fetch_num_messages($box_id);

		$num_pages = ceil($messages / $this->user['disp_topics']);
		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('PM'), $this->lang->t('PM Inbox')),
			'common_javascript' => true,
			'allow_index' => true,
			'active_page' => 'pm',
			'p' => (!isset($_GET['p']) || $_GET['p'] <= 1 || $_GET['p'] > $num_pages) ? 1 : intval($_GET['p']),
		);

		$start_from = $this->user['disp_topics'] * ($this->template->header['p'] - 1);

		$this->template->header = $this->registry->get('\Aura\extensions\hooks')->fire('messenger.index.immediate', $this->template->header);
		$topics = $this->fetch_inbox_messages($box_id, $start_from);

		$args = $this->registry->get('\Aura\extensions\hooks')->fire('messenger.index.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('inbox.tpl');
		$this->template->output($tpl,
			array_merge(
				array(
					'index_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['index']),
					'inbox_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['inbox']),
					'box_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['box'], array($box_id)),
					'message_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['send_message']),
					'box_name' => $box_name,
					'pm_menu' => $this->registry->get('\Aura\messenger\menu')->generate($box_id),
					'csrf_token' => $this->registry->get('\Aura\auth\csrf')->generate(),
					'page' => $this->template->header['p'],
					'pagination' => $this->registry->get('\Aura\pagination')->paginate($num_pages, $this->template->header['p'], $this->rewrite->url['box'], array($box_id)),
					'box_id' => $box_id,
					'topics' => $topics,
				),
				$args
			)
		);
	}

	/**
	 *  Fetch the total number of messages in this inbox
	 */
	protected function fetch_num_messages($box_id)
	{
		$data = array(
			':uid'	=>	$this->user['id'],
			':fid'	=>	$box_id,
		);

		// Check we own this box
		$ps = $this->db->select('folders', 'name', $data, '(user_id=:uid OR user_id=1) AND id=:fid');
		if (!$ps->rowCount())
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'));
		else
			$box_name = $ps->fetchColumn();

		$box_name = $this->registry->get('\Aura\extensions\hooks')->fire('messenger.index.messages.boxname', $box_name);
		$data = array(
			':fid' => $box_id,
			':uid' => $this->user['id'],
		);

		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'pms_data',
				'as' => 'cd',
				'on' => 'c.id=cd.topic_id',
			),
		);

		$ps = $this->db->join('conversations', 'c', $join, 'COUNT(c.id)', $data, 'cd.user_id=:uid AND cd.deleted=0 AND (cd.folder_id=:fid '.(($box_id == 1) ? 'OR cd.viewed=0)' : ')'));
		$messages = $ps->fetchColumn();

		$messages = $this->registry->get('\Aura\extensions\hooks')->fire('messenger.index.messages.messages', $messages);
		return array($box_name, $messages);
	}

	/**
	 * Fetches the user specific messages from an inbox ID
	 */
	protected function fetch_inbox_messages($box_id, $start_from)
	{
		$data = array(
			':uid' => $this->user['id'],
			':fid' => $box_id,
			':start' => $start_from,
			':limit' => $this->user['disp_topics'],
		);

		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'pms_data',
				'as' => 'cd',
				'on' => 'c.id=cd.topic_id',
			),
			array(
				'type' => 'LEFT',
				'table' => 'users',
				'as' => 'u',
				'on' => 'u.id=c.poster_id',
			),
			array(
				'type' => 'LEFT',
				'table' => 'users',
				'as' => 'l',
				'on' => 'l.username=c.last_poster',
			),
		);

		$ps = $this->db->join('conversations', 'c', $join, 'c.id, c.subject, c.poster, c.poster_id, c.num_replies, c.last_post, c.last_poster, c.last_post_id, cd.viewed, u.group_id AS poster_gid, u.email, u.use_gravatar, l.id AS last_poster_id, l.group_id AS last_poster_gid', $data, 'cd.user_id=:uid AND cd.deleted=0 AND (cd.folder_id=:fid '.(($box_id == 1) ? 'OR cd.viewed=0)' : ')'), 'c.last_post DESC LIMIT :start,:limit');

		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'users',
				'as' => 'u',
				'on' => 'cd.user_id=u.id',
			),
		);

		$topics = array();
		foreach ($ps as $cur_topic)
		{
			$data = array(
					':tid' => $cur_topic['id']
			);

			$users = array();
			$ps1 = $this->db->join('pms_data', 'cd', $join, 'cd.user_id AS id, u.username, u.group_id', $data, 'topic_id=:tid');
			foreach ($ps1 as $user_data)
			{
				$users[] = $this->functions->colourise_group($user_data['username'], $user_data['group_id'], $user_data['id']);
				$users = $this->registry->get('\Aura\extensions\hooks')->fire('messenger.index.topics.users', $users);
			}

			if ($this->config['o_censoring'] == '1')
				$cur_topic['subject'] = $this->registry->get('\Aura\message\bbcode')->censor_words($cur_topic['subject']);

			$num_pages_topic = ceil(($cur_topic['num_replies'] + 1) / $this->user['disp_posts']);
			$topics[] = array(
				'viewed' => $cur_topic['viewed'],
				'id' => $cur_topic['id'],
				'poster' => $this->functions->colourise_group($cur_topic['poster'], $cur_topic['poster_gid'], $cur_topic['poster_id']),
				'users' => $users,
				'last_post_avatar' => $this->registry->get('\Aura\avatar')->generate($cur_topic['last_poster_id'], $cur_topic['email'], $cur_topic['use_gravatar'], array(32, 32)),
				'last_post_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['pms_post'], array($cur_topic['last_post_id'])),
				'last_post' => $this->registry->get('\Aura\aura_time')->format($cur_topic['last_post']),
				'last_poster' => $this->functions->colourise_group($cur_topic['last_poster'], $cur_topic['last_poster_gid'], $cur_topic['last_poster_id']),
				'num_replies' => $this->functions->forum_number_format($cur_topic['num_replies']),
				'new_post_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['pms_new'], array($cur_topic['id'])),
				'pagination' => $this->registry->get('\Aura\pagination')->paginate($num_pages_topic, -1, $this->rewrite->url['pms_paginate'], array($cur_topic['id'])),
				'num_pages' => $num_pages_topic,
				'url' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['pms_view'], array($cur_topic['id'])),
				'subject' => $cur_topic['subject'],
			);

			$topics = $this->registry->get('\Aura\extensions\hooks')->fire('messenger.index.topics.topics', $topics);
		}

		return $topics;
	}

	/**
	 * Load the form to delete some messages
	 */
	protected function delete_messages()
	{
		if (!isset($_POST['topics']))
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Select more than one topic'));

		$topics = isset($_POST['topics']) && is_array($_POST['topics']) ? array_map('intval', $_POST['topics']) : array_map('intval', explode(',', $_POST['topics']));

		if (empty($topics))
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Select more than one topic'));

		if (isset($_POST['delete_comply']))
			$this->do_delete_messages($topics);
		else
		{
			$this->template->header = array(
				'page_title' => array($this->config['o_board_title'], $this->lang->t('PM'), $this->lang->t('PM Inbox')),
				'active_page' => 'pm',
			);

			$this->template->header = $this->registry->get('\Aura\extensions\hooks')->fire('messenger.index.delete.header', $this->template->header);
			$args = $this->registry->get('\Aura\extensions\hooks')->fire('messenger.index.delete.render');
			$args = (is_array($args) ? $args : array());

			$tpl = $this->template->load('delete_messages.tpl');
			$this->template->output($tpl,
				array_merge(
					array(
						'index_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['index']),
						'inbox_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['inbox']),
						'message_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['send_message']),
						'pm_menu' => $this->registry->get('\Aura\messenger\menu')->generate(),
						'topics' => $topics,
						'csrf_token' => $this->registry->get('\Aura\auth\csrf')->generate('delete_messages'),
					),
					$args
				)
			);
		}
	}

	/**
	 * Perform the deletion of some messages in the specified folder
	 */
	protected function do_delete_messages($topics)
	{
		$this->registry->get('\Aura\auth\csrf')->confirm('delete_messages');

		$markers = array();
		$data = array($this->user['id']);
		for ($i = 0; $i < count($topics); $i++)
		{
			$markers[] = '?';
			$data[] = $topics[$i];
		}

		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'pms_data',
				'as' => 'cd',
				'on' => 'c.id=cd.topic_id AND cd.user_id=?',
			),
		);

		$ps = $this->db->join('conversations', 'c', $join, 'SUM(c.num_replies)', $data, 'c.id IN ('.implode(',', $markers).')');
		$num_pms = ($ps->fetchColumn() + count($markers));	// The number of topic posts and the number of replies from all topics

		$this->db->run('UPDATE '.$this->db->prefix.'pms_data SET deleted=1 WHERE user_id=? AND topic_id IN ('.implode(',', $markers).')', $data);
		$update = array(
			':markers' => $num_pms,
			':id' => $this->user['id'],
		);

		$this->db->run('UPDATE '.$this->db->prefix.'users SET num_pms=num_pms-:markers WHERE id=:id', $update);
		unset($data[0]);

		// Now check if anyone left in the conversation has any of these topics undeleted. If so, then we leave them. Otherwise, actually delete them.
		foreach (array_values($data) as $tid)
		{
			$delete = array(
				':id' => $tid,
			);

			$ps = $this->db->select('pms_data', 1, $delete, 'topic_id=:id AND deleted=0');
			if ($ps->rowCount())	// People are still left
				continue;

			$this->db->delete('pms_data', 'topic_id=:id', $delete);
			$this->db->delete('conversations', 'id=:id', $delete);
			$this->db->delete('messages', 'topic_id=:id', $delete);

			$this->registry->get('\Aura\extensions\hooks')->fire('messenger.index.delete.deletemessages');
		}

		$this->registry->get('\Aura\extensions\hooks')->fire('messenger.index.delete.beforeredirect');
		$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['inbox']), $this->lang->t('Messages deleted'));
	}

	/**
	 * Load the form to move the messages to a different folder
	 */
	protected function move_messages()
	{
		if (!isset($_POST['topics']))
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Select more than one topic'));

		$topics	= isset($_POST['topics']) && is_array($_POST['topics']) ? array_map('intval', $_POST['topics']) : array_map('intval', explode(',', $_POST['topics']));

		if (empty($topics))
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Select more than one topic'));

		if (isset($_POST['move_comply']))
			$this->do_move_messages($topics);

		$data = array(
			':uid' => $this->user['id'],
		);

		$ps = $this->db->select('folders', 'name, id', $data, 'user_id=:uid OR user_id=1', 'id, user_id ASC');
		if (!$ps->rowCount())
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No available folders'));

		$this->registry->get('\Aura\extensions\hooks')->fire('messenger.index.move');

		$folders = array();
		foreach ($ps as $folder)
		{
			$folders[] = array('id' => $folder['id'], 'name' => $folder['name']);
			$folders = $this->registry->get('\Aura\extensions\hooks')->fire('messenger.index.move.folders', $folders);
		}

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('PM'), $this->lang->t('PM Inbox')),
			'active_page' => 'pm',
		);

		$this->template->header = $this->registry->get('\Aura\extensions\hooks')->fire('messenger.index.move.header', $this->template->header);
		$args = $this->registry->get('\Aura\extensions\hooks')->fire('messenger.index.move.header');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('move_messages.tpl');
		$this->template->output($tpl,
			array_merge(
				array(
					'index_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['index']),
					'inbox_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['inbox']),
					'message_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['send_message']),
					'csrf_token' => $this->registry->get('\Aura\auth\csrf')->generate('move_messages'),
					'pm_menu' => $this->registry->get('\Aura\messenger\menu')->generate(),
					'folders' => $folders,
					'topics' => $topics,
				),
				$args
			)
		);
	}

	/**
	 * Perform the move of the selected messages
	 */
	protected function do_move_messages($topics)
	{
		$this->registry->get('\Aura\auth\csrf')->confirm('move_messages');
		$folder = isset($_POST['folder']) ? intval($_POST['folder']) : 1;

		$markers = array();
		$update = array($folder);
		for ($i = 0; $i < count($topics); $i++)
		{
			$markers[] = '?';
			$update[] = $topics[$i];
		}

		$data = array(
			':fid' => $folder,
			':uid' => $this->user['id'],
		);

		$ps = $this->db->select('folders', 1, $data, 'id=:fid AND user_id=:uid OR user_id=1');
		if (!$ps->rowCount())
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'));	// Then they don't have permission to move them to this folder

		$update[] = $this->user['id'];
		$ps = $this->db->run('UPDATE '.$this->db->prefix.'pms_data SET folder_id=? WHERE topic_id IN ('.implode(',', $markers).') AND user_id=?', $update);

		$this->registry->get('\Aura\extensions\hooks')->fire('messenger.index.move.beforeredirect');
		$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['inbox']), $this->lang->t('Messages moved'));
	}
}