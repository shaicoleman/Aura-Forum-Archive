<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class folders_controller extends base_controller
{
	/*
	 * Main entry point, display the form
	 */
	public function execute()
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('messenger.folders.configure');

		$this->configure_pms();

		$errors = array();
		if (isset($_POST['add_folder']))
			$errors = $this->add_folder($errors);
		else if (isset($_POST['update']))
			$errors = $this->edit_folder($errors);
		else if (isset($_POST['remove']))
			$this->remove_folder();

		$data = array(
			':uid' => $this->user['id'],
		);

		$folders = array();
		$ps = $this->db->select('folders', 'name, id', $data, 'user_id=:uid');
		foreach ($ps as $cur_folder)
			$folders[] = array('id' => $cur_folder['id'], 'name' => $cur_folder['name']);

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('PM'), $this->lang->t('My folders 2')),
			'active_page' => 'pm',
			'required_fields' => array('req_folder' => $this->lang->t('Folder')),
			'focus_element' => array('folder', 'req_folder'),
		);

		$this->template->header = $this->registry->get('\Aura\extensions\hooks')->fire('messenger.folders.header', $this->template->header);
		$args = $this->registry->get('\Aura\extensions\hooks')->fire('messenger.folders.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('message_folders.tpl');
		$this->template->output($tpl,
			array(
				'errors' => $errors,
				'pm_menu' => $this->registry->get('\Aura\messenger\menu')->generate('folders'),
				'form_action' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['pms_folders']),
				'folder' => (isset($folder)) ? $folder : '',
				'folders' => $folders,
			)
		);
	}

	/*
	 * Configure and setup a few things before we start each action
	 */
	protected function configure_pms()
	{
		if ($this->user['g_read_board'] == '0')
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No view'), false, '403 Forbidden');

		if ($this->user['is_guest'])
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'));

		if ($this->config['o_private_messaging'] == '0' || $this->user['g_use_pm'] == '0' || $this->user['pm_enabled'] == '0')
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'));

		$this->lang->load('pms');

		// Load the post language file
		$this->lang->load('post');

		$this->registry->get('\Aura\extensions\hooks')->fire('messenger.folders.configure');
	}

	/*
	 * We want to add a new folder to the PM system
	 */
	protected function add_folder($errors)
	{
		$folder = isset($_POST['req_folder']) ? utf8_trim($_POST['req_folder']) : '';
			
		if ($this->config['o_censoring'] == '1')
			$censored_folder = utf8_trim($this->registry->get('\Aura\message\bbcode')->censor_words($folder));

		if ($folder == '')
			$errors[] = $this->lang->t('No folder name');
		else if (aura_strlen($folder) < 4)
			$errors[] = $this->lang->t('Folder too short');
		else if (aura_strlen($folder) > 30)
			$errors[] = $this->lang->t('Folder too long');
		else if ($this->config['o_censoring'] == '1' && $folder == '')
			$errors[] = $this->lang->t('No folder after censoring');
			
		$data = array(
			':uid' => $this->user['id'],
		);

		if ($this->user['g_pm_folder_limit'] != 0)
		{
			$ps = $this->db->select('folders', 'COUNT(id)', $data, 'user_id=:uid');
			$num_folders = $ps->fetchColumn();
				
			if ($num_folders >= $this->user['g_pm_folder_limit'])
				$errors[] = $this->lang->t('Folder limit', $this->user['g_pm_folder_limit']);
		}

		$errors = $this->registry->get('\Aura\extensions\hooks')->fire('messenger.folders.validatefolder', $errors);
		if (empty($errors))
		{
			$insert = array(
				'user_id' => $this->user['id'],
				'name' => $folder,
			);

			$insert = $this->registry->get('\Aura\extensions\hooks')->fire('messenger.folders.insert', $insert);
			$this->db->insert('folders', $insert);

			$this->registry->get('\Aura\extensions\hooks')->fire('messenger.folders.addredirect');
			$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['pms_folders']), $this->lang->t('Folder added'));
		}

		return $errors;
	}

	/*
	 * We want to edit a folder
	 */
	protected function edit_folder($errors)
	{
		$id = intval(key($_POST['update']));
		$folder = utf8_trim($_POST['folder'][$id]);
			
		if ($this->config['o_censoring'] == '1')
			$censored_folder = utf8_trim($this->registry->get('\Aura\message\bbcode')->censor_words($folder));

		if ($folder == '')
			$errors[] = $this->lang->t('No folder name');
		else if (aura_strlen($folder) < 4)
			$errors[] = $this->lang->t('Folder too short');
		else if (aura_strlen($folder) > 30)
			$errors[] = $this->lang->t('Folder too long');
		else if ($this->config['o_censoring'] == '1' && $folder == '')
			$errors[] = $this->lang->t('No folder after censoring');

		$errors = $this->registry->get('\Aura\extensions\hooks')->fire('messenger.folders.validatefolder', $errors);
		if (empty($errors))
		{
			$update = array(
				'name' => $folder,
			);
				
			$data = array(
				':id' => $id,
				':uid' => $this->user['id'],
			);

			$update = $this->registry->get('\Aura\extensions\hooks')->fire('messenger.folders.update', $update);
			$this->db->update('folders', $update, 'id=:id AND user_id=:uid', $data);

			$this->registry->get('\Aura\extensions\hooks')->fire('messenger.folders.editredirect');
			$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['pms_folders']), $this->lang->t('Folder edit redirect'));
		}

		return $errors;
	}

	/*
	 * We want to remove a folder
	 */
	protected function remove_folder()
	{
		$id = intval(key($_POST['remove']));
		$data = array(
			':id' => $id,
			':uid' => $this->user['id'],
		);

		// Before we do anything, check we own this box
		$ps = $this->db->select('folders', 1, $data, 'id=:id AND user_id=:uid');
		if (!$ps->rowCount())
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'));

		$this->registry->get('\Aura\extensions\hooks')->fire('messenger.folders.remove_folder');

		$update = array(
			'folder_id'	=> 2, // Send all potential conversations in this box back to the inbox upon deletion
		);

		$update_data = array(
			':id'	=>	$id,
		);

		$this->db->update('pms_data', $update, 'folder_id=:id', $update_data);
		$this->db->delete('folders', 'id=:id AND user_id=:uid', $data);

		$this->registry->get('\Aura\extensions\hooks')->fire('messenger.folders.removeredirect');
		$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['pms_folders']), $this->lang->t('Folder del redirect'));
	}
}