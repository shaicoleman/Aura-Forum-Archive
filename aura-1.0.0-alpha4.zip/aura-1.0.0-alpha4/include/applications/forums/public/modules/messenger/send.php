<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class send_controller extends base_controller
{
	/*
	 * Main app entry point, display the send form
	 */
	public function execute()
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('messenger.send.immediate');

		if ($this->user['g_read_board'] == '0')
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No view'), false, '403 Forbidden');

		if ($this->user['is_guest'])
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'));

		if ($this->config['o_private_messaging'] == '0' || $this->user['g_use_pm'] == '0' || $this->user['pm_enabled'] == '0')
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'));

		if ($this->user['g_post_replies'] == '0')
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'));

		$this->registry->get('\Aura\extensions\hooks')->fire('messenger.send.authorised');

		$this->lang->load('pms');

		// Load the post language file
		$this->lang->load('post');
		$this->registry->get('\Aura\auth\bans')->check_posting_ban();

		$tid = isset($_GET['tid']) ? intval($_GET['tid']) : '';
		$qid = isset($_GET['qid']) ? intval($_GET['qid']) : '';

		if ($this->user['g_robot_test'] == '1')
			$aura_robots = $this->cache->get('robots');

		if ($tid != '')
		{
			if ($tid < 1)
				$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'));
				
			$data = array(
				':tid' => $tid,
				':uid' => $this->user['id']
			);

			$join = array(
				array(
					'type' => 'INNER',
					'table' => 'pms_data',
					'as' => 'cd',
					'on' => 'c.id=cd.topic_id',
				),
			);

			$ps = $this->db->join('conversations', 'c', $join, 1, $data, 'cd.topic_id=:tid AND cd.user_id=:uid AND cd.deleted=0');
			if (!$ps->rowCount())
				$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request')); // We've deleted it
			
			if ($qid)
				$quote = $this->fetch_quote($qid, $tid);
		}

		$username = $this->fetch_username();

		$errors = array();
		if (isset($_POST['form_sent']))
			list($message, $parser, $hide_smilies, $subject, $username, $errors) = $this->post_message($tid);

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('PM'), $this->lang->t('Send message')),
			'required_fields' => array('req_message' => $this->lang->t('Message')),
			'focus_element' => array('post'),
			'active_page' => 'pm',
			'posting' => true,
		);

		if (!$tid)
		{
			$this->template->header['required_fields']['req_subject'] = $this->lang->t('Subject');
			$this->template->header['required_fields']['req_username'] = $this->lang->t('Username');
		}
		else
		{
			$data = array(
				':tid' => $tid,
				':uid' => $this->user['id'],
			);
			
			$ps = $this->db->select('pms_data', 'folder_id', $data, 'topic_id=:tid AND user_id=:uid AND deleted=0');
			if (!$ps->rowCount())	// Then we're not a part of this conversation (or have deleted it)
				$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'));
			else
				$folder_id = $ps->fetchColumn();

			if ($folder_id == 3)	// If we've archived this folder
				$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'));
		}

		if (!empty($aura_robots) && $this->user['g_robot_test'] == '1')
			$this->template->header['required_fields']['answer'] = $this->lang->t('Robot title');

		$this->template->header['focus_element'][] = ($tid) ? 'req_message' : 'req_subject';
		$this->template->header = $this->registry->get('\Aura\extensions\hooks')->fire('messenger.send.header', $this->template->header);

		$render = array(
			'tid' => $tid,
			'errors' => $errors,
			'preview' => (isset($_POST['preview'])) ? true : false,
			'index_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['index']),
			'inbox_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['inbox']),
			'pm_menu' => $this->registry->get('\Aura\messenger\menu')->generate('send'),
			'form_action' => (!$tid) ? $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['send_message']) : $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['pms_reply'], array($tid)),
			'subject' => (isset($subject)) ? $subject : '',
			'message' => isset($_POST['req_message']) ? $message : (isset($quote) ? $quote : ''),
			'aura_user' => $this->user,
			'username' => $username,
			'csrf_token' => $this->registry->get('\Aura\auth\csrf')->generate('pms_send'),
			'quickpost_links' => array(
				'bbcode' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['help'], array('bbcode')),
				'url' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['help'], array('url')),
				'img' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['help'], array('img')),
				'smilies' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['help'], array('smilies')),
			),
		);

		if (isset($_POST['preview']))
			$render['preview'] = $parser->parse_message($message, $hide_smilies);

		if (!empty($aura_robots) && $this->user['g_robot_test'] == '1')
		{
			$id = array_rand($aura_robots);
			$render['robot_id'] = $id;
			$render['test'] = $aura_robots[$id];
		}

		$render = $this->registry->get('\Aura\extensions\hooks')->fire('messenger.send.render', $render);

		$tpl = $this->template->load('send_message.tpl');
		$this->template->output($tpl, $render);
	}

	/**
	 * Submit the post into the database and handle the posting
	 */
	protected function post_message($tid)
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('messenger.send.post.immediate');

		$errors = array();
		$parser = $this->registry->get('\Aura\message\parser');

		$message = isset($_POST['req_message']) ? utf8_trim($_POST['req_message']) : '';
		$subject = isset($_POST['req_subject']) ? utf8_trim($_POST['req_subject']) : '';
		$username = isset($_POST['req_username']) ? utf8_trim($_POST['req_username']) : '';
		$hide_smilies = isset($_POST['hide_smilies']) ? '1' : '0';
			
		if (!empty($aura_robots) && $this->user['g_robot_test'] == '1')
		{
			$id = isset($_POST['id']) ? intval($_POST['id']) : 0;
			$answer = isset($_POST['answer']) ? utf8_trim($_POST['answer']) : '';

			if (!isset($aura_robots[$id]) || $answer != $aura_robots[$id]['answer'])
				$errors[] = $this->lang->t('Robot test fail');

			$this->registry->get('\Aura\extensions\hooks')->fire('messenger.send.post.robots');
		}

		if ($tid)
		{
			if ($message == '')
				$errors[] = $this->lang->t('No message');
			elseif (strlen($message) > AURA_MAX_POSTSIZE)
				$errors[] = $this->lang->t('Too long message', $this->functions->forum_number_format(AURA_MAX_POSTSIZE));
			else if ($this->config['p_message_all_caps'] == '0' && is_all_uppercase($message) && !$this->user['is_admmod'])
				$errors[] = $this->lang->t('All caps message');

			if ($this->config['p_message_bbcode'] == '1')
				$message = $parser->preparse_bbcode($message, $errors);

			if (empty($errors))
			{
				if ($message == '')
					$errors[] = $this->lang->t('No message');
				else if ($this->config['o_censoring'] == '1')
				{
					// Censor message to see if that causes problems
					$message = utf8_trim($this->registry->get('\Aura\message\bbcode')->censor_words($message));

					if ($message == '')
						$errors[] = $this->lang->t('No message after censoring');
				}
			}

			$join = array(
				array(
					'type' => 'INNER',
					'table' => 'users',
					'as' => 'u',
					'on' => 'cd.user_id=u.id',
				),
				array(
					'type' => 'INNER',
					'table' => 'groups',
					'as' => 'g',
					'on' => 'u.group_id=g.g_id',
				),
			);

			$data = array(
				':uid' => $this->user['id'],
				':tid' => $tid,
			);

			$ps = $this->db->join('pms_data', 'cd', $join, 'cd.user_id AS uid, u.username, u.email, u.pm_enabled, u.num_pms, u.pm_notify, g.g_use_pm, g.g_pm_limit, cd.deleted', $data, 'cd.user_id!=:uid AND cd.topic_id=:tid');
			if (!$ps->rowCount())
				$errors[] = $this->lang->t('No receivers');
			else
			{
				foreach ($ps as $cur_user)
				{
					if (!empty($errors))
						break;

					if ($cur_user['deleted'] == '1')
						$errors[] = $this->lang->t('User x has left', $cur_user['username']);
						
					// Check if they have the PM enabled
					if ($cur_user['pm_enabled'] == '0' || $cur_user['g_use_pm'] == '0')
						$errors[] = $this->lang->t('No PM access', $cur_user['username']);

					// Check if they've reached their max limit
					if ($cur_user['num_pms'] + 1 >= $cur_user['g_pm_limit'] && $cur_user['g_pm_limit'] != 0)
						$errors[] = $this->lang->t('Receiver inbox full', $cur_user['username']);

					if (!$this->user['is_admmod'])
					{
						$data = array(
							':uid'	=>	$this->user['id'],
							':bid'	=>	$cur_user['uid'],
							':bid2'	=>	$this->user['id'],
							':uid2'	=>	$cur_user['uid'],
						);

						$ps1 = $this->db->select('blocks', 1, $data, 'user_id=:uid AND block_id=:bid OR block_id=:bid2 AND user_id=:uid2');
						if ($ps1->rowCount())
							$errors[] = $this->lang->t('User x has blocked', $cur_user['username']);
					}
						
					$receivers[$cur_user['uid']] = $cur_user;

					$receivers = $this->registry->get('\Aura\extensions\hooks')->fire('messenger.send.post.receivers', $receivers);
				}
			}

			$data = array(
				':id'	=>	$tid,
			);

			$ps = $this->db->select('conversations', 'subject', $data, 'id=:id');
			if (!$ps->rowCount())
				$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'));
			else
				$subject = $ps->fetchColumn();

			if (empty($errors) && !isset($_POST['preview']))
				$this->send_message($subject, $message, $hide_smilies, $tid, $receivers);
		}
		else
			$errors = $this->send_topic($username, $subject, $message, $hide_smilies, $errors);

		return array($message, $parser, $hide_smilies, $subject, $username, $errors);
	}

	/**
	 * Submit a new topic into the database
	 */
	protected function send_topic($username, $subject, $message, $hide_smilies, $errors)
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('messenger.send.topic.immediate');
		$users = array_map('utf8_trim', explode(',', $username));

		if ((count($users) + 1) > $this->config['o_max_pm_receivers']) // Add one for us as we shouldn't be included
			$errors[] = $this->lang->t('Max receivers', $this->config['o_pm_max_receivers']);

		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'groups',
				'as' => 'g',
				'on' => 'u.group_id=g.g_id',
			),
		);

		$receivers = array();
		foreach ($users as $user)
		{
			$data = array(
				':username'	=> $user,
			);

			$ps = $this->db->join('users', 'u', $join, 'u.id, u.username, u.email, u.pm_enabled, u.num_pms, u.pm_notify, g.g_use_pm, g.g_pm_limit', $data, 'u.username=:username AND u.id>1');
			if (!$ps->rowCount())
			{
				$errors[] = $this->lang->t('No user x', $user);
				continue;
			}
			else
				$cur_user = $ps->fetch();

			$receivers[$cur_user['id']] = $cur_user;
			$receivers = $this->registry->get('\Aura\extensions\hooks')->fire('messenger.send.topic.receivers', $receivers);
		}

		if (!isset($_POST['preview']) && $this->user['last_post'] != '' && (CURRENT_TIMESTAMP - $this->user['last_post']) < $this->user['g_post_flood'])
			$errors[] = $this->lang->t('Flood start', $this->user['g_post_flood'], $this->user['g_post_flood'] - (CURRENT_TIMESTAMP - $this->user['last_post']));
				
		if (isset($receivers[$this->user['id']]))	// Stop us from sending messages completely to ourselves
			$errors[] = $this->lang->t('No self messages');
			
		if ($this->user['num_pms'] + 1 >= $this->user['g_pm_limit'] && $this->user['g_pm_limit'] != 0)
			$errors[] = $this->lang->t('Inbox full');

		if ($this->config['o_censoring'] == '1')
			$censored_subject = utf8_trim($this->registry->get('\Aura\message\bbcode')->censor_words($subject));

		if ($subject == '')
			$errors[] = $this->lang->t('No subject');
		else if ($this->config['o_censoring'] == '1' && $censored_subject == '')
			$errors[] = $this->lang->t('No subject after censoring');
		else if (aura_strlen($subject) > 70)
			$errors[] = $this->lang->t('Too long subject');
		else if ($this->config['p_subject_all_caps'] == '0' && is_all_uppercase($subject) && !$this->user['is_admmod'])
			$errors[] = $this->lang->t('All caps subject');
		else if ($this->user['g_subject_links'] == '0' && $this->functions->contains_url($subject))
			$errors[] = $this->lang->t('BBCode error tag url not allowed in subjects');

		if ($message == '')
			$errors[] = $this->lang->t('No message');
		elseif (strlen($message) > AURA_MAX_POSTSIZE)
			$errors[] = $this->lang->t('Too long message', $this->functions->forum_number_format(AURA_MAX_POSTSIZE));
		else if ($this->config['p_message_all_caps'] == '0' && is_all_uppercase($message) && !$this->user['is_admmod'])
			$errors[] = $this->lang->t('All caps message');

		if ($this->config['p_message_bbcode'] == '1')
		{
			$parser = $this->registry->get('\Aura\message\parser');
			$message = $parser->preparse_bbcode($message, $errors);
		}

		$errors = $this->registry->get('\Aura\extensions\hooks')->fire('messenger.send.topic.validatedetails', $errors);
		if (empty($errors))
		{
			if ($message == '')
				$errors[] = $this->lang->t('No message');
			else if ($this->config['o_censoring'] == '1')
			{
				// Censor message to see if that causes problems
				$censored_message = utf8_trim($this->registry->get('\Aura\message\bbcode')->censor_words($message));

				if ($censored_message == '')
					$errors[] = $this->lang->t('No message after censoring');
			}
		}

		foreach ($receivers as $uid => $udata)
		{
			if (!empty($errors))
				break;

			// Check if they have the PM enabled
			if ($udata['pm_enabled'] == '0' || $udata['g_use_pm'] == '0')
				$errors[] = $this->lang->t('No PM access', $udata['username']);

			// Check if they've reached their max limit
			if ($udata['num_pms'] + 1 >= $udata['g_pm_limit'] && $udata['g_pm_limit'] != 0)
				$errors[] = $this->lang->t('Receiver inbox full', $udata['username']);

			if (!$this->user['is_admmod'])
			{
				$data = array(
					':uid'	=>	$this->user['id'],
					':bid'	=>	$uid,
					':bid2'	=>	$this->user['id'],
					':uid2'	=>	$uid,
				);

				$ps = $this->db->select('blocks', 1, $data, 'user_id=:uid AND block_id=:bid OR block_id=:bid2 AND user_id=:uid2');
				if ($ps->rowCount())
					$errors[] = $this->lang->t('User x has blocked', $udata['username']);
			}
		}

		$errors = $this->registry->get('\Aura\extensions\hooks')->fire('messenger.send.topic.validatereceivers', $errors);
		if (empty($errors) && !isset($_POST['preview']))
		{
			$insert = array(
				'subject'	=>	$subject,
				'poster'	=>	$this->user['username'],
				'poster_id'	=>	$this->user['id'],
				'num_replies'	=>	0,
				'last_post'	=>	CURRENT_TIMESTAMP,
				'last_poster'	=>	$this->user['username'],
			);

			$this->db->insert('conversations', $insert);
			$new_tid = $this->db->lastInsertId($this->db->prefix.'conversations');

			$insert = array(
				'poster'	=>	$this->user['username'],
				'poster_id'	=>	$this->user['id'],
				'poster_ip'	=>	get_remote_address(),
				'message'	=>	$message,
				'hide_smilies'	=>	$hide_smilies,
				'posted'	=>	CURRENT_TIMESTAMP,
				'topic_id'	=>	$new_tid,
			);

			$this->db->insert('messages', $insert);
			$new_pid = $this->db->lastInsertId($this->db->prefix.'messages');
					
			$update = array(
				'first_post_id'	=>	$new_pid,
				'last_post_id'	=>	$new_pid,
			);

			$data = array(
				':tid'	=>	$new_tid,
			);
					
			$this->db->update('conversations', $update, 'id=:tid', $data);

			// Now add us to the receivers array to create our row in the pms_data table
			$receivers[$this->user['id']] = $this->user;
			$email = $this->registry->get('\Aura\email\email');

			$subscriptions = $this->registry->get('\Aura\subscriptions');
			$message = $subscriptions->bbcode2email((($this->config['o_censoring'] == '1') ? $censored_message : $message), -1);

			// Yes, unfortunately we need a second loop here =(
			foreach ($receivers as $uid => $udata)
			{
				$insert = array(
					'topic_id'	=>	$new_tid,
					'user_id'	=>	$uid,
					'viewed'	=>	(($uid == $this->user['id']) ? 1 : 0),	// If we're the current receiver, then we've seen the message
				);

				$this->db->insert('pms_data', $insert);

				$data = array(
					':id'	=>	$uid,
				);

				$this->db->run('UPDATE '.$this->db->prefix.'users SET num_pms=num_pms+1 WHERE id=:id', $data);
						
				if ($udata['pm_notify'] == '1' && $uid != $this->user['id'])
				{
					$info = array(
						'message' => array(
							'<username>' => $udata['username'],
							'<sender>' => $this->user['username'],
							'<message>' => $message,
							'<pm_title>' => $subject,
							'<message_url>' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['pms_post'], array($new_pid)),
						)
					);

					$mail_tpl = $this->registry->get('\Aura\email\parser')->parse_email('new_pm', $this->user['language'], $info);
					$email->send($udata['email'], $mail_tpl['subject'], $mail_tpl['message']);
				}
			}

			$this->registry->get('\Aura\extensions\hooks')->fire('messenger.send.redirect');
			$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['pms_view'], array($new_tid)), $this->lang->t('PM sent redirect'));
		}

		return $errors;
	}

	/**
	 * Send an ordinary message
	 */
	protected function send_message($subject, $message, $hide_smilies, $tid, $receivers)
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('messenger.send.posts.immediate');
		$insert = array(
			'poster'	=>	$this->user['username'],
			'poster_id'	=>	$this->user['id'],
			'poster_ip'	=>	get_remote_address(),
			'message'	=>	$message,
			'hide_smilies'	=>	$hide_smilies,
			'posted'	=>	CURRENT_TIMESTAMP,
			'topic_id'	=>	$tid,
		);
					
		$this->db->insert('messages', $insert);
					
		$new_pid = $this->db->lastInsertId($this->db->prefix.'messages');
		$data = array(
			':tid'	=>	$tid,
			':last_post'	=>	CURRENT_TIMESTAMP,
			':last_poster'	=>	$this->user['username'],
			':last_post_id'	=>	$new_pid,
		);

		$this->db->run('UPDATE '.$this->db->prefix.'conversations SET last_post=:last_post, last_poster=:last_poster, num_replies=num_replies+1, last_post_id=:last_post_id WHERE id=:tid', $data);

		$update = array(
			'viewed' => 0,
		);
					
		$data = array(
			':tid'	=>	$tid,
			':uid'	=>	$this->user['id'],
		);
					
		$this->db->update('pms_data', $update, 'topic_id=:tid AND user_id!=:uid', $data);	// Reset the topics as unread for all users but us

		$email = $this->registry->get('\Aura\email\email');
		$subscriptions = $this->registry->get('\Aura\subscriptions');

		$message = $subscriptions->bbcode2email($message, -1);
		foreach ($receivers as $uid => $udata)
		{
			if ($udata['pm_notify'] == '1' && $uid != $this->user['id'])
			{
				$info = array(
					'message' => array(
						'<username>' => $udata['username'],
						'<replier>' => $this->user['username'],
						'<message>' => $message,
						'<pm_title>' => $subject,
						'<message_url>' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['pms_post'], array($new_pid))
					)
				);

				$mail_tpl = $this->registry->get('\Aura\email\parser')->parse_email('pm_reply', $this->user['language'], $info);
				$email->send($udata['email'], $mail_tpl['subject'], $mail_tpl['message']);

				$this->registry->get('\Aura\extensions\hooks')->fire('messenger.send.posts.notifications');
			}
						
			$data = array(
				':id'	=>	$uid,
			);
						
			$this->db->run('UPDATE '.$this->db->prefix.'users SET num_pms=num_pms+1 WHERE id=:id', $data);
		}
					
		$data = array(
			':id' => $this->user['id'],
		);
					
		$this->db->run('UPDATE '.$this->db->prefix.'users SET num_pms=num_pms+1 WHERE id=:id', $data);

		$this->registry->get('\Aura\extensions\hooks')->fire('messenger.send.posts.redirect');
		$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['pms_post'], array($new_pid)), $this->lang->t('PM sent redirect'));		
	}

	/**
	 * If we're submitting to a specific user, then autofill their details
	 */
	protected function fetch_username()
	{
		$username = '';
		if (isset($_GET['uid']))
		{
			$uid = isset($_GET['uid']) ? intval($_GET['uid']) : 0;
			$data = array(
				':id' => $uid,
			);

			$ps = $this->db->select('users', 'username', $data, 'id=:id AND id!=1');
			if (!$ps->rowCount())
				$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'));
			else
				$username = $ps->fetchColumn();
		}

		return $username;
	}

	/**
	 * Fetch the quote from the quote ID of a message
	 */
	protected function fetch_quote($qid, $tid)
	{
		if ($qid < 1)
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		$data = array(
			':id'	=>	$qid,
			':tid'	=>	$tid,
		);

		$ps = $this->db->select('messages', 'poster, message', $data, 'id=:id AND topic_id=:tid');
		if (!$ps->rowCount())
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		list($q_poster, $q_message) = $ps->fetch(PDO::FETCH_NUM);

		// If the message contains a code tag we have to split it up (text within [code][/code] shouldn't be touched)
		if (strpos($q_message, '[code]') !== false && strpos($q_message, '[/code]') !== false)
		{
			list($inside, $outside) = $this->registry->get('\Aura\message\bbcode')->split_text($q_message, '[code]', '[/code]');

			$q_message = implode("\1", $outside);
		}

		// Remove [img] tags from quoted message
		$q_message = preg_replace('%\[img(?:=(?:[^\[]*?))?\]((ht|f)tps?://)([^\s<"]*?)\[/img\]%U', '\1\3', $q_message);

		// If we split up the message before we have to concatenate it together again (code tags)
		if (isset($inside))
		{
			$outside = explode("\1", $q_message);
			$q_message = '';

			$num_tokens = count($outside);
			for ($i = 0; $i < $num_tokens; ++$i)
			{
				$q_message .= $outside[$i];
				if (isset($inside[$i]))
					$q_message .= '[code]'.$inside[$i].'[/code]';
			}

			unset($inside);
		}

		if ($this->config['o_censoring'] == '1')
			$q_message = $this->registry->get('\Aura\message\bbcode')->censor_words($q_message);

		if ($this->config['p_message_bbcode'] == '1')
		{
			// If username contains a square bracket, we add "" or '' around it (so we know when it starts and ends)
			if (strpos($q_poster, '[') !== false || strpos($q_poster, ']') !== false)
			{
				if (strpos($q_poster, '\'') !== false)
					$q_poster = '"'.$q_poster.'"';
				else
					$q_poster = '\''.$q_poster.'\'';
			}
			else
			{
				// Get the characters at the start and end of $q_poster
				$ends = substr($q_poster, 0, 1).substr($q_poster, -1, 1);

				// Deal with quoting "Username" or 'Username' (becomes '"Username"' or "'Username'")
				if ($ends == '\'\'')
					$q_poster = '"'.$q_poster.'"';
				else if ($ends == '""')
					$q_poster = '\''.$q_poster.'\'';
			}

			$quote = '[quote='.$q_poster.']'.$q_message.'[/quote]'."\n";
		}
		else
			$quote = '> '.$q_poster.' '.$this->lang->t('wrote')."\n\n".'> '.$q_message."\n";

		return $quote;
	}
}