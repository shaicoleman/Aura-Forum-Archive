<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class login_controller extends base_controller
{
	/*
	 * Main App Entry Point
	 */
	public function execute($password_expired = false, $errors = array())
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('login.immediate');

		$this->configure_login();

		// Try to determine if the data in HTTP_REFERER is valid (if not, we redirect to index.php after login)
		if (!empty($_SERVER['HTTP_REFERER']))
			$redirect_url = $this->registry->get('\Aura\auth\login')->validate_redirect($_SERVER['HTTP_REFERER'], null);

		if (!isset($redirect_url))
			$redirect_url = $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['index']);
		else if (preg_match('%index\.php\?app=forums&act=viewtopic&pid=(\d+)$%', $redirect_url, $matches))
			$redirect_url .= '#p'.$matches[1];

		$redirect_url = $this->registry->get('\Aura\extensions\hooks')->fire('login.redirecturl', $redirect_url);

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Login')),
			'required_fields' => array('req_username' => $this->lang->t('Username'), 'req_password' => $this->lang->t('Password')),
			'focus_element' => array('login', 'req_username'),
			'active_page' => 'login',
		);

		$this->template->header = $this->registry->get('\Aura\extensions\hooks')->fire('login.header', $this->template->header);
		$args = $this->registry->get('\Aura\extensions\hooks')->fire('login.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('login.tpl');
		$this->template->output($tpl,
			array_merge(
				array(
					'lang' => $this->lang,
					'password_expired' => $password_expired,
					'aura_config' => $this->config,
					'POST' => $_POST,
					'form_action' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['login_in']),
					'redirect_url' => $redirect_url,
					'register' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['register']),
					'request_password' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['request_password']),
					'errors' => $errors,
				),
				$args
			)
		);
	}

	/*
	 * Attempt the login process
	 */
	 public function in()
	 {
		$this->registry->get('\Aura\extensions\hooks')->fire('login.login.immediate');

		 $this->configure_login();

		$errors = array();
		$password_expired = false;
		if (isset($_POST['form_sent']))
		{
			$this->registry->get('\Aura\extensions\hooks')->fire('login.login.beforevalidation');

			$form_username = isset($_POST['req_username']) ? utf8_trim($_POST['req_username']) : '';
			$form_password = isset($_POST['req_password']) ? utf8_trim($_POST['req_password']) : '';
			$save_pass = isset($_POST['save_pass']);

			if ($this->config['o_login_queue'] == '1')
			{
				$data = array(
					':username' => $form_username,
					':timeout' => (TIMEOUT * 1000),
				);

				$ps = $this->db->select('login_queue', 'COUNT(*) AS overall, COUNT(IF(username = :username, TRUE, NULL)) AS user', $data, 'last_checked > NOW() - INTERVAL :timeout MICROSECOND');
				$count = $ps->fetch();

				if (!$count)
					$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Unable to query size'));
				else if ($count['overall'] >= $this->config['o_queue_size'] || $count['user'] >= $this->config['o_max_attempts'])
					$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Login queue exceeded'));	

				$insert = array(
					'ip_address' => get_remote_address(),
					'username' => $form_username,
				);

				$this->db->insert('login_queue', $insert) or $this->registry->get('\Aura\handlers\message')->show($this->lang->t('IP address in queue'));
				$attempt = $this->db->lastInsertId($this->db->prefix.'login_queue');

				// This time, while() is actually in our favour. Yes, I know!
				while (!$this->registry->get('\Aura\auth\login')->check_queue($form_username, $attempt, $this->db))
					usleep(250 * 1000);

				//Force delay between logins, remove dead attempts
				usleep(ATTEMPT_DELAY * 1000);

				$data = array(
					':id' => $attempt,
					':timeout' => (TIMEOUT * 1000),
				);

				$this->db->delete('login_queue', 'id=:id OR last_checked < NOW() - INTERVAL :timeout MICROSECOND', $data);

				$this->registry->get('\Aura\extensions\hooks')->fire('login.login.queue');
			}

			$data = array(
				':username' => $form_username,
			);

			$ps = $this->db->select('users', 'password, salt, group_id, id, login_key, password_changed', $data, 'username=:username');
			$cur_user = $ps->fetch();

			if (!aura_hash_equals($cur_user['password'], aura_hash($form_password.$cur_user['salt'])))
				$errors[] = $this->lang->t('Wrong user/pass', ' <a href="'.$this->registry->get('\Aura\links')->aura_link($this->rewrite->url['request_password']).'">'.$this->lang->t('Forgotten pass').'</a>');
			else if ($this->config['o_password_expires'])
			{
				$expired = $cur_user['password_changed'] + ($this->config['o_password_expires'] * 86400);
				if (CURRENT_TIMESTAMP > $expired)
				{
					$password_expired = true;
					$this->lang->load('prof_reg');
					$password1 = isset($_POST['password1']) ? utf8_trim($_POST['password1']) : '';
					$password2 = isset($_POST['password2']) ? utf8_trim($_POST['password2']) : '';

					if ($password1)
					{
						$errors = validate_password($password1, $password2);
						if (empty($errors))
						{
							$salt = $this->registry->get('\Aura\auth\password')->generate(16);
							$cur_user['login_key'] = $this->registry->get('\Aura\auth\password')->generate(60);

							$data = array(
								':id' => $cur_user['id'],
							);

							$update = array(
								'password' => aura_hash($password1.$salt),
								'salt' => $salt,
								'login_key' => $cur_user['login_key'],
								'password_changed' => CURRENT_TIMESTAMP,
							);

							$this->db->update('users', $update, 'id=:id', $data);
						}
					}
					else
						$errors[] = $this->lang->t('Password expired');
				}
			}

			$password_expired = $this->registry->get('\Aura\extensions\hooks')->fire('login.login.passwordexpired', $password_expired);
			$errors = $this->registry->get('\Aura\extensions\hooks')->fire('login.login.aftervalidation', $errors);

			if (empty($errors))
			{
				// Update the status if this is the first time the user logged in
				if ($cur_user['group_id'] == AURA_UNVERIFIED)
				{
					$update = array(
						'group_id' => $this->config['o_default_user_group'],
					);

					$data = array(
						':id' => $cur_user['id'],
					);

					$this->db->update('users', $update, 'id=:id', $data);
					$this->cache->generate('stats');

					$this->registry->get('\Aura\extensions\hooks')->fire('login.login.unverified');
				}

				// Remove this user's guest entry from the online list
				$data = array(
					':ident' => get_remote_address(),
				);

				$this->db->delete('online', 'ident=:ident', $data);

				$expire = ($save_pass == '1') ? CURRENT_TIMESTAMP + 1209600 : CURRENT_TIMESTAMP + $this->config['o_timeout_visit'];
				$this->registry->get('\Aura\cookie\cookie')->aura_setcookie($cur_user['id'], $cur_user['login_key'], $expire);

				// Reset tracked topics
				$this->registry->get('\Aura\cookie\tracked')->set_tracked_topics(null);

				$this->registry->get('\Aura\extensions\hooks')->fire('login.login.beforeredirect');

				// Try to determine if the data in redirect_url is valid (if not, we redirect to index.php after login)
				$redirect_url = $this->registry->get('\Aura\auth\login')->validate_redirect($_POST['redirect_url'], $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['index']));
				$this->registry->get('\Aura\handlers\redirect')->show($redirect_url, $this->lang->t('Login redirect'));
			}
		}

		$this->execute($password_expired, $errors);
	}

	/*
	 * Attempt to log the user out
	 */
	public function out()
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('login.logout.immediate');

		// Load the login language file
		$this->lang->load('login');

		if ($this->user['is_guest'] || !isset($_GET['id']) || $_GET['id'] != $this->user['id'])
		{
			header('Location: '.$this->registry->get('\Aura\links')->aura_link($this->rewrite->url['index']));
			exit;
		}

		$this->registry->get('\Aura\auth\csrf')->confirm('login');
		$this->registry->get('\Aura\extensions\hooks')->fire('login.logout.authorised');

		$data = array(
			':id' => $this->user['id'],
		);

		// Remove user from "users online" list
		$this->db->delete('online', 'user_id=:id', $data);
		$this->registry->get('\Aura\auth\login')->generate_login_key();

		// Update last_visit (make sure there's something to update it with)
		if (isset($this->user['logged']))
		{
			$update = array(
				'last_visit' => $this->user['logged'],
			);

			$data = array(
				':id' => $this->user['id'],
			);
				
			$this->db->update('users', $update, 'id=:id', $data);
		}

		$this->registry->get('\Aura\cookie\cookie')->aura_setcookie(1, aura_hash(uniqid(rand(), true)), CURRENT_TIMESTAMP + 31536000);
		$this->registry->get('\Aura\extensions\hooks')->fire('login.logout.afterlogout');

		$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['index']), $this->lang->t('Logout redirect'));
	}

	/*
	 * Reset the user password
	 */
	public function forget()
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('login.forget.immediate');

		$this->configure_login();

		// Start with a clean slate
		$errors = array();
		if (isset($_POST['form_sent']))
		{
			$this->registry->get('\Aura\auth\csrf')->confirm('login');

			// Validate the email address
			$email = isset($_POST['req_email']) ? strtolower(utf8_trim($_POST['req_email'])) : '';
			if (!is_valid_email($email))
				$errors[] = $this->lang->t('Invalid email');

			$errors = $this->registry->get('\Aura\extensions\hooks')->fire('login.forget.aftervalidation', $errors);

			// Did everything go according to plan?
			if (empty($errors))
			{
				$data = array(
					':email' => $email,
				);

				$mail = $this->registry->get('\Aura\email\email');
				$ps = $this->db->select('users', 'id, username, last_email_sent', $data, 'email=:email');
				if ($ps->rowCount())
				{
					// Loop through users we found
					foreach ($ps as $cur_hit)
					{
						if ($cur_hit['last_email_sent'] != '' && (CURRENT_TIMESTAMP - $cur_hit['last_email_sent']) < 3600 && (CURRENT_TIMESTAMP - $cur_hit['last_email_sent']) >= 0)
							$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Email flood', intval((3600 - (CURRENT_TIMESTAMP - $cur_hit['last_email_sent'])) / 60)), true);

						// Generate a new password and a new password activation code
						$new_password = $this->registry->get('\Aura\auth\password')->generate(12);
						$new_salt = $this->registry->get('\Aura\auth\password')->generate(16);
						$new_password_key = $this->registry->get('\Aura\auth\password')->generate(8);
							
						$update = array(
							'activate_string' => aura_hash($new_password.$new_salt),
							'salt' => $new_salt,
							'activate_key' => $new_password_key,
							'last_email_sent' => CURRENT_TIMESTAMP,
						);
							
						$data = array(
							':id' => $cur_hit['id'],
						);

						$this->db->update('users', $update, 'id=:id', $data);

						$info = array(
							'message' => array(
								'<base_url>' => $this->functions->get_base_url(),
								'<username>' => $cur_hit['username'],
								'<activation_url>' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['change_password_key'], array($cur_hit['id'], $new_password_key)),
								'<new_password>' => $new_password,
							)
						);

						$mail_tpl = $this->registry->get('\Aura\email\parser')->parse_email('activate_password', $this->user['language'], $info);
						$mail->send($email, $mail_tpl['subject'], $mail_tpl['message']);

						$this->registry->get('\Aura\extensions\hooks')->fire('login.forget.notifications');
					}

					$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Forget mail', $this->config['o_admin_email']), true);
				}
				else
					$errors[] = $this->lang->t('No email match', $email);
			}
		}

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Request pass')),
			'required_fields' => array('req_email' => $this->lang->t('Email')),
			'focus_element' => array('request_pass', 'req_email'),
			'active_page' => 'login',
		);

		$this->template->header = $this->registry->get('\Aura\extensions\hooks')->fire('login.forget.header', $this->template->header);
		$args = $this->registry->get('\Aura\extensions\hooks')->fire('login.forget.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('forgot_password.tpl');
		$this->template->output($tpl,
			array_merge(
				array(
					'form_url' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['request_password']),
					'csrf_token' => $this->registry->get('\Aura\auth\csrf')->generate('login'),
					'errors' => $errors
				),
				$args
			)
		);
	}

	/*
	 * Configure some various parts of the login system
	 */
	protected function configure_login()
	{
		if ($this->user['is_bot']) // I can't think of one valid reason why bots should be able to attempt to login
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'));

		// Load the login language file
		$this->lang->load('login');

		if (!$this->user['is_guest'])
		{
			header('Location: '.$this->registry->get('\Aura\links')->aura_link($this->rewrite->url['index']));
			exit;
		}

		$this->registry->get('\Aura\extensions\hooks')->fire('login.configure');
	}
}