<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class register_controller extends base_controller
{
	/*
	 * Have we already configured the variables?
	 */
	protected $configured = false;

	/*
	 * Main Entry Point - do the registration!
	 */
	public function execute($errors = array())
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('register.immediate');

		$this->configure_page();

		if ($this->config['o_rules'] == '1' && !isset($_GET['agree']) && !isset($_GET['cancel']) && !isset($_POST['form_sent']))
		{
			header('Location: '.$this->registry->get('\Aura\links')->aura_link($this->rewrite->url['register_rules']));
			exit;
		}
		else if (isset($_GET['agree']))
			$this->registry->get('\Aura\auth\csrf')->confirm('register');
		else if (isset($_GET['cancel']))
		{
			// We've cancelled the registration to the forum
			$this->registry->get('\Aura\auth\csrf')->confirm('register');

			$this->registry->get('\Aura\extensions\hooks')->fire('register.cancel');
			$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['index']), $this->lang->t('Reg cancel redirect'));
		}

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Register')),
			'required_fields' => array('req_user' => $this->lang->t('Username'), 'req_password1' => $this->lang->t('Password'), 'req_password2' => $this->lang->t('Confirm pass'), 'req_email1' => $this->lang->t('Email'), 'req_email2' => $this->lang->t('Email').' 2'),
			'focus_element' => array('register', 'req_user'),
			'active_page' => 'register',
		);

		if (!empty($this->robots))
			$this->template->header['required_fields']['answer'] = $this->lang->t('Robot title');

		$this->template->header = $this->registry->get('\Aura\extensions\hooks')->fire('register.header', $this->template->header);
		$timezone = isset($timezone) ? $timezone : $this->config['o_default_timezone'];
		$dst = isset($dst) ? $dst : $this->config['o_default_dst'];
		$email_setting = isset($email_setting) ? $email_setting : $this->config['o_default_email_setting'];

		$render = array(
			'errors' => $errors,
			'form_action' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['register_register']),
			'csrf_token' => $this->registry->get('\Aura\auth\csrf')->generate('register'),
			'POST' => $_POST,
			'dst' => $dst,
			'timezone' => $timezone,
			'email_setting' => $email_setting,
			'languages' => $this->cache->get('locales'),
		);

		if (!empty($this->robots))
		{
			$id = array_rand($this->robots);
			$test = $this->robots[$id];
			
			$render['robot_id'] = $id;
			$render['robot_test'] = $test;
		}

		$render = $this->registry->get('\Aura\extensions\hooks')->fire('register.render', $render);

		$tpl = $this->template->load('register.tpl');
		$this->template->output($tpl, $render);
	}

	/*
	 * The user pressed the cancel button
	 */
	public function agree()
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('register.agree.immediate');

		$this->configure_page();

		// If we don't want to show the rules, we'd best abort
		if ($this->config['o_rules'] == '0')
		{
			header('Location: '.$this->registry->get('\Aura\links')->aura_link($this->rewrite->url['register']));
			exit;
		}

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Register'), $this->lang->t('Forum rules')),
			'active_page' => 'register',
		);

		$this->template->header = $this->registry->get('\Aura\extensions\hooks')->fire('register.agree.header', $this->template->header);
		$args = $this->registry->get('\Aura\extensions\hooks')->fire('register.agree.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('register_rules.tpl');
		$this->template->output($tpl,
			array_merge(
				array(
					'csrf_token' => $this->registry->get('\Aura\auth\csrf')->generate('register'),
					'form_action' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['register']),
				),
				$args
			)
		);
	}

	/*
	 * Try to register the user
	 */
	public function signup()
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('register.signup.immediate');

		$this->configure_page();

		// Start with a clean slate
		$errors = array();
		if (isset($_POST['form_sent']))
		{
			$this->registry->get('\Aura\auth\csrf')->confirm('register');

			// Check that someone from this IP didn't register a user within the last two hours (DoS prevention)
			$data = array(
				':remote_address' => get_remote_address(),
				':registered' => (CURRENT_TIMESTAMP - 7200),
			);

			$ps = $this->db->select('users', 1, $data, 'registration_ip=:remote_address AND registered>:registered');
			if ($ps->rowCount())
				$errors[] = $this->lang->t('Registration flood');

			if (!empty($this->robots))
			{
				$id = isset($_POST['id']) ? intval($_POST['id']) : 0;
				$answer = isset($_POST['answer']) ? utf8_trim($_POST['answer']) : '';

				if (!isset($this->robots[$id]) || $answer != $this->robots[$id]['answer'])
					$errors[] = $this->lang->t('Robot test fail');

				$errors = $this->registry->get('\Aura\extensions\hooks')->fire('register.register.robots', $errors);
			}

			$username = isset($_POST['req_user']) ? utf8_trim($_POST['req_user']) : '';
			$email1 = isset($_POST['req_email1']) ? strtolower(utf8_trim($_POST['req_email1'])) : '';
			$password_salt = $this->registry->get('\Aura\auth\password')->generate(16);

			if ($this->config['o_regs_verify'] == '1')
			{
				$email2 = isset($_POST['req_email2']) ? strtolower(utf8_trim($_POST['req_email2'])) : '';

				$password1 = $this->registry->get('\Aura\auth\password')->generate($this->config['o_password_length']);
				$password2 = $password1;
			}
			else
			{
				$password1 = isset($_POST['req_password1']) ? utf8_trim($_POST['req_password1']) : '';
				$password2 = isset($_POST['req_password2']) ? utf8_trim($_POST['req_password2']) : '';
			}

			// Validate username and passwords
			$errors = $this->registry->get('\Aura\auth\register')->check_username($username, $errors);

			$errors = array_merge($errors, $this->registry->get('\Aura\auth\register')->validate_password($password1, $password2));

			// Validate email
			$email = $this->registry->get('\Aura\email\email');

			if (!is_valid_email($email1))
				$errors[] = $this->lang->t('Invalid email');
			else if ($this->config['o_regs_verify'] == '1' && $email1 != $email2)
				$errors[] = $this->lang->t('Email not match');

			$errors = $this->registry->get('\Aura\extensions\hooks')->fire('register.register.aftervalidation', $errors);
			// Check if it's a banned email address
			if ($this->registry->get('\Aura\auth\bans')->is_banned_email($email1))
			{
				if ($this->config['p_allow_banned_email'] == '0')
					$errors[] = $this->lang->t('Banned email');

				$banned_email = true; // Used later when we send an alert email
			}
			else
				$banned_email = false;

			// Check if someone else already has registered with that email address
			$dupe_list = array();
			$data = array(
				':email' => $email1,
			);

			$ps = $this->db->select('users', 'username', $data, 'email=:email');
			if ($ps->rowCount())
			{
				if ($this->config['p_allow_dupe_email'] == '0')
					$errors[] = $this->lang->t('Dupe email');

				$ps->setFetchMode(PDO::FETCH_COLUMN, 0);
				foreach ($ps as $cur_dupe)
					$dupe_list[] = $cur_dupe;
			}

			// Make sure we have a valid language string
			if (isset($_POST['language']))
			{
				$this->language = preg_replace('%[\.\\\/]%', '', $_POST['language']);
				if (!lang::language_exists($this->language))
					$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');
			}
			else
				$this->language = $this->config['o_default_lang'];

			$timezone = isset($_POST['timezone']) ? round($_POST['timezone'], 1) : '';
			$dst = isset($_POST['dst']) ? 1 : 0;

			$email_setting = isset($_POST['email_setting']) && ($_POST['email_setting'] > 0 && $_POST['email_setting'] < 2) ? intval($_POST['email_setting']) : $this->config['o_default_email_setting'];

			$url_username = \Aura\url\url::replace($username);

			// Did everything go according to plan?
			if (empty($errors))
			{
				// Insert the new user into the database. We do this now to get the last inserted ID for later use

				$initial_group_id = ($this->config['o_regs_verify'] == '0') ? $this->config['o_default_user_group'] : AURA_UNVERIFIED;
				$password_hash = aura_hash($password1.$password_salt);

				// Add the user
				$insert = array(
					'username'	=>	$username,
					'group_id'	=>	$initial_group_id,
					'password'	=>	$password_hash,
					'salt'		=>	$password_salt,
					'email'		=>	$email1,
					'email_setting'	=> $email_setting,
					'timezone'	=>	$timezone,
					'dst'		=>	$dst,
					'language'	=>	$this->language,
					'style'		=>	$this->config['o_default_style'],
					'registered' =>	CURRENT_TIMESTAMP,
					'registration_ip' => get_remote_address(),
					'last_visit' => CURRENT_TIMESTAMP,
					'password_changed' => CURRENT_TIMESTAMP,
				);

				$insert = $this->registry->get('\Aura\extensions\hooks')->fire('register.register.insert', $insert);
				$this->db->insert('users', $insert);

				$new_uid = $this->db->lastInsertId($this->db->prefix.'users');
				$login_key = $this->registry->get('\Aura\auth\login')->generate_login_key($new_uid);

				if ($this->config['o_regs_verify'] == '0')
					$this->cache->generate('stats');

				// If the mailing list isn't empty, we may need to send out some alerts
				if ($this->config['o_mailing_list'] != '')
				{
					// If we previously found out that the email was banned
					if ($banned_email)
					{
						$info = array(
							'message' => array(
								'<username>' => $username,
								'<email>' => $email1,
								'<profile_url>' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['profile'], array($new_uid, $url_username)),
							)
						);

						$mail_tpl = $this->registry->get('\Aura\email\parser')->parse_email('banned_email_register', $this->user['language'], $info);
						$email->send($this->config['o_mailing_list'], $mail_tpl['subject'], $mail_tpl['message']);
					}

					// If we previously found out that the email was a dupe
					if (!empty($dupe_list))
					{
						$info = array(
							'message' => array(
								'<username>' => $username,
								'<dupe_list>' => implode(', ', $dupe_list),
								'<profile_url>' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['profile'], array($new_uid, $url_username)),
							),
						);

						$mail_tpl = $this->registry->get('\Aura\email\parser')->parse_email('dupe_email_register', $this->user['language'], $info);
						$email->send($this->config['o_mailing_list'], $mail_tpl['subject'], $mail_tpl['message']);
					}

					// Should we alert people on the admin mailing list that a new user has registered?
					if ($this->config['o_regs_report'] == '1')
					{
						$info = array(
							'message' => array(
								'<username>' => $username,
								'<base_url>' => $this->functions->get_base_url(),
								'<profile_url>' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['profile'], array($new_uid, $url_username)),
								'<admin_url>' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['profile_admin'], array($new_uid)),
							),
						);

						$mail_tpl = $this->registry->get('\Aura\email\parser')->parse_email('new_user', $this->user['language'], $info);
						$email->send($this->config['o_mailing_list'], $mail_tpl['subject'], $mail_tpl['message']);
					}

					$this->registry->get('\Aura\extensions\hooks')->fire('register.register.bannotifications');
				}

				// Must the user verify the registration or do we log him/her in right now?
				if ($this->config['o_regs_verify'] == '1')
				{
					$info = array(
						'subject' => array(
							'<board_title>' => $this->config['o_board_title'],
						),
						'message' => array(
							'<base_url>' => $this->functions->get_base_url(),
							'<username>' => $username,
							'<password>' => $password1,
							'<login_url>' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['login']),
						)
					);

					$mail_tpl = $this->registry->get('\Aura\email\parser')->parse_email('welcome', $this->user['language'], $info);
					$email->send($email1, $mail_tpl['subject'], $mail_tpl['message']);

					$this->registry->get('\Aura\extensions\hooks')->fire('register.register.userapproved');

					$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Reg email', $this->config['o_admin_email']), true);
				}

				$this->functions->aura_setcookie($new_uid, $login_key, CURRENT_TIMESTAMP + $this->config['o_timeout_visit']);

				$this->registry->get('\Aura\extensions\hooks')->fire('register.register.registered');
				$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['index']), $this->lang->t('Reg complete'));
			}
		}

		$this->execute($errors);
	}

	/*
	 * Try to configure and check a few things before we start the script
	 */
	protected function configure_page()
	{
		if (!$this->configured)
		{
			if ($this->user['is_bot'])
				$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'));

			// If we are logged in, we shouldn't be here
			if (!$this->user['is_guest'])
			{
				header('Location: '.$this->registry->get('\Aura\links')->aura_link($this->rewrite->url['index']));
				exit;
			}

			// Load the register language file
			$this->lang->load('register');

			// Load the register/profile language file
			$this->lang->load('prof_reg');

			$this->robots = $this->cache->get('robots');

			if ($this->config['o_regs_allow'] == '0')
				$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No new regs'));

			$this->registry->get('\Aura\extensions\hooks')->fire('register.configure');
			$this->configured = true;
		}
	}
}