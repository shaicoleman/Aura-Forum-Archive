<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class personal_controller extends base_controller
{
	public function execute()
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('profile.personal.immediate');

		$profile = $this->registry->get('\Aura\profile\common');
		$id = $profile->fetch_id();

		$user = $profile->fetch_user();

		if (isset($_POST['form_sent']))
			$profile->update_profile('personal');

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Profile'), $this->lang->t('Section personal')),
			'active_page' => 'profile',
		);

		$this->template->header = $this->registry->get('\Aura\extensions\hooks')->fire('profile.personal.header', $this->template->header);
		$args = $this->registry->get('\Aura\extensions\hooks')->fire('profile.personal.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('profile_personal.tpl');
		$this->template->output($tpl,
			array_merge(
				array(
					'csrf_token' => $this->registry->get('\Aura\auth\csrf')->generate('profile'),
					'form_action' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['profile_personal'], array($id)),
					'aura_user' => $this->user,
					'user' => $user,
					'profile_menu' => $this->registry->get('\Aura\profile\menu')->generate($id, 'personal'),
				),
				$args
			)
		);
	}
}