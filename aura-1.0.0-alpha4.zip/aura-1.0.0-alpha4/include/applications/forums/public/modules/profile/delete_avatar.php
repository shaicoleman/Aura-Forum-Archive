<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class delete_avatar_controller etends base_controller
{
	public function execute()
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('profile.deleteavatar.immediate');

		$profile = $this->registry->get('\Aura\profile\common');
		$id = $profile->fetch_id();

		$this->registry->get('\Aura\auth\csrf')->confirm('profile');

		if ($this->user['id'] != $id && !$this->user['is_admmod'])
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		$this->registry->get('\Aura\avatar')->delete_avatar($id);

		$this->registry->get('\Aura\extensions\hooks')->fire('profile.deleteavatar.beforeredirect');
		$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['profile_personality'], array($id)), $this->lang->t('Avatar deleted redirect'));
	}
}