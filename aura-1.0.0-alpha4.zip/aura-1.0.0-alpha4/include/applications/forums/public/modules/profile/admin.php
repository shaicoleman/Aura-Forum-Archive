<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class admin_controller extends base_controller
{
	/**
	 * Main app entry point, show the attachments
	 */
	public function execute()
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('profile.admin.immediate');

		$profile = $this->registry->get('\Aura\profile\common');
		$id = $profile->fetch_id();

		$user = $profile->fetch_user();

		if (!$this->user['is_admmod'] || ($this->user['g_moderator'] == '1' && $this->user['g_mod_ban_users'] == '0'))
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'), false, '403 Forbidden');

		if (isset($_POST['update_group_membership']))
			$this->update_group_membership($id);
		else if (isset($_POST['update_forums']))
			$this->update_forums($id);
		else if (isset($_POST['update_posting_ban']))
			$this->update_posting_ban($id);
		else if (isset($_POST['ban']))
			$this->ban_user($id);
		else if (isset($_POST['delete_user']) || isset($_POST['delete_user_comply']))
			$this->delete_user($id);

		$posting_ban = $this->registry->get('\Aura\aura_time')->format_posting_ban_expiration(($user['posting_ban'] - CURRENT_TIMESTAMP));
		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Profile'), $this->lang->t('Section admin')),
			'active_page' => 'profile',
		);

		$this->template->header = $this->registry->get('\Aura\extensions\hooks')->fire('profile.admin.header', $this->template->header);
		$args = $this->registry->get('\Aura\extensions\hooks')->fire('profile.admin.render');
		$args = (is_array($args) ? $args : array());

		$render = array(
			'form_action' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['profile_admin'], array($id)),
			'csrf_token' => $this->registry->get('\Aura\auth\csrf')->generate('profile'),
			'user' => $user,
			'posting_ban' => $user['g_moderator'] == '0' && $user['g_id'] != AURA_ADMIN && $user['g_admin'] == '0' && ($this->user['is_admin'] == '1') ? true : false,
			'ban_info' => (($posting_ban[2] != $this->lang->t('Never')) ? $this->lang->t('current ban', format_time($user['posting_ban'])) : ''),
			'posting_ban' => $posting_ban,
			'is_moderator' => ($this->user['g_moderator'] == '1' && $this->user['g_admin'] == '0' && $user['g_id'] != AURA_ADMIN) ? true : false,
			'profile_menu' => $this->registry->get('\Aura\profile\menu')->generate($id, 'admin'),
		);

		$render = array_merge($render, $this->fetch_forums($id, $user), $args);

		$tpl = $this->template->load('profile_admin.tpl');
		$this->template->output($tpl, $render);
	}

	/**
	 * Fetch the forums we moderate
	 */
	protected function fetch_forums($id, $user)
	{
		$render = array();
		if ($this->user['is_admin'])
		{
			$admins = $this->cache->get('restrictions');
			if (!isset($admins[$this->user['id']]) || $this->user['id'] == '2')
				$admins[$this->user['id']] = array('admin_users' => '1');

			if ($this->user['id'] != $id && $admins[$this->user['id']]['admin_users'] == '1')
			{
				$groups = array();
				$render['edit_groups'] = true;
				$aura_groups = $this->cache->get('groups');
				foreach ($aura_groups as $cur_group)
					if ($cur_group['g_id'] != AURA_GUEST)
						$groups[] = array('id' => $cur_group['g_id'], 'checked' => (($cur_group['g_id'] == $user['g_id'] || ($cur_group['g_id'] == $this->config['o_default_user_group'] && $user['g_id'] == '')) ? true : false), 'title' => $cur_group['g_title']);

				$render['groups'] = $groups;
			}

			$categories = $forums = array();
			$render['can_delete'] = (($admins[$this->user['id']]['admin_users'] == '1') ? true : false);
			if ($user['g_moderator'] == '1' || $user['g_id'] == AURA_ADMIN)
			{
				$render['user_is_moderator'] = true;
				$join = array(
					array(
						'type' => 'INNER',
						'table' => 'forums',
						'as' => 'f',
						'on' => 'c.id=f.cat_id',
					),
				);

				$moderators = $this->cache->get('moderators');
				$ps = $this->db->join('categories', 'c', $join, 'c.id AS cid, c.cat_name, f.id AS fid, f.forum_name', array(), 'f.redirect_url IS NULL', 'c.disp_position, c.id, f.disp_position');
				foreach ($ps as $cur_forum)
				{
					if (!isset($categories[$cur_forum['cid']]))
					{
						$categories[$cur_forum['cid']] = array(
							'name' => $cur_forum['cat_name'],
							'cid' => $cur_forum['cid'],
						);

						$categories = $this->registry->get('\Aura\extensions\hooks')->fire('profile.admin.categories', $categories);
					}

					$forums[] = array(
						'id' => $cur_forum['fid'],
						'name' => $cur_forum['forum_name'],
						'category_id' => $cur_forum['cid'],
						'checked' => (isset($moderators[$cur_forum['fid']]['u'.$id]) || isset($moderators[$cur_forum['fid']]['g'.$user['g_id']])),
						'disabled' => isset($moderators[$cur_forum['fid']]['g'.$user['g_id']]),
					);

					$forums = $this->registry->get('\Aura\extensions\hooks')->fire('profile.admin.forums', $forums);
				}

				$render['categories'] = $categories;
				$render['forums'] = $forums;
			}
		}

		return $render;
	}

	/**
	 * Update the group ID of a member
	 */
	protected function update_group_membership($id)
	{
		$this->registry->get('\Aura\auth\csrf')->confirm('profile');

		if (!$this->user['is_admin'])
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		$aura_groups = $this->cache->get('groups');
		$new_group_id = isset($_POST['group_id']) ? intval($_POST['group_id']) : 0;
		$select = array(
			':id' => $id,
		);

		$ps = $this->db->select('users', 'group_id', $select, 'id=:id');
		$old_group_id = $ps->fetchColumn();
		
		$update = array(
			'group_id' => $new_group_id,
		);
		
		$data = array(
			':id' => $id,
		);

		$this->db->update('users', $update, 'id=:id', $data);

		// Regenerate the users info cache
		$this->cache->generate('stats');

		if ($old_group_id != 0 && ($old_group_id == AURA_ADMIN || $new_group_id == AURA_ADMIN || $aura_groups[$old_group_id]['g_admin'] == '1' || $aura_groups[$new_group_id]['g_admin'] == '1'))
			$this->cache->generate('admins');
		
		$data = array(
			':id' => $new_group_id
		);

		$ps = $this->db->select('groups', 'g_moderator', $data, 'g_id=:id');
		$new_group_mod = $ps->fetchColumn();

		// If the user was a moderator or an administrator, remove him/her from the moderator list in all forums as well
		if ($new_group_id != AURA_ADMIN && $new_group_mod != '1')
		{
			$data = array(
				':id' => $id,
			);

			$this->db->delete('moderators', 'user_id=:id', $data);
			$this->cache->generate('moderators');
		}

		$this->registry->get('\Aura\extensions\hooks')->fire('profile.admin.beforeredirect');
		$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['profile_admin'], array($id)), $this->lang->t('Group membership redirect'));
	}

	/**
	 * Update the forums we moderate
	 */
	protected function update_forums($id)
	{
		$this->registry->get('\Aura\auth\csrf')->confirm('profile');

		if (!$this->user['is_admin'])
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		// Get the username of the user we are processing
		$data = array(
			':id' => $id,
		);

		$ps = $this->db->select('users', 'username', $data, 'id=:id');
		$username = $ps->fetchColumn();

		$moderator_in = isset($_POST['moderator_in']) && is_array($_POST['moderator_in']) ? array_keys($_POST['moderator_in']) : array();

		// Loop through all forums
		$moderators = $this->cache->get('moderators');
		$aura_forums = $this->cache->get('forums');
		foreach ($aura_forums as $cur_forum)
		{
			$cur_moderators = isset($moderators[$cur_forum['id']]) ? $moderators[$cur_forum['id']] : array();

			// If the user should have moderator access (and he/she doesn't already have it)
			if (in_array($cur_forum['id'], $moderator_in) && !isset($cur_moderators['u'.$id]))
			{
				$insert = array(
					'forum_id' => $cur_forum['id'],
					'user_id' => $id,
					'username' => $username,
				);

				$this->db->insert('moderators', $insert);
			}
			// If the user shouldn't have moderator access (and he/she already has it)
			else if (!in_array($cur_forum['id'], $moderator_in) && isset($cur_moderators['u'.$id]))
			{
				$data = array(
					':id' => $id,
					':fid' => $cur_forum['id'],
				);

				$this->db->delete('moderators', 'user_id=:id AND forum_id=:fid', $data);
			}

			$this->registry->get('\Aura\extensions\hooks')->fire('profile.admin.moderators');
		}

		$this->cache->generate('moderators');
		$this->registry->get('\Aura\extensions\hooks')->fire('profile.admin.moderators.beforeredirect');

		$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['profile_admin'], array($id)), $this->lang->t('Update forums redirect'));
	}

	/**
	 * Update the forums we moderate
	 */
	protected function update_posting_ban($id)
	{
		$this->registry->get('\Aura\auth\csrf')->confirm('profile');

		if (!$this->user['is_admin'])
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'));

		$aura_groups = $this->cache->get('groups');
		$data = array(
			':id' => $id,
		);

		$ps = $this->db->select('users', 'username, group_id', $data, 'id=:id');
		$cur_user = $ps->fetch();

		if ($aura_groups[$cur_user['group_id']]['g_admin'] == '1' || $cur_user['group_id'] == AURA_ADMIN)
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('posting ban admin', $cur_user['username']));

		if ($aura_groups[$cur_user['group_id']]['g_moderator'] == '1')
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('posting ban moderator', $cur_user['username']));

		$expiration_time = isset($_POST['expiration_time']) ? intval($_POST['expiration_time']) : 0;
		$expiration_unit = isset($_POST['expiration_unit']) ? utf8_trim($_POST['expiration_unit']) : $this->lang->t('Days');
		$delete_ban = isset($_POST['remove_ban']) ? '1' : '0';
		$time = ($delete_ban == '1') ? '0' : (CURRENT_TIMESTAMP + $this->registry->get('\Aura\aura_time')->get_expiration_time($expiration_time, $expiration_unit)); 

		$update = array(
			'posting_ban' => $time,
		);

		$this->db->update('users', $update, 'id=:id', $data);
		$this->registry->get('\Aura\extensions\hooks')->fire('profile.admin.postingban.beforeredirect');

		$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['profile_admin'], array($id)), $this->lang->t('Update posting ban redirect'));
	}

	/**
	 * Ban the user
	 */
	protected function ban_user($id)
	{
		if (!$this->user['is_admin'] && ($this->user['g_moderator'] != '1' || $this->user['g_mod_ban_users'] == '0'))
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		// Get the username of the user we are banning
		$data = array(
			':id' => $id,
		);

		$ps = $this->db->select('users', 'username', $data, 'id=:id');
		$username = $ps->fetchColumn();

		// Check whether user is already banned
		$data = array(
			':username'	=> $username,
		);

		$ps = $this->db->select('bans', 'id', $data, 'username=:username', 'expire IS NULL DESC, expire DESC LIMIT 1');
		if ($ps->rowCount())
		{
			$ban_id = $ps->fetchColumn();
			$this->registry->get('\Aura\extensions\hooks')->fire('profile.admin.ban.edit.beforeredirect');

			$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['edit_ban'], array($ban_id)), $this->lang->t('Ban redirect'));
		}
		else
		{
			$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_bans_add'], array($id)), $this->lang->t('Ban redirect'));
			$this->registry->get('\Aura\extensions\hooks')->fire('profile.admin.ban.add.beforeredirect');
		}
	}

	/**
	 * Delete the user
	 */
	protected function delete_user($id)
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('profile.admin.delete.immediate');

		$this->registry->get('\Aura\auth\csrf')->confirm('profile');

		if ($this->user['g_id'] != AURA_ADMIN && $this->user['g_admin'] != '1')
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		$aura_groups = $this->cache->get('groups');
		$restrictions = $this->cache->get('restrictions');
		if (!isset($restrictions[$this->user['id']]) || $this->user['id'] == '2')
			$restrictions[$this->user['id']] = array('admin_users' => '1');	
		
		if ($restrictions[$this->user['id']]['admin_users'] == '0')
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'));

		// Get the username and group of the user we are deleting
		$data = array(
			':id' => $id,
		);

		$ps = $this->db->select('users', 'group_id, username', $data, 'id=:id');
		list($group_id, $username) = $ps->fetch(PDO::FETCH_NUM);

		if ($group_id)
		{
			if ($group_id == AURA_ADMIN || $aura_groups[$group_id]['g_admin'] == '1')
				$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No delete admin message'));
		}

		if (isset($_POST['delete_user_comply']))
			$this->delete_user_comply($id, $user_group, $group_id, $username);

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Profile'), $this->lang->t('Confirm delete user')),
			'active_page' => 'profile',
		);

		$this->template->header = $this->registry->get('\Aura\extensions\hooks')->fire('profile.admin.header', $this->template->header);
		$args = $this->registry->get('\Aura\extensions\hooks')->fire('profile.admin.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('delete_user.tpl');
		$this->template->output($tpl,
			array_merge(
				array(
					'form_action' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['profile'], array($id, \Aura\url\url::replace($username))),
					'username' => $username,
					'csrf_token' => $this->registry->get('\Aura\auth\csrf')->generate('profile'),
				),
				$args
			)
		);
	}

	protected function delete_user_comply($id, $user_group, $group_id, $username)
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('profile.admin.deletecomply.immediate');

		@set_time_limit(0);

		// If the user is a moderator or an administrator, we remove him/her from the moderator list in all forums as well
		$cur_group = $aura_groups[$group_id];

		if ($cur_group['g_admin'] == '1' || $group_id == AURA_ADMIN || $cur_group['moderator'] == '1')
		{
			$data = array(
				':id' => $id,
			);

			$this->db->delete('moderators', 'user_id=:id', $data);
			$cache->generate('moderators');
		}

		// Check if we're currently banned - if it's just the username remove it; otherwise edit it and remove the username
		$bans_altered = false;
		$data = array(
			':username' => $username,
		);

		$ps = $this->db->select('bans', 'id', $data, 'username=:username');
		if ($ps->rowCount())
		{
			$bans_altered = true;
			$ban_id = $ps->fetchColumn();
			$ps = $this->db->select('bans', 1, $data, 'username=:username AND email IS NULL AND ip is NULL'); // If they're banned, remove the ban for their username
			if ($ps->rowCount())
				$this->db->delete('bans', 'username=:username', $data);
			else
			{
				$update = array(
					'username' => null,
				);

				$data = array(
					':id' => $ban_id,
				);

				$this->db->update('bans', $update, 'id=:id', $data);
			}
		}

		$data = array(
			':id' => $id,
		);

		// Delete any subscriptions
		$this->db->delete('topic_subscriptions', 'user_id=:id', $data);
		$this->db->delete('forum_subscriptions', 'user_id=:id', $data);
			
		// Remove any issued warnings
		$this->db->delete('warnings', 'user_id=:id', $data);

		// Remove them from the online list (if they happen to be logged in)
		$this->db->delete('online', 'user_id=:id', $data);

		// Should we delete all posts made by this user?
		if (isset($_POST['delete_posts']))
		{
			// Find all posts made by this user
			$join = array(
				array(
					'type' => 'INNER',
					'table' => 'topics',
					'as' => 't',
					'on' => 't.id=p.topic_id',
				),
				array(
					'type' => 'INNER',
					'table' => 'forums',
					'as' => 'f',
					'on' => 'f.id=t.forum_id',
				),
			);

			$ps = $this->db->join('posts', 'p', $join, 'p.id, p.topic_id, t.forum_id', $data, 'p.poster_id=:id');
			if ($ps->rowCount())
			{
				foreach ($ps as $cur_post)
				{
					// Determine whether this post is the "topic post" or not
					$select = array(
						':id' => $cur_post['topic_id'],
					);

					$ps1 = $this->db->select('posts', 'id', $select, 'topic_id=:id', 'posted LIMIT 1');
					if ($ps1->fetchColumn() == $cur_post['id'])
						$this->registry->get('\Aura\topics\delete_topic')->delete_topic_comply($cur_post['topic_id']);
					else
						$this->registry->get('\Aura\topics\delete_post')->delete_post_comply($cur_post['id'], $cur_post['topic_id']);
						
					$delete = array(
						':id'	=>	$cur_post['id'],
					);
						
					$this->db->delete('reputation', 'post_id=:id', $delete);

					$this->registry->get('\Aura\forum\forum')->update($cur_post['forum_id']);

					$this->registry->get('\Aura\extensions\hooks')->fire('profile.admin.deletecomply.posts');
				}
			}
		}
		else // Set all his/her posts to guest
		{
			$update = array(
				'poster_id'	=> 1,
			);

			$this->db->update('posts', $update, 'poster_id=:id', $data);
		}

		// Delete user avatar
		$this->registry->get('\Aura\avatar')->delete_avatar($id);

		// Delete the user
		$this->db->delete('users', 'id=:id', $data);

		// Regenerate the users info cache
		$this->cache->generate('stats');

		if ($bans_altered)
			$this->cache->generate('bans');

		if ($group_id && ($group_id == AURA_ADMIN || $aura_groups[$group_id]['g_admin'] == '1'))
		{
			$this->cache->generate('admins');
			$this->cache->generate('restrictions');
		}

		$this->registry->get('\Aura\extensions\hooks')->fire('profile.admin.deletecomply.beforeredirect');
		$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['index']), $this->lang->t('User delete redirect'));
	}
}