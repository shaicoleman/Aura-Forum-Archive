<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class display_controller extends base_controller
{
	public function execute()
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('profile.display.immediate');

		$profile = $this->registry->get('\Aura\profile\common');
		$id = $profile->fetch_id();

		$user = $profile->fetch_user();

		if (isset($_POST['form_sent']))
			$profile->update_profile('display');

		if ($this->config['o_avatars'] == '0' && $this->config['o_signatures'] == '0')
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Profile'), $this->lang->t('Section display')),
			'active_page' => 'profile',
		);

		$checkboxes = array();
		if ($this->config['o_smilies'] == '1' || $this->config['o_smilies_sig'] == '1')
			$checkboxes[] = array('name' => 'show_smilies', 'checked' => (($user['show_smilies'] == '1') ? true : false), 'title' => $this->lang->t('Show smilies'));

		if ($this->config['o_signatures'] == '1')
			$checkboxes[] = array('name' => 'show_sig', 'checked' => (($user['show_sig'] == '1') ? true : false), 'title' => $this->lang->t('Show sigs'));

		if ($this->config['o_avatars'] == '1')
			$checkboxes[] = array('name' => 'show_avatars', 'checked' => (($user['show_avatars'] == '1') ? true : false), 'title' => $this->lang->t('Show avatars'));

		if ($this->config['p_message_bbcode'] == '1' && $this->config['p_message_img_tag'] == '1')
			$checkboxes[] = array('name' => 'show_img', 'checked' => (($user['show_img'] == '1') ? true : false), 'title' => $this->lang->t('Show images'));

		if ($this->config['o_signatures'] == '1' && $this->config['p_sig_bbcode'] == '1' && $this->config['p_sig_img_tag'] == '1')
			$checkboxes[] = array('name' => 'show_img_sig', 'checked' => (($user['show_img_sig'] == '1') ? true : false), 'title' => $this->lang->t('Show images sigs'));

		if ($this->config['o_use_editor'])
			$checkboxes[] = array('name' => 'use_editor', 'checked' => (($user['use_editor'] == '1') ? true : false), 'title' => $this->lang->t('Use editor'));

		$checkboxes = $this->registry->get('\Aura\extensions\hooks')->fire('profile.display.checkboxes', $checkboxes);
		$this->template->header = $this->registry->get('\Aura\extensions\hooks')->fire('profile.display.header', $this->template->header);
		$args = $this->registry->get('\Aura\extensions\hooks')->fire('profile.display.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('profile_display.tpl');
		$this->template->output($tpl,
			array_merge(
				array(
					'user' => $user,
					'checkboxes' => $checkboxes,
					'styles' => \Aura\styles::get_style_names(),
					'form_action' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['profile_display'], array($id)),
					'csrf_token' => $this->registry->get('\Aura\auth\csrf')->generate('profile'),
					'profile_menu' => $this->registry->get('\Aura\profile\menu')->generate($id, 'display'),
				),
				$args
			)
		);
	}
}