<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class reputation_controller extends base_controller
{
	/**
	 * Usually this is the main entry point- in this case, we don't technically need this function but it still needs to be public
	 */
	public function execute($do = 'received', $total = 0)
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('profile.reputation.immediate');

		$page = (!isset($_GET['p']) || $_GET['p'] <= '1') ? '1' : intval($_GET['p']);

		//What page are we on?
		$num_pages = ceil($total/$this->config['o_disp_topics_default']);
		if ($page > $num_pages) $page = 1;
		$start_from = intval($this->config['o_disp_topics_default'])*($page-1);

		$reputation = $this->fetch_reputation($do, $start_from);

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Profile'), $user['username'], $this->lang->t('Reputation')),
			'active_page' => 'profile',
			'reputation' => true,
		);

		$this->template->header = $this->registry->get('\Aura\extensions\hooks')->fire('profile.reputation.header', $this->template->header);
		$args = $this->registry->get('\Aura\extensions\hooks')->fire('profile.reputation.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('profile_reputation.tpl');
		$this->template->output($tpl,
			array_merge(
				array(
					'index_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['index']),
					'profile_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['profile'], array($id, url_friendly($user['username']))),
					'user' => $user,
					'rep_section' => $this->lang->t(utf8_ucfirst($section)),
					'pagination' => $this->registry->get('\Aura\pagination')->paginate($num_pages, $page, $this->rewrite->url['profile_'.strtolower($section).'_paginate'], array($id)),
					'section' => $section,
					'aura_user' => $this->user,
					'id' => $id,
					'page' => $page,
					'reputation' => $reputation,
					'profile_menu' => ($this->user['id'] == $id || $this->user['is_admmod'] && ($this->user['is_admin'] || $this->user['g_mod_edit_users'] == '1')) ? $this->functions->generate_profile_menu($id, 'view') : '',
				),
				$args
			)
		);
	}

	/**
	 * One of two main entry points, here we get all rep which is given by the user
	 */
	public function given()
	{
		$this->configure();

		$data = array(
			':id' => $this->id,
		);

		$ps = $this->db->select('reputation', 'COUNT(id)', $data, 'given_by=:id');
		$total = $ps->fetchColumn();

		$this->execute('given', $total);
	}

	/**
	 * Second of two main entry points. We fetch all rep that was received by the user
	 */
	public function received()
	{
		$this->configure();

		$data = array(
			':id' => $this->id,
		);

		$join = array(
			array(
				'type' => 'LEFT',
				'table' => 'posts',
				'as' => 'p',
				'on' => 'r.post_id=p.id',
			),
		);

		$ps = $this->db->join('reputation', 'r', $join, 'COUNT(r.id)', $data, 'p.poster_id=:id');
		$total = $ps->fetchColumn();

		$this->execute('received', $total);
	}

	/**
	 * Configure a few things here that can help to setup the app
	 */
	protected function configure()
	{
		$profile = $this->registry->get('\Aura\profile\common');
		$this->id = $profile->fetch_id();

		$user = $profile->fetch_user();

		if ($this->config['o_avatars'] == '0' && $this->config['o_signatures'] == '0')
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Profile'), $this->lang->t('Section display')),
			'active_page' => 'profile',
		);

		$this->registry->get('\Aura\profile\menu')->generate('display');

		if ($this->config['o_reputation'] == '0')
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'));

		$this->registry->get('\Aura\extensions\hooks')->fire('profile.reputation.configure');
	}

	/**
	 * Fetch the reputation which was given/received 
	 */
	protected function fetch_reputation($do, $start_from)
	{
		$data = array(
			':id' => $this->id,
			':start' => $start_from,
			':limit' => $this->config['o_disp_topics_default'],
		);
		
		$join = array(
			array(
				'type' => 'LEFT',
				'table' => 'posts',
				'as' => 'p',
				'on' => 'p.id=r.post_id',
			),
			array(
				'type' => 'LEFT',
				'table' => 'users',
				'as' => 'u',
				'on' => 'u.id=p.poster_id',
			),
			array(
				'type' => 'LEFT',
				'table' => 'topics',
				'as' => 't',
				'on' => 't.id=p.topic_id',
			),
		);

		switch ($do)
		{
			case 'received':
				$data[':given'] = $this->id;
				$join[1]['on'] = 'u.id=r.given_by';

				$ps = $this->db->join('reputation', 'r', $join, 'r.id, r.given_by, u.group_id, u.username, r.time_given, r.post_id, r.vote, p.topic_id, t.subject, :given AS given_to', $data, 'p.poster_id=:id', 'r.id DESC LIMIT :start,:limit');
				if (!$ps->rowCount())
					$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No received reputation'));
			break;
			default:
				$ps = $this->db->join('reputation', 'r', $join, 'r.id, p.poster_id AS given_to, u.group_id, r.given_by, r.time_given, r.post_id, r.vote, u.username, p.topic_id, t.subject', $data, 'r.given_by=:id', 'r.id DESC LIMIT :start,:limit');
				if (!$ps->rowCount())
					$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No given reputation'));
			break;
		}

		$rep_count = 0;
		$reputation = array();
		foreach ($ps as $cur_row)
		{
			if ($cur_row['username'] == '')
			{
				$cur_row['username'] = $this->lang->t('Deleted user');
				$cur_row['group_id'] = AURA_GUEST;
			}

			if ($cur_row['given_by'] == '')
				$cur_row['given_by'] = AURA_GUEST;

			if ($cur_row['given_to'] == '')
				$cur_row['given_to'] = AURA_GUEST;

			if ($do == 'received')
				$username = $this->functions->colourise_group($cur_row['username'], $cur_row['group_id'], $cur_row['given_by']);
			else
				$username = $this->functions->colourise_group($cur_row['username'], $cur_row['group_id'], $cur_row['given_to']);

			$reputation[] = array(
				'given' => $this->registry->get('aura_time')->format($cur_row['time_given']),
				'user' => $username,
				'vote' => $cur_row['vote'],
				'id' => $cur_row['id'],
				'subject' => $cur_row['subject'],
				'link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['post'], array($cur_row['post_id'])),
			);

			$reputation = $this->registry->get('\Aura\extensions\hooks')->fire('profile.reputation', $reputation);
		}

		return $reputation;
	}
}