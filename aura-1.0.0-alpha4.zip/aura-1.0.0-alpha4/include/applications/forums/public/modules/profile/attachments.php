<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class attachments_controller extends base_controller
{
	/**
	 * Main app entry point, show the attachments
	 */
	public function execute()
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('profile.attachments.immediate');

		$profile = $this->registry->get('\Aura\profile\common');
		$id = $profile->fetch_id();

		$user = $profile->fetch_user();

		if ($this->config['o_attachments'] == '0')
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'), false, '403 Forbidden');

		$attachments = $this->fetch_attachments($id);

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Profile'), $this->lang->t('Section attachments')),
			'active_page' => 'profile',
		);

		$this->template->header = $this->registry->get('\Aura\extensions\hooks')->fire('profile.attachments.header', $this->template->header);
		$args = $this->registry->get('\Aura\extensions\hooks')->fire('profile.attachments.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('profile_attachments.tpl');
		$this->template->output($tpl,
			array_merge(
				array(
					'user' => $user,
					'attachments' => $attachments,
					'profile_menu' => $this->registry->get('\Aura\profile\menu')->generate($id, 'attachments'),
				),
				$args
			)	
		);
	}

	/**
	 * Fetch the attachments!
	 */
	protected function fetch_attachments($id)
	{
		$data = array(
			':id' => $id,
		);

		$attachments = array();
		$ps = $this->db->select('attachments', 'post_id, filename, size, downloads', $data, 'owner=:id');
		foreach ($ps as $attachment)
		{
			$attachments[] = array('num_downloads' => $this->functions->forum_number_format($attachment['downloads']), 'size' => $this->functions->file_size($attachment['size']), 'post_id' => $attachment['post_id'], 'name' => $attachment['filename'], 'transfer' => $this->functions->file_size($attachment['size'] * $attachment['downloads']), 'post_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['post'], array($attachment['post_id'])));
			$attachments = $this->registry->get('\Aura\extensions\hooks')->fire('profile.attachments.attachments', $attachments);
		}

		return $attachments;
	}
}