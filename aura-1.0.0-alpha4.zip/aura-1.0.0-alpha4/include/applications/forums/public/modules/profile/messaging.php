<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class messaging_controller extends base_controller
{
	public function execute()
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('profile.messaging.immediate');
		$profile = $this->registry->get('\Aura\profile\common');
		$id = $profile->fetch_id();

		$user = $profile->fetch_user();

		if (isset($_POST['form_sent']))
			$profile->update_profile('messaging');

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Profile'), $this->lang->t('Section messaging')),
			'active_page' => 'profile',
		);

		$this->template->header = $this->registry->get('\Aura\extensions\hooks')->fire('profile.messaging.header', $this->template->header);
		$args = $this->registry->get('\Aura\extensions\hooks')->fire('profile.messaging.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('profile_messaging.tpl');
		$this->template->output($tpl,
			array_merge(
				array(
					'form_action' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['profile_messaging'], array($id)),
					'csrf_token' => $this->registry->get('\Aura\auth\csrf')->generate('profile'),
					'user' => $user,
					'profile_menu' => $this->registry->get('\Aura\profile\menu')->generate($id, 'messaging'),
				),
				$args
			)
		);
	}
}