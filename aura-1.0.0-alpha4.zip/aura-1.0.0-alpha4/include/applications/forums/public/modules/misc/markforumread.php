<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class markforumread_controller extends base_controller
{
	public function execute()
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('markforumread.immediate');

		$this->lang->load('misc');
		$this->registry->get('\Aura\auth\csrf')->confirm('viewforum');

		if ($this->user['is_guest'])
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		$fid = isset($_GET['fid']) ? intval($_GET['fid']) : 0;
		if ($fid < 1)
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		$data = array(
			':id' => $fid,
		);

		$ps = $this->db->select('forums', 'forum_name', $data, 'id=:id');
		$forum_name = \Aura\url\url::replace($ps->fetchColumn());

		$tracked_topics = $this->registry->get('\Aura\cookie\tracked')->get_tracked_topics();
		$tracked_topics['forums'][$fid] = CURRENT_TIMESTAMP;
		$this->registry->get('\Aura\cookie\tracked')->set_tracked_topics($tracked_topics);

		$this->registry->get('\Aura\extensions\hooks')->fire('markforumread.beforeredirect');
		$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['forum'], array($fid, $forum_name)), $this->lang->t('Mark forum read redirect'));
	}
}