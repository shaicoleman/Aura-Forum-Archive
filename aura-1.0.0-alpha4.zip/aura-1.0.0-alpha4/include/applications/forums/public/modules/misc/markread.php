<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class markread_controller extends base_controller
{
	public function execute()
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('markread.immediate');

		$this->lang->load('misc');
		$this->registry->get('\Aura\auth\csrf')->confirm('index');

		if ($this->user['is_guest'])
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		$update = array(
			'last_visit' => $this->user['logged'],
		);

		$data = array(
			':id' => $this->user['id'],
		);

		$this->db->update('users', $update, 'id=:id', $data);

		// Reset tracked topics
		$this->registry->get('\Aura\cookie\tracked')->set_tracked_topics(null);

		$this->registry->get('\Aura\extensions\hooks')->fire('markread.beforeredirect');
		$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['index']), $this->lang->t('Mark read redirect'));
	}
}