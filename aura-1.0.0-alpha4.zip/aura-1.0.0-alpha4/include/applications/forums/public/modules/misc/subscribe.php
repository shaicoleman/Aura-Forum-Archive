<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class subscribe_controller extends base_controller
{
	/*
	 * Main entry point, subscribe to the topic/forum
	 */
	public function execute()
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('subscribe.immediate');

		$this->registry->get('\Aura\auth\csrf')->confirm('subscribe');
		if ($this->user['is_guest'])
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		$this->lang->load('misc');
		$topic_id = isset($_GET['tid']) ? intval($_GET['tid']) : 0;
		$forum_id = isset($_GET['fid']) ? intval($_GET['fid']) : 0;
		if ($topic_id < 1 && $forum_id < 1)
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		if ($topic_id)
			$this->topic($topic_id);
		else
			$this->forum($forum_id);
	}

	/*
	 * Subscribe to a topic
	 */
	protected function topic($topic_id)
	{
		if ($this->config['o_topic_subscriptions'] != '1')
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		// Make sure the user can view the topic
		$data = array(
			':gid' => $this->user['g_id'],
			':tid' => $topic_id,
		);

		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'forums',
				'as' => 'f',
				'on' => 't.forum_id=f.id',
			),
			array(
				'type' => 'LEFT',
				'table' => 'forum_perms',
				'as' => 'fp',
				'on' => '(fp.forum_id=t.forum_id AND fp.group_id=:gid)',
			),
		);

		$ps = $this->db->join('topics', 't', $join, 't.subject, t.poster, f.password, f.protected, f.id AS fid', $data, '(fp.read_forum IS NULL OR fp.read_forum=1) AND t.id=:tid AND t.moved_to IS NULL');
		if (!$ps->rowCount())
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');
		else
			$cur_topic = $ps->fetch();

		if ($cur_topic['password'] != '')
			$this->registry->get('\Aura\cookie\cookie')->check_forum_login_cookie($cur_topic['fid'], $cur_topic['password']);

		$moderators = $this->cache->get('moderators');
		if ($cur_topic['protected'] == '1' && $this->user['username'] != $cur_topic['poster'] && $this->user['g_global_moderator'] != 1 && !$this->user['is_admin'] && !isset($moderators[$cur_post['fid']]['u'.$this->user['id']]) && !isset($moderators[$cur_post['fid']]['g'.$this->user['g_id']]))
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		$data = array(
			':id'	=>	$this->user['id'],
			':tid'	=>	$topic_id,
		);

		$ps = $this->db->select('topic_subscriptions', 1, $data, 'user_id=:id AND topic_id=:tid');
		if ($ps->rowCount())
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Already subscribed topic'));

		$insert = array(
			'user_id'	=>	$this->user['id'],
			'topic_id'	=>	$topic_id,
		);

		$this->db->insert('topic_subscriptions', $insert);

		$this->registry->get('\Aura\extensions\hooks')->fire('subscribe.topic.beforeredirect');
		$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['topic'], array($topic_id, \Aura\url\url::replace($cur_topic['subject']))), $this->lang->t('Subscribe redirect'));
	}

	/*
	 * Subscribe to a forum
	 */
	protected function forum($forum_id)
	{
		if ($this->config['o_forum_subscriptions'] != '1')
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		// Make sure the user can view the forum (and if a password is present, they know that too)
		$data = array(
			':gid' => $this->user['g_id'],
			':fid' => $forum_id,
		);

		$join = array(
			array(
				'type' => 'LEFT',
				'table' => 'forum_perms',
				'as' => 'fp',
				'on' => '(fp.forum_id=f.id AND fp.group_id=:gid)',
			),
		);

		$ps = $this->db->join('forums', 'f', $join, 'f.forum_name, f.password', $data, '(fp.read_forum IS NULL OR fp.read_forum=1) AND f.id=:fid');
		if (!$ps->rowCount())
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');
		else
			$cur_forum = $ps->fetch();

		if ($cur_forum['password'] != '')
			$this->registry->get('\Aura\cookie\cookie')->check_forum_login_cookie($forum_id, $cur_forum['password']);

		$data = array(
			':id' => $this->user['id'],
			':fid' => $forum_id,
		);

		$ps = $this->db->select('forum_subscriptions', 1, $data, 'user_id=:id AND forum_id=:fid');
		if ($ps->rowCount())
			message($this->lang->t('Already subscribed forum'));

		$insert = array(
			'user_id' => $this->user['id'],
			'forum_id' => $forum_id,
		);

		$this->db->insert('forum_subscriptions', $insert);

		$this->registry->get('\Aura\extensions\hooks')->fire('subscribe.forum.beforeredirect');
		$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['forum'], array($forum_id, \Aura\url\url::replace($cur_forum['forum_name']))), $this->lang->t('Subscribe redirect'));
	}
}