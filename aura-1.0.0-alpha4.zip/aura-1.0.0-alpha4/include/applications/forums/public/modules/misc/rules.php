<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class rules_controller extends base_controller
{
	/*
	 * Main entry point- display the rules
	 */
	public function execute()
	{
		if ($this->config['o_rules'] == '0' || ($this->user['is_guest'] && $this->user['g_read_board'] == '0' && $this->config['o_regs_allow'] == '0'))
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		// Load the register language file
		$this->lang->load('register');

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Forum rules')),
			'active_page' => 'rules',
		);

		$this->template->header = $this->registry->get('\Aura\extensions\hooks')->fire('rules.header', $this->template->header);
		$args = $this->registry->get('\Aura\extensions\hooks')->fire('rules.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('forum_rules.tpl');
		$this->template->output($tpl, $args);
	}
}