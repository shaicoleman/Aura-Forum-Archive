<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class topic_controller extends base_controller
{
	/**
	 * Main app entry point, we want to display the moderator controls for this topic
	 */
	public function execute()
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('moderate.topic.immediate');

		$moderate = new moderate($this->registry);
		list($this->fid, , ,) = $moderate->check_user();

		$this->tid = isset($_GET['tid']) ? intval($_GET['tid']) : 0;
		if ($this->tid < 1)
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		// Fetch some information about the topic
		$cur_topic = $this->fetch_topic();

		// Delete one or more posts
		if (isset($_POST['delete_posts']) || isset($_POST['delete_posts_comply']))
			$this->delete_posts($cur_topic);
		else if (isset($_POST['split_posts']) || isset($_POST['split_posts_comply']))
			$this->split_posts($cur_topic);

		// Load the topic language file
		$this->lang->load('topic');

		if (isset($_GET['action']) && $_GET['action'] == 'all')
			$this->user['disp_posts'] = $cur_topic['num_replies'] + 1;

		// Determine the post offset (based on $_GET['p'])
		$num_pages = ceil(($cur_topic['num_replies'] + 1) / $this->user['disp_posts']);

		$p = (!isset($_GET['p']) || $_GET['p'] <= 1 || $_GET['p'] > $num_pages) ? 1 : intval($_GET['p']);
		$start_from = $this->user['disp_posts'] * ($p - 1);

		$info = $this->fetch_topic_info();

		if ($info['archived'] == '1')
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('topic archived'));

		if ($this->config['o_censoring'] == '1')
			$cur_topic['subject'] = $this->registry->get('\Aura\message\bbcode')->censor_words($cur_topic['subject']);

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $cur_topic['forum_name'], $cur_topic['subject']),
			'active_page' => 'index',
		);

		$this->template->header = $this->registry->get('\Aura\extensions\hooks')->fire('moderate.topic.header', $this->template->header);

		// Retrieve a list of post IDs, LIMIT is (really) expensive so we only fetch the IDs here then later fetch the remaining data
		$posts = $this->fetch_posts($start_from, $cur_topic);

		$args = $this->registry->get('\Aura\extensions\hooks')->fire('moderate.topic.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('moderate_topic.tpl');
		$this->template->output($tpl,
			array_merge(
				array(
					'index_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['index']),
					'forum_name' => $cur_topic['forum_name'],
					'forum_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['forum'], array($this->fid, \Aura\url\url::replace($info['forum_name']))),
					'topic_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['topic'], array($this->tid, \Aura\url\url::replace($info['subject']))),
					'cur_topic' => $cur_topic,
					'pagination' => $this->registry->get('\Aura\pagination')->paginate($num_pages, $p, $this->rewrite->url['moderate_topic'], array($this->fid, $this->tid)),
					'form_action' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['moderate_topic'], array($this->fid, $this->tid)),
					'posts' => $posts,
				),
				$args
			)
		);
	}

	/**
	 * Fetch some info about the topic
	 */
	protected function fetch_topic()
	{
		$data = array(
			':gid' => $this->user['g_id'],
			':fid' => $this->fid,
			':tid' => $this->tid,
		);

		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'forums',
				'as' => 'f',
				'on' => 'f.id=t.forum_id',
			),
			array(
				'type' => 'LEFT',
				'table' => 'forum_perms',
				'as' => 'fp',
				'on' => '(fp.forum_id=f.id AND fp.group_id=:gid)',
			),
		);

		$ps = $this->db->join('topics', 't', $join, 't.subject, t.num_replies, t.first_post_id, f.id AS forum_id, f.forum_name', $data, '(fp.read_forum IS NULL OR fp.read_forum=1) AND f.id=:fid AND t.id=:tid AND t.moved_to IS NULL');
		if (!$ps->rowCount())
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');
		else
			$cur_topic = $ps->fetch();

		$cur_topic = $this->registry->get('\Aura\extensions\hooks')->fire('moderate.topic.fetchtopic', $cur_topic);
		return $cur_topic;
	}

	/**
	 * We want to fetch all posts for this topic
	 */
	protected function fetch_posts($start_from, $cur_topic)
	{
		$parser = $this->registry->get('\Aura\message\parser');
		$post_count = 0; // Keep track of post numbers

		$data = array(
			':id' => $this->tid,
		);

		$ps = $this->db->select('posts', 'id', $data, 'topic_id=:id', 'id LIMIT '.$start_from.','.$this->user['disp_posts']);

		$post_ids = array();
		$ps->setFetchMode(PDO::FETCH_COLUMN, 0);
		foreach ($ps as $cur_post_id)
		{
			$post_ids[] = $cur_post_id;
			$markers[] = '?';
		}

		// Retrieve the posts (and their respective poster)
		$posts = array();
		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'users',
				'as' => 'u',
				'on' => 'u.id=p.poster_id',
			),
			array(
				'type' => 'INNER',
				'table' => 'groups',
				'as' => 'g',
				'on' => 'g.g_id=u.group_id',
			),
		);

		$ps = $this->db->join('posts', 'p', $join, 'u.title, u.num_posts, g.g_id, g.g_user_title, p.id, p.poster, p.poster_id, p.message, p.hide_smilies, p.posted, p.edited, p.edited_by', $post_ids, 'p.id IN ('.implode(',', $markers).')', 'p.id');
		foreach ($ps as $cur_post)
		{
			$post_count++;

			// If the poster is a registered user
			if ($cur_post['poster_id'] > 1)
			{
				$poster = $this->functions->colourise_group($cur_post['poster'], $cur_post['g_id'], $cur_post['poster_id']);

				// get_title() requires that an element 'username' be present in the array
				$cur_post['username'] = $cur_post['poster'];
				$user_title = $this->registry->get('\Aura\topics\title')->get_title($cur_post);

				if ($this->config['o_censoring'] == '1')
					$user_title = $this->registry->get('\Aura\message\bbcode')->censor_words($user_title);
			}
			// If the poster is a guest (or a user that has been deleted)
			else
			{
				$poster = $cur_post['poster'];
				$user_title = $this->lang->t('Guest');
			}

			$posts[] = array(
				'message' => $parser->parse_message($cur_post['message'], $cur_post['hide_smilies']),
				'poster' => $poster,
				'user_title' => $user_title,
				'post_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['post'], array($cur_post['id'])),
				'posted' => $this->registry->get('\Aura\aura_time')->format($cur_post['posted']),
				'id' => $cur_post['id'],
				'first_post_id' => $cur_topic['first_post_id'],
				'count' => ($start_from + $post_count),
				'edited' => ($cur_post['edited'] != '') ? $this->registry->get('\Aura\aura_time')->format($cur_post['edited']) : '',
				'edited_by' => $cur_post['edited_by'],
			);

			$posts = $this->registry->get('\Aura\extensions\hooks')->fire('moderate.topic.fetchposts', $posts);
		}

		return $posts;
	}

	/**
	 * We want to fetch the post info
	 */
	protected function fetch_topic_info()
	{
		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'forums',
				'as' => 'f',
				'on' => 't.forum_id=f.id',
			),
		);

		$data = array(
			':id' => $this->tid,
		);

		$ps = $this->db->join('topics', 't', $join, 't.subject, t.archived, f.forum_name', $data, 't.id=:id');
		if (!$ps->rowCount())
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'));
		else
			$info = $ps->fetch();

		$info = $this->registry->get('\Aura\extensions\hooks')->fire('moderate.topic.fetchpostinfo', $info);
		return $info;
	}

	/**
	 * Delete some posts from the topic
	 */
	protected function delete_posts($cur_topic)
	{
		$posts = ((isset($_POST['posts']) && is_array($_POST['posts'])) ? array_map('intval', $_POST['posts']) : (isset($_POST['posts']) ? array_map('intval', explode(',', $_POST['posts'])) : array()));
		if (empty($posts))
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No posts selected'));

		if (isset($_POST['delete_posts_comply']))
			$this->delete_posts_comply($posts, $cur_topic);

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Moderate')),
			'active_page' => 'index',
		);

		$this->template->header = $this->registry->get('\Aura\extensions\hooks')->fire('moderate.topic.delete.header', $this->template->header);
		$args = $this->registry->get('\Aura\extensions\hooks')->fire('moderate.topic.delete.render', $args);
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('delete_posts.tpl');
		$this->template->output($tpl,
			array_merge(
				array(
					'csrf_token' => $this->registry->get('\Aura\auth\csrf')->generate('delete_posts'),
					'form_action' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['moderate_topic'], array($this->fid, $this->tid)),
					'posts' => implode(',', array_map('intval', array_keys($posts))),
				),
				$args
			)
		);
	}

	/**
	 * Here, we actually want to delete the posts
	 */
	protected function delete_posts_comply($posts, $cur_topic)
	{
		$this->registry->get('\Aura\auth\csrf')->confirm('delete_posts');

		$data = array();
		for ($i = 0; $i < count($posts); $i++)
		{
			$data[] = $posts[$i];
			$placeholders[] = '?';
		}

		$post_data = $data;
		$data[] = $this->tid;

		$sql = 'id IN('.implode(',', $placeholders).') AND topic_id=?';
		if (!$this->user['is_admin'] && $this->user['g_mod_edit_admin_posts'] == '0')
		{
			$admins = $this->cache->get('admins');
			for($i = 0; $i < count($admins); $i++)
			{
				$data[] = $admins[$i];
				$markers[] = '?';
			}

			$sql .= ' AND poster_id NOT IN('.implode(',', $markers).')';
		}

		// Run the SQL
		$ps = $this->db->select('posts', 1, $data, $sql);

		if (!$ps->rowCount())
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');
		else
			$deleted_posts = $ps->rowCount();

		foreach($posts as $id)
		{
			$this->registry->get('\Aura\topics\attachment')->attach_delete_post($id);
			$posts = $this->registry->get('\Aura\extensions\hooks')->fire('moderate.topic.deletecomply.posts', $posts);
		}

		// Delete the posts
		if ($this->config['o_delete_full'] == '1')
			$this->db->delete('posts', 'id IN('.implode(',', $placeholders).')', $post_data);
		else
			$this->db->run('UPDATE '.$this->db->prefix.'posts SET deleted=1 WHERE id IN('.implode(',', $placeholders).')', $post_data);

		$idx = $this->registry->get('\Aura\search\idx');
		$idx->strip_search_index($posts);

		$data = array(
			':id' => $this->tid,
		);

		// Get last_post, last_post_id, and last_poster for the topic after deletion
		$ps = $this->db->select('posts', 'id, poster, posted', $data, 'topic_id=:id', 'id DESC LIMIT 1');
		$last_post = $ps->fetch();

		// How many posts did we just delete?
		$num_replies = $cur_topic['num_replies'] - $deleted_posts;

		// Update the topic
		$update = array(
			'last_post'	=>	$last_post['posted'],
			'last_post_id'	=>	$last_post['id'],
			'last_poster'	=>	$last_post['poster'],
			'num_replies'	=>	$num_replies,
		);
	
		$data = array(
			':id' => $this->tid,
		);
	
		$this->db->update('topics', $update, 'id=:id', $data);

		$this->registry->get('\Aura\forum\forum')->update($this->fid);

		$this->registry->get('\Aura\extensions\hooks')->fire('moderate.topic.deletecomply.beforeredirect', $args);
		$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['topic'], array($this->tid, \Aura\url\url::replace($cur_topic['subject']))), $this->lang->t('Delete posts redirect'));
	}

	/**
	 * Split some posts in a topic
	 */
	protected function split_posts($cur_topic)
	{
		$posts = ((isset($_POST['posts']) && is_array($_POST['posts'])) ? array_map('intval', $_POST['posts']) : (isset($_POST['posts']) ? array_map('intval', explode(',', $_POST['posts'])) : array()));
		if (empty($posts))
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No posts selected'));

		if (isset($_POST['split_posts_comply']))
			$this->split_posts_comply($posts, $cur_topic);

		list($categories, $forums) = $this->fetch_forums();

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Moderate')),
			'focus_element' => array('subject','new_subject'),
			'active_page' => 'index',
		);

		$this->template->header = $this->registry->get('\Aura\extensions\hooks')->fire('moderate.topic.split.header', $this->template->header);
		$args = $this->registry->get('\Aura\extensions\hooks')->fire('moderate.topic.split.render', $args);
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('split_posts.tpl');
		$this->template->output($tpl,
			array_merge(
				array(
					'form_action' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['moderate_topic'], array($this->fid, $this->tid)),
					'csrf_token' => $this->registry->get('\Aura\auth\csrf')->generate('split_posts'),
					'posts' => implode(',', array_map('intval', array_keys($posts))),
					'forums' => $forums,
					'categories' => $categories,
					'fid' => $this->fid,
				),
				$args
			)
		);
	}

	/**
	 * Fetch forums for the forms
	 */
	protected function fetch_forums()
	{
		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'forums',
				'as' => 'f',
				'on' => 'c.id=f.cat_id',
			),
			array(
				'type' => 'LEFT',
				'table' => 'forum_perms',
				'as' => 'fp',
				'on' => '(fp.forum_id=f.id AND fp.group_id=:gid)',
			),
		);

		$data = array(
			':gid' => $this->user['g_id'],
		);

		$cur_category = 0;
		$categories = $forums = array();
		$ps = $this->db->join('categories', 'c', $join, 'c.id AS cid, c.cat_name, f.id AS fid, f.forum_name', $data, '(fp.post_topics IS NULL OR fp.post_topics=1) AND f.redirect_url IS NULL', 'c.disp_position, c.id, f.disp_position');
		foreach ($ps as $cur_forum)
		{
			if (!isset($categories[$cur_forum['cid']]))
			{
				$categories[$cur_forum['cid']] = array(
					'name' => $cur_forum['cat_name'],
					'id' => $cur_forum['cid'],
				);

				$categories = $this->registry->get('\Aura\extensions\hooks')->fire('moderate.fetch.categories', $categories);
			}

			$forums[] = array(
				'category_id' => $cur_forum['cid'],
				'id' => $cur_forum['fid'],
				'name' => $cur_forum['forum_name'],
			);

			$forums = $this->registry->get('\Aura\extensions\hooks')->fire('moderate.fetch.forums', $forums);
		}

		return array($categories, $forums);
	}

	/**
	 * Here we want to actually split the posts
	 */
	protected function split_posts_comply($posts, $cur_topic)
	{
		$this->registry->get('\Aura\auth\csrf')->confirm('split_posts');

		if (@preg_match('%[^0-9,]%', implode(',', $posts)))
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		$move_to_forum = isset($_POST['move_to_forum']) ? intval($_POST['move_to_forum']) : 0;
		if ($move_to_forum < 1)
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		// How many posts did we just split off?
		$num_posts_splitted = count($posts);
		$num_replies = $cur_topic['num_replies'] - $num_posts_splitted;

		$data = array();
		$update_data = array($this->tid);	// We need the first value assigned to the new topic ID. So to avoid a second loop, just assign it to the current topic id then replace it later
		for ($i = 0; $i < $num_posts_splitted; $i++)
		{
			$markers[] = '?';
			$data[] = $update_data[] = $posts[$i];	// I know, this is not very nice assigning two variables to the same value. But it avoids a second foreach() loop later.
		}

		$data[] = $this->tid;
		// Verify that the post IDs are valid
		$ps = $this->db->select('posts', 'id', $data, 'id IN ('.implode(',', $markers).') AND topic_id=?');
		if ($ps->rowCount() != $num_posts_splitted)
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		// Verify that the move to forum ID is valid
		$join = array(
			array(
				'type' => 'LEFT',
				'table' => 'forum_perms',
				'as' => 'fp',
				'on' => '(fp.group_id=:gid AND fp.forum_id=:fid)',
			),
		);

		$data = array(
			':gid'	=>	$this->user['g_id'],
			':fid'	=>	$move_to_forum,
		);

		$ps = $this->db->join('forums', 'f', $join, 1, $data, 'f.redirect_url IS NULL AND (fp.post_topics IS NULL OR fp.post_topics=1)');
		if (!$ps->rowCount())
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		// Load the post language file
		$this->lang->load('post');

		// Check subject
		$new_subject = isset($_POST['new_subject']) ? utf8_trim($_POST['new_subject']) : '';

		if ($new_subject == '')
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No subject'));
		else if (aura_strlen($new_subject) > 70)
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Too long subject'));

		$this->registry->get('\Aura\extensions\hooks')->fire('moderate.splitcomply.authorised');
	
		// Get data from the new first post
		$ps = $this->db->select('posts', 'id, poster, posted', $posts, 'id IN('.implode(',', $markers).')', 'id ASC LIMIT 1');
		$first_post_data = $ps->fetch();

		// Create the new topic
		$insert = array(
			'poster'	=>	$first_post_data['poster'],
			'subject'	=>	$new_subject,
			'posted'	=>	$first_post_data['posted'],
			'first_post_id'	=>	$first_post_data['id'],
			'forum_id'	=>	$move_to_forum,
		);

		$this->db->insert('topics', $insert);
		$new_tid = $this->db->lastInsertId('topics');
		$update_data[0] = $new_tid;

		// Move the posts to the new topic
		$this->db->run('UPDATE '.$this->db->prefix.'posts SET topic_id=? WHERE id IN('.implode(',', $markers).')', $update_data);

		// Apply every subscription to both topics
		$data = array(
			':new_tid'	=>	$new_tid,
			':tid'	=>	$this->tid,
		);
		
		$this->db->run('INSERT INTO '.$this->db->prefix.'topic_subscriptions (user_id, topic_id) SELECT user_id, :new_tid FROM '.$this->db->prefix.'topic_subscriptions WHERE topic_id=:tid', $data);

		// Get last_post, last_post_id, and last_poster from the topic and update it
		$data = array(
			':id' => $this->tid,
		);

		$ps = $this->db->select('posts', 'id, posted, poster', $data, 'topic_id=:id', 'id DESC LIMIT 1');
		$last_post_data = $ps->fetch();
				
		$update = array(
			'last_post'		=>	$last_post_data['posted'],
			'last_post_id'	=>	$last_post_data['id'],
			'last_poster'	=>	$last_post_data['poster'],
			'num_replies'	=>	$num_replies,
		);
				
		$data = array(
			':id'	=>	$this->tid,
		);
				
		$this->db->update('topics', $update, 'id=:id', $data);

		// Get last_post, last_post_id, and last_poster from the new topic and update it
		$data = array(
			':id' => $new_tid,
		);

		$ps = $this->db->select('posts', 'id, poster, posted', $data, 'topic_id=:id', 'id DESC LIMIT 1');
		$last_post_data = $ps->fetch();

		$this->registry->get('\Aura\extensions\hooks')->fire('moderate.splitcomply.update');

		$update = array(
			'last_post'		=>	$last_post_data['posted'],
			'last_post_id'	=>	$last_post_data['id'],
			'last_poster'	=>	$last_post_data['poster'],
			'num_replies'	=>	($num_posts_splitted-1),
		);
				
		$data = array(
			':id'	=>	$new_tid,
		);

		$this->db->update('topics', $update, 'id=:id', $data);

		$this->registry->get('\Aura\forum\forum')->update($this->fid);
		$this->registry->get('\Aura\forum\forum')->update($move_to_forum);

		$this->registry->get('\Aura\extensions\hooks')->fire('moderate.splitcomply.beforeredirect');
		$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['topic'], array($new_tid, \Aura\url\url::replace($new_subject))), $this->lang->t('Split posts redirect'));
	}
}