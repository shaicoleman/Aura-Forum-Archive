<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class categories_controller extends base_controller
{
	/**
	 * Main app entry point, we display the categories
	 */
	public function execute()
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('admin.categories.immediate');
		$this->admin = $this->registry->get('\Aura\admin\common');

		if (!$this->user['is_admin'])
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		$this->admin->check_user('admin_categories');

		$this->registry->get('\Aura\auth\http_auth')->check_authentication();

		// Load the admin-censoring language file
		$this->lang->load('admin_categories');

		if (isset($_POST['add_cat'])) // Add a new category
			$this->add_category();
		else if (isset($_POST['update'])) // Change position and name of the categories
			$this->update_categories();
		else if (isset($_POST['del_cat']) || isset($_POST['del_cat_comply']))
			$this->delete_category();

		$categories = array();
		$ps = $this->db->select('categories', 'id, cat_name, disp_position', array(), '', 'disp_position');
		foreach ($ps as $cur_cat)
			$categories[] = array('id' => $cur_cat['id'], 'name' => $cur_cat['cat_name'], 'disp_position' => $cur_cat['disp_position']);

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Admin'), $this->lang->t('Categories')),
			'active_page' => 'admin',
			'admin_console' => true,
		);

		$this->template->header = $this->registry->get('\Aura\extensions\hooks')->fire('admin.categories.header', $this->template->header);
		$this->template->footer = array(
			'admin_console' => true,
		);

		$this->template->footer = $this->registry->get('\Aura\extensions\hooks')->fire('admin.categories.footer', $this->template->footer);
		$args = $this->registry->get('\Aura\extensions\hooks')->fire('admin.categories.execute.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('admin/categories.tpl');
		$this->template->output($tpl,
			array_merge(
				array(
					'admin_menu' => $this->admin->generate_menu('categories'),
					'form_action' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_categories']),
					'csrf_token' => $this->registry->get('\Aura\auth\csrf')->generate('admin_categories'),
					'admin_forums' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_forums']),
					'categories' => $categories,
				),
				$args
			)
		);
	}

	/**
	 * Add a new category to the forum
	 */
	protected function add_category()
	{
		$this->registry->get('\Aura\auth\csrf')->confirm('admin_categories');

		$new_cat_name = isset($_POST['new_cat_name']) ? utf8_trim($_POST['new_cat_name']) : '';
		if ($new_cat_name == '')
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Must enter name message'));

		$insert = array(
			'cat_name' => $new_cat_name,
		);

		$this->db->insert('categories', $insert);

		$this->registry->get('\Aura\extensions\hooks')->fire('admin.categories.add.beforeredirect');
		$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_categories']), $this->lang->t('Category added redirect'));
	}

	/**
	 * Update the position .etc. of the categories on the forum
	 */
	protected function update_categories()
	{
		$this->registry->get('\Aura\auth\csrf')->confirm('admin_categories');

		$categories = isset($_POST['cat']) && is_array($_POST['cat']) ? $_POST['cat'] : array();
		if (empty($categories))
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		foreach ($categories as $cat_id => $cur_cat)
		{
			$cur_cat['name'] = isset($cur_cat['name']) ? utf8_trim($cur_cat['name']) : '';
			$cur_cat['order'] = isset($cur_cat['order']) ? intval($cur_cat['order']) : 0;

			if ($cur_cat['name'] == '')
				$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Must enter name message'));

			if ($cur_cat['order'] < 0)
				$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Must enter integer message'));
			
			$update = array(
				'cat_name' => $cur_cat['name'],
				'disp_position' => $cur_cat['order'],
			);
			
			$data = array(
				':id' => intval($cat_id),
			);

			$this->db->update('categories', $update, 'id=:id', $data);
		}

		// Regenerate the quick jump cache
		$this->cache->generate('quickjump');

		$this->registry->get('\Aura\extensions\hooks')->fire('admin.categories.edit.beforeredirect');
		$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_categories']), $this->lang->t('Categories updated redirect'));
	}

	protected function delete_category()
	{
		$this->registry->get('\Aura\auth\csrf')->confirm('admin_categories');

		$cat_to_delete = isset($_POST['cat_to_delete']) ? intval($_POST['cat_to_delete']) : 0;
		if ($cat_to_delete < 1)
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		if (isset($_POST['del_cat_comply'])) // Delete a category with all forums and posts
		{
			@set_time_limit(0);
			$data = array(
				':id' => $cat_to_delete,
			);

			$ps = $this->db->select('forums', 'id', $data, 'cat_id=:id');
			$ps->setFetchMode(PDO::FETCH_COLUMN, 0);
			foreach ($ps as $cur_forum)
			{
				$this->registry->get('\Aura\admin\misc')->prune($cur_forum, 1, -1);
				$data = array(
					':id' => $cur_forum,
				);

				// Delete the forum
				$db->delete('forums', 'id=:id', $data);
			}

			$join = array(
				array(
					'type' => 'LEFT',
					'table' => 'topics',
					'as' => 't2',
					'on' => 't1.moved_to=t2.id',
				),
			);

			// Locate any "orphaned redirect topics" and delete them
			$this->db->join('topics', 't1', $join, 't1.id', array(), 't2.id IS NULL AND t1.moved_to IS NOT NULL');
			if ($ps->rowCount())
			{
				$data = $markers = array();
				$ps->setFetchMode(PDO::FETCH_COLUMN, 0);
				foreach ($ps as $orphan)
				{
					$markers[] = '?';
					$data[] = $orphan;
				}

				$this->db->delete('topics', 'id IN('.implode(',', $markers).')', $data);
			}
			
			$data = array(
				':id' => $cat_to_delete
			);

			// Delete the category
			$this->db->delete('categories', 'id=:id', $data);

			// Regenerate some caches ...
			$this->cache->generate('forums');
			$this->cache->generate('quickjump');
			$this->cache->generate('perms');

			$this->registry->get('\Aura\extensions\hooks')->fire('admin.categories.delete.beforeredirect');
			$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_categories']), $this->lang->t('Category deleted redirect'));
		}
		else // If the user hasn't confirmed the delete
		{
			$data = array(
				':id' => $cat_to_delete,
			);

			$ps = $this->db->select('categories', 'cat_name', $data, 'id=:id');
			$cat_name = $ps->fetchColumn();

			$this->template->header = array(
				'page_title' => array($this->config['o_board_title'], $this->lang->t('Admin'), $this->lang->t('Categories')),
				'active_page' => 'admin',
				'admin_console' => true,
			);

			$this->template->header = $this->registry->get('\Aura\extensions\hooks')->fire('admin.categories.header', $this->template->header);
			$this->template->footer = array(
				'admin_console' => true,
			);

			$this->template->footer = $this->registry->get('\Aura\extensions\hooks')->fire('admin.categories.footer', $this->template->footer);
			$args = $this->registry->get('\Aura\extensions\hooks')->fire('admin.categories.delete.render');
			$args = (is_array($args) ? $args : array());

			$tpl = $this->template->load('admin/delete_category.tpl');
			$this->template->output($tpl,
				array(
					'admin_menu' => $this->admin->generate_menu('categories'),
					'form_action' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_categories']),
					'csrf_token' => $this->registry->get('\Aura\auth\csrf')->generate('admin_categories'),
					'cat_name' => $cat_name,
					'cat_to_delete' => $cat_to_delete,
				)
			);

			exit;
		}
	}
}