<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class index_controller extends base_controller
{
	/**
	 * Main entry point, execute the app
	 */
	public function execute()
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('admin.index.immediate');

		header('Location: '.$this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_index']));
		exit;
	}
}