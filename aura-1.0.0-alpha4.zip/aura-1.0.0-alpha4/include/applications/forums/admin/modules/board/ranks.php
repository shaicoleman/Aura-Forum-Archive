<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class ranks_controller extends base_controller
{
	/**
	 * Main class entry point
	 */
	public function execute()
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('admin.ranks.immediate');
		$admin = $this->registry->get('\Aura\admin\common');

		if (!$this->user['is_admin'])
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		$admin->check_user('admin_ranks');

		$this->registry->get('\Aura\auth\http_auth')->check_authentication();

		// Load the admin-ranks language file
		$this->lang->load('admin_ranks');

		// Configure the event handlers
		if (isset($_POST['add_rank']))
			$this->add_rank();
		else if (isset($_POST['update'])) // Update a rank
			$this->update_rank();
		else if (isset($_POST['remove'])) // Remove a rank
			$this->delete_rank();

		$ranks = array();
		$ps = $this->db->select('ranks', 'id, rank, min_posts', array(), '', 'min_posts');
		foreach ($ps as $cur_rank)
			$ranks[] = array('id' => $cur_rank['id'], 'rank' => $cur_rank['rank'], 'min_posts' => $cur_rank['min_posts']);

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Admin'), $this->lang->t('Ranks')),
			'focus_element' => array('ranks', 'new_rank'),
			'active_page' => 'admin',
			'admin_console' => true,
		);

		$this->template->header = $this->registry->get('\Aura\extensions\hooks')->fire('admin.ranks.header', $this->template->header);
		$this->template->footer = array(
			'admin_console' => true,
		);

		$this->template->footer = $this->registry->get('\Aura\extensions\hooks')->fire('admin.ranks.footer', $this->template->footer);
		$args = $this->registry->get('\Aura\extensions\hooks')->fire('admin.ranks.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('admin/ranks.tpl');
		$this->template->output($tpl,
			array_merge(
				array(
					'admin_menu' => $admin->generate_menu('ranks'),
					'form_action' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_ranks']),
					'csrf_token' => $this->registry->get('\Aura\auth\csrf')->generate('admin_ranks'),
					'admin_options' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_options']),
					'ranks' => $ranks,
					'ranks_lang' => $this->config['o_ranks'] == '1' ? $this->lang->t('Ranks enabled') : $this->lang->t('Ranks disabled'),
				),
				$args
			)
		);
	}

	/**
	 * Add a new rank
	 */
	protected function add_rank()
	{
		$this->registry->get('\Aura\auth\csrf')->confirm('admin_ranks');

		$rank = isset($_POST['new_rank']) ? utf8_trim($_POST['new_rank']) : '';
		$min_posts = isset($_POST['new_min_posts']) ? utf8_trim($_POST['new_min_posts']) : '';

		if ($rank == '')
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Must enter title message'));

		if ($min_posts == '' || preg_match('%[^0-9]%', $min_posts))
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Must be integer message'));

		// Make sure there isn't already a rank with the same min_posts value
		$data = array(
			':posts' => $min_posts,
		);

		$ps = $this->db->select('ranks', 1, $data, 'min_posts=:posts');
		if ($ps->rowCount())
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Dupe min posts message', $min_posts));
		
		$insert = array(
			'rank' => $rank,
			'min_posts' => $min_posts,
		);

		$this->db->insert('ranks', $insert);

		// Regenerate the ranks cache
		$this->cache->generate('ranks');

		$this->registry->get('\Aura\extensions\hooks')->fire('admin.ranks.add.beforeredirect');
		$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_ranks']), $this->lang->t('Rank added redirect'));
	}

	/**
	 * Edit a rank
	 */
	protected function update_rank()
	{
		$this->registry->get('\Aura\auth\csrf')->confirm('admin_ranks');

		$id = intval(key($_POST['update']));

		$rank = isset($_POST['rank'][$id]) ? utf8_trim($_POST['rank'][$id]) : '';
		$min_posts = isset($_POST['min_posts'][$id]) ? utf8_trim($_POST['min_posts'][$id]) : '';

		if ($rank == '')
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Must enter title message'));

		if ($min_posts == '' || preg_match('%[^0-9]%', $min_posts))
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Must be integer message'));

		// Make sure there isn't already a rank with the same min_posts value
		$data = array(
			':id' => $id,
			':posts' => $min_posts,
		);

		$ps = $this->db->select('ranks', 1, $data, 'id!=:id AND min_posts=:posts');
		if ($ps->rowCount())
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Dupe min posts message', $min_posts));

		$update = array(
			'rank' => $rank,
			'min_posts'	=> $min_posts,
		);

		$data = array(
			':id'	=>	$id,
		);

		$this->db->update('ranks', $update, 'id=:id', $data);

		// Regenerate the ranks cache
		$this->cache->generate('ranks');

		$this->registry->get('\Aura\extensions\hooks')->fire('admin.ranks.update.beforeredirect');
		$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_ranks']), $this->lang->t('Rank updated redirect'));
	}

	/**
	 * Delete a rank
	 */
	protected function delete_rank()
	{
		$this->registry->get('\Aura\auth\csrf')->confirm('admin_ranks');

		$id = intval(key($_POST['remove']));
		$data = array(
			':id'	=>	$id,
		);

		$this->db->delete('ranks', 'id=:id', $data);

		// Regenerate the ranks cache
		$this->cache->generate('ranks');

		$this->registry->get('\Aura\extensions\hooks')->fire('admin.ranks.delete.beforeredirect');
		$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_ranks']), $this->lang->t('Rank removed redirect'));
	}
}