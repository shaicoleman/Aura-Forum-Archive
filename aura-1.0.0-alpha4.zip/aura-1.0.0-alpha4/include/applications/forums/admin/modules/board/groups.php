<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class groups_controller extends base_controller
{
	/**
	 * Main app entry point, we display the groups
	 */
	public function execute()
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('admin.groups.immediate');
		$this->configure_page();

		// Configure our event handlers for this page
		if (isset($_POST['add_group']) || isset($_GET['edit_group']))
			$this->edit_group();
		else if (isset($_POST['add_edit_group'])) // Add/edit a group (stage 2)
			$this->add_edit_group();
		else if (isset($_POST['set_default_group'])) // Set default group
			$this->update_default_group();
		else if (isset($_GET['delete_group'])) // Remove a group
			$this->remove_group();

		// Fetch the information relating to groups
		list($group_options, $default_options, $new_options) = $this->fetch_group_information();

		$args = $this->registry->get('\Aura\extensions\hooks')->fire('admin.groups.execute.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('admin/groups.tpl');
		$this->template->output($tpl,
			array(
				'admin_menu' => $this->admin->generate_menu('groups'),
				'form_action' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_groups']),
				'csrf_token' => $this->registry->get('\Aura\auth\csrf')->generate(config::ADMIN_DIR.'_groups'),
				'group_options' => $group_options,
				'default_options' => $default_options,
				'new_options' => $new_options,
			)
		);
	}

	/**
	 * Delete a group image
	 */
	public function delete_image()
	{
		$this->configure_page();

		$this->registry->get('\Aura\auth\csrf')->confirm(config::ADMIN_DIR.'_groups');

		$aura_groups = $this->cache->get('groups');
		$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

		if (!isset($aura_groups[$id]))
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'));

		if ($aura_groups[$id]['g_image'] == '')
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'));

		$image_path = ($this->config['o_image_group_dir'] != '') ? $this->config['o_image_group_path'] : AURA_ROOT.$this->config['o_image_group_path'].'/';
		@unlink($image_path.$id.'.'.$aura_groups[$id]['g_image']);

		$update = array(
			'g_image' => '',
		);

		$data = array(
			':id' => $id,
		);

		$this->db->update('groups', $update, 'g_id=:id', $data);

		$this->cache->generate('groups');

		$this->registry->get('\Aura\extensions\hooks')->fire('admin.groups.deleteimage');
		$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_groups']), $this->lang->t('Image deleted redirect'));
	}

	/**
	 * Upload a new image
	 */
	public function upload_image()
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('admin.groups.uploadimage.immediate');

		$this->configure_page();

		$aura_groups = $this->cache->get('groups');
		$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

		if (!isset($aura_groups[$id]))
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'));

		$image_path = ($this->config['o_image_group_dir'] != '') ? $this->config['o_image_group_path'] : AURA_ROOT.$this->config['o_image_group_path'].'/';

		if (isset($_POST['form_sent']))
		{
			$this->registry->get('\Aura\auth\csrf')->confirm(config::ADMIN_DIR.'_groups');

			if (!isset($_FILES['req_file']))
				$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No file'));

			$uploaded_file = $_FILES['req_file'];

			// Make sure the upload went smooth
			if (isset($uploaded_file['error']))
			{ 
				switch ($uploaded_file['error'])
				{
					case 1:	// UPLOAD_ERR_INI_SIZE
					case 2:	// UPLOAD_ERR_FORM_SIZE
						$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Too large ini'));
						break;

					case 3:	// UPLOAD_ERR_PARTIAL
						$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Partial upload'));
						break;

					case 4:	// UPLOAD_ERR_NO_FILE
						$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No file'));
						break;

					case 6:	// UPLOAD_ERR_NO_TMP_DIR 
						$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No tmp directory'));
						break;

					default:
						// No error occured, but was something actually uploaded?
						if ($uploaded_file['size'] == 0)
							$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No file'));
						break;
				}
			}

			if (is_uploaded_file($uploaded_file['tmp_name']))
			{
				$allowed_types = array('image/gif', 'image/jpeg', 'image/pjpeg', 'image/png', 'image/x-png');
				if (!in_array($uploaded_file['type'], $allowed_types))
					$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad type'));

				// Make sure the file isn't too big
				if ($uploaded_file['size'] > $this->config['o_image_group_size'])
					$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Too large').' '.$this->config['o_image_group_size'].' '.$this->lang->t('bytes').'.');

				// Determine type
				switch($uploaded_file['type'])
				{
					case 'image/gif':
						$type = 'gif';
						break;
					case 'image/jpeg':
					case 'image/pjpeg':
						$type = 'jpg';
						break;
					default:
						$type = 'png';
						break;
				}

				// Move the file to the image directory. We do this before checking the width/height to circumvent open_basedir restrictions.
				if (!@move_uploaded_file($uploaded_file['tmp_name'], $image_path.$id.'.tmp'))
					$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Move failed', ' '.$this->config['o_admin_email']));

				// Now check the width/height
				list($width, $height, $file_type,) = getimagesize($image_path.$id.'.tmp');
				if (empty($width) || empty($height) || $width > $this->config['o_image_group_width'] || $height > $this->config['o_image_group_height'])
				{
					@unlink($image_path.$id.'.tmp');
					$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Too wide or high', $this->config['o_image_group_width'], $this->config['o_image_group_height']));
				}
				else if ($file_type == 1 && $uploaded_file['type'] != 'image/gif')	// Prevent dodgy uploads
				{
					@unlink($image_path.$id.'.tmp');
					$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad type'));
				}

				// Delete the old image (if it exists) and put the new one in place
				if ($aura_groups[$id]['g_image'] != '')
					@unlink($image_path.$id.'.'.$aura_groups[$id]['g_image']);

				@rename($image_path.$id.'.tmp', $image_path.$id.'.'.$type);
				$this->registry->get('\Aura\tools\optimise')->compress_image($image_path.$id.'.'.$type);
				@chmod($image_path.$id.'.'.$type, 0644);

				$update = array(
					'g_image' => $type,
				);

				$data = array(
					':id' => $id,
				);

				$this->db->update('groups', $update, 'g_id=:id', $data);
			}
			else
				$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Unknown failure'));

			$this->cache->generate('groups');
			$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_groups']), $this->lang->t('Image upload redirect'));
		}

		$this->template->header['page_title'] = array($this->config['o_board_title'], $this->lang->t('Admin'), $this->lang->t('User groups'));
		$this->template->header['required_fields'] = array('req_file' => $this->lang->t('File'));
		$this->template->header['focus_element'] = array('upload_image', 'req_file');

		$this->template->header = $this->registry->get('\Aura\extensions\hooks')->fire('admin.groups.uploadimage.header', $this->template->header);

		$args = $this->registry->get('\Aura\extensions\hooks')->fire('admin.groups.uploadimage.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('admin/upload_image.tpl');
		$this->template->output($tpl,
			array(
				'admin_menu' => $this->admin->generate_menu('groups'),
				'csrf_token' => $this->registry->get('\Aura\auth\csrf')->generate(config::ADMIN_DIR.'_groups'),
				'form_action' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['upload_image'], array($id)),
				'csrf_token' => $this->registry->get('\Aura\auth\csrf')->generate(config::ADMIN_DIR.'_groups'),
				'size' => $this->lang->t('Size unit B', $this->config['o_image_group_size']),
				'size_unit' => $this->lang->t('Size unit KiB', ceil($this->config['o_image_group_size'] / 1024)),
			)
		);
	}

	protected function remove_group()
	{
		$group_id = isset($_POST['group_to_delete']) ? intval($_POST['group_to_delete']) : intval($_GET['delete_group']);
		if ($group_id < 5)
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		// Make sure we don't remove the default group
		if ($group_id == $this->config['o_default_user_group'])
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Cannot remove default message'));

		$data = array(
			':gid' => $group_id,
		);

		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'users',
				'as' => 'u',
				'on' => 'g.g_id=u.group_id',
			),
		);

		// Check if this group has any members
		$ps = $this->db->join('groups', 'g', $join, 'g.g_title, COUNT(u.id)', $data, 'g.g_id=:gid GROUP BY g.g_id, g_title');

		// If the group doesn't have any members or if we've already selected a group to move the members to
		if (!$ps->rowCount() || isset($_POST['del_group']))
		{
			if (isset($_POST['del_group_comply']) || isset($_POST['del_group']))
			{
				$this->registry->get('\Aura\auth\csrf')->confirm(config::ADMIN_DIR.'_groups');
				if (isset($_POST['del_group']))
				{
					$move_to_group = intval($_POST['move_to_group']);
					$update = array(
						':gid' => $move_to_group,
					);

					$data = array(
						':gid2' => $group_id,
					);

					$this->db->update('users', $update, 'group_id=:gid2', $data);
				}

				$data = array(
					':gid' => $group_id,
				);

				// Delete the group and any forum specific permissions
				$this->db->delete('groups', 'g_id=:gid', $data);
				$this->db->delete('forum_perms', 'group_id=:gid', $data);

				// Don't let users be promoted to this group
				$update = array(
					'g_promote_next_group' => 0,
				);

				$this->db->update('groups', $update, 'g_promote_next_group=:gid', $data);

				$this->cache->generate('groups');
				$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_groups']), $this->lang->t('Group removed redirect'));
			}
			else
			{
				$aura_groups = $this->cache->get('groups');
				$group_title = $aura_groups[$group_id]['g_title'];

				$args = $this->registry->get('\Aura\extensions\hooks')->fire('admin.groups.deletecomply.render');
				$args = (is_array($args) ? $args : array());

				$tpl = $this->template->load('admin/delete_group.tpl');
				$this->template->output($tpl,
					array_merge(
						array(
							'admin_menu' => $this->admin->generate_menu('groups'),
							'form_action' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['del_group'], array($group_id)),
							'csrf_token' => $this->registry->get('\Aura\auth\csrf')->generate(config::ADMIN_DIR.'_groups'),
							'group_id' => $group_id,
							'group_title' => $group_title,
						),
						$args
					)
				);

				exit;
			}
		}

		list($group_title, $group_members) = $ps->fetch(PDO::FETCH_NUM);

		$group_options = array();
		foreach ($aura_groups as $cur_group)
		{
			if ($cur_group['g_id'] != AURA_GUEST && $cur_group['g_id'] != $group_id)
				$group_options[] = array('id' => $cur_group['g_id'], 'selected' => (($cur_group['g_id'] == AURA_MEMBER) ? true : false), 'title' => $cur_group['g_title']);
		}

		$args = $this->registry->get('\Aura\extensions\hooks')->fire('admin.groups.delete.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('admin/move_group.tpl');
		$this->template->output($tpl,
			array_merge(
				array(
					'admin_menu' => $this->admin->generate_menu('groups'),
					'form_action' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['del_group'], array($group_id)),
					'csrf_token' => $this->registry->get('\Aura\auth\csrf')->generate(config::ADMIN_DIR.'_groups'),
					'group_id' => $group_id,
					'group_title' => $group_title,
					'group_members' => $this->functions->forum_number_format($group_members),
					'group_options' => $group_options,
				),
				$args
			)
		);

		exit;
	}

	protected function update_default_group()
	{
		$this->registry->get('\Aura\auth\csrf')->confirm(config::ADMIN_DIR.'_groups');

		$aura_groups = $this->cache->get('groups');
		$group_id = isset($_POST['default_group']) ? intval($_POST['default_group']) : 0;

		// Make sure it's not the admin or guest groups (and that it is actually valid)
		if ($group_id == AURA_ADMIN || $group_id == AURA_GUEST || !isset($aura_groups[$group_id]))
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		// Make sure it's not a moderator group
		if ($aura_groups[$group_id]['g_moderator'] != 0)
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		$update = array(
			'conf_value' => $group_id,
		);

		$data = array(
			':conf_name' => 'o_default_user_group',
		);

		$this->db->update('config', $update, 'conf_name=:conf_name', $data);

		// Regenerate the config cache
		$this->cache->generate('config', array(array('o_default_user_group' => $group_id)));

		$this->registry->get('\Aura\extensions\hooks')->fire('admin.groups.defaultgroup.beforeredirect');
		$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_groups']), $this->lang->t('Default group redirect'));		
	}

	protected function add_edit_group()
	{
		$this->registry->get('\Aura\auth\csrf')->confirm(config::ADMIN_DIR.'_groups');

		// Is this the original admin group? (special rules apply)
		$is_admin_group = (isset($_POST['group_id']) && $_POST['group_id'] == AURA_ADMIN) ? true : false;

		$title = isset($_POST['req_title']) ? utf8_trim($_POST['req_title']) : '';
		$user_title = isset($_POST['user_title']) ? utf8_trim($_POST['user_title']) : '';
		$group_colour = isset($_POST['group_colour']) ? utf8_trim($_POST['group_colour']) : '';

		$promote_min_posts = isset($_POST['promote_min_posts']) ? intval($_POST['promote_min_posts']) : 0;
		$promote_next_group = (isset($_POST['promote_next_group']) && isset($aura_groups[$_POST['promote_next_group']]) && !in_array($_POST['promote_next_group'], array(AURA_ADMIN, AURA_GUEST)) && $aura_groups[$_POST['promote_next_group']]['g_admin'] != '1' && (!isset($_POST['group_id']) || $_POST['promote_next_group'] != $_POST['group_id'])) ? $_POST['promote_next_group'] : 0;

		$moderator = isset($_POST['moderator']) && $_POST['moderator'] == '1' ? '1' : '0';
		$global_moderator = $moderator == '1' && isset($_POST['global_moderator']) && $_POST['global_moderator'] == '1' ? '1' : '0';
		$mod_cp = $moderator == '1' && isset($_POST['mod_cp']) && $_POST['mod_cp'] == '1' ? '1' : '0';
		$admin = $moderator == '1' && isset($_POST['admin']) && $_POST['admin'] == '1' ? '1' : '0';
		$mod_edit_users = $moderator == '1' && isset($_POST['mod_edit_users']) && $_POST['mod_edit_users'] == '1' ? '1' : '0';
		$mod_rename_users = $moderator == '1' && isset($_POST['mod_rename_users']) && $_POST['mod_rename_users'] == '1' ? '1' : '0';
		$mod_change_passwords = $moderator == '1' && isset($_POST['mod_change_passwords']) && $_POST['mod_change_passwords'] == '1' ? '1' : '0';
		$mod_ban_users = $moderator == '1' && isset($_POST['mod_ban_users']) && $_POST['mod_ban_users'] == '1' ? '1' : '0';
		$mod_warn_users = $moderator == '1' && isset($_POST['mod_warn_users']) && $_POST['mod_warn_users'] == '1' ? '1' : '0';
		$mod_promote_users = $moderator == '1' && isset($_POST['mod_promote_users']) && $_POST['mod_promote_users'] == '1' ? '1' : '0';
		$read_board = isset($_POST['read_board']) ? intval($_POST['read_board']) : '1';
		$view_users = (isset($_POST['view_users']) && $_POST['view_users'] == '1') || $is_admin_group ? '1' : '0';
		$post_replies = isset($_POST['post_replies']) ? intval($_POST['post_replies']) : '1';
		$post_polls = isset($_POST['post_polls']) ? intval($_POST['post_polls']) : '1';
		$edit_polls = isset($_POST['edit_polls']) ? intval($_POST['edit_polls']) : '1';
		$moderate_posts = isset($_POST['moderate_posts']) ? intval($_POST['moderate_posts']) : '0';
		$post_topics = isset($_POST['post_topics']) ? intval($_POST['post_topics']) : '1';
		$robot_test = isset($_POST['robot_test']) ? intval($_POST['robot_test']) : '0';
		$attach_files = isset($_POST['attach_files']) ? intval($_POST['attach_files']) : '0';
		$max_attachments = isset($_POST['max_attachments']) ? intval($_POST['max_attachments']) : '0';
		$max_size = isset($_POST['max_size']) ? intval($_POST['max_size']) : '0';
		$edit_posts = isset($_POST['edit_posts']) ? intval($_POST['edit_posts']) : ($is_admin_group) ? '1' : '0';
		$edit_subject = isset($_POST['edit_subject']) ? intval($_POST['edit_subject']) : ($is_admin_group) ? '1' : '0';
		$edit_pm_subject = isset($_POST['edit_pm_subject']) ? intval($_POST['edit_pm_subject']) : ($is_admin_group) ? '1' : '0';
		$delete_posts = isset($_POST['delete_posts']) ? intval($_POST['delete_posts']) : ($is_admin_group) ? '1' : '0';
		$delete_topics = isset($_POST['delete_topics']) ? intval($_POST['delete_topics']) : ($is_admin_group) ? '1' : '0';
		$deledit_interval = isset($_POST['deledit_interval']) ? intval($_POST['deledit_interval']) : 0;
		$post_links = isset($_POST['post_links']) ? intval($_POST['post_links']) : '1';
		$subject_links = isset($_POST['subject_links']) ? intval($_POST['subject_links']) : '1';
		$post_images = isset($_POST['post_images']) ? intval($_POST['post_images']) : '1';
		$set_title = isset($_POST['set_title']) ? intval($_POST['set_title']) : ($is_admin_group) ? '1' : '0';
		$search = isset($_POST['search']) ? intval($_POST['search']) : '1';
		$search_users = isset($_POST['search_users']) ? intval($_POST['search_users']) : '1';
		$send_email = (isset($_POST['send_email']) && $_POST['send_email'] == '1') || $is_admin_group ? '1' : '0';
		$post_flood = (isset($_POST['post_flood']) && $_POST['post_flood'] >= 0) ? intval($_POST['post_flood']) : '0';
		$search_flood = (isset($_POST['search_flood']) && $_POST['search_flood'] >= 0) ? intval($_POST['search_flood']) : '0';
		$email_flood = (isset($_POST['email_flood']) && $_POST['email_flood'] >= 0) ? intval($_POST['email_flood']) : '0';
		$report_flood = (isset($_POST['report_flood']) && $_POST['report_flood'] >= 0) ? intval($_POST['report_flood']) : '0';
		$reputation = isset($_POST['rep_enabled']) && intval($_POST['rep_enabled']) == '1' || $is_admin_group ? '1' : '0';
		$reputation_max = isset($_POST['g_rep_plus']) ? intval($_POST['g_rep_plus']) : '0';
		$reputation_min = isset($_POST['g_rep_minus']) ? intval($_POST['g_rep_minus']) : '0';
		$reputation_interval = isset($_POST['g_rep_interval']) ? intval($_POST['g_rep_interval']) : '0';
		$use_pm = isset($_POST['use_pm']) && $_POST['use_pm'] == '1' || $is_admin_group ? '1' : '0';
		$pm_limit = isset($_POST['pm_limit']) ? intval($_POST['pm_limit']) : '0';
		$folder_limit = isset($_POST['pm_folder_limit']) ? intval($_POST['pm_folder_limit']) : '0';

		if ($title == '')
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Must enter title message'));

		if (!empty($group_colour) && !preg_match('/^#([a-fA-F0-9]){6}$/', $group_colour))
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Invalid colour message'));
		
		$max_size = ($max_size > $this->config['o_max_upload_size']) ? $this->config['o_max_upload_size'] : $max_size;
		$user_title = ($user_title != '') ? $user_title : null;

		$group_data = array(
			'g_title'				=>	$title,
			'g_user_title'			=>	$user_title,
			'g_promote_min_posts'	=>	$promote_min_posts,
			'g_promote_next_group'	=>	$promote_next_group,
			'g_moderator'			=>	$moderator,
			'g_mod_cp'				=>	$mod_cp,
			'g_admin'				=>	$admin,
			'g_global_moderator'	=>	$global_moderator,
			'g_mod_edit_users'		=>	$mod_edit_users,
			'g_mod_rename_users'	=>	$mod_rename_users,
			'g_mod_change_passwords'=>	$mod_change_passwords,
			'g_mod_warn_users'		=>	$mod_warn_users,
			'g_mod_ban_users'		=>	$mod_ban_users,
			'g_mod_promote_users'	=>	$mod_promote_users,
			'g_read_board'			=>	$read_board,
			'g_view_users'			=>	$view_users,
			'g_post_replies'		=>	$post_replies,
			'g_post_polls'			=>	$post_polls,
			'g_edit_polls'			=>	$edit_polls,
			'g_post_topics'			=>	$post_topics,
			'g_edit_posts'			=>	$edit_posts,
			'g_edit_subject'		=>	$edit_subject,
			'g_edit_pm_subject'		=>	$edit_pm_subject,
			'g_robot_test'			=>	$robot_test,
			'g_delete_posts'		=>	$delete_posts,
			'g_delete_topics'		=>	$delete_topics,
			'g_deledit_interval'	=>	$deledit_interval,
			'g_post_links'			=>	$post_links,
			'g_subject_links'		=>	$subject_links,
			'g_post_images'			=>	$post_images,
			'g_set_title'			=>	$set_title,
			'g_search'				=>	$search,
			'g_search_users'		=>	$search_users,
			'g_send_email'			=>	$send_email,
			'g_post_flood'			=>	$post_flood,
			'g_search_flood'		=>	$search_flood,
			'g_email_flood'			=>	$email_flood,
			'g_report_flood'		=>	$report_flood,
			'g_rep_enabled'			=>	$reputation,
			'g_rep_interval'		=>	$reputation_interval,
			'g_rep_plus'			=>	$reputation_max,
			'g_rep_minus'			=>	$reputation_min,
			'g_colour'				=>	$group_colour,
			'g_moderate_posts'		=>	$moderate_posts,
			'g_attach_files'		=>	$attach_files,
			'g_max_attachments'		=>	$max_attachments,
			'g_max_size'			=>	$max_size,
			'g_use_pm'				=>	$use_pm,
			'g_pm_limit'			=>	$pm_limit,
			'g_pm_folder_limit'		=>	$folder_limit,
		);

		if ($_POST['mode'] == 'add')
		{
			$data = array(
				':title' => $title,
			);

			$ps = $this->db->select('groups', 1, $data, 'g_title=:title');
			if ($ps->rowCount())
				$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Title already exists message', $title));

			$this->db->insert('groups', $group_data);
			$new_group_id = $this->db->lastInsertId($this->db->prefix.'groups');

			$data = array(
				':id' => isset($_POST['base_group']) ? intval($_POST['base_group']) : 0,
			);

			// Now let's copy the forum specific permissions from the group which this group is based on
			$ps = $this->db->select('forum_perms', 'forum_id, read_forum, post_replies, post_topics', $data, 'group_id=:id');

			foreach ($ps as $cur_forum_perm)
			{
				$insert = array(
					'group_id'	=>	$new_group_id,
					'forum_id'	=>	$cur_forum_perm['forum_id'],
					'read_forum'	=>	$cur_forum_perm['read_forum'],
					'post_replies'	=>	$cur_forum_perm['post_replies'],
					'post_topics'	=>	$cur_forum_perm['post_topics'],
				);

				$this->db->insert('forum_perms', $insert);
			}

			$this->registry->get('\Aura\extensions\hooks')->fire('admin.groups.addgroup');
		}
		else
		{
			$group_id = isset($_POST['group_id']) ? intval($_POST['group_id']) : 0;
			$data = array(
				':g_title'	=>	$title,
				':g_id'		=>	$group_id,
			);

			$ps = $this->db->select('groups', 1, $data, 'g_title=:g_title AND g_id!=:g_id');
			if ($ps->rowCount())
				$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Title already exists message', $title));

			$data = array(
				':id'	=>	$group_id,
			);
			
			$this->db->update('groups', $group_data, 'g_id=:id', $data);

			// Promote all users who would be promoted to this group on their next post
			if ($promote_next_group)
			{
				$update = array(
					'group_id'	=>	$promote_next_group,
				);
				
				$data = array(
					':num_posts' => $promote_min_posts,
					':gid' => $group_id,
				);
		
				$this->db->update('users', $update, 'group_id=:gid AND num_posts>=:num_posts', $data);
			}

			$aura_groups = $this->cache->get('groups');
			if (utf8_strtolower($title) != utf8_strtolower($aura_groups[$group_id]['g_title'])) // We need to update the moderator lists if the name has changed, in case we were on one of them
			{
				$data = array(
					':id' => $group_id,
				);

				$ps = $this->db->select('moderators', 1,  $data, 'group_id=:id');
				if ($ps->rowCount())
				{
					$update = array(
						'group_title' => $title,
					);

					$data = array(
						':id' => $group_id,
					);

					$this->db->update('moderators', $update, 'group_id=:id', $data);
					$this->cache->generate('moderators');
				}
			}

			$this->registry->get('\Aura\extensions\hooks')->fire('admin.groups.editgroup');
		}

		// Regenerate some caches ...
		$this->cache->generate('groups');
		$this->cache->generate('config', array($this->config));

		$group_id = $_POST['mode'] == 'add' ? $new_group_id : intval($_POST['group_id']);
		$this->cache->generate('quickjump', array($group_id, $read_board));

		$this->registry->get('\Aura\extensions\hooks')->fire('admin.groups.modify.beforeredirect');

		$redirect_msg = ($_POST['mode'] == 'edit') ? $this->lang->t('Group edited redirect') : $this->lang->t('Group added redirect');
		$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_groups']), $redirect_msg);		
	}

	protected function edit_group()
	{
		$aura_groups = $this->cache->get('groups');

		if (isset($_POST['add_group']))
		{
			$group_id = isset($_POST['base_group']) ? intval($_POST['base_group']) : '';
			$group = $aura_groups[$group_id];

			$mode = 'add';
		}
		else // We are editing a group
		{
			$group_id = intval($_GET['edit_group']);
			if ($group_id < 1 || !isset($aura_groups[$group_id]))
				$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

			$group = $aura_groups[$group_id];
			$mode = 'edit';
		}

		$this->template->header['required_fields'] = array('req_title' => $this->lang->t('Group title label'));
		$this->template->header['focus_element'] = array('groups2', 'req_title');

		$group_options = array();
		foreach ($aura_groups as $cur_group)
		{
			if (($cur_group['g_id'] != $group['g_id'] || $mode == 'add') && $cur_group['g_id'] != AURA_ADMIN && $group['g_admin'] != '1' && $cur_group['g_id'] != AURA_GUEST)
				$group_options[] = array('id' => $cur_group['g_id'], 'title' => $cur_group['g_title']);
		}
		
		$img_size = array();
		if ($mode == 'edit' && $group['g_image'] != '')
			$img_size = @getimagesize($this->config['o_image_group_path'].'/'.$group_id.'.'.$group['g_image']);

		$args = $this->registry->get('\Aura\extensions\hooks')->fire('admin.groups.editgroup.render');
		$args = (is_array($args) ? $args : array());

		$csrf_token = $this->registry->get('\Aura\auth\csrf')->generate(config::ADMIN_DIR.'_groups');
		$tpl = $this->template->load('admin/edit_group.tpl');
		$this->template->output($tpl,
			array_merge(
				array(
					'admin_menu' => $this->admin->generate_menu('groups'),
					'form_action' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_groups']),
					'csrf_token' => $csrf_token,
					'mode' => $mode,
					'group_id' => $group_id,
					'group' => $group,
					'member_lang' => ($group['g_id'] != AURA_GUEST ? $this->lang->t('Member') : $this->lang->t('Guest')),
					'is_not_admin_group' => $group['g_id'] != AURA_ADMIN ? true : false,
					'robots_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_robots']),
					'is_not_guest_group' => ($group['g_id'] != AURA_GUEST) ? true : false,
					'group_options' => $group_options,
					'upload_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['upload_image'], array($group_id)),
					'img_size' => $img_size,
					'delete_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['delete_image'], array($group_id, $csrf_token)),
					'image_dir' => ($this->config['o_image_group_dir'] != '') ? $this->config['o_image_group_dir'] : $this->functions->get_base_url().'/'.$this->config['o_image_group_path'].'/',
				),
				$args
			)
		);

		exit;
	}

	/**
	 * Fetch all information for display on the index
	 */
	protected function fetch_group_information()
	{
		$aura_groups = $this->cache->get('groups');
		$group_options = $new_options = $default_options = array();
		foreach ($aura_groups as $cur_group)
		{
			if ($cur_group['g_id'] != AURA_ADMIN && $cur_group['g_id'] != AURA_GUEST)
				$new_options[] = array('id' => $cur_group['g_id'], 'title' => $cur_group['g_title']);

			if ($cur_group['g_id'] > AURA_GUEST && $cur_group['g_moderator'] == 0)
				$default_options[] = array('id' => $cur_group['g_id'], 'title' => $cur_group['g_title']);

			$group_options[] = array(
				'edit_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['edit_group'], $cur_group['g_id']),
				'delete_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['del_group'], $cur_group['g_id']),
				'title' => $cur_group['g_title'],
				'can_delete' => ($cur_group['g_id'] > AURA_MEMBER ? true : false),
			);
		}

		return array($group_options, $default_options, $new_options);
	}

	/**
	 * Configure a few things which we commonly use
	 */
	protected function configure_page()
	{
		$this->admin = $this->registry->get('\Aura\admin\common');

		if (!$this->user['is_admin'])
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		$this->admin->check_user('admin_groups');

		$this->registry->get('\Aura\auth\http_auth')->check_authentication();

		// Load the admin-groups language file
		$this->lang->load('admin_groups');

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Admin'), $this->lang->t('User groups')),
			'active_page' => 'admin',
			'admin_console' => true,
		);

		$this->template->header = $this->registry->get('\Aura\extensions\hooks')->fire('admin.groups.header', $this->template->header);
		$this->template->footer = array(
			'admin_console' => true,
		);

		$this->template->footer = $this->registry->get('\Aura\extensions\hooks')->fire('admin.groups.footer', $this->template->footer);
	}
}