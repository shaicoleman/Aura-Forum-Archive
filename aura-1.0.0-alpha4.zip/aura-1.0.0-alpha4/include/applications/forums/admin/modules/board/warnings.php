<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class warnings_controller extends base_controller
{
	/**
	 * Main app entry point
	 */
	public function execute()
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('admin.warnings.immediate');
		$this->configure_page();

		// Configure our event handlers
		if (isset($_POST['form_sent']))
			$this->configure_warnings();
		else if (isset($_POST['add_type']))
			$this->add_warning_type();
		else if (isset($_POST['add_level']))
			$this->add_warning_level();

		list($types, $levels) = $this->fetch_warning_types();

		$args = $this->registry->get('\Aura\extensions\hooks')->fire('admin.warnings.execute.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('admin/warnings.tpl');
		$this->template->output($tpl,
			array_merge(
				array(
					'admin_menu' => $this->admin->generate_menu('warnings'),
					'form_action' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_warnings']),
					'types' => $types,
					'levels' => $levels,
				),
				$args
			)
		);
	}

	/**
	 * Edit a warning level
	 */
	public function edit_level()
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('admin.warnings.edit.level.immediate');
		$this->configure_page();

		$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
		$data = array(
			':id' => $id,
		);

		// Fetch warning information
		$ps = $this->db->select('warning_levels', 'id, points, message, period', $data, 'id=:id');
		if (!$ps->rowCount())
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'));

		$warning_level = $ps->fetch();

		// Get expiration time and unit
		$expiration = explode(' ', $this->registry->get('\Aura\aura_time')->format_expiration_time($warning_level['period']));
		if ($expiration[0] == 'Never')
		{
			$expiration[0] = '';
			$expiration[1] = 'Never';
		}

		$args = $this->registry->get('\Aura\extensions\hooks')->fire('admin.warnings.edit.level.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('admin/edit_warning_level.tpl');
		$this->template->output($tpl,
			array_merge(
				array(
					'admin_menu' => $this->admin->generate_menu('warnings'),
					'form_action' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_warnings']),
					'csrf_token' => $this->registry->get('\Aura\auth\csrf')->generate('admin_warnings'),
					'expiration' => $expiration,
					'warning_level' => $warning_level,
				),
				$args
			)
		);
	}

	/**
	 * Edit a warning type
	 */
	public function edit_type()
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('admin.warnings.edit.type.immediate');
		$this->configure_page();

		$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
		if ($id < 1)
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'));

		$data = array(
			':id'	=>	$id,
		);

		// Get information of the warning
		$ps = $this->db->select('warning_types', 'id, title, description, points, expiration_time', $data, 'id=:id');
		if (!$ps->rowCount())
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'));

		$warning_type = $ps->fetch();

		// Get expiration time and unit
		$expiration = explode(' ', $this->registry->get('\Aura\aura_time')->format_expiration_time($warning_type['expiration_time']));
		if ($expiration[0] == 'Never')
		{
			$expiration[0] = '';
			$expiration[1] = 'Never';
		}

		$args = $this->registry->get('\Aura\extensions\hooks')->fire('admin.warnings.edit.type.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('admin/edit_warning_type.tpl');
		$this->template->output($tpl,
			array_merge(
				array(
					'admin_menu' => $this->admin->generate_menu('warnings'),
					'form_action' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_warnings']),
					'csrf_token' => $this->registry->get('\Aura\auth\csrf')->generate('admin_warnings'),
					'warning_type' => $warning_type,
					'expiration' => $expiration,
				),
				$args
			)
		);
	}

	/**
	 * Edit a warning type
	 */
	public function delete_level()
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('admin.warnings.delete.level.immediate');
		$this->configure_page();

		$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
		if ($id < 1)
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'));

		if (isset($_POST['del_level_comply']))
		{
			$this->registry->get('\Aura\auth\csrf')->confirm('admin_warnings');
			$data = array(
				':id' => $id,
			);

			// Delete the warning level
			$this->db->delete('warning_levels', 'id=:id', $data);

			$this->registry->get('\Aura\extensions\hooks')->fire('admin.warnings.delete.level.beforeredirect');
			$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_warnings']), $this->lang->t('Level del redirect'));
		}

		$args = $this->registry->get('\Aura\extensions\hooks')->fire('admin.warnings.delete.level.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('admin/delete_warning_level.tpl');
		$this->template->output($tpl,
			array_merge(
				array(
					'admin_menu' => $this->admin->generate_menu('warnings'),
					'form_action' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['warning_del_level'], array($id)),
					'csrf_token' => $this->registry->get('\Aura\auth\csrf')->generate('admin_warnings'),
				),
				$args
			)
		);
	}

	/**
	 * Delete a warning type
	 */
	public function delete_type()
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('admin.warnings.delete.type.immediate');
		$this->configure_page();

		$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
		if ($id < 1)
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'));

		if (isset($_POST['del_type_comply']))
		{
			$this->registry->get('\Aura\auth\csrf')->confirm('admin_warnings');
			$data = array(
				':id' => $id,
			);

			// Delete the warning type
			$this->db->delete('warning_types', 'id=:id', $data);

			$this->registry->get('\Aura\extensions\hooks')->fire('admin.warnings.delete.type.beforeredirect');
			$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_warnings']), $this->lang->t('Type delete redirect'));
		}
		else // If the user hasn't confirmed the delete
		{
			$data = array(
				':id' => $id,
			);

			$ps = $this->db->select('warning_types', 'title', $data, 'id=:id');
			if (!$ps->rowCount())
				$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad resuqest'));

			$warning_type = $ps->fetchColumn();

			$args = $this->registry->get('\Aura\extensions\hooks')->fire('admin.warnings.delete.type.render');
			$args = (is_array($args) ? $args : array());

			$tpl = $this->template->load('admin/delete_warning_type.tpl');
			$this->template->output($tpl,
				array_merge(
					array(
						'admin_menu' => $this->admin->generate_menu('warnings'),
						'form_action' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['warning_del_type'], array($id)),
						'csrf_token' => $this->registry->get('\Aura\auth\csrf')->generate('admin_warnings'),
						'warning_type' => $warning_type,
					),
					$args
				)
			);
		}
	}

	/**
	 * We want to setup a new warning level
	 */
	protected function add_warning_level()
	{
		$args = $this->registry->get('\Aura\extensions\hooks')->fire('admin.warnings.add.level.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('admin/add_warning_level.tpl');
		$this->template->output($tpl,
			array_merge(
				array(
					'admin_menu' => $this->admin->generate_menu('warnings'),
					'form_action' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_warnings']),
					'csrf_token' => $this->registry->get('\Aura\auth\csrf')->generate('admin_warnings'),
				),
				$args
			)
		);
	}

	/**
	 * We want to setup a new warning type
	 */
	protected function add_warning_type()
	{
		$args = $this->registry->get('\Aura\extensions\hooks')->fire('admin.warnings.add.type.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('admin/add_warning_type.tpl');
		$this->template->output($tpl,
			array_merge(
				array(
					'admin_menu' => $this->admin->generate_menu('warnings'),
					'form_action' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_warnings']),
					'csrf_token' => $this->registry->get('\Aura\auth\csrf')->generate('admin_warnings'),
				),
				$args
			)
		);
	}

	/**
	 * We want to submit/update information to the database
	 */
	protected function configure_warnings()
	{
		$this->registry->get('\Aura\auth\csrf')->confirm('admin_warnings');

		$action = isset($_POST['action']) ? utf8_trim($_POST['action']) : '';
		$id = isset($_POST['id']) ? intval($_POST['id']) : 0;
		
		if ($action == '')
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'));

		if ($action == 'types')
		{
			if (empty($_POST['warning_title']))
				$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No title'));

			// Determine expiration time
			$expiration_time = $this->registry->get('\Aura\aura_time')->get_expiration_time($_POST['expiration_time'], $_POST['expiration_unit']);
			
			$warning_title = isset($_POST['warning_title']) ? utf8_trim($_POST['warning_title']) : '';
			$warning_description = isset($_POST['warning_description']) ? utf8_trim($_POST['warning_description']) : '';
			$points = isset($_POST['warning_points']) ? intval($_POST['warning_points']) : 0;

			if (aura_strlen($warning_title) < 1)
				$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No title'));
			else if (aura_strlen($warning_title) > 70)
				$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Title too long'));

			if ($warning_description == '')
				$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Must enter description'));
			else if (aura_strlen($warning_description) > AURA_MAX_POSTSIZE)
				$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Must enter description', forum_number_format(AURA_MAX_POSTSIZE)));
				
			$update = array(
				'title'	=> $warning_title,
				'description' => $warning_description,
				'points' => $points,
				'expiration_time' => $expiration_time,
			);

			$this->registry->get('\Aura\extensions\hooks')->fire('admin.warnings.addupdate.type');
			if (isset($_POST['id']) && $id > 0) // Then we're editing
			{
				$data = array(
					':id' => $id,
				);

				$ps = $this->db->select('warning_types', 'id, title, description, points, expiration_time', $data, 'id=:id');
				if ($ps->rowCount())
				{
					$warning_type = $ps->fetch();
					$data = array(
						':id' => $warning_type['id'],
					);
					
					$this->db->update('warning_types', $update, 'id=:id', $data);
					$redirect_msg = $this->lang->t('Type updated redirect');
				}
			}
			else // We're adding a new type
			{
				$this->db->insert('warning_types', $update);
				$redirect_msg = $this->lang->t('Type added redirect');
			}
		}
		else // We're adding/editing warning levels
		{
			$warning_title = isset($_POST['warning_title']) ? utf8_trim($_POST['warning_title']) : '';
			$warning_points = isset($_POST['warning_points']) ? intval($_POST['warning_points']) : 0;

			if ($warning_title == '')
				$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No title'));

			// Determine expiration time
			$expiration_time = $this->registry->get('\Aura\aura_time')->get_expiration_time($_POST['expiration_time'], $_POST['expiration_unit']);

			$update = array(
				'points' => $warning_points,
				'message' => $warning_title,
				'period' => $expiration_time,
			);

			$this->registry->get('\Aura\extensions\hooks')->fire('admin.warnings.addupdate.level');
			if (isset($_POST['id']) && $id > 0)
			{
				$data = array(
					':id'	=>	$id,
				);

				$this->db->update('warning_levels', $update, 'id=:id', $data);
				$redirect_msg = $this->lang->t('Level update redirect');
			}
			else
			{
				$this->db->insert('warning_levels', $update);
				$redirect_msg = $this->lang->t('Level added redirect');
			}
		}

		$this->registry->get('\Aura\extensions\hooks')->fire('admin.warnings.addupdate.beforeredirect');
		$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_warnings']), $redirect_msg);
	}

	/**
	 * Configure a few things which we commonly use
	 */
	protected function configure_page()
	{
		$this->admin = $this->registry->get('\Aura\admin\common');

		if (!$this->user['is_admin'])
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		$this->admin->check_user('admin_warnings');

		$this->registry->get('\Aura\auth\http_auth')->check_authentication();

		// Load the admin-warnings language file
		$this->lang->load('admin_warnings');

		if ($this->user['g_read_board'] == '0')
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No view'), false, '403 Forbidden');

		if ($this->config['o_warnings'] == '0')
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Warnings disabled'));

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Admin'), $this->lang->t('Warnings')),
			'active_page' => 'admin',
			'admin_console' => true,
		);

		$this->template->header = $this->registry->get('\Aura\extensions\hooks')->fire('admin.warnings.header', $this->template->header);
		$this->template->footer = array(
			'admin_console' => true,
		);

		$this->template->footer = $this->registry->get('\Aura\extensions\hooks')->fire('admin.warnings.footer', $this->template->footer);
	}

	/**
	 * Fetch the warnings types & levels to display
	 */
	protected function fetch_warning_types()
	{
		$types = array();
		$ps = $this->db->select('warning_types', 'id, title, description, points, expiration_time', array(), '', 'points, id');
		foreach ($ps as $list_types)
		{
			$expiration = explode(' ', $this->registry->get('\Aura\aura_time')->format_expiration_time($list_types['expiration_time']));
			if ($expiration[0] == 'Never')
			{
				$expiration[0] = '';
				$expiration[1] = 'Never';
			}

			$types[] = array(
				'edit_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['warning_edit_type'], array($list_types['id'])),
				'delete_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['warning_del_type'], array($list_types['id'])),
				'list_types' => $list_types,
				'expiration' => $expiration,
			);
		}

		$types = $this->registry->get('\Aura\extensions\hooks')->fire('admin.warnings.fetch.types', $types);

		$levels = array();
		$ps = $this->db->select('warning_levels', 'id, points, period', array(), '', 'points, id');
		foreach ($ps as $list_levels)
		{
			if ($list_levels['period'] == '0')
				$ban_title = $this->lang->t('Permanent ban');
			else
			{
				$expiration = explode(' ', $this->registry->get('\Aura\aura_time')->format_expiration_time($list_levels['period']));
				if ($expiration[0] == 'Never')
				{
					$expiration[0] = '';
					$expiration[1] = 'Never';
				}

				$ban_title = $this->lang->t('Temporary ban', $expiration[0], $expiration[1]);
			}

			$levels[] = array(
				'edit_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['warning_edit_level'], array($list_levels['id'])),
				'delete_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['warning_del_level'], array($list_levels['id'])),
				'points' => $list_levels['points'],
				'ban_title' => $ban_title,
			);
		}

		$levels = $this->registry->get('\Aura\extensions\hooks')->fire('admin.warnings.fetch.levels', $levels);

		return array($types, $levels);
	}
}