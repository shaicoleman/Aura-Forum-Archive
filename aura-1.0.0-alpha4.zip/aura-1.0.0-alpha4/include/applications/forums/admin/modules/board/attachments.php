<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class attachments_controller extends base_controller
{
	/**
	 * Main app entry point, we display the attachments
	 */
	public function execute()
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('admin.attachments.immediate');

		$admin = $this->registry->get('\Aura\admin\common');

		if (!$this->user['is_admin'])
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		$admin->check_user('admin_attachments');

		$this->registry->get('\Aura\auth\http_auth')->check_authentication();

		// Load the admin-attachments language file
		$this->lang->load('admin_attachments');

		if ($this->config['o_attachments'] == '0')
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'));

		if (isset($_POST['delete_attachment']))
			$this->delete_attachment();
		elseif (isset($_POST['delete_orphans']))
			$this->delete_orphans();

		$start = (isset($_POST['start'])) ? intval($_POST['start']) : 0;
		$limit = (isset($_POST['number'])) ? intval($_POST['number']) : 50;
		$increase = (isset($_POST['auto_increase']) && $_POST['auto_increase'] == '1') ? $start + $limit : $start;
		$direction = (isset($_POST['direction']) && $_POST['direction'] == '1') ? 'ASC' : 'DESC';
		$order = isset($_POST['order']) ? intval($_POST['order']) : 0;

		$attachments = $this->fetch_attachments($start, $limit, $increase, $direction, $order);

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Admin'), $this->lang->t('Attachments')),
			'active_page' => 'admin',
			'admin_console' => true,
		);

		$this->template->header = $this->registry->get('\Aura\extensions\hooks')->fire('admin.attachments.header', $this->template->header);
		$this->template->footer = array(
			'admin_console' => true,
		);

		$this->template->footer = $this->registry->get('\Aura\extensions\hooks')->fire('admin.attachments.footer', $this->template->footer);
		$args = $this->registry->get('\Aura\extensions\hooks')->fire('admin.attachments.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('admin/attachments.tpl');
		$this->template->output($tpl,
			array(
				'admin_menu' => $admin->generate_menu('attachments'),
				'form_action' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_attachments']),
				'csrf_token' => $this->registry->get('\Aura\auth\csrf')->generate('admin_attachments'),
				'increase' => $increase,
				'start' => $start,
				'limit' => $limit,
				'order' => $order,
				'direction' => $direction,
				'attachments' => $attachments,
			)
		);
	}

	/**
	 * Delete an attachment from the forum
	 */
	protected function delete_attachment()
	{
		$this->registry->get('\Aura\auth\csrf')->confirm('admin_attachments');

		$id = intval(key($_POST['delete_attachment']));

		if (!$this->registry->get('\Aura\topics\attachment')->delete_attachment($id))
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Unable to delete attachment'));

		$this->registry->get('\Aura\extensions\hooks')->fire('admin.attachments.delete.beforeredirect');
		$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_attachments']), $this->lang->t('Attachment del redirect'));
	}

	/**
	 * Delete orphan attachments on the forum
	 */
	protected function delete_orphans()
	{
		$this->registry->get('\Aura\auth\csrf')->confirm('admin_attachments');
		$join = array(
			array(
				'type' => 'LEFT',
				'table' => 'posts',
				'as' => 'p',
				'on' => 'p.id=a.post_id',
			),
		);

		$ps = $this->db->join('attachments', 'a', $join, 'a.id', array(), 'p.id IS NULL');
		if (!$ps->rowCount())
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No orphans'));

		$i = 0;
		$ps->setFetchMode(PDO::FETCH_COLUMN, 0);
		foreach ($ps as $attachment)
		{
			if (!delete_attachment($attachment))
				continue;
			else
				$i++;
		}

		$this->registry->get('\Aura\extensions\hooks')->fire('admin.attachments.deleteorphans');
		$this->registry->get('\Aura\handlers\message')->show($this->lang->t('X orphans deleted', array($i)));
	}

	/**
	 * Here, we fetch the attachments and sort them accordingly
	 */
	protected function fetch_attachments($start, $limit, $increase, $direction, $order)
	{
		switch ($order)
		{
			case 1:
				$order = 'a.downloads';
				break;
			case 2:
				$order = 'a.size';
				break;
			case 3:
				$order = 'a.downloads*a.size';
				break;
			case 0:
			default:
				$order = 'a.id';
				break;
		}

		$data = array(
			':start' =>	$start,
			':limit' =>	$limit,
		);

		$join = array(
			array(
				'type' => 'LEFT',
				'table' => 'users',
				'as' => 'u',
				'on' => 'u.id=a.owner',
			),
		);

		$attachments = array();
		$ps = $this->db->join('attachments', 'a', $join, 'a.id, a.owner, a.post_id, a.filename, a.extension, a.size, a.downloads, u.username, u.group_id', $data, '', $order.' '.$direction.' LIMIT :start, :limit');
		foreach ($ps as $cur_item)
		{
			$attachments[] = array(
				'icon' => $this->registry->get('\Aura\topics\attachment')->attach_icon($cur_item['extension']),
				'link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['attachment'], array($cur_item['id'])),
				'name' => $cur_item['filename'],
				'username' => $this->functions->colourise_group($cur_item['username'], $cur_item['group_id'], $cur_item['owner']),
				'post_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['post'], array($cur_item['post_id'])),
				'post_id' => $cur_item['post_id'],
				'size' => $this->functions->file_size($cur_item['size']),
				'downloads' => $this->functions->forum_number_format($cur_item['downloads']),
				'transfer' => $this->functions->file_size($cur_item['size'] * $cur_item['downloads']),
				'id' => $cur_item['id'],
			);
		}

		$attachments = $this->registry->get('\Aura\extensions\hooks')->fire('admin.attachments.fetchattachments', $attachments);
		return $attachments;
	}
}