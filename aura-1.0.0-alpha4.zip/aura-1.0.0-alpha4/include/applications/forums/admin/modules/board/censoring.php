<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class censoring_controller extends base_controller
{
	/**
	 * Main class entry point
	 */
	public function execute()
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('admin.censoring.immediate');
		$admin = $this->registry->get('\Aura\admin\common');

		if (!$this->user['is_admin'])
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		$admin->check_user('admin_censoring');

		$this->registry->get('\Aura\auth\http_auth')->check_authentication();

		// Load the admin-censoring language file
		$this->lang->load('admin_censoring');

		// Set up our post handlers
		if (isset($_POST['add_word']))
			$this->add_word();
		else if (isset($_POST['update'])) // Update a censor word
			$this->update_word();
		else if (isset($_POST['remove'])) // Remove a censor word
			$this->delete_word();

		$words = array();
		$ps = $this->db->select('censoring', 'id, search_for, replace_with', array(), '', 'id');
		foreach ($ps as $cur_word)
			$words[] = array(
				'id' => $cur_word['id'],
				'search_for' => $cur_word['search_for'],
				'replace_with' => $cur_word['replace_with'],
			);

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Admin'), $this->lang->t('Censoring')),
			'focus_element' => array('censoring', 'new_search_for'),
			'active_page' => 'admin',
			'admin_console' => true,
		);

		$this->template->header = $this->registry->get('\Aura\extensions\hooks')->fire('admin.censoring.header', $this->template->header);
		$this->template->footer = array(
			'admin_console' => true,
		);

		$this->template->footer = $this->registry->get('\Aura\extensions\hooks')->fire('admin.censoring.footer', $this->template->footer);
		$args = $this->registry->get('\Aura\extensions\hooks')->fire('admin.censoring.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('admin/censoring.tpl');
		$this->template->output($tpl,
			array_merge(
				array(
					'admin_menu' => $admin->generate_menu('censoring'),
					'form_action' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_censoring']),
					'csrf_token' => $this->registry->get('\Aura\auth\csrf')->generate('admin_censoring'),
					'censoring_lang' => $this->config['o_censoring'] == '1' ? $this->lang->t('Censoring enabled') : $this->lang->t('Censoring disabled'),
					'admin_options' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_options']),
					'words' => $words,
				),
				$args
			)
		);
	}

	/**
	 * Add a new word to be censored
	 */
	protected function add_word()
	{
		$this->registry->get('\Aura\auth\csrf')->confirm('admin_censoring');

		$search_for = utf8_trim($_POST['new_search_for']);
		$replace_with = utf8_trim($_POST['new_replace_with']);

		if ($search_for == '')
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Must enter word message'));

		$insert = array(
			'search_for' => $search_for,
			'replace_with' => $replace_with,
		);
		
		$this->db->insert('censoring', $insert);

		// Regenerate the censoring cache
		$this->cache->generate('censoring');

		$this->registry->get('\Aura\extensions\hooks')->fire('admin.censoring.add.beforeredirect');
		$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_censoring']), $this->lang->t('Word added redirect'));
	}

	/**
	 * Update a censoring word
	 */
	protected function update_word()
	{
		$this->registry->get('\Aura\auth\csrf')->confirm('admin_censoring');

		$id = intval(key($_POST['update']));

		$search_for = isset($_POST['search_for'][$id]) ? utf8_trim($_POST['search_for'][$id]) : '';
		$replace_with = isset($_POST['replace_with'][$id]) ? utf8_trim($_POST['replace_with'][$id]) : '';

		if ($search_for == '')
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Must enter word message'));

		$update = array(
			'search_for' => $search_for,
			'replace_with' => $replace_with,
		);
		
		$data = array(
			':id'	=>	$id,
		);
		
		$this->db->update('censoring', $update, 'id=:id', $data);

		// Regenerate the censoring cache
		$this->cache->generate('censoring');

		$this->registry->get('\Aura\extensions\hooks')->fire('admin.censoring.update.beforeredirect');
		$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_censoring']), $this->lang->t('Word updated redirect'));
	}

	/**
	 * Delete a word
	 */
	protected function delete_word()
	{
		$this->registry->get('\Aura\auth\csrf')->confirm('admin_censoring');

		$id = intval(key($_POST['remove']));
		$data = array(
			':id' => $id,
		);

		$this->db->delete('censoring', 'id=:id', $data);

		// Regenerate the censoring cache
		$this->cache->generate('censoring');

		$this->registry->get('\Aura\extensions\hooks')->fire('admin.censoring.delete.beforeredirect');
		$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_censoring']),  $this->lang->t('Word removed redirect'));
	}
}