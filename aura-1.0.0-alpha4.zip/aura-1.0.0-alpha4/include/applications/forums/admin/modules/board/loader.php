<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class loader_controller extends base_controller
{
	public function execute()
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('admin.loader.immediate');

		if (!$this->user['is_admmod'])
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		$this->registry->get('\Aura\auth\http_auth')->check_authentication();

		// The plugin to load should be supplied via GET
		$plugin = isset($_GET['plugin']) ? utf8_trim($_GET['plugin']) : '';
		if (!preg_match('%^AM?P_(\w*?)$%i', $plugin))
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		// AP_ == Admins only, AMP_ == admins and moderators
		$prefix = substr($plugin, 0, strpos($plugin, '_'));
		if ($this->user['g_moderator'] == '1' && $prefix == 'AP')
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		// Make sure the file actually exists
		if (!file_exists(config::PLUGINS_DIR.$plugin.'.php'))
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No plugin message', $plugin));

		$this->registry->get('\Aura\extensions\manager')->load_plugin($plugin);
	}
}