<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class moderate_controller extends base_controller
{
	/**
	 * Main app entry point, we display all actions to moderate
	 */
	public function execute()
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('admin.moderate.immediate');

		$this->configure_page();

		// Fetch all multi-moderate actions
		list($actions, $num_pages, $page) = $this->fetch_moderation_actions();

		$args = $this->registry->get('\Aura\extensions\hooks')->fire('admin.moderate.execute.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('admin/moderate.tpl');
		$this->template->output($tpl,
			array_merge(
				array(
					'admin_menu' => $this->admin->generate_menu('moderate'),
					'add_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_moderate_add']),
					'pagination' => $this->registry->get('\Aura\pagination')->paginate($num_pages, $page, $this->rewrite->url['admin_moderate']),
					'actions' => $actions,
				),
				$args
			)
		);
	}

	/**
	 * Configure a few things which are used on each page
	 */
	protected function configure_page()
	{
		$this->admin = $this->registry->get('\Aura\admin\common');

		if (!$this->user['is_admin'])
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		$this->admin->check_user('admin_moderate');

		$this->registry->get('\Aura\auth\http_auth')->check_authentication();

		// Load the admin-moderate language file
		$this->lang->load('admin_moderate');

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Admin'), $this->lang->t('Moderate')),
			'active_page' => 'admin',
			'admin_console' => true,
		);

		$this->template->header = $this->registry->get('\Aura\extensions\hooks')->fire('admin.moderate.header', $this->template->header);
		$this->template->footer = array(
			'admin_console' => true,
		);

		$this->template->footer = $this->registry->get('\Aura\extensions\hooks')->fire('admin.moderate.footer', $this->template->footer);
	}

	/**
	 * Fetch all moderation actions
	 */
	protected function fetch_moderation_actions()
	{
		$page = (!isset($_GET['p']) || $_GET['p'] <= '1') ? '1' : intval($_GET['p']);

		$ps = $this->db->select('multi_moderation', 'COUNT(id)');
		$total = $ps->fetchColumn();

		$num_pages = ceil($total/15);
		if ($page > $num_pages) $page = 1;
		$start_from = 15*($page-1);

		$ps = $this->db->select('multi_moderation', 'title, id', array(), '', 'id DESC LIMIT '.$start_from.', '.$this->config['o_disp_topics_default']);

		$actions = array();
		foreach ($ps as $action)
			$actions[] = array(
				'title' => $action['title'],
				'edit_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_moderate_edit'], array($action['id'])),
				'delete_link' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_moderate_delete'], array($action['id'])),
			);

		$actions = $this->registry->get('\Aura\extensions\hooks')->fire('admin.moderate.actions', $actions);
		return array($actions, $num_pages, $page);
	}

	/**
	 * Add a new action
	 */
	public function add()
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('admin.moderate.add.immediate');
		$this->configure_page();

		if (isset($_POST['form_sent']))
			$this->add_moderation_action();
			
		// Fetch a dropdown of all the categories/forums to display
		list($categories, $forums) = $this->fetch_categories();

		// Configure some default values for the fields on the form
		$action = array(
			'increment_posts' => 1,
			'report_posts' => 0,
			'send_email' => 1,
		);

		$this->template->header['posting'] = true;
		$args = $this->registry->get('\Aura\extensions\hooks')->fire('admin.moderate.add.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('admin/modify_action.tpl');
		$this->template->output($tpl,
			array_merge(
				array(
					'admin_menu' => $this->admin->generate_menu('moderate'),
					'csrf_token' => $this->registry->get('\Aura\auth\csrf')->generate('admin_moderate'),
					'form_action' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_moderate_add']),
					'action' => $action,
					'categories' => $categories,
					'forums' => $forums,
				),
				$args
			)
		);
	}

	/**
	 * Delete a configured moderation action
	 */
	public function delete()
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('admin.moderate.delete.immediate');
		$this->configure_page();

		$id = isset($_GET['id']) ? intval($_GET['id']) : '0';
		if ($id < 1)
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'));

		$data = array(
			':id' => $id,
		);

		$ps = $this->db->select('multi_moderation', 1, $data, 'id=:id');
		if (!$ps->rowCount())
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'));

		if (isset($_POST['form_sent']))
			$this->delete_moderation_action($id);

		$args = $this->registry->get('\Aura\extensions\hooks')->fire('admin.moderate.delete.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('admin/delete_action.tpl');
		$this->template->output($tpl,
			array_merge(
				array(
					'admin_menu' => $this->admin->generate_menu('moderate'),
					'form_action' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_moderate_delete'], array($id)),
					'csrf_token' => $this->registry->get('\Aura\auth\csrf')->generate('admin_moderate'),
				),
				$args
			)
		);
	}

	/**
	 * Delete a moderation action from the database
	 */
	protected function delete_moderation_action($id)
	{
		$this->registry->get('\Aura\auth\csrf')->confirm('admin_moderate');

		$data = array(
			':id' => $id,
		);

		$this->db->delete('multi_moderation', 'id=:id', $data);

		$this->registry->get('\Aura\extensions\hooks')->fire('admin.moderate.delete.beforeredirect');
		$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_moderate']), $this->lang->t('delete redirect'));
	}

	/**
	 * Edit an existing action
	 */
	public function edit()
	{
		$this->registry->get('\Aura\extensions\hooks')->fire('admin.moderate.edit.immediate');
		$this->configure_page();

		$id = isset($_GET['id']) ? intval($_GET['id']) : '0';
		$data = array(
			':id'	=>	$id,
		);

		$ps = $this->db->select('multi_moderation', 'close, stick, archive, move, leave_redirect, reply_message, title, add_start, add_end, send_email, increment_posts, report_posts', $data, 'id=:id');
		if (!$ps->rowCount())
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'));

		$cur_action = $ps->fetch();

		if (isset($_POST['form_sent']))
			$this->edit_moderation_action($id);
			
		// Fetch a dropdown of all the categories/forums to display
		list($categories, $forums) = $this->fetch_categories();

		$this->template->header['posting'] = true;
		$args = $this->registry->get('\Aura\extensions\hooks')->fire('admin.moderate.edit.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('admin/modify_action.tpl');
		$this->template->output($tpl,
			array_merge(
				array(
					'admin_menu' => $this->admin->generate_menu('moderate'),
					'csrf_token' => $this->registry->get('\Aura\auth\csrf')->generate('admin_moderate'),
					'form_action' => $this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_moderate_edit'], array($id)),
					'action' => $cur_action,
					'categories' => $categories,
					'forums' => $forums,
				),
				$args
			)
		);
	}

	/**
	 * Validate the request sent and check the information is valid
	 */
	protected function validate_request()
	{
		$message = isset($_POST['message']) ? utf8_trim($_POST['message']) : null;
		$title = isset($_POST['title']) ? utf8_trim($_POST['title']) : null;
		$add_start = isset($_POST['add_start']) ? utf8_ltrim($_POST['add_start']) : null;
		$add_end = isset($_POST['add_end']) ? utf8_rtrim($_POST['add_end']) : null;
		$increment_posts = isset($_POST['increment_posts']) ? intval($_POST['increment_posts']) : '0';
		$report_posts = isset($_POST['report_posts']) ? intval($_POST['report_posts']) : '0';
		$send_email = isset($_POST['send_email']) ? intval($_POST['send_email']) : '0';

		if (aura_strlen($title) > 50)
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Title too long'));

		if (aura_strlen($add_start) > 50 || strlen($add_end) > 50)
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Addition too long'));

		if (aura_strlen($title) < 1)
			$this->registry->get('\Aura\handlers\message')->show($this->lang->t('Bad request'));

		$close = isset($_POST['close']) ? intval($_POST['close']) : '2';
		$stick = isset($_POST['stick']) ? intval($_POST['stick']) : '2';
		$archive = isset($_POST['archive']) ? intval($_POST['archive']) : '2';
		$move = isset($_POST['forum']) ? intval($_POST['forum']) : '0';
		$leave_redirect = isset($_POST['redirect']) ? intval($_POST['redirect']) : '0';

		$this->registry->get('\Aura\extensions\hooks')->fire('admin.moderate.validate');

		return array($message, $title, $add_start, $add_end, $increment_posts, $report_posts, $send_email, $close, $stick, $archive, $move, $leave_redirect);
	}

	/**
	 * Add a new moderation action to the database
	 */
	protected function add_moderation_action()
	{
		$this->registry->get('\Aura\auth\csrf')->confirm('admin_moderate');

		// There are a lot of variables here, but we need to have them in a single reusable function to use when we edit later on
		list ($message, $title, $add_start, $add_end, $increment_posts, $report_posts, $send_email, $close, $stick, $archive, $move, $leave_redirect) = $this->validate_request();

		$insert = array(
			'title'	=>	$title,
			'close'	=>	$close,
			'stick'	=>	$stick,
			'archive' => $archive,
			'move'	=>	$move,
			'leave_redirect' => $leave_redirect,
			'reply_message'	=>	$message,
			'add_start'	=>	$add_start,
			'add_end'	=>	$add_end,
			'send_email' =>	$send_email,
			'increment_posts' => $increment_posts,
			'report_posts' => $report_posts,
		);

		$this->db->insert('multi_moderation', $insert);

		$this->registry->get('\Aura\extensions\hooks')->fire('admin.moderate.add.beforeredirect');
		$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_moderate']), $this->lang->t('Added redirect'));
	}

	/**
	 * Edit an existing moderation action in the database
	 */
	protected function edit_moderation_action($id)
	{
		$this->registry->get('\Aura\auth\csrf')->confirm('admin_moderate');

		// There are a lot of variables here, but we need to have them in a single reusable function to use when we edit later on
		list ($message, $title, $add_start, $add_end, $increment_posts, $report_posts, $send_email, $close, $stick, $archive, $move, $leave_redirect) = $this->validate_request();

		$update = array(
			'title' => $title,
			'close' => $close,
			'stick' => $stick,
			'archive' => $archive,
			'move' => $move,
			'leave_redirect' =>	$leave_redirect,
			'reply_message'	=> $message,
			'add_start' => $add_start,
			'add_end' => $add_end,
			'send_email' => $send_email,
			'increment_posts' => $increment_posts,
			'report_posts' => $report_posts,
		);

		$data = array(
			':id' => $id,
		);

		$this->db->update('multi_moderation', $update, 'id=:id', $data);

		$this->registry->get('\Aura\extensions\hooks')->fire('admin.moderate.edit.beforeredirect');
		$this->registry->get('\Aura\handlers\redirect')->show($this->registry->get('\Aura\links')->aura_link($this->rewrite->url['admin_moderate']), $this->lang->t('Edit redirect'));
	}

	/**
	 * Fetch the categories/forums on the board
	 */
	protected function fetch_categories()
	{
		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'forums',
				'as' => 'f',
				'on' => 'c.id=f.cat_id',
			),
		);

		// Display all the categories and forums
		$categories = $forums = array();
		$ps = $this->db->join('categories', 'c', $join, 'c.id AS cid, c.cat_name, f.id AS fid, f.forum_name', array(), 'f.redirect_url IS NULL', 'c.disp_position, c.id, f.disp_position');
		foreach ($ps as $cur_forum)
		{
			if (!isset($categories[$cur_forum['cid']]))
				$categories[$cur_forum['cid']] = array(
					'name' => $cur_forum['cat_name'],
					'id' => $cur_forum['cid'],
				);

			$forums[] = array(
				'id' => $cur_forum['fid'],
				'name' => $cur_forum['forum_name'],
				'category_id' => $cur_forum['cid'],
			);
		}

		$categories = $this->registry->get('\Aura\extensions\hooks')->fire('admin.moderate.fetch.categories', $categories);
		$forums = $this->registry->get('\Aura\extensions\hooks')->fire('admin.moderate.fetch.forums', $forums);
		return array($categories, $forums);
	}
}