<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
namespace Aura\tasks;

if (!defined('config::SESSION'))
	exit;

class task_update_forum extends \Aura\tasks\background_task
{
	public function run()
	{
		// First we run the upgrader
		$upgrade = $this->registry->get('\Aura\upgrade\automatic');
		$result = $upgrade->run();

		$mail = $this->registry->get('\Aura\email\email');
		if ($result['state'] == false)
		{
			if ($result['attempted']) // We only really need to log something if it's been attempted
			{
				$info = array(
					'subject' => array(
						'<version>' => $upgrade->version,
					),
					'message' => array(
						'<version>' => $upgrade->version,
						'<base_url>' => get_base_url(),
						'<message>' => $result['lang'],
					)
				);

				$mail_tpl = $this->registry->get('\email\parser')->parse_email('upgrade_failed', $aura_user['language'], $info);
				$mail->send($this->config['o_admin_email'], $mail_tpl['subject'], $mail_tpl['message']);
			}
		}
		else // Everything went ok
		{
			$info = array(
				'subject' => array(
					'<version>' => $upgrade->version,
				),
				'message' => array(
					'<version>' => $upgrade->version,
					'<base_url>' => get_base_url(),
				)
			);

			$mail_tpl = $this->registry->get('\email\parser')->parse_email('upgrade', $aura_user['language'], $info);
			$mail->send($this->config['o_admin_email'], $mail_tpl['subject'], $mail_tpl['message']);

			// Make sure we end the transaction
			$this->db->end_transaction();

			// Here we should refresh the script - updates can take a long time!
			header('Location: '.get_current_url());
			exit;
		}
	}
}