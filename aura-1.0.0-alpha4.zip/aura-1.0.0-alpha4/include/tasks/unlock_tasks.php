<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

namespace Aura\tasks;

if (!defined('config::SESSION'))
	exit;

class task_unlock_tasks extends \Aura\tasks\background_task
{
	public function run()
	{
		$data = array(
			':time' => strtotime('-15 minutes'),
		);

		$update = array(
			'locked' => 0,
		);

		$this->db->update('tasks', $update, 'next_run<=:time AND locked=1', $data);
	}
}