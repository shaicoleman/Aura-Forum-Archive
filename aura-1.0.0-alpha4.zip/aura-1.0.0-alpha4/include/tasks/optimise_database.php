<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
namespace Aura\tasks;

if (!defined('config::SESSION'))
	exit;

class task_optimise_database extends \Aura\tasks\background_task
{
	public function run()
	{
		$ps = $this->db->run('SHOW TABLE STATUS');
		foreach ($ps as $cur_table)
			$this->db->run('OPTIMIZE TABLE '.$cur_table['Name']);
	}
}