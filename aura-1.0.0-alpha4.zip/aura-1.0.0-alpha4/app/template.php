<?php
class template
{
	public $header;
	public $footer;
	protected $manager;
	public function __construct($registry)
	{
		$this->registry = $registry;
		$this->user = $registry->user;
		$this->cache = $registry->cache;
		$this->lang = $registry->lang;
		$this->config = $registry->config;

		$this->loader = new Twig_Loader_Filesystem(AURA_ROOT.'include/templates');

		$style_root = (($this->config['o_style_path'] != 'styles') ? $this->config['o_style_path'] : AURA_ROOT.$this->config['o_style_path']).'/'.$this->user['style'].'/templates/';
		$this->loader->addPath(AURA_ROOT.'include/templates/', 'core');

		if (file_exists($style_root)) // If the custom style doesn't use templates, then this is silly
			$this->loader->addPath($style_root, 'style');

		$this->manager = new Twig_Environment($this->loader, 
			array(
				'cache' => $this->cache->cache_dir.'templates/'.$this->user['style'],
				'debug' => ($this->config['o_debug_mode'] == '1') ? true : false,
			)
		);
	}

	/**
	 * Adds a new path to the Twig loader object
	 */
	public function add_path($path, $namespace)
	{
		$this->loader->addPath($path, $namespace);
	}

	/**
	 * Load a template object through the template manager
	 */
	public function load($tpl_file, $namespace = 'core')
	{
		// Do we actually have a namespace we're loading from?
		if (!$namespace || $namespace == 'core')
		{
			$style_root = (($this->config['o_style_path'] != 'styles') ? $this->config['o_style_path'] : AURA_ROOT.$this->config['o_style_path']).'/'.$this->user['style'].'/templates/';
			if (file_exists($style_root.$tpl_file))
				$tpl_file = $this->manager->loadTemplate('@style/'.$tpl_file);
			else 
				$tpl_file = $this->manager->loadTemplate('@core/'.$tpl_file);
		}
		else
			$tpl_file = $this->manager->loadTemplate('@'.$namespace.'/'.$tpl_file);

		return $tpl_file;
	}

	/**
	 * Output a template to the browser
	 */
	public function output($tpl, $data = array(), $header = true, $footer = true)
	{
		if ($header)
			$this->execute_header();

		echo $tpl->render(array_merge(
				array(
					'lang' => $this->lang,
					'aura_config' => $this->config,
					'aura_user' => $this->user,
					'hook' => $this->registry->get('\Aura\extensions\hooks'),
				), $data
			)
		);

		if ($footer)
			$this->execute_footer();
	}

	/**
	 * Render a single template object and return it to the system
	 */
	public function render($tpl, $data = array())
	{
		return $tpl->render(array_merge(
				array(
					'lang' => $this->lang,
					'aura_config' => $this->config,
					'aura_user' => $this->user,
					'hook' => $this->registry->get('\Aura\extensions\hooks'),
				), $data
			)
		);
	}

	/**
	 * Execute our header and output it to the browser
	 */
	public function execute_header()
	{
		$header = $this->registry->fetch_template('header');
		$header->set_data($this->header);
		$args = $header->fetch_data();

		$tpl = $this->load($args['tpl_file']);
		$this->output($tpl, $args, false, false);
	}

	/**
	 * Execute our footer and output it to the browser
	 */
	public function execute_footer()
	{
		$footer = $this->registry->fetch_template('footer');
		$footer->set_data($this->footer);
		$args = $footer->fetch_data();

		$tpl = $this->load($args['tpl_file']);
		$this->output($tpl, $args, false, false);
	}
}

/**
 * Template element class used for the header/footer classes
 */
abstract class template_element
{
	protected $data = array();
	final public function __construct($registry)
	{
		$this->registry = $registry;
		$this->db = $registry->db;
		$this->config = $registry->config;
		$this->user = $registry->user;
		$this->url = $registry->url;
		$this->lang = $registry->lang;
		$this->functions = $registry->functions;
		$this->cache = $registry->cache;
		$this->rewrite = $registry->rewrite;
	}

	final public function set_data($data)
	{
		$this->data = $data;
	}

	abstract function fetch_data();
}