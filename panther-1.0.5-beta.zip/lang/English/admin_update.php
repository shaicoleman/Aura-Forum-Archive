<?php

// Language definitions used in admin_update.php
$lang_admin_update = array(

'curl disabled'	=>	'cURL is disabled in this PHP environment. Please enable cURL support and try again.',
'no updates'	=>	'There are no updates available for Panther, as you are currently running the latest version. If your installation is corrupt, please download a fresh copy of Panther.',
'update failed'	=>	'Downloading the latest update failed for unknown reasons.',
'Unable to open zip' =>	'Opening the downloaded zip archive %s failed.',
'ZipArchive not supported'	=>	'The update patch has been downloaded, however it was not able to be automatically opened because this PHP environment does not have support built in for the class \'ZipArchize\'. Please extract all files from the archive to a folder called %s in the include/update/ folder in order to continue with the update.',
'Update successful'	=>	'Forum updated successfully. No errors have been detected during this process.',
'Admin updates'	=>	'Update Panther',
'Information'	=>	'Information',
'update panther'	=>	'You can automatically upgrade panther through this page. By doing so, you should not need to download or manually alter any files.',
'Patch'		=>	'Patch Version:',
'Release'	=>	'Patch Released:',
'Developer notes'	=>	'Developer notes:',
'Changelog'	=>	'Changelog:',
'View release notes'	=>	'View release notes',
'Hide release notes'	=>	'Hide release notes',
'Disclaimer'	=>	'<strong>Disclaimer:</strong> This process cannot be undone. We strongly recommend you download a database backup from your phpMyAdmin facility before continuing.',
'Install update'	=>	'Install Update',
'Invalid update patch'	=>	'An invalid update patch was downloaded. Please try again. If the issue persists, you can manually download it from <a href="http://panther.strongholdnation.co.uk/downloads.php">the Panther website</a>.',
'Hosting environment does not support Panther x'	=>	'This hosting environment does not support Panther %s because it requires at least MySQL version %s and PHP version %s. Your MySQL version is %s and your PHP version is %s.',
);
