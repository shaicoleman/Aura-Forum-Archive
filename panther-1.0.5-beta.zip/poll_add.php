<?php
/**
 * Copyright (C) 2015 Panther (http://panther.strongholdnation.co.uk/)
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/');
	require PANTHER_ROOT.'include/common.php';
}

if ($panther_user['g_read_board'] == '0')
	message($lang_common['No view'], false, '403 Forbidden');

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($id < 1)
	message($lang_common['Bad request'], false, '404 Not found');
	
// Fetch some info about the topic and/or the forum
$data = array(
	':gid'	=>	$panther_user['g_id'],
	':tid'	=>	$id,
);

$ps = $db->run('SELECT f.id AS fid, f.forum_name, f.redirect_url, f.password, t.poster, t.subject, t.approved, f.moderators FROM '.$db->prefix.'topics AS t INNER JOIN '.$db->prefix.'forums AS f ON f.id=t.forum_id LEFT JOIN '.$db->prefix.'forum_perms AS fp ON (fp.forum_id=f.id AND fp.group_id=:gid) WHERE (fp.read_forum IS NULL OR fp.read_forum=1) AND t.id=:tid', $data);
if (!$ps->rowCount())
	message($lang_common['Bad request'], false, '404 Not found');
	
$cur_posting = $ps->fetch();

$mods_array = ($cur_posting['moderators'] != '') ? unserialize($cur_posting['moderators']) : array();
$is_admmod = ($panther_user['is_admin'] || ($panther_user['g_moderator'] == '1' && $panther_user['g_global_moderator'] ||  array_key_exists($panther_user['username'], $mods_array))) ? true : false;

if ($panther_config['o_polls'] == '0' || (!$is_admmod && ($panther_user['g_post_polls'] == '0' || $cur_posting['poster'] != $panther_user['username'])))
	message($lang_common['No permission'], false, '403 Forbidden');

if ($cur_posting['redirect_url'] != '')
	message($lang_common['Bad request']);

if ($cur_posting['password'] != '')
		check_forum_login_cookie($cur_posting['fid'], $cur_posting['password']);

require PANTHER_ROOT.'lang/'.$panther_user['language'].'/poll.php';
require PANTHER_ROOT.'lang/'.$panther_user['language'].'/post.php';

if (isset($_POST['form_sent']))
{
	// Start with a clean slate
	$errors = array();

	$question = isset($_POST['req_question']) ? panther_trim($_POST['req_question']) : '';
	$options = isset($_POST['options']) && is_array($_POST['options']) ? array_map('panther_trim', $_POST['options']) : array();
	$type = isset($_POST['type']) ? 2 : 1;

	if ($question == '')
		$errors[] = $lang_poll['No question'];
	else if (panther_strlen($question) > 70)
		$errors[] = $lang_poll['Too long question'];
	else if ($panther_config['p_subject_all_caps'] == '0' && is_all_uppercase($question) && !$panther_user['is_admmod'])
		$errors[] = $lang_poll['All caps question'];

	if (empty($options))
		$errors[] = $lang_poll['No options'];

	$option_data = array();
	for ($i = 0; $i <= $panther_config['o_max_poll_fields']; $i++)
	{
		if (!empty($errors))
			break;

		if (panther_strlen($options[$i]) > 55)
			$errors[] = $lang_poll['Too long option'];
		else if ($panther_config['p_subject_all_caps'] == '0' && is_all_uppercase($options[$i]) && !$panther_user['is_admmod'])
			$errors[] = $lang_poll['All caps option'];
		else if ($options[$i] != '')
			$option_data[] = $options[$i];
	}

	if (count($options) < 2)
		$errors[] = $lang_poll['Low options'];

	$now = time();

	// Did everything go according to plan?
	if (empty($errors) && !isset($_POST['preview']))
	{
		$update = array(
			'question'	=>	$question,
		);

		$data = array(
			':id'	=>	$id,
		);

		$db->update('topics', $update, 'id=:id', $data);
		$insert = array(
			'topic_id'	=>	$id,
			'options'	=>	serialize($option_data),
			'type'		=>	$type,
		);

		$db->insert('polls', $insert);
		$new_pid = $db->lastInsertId($db->prefix.'polls');

		// Make sure we actually have a topic to go back to
		if ($cur_posting['approved'] == '0')
			redirect(get_link($panther_url['forum'], array($cur_posting['fid'], url_friendly($cur_posting['forum_name']))), $lang_post['Topic moderation redirect']);
		else
			redirect(get_link($panther_url['topic'], array($id, url_friendly($cur_posting['subject']))), $lang_post['Post redirect']);
	}
}

$cur_index = 1; 
$required_fields = array('req_question' => $lang_poll['Question'], 'req_subject' => $lang_common['Subject'], 'req_message' => $lang_common['Message']);
$focus_element = array('post');

if (!$panther_user['is_guest'])
	$focus_element[] = 'req_question';
else
{
	$required_fields['req_username'] = $lang_post['Guest name'];
	$focus_element[] = 'req_question';
}

$inputs = array();
for ($i = 0; $i <= $panther_config['o_max_poll_fields'] ; $i++)
{
	if (isset($_POST['preview']))
		$inputs[] = '<br />'.($type == 1 ? '<input name="vote" type="radio" value="'.$i.'" />' : '<input type="checkbox" />').' <span>'.panther_htmlspecialchars($options[$i]).'</span><br />';
	else
		$inputs[] = '<label><strong>'.$lang_poll['Option'].'</strong><br /> <input type="text" name="options['.$i.']" value="'.((isset($options[$i])) ? panther_htmlspecialchars($options[$i]) : '').'" size="60" maxlength="55" tabindex="'.$cur_index++.'" /><br /></label>';
}

$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), panther_htmlspecialchars($lang_post['Post new topic']));
define('PANTHER_ACTIVE_PAGE', 'index');
require PANTHER_ROOT.'header.php';
?>
<div class="linkst">
	<div class="inbox crumbsplus">
		<ul class="crumbs">
			<li><a href="<?php echo get_link($panther_url['index']); ?>"><?php echo $lang_common['Index'] ?></a></li>
			<li><span>»&#160;</span><strong><?php echo panther_htmlspecialchars($cur_posting['forum_name']) ?></strong></li>
		</ul>
		<div class="clearer"></div>
	</div>
</div>
<?php
// If there are errors, we display them
if (!empty($errors))
{
?>
<div id="posterror" class="block">
	<h2><span><?php echo $lang_post['Post errors'] ?></span></h2>
	<div class="box">
		<div class="inbox">
			<p><?php echo $lang_post['Post errors info'] ?></p>
			<ul>
<?php
	foreach ($errors as $cur_error)
		echo "\t\t\t\t".'<li><strong>'.$cur_error.'</strong></li>'."\n";
?>
			</ul>
		</div>
	</div>
</div>
<?php
}
else if (isset($_POST['preview']))
{
	require PANTHER_ROOT.'include/parser.php';
?>
<div id="postpreview" class="blockpost">
	<h2><span><?php echo $lang_poll['Poll preview'] ?></span></h2>
	<div class="box">
		<div class="inbox">
			<div class="postright">
				<div class="postmsg">
						<fieldset>
							<legend><?php echo panther_htmlspecialchars($question); ?></legend>
							<?php echo implode("\n\t\t\t\t\t\t", $inputs); ?>
							<br />
						</fieldset>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
}
?>
<div class="blockform">
	<h2><span><?php echo $lang_post['Post new topic'] ?></span></h2>
	<div class="box">
		<form id="post" method="post" action="<?php echo get_link($panther_url['poll_add'], array($id)); ?>" onsubmit="return process_form(this)">
			<div class="inform">
				<fieldset>
					<legend><?php echo $lang_poll['New poll legend'] ?></legend>
					<div class="infldset">
						<input type="hidden" name="form_sent" value="1" />
						<label><strong><?php echo $lang_poll['Question'] ?></strong><br /><input type="text" name="req_question" value="<?php if (isset($_POST['req_question'])) echo panther_htmlspecialchars($question); ?>" size="80" maxlength="70" tabindex="<?php echo $cur_index++ ?>" /><br /><br /></label>
						<?php echo implode("\n\t\t\t\t\t\t", $inputs); ?>
					</div>
				</fieldset>
			</div>
			<div class="inform">
				<fieldset>
					<legend><?php echo $lang_common['Options'] ?></legend>
					<div class="infldset">
						<div class="rbox">
							<label><input type="checkbox" name="type" value="1" tabindex="<?php echo ($cur_index++); ?>"<?php echo (isset($_POST['type']) ? ' checked="checked"' : ''); ?> /><?php echo $lang_poll['Allow multiselect']; ?>
						</div>
					</div>
				</fieldset>
			</div>
			<p class="buttons"><input type="submit" name="submit" value="<?php echo $lang_common['Submit'] ?>" tabindex="<?php echo $cur_index++ ?>" accesskey="s" /><input type="submit" name="preview" value="<?php echo $lang_post['Preview'] ?>" tabindex="<?php echo $cur_index++ ?>" accesskey="p" /></p>
		</form>
	</div>
</div>
<?php
require PANTHER_ROOT.'footer.php';