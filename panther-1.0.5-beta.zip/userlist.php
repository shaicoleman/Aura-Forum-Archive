<?php

/**
 * Copyright (C) 2015 Panther (http://panther.strongholdnation.co.uk/)
 * based on code by Rickard Andersson copyright (C) 2002-2008 PunBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/');
	require PANTHER_ROOT.'include/common.php';
}

if ($panther_user['is_bot'])
	message($lang_common['No permission']);

if ($panther_user['g_read_board'] == '0')
	message($lang_common['No view'], false, '403 Forbidden');
else if ($panther_user['g_view_users'] == '0')
	message($lang_common['No permission'], false, '403 Forbidden');

// Load the userlist.php language file
require PANTHER_ROOT.'lang/'.$panther_user['language'].'/userlist.php';

// Load the search.php language file
require PANTHER_ROOT.'lang/'.$panther_user['language'].'/search.php';

// Determine if we are allowed to view post counts
$show_post_count = ($panther_config['o_show_post_count'] == '1' || $panther_user['is_admmod']) ? true : false;

$username = isset($_GET['username']) && $panther_user['g_search_users'] == '1' ? panther_trim($_GET['username']) : '';
$show_group = isset($_GET['show_group']) ? intval($_GET['show_group']) : -1;
$sort_by = isset($_GET['sort_by']) && (in_array($_GET['sort_by'], array('username', 'registered')) || ($_GET['sort_by'] == 'num_posts' && $show_post_count)) ? $_GET['sort_by'] : 'username';
$sort_dir = isset($_GET['sort_dir']) && $_GET['sort_dir'] == 'DESC' ? 'DESC' : 'ASC';

// Create any applicable SQL generated from the GET array
$data = array(
	':unverified'	=>	PANTHER_UNVERIFIED,
);

$fields = array();
$sql = 'SELECT COUNT(id) FROM '.$db->prefix.'users AS u WHERE u.id > 1 AND u.group_id != :unverified';
$sql1 = 'SELECT u.id, u.username, u.title, u.num_posts, u.registered, u.email, u.use_gravatar, u.group_id AS g_id, g.g_user_title, o.user_id AS is_online FROM '.$db->prefix.'users AS u LEFT JOIN '.$db->prefix.'groups AS g ON g.g_id=u.group_id LEFT JOIN '.$db->prefix.'online AS o ON (o.user_id=u.id AND o.user_id!=1) WHERE u.id>1 AND u.group_id!=:unverified';

if ($username != '')
{
	$fields['username'] = ' AND u.username LIKE :username';
	$data[':username'] = str_replace('*', '%', $username);
}

if ($show_group > -1)
{
	$fields['gid'] = ' AND u.group_id = :gid';
	$data[':gid'] = $show_group;
}

foreach($fields as $field => $where_cond)
{
	$sql .= $where_cond;
	$sql1 .= $where_cond;
}

// Fetch user count
$ps = $db->run($sql, $data);
$num_users = $ps->fetchColumn();

// Determine the user offset (based on $_GET['p'])
$num_pages = ceil($num_users / 50);

$p = (!isset($_GET['p']) || $_GET['p'] <= 1 || $_GET['p'] > $num_pages) ? 1 : intval($_GET['p']);
$start_from = 50 * ($p - 1);

$data[':start'] = $start_from;
$sql1 .= " ORDER BY ".$sort_by." ".$sort_dir.", u.id ASC LIMIT :start, 50";

$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_common['User list']);
if ($panther_user['g_search_users'] == '1')
	$focus_element = array('userlist', 'username');

// Generate paging links
$paging_links = '<span class="pages-label">'.$lang_common['Pages'].' </span>'.paginate($num_pages, $p, $panther_url['userlist_result'], array(urlencode($username), $show_group, $sort_by, $sort_dir));

define('PANTHER_ALLOW_INDEX', 1);
define('PANTHER_ACTIVE_PAGE', 'userlist');
require PANTHER_ROOT.'header.php';
?>
<div class="blockform">
	<h2><span><?php echo $lang_search['User search'] ?></span></h2>
	<div class="box">
		<form id="userlist" method="get" action="<?php echo get_link($panther_url['userlist']); ?>">
			<div class="inform">
				<fieldset>
					<legend><?php echo $lang_ul['User find legend'] ?></legend>
					<div class="infldset">
<?php if ($panther_user['g_search_users'] == '1'): ?>						<label class="conl"><?php echo $lang_common['Username'] ?><br /><input type="text" name="username" value="<?php echo panther_htmlspecialchars($username) ?>" size="25" maxlength="25" /><br /></label>
<?php endif; ?>						<label class="conl"><?php echo $lang_ul['User group']."\n" ?>
						<br /><select name="show_group">
							<option value="-1"<?php if ($show_group == -1) echo ' selected="selected"' ?>><?php echo $lang_ul['All users'] ?></option>
<?php
foreach ($panther_groups as $cur_group)
	echo "\t\t\t\t\t\t\t".'<option value="'.$cur_group['g_id'].'" '.(($cur_group['g_id'] == $show_group) ? 'selected="selected"' : '').'>'.panther_htmlspecialchars($cur_group['g_title']).'</option>'."\n";
?>
						</select>
						<br /></label>
						<label class="conl"><?php echo $lang_search['Sort by']."\n" ?>
						<br /><select name="sort_by">
							<option value="username"<?php if ($sort_by == 'username') echo ' selected="selected"' ?>><?php echo $lang_common['Username'] ?></option>
							<option value="registered"<?php if ($sort_by == 'registered') echo ' selected="selected"' ?>><?php echo $lang_common['Registered'] ?></option>
<?php if ($show_post_count): ?>							<option value="num_posts"<?php if ($sort_by == 'num_posts') echo ' selected="selected"' ?>><?php echo $lang_ul['No of posts'] ?></option>
<?php endif; ?>						</select>
						<br /></label>
						<label class="conl"><?php echo $lang_search['Sort order']."\n" ?>
						<br /><select name="sort_dir">
							<option value="ASC"<?php if ($sort_dir == 'ASC') echo ' selected="selected"' ?>><?php echo $lang_search['Ascending'] ?></option>
							<option value="DESC"<?php if ($sort_dir == 'DESC') echo ' selected="selected"' ?>><?php echo $lang_search['Descending'] ?></option>
						</select>
						<br /></label>
						<p class="clearb"><?php echo ($panther_user['g_search_users'] == '1' ? $lang_ul['User search info'].' ' : '').$lang_ul['User sort info']; ?></p>
					</div>
				</fieldset>
			</div>
			<p class="buttons"><input type="submit" name="search" value="<?php echo $lang_common['Submit'] ?>" accesskey="s" /></p>
		</form>
	</div>
</div>
<div class="linkst">
	<div class="inbox">
		<p class="pagelink"><?php echo $paging_links ?></p>
		<div class="clearer"></div>
	</div>
</div>
<div id="users1" class="blocktable">
	<h2><span><?php echo $lang_common['User list'] ?></span></h2>
	<div class="box">
		<div class="inbox">
			<table>
			<thead>
				<tr>
					<th class="tc3"><?php echo $lang_common['Avatar']; ?></th>
					<th class="tc1" scope="col"><?php echo $lang_common['Username'] ?></th>
					<th class="tc2" scope="col"><?php echo $lang_common['Title'] ?></th>
<?php if ($show_post_count): ?>					<th class="tc3" scope="col"><?php echo $lang_common['Posts'] ?></th>
<?php endif; ?>					<th class="tcr" scope="col"><?php echo $lang_common['Registered'] ?></th>
				</tr>
			</thead>
			<tbody>
<?php
// Retrieve a list of user IDs, LIMIT is (really) expensive so we only fetch the IDs here then later fetch the remaining data
$ps = $db->run($sql1, $data);
if ($ps->rowCount())
{
	// Grab the users
	require PANTHER_ROOT.'lang/'.$panther_user['language'].'/online.php';
	foreach ($ps as $user_data)
	{
		$user_title_field = get_title($user_data);
                $is_online = ($user_data['is_online'] == $user_data['id']) ? '<img src="'.$panther_config['o_image_dir'].'status_online.png" title="'.$lang_online['user is online'].'" />' : '<img src="'.$panther_config['o_image_dir'].'status_offline.png" title="'.$lang_online['user is offline'].'" />';
?>
				<tr>
					<td class="tc3"><?php echo generate_avatar_markup($user_data['id'], $user_data['email'], $user_data['use_gravatar'], array(32, 32)); ?></td>
					<td class="tc1"><?php echo $is_online.colourize_group($user_data['username'], $user_data['g_id'], $user_data['id']); ?></td>
					<td class="tc2"><?php echo $user_title_field ?></td>
<?php if ($show_post_count): ?>					<td class="tc3"><?php echo forum_number_format($user_data['num_posts']) ?></td>
<?php endif; ?>
					<td class="tcr"><?php echo format_time($user_data['registered'], true) ?></td>
				</tr>
<?php
	}
}
else
	echo "\t\t\t".'<tr>'."\n\t\t\t\t\t".'<td class="tcl" colspan="'.(($show_post_count) ? 4 : 3).'">'.$lang_search['No hits'].'</td></tr>'."\n";
?>
			</tbody>
			</table>
		</div>
	</div>
</div>
<div class="linksb">
	<div class="inbox">
		<p class="pagelink"><?php echo $paging_links ?></p>
		<div class="clearer"></div>
	</div>
</div>
<?php
require PANTHER_ROOT.'footer.php';