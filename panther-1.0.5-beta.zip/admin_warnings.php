<?php
/**
 * Copyright (C) 2015 Panther (http://panther.strongholdnation.co.uk/)
 * based on code by Koos copyright (C) 2002-2008 punBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */
 
// Tell header.php to use the admin template
define('PANTHER_ADMIN_CONSOLE', 1);

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/');
	require PANTHER_ROOT.'include/common.php';
}

require PANTHER_ROOT.'include/common_admin.php';

if (!$panther_user['is_admin'])
	message($lang_common['No permission'], false, '403 Forbidden');

if ($panther_user['id'] != '2')
{
	if(!is_null($admins[$panther_user['id']]['admin_warnings']))
	{
		if ($admins[$panther_user['id']]['admin_warnings'] == '0')
			message($lang_common['No permission'], false, '403 Forbidden');
	}
}

check_authentication();

// Load the admin_warnings.php language file
require PANTHER_ROOT.'lang/'.$admin_language.'/admin_warnings.php';

if ($panther_user['g_read_board'] == '0')
	message($lang_common['No view'], false, '403 Forbidden');

if ($panther_config['o_warnings'] == '0')
	message($lang_warnings['Warnings disabled']);

if (isset($_POST['form_sent']))
{
	confirm_referrer('admin_warnings.php');
	$action = isset($_POST['action']) ? panther_trim($_POST['action']) : '';
	$id = isset($_POST['id']) ? intval($_POST['id']) : 0;
	
	if ($action == '')
		message($lang_common['Bad request']);

	if ($action == 'types')
	{
		if (empty($_POST['warning_title']))
			message($lang_warnings['No title']);

		// Determine expiration time
		$expiration_time  = get_expiration_time($_POST['expiration_time'], $_POST['expiration_unit']);
		
		$warning_title = isset($_POST['warning_title']) ? panther_trim($_POST['warning_title']) : '';
		$warning_description = isset($_POST['warning_description']) ? panther_trim($_POST['warning_description']) : '';
		$points = isset($_POST['warning_points']) ? intval($_POST['warning_points']) : 0;

		if (strlen($warning_title) < 1)
			message($lang_warnings['No title']);
		else if (strlen($warning_title) > 70)
			message($lang_warnings['Title too long']);

		if ($warning_description == '')
			message($lang_warnings['Must enter descripiton']);
		else if (panther_strlen($warning_description) > PANTHER_MAX_POSTSIZE)
			message(sprintf($lang_warnings['Must enter descripiton'], forum_number_format(PANTHER_MAX_POSTSIZE)));
			
		$update = array(
			'title'	=>	$warning_title,
			'description'	=>	$warning_description,
			'points'	=>	$points,
			'expiration_time'	=>	$expiration_time,
		);

		if (isset($_POST['id']) && $id > 0) // Then we're editing
		{
			$data = array(
				':id'	=>	$id,
			);

			$ps = $db->select('warning_types', 'id, title, description, points, expiration_time', $data, 'id=:id');
			if ($ps->rowCount())
			{
				$warning_type = $ps->fetch();

				$data = array(
					':id'	=>	$warning_type['id'],
				);
				
				$db->update('warning_types', $update, 'id=:id', $data);
				$redirect_msg = $lang_warnings['Type updated redirect'];
			}
		}
		else // We're adding a new type
		{
			$db->insert('warning_types', $update);
			$redirect_msg = $lang_warnings['Type added redirect'];
		}
	}
	else // We're adding/editing warning levels
	{
		$warning_title = isset($_POST['warning_title']) ? panther_trim($_POST['warning_title']) : '';
		$warning_points = isset($_POST['warning_points']) ? intval($_POST['warning_points']) : 0;

		if ($warning_title == '')
			message($lang_warnings['No title']);

		// Determine expiration time
		$expiration_time  = get_expiration_time($_POST['expiration_time'], $_POST['expiration_unit']);

		$update = array(
			'points'	=>	$warning_points,
			'message'	=>	$warning_title,
			'period'	=>	$expiration_time,
		);

		if (isset($_POST['id']) && $id > 0)
		{
			$data = array(
				':id'	=>	$id,
			);

			$db->update('warning_levels', $update, 'id=:id', $data);
			$redirect_msg = $lang_warnings['Level update redirect'];
		}
		else
		{
			$db->insert('warning_levels', $update);
			$redirect_msg = $lang_warnings['Level added redirect'];
		}
	}

	redirect(get_link($panther_url['admin_warnings']), $redirect_msg);
}

$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_admin_common['Admin'], $lang_admin_common['Warnings']);
define('PANTHER_ACTIVE_PAGE', 'admin');
require PANTHER_ROOT.'header.php';

if (isset($_POST['add_type']))
{
	generate_admin_menu('warnings');
?>
		<div class="blockform">
			<h2><span><?php echo $lang_warnings['Add new type label']; ?></span></h2>
			<div class="box">
				<form id="edit_type" method="post" action="<?php echo get_link($panther_url['admin_warnings']); ?>"> 
					<p class="submittop"><input type="submit" name="add" value="<?php echo $lang_warnings['Add New']; ?>" /></p>
					<div class="inform">
						<fieldset>
							<legend><?php echo $lang_warnings['Type details']; ?></legend>
							<div class="infldset">
								<input type="hidden" name="form_sent" value="1" />
								<input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>" />
								<input type="hidden" name="action" value="types" />								
								<table class="aligntop">
									<tr>
										<th scope="row"><?php echo $lang_warnings['Warning title']; ?></th>
										<td><input type="text" name="warning_title" size="35" maxlength="120" tabindex="1" /></td>
									</tr>
									<tr>
										<th scope="row"><?php echo $lang_warnings['Points']; ?></th>
										<td><input type="text" name="warning_points" size="5" maxlength="5" tabindex="2" /></td>
									</tr>
									<tr>
										<th scope="row"><?php echo $lang_warnings['Expiration']; ?></th>
										<td><input type="text" name="expiration_time" size="5" maxlength="5" value="10" tabindex="3" />

											<select name="expiration_unit">
												<option value="hours"><?php echo $lang_warnings['Hours']; ?></option>
												<option value="days" selected="selected"><?php echo $lang_warnings['Days']; ?></option>
												<option value="months"><?php echo $lang_warnings['Months']; ?></option>
												<option value="never"><?php echo $lang_warnings['Never']; ?></option>
											</select>
										</td>
									</tr>
									<tr>
										<th scope="row"><?php echo $lang_warnings['Description']; ?></th>
										<td><textarea name="warning_description" rows="3" cols="50" tabindex="4"></textarea></td>
									</tr>
								</table>
							</div>
						</fieldset>
					</div>
					<p class="submitend"><input type="submit" name="add" value="<?php echo $lang_warnings['Add New']; ?>" /></p>
				</form>
			</div>
		</div>
		<div class="clearer"></div>
	</div>
<?php
}
else if (isset($_GET['edit_type']))
{
	$id = isset($_GET['edit_type']) ? intval($_GET['edit_type']) : 0;
	if ($id < 1)
		message($lang_common['Bad request']);
	
	$data = array(
		':id'	=>	$id,
	);

	// Get information of the warning
	$ps = $db->select('warning_types', 'id, title, description, points, expiration_time', $data, 'id=:id');
	if (!$ps->rowCount())
		message($lang_common['Bad request']);
		
	$warning_type = $ps->fetch();
		
	// Get expiration time and unit
	$expiration = explode(' ', format_expiration_time($warning_type['expiration_time']));
	if ($expiration[0] == 'Never')
	{
		$expiration[0] = '';
		$expiration[1] = 'Never';
	}

	generate_admin_menu('warnings');
?>
		<div class="blockform">
			<h2><span><?php echo $lang_warnings['Edit warning type']; ?></span></h2>
			<div class="box">
				<form id="edit_type" method="post" action="<?php echo get_link($panther_url['admin_warnings']); ?>"> 
					<p class="submittop"><input type="submit" name="update" value="<?php echo $lang_warnings['Save changes']; ?>" tabindex="6" /></p>
					<div class="inform">
						<fieldset>
							<legend><?php echo $lang_warnings['Warning type details']; ?></legend>
							<div class="infldset">
								<input type="hidden" name="form_sent" value="1" />
								<input type="hidden" name="id" value="<?php echo $warning_type['id']; ?>" />
								<input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>" />
								<input type="hidden" name="action" value="types" />
								<table class="aligntop">
									<tr>
										<th scope="row"><?php echo $lang_warnings['Warning title']; ?></th>
										<td><input type="text" name="warning_title" size="35" maxlength="120" value="<?php echo panther_htmlspecialchars($warning_type['title']); ?>" tabindex="1" /></td>
									</tr>
									<tr>
										<th scope="row"><?php echo $lang_warnings['Points']; ?></th>
										<td><input type="text" name="warning_points" size="3" maxlength="3" value="<?php echo panther_htmlspecialchars($warning_type['points']); ?>" tabindex="2" /></td>
									</tr>
									<tr>
										<th scope="row"><?php echo $lang_warnings['Expiration']; ?></th>
										<td><input type="text" name="expiration_time" size="3" maxlength="3" value="<?php echo panther_htmlspecialchars($expiration[0]); ?>" tabindex="3" />

											<select name="expiration_unit">
												<option value="hours"<?php if ($expiration[1] == 'hours') echo ' selected="selected"' ?>><?php echo $lang_warnings['Hours']; ?></option>
												<option value="days"<?php if ($expiration[1] == 'days') echo ' selected="selected"' ?>><?php echo $lang_warnings['Days']; ?></option>
												<option value="months"<?php if ($expiration[1] == 'months') echo ' selected="selected"' ?>><?php echo $lang_warnings['Months']; ?></option>
												<option value="never"<?php if ($expiration[1] == 'Never') echo ' selected="selected"' ?>><?php echo $lang_warnings['Never']; ?></option>
											</select>
										</td>
									</tr>
									<tr>
										<th scope="row"><?php echo $lang_warnings['Description']; ?></th>
										<td><textarea name="warning_description" rows="3" cols="50" tabindex="4"><?php echo panther_htmlspecialchars($warning_type['description']) ?></textarea></td>
									</tr>
								</table>
							</div>
						</fieldset>
					</div>
					<p class="submitend"><input type="submit" name="update" value="<?php echo $lang_warnings['Save changes']; ?>" /></p>
				</form>
			</div>
		</div>
		<div class="clearer"></div>
	</div>
	<?php
}
elseif (isset($_GET['del_type']))
{
	$id = isset($_GET['del_type']) ? intval($_GET['del_type']) : 0;
	if ($id < 1)
		message($lang_common['Bad request']);

	if (isset($_POST['del_type_comply']))
	{
		$data = array(
			':id'	=>	$id,
		);
		
		// Delete the warning type
		$db->delete('warning_types', 'id=:id', $data);
		redirect(get_link($panther_url['admin_warnings']), $lang_warnings['Type delete redirect']);
	}
	else	// If the user hasn't confirmed the delete
	{
		$data = array(
			':id'	=>	$id,
		);

		$ps = $db->select('warning_types', 'title', $data, 'id=:id');
		if (!$ps->rowCount())
			message($lang_common['Bad resuqest']);
		
		$warning_type = panther_htmlspecialchars($ps->fetchColumn());
		generate_admin_menu('warnings');
?>
		<div class="blockform">
			<h2><span><?php echo $lang_warnings['Confirm delete type']; ?></span></h2>
			<div class="box">
				<form method="post" action="<?php echo get_link($panther_url['warning_del_type'], array($id)); ?>">
					<input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>" />
					<div class="inform">
						<fieldset>
							<legend><?php echo $lang_warnings['Important Information']; ?></legend>
							<div class="infldset">
								<p><?php echo sprintf($lang_warnings['Del type confirm'], $warning_type); ?></p>
								<p><?php echo $lang_warnings['Del warning type']; ?></p>
							</div>
						</fieldset>
					</div>
					<p class="buttons"><input type="submit" name="del_type_comply" value="<?php echo $lang_warnings['Delete']; ?>" /> <a href="javascript:history.go(-1)"><?php echo $lang_common['Go back'] ?></a></p>
				</form>
			</div>
		</div>
		<div class="clearer"></div>
	</div>
	<?php
	}
}
else if (isset($_POST['add_level']))
{
	generate_admin_menu('warnings');
?>
		<div class="blockform">
			<h2><span><?php echo $lang_warnings['Add new level label']; ?></span></h2>
			<div class="box">
				<form id="edit_type" method="post" action="<?php echo get_link($panther_url['admin_warnings']); ?>"> 
					<p class="submittop"><input type="submit" name="add" value="<?php echo $lang_warnings['Add New']; ?>" /></p>
					<input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>" />
					<div class="inform">
						<fieldset>
							<legend><?php echo $lang_warnings['Warning level details']; ?></legend>
							<div class="infldset">
								<input type="hidden" name="form_sent" value="1" />
								<input type="hidden" name="action" value="levels" />		
								<table class="aligntop">
									<tr>
										<th scope="row"><?php echo $lang_warnings['Ban message']; ?></th>
										<td>
											<input type="text" name="warning_title" size="50" maxlength="255" tabindex="1" />
											<span><?php echo $lang_warnings['Ban message help']; ?></span>
										</td>
									</tr>
									<tr>
										<th scope="row"><?php echo $lang_warnings['Points']; ?></th>
										<td>
											<input type="text" name="warning_points" size="5" maxlength="5" tabindex="2" />
											<span><?php echo $lang_warnings['Ban points help']; ?></span>
										</td>
									</tr>
									<tr>
										<th scope="row"><?php echo $lang_warnings['Ban duration']; ?></th>
										<td><input type="text" name="expiration_time" size="5" maxlength="5" value="10" tabindex="3" />
											<select name="expiration_unit">
												<option value="hours"><?php echo $lang_warnings['Hours']; ?></option>
												<option value="days" selected="selected"><?php echo $lang_warnings['Days']; ?></option>
												<option value="months"><?php echo $lang_warnings['Months']; ?></option>
												<option value="never"><?php echo $lang_warnings['Permanent']; ?></option>
											</select>
										</td>
									</tr>
								</table>
							</div>
						</fieldset>
					</div>
					<p class="submitend"><input type="submit" name="add" value="<?php echo $lang_warnings['Add New']; ?>" /></p>
				</form>
			</div>
		</div>
		<div class="clearer"></div>
	</div>
	<?php
}
else if (isset($_GET['edit_level']))
{
	$id = isset($_GET['edit_level']) ? intval($_GET['edit_level']) : 0;

	$data = array(
		':id'	=>	$id,
	);

	// Fetch warning information
	$ps = $db->select('warning_levels', 'id, points, message, period', $data, 'id=:id');
	if (!$ps->rowCount())
		message($lang_common['Bad request']);

	$warning_level = $ps->fetch();
	generate_admin_menu('warnings');

	// Get expiration time and unit
	$expiration = explode(' ', format_expiration_time($warning_level['period']));
	if ($expiration[0] == 'Never')
	{
		$expiration[0] = '';
		$expiration[1] = 'Never';
	}
?>
		<div class="blockform">
			<h2><span><?php echo $lang_warnings['Edit warning level']; ?></span></h2>
			<div class="box">
				<form id="edit_level" method="post" action="<?php echo get_link($panther_url['admin_warnings']); ?>"> 
					<p class="submittop"><input type="submit" name="update" value="<?php echo $lang_warnings['Save changes']; ?>" tabindex="6" /></p>
					<input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>" />
					<input type="hidden" name="action" value="levels" />
					<input type="hidden" name="form_sent" value="1" />
					<div class="inform">
						<fieldset>
							<legend><?php echo $lang_warnings['Warning level details']; ?></legend>
							<div class="infldset">
								<input type="hidden" name="form_sent_level" value="1" />
								<input type="hidden" name="id" value="<?php echo $warning_level['id']; ?>" />
								<table class="aligntop">
									<tr>
										<th scope="row"><?php echo $lang_warnings['Ban message']; ?></th>
										<td>
											<input type="text" name="warning_title" size="50" maxlength="255" value="<?php echo panther_htmlspecialchars($warning_level['message']); ?>" tabindex="1" />
											<span><?php echo $lang_warnings['Ban message help']; ?></span>
										</td>
									</tr>
									<tr>
										<th scope="row"><?php echo $lang_warnings['Points']; ?></th>
										<td>
											<input type="text" name="warning_points" size="3" maxlength="3" value="<?php echo panther_htmlspecialchars($warning_level['points']); ?>" tabindex="2" />
											<span><?php echo $lang_warnings['Ban points help']; ?></span>
										</td>
									</tr>
									<tr>
										<th scope="row"><?php echo $lang_warnings['Ban duration']; ?></th>
										<td><input type="text" name="expiration_time" size="3" maxlength="3" value="<?php echo panther_htmlspecialchars($expiration[0]); ?>" tabindex="3" />

											<select name="expiration_unit">
												<option value="hours"<?php if ($expiration[1] == 'hours') echo ' selected="selected"' ?>><?php echo $lang_warnings['Hours']; ?></option>
												<option value="days"<?php if ($expiration[1] == 'days') echo ' selected="selected"' ?>><?php echo $lang_warnings['Days']; ?></option>
												<option value="months"<?php if ($expiration[1] == 'months') echo ' selected="selected"' ?>><?php echo $lang_warnings['Months']; ?></option>
												<option value="never"<?php if ($expiration[1] == 'Never') echo ' selected="selected"' ?>><?php echo $lang_warnings['Permanent']; ?></option>
											</select>
										</td>
									</tr>
								</table>
							</div>
						</fieldset>
					</div>
					<p class="submitend"><input type="submit" name="update" value="<?php echo $lang_warnings['Save changes']; ?>" /></p>
				</form>
			</div>
		</div>
		<div class="clearer"></div>
	</div>
<?php
}
else if (isset($_GET['del_level']))
{
	$id = isset($_GET['del_level']) ? intval($_GET['del_level']) : 0;
	if ($id < 1)
		message($lang_common['Bad request']);

	if (isset($_POST['del_level_comply']))
	{
		$data = array(
			':id'	=>	$id,
		);

		// Delete the warning level
		$db->delete('warning_levels', 'id=:id', $data);
		redirect(get_link($panther_url['admin_warnings']), $lang_warnings['Level del redirect']);
	}

	generate_admin_menu('warnings');
?>
		<div class="blockform">
			<h2><span><?php echo $lang_warnings['Confirm delete level']; ?></span></h2>
			<div class="box">
				<form method="post" action="<?php echo get_link($panther_url['warning_del_level'], array($id)); ?>">
				<input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>" />
					<div class="inform">
						<fieldset>
							<legend><?php echo $lang_warnings['Important Information']; ?></legend>
							<div class="infldset">
								<p><?php echo $lang_warnings['Delete level']; ?></p>
							</div>
						</fieldset>
					</div>
					<p class="buttons"><input type="submit" name="del_level_comply" value="<?php echo $lang_warnings['Delete']; ?>" /> <a href="javascript:history.go(-1)"><?php echo $lang_common['Go back'] ?></a></p>
				</form>
			</div>
		</div>
		<div class="clearer"></div>
	</div>
	<?php
}
else
{
	$ps = $db->select('warning_types', 'id, title, description, points, expiration_time', array(), '', 'points, id');
	$ps1 = $db->select('warning_levels', 'id, points, period', array(), '', 'points, id');
	// Display the admin navigation menu
	generate_admin_menu('warnings');
?>
		<div class="blockform block2">
			<h2 class="block2"><span><?php echo $lang_warnings['Warning types']; ?></span></h2>
			<div class="box">
				<form id="list_types" method="post" action="<?php echo get_link($panther_url['admin_warnings']); ?>">
					<div class="inform">
						<fieldset>
							<legend><?php echo $lang_warnings['Modify warning types']; ?></legend>
							<div class="infldset">
								<table>
<?php
	foreach ($ps as $list_types)
	{
		$expiration = explode(' ', format_expiration_time($list_types['expiration_time']));
		if ($expiration[0] == $lang_warnings['Never'])
		{
			$expiration[0] = '';
			$expiration[1] = $lang_warnings['Never'];
		}	
?>
									<tr>
										<th><a href="<?php echo get_link($panther_url['warning_edit_type'], array($list_types['id'])); ?>"><?php echo $lang_warnings['Edit']; ?></a> - <a href="<?php echo get_link($panther_url['warning_del_type'], array($list_types['id'])); ?>"><?php echo $lang_warnings['Delete']; ?></a></th>
										<td><?php echo sprintf($lang_warnings['Points 2'], $list_types['points']); ?>&nbsp;&nbsp;<strong><?php echo panther_htmlspecialchars($list_types['title']) ?></strong>&nbsp;&nbsp;<?php echo sprintf($lang_warnings['Expires after x'], $expiration[0], $expiration[1]); ?></td>
									</tr>
<?php	
	}
?>
								</table>
								<div class="fsetsubmit"><input type="submit" name="add_type" value="<?php echo $lang_warnings['Add']; ?>" tabindex="4" /></div>
							</div>
						</fieldset>
					</div>
				</form>
			</div>
		</div>
		<div class="blockform block2">
			<h2 class="block2"><span><?php echo $lang_warnings['Warning levels']; ?></span></h2>
			<div class="box">
				<form id="list_levels" method="post" action="<?php echo get_link($panther_url['admin_warnings']) ?>">
					<div class="inform">
						<fieldset>
							<legend><?php echo $lang_warnings['Modify warning types']; ?></legend>
							<div class="infldset">
								<table>
	<?php
	foreach ($ps1 as $list_levels)
	{
		if ($list_levels['period'] == '0')
			$ban_title = $lang_warnings['Permanent ban'];
		else
		{
			$expiration = explode(' ', format_expiration_time($list_levels['period']));
			if ($expiration[0] == $lang_warnings['Never'])
			{
				$expiration[0] = '';
				$expiration[1] = $lang_warnings['Never'];
			}
			$ban_title = sprintf($lang_warnings['Temporary ban'], $expiration[0], $expiration[1]);
		}
	?>
									<tr>
										<th><a href="<?php echo get_link($panther_url['warning_edit_level'], array($list_levels['id'])) ?>"><?php echo $lang_warnings['Edit']; ?></a> - <a href="<?php echo get_link($panther_url['warning_del_level'], array($list_levels['id'])) ?>"><?php echo $lang_warnings['Delete']; ?></a></th>
										<td><?php echo sprintf($lang_warnings['Points 2'], $list_levels['points']); ?>&nbsp;&nbsp;<strong><?php echo $ban_title ?></strong></td>
									</tr>

	<?php	
	}
	?>
								</table>
								
								<div class="fsetsubmit"><input type="submit" name="add_level" value="<?php echo $lang_warnings['Add']; ?>" tabindex="4" /></div>
							</div>
						</fieldset>
					</div>
				</form>
			</div>
		</div>
		<div class="clearer"></div>
	<?php
}

require PANTHER_ROOT.'footer.php';