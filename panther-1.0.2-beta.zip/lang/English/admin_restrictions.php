<?php

// Language definitions used in admin_restrictions.php
$lang_admin_restrictions = array(

//ADD/EDIT/DELETE: Stage 1
'restrictions head'	=>	'Admin Restrictions',
'restriction information'				=>	'Add New Restriction',
'add new'					=>	'Add',
'no other admins'					=>	'- No Administrators -',
'restrictions head 3'	=>	'Admin Restrictions',
'restriction information 3'				=>	'Delete Existing Restriction',
'delete'					=>	'Delete',
'restrictions head 2'	=>	'Admin Restrictions',
'restriction information 2'				=>	'Edit Existing Restriction',
'edit'					=>	'Edit',
'back'					=>	'Go Back',
'delete label'				=>	'<span style="color:red">WARNING!</span> You are about to permanently delete the restrictions for the administrator %s. Are you sure?',
'back'					=>	'Go Back',


//ADD/EDIT: Stage 2
'user not admin'					=>	'This user is not currently part of the administrator group.',
'restrictions for user x'			=>	'Restrictions for user "%s"',
'admin restrictions'				=>	'The user you are adding these restrictions for will only be able to do what you allow them to do. You can revert this at any time by editing this user\'s restrictions again. If an option is set to no, they will have no access to the page at all, not even to view it.',
'board config'					=>	'Alter Board Config',
'change config label'						=>	'Allow this user to alter the board\'s main configuration. ',
'board perms'					=>	'Alter Board Permissions',
'change perms label'						=>	'Allow this user to alter the board\'s posting permissions. ',
'board cats'					=>	'Alter Board Categories',
'change cats label'						=>	'Allow this user to alter the board\'s categories. ',
'board forums'					=>	'Alter Board Forums',
'change forums label'						=>	'Allow this user to alter the board\'s forums.',
'board forums'					=>	'Alter Board Forums',
'change forums label'						=>	'Allow this user to alter the board\'s forums.',
'board groups'					=>	'Alter User Groups',
'change groups label'						=>	'Allow this user to alter the board\'s user groups configuration.',
'board users'					=>	'Alter User\'s User Group',
'change users label'						=>	'Allow this user to alter the user group of other users (including your own) and delete user profiles. This only applies to the user group and they will not be stopped from editing the rest of a user\'s profile.',
'board censoring'					=>	'Alter Censoring',
'change censoring label'						=>	'Allow this user to alter the board\'s word censoring. If set to no, then they will have no access to the page at all, not even to view it.',
'board moderate'					=>	'Alter Multi-moderation',
'change moderate label'						=>	'Allow this user to alter the board\'s multi-moderation actions. If set to no, then they will have no access to the page at all, not even to view it.',
'board ranks'					=>	'Alter Ranks',
'change ranks label'						=>	'Allow this user to alter the board\'s user ranks. If set to no, then they will have no access to the page at all, not even to view it.',
'board maintenance'					=>	'Use Maintenance Features',
'change maintenance label'						=>	'Allow this user to use the board\'s maintenance whilst in maintenance mode. If set to no, then they will still be able to access the rest of the board whilst in maintenance mode.',
'board plugins'					=>	'Allow use of Plugins',
'change plugins label'						=>	'Allow this user to alter the configuration of the board\'s plugins. If set to no, then they will be able to use none, even ones that standard moderators can.',
'board restrictions'					=>	'Alter Admin Restrictions',
'change restrictions label'						=>	'Allow this user to alter the admin restrictions. <strong style="color:red">WARNING!</strong> Setting this option to yes will automatically give them power to over-ride their own restrictions.',
'board updates'					=>	'Install Updates',
'install updates label'						=>	'Allow this user to install updates to the forum software. Updates are downloaded automatically from the Panther website.',

//ADD: Stage 3
'no user'						=>	'This user is not a valid board administrator.',
'already restrictions'						=>	'This user already has restrictions set up. Instead you should edit those.',
'added redirect'						=>	'Restrictions Imposed. Redirecting …',

//EDIT: Stage 3
'no restrictions'						=>	'This user already has no restrictions set up. You should create some instead.',
'edited redirect'						=>	'Restrictions Edited. Redirecting …',

//EDIT: Stage 3
'removed redirect'						=>	'Restrictions Removed. Redirecting …',
);
