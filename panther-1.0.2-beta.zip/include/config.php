<?php

$db_type = 'mysqli';
$db_host = 'localhost';
$db_name = 'panther2';
$db_username = 'root';
$db_password = '';
$db_prefix = 'pantherf53a6_';
$p_connect = false;

define('PANTHER', 1);
