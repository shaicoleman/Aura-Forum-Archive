<?php

/**
 * Copyright (C) 2015 Panther (http://panther.strongholdnation.co.uk/)
 * based on code by Rickard Andersson copyright (C) 2002-2008 PunBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

// Make sure no one attempts to run this script "directly"
if (!defined('PANTHER'))
	exit;


//
// Generate the config cache PHP script
//
function generate_config_cache()
{
	global $db, $panther_config;

	$result = $db->query('SELECT g_id, g_colour, g_global_moderator FROM '.$db->prefix.'groups ORDER BY g_id ASC') or error('Unable to fetch forum groups', __FILE__, __LINE__, $db->error());
	if ($db->num_rows($result))
	{
		$style = '';
		$group_style = array();
		while ($cur_group = $db->fetch_assoc($result))
		{
			$group_style = array();
			if (!empty($cur_group['g_colour']))
				$group_style[] = 'color: '.panther_htmlspecialchars($cur_group['g_colour']);

				// Any group except default user group
			if ($cur_group['g_id'] != $panther_config['o_default_user_group'])
				$group_style[] = 'font-weight: bold';

				// Global moderators and admins should be italic
			if ($cur_group['g_global_moderator'] == '1' || $cur_group['g_id'] == PANTHER_ADMIN)
				$group_style[] = 'font-style: italic';

			if (!empty($group_style))
				$style .= '.gid'.$cur_group['g_id'].' {'.implode('; ', $group_style).'} ';
		}
		$db->query('UPDATE '.$db->prefix.'config SET conf_value = \''.$db->escape($style).'\' WHERE conf_name = \'o_colourize_groups\'') or error('Unable to update group colours', __FILE__, __LINE__, $db->error());
	}
	// Get the forum config from the DB
	$result = $db->query('SELECT * FROM '.$db->prefix.'config', true) or error('Unable to fetch forum config', __FILE__, __LINE__, $db->error());

	$output = array();
	while ($cur_config_item = $db->fetch_row($result))
		$output[$cur_config_item[0]] = $cur_config_item[1];

	// Output config as PHP code
	$content = '<?php'."\n\n".'define(\'PANTHER_CONFIG_LOADED\', 1);'."\n\n".'$panther_config = '.var_export($output, true).';'."\n\n".'?>';
	panther_write_cache_file('cache_config.php', $content);
}

//
// Generate the groups cache PHP script
//
function generate_groups_cache()
{
	global $db;
	$output = '<?php'."\n\n".'if (!defined(\'PANTHER\')) exit;'."\n\n".'define(\'PANTHER_GROUPS_LOADED\', 1);'."\n\n".'$panther_groups = array();'."\n\n";

	$result = $db->query('SELECT * FROM '.$db->prefix.'groups ORDER BY g_id ASC') or error('Unable to fetch group list', __FILE__, __LINE__, $db->error());
	while($cur_group = $db->fetch_assoc($result))
		$output .= '$panther_groups[\''.$cur_group['g_id'].'\'] = '.var_export($cur_group, true).';'."\n\n";

	panther_write_cache_file('cache_groups.php', $output);
}

//
// Generate the bans cache PHP script
//
function generate_bans_cache()
{
	global $db;

	// Get the ban list from the DB
	$result = $db->query('SELECT * FROM '.$db->prefix.'bans', true) or error('Unable to fetch ban list', __FILE__, __LINE__, $db->error());

	$output = array();
	while ($cur_ban = $db->fetch_assoc($result))
		$output[] = $cur_ban;

	// Output ban list as PHP code
	$content = '<?php'."\n\n".'define(\'PANTHER_BANS_LOADED\', 1);'."\n\n".'$panther_bans = '.var_export($output, true).';'."\n\n".'?>';
	panther_write_cache_file('cache_bans.php', $content);
}

//
// Generate the ranks cache PHP script
//
function generate_ranks_cache()
{
	global $db;

	// Get the rank list from the DB
	$result = $db->query('SELECT id, rank, min_posts FROM '.$db->prefix.'ranks ORDER BY min_posts', true) or error('Unable to fetch rank list', __FILE__, __LINE__, $db->error());

	$output = array();
	while ($cur_rank = $db->fetch_assoc($result))
		$output[] = $cur_rank;

	$output = '<?php'."\n\n".'define(\'PANTHER_RANKS_LOADED\', 1);'."\n\n".'$panther_ranks = '.var_export($output, true).';'."\n\n".'?>';
	panther_write_cache_file('cache_ranks.php', $output);
}

//
// Generate quick jump cache PHP scripts
//
function generate_quickjump_cache($group_id = false)
{
	global $db, $lang_common, $panther_url, $panther_groups;

	$groups = array();
	$base_url = get_base_url();
	// If a group_id was supplied, we generate the quick jump cache for that group only
	if ($group_id !== false)
		$groups[$group_id] = $panther_groups[$group_id]['g_read_board'];
	else
	{
		// A group_id was not supplied, so we generate the quick jump cache for all groups
		foreach ($panther_groups as $cur_group)
			$groups[$cur_group['g_id']] = $cur_group['g_read_board'];
	}

	// Loop through the groups in $groups and output the cache for each of them
	foreach ($groups as $group_id => $read_board)
	{
		// Output quick jump as PHP code
		$output = '<?php'."\n\n".'if (!defined(\'PANTHER\')) exit;'."\n".'define(\'PANTHER_QJ_LOADED\', 1);'."\n".'$forum_id = isset($forum_id) ? $forum_id : 0;'."\n\n".'?>';

		if ($read_board == '1')
		{
			$result = $db->query('SELECT c.id AS cid, c.cat_name, f.id AS fid, f.forum_name, f.redirect_url, f.parent_forum FROM '.$db->prefix.'categories AS c INNER JOIN '.$db->prefix.'forums AS f ON c.id=f.cat_id LEFT JOIN '.$db->prefix.'forum_perms AS fp ON (fp.forum_id=f.id AND fp.group_id='.$group_id.') WHERE fp.read_forum IS NULL OR fp.read_forum=1 ORDER BY c.disp_position, c.id, f.disp_position') or error('Unable to fetch category/forum list', __FILE__, __LINE__, $db->error());

			if ($db->num_rows($result))
			{
				$output .= "\t\t\t\t".'<form id="qjump" method="get" action="'.$base_url.'/viewforum.php">'."\n\t\t\t\t\t".'<div><label><span><?php echo $lang_common[\'Jump to\'] ?>'.'<br /></span>'."\n\t\t\t\t\t".'<select name="id" onchange="window.location=(\''.get_link($panther_url['forum'], array("'+this.options[this.selectedIndex].value)+'", 'forum-name')).'\'">'."\n"; // It isn't ideal we're not putting the exact forum name in. Maybe re-visit this later.

				$cur_category = 0;
				while ($cur_forum = $db->fetch_assoc($result))
				{
					if ($cur_forum['cid'] != $cur_category) // A new category since last iteration?
					{
						if ($cur_category)
							$output .= "\t\t\t\t\t\t".'</optgroup>'."\n";

						$output .= "\t\t\t\t\t\t".'<optgroup label="'.panther_htmlspecialchars($cur_forum['cat_name']).'">'."\n";
						$cur_category = $cur_forum['cid'];
					}

					$redirect_tag = ($cur_forum['redirect_url'] != '') ? ' &gt;&gt;&gt;' : '';
					$output .= "\t\t\t\t\t\t\t".'<option value="'.$cur_forum['fid'].'"<?php echo ($forum_id == '.$cur_forum['fid'].') ? \' selected="selected"\' : \'\' ?>>'.($cur_forum['parent_forum'] == 0 ? '' : '&nbsp;&nbsp;&nbsp;').panther_htmlspecialchars($cur_forum['forum_name']).$redirect_tag.'</option>'."\n";
				}

				$output .= "\t\t\t\t\t\t".'</optgroup>'."\n\t\t\t\t\t".'</select></label>'."\n\t\t\t\t\t".'<input type="submit" value="<?php echo $lang_common[\'Go\'] ?>" accesskey="g" />'."\n\t\t\t\t\t".'</div>'."\n\t\t\t\t".'</form>'."\n";
			}
		}

		panther_write_cache_file('cache_quickjump_'.$group_id.'.php', $output);
	}
}

//
// Generate the censoring cache PHP script
//
function generate_censoring_cache()
{
	global $db;

	$result = $db->query('SELECT search_for, replace_with FROM '.$db->prefix.'censoring') or error('Unable to fetch censoring list', __FILE__, __LINE__, $db->error());
	$num_words = $db->num_rows($result);

	$search_for = $replace_with = array();
	for ($i = 0; $i < $num_words; $i++)
	{
		list($search_for[$i], $replace_with[$i]) = $db->fetch_row($result);
		$search_for[$i] = '%(?<=[^\p{L}\p{N}])('.str_replace('\*', '[\p{L}\p{N}]*?', preg_quote($search_for[$i], '%')).')(?=[^\p{L}\p{N}])%iu';
	}

	// Output censored words as PHP code
	$content = '<?php'."\n\n".'define(\'PANTHER_CENSOR_LOADED\', 1);'."\n\n".'$search_for = '.var_export($search_for, true).';'."\n\n".'$replace_with = '.var_export($replace_with, true).';'."\n\n".'?>';
	panther_write_cache_file('cache_censoring.php', $content);
}


//
// Generate the stopwords cache PHP script
//
function generate_stopwords_cache()
{
	$stopwords = array();

	$d = dir(PANTHER_ROOT.'lang');
	while (($entry = $d->read()) !== false)
	{
		if ($entry{0} == '.')
			continue;

		if (is_dir(PANTHER_ROOT.'lang/'.$entry) && file_exists(PANTHER_ROOT.'lang/'.$entry.'/stopwords.txt'))
			$stopwords = array_merge($stopwords, file(PANTHER_ROOT.'lang/'.$entry.'/stopwords.txt'));
	}
	$d->close();

	// Tidy up and filter the stopwords
	$stopwords = array_map('panther_trim', $stopwords);
	$stopwords = array_filter($stopwords);

	// Output stopwords as PHP code
	$content = '<?php'."\n\n".'$cache_id = \''.generate_stopwords_cache_id().'\';'."\n".'if ($cache_id != generate_stopwords_cache_id()) return;'."\n\n".'define(\'PANTHER_STOPWORDS_LOADED\', 1);'."\n\n".'$stopwords = '.var_export($stopwords, true).';'."\n\n".'?>';
	panther_write_cache_file('cache_stopwords.php', $content);
}


//
// Load some information about the latest registered users
//
function generate_users_info_cache()
{
	global $db;

	$stats = array();

	$result = $db->query('SELECT COUNT(id)-1 FROM '.$db->prefix.'users WHERE group_id!='.PANTHER_UNVERIFIED) or error('Unable to fetch total user count', __FILE__, __LINE__, $db->error());
	$stats['total_users'] = $db->result($result);

	$result = $db->query('SELECT id, username, group_id FROM '.$db->prefix.'users WHERE group_id!='.PANTHER_UNVERIFIED.' ORDER BY registered DESC LIMIT 1') or error('Unable to fetch newest registered user', __FILE__, __LINE__, $db->error());
	$stats['last_user'] = $db->fetch_assoc($result);

	// Output users info as PHP code
	$content = '<?php'."\n\n".'define(\'PANTHER_USERS_INFO_LOADED\', 1);'."\n\n".'$stats = '.var_export($stats, true).';'."\n\n".'?>';
	panther_write_cache_file('cache_users_info.php', $content);
}


//
// Generate the admins cache PHP script
//
function generate_admins_cache()
{
	global $db;

	// Get admins from the DB
	$result = $db->query('SELECT id FROM '.$db->prefix.'users WHERE group_id='.PANTHER_ADMIN) or error('Unable to fetch users info', __FILE__, __LINE__, $db->error());

	$output = array();
	while ($row = $db->fetch_row($result))
		$output[] = $row[0];

	// Output admin list as PHP code
	$content = '<?php'."\n\n".'define(\'PANTHER_ADMINS_LOADED\', 1);'."\n\n".'$panther_admins = '.var_export($output, true).';'."\n\n".'?>';
	panther_write_cache_file('cache_admins.php', $content);
}


//
// Safely write out a cache file.
//
function panther_write_cache_file($file, $content)
{
	$fh = @fopen(FORUM_CACHE_DIR.$file, 'wb');
	if (!$fh)
		error('Unable to write cache file '.panther_htmlspecialchars($file).' to cache directory. Please make sure PHP has write access to the directory \''.panther_htmlspecialchars(FORUM_CACHE_DIR).'\'', __FILE__, __LINE__);

	flock($fh, LOCK_EX);
	ftruncate($fh, 0);

	fwrite($fh, $content);

	flock($fh, LOCK_UN);
	fclose($fh);

	panther_invalidate_cached_file(FORUM_CACHE_DIR.$file);
}


//
// Delete all feed caches
//
function clear_feed_cache()
{
	$d = dir(FORUM_CACHE_DIR);
	while (($entry = $d->read()) !== false)
	{
		if (substr($entry, 0, 10) == 'cache_feed' && substr($entry, -4) == '.php')
			@unlink(FORUM_CACHE_DIR.$entry);
			panther_invalidate_cached_file(FORUM_CACHE_DIR.$entry);
	}
	$d->close();
}


//
// Invalidate updated php files that are cached by an opcache
//
function panther_invalidate_cached_file($file)
{
	if (function_exists('opcache_invalidate'))
		opcache_invalidate($file, true);
	elseif (function_exists('apc_delete_file'))
		@apc_delete_file($file);
}

//
// Generate forum permissions cache script
//

function generate_perms_cache()
{
	global $db, $lang_common, $panther_user;

	$groups = array();

	$fh = @fopen(FORUM_CACHE_DIR.'cache_perms.php', 'wb');
	if (!$fh)
		error('Unable to write forum permissions cache files to cache directory. Please make sure PHP has write access to the directory \''.panther_htmlspecialchars(FORUM_CACHE_DIR).'\'', __FILE__, __LINE__);

	$output = '<?php'."\n\n".'if (!defined(\'PANTHER\')) exit;'."\n\n".'define(\'PANTHER_FP_LOADED\', 1);'."\n"."\n\n".'$perms = array();'."\n\n";

	// A group_id was not supplied, so we generate the permission cache for all groups
	$result = $db->query('SELECT g.g_read_board, fp.group_id AS id, fp.forum_id, fp.read_forum, fp.post_replies, fp.post_topics FROM '.$db->prefix.'groups AS g LEFT JOIN '.$db->prefix.'forum_perms AS fp ON g.g_id = fp.group_id ORDER BY fp.group_id ASC') or error('Unable to fetch user group list', __FILE__, __LINE__, $db->error());
	while ($group = $db->fetch_assoc($result))
	{
		$groups = array('read_board' => $group['g_read_board'], 'forum_id' => $group['forum_id'], 'read_forum' => $group['read_forum'], 'post_replies' => $group['post_replies'], 'post_topics' => $group['post_topics']);

		$output .= '$perms[\''.$group['id'].'_'.$group['forum_id'].'\'] = '.var_export($groups, true).';'."\n\n";
	}

	fwrite($fh, $output);

	fclose($fh);

	if (function_exists('apc_delete_file'))
		@apc_delete_file(FORUM_CACHE_DIR.'cache_perms.php');

}

//
// Generate admin restrictions cache script
//

function generate_admin_restrictions_cache()
{
	global $db;

	$fh = @fopen(FORUM_CACHE_DIR.'cache_admin.php', 'wb');
	if (!$fh)
		error('Unable to write forum permissions cache files to cache directory. Please make sure PHP has write access to the directory \''.panther_htmlspecialchars(FORUM_CACHE_DIR).'\'', __FILE__, __LINE__);

	$output = '<?php'."\n\n".'if (!defined(\'PANTHER\')) exit;'."\n"."\n\n".'$admins = array();'."\n\n";
	$admins = array();
	$default = array('admin_options' => '1', 'admin_permissions' => '1', 'admin_categories' => '1', 'admin_forums' => '1', 'admin_groups' => '1', 'admin_censoring' => '1', 'admin_maintenance' => '1', 'admin_plugins' => '1', 'admin_ranks' => '1', 'admin_moderate' => '1', 'admin_restrictions' => '1');

	$result = $db->query('SELECT id FROM '.$db->prefix.'users WHERE group_id = '.PANTHER_ADMIN.' AND id != \'2\' ORDER BY id ASC') or error('Unable to fetch user group list', __FILE__, __LINE__, $db->error());
	while ($user = $db->fetch_assoc($result))
	{
		$query = $db->query('SELECT admin_opt AS opt, admin_perms AS perms, admin_cats AS cats, admin_forums AS forums, admin_groups AS groups, admin_censoring AS censoring, admin_maintenance AS maintenance, admin_plugins AS plugins, admin_rest AS rest, admin_users AS users, admin_moderate AS moderate, admin_ranks AS ranks FROM '.$db->prefix.'admin_restrictions WHERE admin_id = '.$user['id']) or error('Unable to fetch user group list', __FILE__, __LINE__, $db->error());
		while ($admin = $db->fetch_assoc($query))
		{
			$array = array('admin_options' => $admin['opt'], 'admin_permissions' => $admin['perms'], 'admin_categories' => $admin['cats'], 'admin_forums' => $admin['forums'], 'admin_groups' => $admin['groups'], 'admin_users' => $admin['users'], 'admin_censoring' => $admin['censoring'], 'admin_maintenance' => $admin['maintenance'], 'admin_moderate' => $admin['moderate'], 'admin_plugins' => $admin['plugins'], 'admin_restrictions' => $admin['rest'], 'admin_ranks' => $admin['ranks']);
			
			if (empty($array) || empty($admin))
				$array = $default;
				
			$output .= '$admins[\''.$user['id'].'\'] = '.var_export($array, true).';'."\n\n";
		}
	}
	
	fwrite($fh, $output);

	fclose($fh);

	if (function_exists('apc_delete_file'))
		@apc_delete_file(FORUM_CACHE_DIR.'cache_admin.php');

}

//
// Check for updates to panther
//
function generate_update_cache()
{
	global $db, $panther_config, $lang_admin_index;

	if (!ini_get('allow_url_fopen'))
		message($lang_admin_index['fopen disabled message']);

	$output = trim(@file_get_contents('http://panther.strongholdnation.co.uk/update_check.php')); // If we're behind a few versions, we need to get only the next version to avoid conflicts
	if (empty($output))
		message($lang_admin_index['Upgrade check failed message']);
	
	// Decode the response and set it as the new cache
	$output = array_map('panther_htmlspecialchars', json_decode($output, true));
	$output['cached'] = time();

	$content = '<?php'."\n\n".'define(\'PANTHER_UPDATES_LOADED\', 1);'."\n\n".'$panther_updates = '.var_export($output, true).';'."\n\n".'?>';
	panther_write_cache_file('cache_updates.php', $content);

	return $output;
}

define('FORUM_CACHE_FUNCTIONS_LOADED', true);