<?php
/**
 * Copyright (C) 2015 Panther (http://panther.strongholdnation.co.uk/)
 * based on code by Rickard Andersson copyright (C) 2002-2008 pantherBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/');
	require PANTHER_ROOT.'include/common.php';
}
define('REPUTATION', 1);

if ($panther_user['g_read_board'] == '0')
	message($lang_common['No view'], false, '403 Forbidden');

$action = isset($_GET['action']) ? $_GET['action'] : null;
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$pid = isset($_GET['pid']) ? intval($_GET['pid']) : 0;
if ($id < 1 && $pid < 1)
	message($lang_common['Bad request'], false, '404 Not Found');

// Load the viewtopic.php language file
require PANTHER_ROOT.'lang/'.$panther_user['language'].'/topic.php';

// If a post ID is specified we determine topic ID and page number so we can redirect to the correct message
if ($pid)
{
	$result = $db->query('SELECT topic_id, posted FROM '.$db->prefix.'posts WHERE id='.$pid.' AND approved=1') or error('Unable to fetch topic ID', __FILE__, __LINE__, $db->error());
	if (!$db->num_rows($result))
		message($lang_common['Bad request'], false, '404 Not Found');
	else
		list($id, $posted) = $db->fetch_row($result);

	// Determine on which page the post is located (depending on $forum_user['disp_posts'])
	$result = $db->query('SELECT COUNT(id) FROM '.$db->prefix.'posts WHERE topic_id='.$id.' AND posted<'.$posted.' AND approved=1') or error('Unable to count previous posts', __FILE__, __LINE__, $db->error());
	$num_posts = $db->result($result) + 1;

	$_GET['p'] = ceil($num_posts / $panther_user['disp_posts']);
}
else
{
	// If action=new, we redirect to the first new post (if any)
	if ($action == 'new')
	{
		if (!$panther_user['is_guest'])
		{
			// We need to check if this topic has been viewed recently by the user
			$tracked_topics = get_tracked_topics();
			$last_viewed = isset($tracked_topics['topics'][$id]) ? $tracked_topics['topics'][$id] : $panther_user['last_visit'];

			$result = $db->query('SELECT MIN(id) FROM '.$db->prefix.'posts WHERE topic_id='.$id.' AND posted>'.$last_viewed.' AND approved=1') or error('Unable to fetch first new post info', __FILE__, __LINE__, $db->error());
			$first_new_post_id = $db->result($result);

			if ($first_new_post_id)
			{
				header('Location: '.get_link($panther_url['post'], array($first_new_post_id)));
				exit;
			}
		}

		// If there is no new post, we go to the last post
		$action = 'last';
	}

	// If action=last, we redirect to the last post
	if ($action == 'last')
	{
		$result = $db->query('SELECT MAX(id) FROM '.$db->prefix.'posts WHERE topic_id='.$id.' AND approved=1') or error('Unable to fetch last post info', __FILE__, __LINE__, $db->error());
		$last_post_id = $db->result($result);

		if ($last_post_id)
		{
			header('Location: '.get_link($panther_url['post'], array($last_post_id)));
			exit;
		}
	}
}

// Fetch some info about the topic
if (!$panther_user['is_guest'])
	$result = $db->query('SELECT pf.forum_name AS parent, f.parent_forum, t.subject, t.closed, t.num_replies, t.sticky, t.first_post_id, f.id AS forum_id, f.forum_name, f.use_reputation, f.moderators, fp.post_replies, fp.download, s.user_id AS is_subscribed FROM '.$db->prefix.'topics AS t INNER JOIN '.$db->prefix.'forums AS f ON f.id=t.forum_id LEFT JOIN '.$db->prefix.'topic_subscriptions AS s ON (t.id=s.topic_id AND s.user_id='.$panther_user['id'].') LEFT JOIN '.$db->prefix.'forum_perms AS fp ON (fp.forum_id=f.id AND fp.group_id='.$panther_user['g_id'].') LEFT JOIN '.$db->prefix.'forums AS pf ON f.parent_forum=pf.id WHERE (fp.read_forum IS NULL OR fp.read_forum=1) AND t.id='.$id.' AND t.moved_to IS NULL AND t.approved=1') or error('Unable to fetch topic info', __FILE__, __LINE__, $db->error());
else
	$result = $db->query('SELECT pf.forum_name AS parent, f.parent_forum, t.subject, t.closed, t.num_replies, t.sticky, t.first_post_id, f.id AS forum_id, f.forum_name, f.use_reputation, f.moderators, fp.post_replies, fp.download, 0 AS is_subscribed FROM '.$db->prefix.'topics AS t INNER JOIN '.$db->prefix.'forums AS f ON f.id=t.forum_id LEFT JOIN '.$db->prefix.'forum_perms AS fp ON (fp.forum_id=f.id AND fp.group_id='.$panther_user['g_id'].') LEFT JOIN '.$db->prefix.'forums AS pf ON f.parent_forum=pf.id WHERE (fp.read_forum IS NULL OR fp.read_forum=1) AND t.id='.$id.' AND t.moved_to IS NULL AND t.approved=1') or error('Unable to fetch topic info', __FILE__, __LINE__, $db->error());

if (!$db->num_rows($result))
	message($lang_common['Bad request'], false, '404 Not Found');
else
	$cur_topic = $db->fetch_assoc($result);

// Sort out who the moderators are and if we are currently a moderator (or an admin)
$mods_array = ($cur_topic['moderators'] != '') ? unserialize($cur_topic['moderators']) : array();
$is_admmod = ($panther_user['g_id'] == PANTHER_ADMIN || ($panther_user['g_moderator'] == '1' && $panther_user['g_global_moderator'] ||  array_key_exists($panther_user['username'], $mods_array))) ? true : false;
if ($is_admmod)
	$admin_ids = get_admin_ids();

// Can we or can we not post replies?
if ($cur_topic['closed'] == '0')
{
	if (($cur_topic['post_replies'] == '' && $panther_user['g_post_replies'] == '1') || $cur_topic['post_replies'] == '1' || $is_admmod)
		$post_link = "\t\t\t".'<p class="postlink conr"><a href="'.get_link($panther_url['new_reply'], array($id)).'">'.$lang_topic['Post reply'].'</a></p>'."\n";
	else
		$post_link = '';
}
else
{
	$post_link = $lang_topic['Topic closed'];

	if ($is_admmod)
		$post_link .= ' / <a href="'.get_link($panther_url['new_reply'], array($id)).'">'.$lang_topic['Post reply'].'</a>';

	$post_link = "\t\t\t".'<p class="postlink conr">'.$post_link.'</p>'."\n";
}

// Add/update this topic in our list of tracked topics
if (!$panther_user['is_guest'])
{
	$tracked_topics = get_tracked_topics();
	$tracked_topics['topics'][$id] = time();
	set_tracked_topics($tracked_topics);
}

// Preg replace is slow!
$url_subject = url_friendly($cur_topic['subject']);
$url_forum = url_friendly($cur_topic['forum_name']);

// Determine the post offset (based on $_GET['p'])
$num_pages = ceil(($cur_topic['num_replies'] + 1) / $panther_user['disp_posts']);

$p = (!isset($_GET['p']) || $_GET['p'] <= 1 || $_GET['p'] > $num_pages) ? 1 : intval($_GET['p']);
$start_from = $panther_user['disp_posts'] * ($p - 1);

// Generate paging links
$paging_links = '<span class="pages-label">'.$lang_common['Pages'].' </span>'.paginate($num_pages, $p, $panther_url['topic_paginate'], array($id, $url_subject));

if ($panther_config['o_censoring'] == '1')
	$cur_topic['subject'] = censor_words($cur_topic['subject']);

$quickpost = false;
if ($panther_config['o_quickpost'] == '1' &&
	($cur_topic['post_replies'] == '1' || ($cur_topic['post_replies'] == '' && $panther_user['g_post_replies'] == '1')) &&
	($cur_topic['closed'] == '0' || $is_admmod))
{
	// Load the post.php language file
	require PANTHER_ROOT.'lang/'.$panther_user['language'].'/post.php';

	$required_fields = array('req_message' => $lang_common['Message']);
	if ($panther_user['is_guest'])
	{
		$required_fields['req_username'] = $lang_post['Guest name'];
		if ($panther_config['p_force_guest_email'] == '1')
			$required_fields['req_email'] = $lang_common['Email'];
	}
	$quickpost = true;
}

if (!$panther_user['is_guest'] && $panther_config['o_topic_subscriptions'] == '1')
{
	if ($cur_topic['is_subscribed'])
		// I apologize for the variable naming here. It's a mix of subscription and action I guess :-)
		$subscraction = "\t\t".'<p class="subscribelink clearb"><span>'.$lang_topic['Is subscribed'].' - </span><a href="'.get_link($panther_url['topic_unsubscribe'], array($id)).'">'.$lang_topic['Unsubscribe'].'</a></p>'."\n";
	else
		$subscraction = "\t\t".'<p class="subscribelink clearb"><a href="'.get_link($panther_url['topic_subscribe'], array($id)).'">'.$lang_topic['Subscribe'].'</a></p>'."\n";
}
else
	$subscraction = '';

// Add relationship meta tags
$page_head = array();
$page_head['canonical'] = '<link rel="canonical" href="'.get_link($panther_url['topic_page'], array($id, $p, $url_subject)).'" title="'.sprintf($lang_common['Page'], $p).'" />';

if ($num_pages > 1)
{
	if ($p > 1)
		$page_head['prev'] = '<link rel="prev" href="'.get_link($panther_url['topic_page'], array($id, ($p - 1), $url_subject)).'" title="'.sprintf($lang_common['Page'], $p - 1).'" />';
	if ($p < $num_pages)
		$page_head['next'] = '<link rel="next" href="'.get_link($panther_url['topic'], array($id, ($p + 1), $url_subject)).'" title="'.sprintf($lang_common['Page'], $p + 1).'" />';
}

if ($panther_config['o_feed_type'] == '1')
	$page_head['feed'] = '<link rel="alternate" type="application/rss+xml" href="'.get_link($panther_url['topic_rss'], array($id)).'" title="'.$lang_common['RSS topic feed'].'" />';
else if ($panther_config['o_feed_type'] == '2')
	$page_head['feed'] = '<link rel="alternate" type="application/atom+xml" href="'.get_link($panther_url['topic_atom'], array($id)).'" title="'.$lang_common['Atom topic feed'].'" />';

$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), panther_htmlspecialchars($cur_topic['forum_name']), panther_htmlspecialchars($cur_topic['subject']));
define('PANTHER_ALLOW_INDEX', 1);
define('PANTHER_ACTIVE_PAGE', 'index');
require PANTHER_ROOT.'header.php';
?>
<div class="linkst">
	<div class="inbox crumbsplus">
		<ul class="crumbs">
			<li><a href="<?php echo get_link($panther_url['index']) ?>"><?php echo $lang_common['Index'] ?></a></li>
			<?php if ($cur_topic['parent']) echo "\t\t".'<li><span>»&#160;</span><a href="'.get_link($panther_url['forum'], array($cur_topic['parent_forum'], url_friendly($cur_topic['parent']))).'">'.panther_htmlspecialchars($cur_topic['parent']).'</a></li> '; ?>
			<li><span>»&#160;</span><a href="<?php echo get_link($panther_url['forum'], array($cur_topic['forum_id'], $url_forum)) ?>"><?php echo panther_htmlspecialchars($cur_topic['forum_name']) ?></a></li>
			<li><span>»&#160;</span><strong><a href="<?php echo get_link($panther_url['topic'], array($id, $url_subject)) ?>"><?php echo panther_htmlspecialchars($cur_topic['subject']) ?></a></strong></li>
		</ul>
		<div class="pagepost">
			<p class="pagelink conl"><?php echo $paging_links ?></p>
<?php echo $post_link ?>
		</div>
		<div class="clearer"></div>
	</div>
</div>
<?php
require PANTHER_ROOT.'include/parser.php';
$post_count = 0; // Keep track of post numbers

// Retrieve a list of post IDs, LIMIT is (really) expensive so we only fetch the IDs here then later fetch the remaining data
$result = $db->query('SELECT id FROM '.$db->prefix.'posts WHERE topic_id='.$id.' AND approved=1 ORDER BY id LIMIT '.$start_from.','.$panther_user['disp_posts']) or error('Unable to fetch post IDs', __FILE__, __LINE__, $db->error());

$post_ids = array();
for ($i = 0;$cur_post_id = $db->result($result, $i);$i++)
	$post_ids[] = $cur_post_id;

if (empty($post_ids))
	error('The post table and topic table seem to be out of sync!', __FILE__, __LINE__);

// Retrieve the posts (and their respective poster/online status)

$results = array();
$download = false;
if ($panther_user['g_id'] == PANTHER_ADMIN)
	$download = true;
else if ($cur_topic['download'] == '1' || $cur_topic['download'] == '')
	$download = true;

if ($download)
{
	$result = $db->query('SELECT id, filename, post_id, size, downloads FROM '.$db->prefix.'attachments WHERE post_id IN ('.implode(',', $post_ids).') ORDER BY post_id') or error('Unable to fetch any attachments', __FILE__, __LINE__, $db->error());
	while ($cur_attach = $db->fetch_assoc($result))
	{
		if (!isset($results[$cur_attach['post_id']]))
			$results[$cur_attach['post_id']] = array();

		$results[$cur_attach['post_id']][$cur_attach['id']] = $cur_attach;
	}
}

$result = $db->query('SELECT u.email, u.title, u.url, u.location, u.signature, u.email_setting, u.num_posts, u.registered, u.admin_note, u.reputation AS poster_reputation, p.id, p.reputation, p.poster AS username, p.poster_id, p.poster_ip, p.poster_email, p.message, p.hide_smilies, p.posted, p.edited, p.edit_reason, p.edited_by, g.g_id, g.g_user_title, g.g_promote_next_group, o.user_id AS is_online FROM '.$db->prefix.'posts AS p INNER JOIN '.$db->prefix.'users AS u ON u.id=p.poster_id INNER JOIN '.$db->prefix.'groups AS g ON g.g_id=u.group_id LEFT JOIN '.$db->prefix.'online AS o ON (o.user_id=u.id AND o.user_id!=1 AND o.idle=0) WHERE p.id IN ('.implode(',', $post_ids).') ORDER BY p.id', true) or error('Unable to fetch post info', __FILE__, __LINE__, $db->error());
$base_url = get_base_url(true);
while ($cur_post = $db->fetch_assoc($result))
{
	$post_count++;
	$user_avatar = '';
	$user_info = array();
	$user_contacts = array();
	$post_actions = array();
	$is_online = '';
	$signature = '';

	// If the poster is a registered user
	if ($cur_post['poster_id'] > 1)
	{
		$username = colourize_group($cur_post['username'], $cur_post['g_id'], $cur_post['poster_id']);

		$user_title = get_title($cur_post);

		if ($panther_config['o_censoring'] == '1')
			$user_title = censor_words($user_title);

		// Format the online indicator
		$is_online = ($cur_post['is_online'] == $cur_post['poster_id']) ? '<strong>'.$lang_topic['Online'].'</strong>' : '<span>'.$lang_topic['Offline'].'</span>';

		if ($panther_config['o_avatars'] == '1' && $panther_user['show_avatars'] != '0')
			$user_avatar = generate_avatar_markup($cur_post['poster_id']);

		// We only show location, register date, post count and the contact links if "Show user info" is enabled
		if ($panther_config['o_show_user_info'] == '1')
		{
			if ($cur_post['location'] != '')
			{
				if ($panther_config['o_censoring'] == '1')
					$cur_post['location'] = censor_words($cur_post['location']);

				$user_info[] = '<dd><span>'.$lang_topic['From'].' '.panther_htmlspecialchars($cur_post['location']).'</span></dd>';
			}

			$user_info[] = '<dd><span>'.$lang_topic['Registered'].' '.format_time($cur_post['registered'], true).'</span></dd>';

			if ($panther_config['o_show_post_count'] == '1' || $panther_user['is_admmod'])
				$user_info[] = '<dd><span>'.$lang_topic['Posts'].' '.forum_number_format($cur_post['num_posts']).'</span></dd>';

			// Now let's deal with the contact links (Email and URL)
			if ((($cur_post['email_setting'] == '0' && !$panther_user['is_guest']) || $panther_user['is_admmod']) && $panther_user['g_send_email'] == '1')
				$user_contacts[] = '<span class="email"><a href="mailto:'.panther_htmlspecialchars($cur_post['email']).'">'.$lang_common['Email'].'</a></span>';
			else if ($cur_post['email_setting'] == '1' && !$panther_user['is_guest'] && $panther_user['g_send_email'] == '1')
				$user_contacts[] = '<span class="email"><a href="'.get_link($panther_url['email'], array($cur_post['poster_id'])).'">'.$lang_common['Email'].'</a></span>';

			if ($cur_post['url'] != '')
			{
				if ($panther_config['o_censoring'] == '1')
					$cur_post['url'] = censor_words($cur_post['url']);

				$user_contacts[] = '<span class="website"><a href="'.panther_htmlspecialchars($cur_post['url']).'" rel="nofollow">'.$lang_topic['Website'].'</a></span>';
			}
		}

		if ($panther_user['g_id'] == PANTHER_ADMIN || ($panther_user['g_moderator'] == '1' && $panther_user['g_mod_promote_users'] == '1'))
		{
			if ($cur_post['g_promote_next_group'])
				$user_info[] = '<dd><span><a href="'.get_link($panther_url['profile_promote'], array($cur_post['poster_id'], $cur_post['id'])).'">'.$lang_topic['Promote user'].'</a></span></dd>';
		}

		if ($panther_user['is_admmod'])
		{
			$user_info[] = '<dd><span><a href="'.get_link($panther_url['get_host'], array($cur_post['id'])).'" title="'.panther_htmlspecialchars($cur_post['poster_ip']).'">'.$lang_topic['IP address logged'].'</a></span></dd>';

			if ($cur_post['admin_note'] != '')
				$user_info[] = '<dd><span>'.$lang_topic['Note'].' <strong>'.panther_htmlspecialchars($cur_post['admin_note']).'</strong></span></dd>';
		}
	}
	// If the poster is a guest (or a user that has been deleted)
	else
	{
		$username = colourize_group($cur_post['username'], $cur_post['g_id']);
		$user_title = get_title($cur_post);

		if ($panther_user['is_admmod'])
			$user_info[] = '<dd><span><a href="'.get_link($panther_url['get_host'], array($cur_post['id'])).'" title="'.panther_htmlspecialchars($cur_post['poster_ip']).'">'.$lang_topic['IP address logged'].'</a></span></dd>';

		if ($panther_config['o_show_user_info'] == '1' && $cur_post['poster_email'] != '' && !$panther_user['is_guest'] && $panther_user['g_send_email'] == '1')
			$user_contacts[] = '<span class="email"><a href="mailto:'.panther_htmlspecialchars($cur_post['poster_email']).'">'.$lang_common['Email'].'</a></span>';
	}

	if ($panther_config['o_reputation'] == '1')
	{
		switch(true)
		{
			case $cur_post['poster_id'] == 1:
				$type = 'zero';
			break;
			case $cur_post['poster_reputation'] > '0':
				$type = 'positive';
			break;
			case $cur_post['poster_reputation'] < '0':
				$type = 'negative';
			break;
			default:
				$type = 'zero';
			break;
		}

		$cur_post['poster_reputation'] = '<span class="reputation '.$type.'">'.sprintf($lang_topic['reputation'], $cur_post['poster_reputation']).'</span><br /><br />';
		if ($cur_topic['use_reputation'] == '1')
		{
			switch(true)
			{
				case $cur_post['reputation'] > '0':
					$type = 'positive';
				break;
				case $cur_post['reputation'] < '0':
					$type = 'negative';
				break;
				default:
					$type = 'zero';
				break;
			}

			if ($cur_post['poster_id'] != 1)
			{
				if ($cur_post['poster_id'] != $panther_user['id'] && $panther_user['g_rep_enabled'] == '1' && ($cur_topic['closed'] == '0' || $is_admmod))
				{
					$actions = array();
					if ($panther_config['o_rep_type'] != 3)
						$actions[] = '<img src="'.$base_url.'/img/plus.png" style="cursor:pointer;" onclick="reputation(1, '.$cur_post['id'].')" id="vote" width="16" height="16" />';

					if ($panther_config['o_rep_type'] != 2)
						$actions[] = '<img src="'.$base_url.'/img/minus.png" style="cursor:pointer;" onclick="reputation(-1,'.$cur_post['id'].')" id="vote" width="16" height="16" />';

					if (count($actions) > 0)
					{
						if ($cur_topic['first_post_id'] == $cur_post['id'])
							$post_actions[] = $lang_topic['topic helpful'].implode('&nbsp;&nbsp;', $actions);
						else
							$post_actions[] = $lang_topic['post helpful'].implode('&nbsp;&nbsp;', $actions);
					}
				}				
				$post_actions[] = '<span id="post_rep_'.$cur_post['id'].'" class="reputation '.$type.'">'.$cur_post['reputation'].'</span>';
			}
		}
	}

	// Generation post action array (quote, edit, delete etc.)
	if (!$is_admmod)
	{
		if (!$panther_user['is_guest'])
			$post_actions[] = '<li class="postreport"><span><a href="'.get_link($panther_url['report'], array($cur_post['id'])).'">'.$lang_topic['Report'].'</a></span></li>';

		if ($cur_topic['closed'] == '0')
		{
			if ($cur_post['poster_id'] == $panther_user['id'])
			{
				if ((($start_from + $post_count) == 1 && $panther_user['g_delete_topics'] == '1') || (($start_from + $post_count) > 1 && $panther_user['g_delete_posts'] == '1'))
					$post_actions[] = '<li class="postdelete"><span><a href="'.get_link($panther_url['delete'], array($cur_post['id'])).'">'.$lang_topic['Delete'].'</a></span></li>';
				if ($panther_user['g_edit_posts'] == '1')
					$post_actions[] = '<li class="postedit"><span><a href="'.get_link($panther_url['edit'], array($cur_post['id'])).'">'.$lang_topic['Edit'].'</a></span></li>';
			}

			if (($cur_topic['post_replies'] == '' && $panther_user['g_post_replies'] == '1') || $cur_topic['post_replies'] == '1')
				$post_actions[] = '<li class="postquote"><span><a href="'.get_link($panther_url['quote'], array($id, $cur_post['id'])).'">'.$lang_topic['Quote'].'</a></span></li>';
		}
	}
	else
	{
		$post_actions[] = '<li class="postreport"><span><a href="'.get_link($panther_url['report'], array($cur_post['id'])).'">'.$lang_topic['Report'].'</a></span></li>';
		if ($panther_user['g_id'] == PANTHER_ADMIN || !in_array($cur_post['poster_id'], $admin_ids))
		{
			$post_actions[] = '<li class="postdelete"><span><a href="'.get_link($panther_url['delete'], array($cur_post['id'])).'">'.$lang_topic['Delete'].'</a></span></li>';
			$post_actions[] = '<li class="postedit"><span><a href="'.get_link($panther_url['edit'], array($cur_post['id'])).'">'.$lang_topic['Edit'].'</a></span></li>';
		}
		$post_actions[] = '<li class="postquote"><span><a href="'.get_link($panther_url['quote'], array($id, $cur_post['id'])).'">'.$lang_topic['Quote'].'</a></span></li>';
	}

	// Perform the main parsing of the message (BBCode, smilies, censor words etc)
	$cur_post['message'] = parse_message($cur_post['message'], $cur_post['hide_smilies']);

	// Do signature parsing/caching
	if ($panther_config['o_signatures'] == '1' && $cur_post['signature'] != '' && $panther_user['show_sig'] != '0')
	{
		if (isset($signature_cache[$cur_post['poster_id']]))
			$signature = $signature_cache[$cur_post['poster_id']];
		else
		{
			$signature = parse_signature($cur_post['signature']);
			$signature_cache[$cur_post['poster_id']] = $signature;
		}
	}

	$attachments = '';
	if ($download && isset($results[$cur_post['id']]) && count($results[$cur_post['id']]) > 0)
	{
		$attachments = $lang_topic['Attachments'];
		foreach ($results[$cur_post['id']] as $cur_attach)
			$attachments .= '<br />'."\n\t\t\t\t\t\t".attach_icon(attach_get_extension($cur_attach['filename'])).' <a href="'.get_link($panther_url['attachment'], array($cur_attach['id'])).'">'.panther_htmlspecialchars($cur_attach['filename']).'</a>, '.sprintf($lang_topic['Attachment size'], file_size($cur_attach['size'])).', '.sprintf($lang_topic['Attachment downloads'], forum_number_format($cur_attach['downloads']));
	}
?>
<div id="p<?php echo $cur_post['id'] ?>" class="blockpost<?php echo ($post_count % 2 == 0) ? ' roweven' : ' rowodd' ?><?php if ($cur_post['id'] == $cur_topic['first_post_id']) echo ' firstpost'; ?><?php if ($post_count == 1) echo ' blockpost1'; ?>">
	<h2><span><span class="conr">#<?php echo ($start_from + $post_count) ?></span> <a href="<?php echo get_link($panther_url['post'], array($cur_post['id'])) ?>"><?php echo format_time($cur_post['posted']) ?></a></span></h2>
	<div class="box">
		<div class="inbox">
			<div class="postbody">
				<div class="postleft">
					<dl>
						<dt><strong><?php echo $username ?></strong></dt>
						<dd class="usertitle"><strong><?php echo $user_title ?></strong></dd>
<?php if ($panther_config['o_reputation'] == '1') echo "\t\t\t\t\t\t".'<dd>'.$cur_post['poster_reputation'].'</dd>'."\n"; ?>
<?php if ($user_avatar != '') echo "\t\t\t\t\t\t".'<dd class="postavatar">'.$user_avatar.'</dd>'."\n"; ?>
<?php if (count($user_info)) echo "\t\t\t\t\t\t".implode("\n\t\t\t\t\t\t", $user_info)."\n"; ?>
<?php if (count($user_contacts)) echo "\t\t\t\t\t\t".'<dd class="usercontacts">'.implode(' ', $user_contacts).'</dd>'."\n"; ?>
					</dl>
				</div>
				<div class="postright">
					<h3><?php if ($cur_post['id'] != $cur_topic['first_post_id']) echo $lang_topic['Re'].' '; ?><?php echo panther_htmlspecialchars($cur_topic['subject']) ?></h3>
					<div class="postmsg">
						<?php echo $cur_post['message']."\n" ?>
<?php if ($cur_post['edited'] != '') echo "\t\t\t\t\t\t".'<p class="postedit"><em>'.$lang_topic['Last edit'].' '.panther_htmlspecialchars($cur_post['edited_by']).' ('.format_time($cur_post['edited']).')</em></p>'."\n"; ?>
<?php if ($cur_post['edit_reason'] != '') echo "\t\t\t\t\t\t".'<p class="postedit">'.sprintf($lang_topic['Edit reason'], panther_htmlspecialchars($cur_post['edit_reason'])).'</strong></p>'."\n"; ?>
<?php if ($attachments != '') echo "\t\t\t\t\t".'<div class="postsignature"><hr />'.$attachments.'</div>'."\n"; ?>
					</div>
<?php if ($signature != '') echo "\t\t\t\t\t".'<div class="postsignature postmsg"><hr />'.$signature.'</div>'."\n"; ?>
				</div>
			</div>
		</div>
		<div class="inbox">
			<div class="postfoot clearb">
				<div class="postfootleft"><?php if ($cur_post['poster_id'] > 1) echo '<p>'.$is_online.'</p>'; ?></div>
<?php if (count($post_actions)) echo "\t\t\t\t".'<div class="postfootright">'."\n\t\t\t\t\t".'<ul>'."\n\t\t\t\t\t\t".implode("\n\t\t\t\t\t\t", $post_actions)."\n\t\t\t\t\t".'</ul>'."\n\t\t\t\t".'</div>'."\n" ?>
			</div>
		</div>
	</div>
</div>
<?php
}
?>
<div class="postlinksb">
	<div class="inbox crumbsplus">
		<div class="pagepost">
			<p class="pagelink conl"><?php echo $paging_links ?></p>
<?php echo $post_link ?>
		</div>
		<ul class="crumbs">
			<li><a href="<?php echo get_link($panther_url['index']) ?>"><?php echo $lang_common['Index'] ?></a></li>
			<?php if ($cur_topic['parent']) echo "\t\t".'<li><span>»&#160;</span><a href="'.get_link($panther_url['forum'], array($cur_topic['parent_forum'], url_friendly($cur_topic['parent']))).'">'.panther_htmlspecialchars($cur_topic['parent']).'</a></li> '; ?>
			<li><span>»&#160;</span><a href="<?php echo get_link($panther_url['forum'], array($cur_topic['forum_id'], $url_forum)) ?>"><?php echo panther_htmlspecialchars($cur_topic['forum_name']) ?></a></li>
			<li><span>»&#160;</span><strong><a href="<?php echo get_link($panther_url['topic'], array($id, $url_subject)) ?>"><?php echo panther_htmlspecialchars($cur_topic['subject']) ?></a></strong></li>
		</ul>
<?php echo $subscraction ?>
		<div class="clearer"></div>
	</div>
</div>
<?php
if ($panther_config['o_users_online'] == '1') /* ALTER */
{
	require PANTHER_ROOT.'lang/'.$panther_user['language'].'/online.php';
	$guests_in_topic = $users = array();

	$online = $db->query("SELECT o.user_id, o.ident, o.currently, o.logged, u.group_id FROM ".$db->prefix."online AS o INNER JOIN ".$db->prefix."users AS u ON u.id=o.user_id WHERE o.currently LIKE '%viewtopic.php%' AND o.idle = 0", true) or error('Unable to get current location from viewtopic.php', __FILE__, __LINE__, $db->error());
	while ($user_online = $db->fetch_assoc($online))
	{
		if (strpos($user_online['currently'], '&p=')!== false)
		{
			preg_match('~&p=(.*)~', $user_online['currently'], $replace);
			$user_online['currently'] = str_replace($replace[0], '', $user_online['currently']);
		}
		$tid = filter_var($user_online['currently'], FILTER_SANITIZE_NUMBER_INT);
	

		if (strpos($user_online['currently'], '?pid') !== false)
		{
			if (in_array($tid, $post_ids))
			{
				if ($user_online['user_id'] == 1)
					$guests_in_topic[] = $user_online['ident'];
				else
					$users[] = colourize_group($user_online['ident'], $user_online['group_id'], $user_online['user_id']);
			}
		}
		elseif (strpos($user_online['currently'], '?id') !== false)
		{
			if ($tid == $id)
			{
				if ($user_online['user_id'] == 1)
					$guests_in_topic[] = $user_online['ident'];
				else
					$users[] = colourize_group($user_online['ident'], $user_online['group_id'], $user_online['user_id']);
			}
		}
			 
	}
	$num_guests = count($guests_in_topic);
	$num_users = count($users);
?>
<div id="brdstats" class="block">
	<div class="box">
		<div class="inbox">	
<?php
	if ($num_users > 0)
		$users = implode(', ', $users);
	else
		$users = $lang_online['no users'];

		echo "\t\t\t".'<dl id="onlinelist" class="clearb">'.sprintf($lang_online['online topic'], $num_guests, $users)."\n";
?>					
		</div>
	</div>
</div>
<?php 
}

// Display quick post if enabled
if ($quickpost)
{
	$cur_index = 1;
?>
<div id="quickpost" class="blockform">
	<h2><span><?php echo $lang_topic['Quick post'] ?></span></h2>
	<div class="box">
		<form id="quickpostform" method="post" action="<?php echo get_link($panther_url['new_reply'], array($id)) ?>" onsubmit="this.submit.disabled=true;if(process_form(this)){return true;}else{this.submit.disabled=false;return false;}">
			<div class="inform">
				<fieldset>
					<legend><?php echo $lang_common['Write message legend'] ?></legend>
					<div class="infldset txtarea">
						<input type="hidden" name="form_sent" value="1" />
						<input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token('post.php'); ?>" />
<?php if ($panther_config['o_topic_subscriptions'] == '1' && ($panther_user['auto_notify'] == '1' || $cur_topic['is_subscribed'])): ?>						<input type="hidden" name="subscribe" value="1" />
<?php endif; ?>
<?php
if ($panther_user['is_guest'])
{
	$email_label = ($panther_config['p_force_guest_email'] == '1') ? '<strong>'.$lang_common['Email'].' <span>'.$lang_common['Required'].'</span></strong>' : $lang_common['Email'];
	$email_form_name = ($panther_config['p_force_guest_email'] == '1') ? 'req_email' : 'email';

?>
						<label class="conl required"><strong><?php echo $lang_post['Guest name'] ?> <span><?php echo $lang_common['Required'] ?></span></strong><br /><input type="text" name="req_username" size="25" maxlength="25" tabindex="<?php echo $cur_index++ ?>" /><br /></label>
						<label class="conl<?php echo ($panther_config['p_force_guest_email'] == '1') ? ' required' : '' ?>"><?php echo $email_label ?><br /><input type="text" name="<?php echo $email_form_name ?>" size="50" maxlength="80" tabindex="<?php echo $cur_index++ ?>" /><br /></label>
						<div class="clearer"></div>
<?php

	echo "\t\t\t\t\t\t".'<label class="required"><strong>'.$lang_common['Message'].' <span>'.$lang_common['Required'].'</span></strong><br />';
}
else
	echo "\t\t\t\t\t\t".'<label>';

?>
<textarea name="req_message" rows="7" cols="75" tabindex="<?php echo $cur_index++ ?>"></textarea></label>
						<ul class="bblinks">
							<li><span><a href="<?php echo get_link($panther_url['help'], array('bbcode')); ?>" onclick="window.open(this.href); return false;"><?php echo $lang_common['BBCode'] ?></a> <?php echo ($panther_config['p_message_bbcode'] == '1') ? $lang_common['on'] : $lang_common['off']; ?></span></li>
							<li><span><a href="<?php echo get_link($panther_url['help'], array('url')); ?>" onclick="window.open(this.href); return false;"><?php echo $lang_common['url tag'] ?></a> <?php echo ($panther_config['p_message_bbcode'] == '1' && $panther_user['g_post_links'] == '1') ? $lang_common['on'] : $lang_common['off']; ?></span></li>
							<li><span><a href="<?php echo get_link($panther_url['help'], array('img')); ?>" onclick="window.open(this.href); return false;"><?php echo $lang_common['img tag'] ?></a> <?php echo ($panther_config['p_message_bbcode'] == '1' && $panther_config['p_message_img_tag'] == '1') ? $lang_common['on'] : $lang_common['off']; ?></span></li>
							<li><span><a href="<?php echo get_link($panther_url['help'], array('smilies')); ?>" onclick="window.open(this.href); return false;"><?php echo $lang_common['Smilies'] ?></a> <?php echo ($panther_config['o_smilies'] == '1') ? $lang_common['on'] : $lang_common['off']; ?></span></li>
						</ul>
					</div>
				</fieldset>
			</div>
<?php flux_hook('quickpost_before_submit') ?>
			<p class="buttons"><input type="submit" name="submit" tabindex="<?php echo $cur_index++ ?>" value="<?php echo $lang_common['Submit'] ?>" accesskey="s" /> <input type="submit" name="preview" value="<?php echo $lang_topic['Preview'] ?>" tabindex="<?php echo $cur_index++ ?>" accesskey="p" /></p>
		</form>
	</div>
</div>
<?php
}

// Increment "num_views" for topic
if ($panther_config['o_topic_views'] == '1')
	$db->query('UPDATE '.$db->prefix.'topics SET num_views=num_views+1 WHERE id='.$id) or error('Unable to update topic', __FILE__, __LINE__, $db->error());

$csrf_token = generate_csrf_token();
$forum_id = $cur_topic['forum_id'];
$footer_style = 'viewtopic';
require PANTHER_ROOT.'footer.php';