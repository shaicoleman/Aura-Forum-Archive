<?php
/**
 * Copyright (C) 2015 Panther (http://panther.strongholdnation.co.uk/)
 * based on code by Rickard Andersson copyright (C) 2002-2008 PunBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

// Tell header.php to use the admin template ...
define('PANTHER_ADMIN_CONSOLE', 1);

// ... and that we want jQuery included.
define('JQUERY_REQUIRED', 1);

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/');
	require PANTHER_ROOT.'include/common.php';
}
require PANTHER_ROOT.'include/common_admin.php';

if (($panther_user['is_admmod'] && $panther_user['g_mod_cp'] == '0' && !$panther_user['is_admin']) || !$panther_user['is_admmod'])
	message($lang_common['No permission'], false, '403 Forbidden');

check_authentication();

// Load the admin_index.php language file
require PANTHER_ROOT.'lang/'.$admin_language.'/admin_index.php';

$action = isset($_GET['action']) ? $_GET['action'] : null;

// Check for upgrade
if ($action == 'check_upgrade')
{
	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PANTHER_ROOT.'include/cache.php';
	
	$output = generate_update_cache();
	
	if (version_compare($panther_config['o_cur_version'], $output['version'], '>='))
		message($lang_admin_index['Running latest version message']);
	else
		message(sprintf($lang_admin_index['New version available message'], '<a href="http://panther.strongholdnation.co.uk/">StrongholdNation</a>'));
}
else if ($action == 'remove_install_file')
{
	if (@unlink(PANTHER_ROOT.'install.php'))
	{
		if (@unlink(PANTHER_ROOT.'lang/'.$panther_user['language'].'/install.php'))
			redirect(get_link($panther_url['admin_index']), $lang_admin_index['Deleted install.php redirect']);
		else
			message($lang_admin_index['Delete install.php failed']);
	}
	else
		message($lang_admin_index['Delete install.php failed']);
}
else if ($action == 'phpinfo' && $panther_user['is_admin'])
{
	// Is phpinfo() a disabled function?
	if (strpos(strtolower((string) ini_get('disable_functions')), 'phpinfo') !== false)
		message($lang_admin_index['PHPinfo disabled message']);

	phpinfo();
	exit;
}
elseif ($action == 'save_notes')
{

	$notes = isset($_POST['notes']) ? panther_trim($_POST['notes']) : $lang_admin_index['admin notes'];
	$update = array(
		'conf_value'	=>	$notes,
	);

	$db->update('config', $update, 'conf_name=\'o_admin_notes\'');

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PANTHER_ROOT.'include/cache.php';
	
	generate_config_cache();
	exit;
}

$alerts = array();
if (is_file(PANTHER_ROOT.'install.php'))
	$alerts[] = sprintf($lang_admin_index['Install file exists'], '<a href="'.get_link($panther_url['remove_install_file']).'">'.$lang_admin_index['Delete install file'].'</a>');

foreach (get_admin_ids() as $admin)
{
	if ($admin == '2') // No restrictions for the original administrator
		continue;
		
	$data = array(
		':admin'	=>	$admin,
	);

	$ps = $db->select('restrictions', 1, $data, 'admin_id=:admin');
	if (!$ps->rowCount())
	{
		$alerts[] = sprintf($lang_admin_index['No restrictions'], get_link($panther_url['admin_restrictions']));
		break;
	}
}

$update_downloaded = (file_exists(PANTHER_ROOT.'include/updates/panther-update-patch-'.version_friendly($panther_updates['version']).'.zip') ? true : false);

if (version_compare($panther_config['o_cur_version'], $panther_updates['version'], '<') && !$update_downloaded)
	$alerts[] = sprintf($lang_admin_index['New version'], $panther_updates['version'], get_link($panther_url['admin_updates']));

if ($update_downloaded)
	$alerts[] = sprintf($lang_admin_index['update downloaded'], $panther_updates['version'], get_link($panther_url['admin_updates']));

$panther_config['o_avatars_path'] = ($panther_config['o_avatars_dir'] != '') ? $panther_config['o_avatars_path'].'/' : PANTHER_ROOT.$panther_config['o_avatars_path'].'/';

if (!forum_is_writable($panther_config['o_avatars_path']))
	$alerts[] = sprintf($lang_admin_index['Alert avatar'], $panther_config['o_avatars_path']);

if (!forum_is_writable($panther_config['o_smilies_path']))
	$alerts[] = sprintf($lang_admin_index['Alert smilies'], $panther_config['o_smilies_path']);

$active_alerts = (count($alerts) > 0) ? true : false;

$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_admin_common['Admin'], $lang_admin_common['Index']);
define('PANTHER_ACTIVE_PAGE', 'admin');
require PANTHER_ROOT.'header.php';

generate_admin_menu('index');
?>
	<div class="block">
		<h2><span><?php echo $lang_admin_index['Forum admin head'] ?></span></h2>
		<div id="adintro" class="box">
			<div class="inbox">
				<p><?php echo $lang_admin_index['Welcome to admin'] ?></p>
				<ul>
					<li><span><?php echo $lang_admin_index['Welcome 1'] ?></span></li>
					<li><span><?php echo $lang_admin_index['Welcome 2'] ?></span></li>
					<li><span><?php echo $lang_admin_index['Welcome 3'] ?></span></li>
					<li><span><?php echo $lang_admin_index['Welcome 4'] ?></span></li>
					<li><span><?php echo $lang_admin_index['Welcome 5'] ?></span></li>
					<li><span><?php echo $lang_admin_index['Welcome 6'] ?></span></li>
					<li><span><?php echo $lang_admin_index['Welcome 7'] ?></span></li>
					<li><span><?php echo $lang_admin_index['Welcome 8'] ?></span></li>
					<li><span><?php echo $lang_admin_index['Welcome 9'] ?></span></li>
					<li><span><?php echo $lang_admin_index['Welcome 10'] ?></span></li>
					<li><span><?php echo $lang_admin_index['Welcome 11'] ?></span></li>
					<li><span><?php echo $lang_admin_index['Welcome 12'] ?></span></li>
					<li><span><?php echo $lang_admin_index['Welcome 13'] ?></span></li>
					<li><span><?php echo $lang_admin_index['Welcome 14'] ?></span></li>
					<li><span><?php echo $lang_admin_index['Welcome 15'] ?></span></li>
				</ul>
			</div>
		</div>

<?php if ($active_alerts) : ?>
		<h2 class="block2"><span><?php echo $lang_admin_index['Alerts head'] ?></span></h2>
		<div id="adalerts" class="box">
			<p><?php echo implode("\n".'</p><p>', $alerts) ?></p>
		</div>
<?php endif; ?>
		<h2 class="block2"><span><?php echo $lang_admin_index['Notes head'] ?></span></h2>
			<p><div style="padding: 5px;"><form>
	<div class="infldset txtarea"><input type="hidden" id="notes_url" value="<?php echo get_link($panther_url['save_notes']); ?>" /><textarea id="dashboard_notes" class="dashboard_notes" style="height: 70px;" rows="5"><?php echo panther_htmlspecialchars($panther_config['o_admin_notes']); ?></textarea></div>
	<div style="text-align: left; margin-top: 5px; display:none" id="notes_save">
		<p class="buttons" id="ajax_submit"><button type="button"><?php echo $lang_admin_index['save notes']; ?></button></p>
	</div></form></p>
		</div>
		<h2 class="block2"><span><?php echo $lang_admin_index['About head'] ?></span></h2>
		<div id="adstats" class="box">
			<div class="inbox">
				<dl>
					<dt><?php echo $lang_admin_index['Panther version label'] ?></dt>
					<dd>
						<?php printf($lang_admin_index['Panther version data']."\n", $panther_config['o_cur_version'], '<a href="'.get_link($panther_url['check_upgrade']).'">'.$lang_admin_index['Check for upgrade'].'</a>') ?>
					</dd>
					<dt><?php echo $lang_admin_index['Server statistics label'] ?></dt>
					<dd>
						<a href="<?php echo get_link($panther_url['admin_statistics']); ?>"><?php echo $lang_admin_index['View server statistics'] ?></a>
					</dd>
					<dt><?php echo $lang_admin_index['Support label'] ?></dt>
					<dd>
						<a href="http://panther.strongholdnation.co.uk/forums.php"><?php echo $lang_admin_index['Forum label'] ?></a>
					</dd>
				</dl>
			</div>
		</div>
	</div>
	<div class="clearer"></div>
</div>
<?php
require PANTHER_ROOT.'footer.php';