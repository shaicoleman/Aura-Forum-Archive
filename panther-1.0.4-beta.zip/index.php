<?php
/**
 * Copyright (C) 2015 Panther (http://panther.strongholdnation.co.uk/)
 * based on code by Rickard Andersson copyright (C) 2002-2008 pantherBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/');
	require PANTHER_ROOT.'include/common.php';
}

if ($panther_user['g_read_board'] == '0')
	message($lang_common['No view'], false, '403 Forbidden');

// Load the index.php language file
require PANTHER_ROOT.'lang/'.$panther_user['language'].'/index.php';

// Get list of forums and topics with new posts since last visit
if (!$panther_user['is_guest'])
{
	$data = array(
		':id'	=> $panther_user['g_id'],
		':last_visit'	=> $panther_user['last_visit'],
	);
	$ps = $db->run('SELECT f.id, f.last_post FROM '.$db->prefix.'forums AS f LEFT JOIN '.$db->prefix.'forum_perms AS fp ON (fp.forum_id=f.id AND fp.group_id=:id) WHERE (fp.read_forum IS NULL OR fp.read_forum=1) AND f.last_post>:last_visit', $data);
	if ($ps->rowCount())
	{
		$forums = $new_topics = array();
		$tracked_topics = get_tracked_topics();
		foreach ($ps as $cur_forum)
		{
			if (!isset($tracked_topics['forums'][$cur_forum['id']]) || $tracked_topics['forums'][$cur_forum['id']] < $cur_forum['last_post'])
				$forums[$cur_forum['id']] = $cur_forum['last_post'];
		}

		if (!empty($forums))
		{
			if (empty($tracked_topics['topics']))
				$new_topics = $forums;
			else
			{
				for ($i = 0; $i < count($forums); $i++)
					$placeholders[] = '?';
				
				$data = array_keys($forums);
				$data[] = $panther_user['last_visit'];
				
				$ps = $db->run('SELECT forum_id, id, last_post FROM '.$db->prefix.'topics WHERE forum_id IN('.implode(',', $placeholders).') AND last_post>? AND moved_to IS NULL', $data);
				foreach ($ps as $cur_topic)
				{
					if (!isset($new_topics[$cur_topic['forum_id']]) && (!isset($tracked_topics['forums'][$cur_topic['forum_id']]) || $tracked_topics['forums'][$cur_topic['forum_id']] < $forums[$cur_topic['forum_id']]) && (!isset($tracked_topics['topics'][$cur_topic['id']]) || $tracked_topics['topics'][$cur_topic['id']] < $cur_topic['last_post']))
						$new_topics[$cur_topic['forum_id']] = $forums[$cur_topic['forum_id']];
				}
			}
		}
	}
}

if ($panther_config['o_feed_type'] == '1')
	$page_head = array('feed' => '<link rel="alternate" type="application/rss+xml" href="'.get_link($panther_url['index_rss']).'" title="'.$lang_common['RSS active topics feed'].'" />');
else if ($panther_config['o_feed_type'] == '2')
	$page_head = array('feed' => '<link rel="alternate" type="application/atom+xml" href="'.get_link($panther_url['index_atom']).'" title="'.$lang_common['Atom active topics feed'].'" />');

$forum_actions = array();

// Display a "mark all as read" link
if (!$panther_user['is_guest'])
	$forum_actions[] = '<a href="'.get_link($panther_url['mark_read']).'">'.$lang_common['Mark all as read'].'</a>';

$sub_forums = array();
$data = array(
	':id'	=>	$panther_user['g_id'],
);

$ps = $db->run('SELECT u.id AS uid, u.email, u.use_gravatar, u.group_id, f.num_topics, f.num_posts, f.parent_forum, f.last_post_id, f.show_post_info, f.last_poster, f.last_post, f.id, f.forum_name FROM '.$db->prefix.'forums AS f LEFT JOIN '.$db->prefix.'forum_perms AS fp ON (fp.forum_id=f.id AND fp.group_id=:id) LEFT JOIN '.$db->prefix.'users AS u ON (f.last_poster=u.username) WHERE (fp.read_forum IS NULL OR fp.read_forum=1) AND f.parent_forum <> 0 ORDER BY f.disp_position', $data);
foreach ($ps as $current)
{
	if (!isset($sub_forums[$current['parent_forum']]))
		$sub_forums[$current['parent_forum']] = array();

	$sub_forums[$current['parent_forum']][] = $current;
}

$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']));
define('PANTHER_ALLOW_INDEX', 1);
define('PANTHER_ACTIVE_PAGE', 'index');
require PANTHER_ROOT.'header.php';

// Print the categories and forums
$ps = $db->run('SELECT c.id AS cid, c.cat_name, f.id AS fid, f.forum_name, f.forum_desc, f.show_post_info, f.redirect_url, f.moderators, f.num_topics, f.num_posts, f.last_post, f.last_post_id, f.last_poster, f.parent_forum, u.group_id, u.id AS uid, u.email, u.use_gravatar FROM '.$db->prefix.'categories AS c INNER JOIN '.$db->prefix.'forums AS f ON c.id=f.cat_id LEFT JOIN '.$db->prefix.'forum_perms AS fp ON (fp.forum_id=f.id AND fp.group_id=:id) LEFT JOIN '.$db->prefix.'users AS u ON (f.last_poster=u.username) WHERE (fp.read_forum IS NULL OR fp.read_forum=1) AND (f.parent_forum IS NULL OR f.parent_forum=0) ORDER BY c.disp_position, c.id, f.disp_position', $data);

$cur_category = 0;
$cat_count = 0;
$forum_count = 0;
foreach ($ps as $cur_forum)
{
	$moderators = '';
	if ($cur_forum['cid'] != $cur_category) // A new category since last iteration?
	{
		if ($cur_category != 0)
			echo "\t\t\t".'</tbody>'."\n\t\t\t".'</table>'."\n\t\t".'</div>'."\n\t".'</div>'."\n".'</div>'."\n\n";

		++$cat_count;
		$forum_count = 0;
?>
<div id="idx<?php echo $cat_count ?>" class="blocktable">
	<h2><span><?php echo panther_htmlspecialchars($cur_forum['cat_name']) ?></span></h2>
	<div class="box">
		<div class="inbox">
			<table>
			<thead>
				<tr>
					<th class="tcl" scope="col"><?php echo $lang_common['Forum'] ?></th>
					<th class="tc2" scope="col"><?php echo $lang_index['Topics'] ?></th>
					<th class="tc3" scope="col"><?php echo $lang_common['Posts'] ?></th>
					<th class="tcr" scope="col"><?php echo $lang_common['Last post'] ?></th>
				</tr>
			</thead>
			<tbody>
<?php
		$cur_category = $cur_forum['cid'];
	}

	++$forum_count;
	$item_status = ($forum_count % 2 == 0) ? 'roweven' : 'rowodd';
	$forum_field_new = '';
	$icon_type = 'icon';

	// Are there new posts since our last visit?
	if (isset($new_topics[$cur_forum['fid']]))
	{
		$item_status .= ' inew';
		$forum_field_new = '<span class="newtext">[ <a href="'.get_link($panther_url['search_new_results'], array($cur_forum['fid'])).'">'.$lang_common['New posts'].'</a> ]</span>';
		$icon_type = 'icon icon-new';
	}

	// Is this a redirect forum?
	if ($cur_forum['redirect_url'] != '')
	{
		$forum_field = '<h3><span class="redirtext">'.$lang_index['Link to'].'</span> <a href="'.panther_htmlspecialchars($cur_forum['redirect_url']).'" title="'.$lang_index['Link to'].' '.panther_htmlspecialchars($cur_forum['redirect_url']).'">'.panther_htmlspecialchars($cur_forum['forum_name']).'</a></h3>';
		$num_topics = $num_posts = '-';
		$item_status .= ' iredirect';
		$icon_type = 'icon';
	}
	else
	{
		$forum_field = '<h3><a href="'.get_link($panther_url['forum'], array($cur_forum['fid'], url_friendly($cur_forum['forum_name']))).'">'.panther_htmlspecialchars($cur_forum['forum_name']).'</a>'.(!empty($forum_field_new) ? ' '.$forum_field_new : '').'</h3>';
		$num_topics = $cur_forum['num_topics'];
		$num_posts = $cur_forum['num_posts'];
	}

	$subforum_list = array();
	if (isset($sub_forums[$cur_forum['fid']]))
	{
		// There can be more than one sub forum per forum
		foreach ($sub_forums[$cur_forum['fid']] as $cur_subforum)
		{
			$num_topics += $cur_subforum['num_topics'];
			$num_posts += $cur_subforum['num_posts'];
			if ($cur_forum['show_post_info'] == '0')
				$last_post = $lang_common['Protected forum'];
			elseif ($cur_forum['last_post'] < $cur_subforum['last_post'])
			{
				$cur_forum['last_post_id'] = $cur_subforum['last_post_id'];
				$cur_forum['last_poster'] = $cur_subforum['last_poster'];
				$cur_forum['last_post'] = $cur_subforum['last_post'];
				$cur_forum['email'] = $cur_subforum['email'];
				$cur_forum['uid'] = $cur_subforum['uid'];
				$cur_forum['use_gravatar'] = $cur_subforum['use_gravatar'];
				$cur_forum['group_id'] = $cur_subforum['group_id'];
			}
			
			if (isset($new_topics[$cur_subforum['id']]))
			{
				if (stristr($item_status, 'inew') === false)
				{
					$item_status .= ' inew';
					$forum_field_new = '<span class="newtext">[ <a href="'.get_link($panther_url['search_new_results'], array($cur_forum['fid'])).'">'.$lang_common['New posts'].'</a> ]</span>';
					$icon_type = 'icon icon-new';
				}
			}
			$subforum_list[] = '<a class="subforum_name" href="'.get_link($panther_url['forum'], array($cur_subforum['id'], url_friendly($cur_subforum['forum_name']))).'">'.panther_htmlspecialchars($cur_subforum['forum_name']).'</a>';
		}
	}

	if ($cur_forum['forum_desc'] != '')
		$forum_field .= "\n\t\t\t\t\t\t\t\t".'<div class="forumdesc">'.$cur_forum['forum_desc'].'</div>';

	// If there is a last_post/last_poster
	if ($cur_forum['show_post_info'] == '0')
			$last_post = $lang_common['Protected forum'];
	elseif ($cur_forum['last_post'] != '')
	{
		if (isset($cur_forum['group_id']))
			$username = colourize_group($cur_forum['last_poster'], $cur_forum['group_id'], $cur_forum['uid']);
		else
			$username = colourize_group($cur_forum['last_poster'], PANTHER_GUEST);

		$last_post = '<span class="byuser_avatar">'.generate_avatar_markup($cur_forum['uid'], $cur_forum['email'], $cur_forum['use_gravatar'], array(32, 32)).'</span><a href="'.get_link($panther_url['post'], array($cur_forum['last_post_id'])).'">'.format_time($cur_forum['last_post']).'</a> <span class="byuser">'.$lang_common['by'].' '.$username.'</span>';
	}
	else if ($cur_forum['redirect_url'] != '')
		$last_post = '- - -';
	else
		$last_post = $lang_common['Never'];

	if ($cur_forum['moderators'] != '')
	{
		$mods_array = unserialize($cur_forum['moderators']);
		$moderator_groups = array();
		if (isset($mods_array['groups']))
		{
			$moderator_groups = $mods_array['groups'];
			unset($mods_array['groups']);
		}

		if (count($mods_array) > 0)
		{
			$moderators = array();

			foreach ($mods_array as $mod_username => $mod_id)
				$moderators[] = colourize_group($mod_username, $moderator_groups[$mod_id], $mod_id);

			$moderators = "\t\t\t\t\t\t\t\t".'<p class="modlist">(<em>'.$lang_common['Moderated by'].'</em> '.implode(', ', $moderators).')</p>'."\n";
		}
	}
?>
				<tr class="<?php echo $item_status ?>">
					<td class="tcl">
						<div class="<?php echo $icon_type ?>"><div class="nosize"><?php echo forum_number_format($forum_count) ?></div></div>
						<div class="tclcon">
							<div>
								<?php echo $forum_field."\n".$moderators."\n"; ?>
								<?php echo (count($subforum_list)) ? '<br /><span class="subforum">'.$lang_index['Sub forums'].':</span> '.implode(', ', $subforum_list)."\n" : ''; ?>
							</div>
						</div>
					</td>
					<td class="tc2"><?php echo forum_number_format($num_topics) ?></td>
					<td class="tc3"><?php echo forum_number_format($num_posts) ?></td>
					<td class="tcr"><?php echo $last_post ?></td>
				</tr>
<?php
}

// Did we output any categories and forums?
if ($cur_category > 0)
	echo "\t\t\t".'</tbody>'."\n\t\t\t".'</table>'."\n\t\t".'</div>'."\n\t".'</div>'."\n".'</div>'."\n\n";
else
	echo '<div id="idx0" class="block"><div class="box"><div class="inbox"><p>'.$lang_index['Empty board'].'</p></div></div></div>';

// Collect some statistics from the database
if (file_exists(FORUM_CACHE_DIR.'cache_users_info.php'))
	include FORUM_CACHE_DIR.'cache_users_info.php';

if (!defined('PANTHER_USERS_INFO_LOADED'))
{
	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PANTHER_ROOT.'include/cache.php';

	generate_users_info_cache();
	require FORUM_CACHE_DIR.'cache_users_info.php';
}

$ps = $db->run('SELECT SUM(num_topics), SUM(num_posts) FROM '.$db->prefix.'forums');
list($stats['total_topics'], $stats['total_posts']) = array_map('intval', $ps->fetch(PDO::FETCH_NUM));

$stats['newest_user'] = colourize_group($stats['last_user']['username'], $stats['last_user']['group_id'], $stats['last_user']['id']);
if (!empty($forum_actions))
{
?>
<div class="linksb">
	<div class="inbox crumbsplus">
		<p class="subscribelink clearb"><?php echo implode(' - ', $forum_actions); ?></p>
	</div>
</div>
<?php
}
?>
<div id="brdstats" class="block">
	<h2><span><?php echo $lang_index['Board info'] ?></span></h2>
	<div class="box">
		<div class="inbox">
			<dl class="conr">
				<dt><strong><?php echo $lang_index['Board stats'] ?></strong></dt>
				<dd><span><?php printf($lang_index['No of users'], '<strong>'.forum_number_format($stats['total_users']).'</strong>') ?></span></dd>
				<dd><span><?php printf($lang_index['No of topics'], '<strong>'.forum_number_format($stats['total_topics']).'</strong>') ?></span></dd>
				<dd><span><?php printf($lang_index['No of posts'], '<strong>'.forum_number_format($stats['total_posts']).'</strong>') ?></span></dd>
			</dl>
			<dl class="conl">
				<dt><strong><?php echo $lang_index['User info'] ?></strong></dt>
				<dd><span><?php printf($lang_index['Newest user'], $stats['newest_user']) ?></span></dd>
<?php
if ($panther_config['o_users_online'] == '1')
{
	// Fetch users online info and generate strings for output
	$num_guests = count($online['guests']);
	$num_users = count($online['users']);
	$num_bots = 0;
	$users = $bots = $bots_online = array();
	
	foreach ($online['users'] as $online_id => $details)
		$users[] = "\n\t\t\t\t".colourize_group($details['username'], $details['group_id'], $details['id'], $online_id);

	foreach ($online['guests'] as $details)
	{
		if (strpos($details['ident'], '[Bot]') !== false)
		{
			++$num_bots;
			$name = explode('[Bot]', $details['ident']);
			if (empty($bots[$name[1]]))
				$bots[$name[1]] = 1;
			else
				++$bots[$name[1]];
		}
	}
	foreach ($bots as $online_name => $online_id)
		   $bots_online[] = "\n\t\t\t\t".panther_htmlspecialchars($online_name.' [Bot]'.($online_id > 1 ? ' ('.$online_id.')' : ''));

	$num_guests = $num_guests - $num_bots;
	
	echo "\t\t\t\t".'<dd><span>'.sprintf($lang_index['Users online'], '<strong>'.forum_number_format($num_users).'</strong>').'</span></dd>'."\n\t\t\t\t".'<dd><span>'.sprintf($lang_index['Guests online'], '<strong>'.forum_number_format($num_guests).'</strong>').'</span></dd>'."\n\t\t\t\t".'<dd><span>'.sprintf($lang_index['Bots online 1'], '<strong>'.forum_number_format($num_bots).'</strong>').'</span></dd>'."\n\t\t\t".'</dl>'."\n";
	
	if ($num_users > 0)
       		echo "\t\t\t".'<dl id="onlinelist" class="clearb">'."\n\t\t\t\t".'<dt><strong>'.$lang_index['Online'].' </strong></dt>'."\t\t\t\t".implode(',</dd> ', $users).'</dd>'."\n\t\t\t".'</dl>'."\n";

	if ($num_bots > 0)
		echo "\t\t\t".'<dl id="onlinelist" class="clearb">'."\n\t\t\t\t".'<dt><strong>'.$lang_index['Bots Online'].' </strong></dt>'."\t\t\t\t".implode(',</dd> ', $bots_online).'</dd>'."\n\t\t\t".'</dl>'."\n";
    	
    if ($num_bots + $num_users == 0)
		echo "\t\t\t".'<div class="clearer"></div>'."\n";
}
else
	echo "\t\t\t".'</dl>'."\n\t\t\t".'<div class="clearer"></div>'."\n";

	$groups = array();
	foreach ($panther_groups as $g_id => $details)
	{
		if (!in_array($g_id, array(PANTHER_GUEST, PANTHER_MEMBER)) && $details['g_colour'] !== '')
		{
			$cur_group = colourize_group($details['g_title'], $g_id);
			if ($panther_user['g_view_users'] == 1)
				$cur_group = '<a href="'.get_link($panther_url['userlist_group'], array($g_id)).'">'.$cur_group.'</a>';

			$groups[] = "\n\t\t\t\t".'<dd>'.$cur_group.'</dd>';
		}
	}

	if (count($groups) > 0)
		echo "\t\t\t".'<dl id="onlinelist" class="clearb">'."\n\t\t\t\t".'<dt><strong>'.$lang_index['Legend'].': </strong></dt>'.implode(', ', $groups)."\n\t\t\t".'</dl>'."\n";
?>
		</div>
	</div>
</div>
<?php
$footer_style = 'index';
require PANTHER_ROOT.'footer.php';