<?php
if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/');
	require PANTHER_ROOT.'include/common.php';
}

// Load the attach.php language file
require PANTHER_ROOT.'lang/'.$panther_user['language'].'/attach.php';

$id = isset($_GET['item']) ? intval($_GET['item']) : 0;

if ($id < 1)
	message($lang_common['Bad request']);

$data = array(
	':id'	=>	$id,
	':gid'	=>	$panther_user['g_id'],
);

$ps = $db->run('SELECT a.post_id, a.filename, a.extension, a.mime, a.location, a.size, fp.download FROM '.$db->prefix.'attachments AS a LEFT JOIN '.$db->prefix.'posts AS p ON a.post_id=p.id LEFT JOIN '.$db->prefix.'topics AS t ON p.topic_id=t.id LEFT JOIN '.$db->prefix.'forum_perms AS fp ON t.forum_id=fp.forum_id AND fp.group_id=:gid WHERE a.id=:id', $data);
if (!$ps->rowCount())
	message($lang_common['Bad request']);
else
	$attachment = $ps->fetch();

$download = false;
if ($panther_user['is_admin'])
	$download = true;
else if ($attachment['download'] == '1' || $attachment['download'] == '')
	$download = true;

if(!$download)
	message($lang_common['No permission']);

if (($attachment['extension'] == 'jpg' || $attachment['extension'] == 'jpeg' || $attachment['extension'] == 'gif' || $attachment['extension'] == 'png') && !isset($_GET['download']))
{
	$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_attach['Image view'], panther_htmlspecialchars($attachment['filename']));
	define('PANTHER_ALLOW_INDEX', 1);
	define('PANTHER_ACTIVE_PAGE', 'index');
	require PANTHER_ROOT.'header.php';
?>
<div id="msg" class="block">
	<h2><span><?php echo $lang_attach['Image view'] ?></span></h2>
	<div class="box">
		<div class="inbox">
		<div class="imgbox"><div class="scrollbox"><a href="<?php echo get_link($panther_url['attachment_download'], array($id)) ?>"><img src="<?php echo get_link($panther_url['attachment_download'], array($id)) ?>" style="max-width: 100%" alt="<?php echo panther_htmlspecialchars($attachment['filename']) ?>" /></a></div></div><p>
		<?php echo $lang_attach['Download:']; ?> <a href="<?php echo get_link($panther_url['attachment_download'], array($id)) ?>"><?php echo panther_htmlspecialchars($attachment['filename']) ?></a></p>
		<p><a href="javascript: history.go(-1)"><?php echo $lang_common['Go back'] ?></a></p>
		</div>
	</div>
</div>	
<?php	
	require PANTHER_ROOT.'footer.php';
}

$data = array(
	':id'	=>	$id,
);

$db->run('UPDATE '.$db->prefix.'attachments SET downloads=downloads+1 WHERE id=:id', $data);
$db->end_transaction();
$db->close();

$fp = fopen($panther_config['o_attachments_dir'].$attachment['location'], "rb");
if(!$fp)
	message($lang_common['Bad request']);

$attachment['filename'] = rawurlencode($attachment['filename']);

// send some headers
header('Content-Disposition: attachment; filename='.$attachment['filename']);
if (strlen($attachment['mime']) > 0)
	header('Content-Type: '.$attachment['mime']);
else
	header('Content-type: application/octet-stream');

header('Pragma: no-cache');
header('Expires: 0'); 
header('Connection: close');
if ($attachment['size'] != 0)
	header('Content-Length: '.$attachment['size']);

fpassthru($fp);