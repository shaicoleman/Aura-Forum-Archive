<?php
/**
 * Copyright (C) 2014 StrongholdNation (http://www.strongholdnation.co.uk)
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

// Tell header.php to use the admin template
define('PANTHER_ADMIN_CONSOLE', 1);

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', dirname(__FILE__).'/');
	require PANTHER_ROOT.'include/common.php';
}

if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
	require PANTHER_ROOT.'include/cache.php';

require PANTHER_ROOT.'include/common_admin.php';

if (!$panther_user['is_admin'])
	message($lang_common['No permission']);

// Load the admin_restrictions.php language file
require PANTHER_ROOT.'lang/'.$admin_language.'/admin_restrictions.php';

if ($panther_user['id'] != '2')
{
	if(!is_null($admins[$panther_user['id']]['admin_restrictions']))
	{
		if ($admins[$panther_user['id']]['admin_restrictions'] == '0')
			message($lang_common['No permission'], false, '403 Forbidden');
	}
}

check_authentication();

$action = isset($_GET['action']) ? panther_htmlspecialchars($_GET['action']) : null;
$stage = isset($_GET['stage']) ? intval($_GET['stage']) : null;
$csrf_token = generate_csrf_token();

if (($action == 'add' || $action == 'edit') && isset($_POST['form_sent']) && $stage == '3')
{
	confirm_referrer('admin_restrictions.php');

	//Stage 3: Add/edit restrictions
	$user = isset($_POST['admin_id']) ? intval($_POST['admin_id']) : 0;
	if ($user < 1)
		message($lang_common['Bad request']);
	
	$board_config = isset($_POST['board_config']) ? intval($_POST['board_config']) : '1';
	$board_perms = isset($_POST['board_perms']) ? intval($_POST['board_perms']) : '1';	
	$board_cats = isset($_POST['board_cats']) ? intval($_POST['board_cats']) : '1';
	$board_forums = isset($_POST['board_forums']) ? intval($_POST['board_forums']) : '1';	
	$board_groups = isset($_POST['board_groups']) ? intval($_POST['board_groups']) : '1';
	$board_users = isset($_POST['board_users']) ? intval($_POST['board_users']) : '1';
	$board_censoring = isset($_POST['board_censoring']) ? intval($_POST['board_censoring']) : '1';
	$board_ranks = isset($_POST['board_ranks']) ? intval($_POST['board_ranks']) : '1';
	$board_moderate = isset($_POST['board_moderate']) ? intval($_POST['board_moderate']) : '1';
	$board_maintenance = isset($_POST['board_maintenance']) ? intval($_POST['board_maintenance']) : '0';
	$board_plugins = isset($_POST['board_plugins']) ? intval($_POST['board_plugins']) : '1';
	$board_restrictions = isset($_POST['board_restrictions']) ? intval($_POST['board_restrictions']) : '0';
	$board_updates = isset($_POST['board_updates']) ? intval($_POST['board_updates']) : '0';
	$board_archive = isset($_POST['board_archive']) ? intval($_POST['board_archive']) : '1';
	$board_smilies = isset($_POST['board_smilies']) ? intval($_POST['board_smilies']) : '1';
	$board_warnings = isset($_POST['board_warnings']) ? intval($_POST['board_warnings']) : '1';
	$board_attachments = isset($_POST['board_attachments']) ? intval($_POST['board_attachments']) : '1';
	$board_robots = isset($_POST['board_robots']) ? intval($_POST['board_robots']) : '1';

	$data = array(
		':id'	=>	$user,
	);

	$ps = $db->run('SELECT 1 FROM '.$db->prefix.'users AS u INNER JOIN '.$db->prefix.'groups AS g ON u.group_id=g.g_id WHERE u.group_id=:id OR g.g_admin=1', $data);
	if (!$ps->rowCount())
		message($lang_admin_restrictions['no user']);

	$data = array(
		':id'	=>	$user,
	);

	$restrictions = array(
		'admin_options'		=>	$board_config,
		'admin_permissions'	=>	$board_perms,
		'admin_categories'	=>	$board_cats,
		'admin_forums'		=>	$board_forums,
		'admin_groups'		=>	$board_groups,
		'admin_censoring'	=>	$board_censoring,
		'admin_maintenance'	=>	$board_maintenance,
		'admin_plugins'		=>	$board_plugins,
		'admin_restrictions'=>	$board_restrictions,
		'admin_users'		=>	$board_users,
		'admin_moderate'	=>	$board_moderate,
		'admin_ranks'		=>	$board_ranks,
		'admin_updates'		=>	$board_updates,
		'admin_archive'		=>	$board_archive,
		'admin_smilies'		=>	$board_smilies,
		'admin_warnings'	=>	$board_warnings,
		'admin_attachments'	=>	$board_attachments,
		'admin_robots'		=>	$board_robots,
	);

	$insert = array(
		'admin_id'	=>	$user,
		'restrictions'	=>	serialize($restrictions),
	);

	if ($action == 'add')
	{
		$db->insert('restrictions', $insert);
		$redirect_lang = $lang_admin_restrictions['added redirect'];
	}
	else
	{
		$data = array(
			':id'	=>	$user,
		);

		$db->update('restrictions', $update, 'id=:id', $data);
		$redirect_lang = $lang_admin_restrictions['edited redirect'];
	}

	generate_admin_restrictions_cache();
	redirect(get_link($panther_url['admin_restrictions']), $redirect_lang);
}
else if ($action == 'delete' && isset($_POST['form_sent']) && $stage == '3')
{
	confirm_referrer('admin_restrictions.php');

	//Stage 3: Remove restrictions
	$user = isset($_POST['admin_id']) ? intval($_POST['admin_id']) : 0;

	$data = array(
		':id'	=>	$user,
	);

	$ps = $db->select('users', 'group_id', $data, 'id=:id');
	$gid = $ps->fetchColumn();

	if ($gid != PANTHER_ADMIN)
		message($lang_admin_restrictions['no user']);

	$data = array(
		':id'	=>	$user,
	);

	$ps = $db->select('restrictions', 1, $data, 'admin_id=:id');

	if (!$ps->rowCount())
		message($lang_admin_restrictions['no restrictions']);

	$db->delete('restrictions', 'admin_id=:id', $data);

	generate_admin_restrictions_cache();
	redirect(get_link($panther_url['admin_restrictions']), $lang_admin_restrictions['removed redirect']);
}

$page_title = array(panther_htmlspecialchars($panther_config['o_board_title']), $lang_admin_common['Admin'], $lang_admin_common['Restrictions']);
define('PANTHER_ACTIVE_PAGE', 'admin');
require PANTHER_ROOT.'header.php';

if ($action == 'delete' && isset($_POST['form_sent']) && $stage == '2')
{
	//Stage 2: Confirm Removal of existing restrictions
	$user = isset($_POST['user']) ? intval($_POST['user']) : 0;
	$data = array(
		':id'	=>	$user,
	);

	$ps = $db->select('restrictions', 1, $data, 'admin_id=:id');
	if (!$ps->rowCount())
		message($lang_admin_restrictions['no user']);

	// Check for changing input value from previous form
	$ps = $db->select('users', 'group_id, username', $data, 'id=:id');
	list($group_id, $username) = $ps->fetch(PDO::FETCH_NUM);

	if ($group_id != PANTHER_ADMIN)
		message($lang_admin_restrictions['no user']);

	generate_admin_menu('restrictions');
?>
	<div class="blockform">
		<h2><span><?php echo $lang_admin_restrictions['restrictions head']; ?></span></h2>
		<div class="box">
			<form id="restrictions" method="post" action="<?php echo get_link($panther_url['admin_restrictions_query'], array('action=delete&stage=3')); ?>">
				<input type="hidden" name="form_sent" value="1" />
				<input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>" />
				<div class="inform">
					<input type="hidden" name="admin_id" value="<?php echo $user; ?>" />
						<div class="infldset">
							<div class="forminfo">
								<p><strong><?php echo sprintf($lang_admin_restrictions['delete label'], panther_htmlspecialchars($username)); ?></strong></p>
							</div>		
						</div>
				</div>
				<p class="buttons"><input type="submit" name="delete" value="<?php echo $lang_admin_restrictions['delete']; ?>" /> <a href="javascript:history.go(-1)"><?php echo $lang_admin_restrictions['back']; ?></a></p>
			</form>
		</div>
	</div>
	<div class="clearer"></div>
</div>
</div>
<?php
}
else if (($action == 'edit' || $action == 'add') && isset($_POST['form_sent']) && $stage == '2')
{
	confirm_referrer('admin_restrictions.php');

	//Stage 2: Edit existing restrictions
	$user = isset($_POST['user']) ? intval($_POST['user']) : 0;
	$data = array(
		':id'	=>	$user,
	);
	
	$ps = $db->select('users', 'username, group_id', $data, 'id=:id');
	if (!$ps->rowCount())
		message($lang_common['Bad request']);
	
	list($username, $group_id) = $ps->fetch(PDO::FETCH_NUM);
	
	if ($panther_groups[$group_id]['g_admin'] != '1' && $group_id != PANTHER_ADMIN)
		message($lang_common['Bad request']);

	// Then we're adding restrictions
	if (!isset($admins[$user]))
	{
		$admins[$user] = array(
			'admin_options'		=>	1,
			'admin_permissions'	=>	1,
			'admin_categories'	=>	1,
			'admin_forums'		=>	1,
			'admin_groups'		=>	1,
			'admin_censoring'	=>	1,
			'admin_maintenance'	=>	1,
			'admin_plugins'		=>	1,
			'admin_restrictions'=>	1,
			'admin_users'		=>	1,
			'admin_moderate'	=>	1,
			'admin_ranks'		=>	1,
			'admin_updates'		=>	1,
			'admin_archive'		=>	1,
			'admin_smilies'		=>	1,
			'admin_warnings'	=>	1,
			'admin_attachments'	=>	1,
			'admin_robots'		=>	1,
		);
	}
	
	generate_admin_menu('restrictions');
?>
	<div class="blockform">
		<h2><span><?php echo $lang_admin_restrictions['restrictions head']; ?></span></h2>
		<div class="box">
			<form id="restrictions2" method="post" action="<?php echo get_link($panther_url['admin_restrictions_query'], array('action='.$action.'&stage=3')); ?>">
				<input type="hidden" name="form_sent" value="1" />
				<p class="submittop"><input tabindex="1" type="submit" name="submit" value="<?php echo $lang_common['Submit']; ?>" /></p>
				<div class="inform">
					<input type="hidden" name="admin_id" value="<?php echo $user; ?>" />
					<input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>" />
					<fieldset>
						<legend><?php echo sprintf($lang_admin_restrictions['restrictions for user x'], panther_htmlspecialchars($username)); ?></legend>
						<div class="infldset">
							<p><?php echo $lang_admin_restrictions['admin restrictions']; ?></p>
							<table class="aligntop">
								<tr>
									<th scope="row"><?php echo $lang_admin_restrictions['board config']; ?></th>
									<td>
										<label class="conl"><input type="radio" name="board_config" value="1"<?php if ($admins[$user]['admin_options'] == '1') echo ' checked="checked"'; ?> tabindex="2" />&#160;<strong><?php echo $lang_admin_common['Yes']; ?></strong></label>
										<label class="conl"><input type="radio" name="board_config" value="0"<?php if ($admins[$user]['admin_options'] == '0') echo ' checked="checked"'; ?> tabindex="3" />&#160;<strong><?php echo $lang_admin_common['No']; ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_restrictions['change config label']; ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_restrictions['board archive']; ?></th>
									<td>
										<label class="conl"><input type="radio" name="board_archive" value="1"<?php if ($admins[$user]['admin_archive'] == '1') echo ' checked="checked"'; ?> tabindex="8" />&#160;<strong><?php echo $lang_admin_common['Yes']; ?></strong></label>
										<label class="conl"><input type="radio" name="board_archive" value="0"<?php if ($admins[$user]['admin_archive'] == '0') echo ' checked="checked"'; ?> tabindex="9" />&#160;<strong><?php echo $lang_admin_common['No']; ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_restrictions['change archive label']; ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_restrictions['board perms']; ?></th>
									<td>
										<label class="conl"><input type="radio" name="board_perms" value="1"<?php if ($admins[$user]['admin_permissions'] == '1') echo ' checked="checked"'; ?> tabindex="4" />&#160;<strong><?php echo $lang_admin_common['Yes']; ?></strong></label>
										<label class="conl"><input type="radio" name="board_perms" value="0"<?php if ($admins[$user]['admin_permissions'] == '0') echo ' checked="checked"'; ?> tabindex="5" />&#160;<strong><?php echo $lang_admin_common['No']; ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_restrictions['change perms label']; ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_restrictions['board cats']; ?></th>
									<td>
										<label class="conl"><input type="radio" name="board_cats" value="1"<?php if ($admins[$user]['admin_categories'] == '1') echo ' checked="checked"'; ?> tabindex="6" />&#160;<strong><?php echo $lang_admin_common['Yes']; ?></strong></label>
										<label class="conl"><input type="radio" name="board_cats" value="0"<?php if ($admins[$user]['admin_categories'] == '0') echo ' checked="checked"'; ?> tabindex="7" />&#160;<strong><?php echo $lang_admin_common['No']; ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_restrictions['change cats label']; ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_restrictions['board forums']; ?></th>
									<td>
										<label class="conl"><input type="radio" name="board_forums" value="1"<?php if ($admins[$user]['admin_forums'] == '1') echo ' checked="checked"'; ?> tabindex="8" />&#160;<strong><?php echo $lang_admin_common['Yes']; ?></strong></label>
										<label class="conl"><input type="radio" name="board_forums" value="0"<?php if ($admins[$user]['admin_forums'] == '0') echo ' checked="checked"'; ?> tabindex="9" />&#160;<strong><?php echo $lang_admin_common['No']; ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_restrictions['change forums label']; ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_restrictions['board groups']; ?></th>
									<td>
										<label class="conl"><input type="radio" name="board_groups" value="1"<?php if ($admins[$user]['admin_groups'] == '1') echo ' checked="checked"'; ?> tabindex="10" />&#160;<strong><?php echo $lang_admin_common['Yes']; ?></strong></label>
										<label class="conl"><input type="radio" name="board_groups" value="0"<?php if ($admins[$user]['admin_groups'] == '0') echo ' checked="checked"'; ?> tabindex="11" />&#160;<strong><?php echo $lang_admin_common['No']; ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_restrictions['change groups label']; ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_restrictions['board censoring']; ?></th>
									<td>
										<label class="conl"><input type="radio" name="board_censoring" value="1"<?php if ($admins[$user]['admin_censoring'] == '1') echo ' checked="checked"'; ?> tabindex="10" />&#160;<strong><?php echo $lang_admin_common['Yes']; ?></strong></label>
										<label class="conl"><input type="radio" name="board_censoring" value="0"<?php if ($admins[$user]['admin_censoring'] == '0') echo ' checked="checked"'; ?> tabindex="11" />&#160;<strong><?php echo $lang_admin_common['No']; ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_restrictions['change censoring label']; ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_restrictions['board ranks']; ?></th>
									<td>
										<label class="conl"><input type="radio" name="board_ranks" value="1"<?php if ($admins[$user]['admin_ranks'] == '1') echo ' checked="checked"'; ?> tabindex="10" />&#160;<strong><?php echo $lang_admin_common['Yes']; ?></strong></label>
										<label class="conl"><input type="radio" name="board_ranks" value="0"<?php if ($admins[$user]['admin_ranks'] == '0') echo ' checked="checked"'; ?> tabindex="11" />&#160;<strong><?php echo $lang_admin_common['No']; ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_restrictions['change ranks label']; ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_restrictions['board robots']; ?></th>
									<td>
										<label class="conl"><input type="radio" name="board_robots" value="1"<?php if ($admins[$user]['admin_robots'] == '1') echo ' checked="checked"'; ?> tabindex="10" />&#160;<strong><?php echo $lang_admin_common['Yes']; ?></strong></label>
										<label class="conl"><input type="radio" name="board_robots" value="0"<?php if ($admins[$user]['admin_robots'] == '0') echo ' checked="checked"'; ?> tabindex="11" />&#160;<strong><?php echo $lang_admin_common['No']; ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_restrictions['change robots label']; ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_restrictions['board smilies']; ?></th>
									<td>
										<label class="conl"><input type="radio" name="board_smilies" value="1"<?php if ($admins[$user]['admin_smilies'] == '1') echo ' checked="checked"'; ?> tabindex="10" />&#160;<strong><?php echo $lang_admin_common['Yes']; ?></strong></label>
										<label class="conl"><input type="radio" name="board_smilies" value="0"<?php if ($admins[$user]['admin_smilies'] == '0') echo ' checked="checked"'; ?> tabindex="11" />&#160;<strong><?php echo $lang_admin_common['No']; ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_restrictions['change smilies label']; ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_restrictions['board warnings']; ?></th>
									<td>
										<label class="conl"><input type="radio" name="board_warnings" value="1"<?php if ($admins[$user]['admin_warnings'] == '1') echo ' checked="checked"'; ?> tabindex="10" />&#160;<strong><?php echo $lang_admin_common['Yes']; ?></strong></label>
										<label class="conl"><input type="radio" name="board_warnings" value="0"<?php if ($admins[$user]['admin_warnings'] == '0') echo ' checked="checked"'; ?> tabindex="11" />&#160;<strong><?php echo $lang_admin_common['No']; ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_restrictions['change warnings label']; ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_restrictions['board moderate']; ?></th>
									<td>
										<label class="conl"><input type="radio" name="board_moderate" value="1"<?php if ($admins[$user]['admin_moderate'] == '1') echo ' checked="checked"'; ?> tabindex="10" />&#160;<strong><?php echo $lang_admin_common['Yes']; ?></strong></label>
										<label class="conl"><input type="radio" name="board_moderate" value="0"<?php if ($admins[$user]['admin_moderate'] == '0') echo ' checked="checked"'; ?> tabindex="11" />&#160;<strong><?php echo $lang_admin_common['No']; ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_restrictions['change moderate label']; ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_restrictions['board attachments']; ?></th>
									<td>
										<label class="conl"><input type="radio" name="board_attachments" value="1"<?php if ($admins[$user]['admin_attachments'] == '1') echo ' checked="checked"'; ?> tabindex="10" />&#160;<strong><?php echo $lang_admin_common['Yes']; ?></strong></label>
										<label class="conl"><input type="radio" name="board_attachments" value="0"<?php if ($admins[$user]['admin_attachments'] == '0') echo ' checked="checked"'; ?> tabindex="11" />&#160;<strong><?php echo $lang_admin_common['No']; ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_restrictions['change attachments label']; ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_restrictions['board restrictions']; ?></th>
									<td>
										<label class="conl"><input type="radio" name="board_restrictions" value="1"<?php if ($admins[$user]['admin_restrictions'] == '1') echo ' checked="checked"'; ?> tabindex="10" />&#160;<strong><?php echo $lang_admin_common['Yes']; ?></strong></label>
										<label class="conl"><input type="radio" name="board_restrictions" value="0"<?php if ($admins[$user]['admin_restrictions'] == '0') echo ' checked="checked"'; ?> tabindex="11" />&#160;<strong><?php echo $lang_admin_common['No']; ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_restrictions['change restrictions label']; ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_restrictions['board maintenance']; ?></th>
									<td>
										<label class="conl"><input type="radio" name="board_maintenance" value="1"<?php if ($admins[$user]['admin_maintenance'] == '1') echo ' checked="checked"'; ?> tabindex="10" />&#160;<strong><?php echo $lang_admin_common['Yes']; ?></strong></label>
										<label class="conl"><input type="radio" name="board_maintenance" value="0"<?php if ($admins[$user]['admin_maintenance'] == '0') echo ' checked="checked"'; ?> tabindex="11" />&#160;<strong><?php echo $lang_admin_common['No']; ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_restrictions['change maintenance label']; ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_restrictions['board updates']; ?></th>
									<td>
										<label class="conl"><input type="radio" name="board_updates" value="1"<?php if ($admins[$user]['admin_updates'] == '1') echo ' checked="checked"'; ?> tabindex="10" />&#160;<strong><?php echo $lang_admin_common['Yes']; ?></strong></label>
										<label class="conl"><input type="radio" name="board_updates" value="0"<?php if ($admins[$user]['admin_updates'] == '0') echo ' checked="checked"'; ?> tabindex="11" />&#160;<strong><?php echo $lang_admin_common['No']; ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_restrictions['install updates label']; ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_restrictions['board plugins']; ?></th>
									<td>
										<label class="conl"><input type="radio" name="board_plugins" value="1"<?php if ($admins[$user]['admin_plugins'] == '1') echo ' checked="checked"'; ?> tabindex="10" />&#160;<strong><?php echo $lang_admin_common['Yes']; ?></strong></label>
										<label class="conl"><input type="radio" name="board_plugins" value="0"<?php if ($admins[$user]['admin_plugins'] == '0') echo ' checked="checked"'; ?> tabindex="11" />&#160;<strong><?php echo $lang_admin_common['No']; ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_restrictions['change plugins label']; ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php echo $lang_admin_restrictions['board users']; ?></th>
									<td>
										<label class="conl"><input type="radio" name="board_users" value="1"<?php if ($admins[$user]['admin_users'] == '1') echo ' checked="checked"'; ?> tabindex="10" />&#160;<strong><?php echo $lang_admin_common['Yes']; ?></strong></label>
										<label class="conl"><input type="radio" name="board_users" value="0"<?php if ($admins[$user]['admin_users'] == '0') echo ' checked="checked"'; ?> tabindex="11" />&#160;<strong><?php echo $lang_admin_common['No']; ?></strong></label>
										<span class="clearb"><?php echo $lang_admin_restrictions['change users label']; ?></span>
									</td>
								</tr>
							</table>
						</div>
					</fieldset>
				</div>
				<p class="submitend"><input type="submit" name="submit" value="<?php echo $lang_common['Submit']; ?>" tabindex="43" /></p>
			</form>
		</div>
	</div>
	<div class="clearer"></div>
</div>
</div>
<?php
}
else
{
	if (count(get_admin_ids()) < 2)
		message($lang_admin_restrictions['no admins available']);

	$cur_admins = $restrictions = array();
	$data = array(
		':admin'	=>	PANTHER_ADMIN,
	);

	$ps = $db->run('SELECT u.username, u.id FROM '.$db->prefix.'users AS u LEFT JOIN '.$db->prefix.'restrictions AS ar ON u.id=ar.admin_id INNER JOIN '.$db->prefix.'groups AS g ON u.group_id=g.g_id WHERE (u.group_id=:admin OR g.g_admin=1) AND u.id!=2 AND ar.admin_id IS NULL ORDER BY u.id ASC', $data);
	foreach ($ps as $admin)
		$cur_admins[] = '<option value="'.$admin['id'].'">'.panther_htmlspecialchars($admin['username']).'</option>';

	$ps = $db->run('SELECT u.username, u.id FROM '.$db->prefix.'users AS u LEFT JOIN '.$db->prefix.'restrictions AS ar ON u.id=ar.admin_id INNER JOIN '.$db->prefix.'groups AS g ON u.group_id=g.g_id WHERE (u.group_id=:admin OR g.g_admin=1) AND u.id!=2 AND ar.admin_id IS NOT NULL ORDER BY u.id ASC', $data);
	foreach ($ps as $admin)
		$restrictions[] = '<option value="'.$admin['id'].'">'.panther_htmlspecialchars($admin['username']).'</option>';

	if (count($cur_admins) < 1)
		$cur_admins[] = '<optgroup label="'.$lang_admin_restrictions['no other admins'].'"></optgroup>';
	
	if (count($restrictions) < 1)
		$restrictions[] = '<optgroup label="'.$lang_admin_restrictions['no other admins'].'"></optgroup>';

	generate_admin_menu('restrictions');
?>
	<div class="blockform">
		<h2><span><?php echo $lang_admin_restrictions['restrictions head']; ?></span></h2>
		<div class="box">
			<form id="restrictions2" method="post" action="<?php echo get_link($panther_url['admin_restrictions_query'], array('action=add&stage=2')); ?>">
				<input type="hidden" name="form_sent" value="1" />
				<input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>" />
				<div class="inform">
					<fieldset>
						<legend><?php echo $lang_admin_restrictions['restriction information']; ?></legend>
						<div class="infldset">
							<br />
								<select name="user">
								<?php echo implode("\n\t\t\t\t\t\t", $cur_admins)."\n"; ?>
								</select>				
							<input type="submit" name="submit" value="<?php echo $lang_common['Submit']; ?>" tabindex="43" />
						<br /><br />
						</div>
					</fieldset>
				</div>
			</form>
			<form id="restrictions2" method="post" action="<?php echo get_link($panther_url['admin_restrictions_query'], array('action=edit&stage=2')); ?>">
				<input type="hidden" name="form_sent" value="1" />
				<input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>" />
				<div class="inform">
					<fieldset>
						<legend><?php echo $lang_admin_restrictions['restriction information 2']; ?></legend>
						<div class="infldset">
							<br />
								<select name="user">
								<?php echo implode("\n\t\t\t\t\t\t", $restrictions)."\n"; ?>
								</select>				
							<input type="submit" name="submit" value="<?php echo $lang_common['Submit']; ?>" tabindex="43" />
						<br /><br />
						</div>
					</fieldset>
				</div>
			</form>
			<form id="restrictions2" method="post" action="<?php echo get_link($panther_url['admin_restrictions_query'], array('action=delete&stage=2')); ?>">
				<input type="hidden" name="form_sent" value="1" />
				<input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>" />
				<div class="inform">
					<fieldset>
						<legend><?php echo $lang_admin_restrictions['restriction information 3']; ?></legend>
						<div class="infldset">
							<br />
								<select name="user">
								<?php echo implode("\n\t\t\t\t\t\t", $restrictions)."\n"; ?>
								</select>				
							<input type="submit" name="submit" value="<?php echo $lang_admin_restrictions['delete']; ?>" tabindex="43" />
						<br /><br />
						</div>
					</fieldset>
				</div>
			</form>

		</div>
	</div>
	<div class="clearer"></div>
</div>
</div>
<?php
}
require PANTHER_ROOT.'footer.php';