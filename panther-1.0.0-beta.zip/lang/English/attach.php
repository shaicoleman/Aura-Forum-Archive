<?php

// Language definitions for frequently used strings
$lang_attach = array(

// attach.php
'Image view'			=>	'Image view',
'Download:'				=>	'Download:'
);
