<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

define('AURA_ROOT', __DIR__.'/');
require AURA_ROOT.'include/init.php';

Aura::run();

ob_flush();
exit;