<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

namespace handlers;
use AuraClass;
use styles;

class maintenance extends AuraClass
{
	//
	// Display a message when board is in maintenance mode
	//
	function show()
	{
		// Send no-cache headers
		header('HTTP/1.1 503 Service Unavailable');
		header('Expires: Thu, 21 Jul 1977 07:30:00 GMT'); // When yours truly first set eyes on this world! :)
		header('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT');
		header('Cache-Control: post-check=0, pre-check=0', false);
		header('Pragma: no-cache'); // For HTTP/1.0 compatibility

		// Send the Content-type header in case the web server is setup to send something else
		header('Content-type: text/html; charset=utf-8');

		// Deal with newlines, tabs and multiple spaces
		$pattern = array("\t", '  ', '  ');
		$replace = array('&#160; &#160; ', '&#160; ', ' &#160;');
		$message = str_replace($pattern, $replace, $this->config['o_maintenance_message']);

		$tpl = $this->template->load('maintenance.tpl');
		$this->template->output($tpl,
			array(
				'message' => $message,
				'style_core' => styles::get_core_path(),
				'page_title' => $this->functions->generate_page_title(array($this->config['o_board_title'], $this->lang->t('Maintenance'))),
				'style' => styles::get_style_root().$this->user['style'],
			), false, false
		);

		// End the transaction
		$this->db->end_transaction();

		exit;
	}
}