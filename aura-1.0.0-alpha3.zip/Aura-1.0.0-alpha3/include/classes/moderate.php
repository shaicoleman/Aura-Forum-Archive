<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class moderate
{
	public function __construct($registry)
	{
		$this->registry = $registry;
		$this->user = $registry->user;
		$this->cache = $registry->cache;
		$this->lang = $registry->lang;
		$this->functions = $registry->functions;
	}

	public function check_user()
	{
		// All other functions require moderator/admin access
		$fid = isset($_GET['fid']) ? intval($_GET['fid']) : 0;
		$forums = $this->cache->get('forums');
		if ($fid < 1 || !isset($forums[$fid]))
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		$cur_forum = $forums[$fid];

		$moderators = $this->cache->get('moderators');
		if (!$this->user['is_admin'] && ($this->user['g_moderator'] == '0' || $this->user['g_global_moderator'] == '0' && !isset($moderators[$fid]['u'.$this->user['id']]) && !isset($moderators[$fid]['g'.$this->user['g_id']])))
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		if ($cur_forum['password'] != '')
			$this->registry->get('\cookie\tracked')->check_forum_login_cookie($fid, $cur_forum['password']);

		// Get topic/forum tracking data
		$tracked_topics = $this->registry->get('\cookie\tracked')->get_tracked_topics();

		// Load the miscellaneous language file
		$this->lang->load('misc');

		return array($fid, $cur_forum, $moderators, $forums);
	}
}