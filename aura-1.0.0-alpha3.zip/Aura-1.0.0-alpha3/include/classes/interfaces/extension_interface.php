<?php
namespace interfaces;

interface extension_interface
{
	public function run();
}