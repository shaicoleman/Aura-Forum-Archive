<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

namespace interfaces;

interface database_interface
{
	/**
	 * Construct the class
	 */
	public function __construct($config);

	/**
	 * Select some information from the table
	 */
	public function select($table, $fields = '*', $parameters = array(), $where = '', $order_by = '');

	/**
	 * Insert some data into the database
	 */
	public function insert($table, $fields);

	/**
	 * Replace an existing database row
	 */
	public function replace($table, $fields = array());

	/**
	 * Check if a row already exists
	 */
	public function row_exists($table, $field, $value);

	/**
	 * Update a row in the database
	 */
	public function update($table, $fields, $where = '', $parameters = array());

	/**
	 * Delete a row in the database
	 */
	public function delete($table, $where = '', $parameters = array());

	/**
	 * Perofrm a JOIN (usually INNER)
	 */
	public function join($table, $alias, $join, $fields = '*', $parameters = array(), $where = '', $order_by = '');

	/**
	 * Run the query!
	 */
	public function run($sql, $parameters = array(), $type = '');

	/**
	 * Start the transaction
	 */
	public function start_transaction();

	/**
	 * End the transaction
	 */
	public function end_transaction();

	/**
	 * Free the database result up
	 */
	public function free_result($ps);

	/**
	 * Get the number of queries
	 */
	public function get_num_queries();

	/**
	 * Get the number of saved queries
	 */
	public function get_saved_queries();

	/**
	 * Get the Database type & version we are using
	 */
	public function get_version();

	/**
	 * Create a new table
	 */
	public function create_table($table_name, $schema);

	/**
	 * Rename a database table
	 */
	public function rename_table($old_table, $new_table);

	/**
	 * Check whether the specified table exists
	 */
	public function table_exists($table);

	/**
	 * Drop a database table
	 */
	public function drop_table($table);

	/**
	 * Alter the field of a database table
	 */
	public function alter_field($table_name, $field_name, $field_type, $allow_null, $default_value = null, $after_field = null);

	/**
	 * Add a field of the database table
	 */
	public function add_field($table_name, $field_name, $field_type, $allow_null, $default_value = null, $after_field = null);

	/**
	 * Check whether a database field exists
	 */
	public function field_exists($table, $field);

	/**
	 * Drop a database field
	 */
	public function drop_field($table_name, $field_name);

	/**
	 * Check whether a specific index exists
	 */
	public function index_exists($table_name, $index_name);

	/**
	 * Add an index to the database
	 */
	public function add_index($table_name, $index_name, $index_fields, $unique = false);

	/**
	 * Drop an index from a table
	 */
	public function drop_index($table_name, $index_name);

	/**
	 * Delete all rows in the database table
	 */
	public function truncate_table($table_name);
}