<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
namespace email;

// Make sure no one attempts to run this script "directly"
if (!defined('config::SESSION'))
	exit;

class email
{
	/**
	 * Construct the email object, instantiate a few things ...
	 */
	public function __construct($registry)
	{
		$this->registry = $registry;
		$this->config = $registry->config;

		if (!defined('FORUM_EOL')) // Define line breaks in mail headers; possible values can be PHP_EOL, "\r\n", "\n" or "\r"
			define('FORUM_EOL', PHP_EOL);

		require_once AURA_ROOT.'include/lib/utf8/utils/ascii.php';
	}

	/**
	 * Encode the mail text which will be sent
	 */
	protected static function encode_mail_text($str)
	{
		if (utf8_is_ascii($str))
			return $str;

		return '=?UTF-8?B?'.base64_encode($str).'?=';
	}

	/**
	 * Main entry point - send the email
	 */
	public function send($to, $subject, $message, $reply_to_email = '', $reply_to_name = '')
	{
		if ($this->config['o_email'] == '0')
			return;

		// Use \r\n for SMTP servers, the system's line ending for local mailers
		$smtp = $this->config['o_smtp_host'] != '';
		$EOL = $smtp ? "\r\n" : FORUM_EOL;

		// Do a little spring cleaning
		$to = utf8_trim(preg_replace('%[\n\r]+%s', '', $to));
		$subject = utf8_trim(preg_replace('%[\n\r]+%s', '', $subject));
		$from_email = utf8_trim(preg_replace('%[\n\r:]+%s', '', $this->config['o_webmaster_email']));
		$from_name = utf8_trim(preg_replace('%[\n\r:]+%s', '', str_replace('"', '', $this->config['o_email_name'])));
		$reply_to_email = utf8_trim(preg_replace('%[\n\r:]+%s', '', $reply_to_email));
		$reply_to_name = utf8_trim(preg_replace('%[\n\r:]+%s', '', str_replace('"', '', $reply_to_name)));

		// Set up some headers to take advantage of UTF-8
		$from = '"'.self::encode_mail_text($from_name).'" <'.$from_email.'>';
		$subject = self::encode_mail_text($subject);

		$headers = 'From: '.$from.$EOL.'Date: '.gmdate('r').$EOL.'MIME-Version: 1.0'.$EOL.'Content-transfer-encoding: 8bit'.$EOL.'Content-type: text/plain; charset=utf-8'.$EOL.'X-Mailer: Aura';

		// If we specified a reply-to email, we deal with it here
		if (!empty($reply_to_email))
		{
			$reply_to = '"'.self::encode_mail_text($reply_to_name).'" <'.$reply_to_email.'>';
			$headers .= $EOL.'Reply-To: '.$reply_to;
		}

		// Make sure all linebreaks are LF in message (and strip out any NULL bytes)
		$message = str_replace("\0", '', aura_linebreaks($message));
		$message = str_replace("\n", $EOL, $message);

		if ($smtp)
			$this->smtp_mail($to, $subject, $message, $headers);
		else
			mail($to, $subject, $message, $headers);
	}

	/**
	 * Parse the server and check response codes
	 */
	protected static function server_parse($socket, $expected_response)
	{
		$server_response = '';
		while (substr($server_response, 3, 1) != ' ')
		{
			if (!($server_response = fgets($socket, 256)))
				throw new Exception('Unable to get mail server response codes. Please contact the forum administrator.');
		}

		if (!(substr($server_response, 0, 3) == $expected_response))
			throw new Exception('Unable to send email. Please contact the forum administrator with the following error message reported by the SMTP server: "'.$server_response.'"');
	}

	/**
	 * Send an email through SMTP
	 */
	protected function smtp_mail($to, $subject, $message, $headers = '')
	{
		static $local_host;

		$recipients = explode(',', $to);

		// Sanitize the message
		$message = str_replace("\r\n.", "\r\n..", $message);
		$message = (substr($message, 0, 1) == '.' ? '.'.$message : $message);

		// Are we using port 25 or a custom port?
		if (strpos($this->config['o_smtp_host'], ':') !== false)
			list($smtp_host, $smtp_port) = explode(':', $this->config['o_smtp_host']);
		else
		{
			$smtp_host = $this->config['o_smtp_host'];
			$smtp_port = 25;
		}

		if ($this->config['o_smtp_ssl'] == '1')
			$smtp_host = 'ssl://'.$smtp_host;

		if (!($socket = fsockopen($smtp_host, $smtp_port, $errno, $errstr, 15)))
			throw new Exception('Could not connect to smtp host "'.$this->config['o_smtp_host'].'" ('.$errno.') ('.$errstr.')');

		self::server_parse($socket, '220');

		if (!isset($local_host))
		{
			// Here we try to determine the *real* hostname (reverse DNS entry preferably)
			$local_host = php_uname('n');

			// Able to resolve name to IP
			if (($local_addr = @gethostbyname($local_host)) !== $local_host)
			{
				// Able to resolve IP back to name
				if (($local_name = @gethostbyaddr($local_addr)) !== $local_addr)
					$local_host = $local_name;
			}
		}

		if ($this->config['o_smtp_user'] != '' && $this->config['o_smtp_pass'] != '')
		{
			fwrite($socket, 'EHLO '.$local_host."\r\n");
			self::server_parse($socket, '250');

			fwrite($socket, 'AUTH LOGIN'."\r\n");
			self::server_parse($socket, '334');

			fwrite($socket, base64_encode($this->config['o_smtp_user'])."\r\n");
			self::server_parse($socket, '334');

			fwrite($socket, base64_encode($this->config['o_smtp_pass'])."\r\n");
			self::server_parse($socket, '235');
		}
		else
		{
			fwrite($socket, 'HELO '.$local_host."\r\n");
			self::server_parse($socket, '250');
		}

		fwrite($socket, 'MAIL FROM: <'.$this->config['o_webmaster_email'].'>'."\r\n");
		self::server_parse($socket, '250');;

		foreach ($recipients as $email)
		{
			fwrite($socket, 'RCPT TO: <'.$email.'>'."\r\n");
			self::server_parse($socket, '250');
		}

		fwrite($socket, 'DATA'."\r\n");
		self::server_parse($socket, '354');

		fwrite($socket, 'Subject: '.$subject."\r\n".'To: <'.implode('>, <', $recipients).'>'."\r\n".$headers."\r\n\r\n".$message."\r\n");

		fwrite($socket, '.'."\r\n");
		self::server_parse($socket, '250');

		fwrite($socket, 'QUIT'."\r\n");
		fclose($socket);

		return true;
	}
}