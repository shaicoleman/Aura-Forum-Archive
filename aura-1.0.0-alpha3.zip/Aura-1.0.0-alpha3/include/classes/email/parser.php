<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

namespace email;
use AuraClass;
use lang;

class parser extends AuraClass
{
	function parse_email($tpl, $language, $data)
	{
		$mail_tpl = trim(file_get_contents(lang::mail_template_location($language).$tpl.'.tpl'));
		$data['message']['<board_mailer>'] = $this->config['o_board_title'];

		// The first row contains the subject (it also starts with "Subject:")
		$first_crlf = strpos($mail_tpl, "\n");
		$mail_subject = trim(substr($mail_tpl, 8, $first_crlf-8));
		$mail_message = trim(substr($mail_tpl, $first_crlf));
			
		if (isset($data['subject']))
			$mail_subject = str_replace(array_keys($data['subject']), array_values($data['subject']), $mail_subject);
			
		$mail_message = str_replace(array_keys($data['message']), array_values($data['message']), $mail_message);
		return array('subject' => $mail_subject, 'message' => $mail_message);
	}
}