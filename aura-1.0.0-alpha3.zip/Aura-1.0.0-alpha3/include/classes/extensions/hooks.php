<?php
namespace extensions;

// Hooks for the extensions
class hooks extends \extensions\base_hook
{
	protected $hooks = array();
	public function fire($name)
	{
		$args = func_get_args();
        array_shift($args);

		if (!isset($this->hooks[$name]))
		{
			if (isset($args[0]))
				return $args[0];
			else
				return;
		}

		$i = 0;
		$output = array();
		if (!empty($this->hooks[$name]))
		{
			foreach ($this->hooks[$name] as $hook)
			{
				$output[] = call_user_func_array($hook, $args);
				++$i;
			}
		}

		if ($i == 1 || !is_array($args[0]))
			return $output[0];
		else
		{
			$data = array();

			// Move all the keys to the same level
			array_walk_recursive($output, function ($v, $k) use (&$data)
			{
				$data[] = $v;
			});

			$data = array_unique($data);
			return $data;
		}
	}

	public function bind($name, $callable)
	{
		if (!isset($this->hooks[$name]))
			$this->hooks[$name] = array();

		if (is_callable($callable))
			$this->hooks[$name][] = $callable;
	}
}