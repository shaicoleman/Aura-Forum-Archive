<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

// Make sure no one attempts to run this script "directly"
if (!defined('config::SESSION'))
	exit;

class subscriptions
{
	public function __construct($registry)
	{
		$this->registry = $registry;
		$this->db = $registry->db;
		$this->lang = $registry->lang;
		$this->url = $registry->rewrite->url;
		$this->user = $registry->user;
		$this->config = $registry->config;
		$this->cache = $registry->cache;
		$this->functions = $registry->functions;

		$this->forums = $this->cache->get('forums');
	}

	/**
	 * Translate some BBCodes into more "email friendly" formats
	 */
	public function bbcode2email($text, $wrap_length = 72)
	{
		$text = utf8_trim($text, "\t\n ");
		$shortcut_urls = array(
			'topic' => $this->url['topic'],
			'post' => $this->url['post'],
			'forum' => $this->url['forum'],
			'user' => $this->url['profile'],
		);

		// Split code blocks and text so BBcode in codeblocks won't be touched
		list($code, $text) = $this->registry->get('\message\bbcode')->extract_blocks($text, '[code]', '[/code]');

		// Strip all bbcodes, except the quote, url, img, email, code and list items bbcodes
		$text = preg_replace(array(
			'%\[/?(?!(?:quote|url|topic|post|user|forum|img|email|code|list|\*))[a-z]+(?:=[^\]]+)?\]%i',
			'%\n\[/?list(?:=[^\]]+)?\]%i' // A separate regex for the list tags to get rid of some whitespace
		), '', $text);

		// Match the deepest nested bbcode
		// An adapted example from Mastering Regular Expressions
		$match_quote_regex = '%
			\[(quote|\*|url|img|email|topic|post|user|forum)(?:=([^\]]+))?\]
			(
				(?>[^\[]*)
				(?>
					(?!\[/?\1(?:=[^\]]+)?\])
					\[
					[^\[]*
				)*
			)
			\[/\1\]
		%ix';

		$url_index = 1;
		$url_stack = array();
		while (preg_match($match_quote_regex, $text, $matches))
		{
			// Quotes
			if ($matches[1] == 'quote')
			{
				// Put '>' or '> ' at the start of a line
				$replacement = preg_replace(
					array('%^(?=\>)%m', '%^(?!\>)%m'),
					array('>', '> '),
					$matches[2].' '.$this->lang->t('wrote').'\n'.$matches[3]);
			}

			// List items
			elseif ($matches[1] == '*')
				$replacement = ' * '.$matches[3];

			// URLs and emails
			elseif (in_array($matches[1], array('url', 'email')))
			{
				if (!empty($matches[2]))
				{
					$replacement = '['.$matches[3].']['.$url_index.']';
					$url_stack[$url_index] = $matches[2];
					$url_index++;
				}
				else
					$replacement = '['.$matches[3].']';
			}

			// Images
			elseif ($matches[1] == 'img')
			{
				if (!empty($matches[2]))
					$replacement = '['.$matches[2].']['.$url_index.']';
				else
					$replacement = '['.basename($matches[3]).']['.$url_index.']';

				$url_stack[$url_index] = $matches[3];
				$url_index++;
			}

			// Topic, post, forum and user URLs
			elseif (in_array($matches[1], array('topic', 'post', 'forum', 'user')))
			{
				$arg = '';
				if ($matches[1] == 'topic')
				{
					$data = array(
						':id' => $matches[3],
					);

					$ps = $this->db->select('topics', 'subject', $data, 'id=:id');
					$arg = url_friendly($ps->fetchColumn());
				}
				else if ($matches[1] == 'forum')
				{
					if (isset($this->forums[$matches[3]]))
						$arg = url_friendly($this->forums[$matches[3]]['forum_name']);
				}
				else if ($matches[1] == 'user')
				{
					$data = array(
						':username' => $matches[3],
					);

					$ps = $this->db->select('users', 'id', $data, 'username=:username');
					$id = $ps->fetchColumn();

					$arg = url_friendly($matches[3]);
					$matches[3] = $id;
				}

				if (!empty($matches[2]))
				{
					$replacement = '['.$matches[3].']['.$url_index.']';
					$url_stack[$url_index] = aura_link($shortcut_urls[$matches[1]], array($matches[2], $arg));
					$url_index++;
				}
				else
					$replacement = '['.aura_link($shortcut_urls[$matches[1]], array($matches[3], $arg)).']';
			}

			// Update the main text if there is a replacement
			if (!is_null($replacement))
			{
				$text = str_replace($matches[0], $replacement, $text);
				$replacement = null;
			}
		}

		// Put code blocks and text together
		if (isset($code))
		{
			$parts = explode("\1", $text);
			$text = '';
			foreach ($parts as $i => $part)
			{
				$text .= $part;
				if (isset($code[$i]))
					$text .= trim($code[$i], "\n\r");
			}
		}

		// Put URLs at the bottom
		if ($url_stack)
		{
			$text .= "\n\n";
			foreach ($url_stack as $i => $url)
				$text .= "\n".' ['.$i.']: '.$url;
		}

		// Wrap lines if $wrap_length is higher than -1
		if ($wrap_length > -1)
		{
			// Split all lines and wrap them individually
			$parts = explode("\n", $text);
			foreach ($parts as $k => $part)
			{
				preg_match('%^(>+ )?(.*)%', $part, $matches);
				$parts[$k] = wordwrap($matches[1].$matches[2], $wrap_length -
					strlen($matches[1]), "\n".$matches[1]);
			}

			return implode("\n", $parts);
		}
		else
			return $text;
	}

	/**
	 * Handle subscriptions for an entire topic
	 */
	public function handle_topic_subscriptions($tid, $post_data, $replier, $pid, $previous_post_time = 0)
	{
		if ($this->config['o_topic_subscriptions'] != '1')
			return;

		// Get the post time for the previous post in this topic
		if (!$previous_post_time)
		{
			$data = array(
				':tid' => $tid,
			);

			$ps = $this->db->select('posts', 'posted', $data, 'topic_id=:tid', 'id DESC LIMIT 1,1');
			$previous_post_time = $ps->fetchColumn();
		}

		$data = array(
			':fid' => isset($post_data['forum_id']) ? $post_data['forum_id'] : $post_data['id'],
			':previous_post' => $previous_post_time,
			':tid' => $tid,
			':id' => $this->user['id'],
		);

		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'topic_subscriptions',
				'as' => 's',
				'on' => 'u.id=s.user_id',
			),
			array(
				'type' => 'LEFT',
				'table' => 'groups',
				'as' => 'g',
				'on' => 'u.group_id=g.g_id',
			),
			array(
				'type' => 'LEFT',
				'table' => 'forum_perms',
				'as' => 'fp',
				'on' => '(fp.forum_id=:fid AND fp.group_id=u.group_id)',
			),
			array(
				'type' => 'LEFT',
				'table' => 'online',
				'as' => 'o',
				'on' => 'u.id=o.user_id',
			),
			array(
				'type' => 'LEFT',
				'table' => 'bans',
				'as' => 'b',
				'on' => 'u.username=b.username',
			),
		);

		// Get any subscribed users that should be notified (banned users are excluded)
		$ps = $this->db->join('users', 'u', $join, 'u.id, u.username, u.email, u.salt, u.login_key, u.notify_with_post, u.language', $data, 'b.username IS NULL AND COALESCE(o.logged, u.last_visit)>:previous_post AND (fp.read_forum IS NULL OR fp.read_forum=1) AND s.topic_id=:tid AND u.id!=:id');
		if ($ps->rowCount())
		{
			$cleaned_message = $this->bbcode2email($post_data['message'], -1);

			// Loop through subscribed users and send emails
			$email = new email($this->config);
			foreach ($ps as $cur_subscriber)
			{
				if (!file_exists(lang::mail_template_location($cur_subscriber['language']).'new_reply.tpl'))
					continue;

				$token = aura_hash($cur_subscriber['id'].'viewforum.php'.$cur_subscriber['salt'].$cur_subscriber['login_key']);
				$info = array(
					'subject' => array(
						'<topic_subject>' => $post_data['subject'],
					),
					'message' => array(
						'<username>' => $cur_subscriber['username'],
						'<topic_subject>' => $post_data['subject'],
						'<replier>' => $replier,
						'<post_url>' => aura_link($this->url['post'], array($pid)),
						'<unsubscribe_url>' => aura_link($this->url['topic_unsubscribe'], array($tid, $token)),
						'<message>' => $cleaned_message,
					)
				);

				// Load the "new reply" template
				$mail_tpl = parse_email((($cur_subscriber['notify_with_post'] == '0') ? 'new_reply' : 'new_reply_full'), $cur_subscriber['language'], $info);
				$email->send($cur_subscriber['email'], $mail_tpl['subject'], $mail_tpl['message']);
			}
		}
	}

	/**
	 * Handle subscriptions for an entire forum
	 */
	public function handle_forum_subscriptions($post_data, $replier, $tid)
	{
		if ($this->config['o_forum_subscriptions'] != '1')
			return;

		$forum_id = isset($post_data['forum_id']) ? $post_data['forum_id'] : $post_data['id'];
		$poster_id = isset($post_data['poster_id']) ? $post_data['poster_id'] : $this->user['id'];

		// Get any subscribed users that should be notified (banned users are excluded)
		$data = array(
			':id'	=>	$this->user['id'],
			':post_id'	=>	$forum_id,
			':forum_id'	=>	$forum_id,
		);

		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'forum_subscriptions',
				'as' => 's',
				'on' => 'u.id=s.user_id',
			),
			array(
				'type' => 'LEFT',
				'table' => 'groups',
				'as' => 'g',
				'on' => 'u.group_id=g.g_id',
			),
			array(
				'type' => 'LEFT',
				'table' => 'forum_perms',
				'as' => 'fp',
				'on' => '(fp.forum_id=:post_id AND fp.group_id=u.group_id)',
			),
			array(
				'type' => 'LEFT',
				'table' => 'bans',
				'as' => 'b',
				'on' => 'u.username=b.username',
			),
		);

		$ps = $this->db->join('users', 'u', $join, 'u.id, u.username, u.email, u.salt, u.login_key, u.notify_with_post, u.language, u.group_id, g.g_global_moderator, g.g_admin', $data, 'b.username IS NULL AND (fp.read_forum IS NULL OR fp.read_forum=1) AND s.forum_id=:forum_id AND u.id!=:id');
		if ($ps->rowCount())
		{
			$is_moderator = false;
			$cleaned_message = $this->bbcode2email($post_data['message'], -1);
			if ($this->forums[$forum_id]['protected'] == '1')
			{
				$data = array(
					':id' => $cur_subscriber['id'],
					':gid' => $cur_subscriber['group_id'],
					':fid' => $forum_id,
				);

				$ps1 = $db->select('moderators', 1, '(user_id=:id OR group_id=:gid) AND forum_id=:fid');
				$is_moderator = ($ps1->rowCount()) ? true : false;
			}

			// Loop through subscribed users and send emails
			$email = new email($this->config);
			foreach ($ps as $cur_subscriber)
			{
				if ($this->forums[$forum_id]['protected'] == '1' && $cur_subscriber['g_global_moderator'] != '1' && $cur_subscriber['g_admin'] != '1' && $cur_subscriber['group_id'] != AURA_ADMIN && !$is_moderator && $cur_subscriber['id'] != $poster_id || !file_exists(lang::mail_template_location($cur_subscriber['language']).'new_topic.tpl'))
					continue;

				$token = aura_hash($cur_subscriber['id'].'viewforum.php'.$cur_subscriber['salt'].$cur_subscriber['login_key']);
				$info = array(
					'subject' => array(
						'<forum_name>' => $post_data['forum_name'],
					),
					'message' => array(
						'<username>' => $cur_subscriber['username'],
						'<topic_subject>' => $post_data['subject'],
						'<forum_name>' => $post_data['forum_name'],
						'<poster>' => $replier,
						'<topic_url>' => aura_link($this->url['topic'], array($tid, url_friendly($post_data['subject']))),
						'<unsubscribe_url>' => aura_link($this->url['forum_unsubscribe'], array($forum_id, $token)),
						'<message>' => $cleaned_message,
					),
				);

				// Load the "new topic" template
				$mail_tpl = parse_email((($cur_subscriber['notify_with_post'] == '0') ? 'new_topic' : 'new_topic_full'), $cur_subscriber['language'], $info);
				$email->send($cur_subscriber['email'], $mail_tpl['subject'], $mail_tpl['message']);
			}
		}
	}
}