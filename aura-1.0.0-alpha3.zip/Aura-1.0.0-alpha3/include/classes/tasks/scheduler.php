<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

namespace tasks;
use Exception;

// Make sure no one attempts to run this script "directly"
if (!defined('config::SESSION'))
	exit;

/**
 * A helper class to schedule the task management of the forum
 */
class scheduler
{
	/**
	 * Holds the list of tasks
	 */
	protected $task_list;

	/**
	 * Construct a few things
	 */
	public function __construct($registry)
	{
		$this->registry = $registry;
		$this->cache = $registry->cache;
		$this->config = $registry->config;
		$this->db = $registry->db;

		$this->task_list = $this->cache->get('tasks');
	}

	/**
	 * Check all tasks and see if we're due to run one
	 */
	public function run_tasks()
	{
		foreach ($this->task_list as $task_id => $cur_task)
		{
			if ($cur_task['next_run'] < CURRENT_TIMESTAMP)
			{
				$this->run($task_id);

				if (!defined('AURA_CRON_MANAGER'))
					break; // If it's running through page load, only run 1 task per page-load
			}
		}
	}

	/**
	 * Run the task!
	 */
	protected function run($task_id)
	{
		$this->task = $this->task_list[$task_id];
		if (!preg_match('/^[a-z-_0-9]+$/i', $this->task['script']) || !file_exists(AURA_ROOT.'include/tasks/'.$this->task['script'].'.php'))
			throw new Exception('Invalid task name or task does not exist');

		if ($this->task['locked'])
			return;

		// Lock the task so it can't be ran twice
		$this->lock(1);

		$task_name = 'task_'.$this->task['script'];
		if (!class_exists($task_name)) // If there are duplicate tasks, only perform it once
		{
			require AURA_ROOT.'include/tasks/'.$this->task['script'].'.php';
			$task = new $task_name($this->registry);
			$task->run();
		}

		$this->lock(0);
	}

	/**
	 * Lock the task so we can't run it twice
	 */
	protected function lock($lock = 1)
	{
		$update = array(
			'locked' => $lock,
		);

		if (!$lock) // If we're unlocking the task, we need the next run time
			$update['next_run'] = $this->registry->get('\tasks\task_time')->next_run($this->task['minute'], $this->task['hour'], $this->task['day'], $this->task['month'], $this->task['week_day']);

		$data = array(
			':id' => $this->task['id'],
		);

		$this->db->update('tasks', $update, 'id=:id', $data);
		$this->cache->generate('tasks');
	}
}