<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

namespace forum;
use AuraClass;
use PDO;

class forum extends AuraClass
{
	//
	// Update posts, topics, last_post, last_post_id and last_poster for a forum
	//
	function update($forum_id)
	{
		$data = array(
			':id'	=>	$forum_id,
		);

		$ps = $this->db->select('topics', 'COUNT(id), SUM(num_replies)', $data, 'forum_id=:id AND approved=1 AND deleted=0');
		list($num_topics, $num_posts) = $ps->fetch(PDO::FETCH_NUM);

		$num_posts = $num_posts + $num_topics; // $num_posts is only the sum of all replies (we have to add the topic posts)
		$data = array(
			':id' => $forum_id
		);

		$ps = $this->db->select('topics', 'last_post, last_post_id, last_poster, subject, id', $data, 'forum_id=:id AND approved=1 AND deleted=0 AND moved_to IS NULL ORDER BY last_post DESC LIMIT 1');
		if ($ps->rowCount()) // There are topics in the forum
		{
			list($last_post, $last_post_id, $last_poster, $last_topic, $last_topic_id) = $ps->fetch(PDO::FETCH_NUM);
			$update = array(
				'num_topics'	=>	$num_topics,
				'num_posts'		=>	$num_posts,
				'last_post'		=>	$last_post,
				'last_post_id'	=>	$last_post_id,
				'last_topic'	=>	$last_topic,
				'last_topic_id'	=>	$last_topic_id,
				'last_poster'	=>	$last_poster,
			);

			$data = array(
				':id' => $forum_id,
			);

			$this->db->update('forums', $update, 'id=:id', $data);
		}
		else // There are no topics
		{
			$data = array(
				':num_topics'	=>	$num_topics,
				':num_posts'	=>	$num_posts,
				':id'		=>	$forum_id,
			);

			// Annoyingly PDO does not allow NULL values to be added in prepared statements. When added it becomes 'NULL', so we have to run the query manually instead
			$this->db->run('UPDATE '.$this->db->prefix.'forums SET num_topics=:num_topics, num_posts=:num_posts, last_post=NULL, last_post_id=NULL, last_poster=NULL, last_topic=\'\', last_topic_id=0 WHERE id=:id', $data);
		}
	}
}