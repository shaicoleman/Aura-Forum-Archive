<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class pagination extends AuraClass
{
	//
	// Generate a string with numbered links (for multipage scripts)
	//
	function paginate($num_pages, $cur_page, $link, $args = null)
	{
		$pages = array();
		$link_to_all = false;

		// If $cur_page == -1, we link to all pages (used in viewforum.php)
		if ($cur_page == -1)
		{
			$cur_page = 1;
			$link_to_all = true;
		}

		if ($num_pages > 1)
		{
			if ($cur_page > 1)
				$pages[] = array('item' => true, 'href' => $this->aura_sublink($link, $this->rewrite->url['page'], ($cur_page - 1), $args), 'current' => $this->lang->t('Previous'));

			if ($cur_page > 3)
			{
				$pages[] = array('item' => (empty($pages) ? true : false), 'href' => $this->aura_sublink($link, $this->rewrite->url['page'], 1, $args), 'current' => 1);
				if ($cur_page > 5)
					$pages[] = $this->lang->t('Spacer');
			}

			// Don't ask me how the following works. It just does, OK? =)
			for ($current = ($cur_page == 5) ? $cur_page - 3 : $cur_page - 2, $stop = ($cur_page + 4 == $num_pages) ? $cur_page + 4 : $cur_page + 3; $current < $stop; ++$current)
			{
				if ($current < 1 || $current > $num_pages)
					continue;
				else if ($current != $cur_page || $link_to_all)
					$pages[] = array('item' => (empty($pages) ? true : false), 'href' => $this->aura_sublink($link, $this->rewrite->url['page'], $current, $args), 'current' => $this->forum_number_format($current));
				else
					$pages[] = array('item' => (empty($pages) ? true : false), 'current' => $this->forum_number_format($current));
			}

			if ($cur_page <= ($num_pages-3))
			{
				if ($cur_page != ($num_pages-3) && $cur_page != ($num_pages-4))
					$pages[] = $lang->t('Spacer');

				$pages[] = array('item' => (empty($pages) ? true : false), 'href' => $this->aura_sublink($link, $this->rewrite->url['page'], $num_pages, $args), 'current' => $this->forum_number_format($num_pages));
			}

			// Add a next page link
			if ($num_pages > 1 && !$link_to_all && $cur_page < $num_pages)
				$pages[] = array('item' => (empty($pages) ? true : false), 'rel' => 'next', 'href' => $this->aura_sublink($link, $this->rewrite->url['page'], ($cur_page + 1), $args), 'current' => $this->lang->t('Next'));
		}

		$tpl = $this->template->load('pagination.tpl', false, false);
		return $this->template->render($tpl, 
			array(
				'num_pages' => $num_pages,
				'cur_page' => $cur_page,
				'pages' => $pages,
				'link' => $link,
			)
		);
	}
}