<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

namespace upgrade;
use lang;

class automatic extends \upgrade\core_upgrader implements \interfaces\upgrader_interface
{
	public $version;
	public function run()
	{
		$upgrade = $this->cache->generate('updates', array($this->lang), true);
		$info = $this->db->get_version();

		if ($upgrade['failed'])
			return array('state' => false, 'attempted' => false, 'lang' => $this->lang->t('Upgrade check failed message'));
		else if (substr($upgrade['package_url'], 0, 29) !== 'https://www.get-aura.org/')
			return array('state' => false, 'attempted' => false, 'lang' => $this->lang->t('Package URL invalid'));
		else if (version_compare(PHP_VERSION, $upgrade['php_version'], '<'))
			return array('state' => false, 'attempted' => false, 'lang' => $this->lang->t('Discontinued PHP version', PHP_VERSION, $upgrade['version'], $upgrade['php_version']));
		else if (!in_array($info['name'], $upgrade['drivers']))
			return array('state' => false, 'attempted' => false, 'lang' => $this->lang->t('Discontinued database driver', $info['name'], $upgrade['version']));
		else if (!$this->should_upgrade($upgrade['version']))
			return array('state' => false, 'attempted' => false, 'lang' => $this->lang->t('No upgrade necessary', $upgrade['version']));

		// Make sure we know what version this is in case something fails from this point on
		$this->version = $upgrade['version'];

		// Has the default language been updated?
		if (!lang::language_exists($upgrade['default_lang']))
			$this->update_language = true;

		// Lock the upgrader so we can continue
		if (!$this->lock_upgrader())
			return array('state' => false, 'attempted' => false, 'lang' => $this->lang->t('Upgrader locked'));

		@set_time_limit(0);

		// Attempt to download the upgrade package
		$package = $this->download_package($upgrade['package_url']);
		if (!$package['state'])
		{
			$this->unlock_upgrader();
			return array('state' => false, 'attempted' => true, 'lang' => $package['lang']);
		}

		// Unarchive the package
		$package = $this->unarchive_package(AURA_ROOT.$this->upgrade_location, $upgrade['package'], $package['archive'], $upgrade['version']);
		if (!$package['state'])
		{
			$this->unlock_upgrader();
			return array('state' => false, 'attempted' => true, 'lang' => $package['lang']);
		}

		// Install the package
		$package = $this->install_package($package['location'], AURA_ROOT, $upgrade['default_lang']);
		if (!$package['state'])
		{
			$this->unlock_upgrader();
			return array('state' => false, 'attempted' => true, 'lang' => $package['lang']);
		}

		// Finally, update the database
		$this->update_database($upgrade['version'], $upgrade['default_lang']);

		$this->unlock_upgrader();
		return array('state' => true, 'attempted' => true, 'lang' => $this->lang->t('Upgrade completed'));
	}
}