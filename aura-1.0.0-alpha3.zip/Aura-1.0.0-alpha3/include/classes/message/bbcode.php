<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

namespace message;
use AuraClass;

class bbcode extends AuraClass
{
	/**
	 * The current style of the forum
	 */
	protected $style;

	//
	// Split text into chunks ($inside contains all text inside $start and $end, and $outside contains all text outside)
	//
	function split_text($text, $start, $end, $retab = true)
	{
		$result = array(0 => array(), 1 => array()); // 0 = inside, 1 = outside

		// split the text into parts
		$parts = preg_split('%'.preg_quote($start, '%').'(.*)'.preg_quote($end, '%').'%Us', $text, -1, PREG_SPLIT_DELIM_CAPTURE);
		$num_parts = count($parts);

		// preg_split results in outside parts having even indices, inside parts having odd
		for ($i = 0;$i < $num_parts;$i++)
			$result[1 - ($i % 2)][] = $parts[$i];

		if ($this->config['o_indent_num_spaces'] != 8 && $retab)
		{
			$spaces = str_repeat(' ', $this->config['o_indent_num_spaces']);
			$result[1] = str_replace("\t", $spaces, $result[1]);
		}

		return $result;
	}

	function extract_blocks($text, $start, $end, $retab = true)
	{
		$code = array();
		$start_len = strlen($start);
		$end_len = strlen($end);
		$regex = '%(?:'.preg_quote($start, '%').'|'.preg_quote($end, '%').')%';
		$matches = array();

		if (preg_match_all($regex, $text, $matches))
		{
			$counter = $offset = 0;
			$start_pos = $end_pos = false;

			foreach ($matches[0] as $match)
			{
				if ($match == $start)
				{
					if ($counter == 0)
						$start_pos = strpos($text, $start);
					$counter++;
				}
				elseif ($match == $end)
				{
					$counter--;
					if ($counter == 0)
						$end_pos = strpos($text, $end, $offset + 1);
					$offset = strpos($text, $end, $offset + 1);
				}

				if ($start_pos !== false && $end_pos !== false)
				{
					$code[] = substr($text, $start_pos + $start_len,
						$end_pos - $start_pos - $start_len);
					$text = substr_replace($text, "\1", $start_pos,
						$end_pos - $start_pos + $end_len);
					$start_pos = $end_pos = false;
					$offset = 0;
				}
			}
		}

		if ($this->config['o_indent_num_spaces'] != 8 && $retab)
		{
			$spaces = str_repeat(' ', $this->config['o_indent_num_spaces']);
			$text = str_replace("\t", $spaces, $text);
		}

		return array($code, $text);
	}

	//
	// Replace censored words in $text
	//
	function censor_words($text)
	{
		static $search_for, $replace_with;

		// If not already built in a previous call, build an array of censor words and their replacement text
		if (!isset($search_for))
			list ($search_for, $replace_with) = $this->cache->get('censoring');

		if (!empty($search_for))
			$text = substr(ucp_preg_replace($search_for, $replace_with, ' '.$text.' '), 1, -1);

		return $text;
	}

	/**
	 * Style some individual lines of HTML, these are too small for templates
	 */
	function style_html($html, $args = null)
	{
		// If the cache has failed for some reason, just fall back on the default styles.xml
		if (is_null($this->style))
		{
			$parser = new \xml\parser;
			$parser->load(AURA_ROOT.'include/styles.xml');
			$style = $parser->fetch_array();

			$config = array();
			foreach ($style['style'] as $name => $item)
			{
				if ($name == 'data')
					continue;

				$this->style[$name] = isset($item['data']) ? utf8_trim($item['data']) : '';
			}
		}

		if ($args == null)
			return $this->style[$html];
		else if (!is_array($args))
			return str_replace('$1', $args, $this->style[$html]);

		$html = $this->style[$html];
		for ($i = 0; isset($args[$i]); ++$i)
			$html = str_replace('$'.($i + 1), $args[$i], $html);

		return $html;
	}
}