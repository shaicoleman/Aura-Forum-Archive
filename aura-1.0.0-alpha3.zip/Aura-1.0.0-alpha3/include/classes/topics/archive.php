<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

namespace topics;
use AuraClass;
use PDO;

class archive extends AuraClass
{
	function check_archive_rules($archive_rules, $tid = 0)
	{
		$day = (24*60*60);	// Set some useful time related stuff
		$month = (24*60*60*date('t'));
		$year = ($month*12);

		$sql = $data = array();
		if ($archive_rules['closed'] != '2')
		{
			$data[] = $archive_rules['closed'];
			$sql[] = 'closed=?';
		}
		
		if ($archive_rules['sticky'] != '2')
		{
			$data[] = $archive_rules['sticky'];
			$sql[] = 'sticky=?';
		}
		
		if ($archive_rules['time'] != '0')
		{
			switch ($archive_rules['unit'])
			{
				case 'years':
					$seconds = $archive_rules['time']*$year;
				break;
				case 'months':
					$seconds = $archive_rules['time']*$month;
				break;
				case 'days':
				default:
					$seconds = $archive_rules['time']*$day;
				break;
			}

			$data[] = (CURRENT_TIMESTAMP-$seconds);
			$sql[] = 'last_post<?';
		}
		
		if ($archive_rules['forums'][0] != '0')
		{
			$forums = '';
			for ($i = 0; $i < count($i); $i++)
			{
				$forums .= ($forums != '') ? ',?' : '?';
				$data[] = $archive_rules['forums'][$i];
			}
			$sql[] = 'forum_id IN('.$forums.')';
		}

		if ($tid != 0)
		{
			$sql[] = 'id=?';
			$data[] = $tid;
			$fetch = 1;
		}
		else
		{
			$fetch = 'id';
			$sql[] = 'archived=0 AND deleted=0 AND approved=1';	// Make sure to get topics that have the ability to be archived
		}

		$ps = $this->db->select('topics', $fetch, $data, implode(' AND ', $sql));
		
		if ($tid != 0)
		{
			if ($ps->rowCount()) // Time to archive!
			{
				$update = array(
					'archived'	=>	1,
				);
				
				$data = array(
					':id'	=>	$tid,
				);

				return $this->db->update('topics', $update, 'id=:id', $data);
			}
			else
				return 0;
		}
		else
		{
			$topics = array(
				'count'	=>	$ps->rowCount(),
				'topics' =>	array(),
			);

			$ps->setFetchMode(PDO::FETCH_COLUMN, 0);
			foreach ($ps as $tid)
				$topics['topics'][] = $tid;
		}
			return $topics;
	}
}