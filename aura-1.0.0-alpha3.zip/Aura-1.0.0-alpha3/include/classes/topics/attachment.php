<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

namespace topics;
use AuraClass;

class attachment extends AuraClass
{
	function attach_delete_thread($id = 0)
	{
		// Should we orhpan any attachments
		if ($this->config['o_create_orphans'] == 0)
		{
			$join = array(
				array(
					'type' => 'LEFT',
					'table' => 'posts',
					'as' => 'p',
					'on' => 'a.post_id=p.id',
				),
			);

			$data = array(
				':id' => $id,	
			);

			$ps = $this->db->join('attachments', 'a', $join, 'a.id', $data, 'p.topic_id=:id');
			if ($ps->rowCount())
			{
				$ps->setFetchMode(PDO::FETCH_COLUMN, 0);
				foreach ($ps as $attach_id)
				{
					if (!delete_attachment($attach_id))
						continue;
				}
			}
		}
	}

	function attach_delete_post($id = 0)
	{
		$data = array(
			':id' => $id,
		);

		$ps = $this->db->select('attachments', 'id', $data, 'post_id=:id');
		if ($ps->rowCount())
		{
			$ps->setFetchMode(PDO::FETCH_COLUMN, 0);		
			foreach ($ps as $attach_id)
			{
					if (!$this->delete_attachment($attach_id))
						continue;
			}
		}
	}

	function delete_attachment($item = 0)
	{
		$join = array(
			array(
				'type' => 'LEFT',
				'table' => 'posts',
				'as' => 'p',
				'on' => 'a.post_id=p.id',
			),
			array(
				'type' => 'LEFT',
				'table' => 'topics',
				'as' => 't',
				'on' => 'p.topic_id=t.id',
			),
			array(
				'type' => 'LEFT',
				'table' => 'forum_perms',
				'as' => 'fp',
				'on' => 't.forum_id=fp.forum_id AND fp.group_id=:uid',
			),
		);

		$data = array(
			':uid' => $this->user['g_id'],
			':id' => $item,
		);
		
		// Make sure the item actually exists
		$ps = $this->db->join('attachments', 'a', $join, 'a.owner, a.location', $data, 'a.id=:id');
		if (!$ps->rowCount())
			$this->message($this->lang->t('Bad request'));
		else
			$attachment = $ps->fetch();
		
		$data = array(
			':id' => $item,
		);

		$this->db->delete('attachments', 'id=:id', $data);
		if ($this->config['o_create_orphans'] == '0')
			@unlink($this->config['o_attachments_dir'].$attachment['location']);

		return true;
	}

	function create_attachment($name = '', $mime = '', $size = 0, $tmp_name = '', $post_id = 0, $message = 0)
	{
		$unique_name = $this->attach_generate_filename($this->config['o_attachments_dir'], $message, $size);
		if (!move_uploaded_file($tmp_name, $this->config['o_attachments_dir'].$unique_name))
			throw new Exception('Unable to move file from: '.$tmp_name.' to '.$this->config['o_attachments_dir'].$unique_name);

		if (strlen($mime) < 1)
			$mime = $this->attach_create_mime($this->attach_find_extention($name));

		$insert	= array(
			'owner'	=>	$this->user['id'],
			'post_id'	=>	$post_id,
			'filename'	=>	$name,
			'extension'	=>	$this->attach_get_extension($name),
			'mime'		=>	$mime,
			'location'	=>	$unique_name,
			'size'		=>	$size
		);

		$this->db->insert('attachments', $insert);
		return true;
	}

	function attach_generate_filename($storagepath, $messagelength = 0, $size = 0)
	{
		// Login keys are one time use only. Use this as salt too.
		$newfile = md5($messagelength.$size.$this->user['login_key'].random_key(18)).'.attach';
		if (!is_file($storagepath.$newfile))
			return $newfile;
		else
			return $this->attach_generate_filename($storagepath, $messagelength, $size);
	}

	function check_file_extension($file_name)
	{
		$actual_extension = $this->attach_get_extension($file_name);
		$always_deny = explode(',', $this->config['o_always_deny']);
		foreach ($always_deny as $ext)
		{
			if ($ext == $actual_extension)
				return false;
		}
		
		return true;
	}

	function attach_icon($extension)
	{
		static $base_url, $attach_icons;

		$icon_dir = ($this->config['o_attachment_icon_dir'] != '') ? $this->config['o_attachment_icon_dir'] : $this->get_base_url().'/'.$this->config['o_attachment_icon_path'].'/';
		if ($this->user['show_img'] == 0 || $this->config['o_attachment_icons'] == 0)
			return '';

		if (!isset($attach_icons))
		{
			$attach_icons = array();
			$extensions = explode(',', $this->config['o_attachment_extensions']);
			$icons = explode(',', $this->config['o_attachment_images']);

			for ($i = 0; $i < count($extensions); $i++)
			{
				if (!isset($extensions[$i]) || !isset($icons[$i]))
					break;

				$attach_icons[$extensions[$i]] = $icons[$i];
			}
		}

		$icon = isset($attach_icons[$extension]) ? $attach_icons[$extension] : 'unknown.png';
		return array('file' => $icon_dir.$icon, 'extension' => $extension);
	}
}