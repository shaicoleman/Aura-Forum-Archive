<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

namespace auth;

class password
{
	public function __construct($registry)
	{
		$this->registry = $registry;
		$this->config = $registry->config;
	}

	public function generate($len)
	{
		$arr = range(chr(33), chr(126)); // Get all printable characters from the ASCII table (then remove any which cause problems)
		unset($arr[1], $arr[6], $arr[11], $arr[13], $arr[14], $arr[25], $arr[26], $arr[27], $arr[29], $arr[30], $arr[59], $arr[61], $arr[63], $arr[91], $arr[93]);

		$password = implode('', array_rand(array_flip($arr), $len));

		if (utf8_strlen($password) < $this->config['o_password_min_length'])
			return $this->generate($len);
		else if (utf8_strlen(preg_replace('/[^0-9]/', '', $password)) < $this->config['o_password_min_digits'])
			return $this->generate($len);
		else if (utf8_strlen(preg_replace('/[^A-Z]/', '', $password)) < $this->config['o_password_min_uppercase'])
			return $this->generate($len);
		else if (utf8_strlen(preg_replace('/[0-9A-Za-z]/', '', $password)) < $this->config['o_password_min_symbols'])
			return $this->generate($len);

		return $password;
	}
}