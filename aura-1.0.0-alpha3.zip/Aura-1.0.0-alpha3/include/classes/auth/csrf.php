<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

namespace auth;
use AuraClass;

class csrf extends AuraClass
{
	//
	// Generate a csrf token
	//
	function generate($script = 'nothing', $use_ip = true)
	{
		$script = ($script != 'nothing') ? $script : utf8_trim(basename($_SERVER['SCRIPT_NAME']));
		return aura_hash($this->user['id'].$script.$this->user['salt'].(($use_ip ? get_remote_address() : '')).$this->user['login_key']);
	}

	//
	// Make sure that user is using a valid token
	// 
	function confirm($script, $use_ip = true)
	{
		// Yeah, pretty complex ternary =)
		$sent_hash = ((isset($_POST['csrf_token'])) ? utf8_trim($_POST['csrf_token']) : (isset($_GET['csrf_token']) ? utf8_trim($_GET['csrf_token']) : ''));

		if (!aura_hash_equals($this->generate($script, $use_ip), $sent_hash))
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad referrer'));
	}
}