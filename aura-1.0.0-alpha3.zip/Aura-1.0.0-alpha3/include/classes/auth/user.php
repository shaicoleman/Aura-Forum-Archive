<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

namespace auth;
use AuraClass;
use lang;
use styles;

class user extends AuraClass
{
	/**
	 * Cookie stuff!
	 */
	public function check_cookie()
	{
		// If the cookie is set and it matches the correct pattern, then read the values from it
		if (isset($_COOKIE[$this->config['o_cookie_name']]) && preg_match('%^(\d+)\|([0-9a-fA-F]+)\|(\d+)\|([0-9a-fA-F]+)$%', $_COOKIE[$this->config['o_cookie_name']], $matches))
		{
			$cookie = array(
				'user_id'			=> intval($matches[1]),
				'password_hash' 	=> $matches[2],
				'expiration_time'	=> intval($matches[3]),
				'cookie_hash'		=> $matches[4],
			);
		}

		// If it has a non-guest user, and hasn't expired
		if (isset($cookie) && $cookie['user_id'] > 1 && $cookie['expiration_time'] > CURRENT_TIMESTAMP)
		{
			// If the cookie has been tampered with
			if (!aura_hash_equals(hash_hmac('sha512', $cookie['user_id'].'|'.$cookie['expiration_time'], $this->config['o_cookie_seed'].'_cookie_hash'), $cookie['cookie_hash']))
			{
				$expire = CURRENT_TIMESTAMP + 31536000; // The cookie expires after a year
				$this->registry->get('\cookie\cookie')->aura_setcookie(1, aura_hash(uniqid(rand(), true)), $expire);

				return $this->set_default_user();
			}

			$data = array(
				':id' => $cookie['user_id'],
			);

			// Check if there's a user with the user ID and password hash from the cookie
			$join = array(
				array(
					'type' => 'INNER',
					'table' => 'groups',
					'as' => 'g',
					'on' => 'u.group_id=g.g_id',
				),
				array(
					'type' => 'LEFT',
					'table' => 'online',
					'as' => 'o',
					'on' => 'o.user_id=u.id',
				),
			);

			$ps = $this->db->join('users', 'u', $join, 'u.*, g.*, o.logged, o.idle', $data, 'u.id=:id');
			$this->user = $ps->fetch();

			// If user authorisation failed
			if (!isset($this->user['id']) || !aura_hash_equals(hash_hmac('sha512', $this->user['login_key'], $this->config['o_cookie_seed'].'_password_hash'), $cookie['password_hash']))
			{
				$expire = CURRENT_TIMESTAMP + 31536000; // The cookie expires after a year
				$this->registry->get('\cookie\cookie')->aura_setcookie(1, aura_hash(uniqid(rand(), true)), $expire);

				return $this->set_default_user();
			}

			// Send a new, updated cookie with a new expiration timestamp
			$expire = ($cookie['expiration_time'] > CURRENT_TIMESTAMP + $this->config['o_timeout_visit']) ? CURRENT_TIMESTAMP + 1209600 : CURRENT_TIMESTAMP + $this->config['o_timeout_visit'];
			$this->registry->get('\cookie\cookie')->aura_setcookie($this->user['id'], $this->user['login_key'], $expire);

			// Set a default language if the user selected language no longer exists
			if (!lang::language_exists($this->user['language']))
				$this->user['language'] = $this->config['o_default_lang'];

			$style_root = (($this->config['o_style_path'] != 'styles') ? $this->config['o_style_path'] : AURA_ROOT.$this->config['o_style_path']).'/';

			// Set a default style if the user selected style no longer exists
			if (!styles::style_exists($this->user['style']))
				$this->user['style'] = $this->config['o_default_style'];

			if (!$this->user['disp_topics'])
				$this->user['disp_topics'] = $this->config['o_disp_topics_default'];

			if (!$this->user['disp_posts'])
				$this->user['disp_posts'] = $this->config['o_disp_posts_default'];

			// Define this if you want this visit to affect the online list and the users last visit data
			if (!defined('AURA_QUIET_VISIT'))
			{
				// Update the online list
				if (!$this->user['logged'])
				{
					$this->user['logged'] = CURRENT_TIMESTAMP;
					$replace = array(
						'user_id' => $this->user['id'],
						'ident' => $this->user['username'],
						'logged' => $this->user['logged'],
					);

					// REPLACE avoids a user having two rows in the online table
					$this->db->replace('online', $replace);

					// Reset tracked topics
					$this->registry->get('\cookie\tracked')->set_tracked_topics(null);
				}
				else
				{
					$data = array(
						':id' => $this->user['id'],
					);

					// Special case: We've timed out, but no other user has browsed the forums since we timed out
					if ($this->user['logged'] < (CURRENT_TIMESTAMP-$this->config['o_timeout_visit']))
					{
						$update = array(
							'last_visit' => $this->user['logged'],
						);

						$this->db->update('users', $update, 'id=:id', $data);
						$this->user['last_visit'] = $this->user['logged'];
					}

					$update = array(
						'logged' => CURRENT_TIMESTAMP,
					);

					if ($this->user['idle'] == '1')
						$update['idle'] = 0;

					$this->db->update('online', $update, 'user_id=:id', $data);

					// Update tracked topics with the current expire time
					if (isset($_COOKIE[$this->config['o_cookie_name'].'_track']))
						$this->registry->get('\cookie\cookie')->forum_setcookie($this->config['o_cookie_name'].'_track', $_COOKIE[$this->config['o_cookie_name'].'_track'], CURRENT_TIMESTAMP + $this->config['o_timeout_visit']);
				}
			}
			else
			{
				if (!$this->user['logged'])
					$this->user['logged'] = $this->user['last_visit'];
			}

			$this->user['is_guest'] = false;
			$this->user['is_admmod'] = $this->user['g_id'] == AURA_ADMIN || $this->user['g_moderator'] == '1';
			$this->user['is_admin'] = $this->user['g_id'] == AURA_ADMIN || $this->user['g_moderator'] == '1' && $this->user['g_admin'] == '1';
			$this->user['is_bot'] = false;

			return $this->user;
		}
		else
			return $this->set_default_user();
	}

	/**
	 * Fill $this->user with default values (for guests)
	 */
	public function set_default_user()
	{
		$remote_addr = get_remote_address();
		$remote_addr = isbotex($remote_addr);

		$data = array(
			':ident' => $remote_addr,
		);

		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'groups',
				'as' => 'g',
				'on' => 'u.group_id=g.g_id',
			),
			array(
				'type' => 'LEFT',
				'table' => 'online',
				'as' => 'o',
				'on' => 'o.ident=:ident',
			),
		);

		// Fetch guest user
		$ps = $this->db->join('users', 'u', $join, 'u.*, g.*, o.logged, o.last_post, o.last_search', $data, 'u.id=1');
		if (!$ps->rowCount())
			throw new Exception('Unable to fetch guest information. Your database must contain both a guest user and a guest user group.');

		$this->user = $ps->fetch();

		// Update online list
		if (!$this->user['logged'])
		{
			$this->user['logged'] = CURRENT_TIMESTAMP;
			$replace = array(
				'user_id' => 1,
				'ident' => $remote_addr,
				'logged' => $this->user['logged'],
			);

			// REPLACE avoids a user having two rows in the online table
			$this->db->replace('online', $replace);
		}
		else
		{
			$update = array(
				'logged' => CURRENT_TIMESTAMP,
			);

			$data = array(
				':ident' => $remote_addr,
			);

			$this->db->update('online', $update, 'ident=:ident', $data);
		}

		$this->user['disp_topics'] = $this->config['o_disp_topics_default'];
		$this->user['disp_posts'] = $this->config['o_disp_posts_default'];
		$this->user['timezone'] = $this->config['o_default_timezone'];
		$this->user['dst'] = $this->config['o_default_dst'];
		$this->user['language'] = $this->config['o_default_lang'];
		$this->user['style'] = $this->config['o_default_style'];
		$this->user['is_guest'] = true;
		$this->user['is_admmod'] = false;
		$this->user['is_admin'] = false;
		$this->user['is_bot'] = (strpos($remote_addr, '[Bot]') !== false);

		return $this->user;
	}
}