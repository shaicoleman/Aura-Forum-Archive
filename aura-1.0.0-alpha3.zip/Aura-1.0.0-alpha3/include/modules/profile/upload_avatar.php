<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class upload_avatar_controller extends base_controller
{
	public function execute()
	{
		$this->registry->get('\extensions\hooks')->fire('profile.avatar.immediate');

		$profile = new \profile\common($this->registry);
		$id = $profile->fetch_id();

		if ($this->config['o_avatars'] == '0')
			$this->registry->get('\handlers\message')->show($this->lang->t('Avatars disabled'));

		if ($this->config['o_avatar_upload'] == '0')
			$this->registry->get('\handlers\message')->show($this->lang->t('Avatars disabled'));

		if ($this->user['id'] != $id && !$this->user['is_admmod'])
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		if (isset($_POST['form_sent']))
		{
			if (!isset($_FILES['req_file']))
				$this->registry->get('\handlers\message')->show($this->lang->t('No file'));

			$avatar_path = ($this->config['o_avatars_dir'] != '') ? $this->config['o_avatars_path'] : AURA_ROOT.$this->config['o_avatars_path'].'/';
	
			// Make sure they got here from the site
			$this->registry->get('\auth\csrf')->confirm('profile');

			$uploaded_file = $_FILES['req_file'];

			// Make sure the upload went smooth
			if (isset($uploaded_file['error']))
			{
				switch ($uploaded_file['error'])
				{
					case 1: // UPLOAD_ERR_INI_SIZE
					case 2: // UPLOAD_ERR_FORM_SIZE
						$this->registry->get('\handlers\message')->show($this->lang->t('Too large ini'));
						break;

					case 3: // UPLOAD_ERR_PARTIAL
						$this->registry->get('\handlers\message')->show($this->lang->t('Partial upload'));
						break;

					case 4: // UPLOAD_ERR_NO_FILE
						$this->registry->get('\handlers\message')->show($this->lang->t('No file'));
						break;

					case 6: // UPLOAD_ERR_NO_TMP_DIR
						$this->registry->get('\handlers\message')->show($this->lang->t('No tmp directory'));
						break;

					default:
						// No error occured, but was something actually uploaded?
						if ($uploaded_file['size'] == 0)
							$this->registry->get('\handlers\message')->show($this->lang->t('No file'));
						break;
				}
			}

			if (is_uploaded_file($uploaded_file['tmp_name']))
			{
				// Preliminary file check, adequate in most cases
				$allowed_types = array('image/gif', 'image/jpeg', 'image/pjpeg', 'image/png', 'image/x-png');
				if (!in_array($uploaded_file['type'], $allowed_types))
					$this->registry->get('\handlers\message')->show($this->lang->t('Bad type'));

				// Make sure the file isn't too big
				if ($uploaded_file['size'] > $this->config['o_avatars_size'])
					$this->registry->get('\handlers\message')->show($this->lang->t('Too large', forum_number_format($this->config['o_avatars_size']), $this->lang->t('bytes')));

				// Move the file to the avatar directory. We do this before checking the width/height to circumvent open_basedir restrictions
				if (!@move_uploaded_file($uploaded_file['tmp_name'], $avatar_path.$id.'.tmp'))
					$this->registry->get('\handlers\message')->show($this->lang->t('Move failed', $this->config['o_admin_email']));

				list($width, $height, $type,) = @getimagesize($avatar_path.$id.'.tmp');

				// Determine type
				if ($type == IMAGETYPE_GIF)
					$extension = '.gif';
				else if ($type == IMAGETYPE_JPEG)
					$extension = '.jpg';
				else if ($type == IMAGETYPE_PNG)
					$extension = '.png';
				else
				{
					// Invalid type
					@unlink($avatar_path.$id.'.tmp');
					$this->registry->get('\handlers\message')->show($this->lang->t('Bad type'));
				}

				// Now check the width/height
				if (empty($width) || empty($height) || $width > $this->config['o_avatars_width'] || $height > $this->config['o_avatars_height'])
				{
					@unlink($avatar_path.$id.'.tmp');
					$this->registry->get('\handlers\message')->show($this->lang->t('Too wide or high', $this->config['o_avatars_width'], $this->config['o_avatars_height'], $this->lang->t('pixels')));
				}

				// Delete any old avatars and put the new one in place
				delete_avatar($id);
				@rename($avatar_path.$id.'.tmp', $avatar_path.$id.$extension);
				compress_image($avatar_path.$id.$extension);
				@chmod($avatar_path.$id.$extension, 0644);

				// Disable Gravatar
				$update = array(
					'use_gravatar' => 0,
				);
				
				$data = array(
				':id' => $id,
				);

				$this->db->update('users', $update, 'id=:id', $data);

				$this->registry->get('\extensions\hooks')->fire('profile.avatar.uploaded');
			}
			else
				$this->registry->get('\handlers\message')->show($this->lang->t('Unknown failure'));

			$this->registry->get('\extensions\hooks')->fire('profile.avatar.beforeredirect');

			$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['profile_personality'], array($id)), $this->lang->t('Avatar upload redirect'));
		}

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Profile'), $this->lang->t('Upload avatar')),
			'reqiured_fields' => array('req_file' => $this->lang->t('File')),
			'focus_element' => array('upload_avatar', 'req_file'),
			'active_page' => 'profile',
		);

		$this->template->header = $this->registry->get('\extensions\hooks')->fire('profile.avatar.header', $this->template->header);
		$args = $this->registry->get('\extensions\hooks')->fire('profile.avatar.render');
		$args = (is_array($args) ? $args : array());

		$csrf_token = $this->registry->get('\auth\csrf')->generate('profile');
		$tpl = $this->template->load('upload_avatar.tpl');
		$this->template->output($tpl,
			array_merge(
				array(
					'form_action' => $this->registry->get('\links')->aura_link($this->rewrite->url['upload_avatar'], array($id, $csrf_token)),
					'csrf_token' => $csrf_token,
					'avatar_size' => $this->functions->forum_number_format($this->config['o_avatars_size']),
					'file_size' => $this->functions->file_size($this->config['o_avatars_size']),
				),
				$args
			)
		);
	}
}