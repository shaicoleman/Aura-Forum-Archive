<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class index_controller extends base_controller
{
	public function execute()
	{
		$act = isset($_GET['act']) ? utf8_trim($_GET['act']) : '';
		if ($act !=  '' && $act != 'view')
		{
			$this->registry->get('\extensions\hooks')->fire('profile.'.$act);
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');
		}
		else
		{
			$this->registry->get('\extensions\hooks')->fire('profile.view.immediate');

			$profile = new \profile\common($this->registry);
			$id = $profile->fetch_id();

			$user = $profile->fetch_user();

			$profile->view_profile($user);
		}
	}
}