<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class use_gravatar_controller extends base_controller
{
	public function execute()
	{
		$this->registry->get('\extensions\hooks')->fire('profile.gravatar.immediate');

		$profile = new \profile\common($this->registry);
		$id = $profile->fetch_id();

		if ($this->config['o_avatars'] == '0')
			$this->registry->get('\handlers\message')->show($this->lang->t('Avatars disabled'));

		if ($this->user['id'] != $id && !$this->user['is_admmod'])
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'));

		$this->registry->get('\auth\csrf')->confirm('profile');
		$data = array(
			':id' => $id,
		);

		$ps = $this->db->select('users', 'use_gravatar', $data, 'id=:id');
		$use_gravatar = $ps->fetchColumn();
		
		if (!$use_gravatar)
			$this->registry->('\avatar')->delete_avatar($id);

		$redirect_msg = ($use_gravatar) ? $this->lang->t('Gravatar disabled redirect') : $this->lang->t('Gravatar enabled redirect');
		$update = array(
			'use_gravatar' => (($use_gravatar == 0) ? 1 : 0),
		);

		$this->db->update('users', $update, 'id=:id', $data);

		$this->registry->get('\extensions\hooks')->fire('profile.gravatar.beforeredirect');
		$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['profile_personality'], array($id)), $redirect_msg);
	}
}