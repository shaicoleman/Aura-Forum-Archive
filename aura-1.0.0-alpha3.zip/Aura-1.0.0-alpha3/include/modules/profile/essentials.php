<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class essentials_controller extends base_controller
{
	public function execute()
	{
		$this->registry->get('\extensions\hooks')->fire('profile.essentials.immediate');

		$profile = new \profile\common($this->registry);
		$id = $profile->fetch_id();

		$user = $profile->fetch_user();

		if (isset($_POST['form_sent']))
			$profile->update_profile('essentials');

		if ($this->user['is_admmod'])
			$email_link = $this->registry->get('\links')->aura_link($this->rewrite->url['email'], array($id));
		else if ($this->config['o_regs_verify'] == '1')
			$email_link = $this->registry->get('\links')->aura_link($this->rewrite->url['change_email'], array($id));
		else
			$email_link = '';

		$posts_field = '';
		$posts_actions = array();
		if ($this->user['g_search'] == '1' || $this->user['is_admin'])
		{
			$posts_actions[] = array('href' => $this->registry->get('\links')->aura_link($this->rewrite->url['search_user_topics'], array($id)), 'lang' => $this->lang->t('Show topics'));
			$posts_actions[] = array('href' => $this->registry->get('\links')->aura_link($this->rewrite->url['search_user_posts'], array($id)), 'lang' => $this->lang->t('Show posts'));

			if ($this->config['o_topic_subscriptions'] == '1')
				$posts_actions[] = array('href' => $this->registry->get('\links')->aura_link($this->rewrite->url['search_subscriptions'], array($id)), 'lang' => $this->lang->t('Show subscriptions'));
		}

		$posts_actions = $this->registry->get('\extensions\hooks')->fire('profile.essentials.actions', $posts_actions);
		$this->lang->load('warnings');

		// Does the user have active warnings?
		$data = array(
			':id'	=>	$id,
			':time'	=>	CURRENT_TIMESTAMP,
		);

		$ps = $this->db->select('warnings', 'COALESCE(SUM(points), 0)', $data, 'user_id=:id AND (date_expire>:time OR date_expire=0)');
		$has_active = $ps->fetchColumn();

		if ($this->config['o_reputation'] == '1')
		{
			switch(true)
			{
				case $user['reputation'] > '0':
					$type = 'positive';
				break;
				case $user['reputation'] < '0':
					$type = 'negative';
				break;
				default:
					$type = 'zero';
				break;
			}

			$reputation = array('type' => $type, 'value' => $this->functions->forum_number_format($user['reputation']));
		}

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Profile'), $this->lang->t('Section essentials')),
			'required_fields' => array('req_username' => $this->lang->t('Username'), 'req_email' => $this->lang->t('Email')),
			'active_page' => 'profile',
		);

		$time_formats = $date_formats = array();
		foreach (array_unique($this->config['o_time_formats']) as $key => $time_format)
			$time_formats[] = array('value' => $key, 'time' => ($this->registry->get('\aura_time')->format(CURRENT_TIMESTAMP, false, null, $time_format, true, true).(($key == $this->config['o_time_format']) ? ' ('.$this->lang->t('Default').')' : '')));

		$time_formats = $this->registry->get('\extensions\hooks')->fire('profile.essentials.timeformats', $time_formats);
		foreach (array_unique($this->config['o_date_formats']) as $key => $date_format)
			$date_formats[] = array('value' => $key, 'time' => ($this->registry->get('\aura_time')->format(CURRENT_TIMESTAMP, true, $date_format, null, false, true).(($key == $this->config['o_date_format']) ? ' ('.$this->lang->t('Default').')' : '')));

		$date_formats = $this->registry->get('\extensions\hooks')->fire('profile.essentials.dateformats', $date_formats);
		$this->template->header = $this->registry->get('\extensions\hooks')->fire('profile.essentials.header', $this->template->header);
		$args = $this->registry->get('\extensions\hooks')->fire('profile.essentials.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('profile_essentials.tpl');
		$this->template->output($tpl,
			array_merge(
				array(
					'id' => $id,
					'aura_user' => $this->user,
					'user' => $user,
					'csrf_token' => $this->registry->get('\auth\csrf')->generate('profile'),
					'form_action' => $this->registry->get('\links')->aura_link($this->rewrite->url['profile_essentials'], array($id)),
					'posts_actions' => $posts_actions,
					'time_formats' => $time_formats,
					'date_formats' => $date_formats,
					'languages' => $this->cache->get('locales'),
					'change_pass_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['change_password'], array($id)),
					'last_visit' => $this->registry->get('\aura_time')->format($user['last_visit']),
					'last_post' => $this->registry->get('\aura_time')->format($user['last_post']),
					'registered' => $this->registry->get('\aura_time')->format($user['registered'], true),
					'ip_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['get_host'], array($user['registration_ip'])),
					'warning_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['warning_view'], array($id)),
					'warn_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['warn_user'], array($id)),
					'has_active' => $has_active,
					'posts' => $this->functions->forum_number_format($user['num_posts']),
					'email_link' => $email_link,
					'given_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['profile_rep_given'], array($id)),
					'received_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['profile_rep_received'], array($id)),
					'reputation' => isset($reputation) ? $reputation : '',
					'profile_menu' => $this->registry->get('\profile\menu')->generate($id, 'essentials'),
				),
				$args
			)
		);
	}
}