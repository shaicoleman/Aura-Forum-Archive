<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class add_controller extends base_controller
{
	/**
	 * Main entry point- launch the form
	 */
	public function execute()
	{
		$this->registry->get('\extensions\hooks')->fire('polls.add.immediate');
	
		if ($this->user['g_read_board'] == '0')
			$this->registry->get('\handlers\message')->show($this->lang->t('No view'), false, '403 Forbidden');

		$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
		if ($id < 1)
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not found');
			
		// Fetch some info about the topic and/or the forum
		$cur_posting = $this->fetch_poll_details($id);

		$moderators = $this->cache->get('moderators');
		$is_admmod = ($this->user['is_admin'] || ($this->user['g_moderator'] == '1' && $this->user['g_global_moderator'] == '1' || isset($moderators[$cur_posting['fid']]['u'.$this->user['id']]) || isset($moderators[$cur_posting['fid']]['g'.$this->user['g_id']]))) ? true : false;

		if ($this->config['o_polls'] == '0' || (!$is_admmod && ($this->user['g_post_polls'] == '0' || $cur_posting['poster'] != $this->user['username'])))
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		if ($cur_posting['redirect_url'] != '')
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'));

		if ($cur_posting['password'] != '')
				$this->registry->get('\cookie\cookie')->check_forum_login_cookie($cur_posting['fid'], $cur_posting['password']);

		$this->lang->load('poll');
		$this->lang->load('post');

		$option_data = $errors = array();
		if (isset($_POST['form_sent']))
			list($errors, $option_data, $question) = $this->submit_poll($id, $cur_posting);

		$cur_index = 1; 
		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Post new topic')),
			'required_fields' => array('req_question' => $this->lang->t('Question'), 'req_subject' => $this->lang->t('Subject'), 'req_message' => $this->lang->t('Message')),
			'focus_element' => array('post'),
			'active_page' => 'index',
		);

		if (!$this->user['is_guest'])
			$this->template->header['focus_element'][] = 'req_question';
		else
		{
			$this->template->header['required_fields']['req_username'] = $this->lang->t('Guest name');
			$this->template->header['focus_element'][] = 'req_question';
		}

		$inputs = $this->generate_inputs($option_data);

		$this->template->header = $this->registry->get('\extensions\hooks')->fire('polls.add.header', $this->template->header);
		$args = $this->registry->get('\extensions\hooks')->fire('polls.add.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('add_poll.tpl');
		$this->template->output($tpl,
			array_merge(
				array(
					'errors' => $errors,
					'preview' => (isset($_POST['preview'])) ? true : false,
					'inputs' => $inputs,
					'question' => (isset($_POST['req_question'])) ? $question : '',
					'index_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['index']),
					'cur_posting' => $cur_posting,
					'forum_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['forum'], array($cur_posting['fid'], \url\url::replace($cur_posting['forum_name']))),
					'form_action' => $this->registry->get('\links')->aura_link($this->rewrite->url['poll_add'], array($id)),
					'type' => isset($_POST['type']) ? true : false,
				),
				$args
			)
		);
	}

	/**
	 * Fetch poll details used to generate the form
	 */
	public function fetch_poll_details($id)
	{
		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'forums',
				'as' => 'f',
				'on' => 'f.id=t.forum_id',
			),
			array(
				'type' => 'LEFT',
				'table' => 'forum_perms',
				'as' => 'fp',
				'on' => '(fp.forum_id=f.id AND fp.group_id=:gid)',
			),
		);

		$data = array(
			':gid' => $this->user['g_id'],
			':tid' => $id,
		);

		$ps = $this->db->join('topics', 't', $join, 'f.id AS fid, f.forum_name, f.redirect_url, f.password, t.poster, t.subject, t.approved', $data, '(fp.read_forum IS NULL OR fp.read_forum=1) AND t.id=:tid');
		if (!$ps->rowCount())
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not found');
			
		$cur_posting = $ps->fetch();

		$cur_posting = $this->registry->get('\extensions\hooks')->fire('polls.add.polldetails', $cur_posting);
		return $cur_posting;
	}

	public function submit_poll($id, $cur_posting)
	{
		$errors = array();
		$question = isset($_POST['req_question']) ? utf8_trim($_POST['req_question']) : '';
		$options = isset($_POST['options']) && is_array($_POST['options']) ? array_map('utf8_trim', $_POST['options']) : array();
		$type = isset($_POST['type']) ? 2 : 1;

		if ($question == '')
			$errors[] = $this->lang->t('No question');
		else if (aura_strlen($question) > 70)
			$errors[] = $this->lang->t('Too long question');
		else if ($this->config['p_subject_all_caps'] == '0' && is_all_uppercase($question) && !$this->user['is_admmod'])
			$errors[] = $this->lang->t('All caps question');

		if (empty($options))
			$errors[] = $this->lang->t('No options');

		$option_data = array();
		for ($i = 0; $i <= $this->config['o_max_poll_fields']; $i++)
		{
			if (!empty($errors))
				break;

			if (aura_strlen($options[$i]) > 55)
				$errors[] = $this->lang->t('Too long option');
			else if ($this->config['p_subject_all_caps'] == '0' && is_all_uppercase($options[$i]) && !$this->user['is_admmod'])
				$errors[] = $this->lang->t('All caps option');
			else if ($options[$i] != '')
				$option_data[] = $options[$i];
		}

		if (count($option_data) < 2)
			$errors[] = $this->lang->t('Low options');

		$errors = $this->registry->get('\extensions\hooks')->fire('polls.add.validate', $errors);

		// Did everything go according to plan?
		if (empty($errors) && !isset($_POST['preview']))
		{
			$update = array(
				'question' => $question,
			);

			$data = array(
				':id' => $id,
			);

			$this->db->update('topics', $update, 'id=:id', $data);
			$insert = array(
				'topic_id' => $id,
				'options' => serialize($option_data),
				'type' => $type,
				'voters' => '', // Bugfix: Support for MySQL 5.7.9 strict standards mode
				'votes' => '',
			);

			$this->db->insert('polls', $insert);
			$new_pid = $this->db->lastInsertId($this->db->prefix.'polls');

			$this->registry->get('\extensions\hooks')->fire('polls.add.beforeredirect');
			// Make sure we actually have a topic to go back to
			if ($cur_posting['approved'] == '0')
				$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['forum'], array($cur_posting['fid'], \url\url::replace($cur_posting['forum_name']))), $this->lang->t('Topic moderation redirect'));
			else
				$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['topic'], array($id, \url\url::replace($cur_posting['subject']))), $this->lang->t('Post redirect'));
		}

		return array($errors, $option_data, $question);
	}

	/**
	 * Generate the correct number of inputs which are used on the form
	 */
	protected function generate_inputs($option_data)
	{
		$inputs = array();
		for ($i = 0; $i <= $this->config['o_max_poll_fields'] ; $i++)
		{
			// Make sure this is indeed a valid option
			if (isset($option_data[$i]) && $option_data[$i] != '')
			{
				if (isset($_POST['preview']))
					$inputs[] = array('id' => $i, 'option' => $option_data[$i]);
			}
			else
				$inputs[] = array('id' => $i, 'option' => ((isset($options[$i])) ? $options[$i] : ''));
		}

		$inputs = $this->registry->get('\extensions\hooks')->fire('polls.add.inputs', $inputs);
		return $inputs;
	}
}