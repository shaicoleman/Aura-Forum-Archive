<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class post_controller extends base_controller
{
	public function execute()
	{
		$this->registry->get('\extensions\hooks')->fire('post.immediate');

		if ($this->user['g_read_board'] == '0')
			$this->registry->get('\handlers\message')->show($this->lang->t('No view'), false, '403 Forbidden');

		if ($this->user['is_bot'])
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'));

		if ($this->user['g_robot_test'] == '1')
			$aura_robots = $this->cache->get('robots');

		$tid = isset($_GET['tid']) ? intval($_GET['tid']) : 0;
		$fid = isset($_GET['fid']) ? intval($_GET['fid']) : 0;
		if ($tid < 1 && $fid < 1 || $tid > 0 && $fid > 0 || !$tid && !$fid)
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		$data = array(
			':gid' => $this->user['g_id'],
		);

		// Fetch some info about the topic and/or the forum
		if ($tid)
		{
			$join = array(
				array(
					'type' => 'INNER',
					'table' => 'forums',
					'as' => 'f',
					'on' => 'f.id=t.forum_id',
				),
				array(
					'type' => 'LEFT',
					'table' => 'forum_perms',
					'as' => 'fp',
					'on' => '(fp.forum_id=f.id AND fp.group_id=:gid)',
				),
				array(
					'type' => 'LEFT',
					'table' => 'topic_subscriptions',
					'as' => 's',
					'on' => '(t.id=s.topic_id AND s.user_id=:id)',
				),
			);

			$data[':id'] = $this->user['id'];
			$data[':tid'] = $tid;
			$ps = $this->db->join('topics', 't', $join, 'f.id, f.forum_name, f.increment_posts, f.password, f.redirect_url, f.force_approve, fp.post_replies, fp.post_polls, fp.post_topics, fp.upload, t.subject, t.archived, t.closed, s.user_id AS is_subscribed', $data, '(fp.read_forum IS NULL OR fp.read_forum=1) AND t.id=:tid');
		}
		else
		{
			$join = array(
				array(
					'type' => 'LEFT',
					'table' => 'forum_perms',
					'as' => 'fp',
					'on' => '(fp.forum_id=f.id AND fp.group_id=:gid)',
				),
			);

			$data[':fid'] = $fid;	
			$ps = $this->db->join('forums', 'f', $join, 'f.id, f.forum_name, f.increment_posts, f.password, f.redirect_url, f.force_approve, fp.post_replies, fp.post_polls, fp.post_topics, fp.upload, 0 AS archived', $data, '(fp.read_forum IS NULL OR fp.read_forum=1) AND f.id=:fid');
		}

		if (!$ps->rowCount())
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		$cur_posting = $ps->fetch();
		$is_subscribed = $tid && $cur_posting['is_subscribed'];

		$cur_posting = $this->registry->get('\extensions\hooks')->fire('post.fetch_posting', $cur_posting);

		// Is someone trying to post into a redirect forum?
		if ($cur_posting['redirect_url'] != '')
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		// Sort out who the moderators are and if we are currently a moderator (or an admin)
		$moderators = $this->cache->get('moderators');
		if ($tid)
			$is_admmod = ($this->user['is_admin'] || ($this->user['g_moderator'] == '1' && $this->user['g_global_moderator'] == '1' || isset($moderators[$cur_posting['id']]['u'.$this->user['id']]) || isset($moderators[$cur_posting['id']]['g'.$this->user['g_id']]))) ? true : false;
		else
			$is_admmod = ($this->user['is_admin'] || ($this->user['g_moderator'] == '1' && $this->user['g_global_moderator'] == '1' || isset($moderators[$fid]['u'.$this->user['id']]) || isset($moderators[$fid]['g'.$this->user['g_id']]))) ? true : false;

		if ($tid && $this->config['o_censoring'] == '1')
			$cur_posting['subject'] = censor_words($cur_posting['subject']);

		// Do we have permission to post?
		if ((($tid && (($cur_posting['post_replies'] == '' && $this->user['g_post_replies'] == '0') || $cur_posting['post_replies'] == '0')) ||
			($fid && (($cur_posting['post_topics'] == '' && $this->user['g_post_topics'] == '0') || $cur_posting['post_topics'] == '0')) ||
			(isset($cur_posting['closed']) && $cur_posting['closed'] == '1')) &&
			!$is_admmod)
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		if ($cur_posting['password'] != '')
		{
			if ($fid)
				$this->registry->get('\cookie\cookie')->check_forum_login_cookie($fid, $cur_posting['password']);
			else
				$this->registry->get('\cookie\cookie')->check_forum_login_cookie($cur_posting['id'], $cur_posting['password']);
		}

		// Load the post language file
		$this->lang->load('post');
		$this->registry->get('\auth\bans')->check_posting_ban();

		if ($cur_posting['archived'] == '1')
			$this->registry->get('\handlers\message')->show($this->lang->t('Topic archived'));
		
		$this->registry->get('\extensions\hooks')->fire('post.authorised');

		// Start with a clean slate
		$errors = array();

		// Did someone just hit "Submit" or "Preview"?
		if (isset($_POST['form_sent']))
		{		
			$this->registry->get('\extensions\hooks')->fire('post.posting');

			// Flood protection
			if (!isset($_POST['preview']) && $this->user['last_post'] != '' && (CURRENT_TIMESTAMP - $this->user['last_post']) < $this->user['g_post_flood'])
				$errors[] = $this->lang->t('Flood start', $this->user['g_post_flood'], $this->user['g_post_flood'] - (CURRENT_TIMESTAMP - $this->user['last_post']));

			// Make sure they got here from the site
			$this->registry->get('\auth\csrf')->confirm('post');

			// If it's a new topic
			if ($fid)
			{
				$subject = isset($_POST['req_subject']) ? utf8_trim($_POST['req_subject']) : '';

				if ($this->config['o_censoring'] == '1')
					$censored_subject = utf8_trim($this->registry->get('\message\bbcode')->censor_words($subject));

				if ($subject == '')
					$errors[] = $this->lang->t('No subject');
				else if ($this->config['o_censoring'] == '1' && $censored_subject == '')
					$errors[] = $this->lang->t('No subject after censoring');
				else if (aura_strlen($subject) > 70)
					$errors[] = $this->lang->t('Too long subject');
				else if ($this->config['p_subject_all_caps'] == '0' && is_all_uppercase($subject) && !$this->user['is_admmod'])
					$errors[] = $this->lang->t('All caps subject');
				else if ($this->user['g_subject_links'] == '0' && contains_url($subject))
					$errors[] = $this->lang->t('BBCode error tag url not allowed in subjects');

				$this->registry->get('\extensions\hooks')->fire('post.posting.validatesubject');
			}

			if (!empty($aura_robots) && $this->user['g_robot_test'] == '1')
			{
				$id = isset($_POST['id']) ? intval($_POST['id']) : 0;
				$answer = isset($_POST['answer']) ? utf8_trim($_POST['answer']) : '';

				if (!isset($aura_robots[$id]) || $answer != $aura_robots[$id]['answer'])
					$errors[] = $this->lang->t('Robot test fail');

				$this->registry->get('\extensions\hooks')->fire('post.posting.robots');
			}

			// If the user is logged in we get the username and email from the user
			if (!$this->user['is_guest'])
			{
				$username = $this->user['username'];
				$email = $this->user['email'];

				$this->registry->get('\extensions\hooks')->fire('post.posting.userposting');
			}
			// Otherwise it should be in $_POST
			else
			{
				$username = isset($_POST['req_username']) ? utf8_trim($_POST['req_username']) : '';
				$email = strtolower(utf8_trim(($this->config['p_force_guest_email'] == '1') ? $_POST['req_email'] : $_POST['email']));
				$banned_email = false;

				// Load the register/profile-register language files
				$this->lang->load('prof_reg');
				$this->lang->load('register');

				// It's a guest, so we have to validate the username
				$this->registry->get('\auth\register')->check_username($username);

				if ($this->config['p_force_guest_email'] == '1' || $email != '')
				{
					if (!is_valid_email($email))
						$errors[] = $this->lang->t('Invalid email');

					// Check if it's a banned email address
					// we should only check guests because members' addresses are already verified
					if ($this->user['is_guest'] && $this->registry->get('\auth\bans')->is_banned_email($email))
					{
						if ($this->config['p_allow_banned_email'] == '0')
							$errors[] = $this->lang->t('Banned email');

						$banned_email = true; // Used later when we send an alert email
					}
				}

				$this->registry->get('\extensions\hooks')->fire('post.posting.guestposting');
			}

			// Clean up message from POST
			$orig_message = $message = isset($_POST['req_message']) ? aura_linebreaks(utf8_trim($_POST['req_message'])) : '';

			// Here we use strlen() not aura_strlen() as we want to limit the post to AURA_MAX_POSTSIZE bytes, not characters
			if (strlen($message) > AURA_MAX_POSTSIZE)
				$errors[] = $this->lang->t('Too long message', $this->functions->forum_number_format(AURA_MAX_POSTSIZE));
			else if ($this->config['p_message_all_caps'] == '0' && is_all_uppercase($message) && !$this->user['is_admmod'])
				$errors[] = $this->lang->t('All caps message');

			// Validate BBCode syntax
			if ($this->config['p_message_bbcode'] == '1')
			{
				$parser = new \message\parser($this->registry);
				$message = $parser->preparse_bbcode($message, $errors);
			}

			if (empty($errors))
			{
				if ($message == '')
					$errors[] = $this->lang->t('No message');
				else if ($this->config['o_censoring'] == '1')
				{
					// Censor message to see if that causes problems
					$censored_message = utf8_trim($this->registry->get('\message\bbcode')->censor_words($message));

					if ($censored_message == '')
						$errors[] = $this->lang->t('No message after censoring');
				}
			}

			$hide_smilies = isset($_POST['hide_smilies']) ? '1' : '0';
			$subscribe = isset($_POST['subscribe']) ? '1' : '0';
			$stick_topic = isset($_POST['stick_topic']) && $is_admmod ? '1' : '0';
			$add_poll = isset($_POST['add_poll']) && $fid && $cur_posting['post_polls'] != '0' && $this->user['g_post_polls'] == '1' && $this->config['o_polls'] == '1' ? 1 : 0;
			$topic_approve = (!$is_admmod && ($cur_posting['force_approve'] == '1' || $cur_posting['force_approve'] == '3' || $this->user['g_moderate_posts'] == '1')) ? 0 : 1;
			$post_approve = (!$is_admmod && ($cur_posting['force_approve'] == '2' || $cur_posting['force_approve'] == '3' || $this->user['g_moderate_posts'] == '1')) ? 0 : 1;

			$this->registry->get('\extensions\hooks')->fire('post.posting.fetchinfo');

			// Replace four-byte characters (MySQL cannot handle them)
			$message = strip_bad_multibyte_chars($message);

			// Did everything go according to plan?
			if (empty($errors) && !isset($_POST['preview']))
			{
				$idx = new \search\idx($this->registry);

				// If it's a reply
				if ($tid)
				{
					if (!$this->user['is_guest'])
					{
						$new_tid = $tid;

						// Insert the new post
						$insert = array(
							'poster'	=>	$username,
							'poster_id'	=>	$this->user['id'],
							'poster_ip'	=>	get_remote_address(),
							'message'	=>	$message,
							'hide_smilies' => $hide_smilies,
							'posted'	=>	CURRENT_TIMESTAMP,
							'topic_id'	=>	$tid,
							'approved'	=>	$post_approve,
						);

						$insert = $this->registry->get('\extensions\hooks')->fire('post.posting.userinsert', $insert);

						$this->db->insert('posts', $insert);
						$new_pid = $this->db->lastInsertId($this->db->prefix.'posts');

						// To subscribe or not to subscribe, that ...
						if ($this->config['o_topic_subscriptions'] == '1')
						{
							if ($subscribe && !$is_subscribed)
							{
								$data = array(
									'user_id'	=>	$this->user['id'],
									'topic_id'	=>	$tid,
								);
								
								$this->db->insert('topic_subscriptions', $data);
							}
							else if (!$subscribe && $is_subscribed)
							{
								$data = array(
									':id'	=>	$this->user['id'],
									':tid'	=>	$tid,
								);

								$this->db->delete('topic_subscriptions', 'user_id=:uid AND topic_id=:tid', $data);
							}

							$this->registry->get('\extensions\hooks')->fire('post.posting.subscriptions');
						}
					}
					else
					{
						// It's a guest. Insert the new post
						$insert_email = ($this->config['p_force_guest_email'] == '1' || $email != '') ? $email : NULL;
						$insert = array(
							'poster'	=>	$username,
							'poster_ip'	=>	get_remote_address(),
							'poster_email'	=>	$insert_email,
							'message'	=>	$message,
							'hide_smilies'	=>	$hide_smilies,
							'posted'	=>	CURRENT_TIMESTAMP,
							'topic_id'	=>	$tid,
							'approved'	=>	$post_approve,
						);

						$insert = $this->registry->get('\extensions\hooks')->fire('post.posting.guestinsert', $insert);

						$this->db->insert('posts', $insert);
						$new_pid = $this->db->lastInsertId($this->db->prefix.'posts');
					}

					if ($post_approve == '1')
					{
						// Update topic
						$data = array(
							':now'	=>	CURRENT_TIMESTAMP,
							':last_post_id'	=>	$new_pid,
							':last_poster'	=>	$username,
							':id'	=>	$tid,
						);

						$this->db->run('UPDATE '.$this->db->prefix.'topics SET num_replies=num_replies+1, last_post=:now, last_post_id=:last_post_id, last_poster=:last_poster WHERE id=:id', $data);

						$idx->update_search_index('post', $new_pid, $message);
						$this->registry->get('\forum\forum')->update($cur_posting['id']);

						$cur_posting['message'] = ($this->config['o_censoring'] == '1') ? $censored_message : $message;

						$subscriptions = new subscriptions($this->registry);
						$subscriptions->handle_topic_subscriptions($tid, $cur_posting, $username, $new_pid);

						$this->registry->get('\extensions\hooks')->fire('post.posting.postapproved');
					}
					else
					{
						$mail = new \email\email($this->config);
						$info = array(
							'message' => array(
								'<username>' => $username,
								'<topic_title>' => $cur_posting['subject'],
								'<post_url>' => $this->registry->get('\links')->aura_link($this->rewrite->url['admin_posts']),
							)
						);

						$mail_tpl = $this->registry->get('\email\parser')->parse_email('new_post', $this->user['language'], $info);
						$mail->send($this->config['o_mailing_list'], $mail_tpl['subject'], $mail_tpl['message']);

						$this->registry->get('\extensions\hooks')->fire('post.posting.statusready');
					}
				}
				// If it's a new topic
				else if ($fid)
				{
					// Create the topic
					$insert = array(
						'poster'	=>	$username,
						'subject'	=>	$subject,
						'posted'	=>	CURRENT_TIMESTAMP,
						'last_post'	=>	CURRENT_TIMESTAMP,
						'last_poster'	=>	$username,
						'sticky'	=>	$stick_topic,
						'forum_id'	=>	$fid,
						'approved'	=>	$topic_approve,
					);

					$insert = $this->registry->get('\extensions\hooks')->fire('post.posting.topicinsert', $insert);

					$this->db->insert('topics', $insert);
					$new_tid = $this->db->lastInsertId($this->db->prefix.'topics');

					if (!$this->user['is_guest'])
					{
						// To subscribe or not to subscribe, that ...
						$data = array(
							'user_id'	=>	$this->user['id'],
							'topic_id'	=>	$new_tid,
						);

						if ($this->config['o_topic_subscriptions'] == '1' && $subscribe)
						{
							$this->db->insert('topic_subscriptions', $data);
							$this->registry->get('\extensions\hooks')->fire('post.posting.subscriptions');
						}

						// Create the post ("topic post")
						$insert = array(
							'poster'	=>	$username,
							'poster_id'	=>	$this->user['id'],
							'poster_ip'	=>	get_remote_address(),
							'message'	=>	$message,
							'hide_smilies'	=>	$hide_smilies,
							'posted'	=>	CURRENT_TIMESTAMP,
							'topic_id'	=>	$new_tid,
							'approved'	=>	$topic_approve,
						);

						$insert = $this->registry->get('\extensions\hooks')->fire('post.posting.userinsert', $insert);
					}
					else
					{
						$insert_email = ($this->config['p_force_guest_email'] == '1' || $email != '') ? $email : NULL;
						// Create the post ("topic post")
						$insert = array(
							'poster'	=>	$username,
							'poster_ip'	=>	get_remote_address(),
							'poster_email'	=>	$insert_email,
							'message'	=>	$message,
							'hide_smilies'	=>	$hide_smilies,
							'posted'	=>	CURRENT_TIMESTAMP,
							'topic_id'	=>	$new_tid,
							'approved'	=>	$topic_approve,
						);

						$insert = $this->registry->get('\extensions\hooks')->fire('post.posting.guestinsert', $insert);
					}

					$this->db->insert('posts', $insert);
					$new_pid = $this->db->lastInsertId($this->db->prefix.'posts');

					// Update the topic with last_post_id
					$update = array(
						'last_post_id'	=>	$new_pid,
						'first_post_id'	=>	$new_pid,
					);

					$data = array(
						':id'	=>	$new_tid,
					);

					$this->db->update('topics', $update, 'id=:id', $data);

					if ($topic_approve)
					{
						$idx->update_search_index('post', $new_pid, $message, $subject);
						$this->registry->get('\forum\forum')->update($fid);

						$cur_posting['subject'] = ($this->config['o_censoring'] == '1') ? $censored_subject : $subject;
						$cur_posting['message'] = ($this->config['o_censoring'] == '1') ? $censored_message : $message;

						$subscriptions = new subscriptions($this->registry);
						$subscriptions->handle_forum_subscriptions($cur_posting, $username, $new_tid);

						$this->registry->get('\extensions\hooks')->fire('post.posting.topicapproved');
					}
					else
					{
						$email = new \email\email($this->config);
						$info = array(
							'message' => array(
								'<username>' => $this->user['username'],
								'<forum_name>' => $cur_posting['forum_name'],
								'<post_url>' => $this->registry->get('\links')->aura_link($this->rewrite->url['admin_posts']),
							)
						);

						// Load the "new post" template
						$mail_tpl = $this->registry->get('\email\parser')->parse_email('new_post_topic', $this->user['language'], $info);
						$email->send($this->config['o_mailing_list'], $mail_tpl['subject'], $mail_tpl['message']);

						$this->registry->get('\extensions\hooks')->fire('post.posting.topicready');
					}
				}

				// If we previously found out that the email was banned
				if ($this->user['is_guest'] && $banned_email && $this->config['o_mailing_list'] != '')
				{
					$mail = new \email\email($this->config);
					$info = array(
						'message' => array(
							'<username>' => $username,
							'<email>' => $email,
							'<post_url>' => $this->registry->get('\links')->aura_link($this->rewrite->url['post'], array($new_pid)),
						)
					);

					$mail_tpl = $this->registry->get('\email\parser')->parse_email('banned_email_post', $this->user['language'], $info);
					$mail->send($this->config['o_mailing_list'], $mail_tpl['subject'], $mail_tpl['message']);

					$this->registry->get('\extensions\hooks')->fire('post.posting.bannedemail');
				}

				if (isset($_FILES['attached_file']) && $this->config['o_attachments'] == '1')
				{
					if (isset($_FILES['attached_file']['error']) && $_FILES['attached_file']['error'] != 0 && $_FILES['attached_file']['error'] != 4)
						throw new Exception (file_upload_error_message($_FILES['attached_file']['error']));

					if ($_FILES['attached_file']['size'] != 0 && is_uploaded_file($_FILES['attached_file']['tmp_name']))
					{
						$can_upload = false;
						if ($this->user['is_admin'])
							$can_upload = true;
						else
						{
							$can_upload = ($this->user['g_attach_files'] == '1' && ($cur_posting['upload'] == '1' || $cur_posting['upload'] == '')) ? true : false;

							$max_size = ($this->user['g_max_size'] == '0' && $this->user['g_attach_files'] == '1') ? $this->config['o_max_upload_size'] : $this->user['g_max_size'];
							if ($can_upload && $_FILES['attached_file']['size'] > $max_size)
								$can_upload = false;

							if (!$this->registry->get('	opics\attachment')->check_file_extension($_FILES['attached_file']['name']))
								$can_upload = false;
						}

						$this->registry->get('\extensions\hooks')->fire('post.posting.attachment');
						if ($can_upload)
						{
							if (!$this->registry->get('\topics\attachment')->create_attachment($_FILES['attached_file']['name'], $_FILES['attached_file']['type'], $_FILES['attached_file']['size'], $_FILES['attached_file']['tmp_name'], $new_pid, strlen($message)))
								$this->registry->get('\handlers\message')->show($this->lang->t('Attachment error'));
						}
						else // Remove file as it's either dangerous or they've attempted to URL hack. Either way, there's no need for it.
							unlink($_FILES['attached_file']['tmp_name']);
					}

					$this->registry->get('\extensions\hooks')->fire('post.posting.attachmentuploaded');
				}

				// If the posting user is logged in, increment his/her post count
				if (!$this->user['is_guest'])
				{
					if ($fid && $topic_approve == '1' || $tid && $post_approve == '1')
					{
						$data = array(
							':id'	=>	$this->user['id'],
							':last_post' => CURRENT_TIMESTAMP,
						);

						$update = ($cur_posting['increment_posts'] == '1') ? 'num_posts=num_posts+1, ' : '';
						$this->db->run('UPDATE '.$this->db->prefix.'users SET '.$update.'last_post=:last_post WHERE id=:id', $data);

						// Promote this user to a new group if enabled
						if ($this->user['g_promote_next_group'] != 0 && $this->user['num_posts'] + 1 >= $this->user['g_promote_min_posts'] && $cur_posting['increment_posts'] == '1')
						{
							$update = array(
								'group_id' => $this->user['g_promote_next_group'],
							);
							
							$data = array(
								'id' => $this->user['id'],
							);

							$this->db->update('users', $update, 'id=:id', $data);

							$this->registry->get('\extensions\hooks')->fire('post.posting.autopromotion');
						}

						$this->registry->get('\extensions\hooks')->fire('post.posting.postcount');
					}
					else
					{
						$update = array(
							'last_post'	=> CURRENT_TIMESTAMP,
						);
						
						$data = array(
							':id' => $this->user['id'],
						);
						
						$this->db->update('users', $update, 'id=:id', $data);

						$this->registry->get('\extensions\hooks')->fire('post.posting.updatelastpost');
					}
						
					// Topic tracking stuff...
					$tracked_topics = $this->registry->get('\cookie\tracked')->get_tracked_topics();
					$tracked_topics['topics'][$new_tid] = CURRENT_TIMESTAMP;
					$this->registry->get('\cookie\tracked')->set_tracked_topics($tracked_topics);
				}
				else
				{
					$update = array(
						'last_post' => CURRENT_TIMESTAMP,
					);

					$data = array(
						':ident' => get_remote_address(),
					);
					
					$this->db->update('online', $update, 'ident=:ident', $data);

					$this->registry->get('\extensions\hooks')->fire('post.posting.updateonline');
				}

				$this->registry->get('\extensions\hooks')->fire('post.posting.beforeredirect');

				if ($add_poll)
				{
					$redirect = $this->registry->get('\links')->aura_link($this->rewrite->url['poll_add'], array($new_tid));
					$redirect = $this->registry->get('\extensions\hooks')->fire('post.posting.addpoll', $redirect);
				}

				switch (true)
				{
					case $fid && $topic_approve == '0':
						$redirect_lang = $this->lang->t('Topic moderation redirect');
						
						if (!isset($redirect))
							$redirect = $this->registry->get('\links')->aura_link($this->rewrite->url['forum'], array($cur_posting['id'], \url\url::replace($subject)));
					break;
					case $tid && $post_approve == '0':
						$redirect_lang = $this->lang->t('Post moderation redirect');
						
						if (!isset($redirect))
							$redirect = $this->registry->get('\links')->aura_link($this->rewrite->url['topic'], array($tid, \url\url::replace($cur_posting['subject'])));
					break;
					default:
						$redirect_lang = $this->lang->t('Post redirect');

						if (!isset($redirect))
							$redirect = $this->registry->get('\links')->aura_link($this->rewrite->url['post'], array($new_pid));
					break;
				}

				$this->registry->get('\extensions\hooks')->fire('post.posting.redirect');
				$this->registry->get('\handlers\redirect')->show($redirect, $redirect_lang);
			}
		}

		// If a topic ID was specified in the url (it's a reply)
		if ($tid)
		{
			$post_link = $this->registry->get('\links')->aura_link($this->rewrite->url['new_reply'], array($tid));
			$action = $this->lang->t('Post a reply');

			// If a quote ID was specified in the url
			if (isset($_GET['qid']))
			{
				$qid = intval($_GET['qid']);
				if ($qid < 1)
					$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

				$data = array(
					':id' => $qid,
					':tid' => $tid,
				);

				$ps = $this->db->select('posts', 'poster, message', $data, 'id=:id AND topic_id=:tid');
				if (!$ps->rowCount())
					$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

				list($q_poster, $q_message) = $ps->fetch(PDO::FETCH_NUM);

				// If the message contains a code tag we have to split it up (text within [code][/code] shouldn't be touched)
				if (strpos($q_message, '[code]') !== false && strpos($q_message, '[/code]') !== false)
				{
					list($inside, $outside) = $this->registry->get('\message\bbcode')->split_text($q_message, '[code]', '[/code]');
					$q_message = implode("\1", $outside);
				}

				// Remove [img] tags from quoted message
				$q_message = preg_replace('%\[img(?:=(?:[^\[]*?))?\]((ht|f)tps?://)([^\s<"]*?)\[/img\]%U', '\1\3', $q_message);

				// If we split up the message before we have to concatenate it together again (code tags)
				if (isset($inside))
				{
					$outside = explode("\1", $q_message);
					$q_message = '';

					$num_tokens = count($outside);
					for ($i = 0; $i < $num_tokens; ++$i)
					{
						$q_message .= $outside[$i];
						if (isset($inside[$i]))
							$q_message .= '[code]'.$inside[$i].'[/code]';
					}

					unset($inside);
				}

				if ($this->config['o_censoring'] == '1')
					$q_message = $this->registry->get('\message\bbcode')->censor_words($q_message);

				if ($this->config['p_message_bbcode'] == '1')
				{
					// If username contains a square bracket, we add "" or '' around it (so we know when it starts and ends)
					if (strpos($q_poster, '[') !== false || strpos($q_poster, ']') !== false)
					{
						if (strpos($q_poster, '\'') !== false)
							$q_poster = '"'.$q_poster.'"';
						else
							$q_poster = '\''.$q_poster.'\'';
					}
					else
					{
						// Get the characters at the start and end of $q_poster
						$ends = substr($q_poster, 0, 1).substr($q_poster, -1, 1);

						// Deal with quoting "Username" or 'Username' (becomes '"Username"' or "'Username'")
						if ($ends == '\'\'')
							$q_poster = '"'.$q_poster.'"';
						else if ($ends == '""')
							$q_poster = '\''.$q_poster.'\'';
					}

					$quote = '[quote='.$q_poster.']'.$q_message.'[/quote]'."\n";
				}
				else
					$quote = '> '.$q_poster.' '.$this->lang->t('wrote')."\n\n".'> '.$q_message."\n";

				$quote = $this->registry->get('\extensions\hooks')->fire('post.quote', $quote);
			}
		}
		else if ($fid) // If a forum ID was specified in the url (new topic)
		{
			$post_link = $this->registry->get('\links')->aura_link($this->rewrite->url['new_topic'], array($fid));
			$action = $this->lang->t('Post new topic');
		}

		$this->template->header = array(
			'posting' => true, // Tell header.php we should use the editor
			'page_title' => array($this->config['o_board_title'], $action),
			'required_fields' => array('req_email' => $this->lang->t('Email'), 'req_subject' => $this->lang->t('Subject'), 'req_message' => $this->lang->t('Message')),
			'focus_element' => array('post'),
			'active_page' => 'index',
		);

		if (!$this->user['is_guest'])
			$this->template->header['focus_element'][] = ($fid) ? 'req_subject' : 'req_message';
		else
		{
			$this->template->header['required_fields']['req_username'] = $this->lang->t('Guest name');
			$this->template->header['focus_element'][] = 'req_username';
		}

		if (!empty($aura_robots) && $this->user['g_robot_test'] == '1')
			$this->template->header['required_fields']['answer'] = $this->lang->t('Robot title');

		$this->template->header = $this->registry->get('\extensions\hooks')->fire('post.header', $this->template->header);

		$can_upload = false;
		if ($this->config['o_attachments'] == '1')
		{
			if ($this->user['is_admin'])
				$can_upload = true;
			else if ($this->user['g_attach_files'] == '1' && ($cur_posting['upload'] == '1' || $cur_posting['upload'] == ''))
				$can_upload = true;

			$can_upload = $this->registry->get('\extensions\hooks')->fire('post.attachment', $can_upload);
		}

		$max_size = ($this->user['g_max_size'] == '0' && $this->user['g_attach_files'] == '1') ? $this->config['o_max_upload_size'] : $this->user['g_max_size'];

		$checkboxes = array();
		if ($fid && $is_admmod)
			$checkboxes[] = array('name' => 'stick_topic', 'checked' => (isset($_POST['stick_topic']) ? true : false), 'title' => $this->lang->t('Stick topic'));

		if ($fid && $cur_posting['post_polls'] != '0' && $this->user['g_post_polls'] == '1' && $this->config['o_polls'] == '1')
			$checkboxes[] = array('name' => 'add_poll', 'checked' => (isset($_POST['add_poll']) ? true : false), 'title' => $this->lang->t('Add poll'));

		if (!$this->user['is_guest'])
		{
			if ($this->config['o_smilies'] == '1')
				$checkboxes[] = array('name' => 'hide_smilies', 'checked' => (isset($_POST['hide_smilies']) ? true : false), 'title' => $this->lang->t('Hide smilies'));

			if ($this->config['o_topic_subscriptions'] == '1')
			{
				$subscr_checked = false;

				// If it's a preview
				if (isset($_POST['preview']))
					$subscr_checked = isset($_POST['subscribe']) ? true : false;
				// If auto subscribed
				else if ($this->user['auto_notify'])
					$subscr_checked = true;
				// If already subscribed to the topic
				else if ($is_subscribed)
					$subscr_checked = true;

				$checkboxes[] = array('name' => 'subscribe', 'checked' => (($subscr_checked) ? true : false), 'title' => (($is_subscribed ? $this->lang->t('Stay subscribed') : $this->lang->t('Subscribe'))));
			}
		}
		else if ($this->config['o_smilies'] == '1')
			$checkboxes[] = array('name' => 'hide_smilies', 'checked' => (isset($_POST['hide_smilies']) ? true : false), 'title' => $this->lang->t('Hide smilies'));

		$checkboxes = $this->registry->get('\extensions\hooks')->fire('post.checkboxes', $checkboxes);

		// Check to see if the topic review is to be displayed
		$posts = array();
		if ($tid && $this->config['o_topic_review'] != '0')
		{
			$parser = new \message\parser($this->registry);
			$join = array(
				array(
					'type' => 'LEFT',
					'table' => 'users',
					'as' => 'u',
					'on' => '(p.poster=u.username)',
				),
			);

			$data = array(
				':id' => $tid,
				':limit' => $this->config['o_topic_review'],
			);

			$ps = $this->db->join('posts', 'p', $join, 'p.poster, p.message, p.hide_smilies, p.posted, u.group_id', $data, 'p.topic_id=:id', 'p.id DESC LIMIT :limit');
			foreach ($ps as $cur_post)
				$posts[] = array('username' => $this->functions->colourise_group($cur_post['poster'], $cur_post['group_id']), 'posted' => $this->registry->get('\aura_time')->format($cur_post['posted']), 'message' => $parser->parse_message($cur_post['message'], $cur_post['hide_smilies']));

			$posts = $this->registry->get('\extensions\hooks')->fire('post.postreview', $posts);
		}

		$render = array(
			'posts' => $posts,
			'errors' => $errors,
			'index_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['index']),
			'forum_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['forum'], array($cur_posting['id'], \url\url::replace($cur_posting['forum_name']))),
			'cur_posting' => $cur_posting,
			'POST' => $_POST,
			'action' => $action,
			'fid' => $fid,
			'tid' => $tid,
			'csrf_token' => $this->registry->get('\auth\csrf')->generate('post'),
			'message' => isset($_POST['req_message']) ? $orig_message : (isset($quote) ? $quote : ''),
			'aura_user' => $this->user,
			'can_upload' => $can_upload,
			'checkboxes' => $checkboxes,
			'quickpost_links' => array(
				'bbcode' => $this->registry->get('\links')->aura_link($this->rewrite->url['help'], array('bbcode')),
				'url' => $this->registry->get('\links')->aura_link($this->rewrite->url['help'], array('url')),
				'img' => $this->registry->get('\links')->aura_link($this->rewrite->url['help'], array('img')),
				'smilies' => $this->registry->get('\links')->aura_link($this->rewrite->url['help'], array('smilies')),
			),
		);

		if (isset($cur_posting['subject']))
			$render['topic_link'] = $this->registry->get('\links')->aura_link($this->rewrite->url['topic'], array($tid, \url\url::replace($cur_posting['subject'])));

		if (isset($_POST['preview']))
		{
			$parser = new \message\parser($this->registry);
			$render['preview'] = $parser->parse_message($message, $hide_smilies);
		}

		if ($this->user['is_guest'])
		{
			$email_form_name = ($this->config['p_force_guest_email'] == '1') ? 'req_email' : 'email';

			$render['username'] = (isset($username)) ? $username : '';
			$render['email'] = (isset($_POST[$email_form_name])) ? $email : '';
			$render['email_form_name'] = $email_form_name;
		}

		if ($can_upload)
			$render['max_size'] = $max_size;

		if (!empty($aura_robots) && $this->user['g_robot_test'] == '1')
		{
			$id = array_rand($aura_robots);
			$render['robot_id'] = $id;
			$render['test'] = $aura_robots[$id];
		}

		$args = $this->registry->get('\extensions\hooks')->fire('post.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('post.tpl');
		$this->template->output($tpl, $render);
	}
}