<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class help_controller extends base_controller
{
	/*
	 * Main app entry point- run the help section
	 */
	public function execute()
	{
		$this->registry->get('\extensions\hooks')->fire('help.immediate');

		if ($this->user['g_read_board'] == '0')
			$this->registry->get('\handlers\message')->show($this->lang->t('No view'), false, '403 Forbidden');

		// Load the help language file
		$this->lang->load('help');

		// Display the smiley set
		$parser = new \message\parser($this->registry);

		$smiley_groups = array();
		foreach (\message\parser::$smilies as $smiley_text => $smiley_img)
			$smiley_groups[$smiley_img][] = $smiley_text;

		$smiley_groups = $this->registry->get('\extensions\hooks')->fire('help.emoticons', $smiley_groups);

		$ps = $this->db->select('topics', 'subject, id', array(), '', 'id ASC LIMIT 1');
		$cur_topic = $ps->fetch();

		$ps = $this->db->select('posts', 'id', array(), '', 'id ASC LIMIT 1');
		$cur_post = $ps->fetchColumn();

		$ps = $this->db->select('users', 'id, username, group_id', array(), 'id>1', 'id ASC LIMIT 1');
		$user = $ps->fetch();

		$forums = $this->cache->get('forums');
		$forum = $forums[key($forums)];

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Help')),
			'active_page' => 'help',
		);

		$this->template->header = $this->registry->get('\extensions\hooks')->fire('help.header', $this->template->header);
		$args = $this->registry->get('\extensions\hooks')->fire('help.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('help.tpl');
		$this->template->output($tpl,
		array_merge(
			array(
				'base_url' => $this->registry->get('\links')->aura_link($this->rewrite->url['index']),
				'help_page' => $this->registry->get('\links')->aura_link($this->rewrite->url['help'], array('url')),
				'topic_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['topic'], array($cur_topic['id'], \url\url::replace($cur_topic['subject']))),
				'topic_id' => $cur_topic['id'],
				'post_id' => $cur_post,
				'post_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['post'], array($cur_post)),
				'forum_id' => $forum['id'],
				'forum_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['forum'], array($forum['id'], \url\url::replace($forum['forum_name']))),
				'formatted_username' => $this->functions->colourise_group($user['username'], $user['group_id'], $user['id']),
				'username' => $user['username'],
				'smiley_path' => (($this->config['o_smilies_dir'] != '') ? $this->config['o_smilies_dir'] : $this->functions->get_base_url().'/'.$this->config['o_smilies_path'].'/'),
				'smiley_groups' => $smiley_groups,
				),
				$args
			)
		);
	}
}