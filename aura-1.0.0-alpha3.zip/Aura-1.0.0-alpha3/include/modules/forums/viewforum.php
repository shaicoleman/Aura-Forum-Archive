<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class viewforum_controller extends base_controller
{
	/*
	 * Main class entry point
	 */
	public function execute()
	{
		$this->registry->get('\extensions\hooks')->fire('viewforum.immediate');

		$this->lang->load('index');
		$this->lang->load('online');

		if ($this->user['g_read_board'] == '0')
			$this->registry->get('\handlers\message')->show($this->lang->t('No view'), false, '403 Forbidden');

		$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
		if ($id < 1)
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		// Load the viewforum language file
		$this->lang->load('forum');

		$cur_forum = $this->fetch_forum_info($id);

		// Is this a redirect forum? In that case, redirect!
		if ($cur_forum['redirect_url'] != '')
		{
			header('Location: '.$cur_forum['redirect_url']);
			exit;
		}

		if ($cur_forum['password'] != '')
		{
			if (isset($_POST['form_sent']))
				$this->registry->get('\auth\forum')->validate_login_attempt($id);
			else
				$this->registry->get('\cookie\cookie')->check_forum_login_cookie($id, $cur_forum['password']);
		}

		$this->registry->get('\extensions\hooks')->fire('viewforum.authorised');

		// Sort out who the moderators are and if we are currently a moderator (or an admin)
		$moderators = $this->cache->get('moderators');
		$is_admmod = ($this->user['is_admin'] || ($this->user['g_moderator'] == '1' && $this->user['g_global_moderator'] == '1' || isset($moderators[$id]['u'.$this->user['id']]) || isset($moderators[$id]['g'.$this->user['g_id']]))) ? true : false;

		switch ($cur_forum['sort_by'])
		{
			case 0:
				$sort_by = 'last_post DESC';
				break;
			case 1:
				$sort_by = 'posted DESC';
				break;
			case 2:
				$sort_by = 'subject ASC';
				break;
			default:
				$sort_by = 'last_post DESC';
				break;
		}

		$sort_by = $this->registry->get('\extensions\hooks')->fire('viewforum.sortby', $sort_by);

		// Get topic/forum tracking data
		list($new_topics, $tracked_topics) = $this->fetch_new_topics();

		// Determine the topic offset (based on $_GET['p'])
		$num_pages = ceil($cur_forum['num_topics'] / $this->user['disp_topics']);

		// Preg replace is slow!
		$url_forum = \url\url::replace($cur_forum['forum_name']);

		// Add relationship meta tags
		$this->template->header = array(
			'canonical' => array('href' => $this->registry->get('\links')->aura_link($this->rewrite->url['forum'], array($id, $url_forum)), 'rel' => 'canonical'),
			'p' => (!isset($_GET['p']) || $_GET['p'] <= 1 || $_GET['p'] > $num_pages) ? 1 : intval($_GET['p']),
			'page_title' => array($this->config['o_board_title'], $cur_forum['forum_name']),
			'allow_index' => true,
			'active_page' => 'index',
		);

		$start_from = $this->user['disp_topics'] * ($this->template->header['p'] - 1);
		if ($num_pages > 1)
		{
			if ($this->template->header['p'] > 1)
				$this->template->header['prev'] = array('href' => $this->registry->get('\links')->aura_link($this->rewrite->url['forum_page'], array($id, ($this->template->header['p'] -1), $url_forum)), 'rel' => 'prev');
			if ($this->template->header['p'] < $num_pages)
				$this->template->header['next'] = array('href' => $this->registry->get('\links')->aura_link($this->rewrite->url['forum_page'], array($id, ($this->template->header['p'] +1), $url_forum)), 'rel' => 'next');
		}

		if ($this->config['o_feed_type'] == '1')
			$this->template->header['feed'] = array('href' => $this->registry->get('\links')->aura_link($this->rewrite->url['forum_rss'], array($id)), 'rel' => 'alternate', 'type' => 'application/rss+xml', 'title' => $this->lang->t('RSS forum feed'));
		else if ($this->config['o_feed_type'] == '2')
			$this->template->header['feed'] = array('href' => $this->registry->get('\links')->aura_link($this->rewrite->url['forum_atom'], array($id)), 'rel' => 'alternate', 'type' => 'application/atom+xml', 'title' => $this->lang->t('Atom forum feed'));

		$this->template->header = $this->registry->get('\extensions\hooks')->fire('viewforum.header', $this->template->header);
		$forum_actions = $this->fetch_forum_actions($cur_forum, $id);

		$forums = $this->list_sub_forums($id, $moderators, $tracked_topics);

		$announcements = $this->fetch_announcements($id);

		// Retrieve a list of topic IDs, LIMIT is (really) expensive so we only fetch the IDs here then later fetch the remaining data
		$topics = $this->fetch_forum_topics($id, $start_from, $is_admmod, $sort_by, $cur_forum, $tracked_topics);

		list($users, $guests_in_forum) = $this->fetch_users_online($id);

		$render = array(
			'cur_forum' => $cur_forum,
			'is_admmod' => $is_admmod,
			'post_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['new_topic'], array($id)),
			'lang' => $this->lang,
			'index_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['index']),
			'forum_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['forum'], array($id, $url_forum)),
			'pagination' => $this->registry->get('\pagination')->paginate($num_pages, $this->template->header['p'], $this->rewrite->url['forum_paginate'], array($id, $url_forum)),
			'forums' => $forums,
			'topics' => $topics,
			'new_topics' => $new_topics,
			'announcements' => $announcements,
			'forum_actions' => $forum_actions,
			'guests' => $guests_in_forum,
			'users' => (count($users) > 0) ? implode(', ', $users) : $this->lang->t('no users'),
		);

		if ($cur_forum['parent'])
			$render['parent_link'] = $this->registry->get('\links')->aura_link($this->rewrite->url['forum'], array($cur_forum['parent_forum'], \url\url::replace($cur_forum['parent'])));

		$this->template->footer = array(
			'forum_id' => $id, // We need a specific 'forum_id' key for the quickjump cache
			'footer_style' => 'viewforum',
			'is_admmod' => $is_admmod,
			'id' => $id,
		);

		$this->template->footer = $this->registry->get('\extensions\hooks')->fire('viewforum.footer', $this->template->footer);

		$args = $this->registry->get('\extensions\hooks')->fire('viewforum.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('forum.tpl');
		$this->template->output($tpl, array_merge($render, $args));
	}

	/*
	 * Fetches some info about the forum
	 */
	protected function fetch_forum_info($id)
	{
		$data = array(
			':gid'	=>	$this->user['g_id'],
			':fid'	=>	$id,
		);

		// Fetch some info about the forum
		$join = array(
			array(
				'type' => 'LEFT',
				'table' => 'forum_subscriptions',
				'as' => 's',
				'on' => '(f.id=s.forum_id AND s.user_id=:id)',
			),
			array(
				'type' => 'LEFT',
				'table' => 'forum_perms',
				'as' => 'fp',
				'on' => '(fp.forum_id=f.id AND fp.group_id=:gid)',
			),
			array(
				'type' => 'LEFT',
				'table' => 'forums',
				'as' => 'pf',
				'on' => 'f.parent_forum=pf.id',
			),
		);

		if (!$this->user['is_guest'])
		{
			$data[':id'] = $this->user['id'];
			$ps = $this->db->join('forums', 'f', $join, 'pf.forum_name AS parent, f.parent_forum, f.protected, f.forum_name, f.redirect_url, f.password, f.num_topics, f.sort_by, fp.post_topics, s.user_id AS is_subscribed', $data, '(fp.read_forum IS NULL OR fp.read_forum=1) AND f.id=:fid');
		}
		else
		{
			unset($join[0]);
			$ps = $this->db->join('forums', 'f', $join, 'pf.forum_name AS parent, f.parent_forum, f.protected, f.forum_name, f.redirect_url, f.password, f.num_topics, f.sort_by, fp.post_topics, 0 AS is_subscribed', $data, '(fp.read_forum IS NULL OR fp.read_forum=1) AND f.id=:fid');
		}

		if (!$ps->rowCount())
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		$cur_forum = $ps->fetch();

		$cur_forum = $this->registry->get('\extensions\hooks')->fire('viewforum.fetchforum', $cur_forum);
		return $cur_forum;
	}

	/*
	 * Do we have any forum announcements?
	 */
	protected function fetch_announcements($id)
	{
		// Load the cached announcements
		$aura_announcements = $this->cache->get('announcements');

		$announcements = array();
		if (!empty($aura_announcements[$id]))
		{
			$announce_count = 0;
			foreach ($aura_announcements[$id] as $cur_announce)
			{
				$data = array(
					':id' => $cur_announce['user_id'],
				);

				$ps = $this->db->select('users', 'username, group_id', $data, 'id=:id');
				list($username, $group_id) = $ps->fetch(PDO::FETCH_NUM);

				$announcements[] = array(
					'count' => $this->functions->forum_number_format($announce_count++),
					'user' => $this->functions->colourise_group($username, $group_id, $cur_announce['user_id']),
					'link' => $this->registry->get('\links')->aura_link($this->rewrite->url['announcement'], array($cur_announce['id'], $id, $cur_announce['url_subject'])),
					'subject' => $cur_announce['subject'],
				);

				$announcements = $this->registry->get('\extensions\hooks')->fire('viewforum.announcements', $announcements);
			}
		}

		return $announcements;
	}

	/*
	 * Fetch the users online in this forum
	 */
	protected function fetch_users_online($id)
	{
		$users = array();
		$guests_in_forum = 0;
		if ($this->config['o_users_online'] == '1')
		{
			$data = array(
				':topic' => '%forum|'.$id.'|topic|%',
				':forum' => 'forum|'.$id,
			);

			$join = array(
				array(
					'type' => 'INNER',
					'table' => 'users',
					'as' => 'u',
					'on' => 'o.user_id=u.id',
				),
			);

			$ps = $this->db->join('online', 'o', $join, 'o.user_id, o.ident, o.currently, o.logged, u.group_id', $data, '(o.currently LIKE :topic OR o.currently=:forum) AND o.idle=0');
			foreach ($ps as $user_online)
			{
				if ($user_online['user_id'] == 1)
					++$guests_in_forum;
				else
					$users[] = $this->functions->colourise_group($user_online['ident'], $user_online['group_id'], $user_online['user_id']);

				$users = $this->registry->get('\extensions\hooks')->fire('viewforum.usersonline', $users);
			}
		}

		return array($users, $guests_in_forum);
	}

	/**
	 * Fetch any new topics in this forum
	 */
	protected function fetch_new_topics()
	{
		$new_topics = $tracked_topics = array();
		if (!$this->user['is_guest'])
		{
			$join = array(
				array(
					'type' => 'INNER',
					'table' => 'forums',
					'as' => 'f',
					'on' => 'f.id=t.forum_id',
				),
				array(
					'type' => 'LEFT',
					'table' => 'forum_perms',
					'as' => 'fp',
					'on' => '(fp.forum_id=f.id AND fp.group_id=:gid)',
				),
			);

			$data = array(
				':gid' => $this->user['g_id'],
				':last_visit' => $this->user['last_visit'],
			);

			$ps = $this->db->join('topics', 't', $join, 't.forum_id, t.id, t.last_post', $data, '(fp.read_forum IS NULL OR fp.read_forum=1) AND t.last_post>:last_visit AND t.moved_to IS NULL');
			if ($ps->rowCount())
			{
				foreach ($ps as $cur_topic)
					$new_topics[$cur_topic['forum_id']][$cur_topic['id']] = $cur_topic['last_post'];
			}

			$tracked_topics = $this->registry->get('\cookie\tracked')->get_tracked_topics();
			$tracked_topics = $this->registry->get('\extensions\hooks')->fire('viewforum.trackedtopics', $tracked_topics);
		}

		return array($new_topics, $tracked_topics);
	}

	/*
	 * If we're logged in, are there any actions we can perform?
	 */
	protected function fetch_forum_actions($cur_forum, $id)
	{
		$forum_actions = array();
		if (!$this->user['is_guest'])
		{
			$token = $this->registry->get('\auth\csrf')->generate('viewforum');
			if ($this->config['o_forum_subscriptions'] == '1')
			{
				if ($cur_forum['is_subscribed'])
					$forum_actions[] = array('info' => $this->lang->t('Is subscribed'), 'href' => $this->registry->get('\links')->aura_link($this->rewrite->url['forum_unsubscribe'], array($id, $this->registry->get('\auth\csrf')->generate('unsubscribe'))), 'title' => $this->lang->t('Unsubscribe'));
				else
					$forum_actions[] = array('href' => $this->registry->get('\links')->aura_link($this->rewrite->url['forum_subscribe'], array($id, $this->registry->get('\auth\csrf')->generate('subscribe'))), 'title' => $this->lang->t('Subscribe'));
			}

			$forum_actions[] = array('href' => $this->registry->get('\links')->aura_link($this->rewrite->url['mark_forum_read'], array($id, $token)), 'title' => $this->lang->t('Mark forum read'));
		}

		$forum_actions = $this->registry->get('\extensions\hooks')->fire('viewforum.forumactions', $forum_actions);
		return $forum_actions;
	}

	/*
	 * Grab a list of any sub forums within this forum
	 */
	protected function list_sub_forums($id, $moderators, $tracked_topics)
	{
		$data = array(
			':gid' => $this->user['g_id'],
			':id' => $id,
		);

		$join = array(
			array(
				'type' => 'LEFT',
				'table' => 'forum_perms',
				'as' => 'fp',
				'on' => '(fp.forum_id=f.id AND fp.group_id=:gid)',
			),
			array(
				'type' => 'LEFT',
				'table' => 'users',
				'as' => 'u',
				'on' => '(f.last_poster=u.username)',
			),
		);

		$forums = array();
		$ps = $this->db->join('forums', 'f', $join, 'f.forum_desc, f.forum_name, f.id, f.last_post, f.last_post_id, f.last_poster, f.last_topic, f.last_topic_id, u.id AS uid, u.email, u.group_id, u.use_gravatar, f.num_posts, f.show_post_info, f.num_topics, f.redirect_url', $data, '(fp.read_forum IS NULL OR fp.read_forum=1) AND parent_forum=:id ORDER BY disp_position');
		if ($ps->rowCount())
		{
			$forum_count = 0;
			$forums = array();
			foreach ($ps as $cur_subforum)
			{
				$num_topics = $cur_subforum['num_topics'];
				$num_posts = $cur_subforum['num_posts'];

				$cur_subforum['moderators'] = array();
				if (isset($moderators[$cur_subforum['id']]))
				{
					foreach ($moderators[$cur_subforum['id']] as $moderator)
					{
						if ($moderator['user_id']) // It's a user
						{
							$data = array(
								':id' => $moderator['user_id'],
							);

							// There has to be a better way of doing this ....
							$ps1 = $this->db->select('users', 'group_id', $data, 'id=:id');
							$group_id = $ps1->fetchColumn();

							$cur_subforum['moderators'][] = $this->functions->colourise_group($moderator['username'], $group_id, $moderator['user_id']);
						}
						else // It's an entire user group
							$cur_subforum['moderators'][] = $this->functions->colourise_group($moderator['group_title'], $moderator['group_id']);
					}
				}

				// Is this a redirect forum?
				if ($cur_subforum['redirect_url'] != '')
					$num_topics = $num_posts = '-';
				else
				{
					$num_topics = $this->functions->forum_number_format($num_topics);
					$num_posts = $this->functions->forum_number_format($num_posts);
				}
				
				$new = false;
				if (!$this->user['is_guest'] && $cur_subforum['last_post'] > $this->user['last_visit'] && (empty($tracked_topics['forums'][$cur_subforum['id']]) || $cur_subforum['last_post'] > $tracked_topics['forums'][$cur_subforum['id']]))
				{
					// There are new posts in this forum, but have we read all of them already?
					foreach ($new_topics[$cur_subforum['id']] as $check_topic_id => $check_last_post)
					{
						if ((empty($tracked_topics['topics'][$check_topic_id]) || $tracked_topics['topics'][$check_topic_id] < $check_last_post) && (empty($tracked_topics['forums'][$cur_subforum['id']]) || $tracked_topics['forums'][$cur_subforum['id']] < $check_last_post))
						{
							$new = true;
							break;
						}
					}
				}

				$forums[$cur_subforum['id']] = array(
					'moderators' => $cur_subforum['moderators'],
					'last_post' => ($cur_subforum['last_post']) ? $this->registry->get('\aura_time')->format($cur_subforum['last_post']) : '',
					'num_topics' => $num_topics,
					'num_posts' => $num_posts,
					'forum_count' => $this->functions->forum_number_format($forum_count++),
					'search_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['search_new_results'], array($cur_subforum['id'])),
					'link' => $this->registry->get('\links')->aura_link($this->rewrite->url['forum'], array($cur_subforum['id'], \url\url::replace($cur_subforum['forum_name']))),
					'forum_name' => $cur_subforum['forum_name'],
					'forum_desc' => $cur_subforum['forum_desc'],
					'redirect_url' => $cur_forum['redirect_url'],
					'show_post_info' => $cur_subforum['show_post_info'],
					'new' => $new,
				);

				if ($cur_subforum['last_post'])
				{
					$forums[$cur_subforum['id']]['last_post_avatar'] = $this->registry->get('\avatar')->generate($cur_subforum['uid'], $cur_subforum['email'], $cur_subforum['use_gravatar'], array(32, 32));
					$forums[$cur_subforum['id']]['last_post_link'] = $this->registry->get('\links')->aura_link($this->rewrite->url['post'], array($cur_subforum['last_post_id']));
					$forums[$cur_subforum['id']]['last_topic_link'] = $this->registry->get('\links')->aura_link($this->rewrite->url['topic'], array($cur_subforum['last_topic_id'], \url\url::replace($cur_subforum['last_topic'])));
					$forums[$cur_subforum['id']]['last_topic'] = ((aura_strlen($cur_subforum['last_topic']) > 30) ? utf8_substr($cur_subforum['last_topic'], 0, 30).' �' : $cur_subforum['last_topic']);
					$forums[$cur_subforum['id']]['last_poster'] = (isset($cur_subforum['group_id'])) ? $this->functions->colourise_group($cur_subforum['last_poster'], $cur_subforum['group_id'], $cur_subforum['uid']) : $this->functions->colourise_group($cur_subforum['last_poster'], AURA_GUEST);
				}

				$forums = $this->registry->get('\extensions\hooks')->fire('viewforum.subforums', $forums);
			}
		}

		return $forums;
	}

	/*
	 * Fetch the main body of the topics
	 */
	protected function fetch_forum_topics($id, $start_from, $is_admmod, $sort_by, $cur_forum, $tracked_topics)
	{
		$data = array(
			':id' => $id,
			':start' => $start_from,
			':limit' => $this->user['disp_topics'],
		);

		if ($cur_forum['protected'] == '1' && !$is_admmod)
		{
			$where = ' AND poster=:username';
			$data[':username'] = $this->user['username']; // This won't work with guests, but there's nothing that can be done
		}
		else
			$where = '';

		$topics = array();
		$forum_has_posts = false;
		$ps = $this->db->select('topics', 'id', $data, 'forum_id=:id AND approved=1 AND deleted=0'.$where, 'sticky DESC, '.$sort_by.', id DESC LIMIT :start, :limit');
		if ($ps->rowCount())
		{
			$forum_has_posts = true; // If there are topics in this forum
			$topic_ids = $placeholders = $data = array();
			$ps->setFetchMode(PDO::FETCH_COLUMN, 0);
			foreach ($ps as $cur_topic_id)
			{
				$topic_ids[] = $cur_topic_id;
				$placeholders[] = '?';
			}

			// Fetch list of topics to display on this page
			if ($this->user['is_guest'] || $this->config['o_show_dot'] == '0') // Without "the dot"
			{
				$join = array(
					array(
						'type' => 'LEFT',
						'table' => 'users',
						'as' => 'u',
						'on' => '(t.last_poster=u.username)',
					),
					array(
						'type' => 'LEFT',
						'table' => 'users',
						'as' => 'up',
						'on' => '(t.poster=up.username)',
					),
				);

				$data = array_merge($data, $topic_ids);
				$ps = $this->db->join('topics', 't', $join, 'u.id AS uid, u.group_id, u.email, u.use_gravatar, up.id AS up_id, up.group_id AS up_group_id, t.id, t.poster, t.subject, t.question, t.posted, t.last_post, t.last_post_id, t.last_poster, t.num_views, t.num_replies, t.closed, t.sticky, t.archived, t.moved_to', $data, 't.id IN('.implode(',', $placeholders).') AND t.approved=1 AND t.deleted=0', 't.sticky DESC, t.'.$sort_by.', t.id DESC');
			}
			else // With "the dot"
			{
				$data[] = $this->user['id'];
				$join = array(
					array(
						'type' => 'LEFT',
						'table' => 'posts',
						'as' => 'p',
						'on' => 't.id=p.topic_id AND p.poster_id=?',
					),
					array(
						'type' => 'LEFT',
						'table' => 'users',
						'as' => 'u',
						'on' => '(t.last_poster=u.username)',
					),
					array(
						'type' => 'LEFT',
						'table' => 'users',
						'as' => 'up',
						'on' => '(t.poster=up.username)',
					),
				);

				$data = array_merge($data, $topic_ids);
				$ps = $this->db->join('topics', 't', $join, 'u.id AS uid, u.group_id, u.email, u.use_gravatar, up.id AS up_id, up.group_id AS up_group_id, p.poster_id AS has_posted, t.id, t.subject, t.question, t.poster, t.posted, t.last_post, t.last_post_id, t.last_poster, t.num_views, t.num_replies, t.closed, t.sticky, t.archived, t.moved_to', $data, 't.id IN('.implode(',', $placeholders).') AND t.approved=1 AND t.deleted=0 GROUP BY t.id', 't.sticky DESC, t.'.$sort_by.', t.id DESC');
			}

			$topic_count = 0;
			foreach ($ps as $cur_topic)
			{
				$url_subject = \url\url::replace($cur_topic['subject']); // Preg match is slow!

				if ($this->config['o_censoring'] == '1')
					$cur_topic['subject'] = $this->registry->get('\message\bbcode')->censor_words($cur_topic['subject']);

				$num_pages_topic = ceil(($cur_topic['num_replies'] + 1) / $this->user['disp_posts']);
				$topics[$cur_topic['id']] = array(
					'count' => ++$topic_count,
					'topic_count' => $this->functions->forum_number_format($topic_count + $start_from),
					'cur_topic' => $cur_topic,
					'topic_poster' => ($cur_topic['up_id'] > 1) ? $this->functions->colourise_group($cur_topic['poster'], $cur_topic['up_group_id'], $cur_topic['up_id']) : $this->functions->colourise_group($cur_topic['poster'], AURA_GUEST),
					'moved_to' => $cur_topic['moved_to'],
					'subject' => $cur_topic['subject'],
					'sticky' => $cur_topic['sticky'],
					'closed' => $cur_topic['closed'],
					'archived' => $cur_topic['archived'],
					'question' => $cur_topic['question'],
					'topic_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['topic'], array($cur_topic['id'], $url_subject)),
					'num_pages' => $num_pages_topic,
					'pagination' => $this->registry->get('\pagination')->paginate($num_pages_topic, -1, $this->rewrite->url['topic_paginate'], array($cur_topic['id'], $url_subject)),
					'new' => (!$this->user['is_guest'] && $cur_topic['last_post'] > $this->user['last_visit'] && (!isset($tracked_topics['topics'][$cur_topic['id']]) || $tracked_topics['topics'][$cur_topic['id']] < $cur_topic['last_post']) && (!isset($tracked_topics['forums'][$id]) || $tracked_topics['forums'][$id] < $cur_topic['last_post']) && is_null($cur_topic['moved_to'])) ? '1' : '0',
				);

				if (is_null($cur_topic['moved_to']))
				{
					$topics[$cur_topic['id']]['last_post_avatar'] = $this->registry->get('\avatar')->generate($cur_topic['uid'], $cur_topic['email'], $cur_topic['use_gravatar'], array(32, 32));
					$topics[$cur_topic['id']]['last_post_link'] = $this->registry->get('\links')->aura_link($this->rewrite->url['post'], array($cur_topic['last_post_id']));
					$topics[$cur_topic['id']]['last_post'] = $this->registry->get('\aura_time')->format($cur_topic['last_post']);
					$topics[$cur_topic['id']]['last_poster'] = ($cur_topic['uid'] > 1) ? $this->functions->colourise_group($cur_topic['last_poster'], $cur_topic['group_id'], $cur_topic['uid']) : $this->functions->colourise_group($cur_topic['last_poster'], AURA_GUEST);
					$topics[$cur_topic['id']]['num_replies'] = $this->functions->forum_number_format($cur_topic['num_replies']);

					if ($this->config['o_topic_views'] == '1')
						$topics[$cur_topic['id']]['num_views'] = $this->functions->forum_number_format($cur_topic['num_views']);
				}
				else
					$topics[$cur_topic['id']]['topic_link'] = $this->registry->get('\links')->aura_link($this->rewrite->url['topic'], array($cur_topic['moved_to'], $url_subject));

				if ($topics[$cur_topic['id']]['new'] == '1')
					$topics[$cur_topic['id']]['new_link'] = $this->registry->get('\links')->aura_link($this->rewrite->url['topic_new_posts'], array($cur_topic['id'], $url_subject));

				$topics = $this->registry->get('\extensions\hooks')->fire('viewforum.topics', $topics);
			}
		}

		return $topics;
	}
}