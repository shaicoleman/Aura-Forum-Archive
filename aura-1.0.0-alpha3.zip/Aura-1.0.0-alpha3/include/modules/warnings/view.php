<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class view_controller extends base_controller
{
	/**
	 * Main app entry point, we view the warning
	 */
	public function execute()
	{
		$this->registry->get('\extensions\hooks')->fire('warnings.view.immediate');

		if ($this->config['o_warnings'] == '0')
			$this->registry->get('\handlers\message')->show($this->lang->t('Warning system disabled'));

		// Load the warnings/post language files
		$this->lang->load('warnings');
		$this->lang->load('post');

		$user_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
		if ($user_id < 1)
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'));

		// Standard users can only view their own warnings if they have permission
		if ($this->user['is_guest'] || (!$this->user['is_admmod'] && $this->user['id'] != $user_id) || (!$this->user['is_admmod'] && $this->config['o_warning_status'] == '2'))
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'));

		// Fetch some details about the warning that we're viewing
		list($username, $url_username, $points_active, $num_active, $expired_warnings, $active_warnings, $points_expired) = $this->fetch_details($user_id);

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Warning system')),
			'active_page' => 'index',
		);

		$this->template->footer = array(
			'footer_style' => 'warnings',
		);

		$this->template->header = $this->registry->get('\extensions\hooks')->fire('warnings.view.header', $this->template->header);
		$this->template->footer = $this->registry->get('\extensions\hooks')->fire('warnings.view.footer', $this->template->footer);

		$args = $this->registry->get('\extensions\hooks')->fire('warnings.view.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('view_warning.tpl');
		$this->template->output($tpl,
			array_merge(
				array(
					'profile_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['profile'], array($user_id, $url_username)),
					'username' => $username,
					'warning_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['warning_view'], array($user_id)),
					'points_active' => $points_active,
					'num_active' => $num_active,
					'expired_warnings' => $expired_warnings,
					'active_warnings' => $active_warnings,
					'points_expired' => $points_expired,
				),
				$args
			)
		);
	}

	protected function fetch_details($user_id)
	{
		$data = array(
			':id' => $user_id,
		);

		$ps = $this->db->select('users', 'username', $data, 'id=:id');
		$username = $ps->fetchColumn();

		$url_username = \url\url::replace($username);
		$data = array(
			':id' => $user_id,
			':time' => CURRENT_TIMESTAMP,
		);

		$ps = $this->db->select('warnings', 'COUNT(id)', $data, 'user_id=:id AND (date_expire>:time OR date_expire=0)');
		$num_active = $ps->fetchColumn();

		$ps = $this->db->select('warnings', 'COUNT(id)', $data, 'user_id=:id AND date_expire<=:time OR date_expire!=0');
		$num_expired = $ps->fetchColumn();

		$ps = $this->db->select('warnings', 'SUM(points)', $data, 'user_id=:id AND (date_expire>:time OR date_expire=0)');
		$points_active = $ps->fetchColumn();

		$ps = $this->db->select('warnings', 'SUM(points)', $data, 'user_id=:id AND date_expire<=:time AND date_expire!=0');
		$points_expired = $ps->fetchColumn();

		$active_warnings = array();
		$join = array(
			array(
				'type' => 'LEFT',
				'table' => 'warning_types',
				'as' => 't',
				'on' => 't.id=w.type_id',
			),
			array(
				'type' => 'LEFT',
				'table' => 'users',
				'as' => 'u',
				'on' => 'u.id=w.issued_by',
			),
		);

		$ps = $this->db->join('warnings', 'w', $join, 'w.id, w.type_id, w.post_id, w.title AS custom_title, w.points, w.date_issued, w.date_expire, w.issued_by, t.title, u.username AS issued_by_username, u.group_id AS issuer_gid', $data, 'w.user_id=:id AND (w.date_expire>:time OR w.date_expire=0)', 'w.date_issued DESC');
		foreach ($ps as $cur_warning)
		{
			if ($cur_warning['custom_title'] != '')
				$warning_title = $this->lang->t('Custom warning', $cur_warning['custom_title']);
			else if ($cur_warning['title'] != '')
				$warning_title = $cur_warning['title'];
			else
				$warning_title = ''; // This warning type has been deleted

			$active_warnings[] = array(
				'title' => $warning_title,
				'issued' => $this->registry->get('\aura_time')->format($cur_warning['date_issued']),
				'points' => $cur_warning['points'],
				'expires' => ($cur_warning['date_expire'] == '0') ? $this->lang->t('Never') : $this->registry->get('\aura_time')->format($cur_warning['date_expire']),
				'issuer' => ($cur_warning['issued_by_username'] != '') ? $this->functions->colourise_group($cur_warning['issued_by_username'], $cur_warning['issuer_gid'], $cur_warning['issued_by']) : '',
				'details_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['warning_details'], array($cur_warning['id'])),
			);

			$active_warnings = $this->registry->get('\extensions\hooks')->fire('warnings.view.render', $active_warnings);
		}

		$expired_warnings = array();
		$join = array(
			array(
				'type' => 'LEFT',
				'table' => 'warning_types',
				'as' => 't',
				'on' => 't.id=w.type_id',
			),
			array(
				'type' => 'LEFT',
				'table' => 'users',
				'as' => 'u',
				'on' => 'u.id=w.issued_by',
			),
		);

		$ps = $this->db->join('warnings', 'w', $join, 'w.id, w.type_id, w.post_id, w.title AS custom_title, w.points, w.date_issued, w.date_expire, w.issued_by, t.title, u.username AS issued_by_username, u.group_id AS issuer_gid', $data, 'w.user_id=:id AND w.date_expire<=:time AND w.date_expire!=0');
		foreach ($ps as $cur_warning)
		{
			// Determine warning type
			if ($cur_warning['custom_title'] != '')
				$warning_title = $this->lang->t('Custom warning', $cur_warning['custom_title']);
			else if ($cur_warning['title'] != '')
				$warning_title = $cur_warning['title'];
			else
				$warning_title = ''; // This warning type has been deleted

			$expired_warnings[] = array(
				'title' => $warning_title,
				'issued' => $this->registry->get('\aura_time')->format($cur_warning['date_issued']),
				'points' => $cur_warning['points'],
				'expired' => $this->registry->get('\aura_time')->format($cur_warning['date_expire']),
				'issuer' => ($cur_warning['issued_by_username'] != '') ? $this->functions->colourise_group($cur_warning['issued_by_username'], $cur_warning['issuer_gid'], $cur_warning['issued_by']) : '',
				'details_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['warning_details'], array($cur_warning['id'])),
			);

			$expired_warnings = $this->registry->get('\extensions\hooks')->fire('warnings.view.render', $expired_warnings);
		}

		return array($username, $url_username, $points_active, $num_active, $expired_warnings, $active_warnings, $points_expired);
	}
}