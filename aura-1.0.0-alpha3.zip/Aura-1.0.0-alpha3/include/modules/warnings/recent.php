<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class recent_controller extends base_controller
{
	/**
	 * Main app entry point, display all recent warnings
	 */
	public function execute()
	{
		$this->registry->get('\extensions\hooks')->fire('warnings.recent.immediate');

		if ($this->config['o_warnings'] == '0')
			$this->registry->get('\handlers\message')->show($this->lang->t('Warning system disabled'));

		// Load the warnings/post language files
		$this->lang->load('warnings');
		$this->lang->load('post');

		if (!$this->user['is_admmod'])
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'));

		// Fetch warnings count
		$ps = $this->db->select('warnings', 'COUNT(id)');
		$num_warnings = $ps->fetchColumn();

		// Determine the user offset (based on $_GET['p'])
		$num_pages = ceil($num_warnings / 50);

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Warning system')),
			'active_page' => 'index',
			'p' => (!isset($_GET['p']) || !is_numeric($_GET['p']) || $_GET['p'] <= 1 || $_GET['p'] > $num_pages) ? 1 : $_GET['p'],
		);

		$this->template->footer = array(
			'footer_style' => 'warnings',
		);

		$start_from = 50 * ($this->template->header['p'] - 1);

		$warnings = $this->fetch_warnings($start_from);

		$this->template->header = $this->registry->get('\extensions\hooks')->fire('warnings.recent.header', $this->template->header);
		$this->template->footer = $this->registry->get('\extensions\hooks')->fire('warnings.recent.footer', $this->template->footer);

		$args = $this->registry->get('\extensions\hooks')->fire('warnings.recent.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('recent_warnings.tpl');
		$this->template->output($tpl,
			array_merge(
				array(
					'warnings' => $warnings,
					'num_pages' => $num_pages,
					'pagination' => $this->registry->get('\pagination')->paginate($num_pages, $p, $this->rewrite->url['warnings_recent']),
				),
				$args
			)
		);
	}

	/**
	 * We want to fetch all of the recent warnings
	 */
	protected function fetch_warnings($start_from)
	{
		$data = array(
			':start' => $start_from,
		);

		$join = array(
			array(
				'type' => 'LEFT',
				'table' => 'warning_types',
				'as' => 't',
				'on' => 't.id=w.type_id',
			),
			array(
				'type' => 'LEFT',
				'table' => 'users',
				'as' => 'u',
				'on' => 'u.id=w.issued_by',
			),
			array(
				'type' => 'LEFT',
				'table' => 'users',
				'as' => 'v',
				'on' => 'v.id=w.user_id',
			),
		);

		$warnings = array();
		$ps = $this->db->join('warnings', 'w', $join, 'w.id, w.user_id, w.type_id, w.post_id, w.title AS custom_title, w.points, w.date_issued, w.date_expire, w.issued_by, t.title, u.username AS issued_by_username, u.group_id AS issuer_gid, v.username AS username, v.group_id AS user_gid', $data, '', 'w.date_issued DESC LIMIT :start, 50');
		foreach ($ps as $active_warnings)
		{
			if ($active_warnings['custom_title'] != '')
				$warning_title = $this->lang->t('Custom warning', $active_warnings['custom_title']);
			else if ($active_warnings['title'] != '')
				$warning_title = $active_warnings['title'];
			else
				$warning_title = '';
				
			$warnings[] = array(
				'title' => $warning_title,
				'issued' => $this->registry->get('\aura_time')->format($active_warnings['date_issued']),
				'points' => $active_warnings['points'],
				'username' => ($active_warnings['username'] != '') ? $this->functions->colourise_group($active_warnings['username'], $active_warnings['user_gid'], $active_warnings['user_id']) : '',
				'issuer' => ($active_warnings['issued_by_username'] != '') ? $this->functions->colourise_group($active_warnings['issued_by_username'], $active_warnings['issuer_gid'], $active_warnings['issued_by']) : '',
				'details_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['warning_details'], array($active_warnings['id'])),
			);

			$warnings = $this->registry->get('\extensions\hooks')->fire('warnings.recent.warnings', $warnings);
		}

		return $warnings;
	}
}