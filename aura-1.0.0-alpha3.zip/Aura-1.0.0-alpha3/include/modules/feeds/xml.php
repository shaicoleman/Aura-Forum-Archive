<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class xml_controller extends base_controller
{
	/**
	 * App entry point, run the controller and output the XML feed
	 */
	public function execute()
	{
		$this->registry->get('\extensions\hooks')->fire('feed.immediate');

		$generator = new feed($this->registry);
		$feed = $generator->generate_feed();

		// Send XML/no cache headers
		header('Content-Type: application/xml; charset=utf-8');
		header('Expires: '.gmdate('D, d M Y H:i:s').' GMT');
		header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
		header('Pragma: public');

		echo '<?xml version="1.0" encoding="utf-8"?>'."\n";
		echo '<source>'."\n";
		echo "\t".'<url>'.aura_htmlspecialchars($feed['link']).'</url>'."\n";

		$forum_tag = ($feed['type'] == 'posts') ? 'post' : 'topic';

		foreach ($feed['items'] as $item)
		{
			echo "\t".'<'.$forum_tag.' id="'.$item['id'].'">'."\n";

			echo "\t\t".'<title><![CDATA['.$generator->escape_cdata($item['title']).']]></title>'."\n";
			echo "\t\t".'<link>'.aura_htmlspecialchars($item['link']).'</link>'."\n";
			echo "\t\t".'<content><![CDATA['.$generator->escape_cdata($item['description']).']]></content>'."\n";
			echo "\t\t".'<author>'."\n";
			echo "\t\t\t".'<name><![CDATA['.$generator->escape_cdata($item['author']['name']).']]></name>'."\n";

			if (isset($item['author']['email']))
				echo "\t\t\t".'<email><![CDATA['.$generator->escape_cdata($item['author']['email']).']]></email>'."\n";

			if (isset($item['author']['uri']))
				echo "\t\t\t".'<uri>'.aura_htmlspecialchars($item['author']['uri']).'</uri>'."\n";

			echo "\t\t".'</author>'."\n";
			echo "\t\t".'<posted>'.gmdate('r', $item['pubdate']).'</posted>'."\n";

			echo "\t".'</'.$forum_tag.'>'."\n";

			$this->registry->get('\extensions\hooks')->fire('feed.xml.output');
		}

		echo '</source>'."\n";
	}
}