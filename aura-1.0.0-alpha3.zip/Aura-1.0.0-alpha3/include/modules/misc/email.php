<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class email_controller extends base_controller
{
	/*
	 * Main entry point- load the form
	 */
	public function execute()
	{
		$this->registry->get('\extensions\hooks')->fire('email.immediate');

		$this->lang->load('misc');
		if ($this->user['is_guest'] || $this->user['g_send_email'] == '0')
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		$recipient_id = isset($_GET['id']) ? intval($_GET['id']) : 1;
		if ($recipient_id < 2)
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		$data = array(
			':id' => $recipient_id,
		);

		$ps = $this->db->select('users', 'username, email, email_setting', $data, 'id=:id');
		if (!$ps->rowCount())
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		list($recipient, $recipient_email, $email_setting) = $ps->fetch(PDO::FETCH_NUM);

		if ($email_setting == 2 && !$this->user['is_admmod'])
			$this->registry->get('\handlers\message')->show($this->lang->t('Form email disabled'));

		$this->registry->get('\extensions\hooks')->fire('email.authorised');

		$errors = $this->send_email();

		// Try to determine if the data in HTTP_REFERER is valid (if not, we redirect to the user's profile after the email is sent)
		if (!empty($_SERVER['HTTP_REFERER']))
			$redirect_url = $this->registry->get('\auth\login')->validate_redirect($_SERVER['HTTP_REFERER'], null);

		if (!isset($redirect_url))
			$redirect_url = $this->registry->get('\links')->aura_link($this->rewrite->url['profile'], array($recipient_id));
		else if (preg_match('%index\.php\?app=forums&act=viewtopic&pid=(\d+)$%', $redirect_url, $matches))
			$redirect_url .= '#p'.$matches[1];

		$redirect_url = $this->registry->get('\extensions\hooks')->fire('email.redirecturl', $redirect_url);
		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Send email to', $recipient)),
			'required_fields' => array('req_subject' => $this->lang->t('Email subject'), 'req_message' => $this->lang->t('Email message')),
			'focus_element' => array('email', 'req_subject'),
			'active_page' => 'index',
		);

		$this->template->header = $this->registry->get('\extensions\hooks')->fire('email.header', $this->template->header);
		$args = $this->registry->get('\extensions\hooks')->fire('email.header');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('send_email.tpl');
		$this->template->output($tpl,
			array_merge(
				array(
					'recipient' => $recipient,
					'form_action' => $this->registry->get('\links')->aura_link($this->rewrite->url['email'], array($recipient_id)),
					'csrf_token' => $this->registry->get('\auth\csrf')->generate('send_email'),
					'redirect_url' => $redirect_url,
					'errors' => $errors,
					'subject' => isset($subject) ? $subject : '',
					'message' => isset($message) ? $message : ''
				),
				$args
			)
		);
	}

	/*
	 * Attempts to send the email
	 */
	protected function send_email()
	{
		$errors = array();
		if (isset($_POST['form_sent']))
		{
			$this->registry->get('\auth\csrf')->confirm('send_email');

			// Clean up message and subject from POST
			$subject = isset($_POST['req_subject']) ? utf8_trim($_POST['req_subject']) : '';
			$message = isset($_POST['req_message']) ? utf8_trim($_POST['req_message']) : '';

			if ($subject == '')
				$errors[] = $this->lang->t('No email subject');
			else if ($message == '')
				$errors[] = $this->lang->t('No email message');
			// Here we use strlen() not aura_strlen() as we want to limit the post to AURA_MAX_POSTSIZE bytes, not characters
			else if (strlen($message) > AURA_MAX_POSTSIZE)
				$errors[] = $this->lang->t('Too long email message');

			if ($this->user['last_email_sent'] != '' && (CURRENT_TIMESTAMP - $this->user['last_email_sent']) < $this->user['g_email_flood'] && (CURRENT_TIMESTAMP - $this->user['last_email_sent']) >= 0)
				$errors[] = $this->lang->t('Email flood', $this->user['g_email_flood'], $this->user['g_email_flood'] - (CURRENT_TIMESTAMP - $this->user['last_email_sent']));

			$errors = $this->registry->get('\extensions\hooks')->fire('email.errors', $errors);
			if (empty($errors))
			{
				$email = new \email\email($this->registry);
				$info = array(
					'subject' => array(
						'<mail_subject>' => $subject,
					),
					'message' => array(
						'<sender>' => $this->user['username'],
						'<board_title>' => $this->config['o_board_title'],
						'<mail_message>' => $message,
					)
				);

				$mail_tpl = $this->registry->get('\email\parser')->parse_email('form_email', $this->user['language'], $info);
				$email->send($recipient_email, $mail_tpl['subject'], $mail_tpl['message'], $this->user['email'], $this->user['username']);

				$update = array(
					'last_email_sent' => CURRENT_TIMESTAMP,
				);

				$data = array(
					':id' => $this->user['id'],
				);

				$this->db->update('users', $update, 'id=:id', $data);

				// Try to determine if the data in redirect_url is valid (if not, we redirect to index.php after the email is sent)
				$redirect_url = $this->registry->get('\auth\login')->validate_redirect($_POST['redirect_url'], $this->registry->get('\links')->aura_link($this->rewrite->url['index']));

				$this->registry->get('\extensions\hooks')->fire('email.beforeredirect');
				$this->registry->get('\handlers\redirect')->show($redirect_url, $this->lang->t('Email sent redirect'));
			}
		}

		return $errors;
	}
}