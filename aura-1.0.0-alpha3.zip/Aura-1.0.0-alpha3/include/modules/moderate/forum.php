<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class forum_controller extends base_controller
{
	/**
	 * Min app entry point, we check for the actions and display the forum if none
	 */
	public function execute()
	{
		$this->registry->get('\extensions\hooks')->fire('moderate.forum.immediate');

		$moderate = new moderate($this->registry);
		list($fid, , ,) = $moderate->check_user();

		// Move one or more topics
		if (isset($_GET['move_topics']) || isset($_POST['move_topics']) || isset($_POST['move_topics_to']))
		{
			if (isset($_POST['move_topics_to']))
				$this->move_topics_to();

			$this->move_topics();
		}
		// Merge two or more topics
		else if (isset($_POST['merge_topics']) || isset($_POST['merge_topics_comply']))
		{
			if (isset($_POST['merge_topics_comply']))
				$this->merge_topics_comply($fid);

			$this->merge_topics($fid);
		}
		// Archive/unarchive multiple topics (admins only)
		else if (isset($_POST['archive_topics']) || isset($_POST['unarchive_topics']))
			$this->archive_topics($fid);
		// Delete one or more topics
		else if (isset($_POST['delete_topics']) || isset($_POST['delete_topics_comply']))
			$this->delete_topics($fid);

		$this->registry->get('\extensions\hooks')->fire('moderate.forum.actions');

		$this->show_forum($fid);
	}

	/**
	 * Display the forum and moderator controls
	 */
	protected function show_forum($fid)
	{
		$this->registry->get('\extensions\hooks')->fire('moderate.forum.showforum.immediate');

		// Load the forum language file
		$this->lang->load('forum');

		// Fetch some info about the forum
		$join = array(
			array(
				'type' => 'LEFT',
				'table' => 'forum_perms',
				'as' => 'fp',
				'on' => '(fp.forum_id=f.id AND fp.group_id=:gid)',
			),
		);

		$data = array(
			':gid' => $this->user['g_id'],
			':fid' => $fid,
		);

		$ps = $this->db->join('forums', 'f', $join, 'f.forum_name, f.redirect_url, f.num_topics, f.sort_by', $data, '(fp.read_forum IS NULL OR fp.read_forum=1) AND f.id=:fid');
		if (!$ps->rowCount())
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		$cur_forum = $ps->fetch();

		$cur_forum = $this->registry->get('\extensions\hooks')->fire('moderate.forum.showforum.forum', $cur_forum);

		// Is this a redirect forum? In that case, abort!
		if ($cur_forum['redirect_url'] != '')
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		switch ($cur_forum['sort_by'])
		{
			case 0:
				$sort_by = 'last_post DESC';
				break;
			case 1:
				$sort_by = 'posted DESC';
				break;
			case 2:
				$sort_by = 'subject ASC';
				break;
			default:
				$sort_by = 'last_post DESC';
				break;
		}

		// Determine the topic offset (based on $_GET['p'])
		$num_pages = ceil($cur_forum['num_topics'] / $this->user['disp_topics']);

		$this->template->header = array(
			'p' => (!isset($_GET['p']) || $_GET['p'] <= 1 || $_GET['p'] > $num_pages) ? 1 : intval($_GET['p']),
			'page_title' => array($this->config['o_board_title'], $cur_forum['forum_name']),
			'active_page' => 'index',
		);

		$start_from = $this->user['disp_topics'] * ($this->template->header['p'] - 1);
		$tracked_topics = $this->registry->get('\cookie\tracked')->get_tracked_topics();

		$this->template->header = $this->registry->get('\extensions\hooks')->fire('moderate.forum.showforum.header', $this->template->header);

		// Retrieve a list of topic IDs, LIMIT is (really) expensive so we only fetch the IDs here then later fetch the remaining data
		$data = array(
			':id' => $fid,
			':start' => $start_from,
			':limit' => $this->user['disp_topics'],
		);

		// If there are topics in this forum
		$topics = array();
		$ps = $this->db->select('topics', 'id', $data, 'forum_id=:id AND deleted=0 AND approved=1', 'sticky DESC, '.$sort_by.', id DESC LIMIT :start, :limit');
		if ($ps->rowCount())
		{
			$topic_ids = array();
			$ps->setFetchMode(PDO::FETCH_COLUMN, 0);
			foreach ($ps as $cur_topic_id)
			{
				$topic_ids[] = $cur_topic_id;
				$markers[] = '?';
			}

			// Select topics
			$join = array(
				array(
					'type' => 'LEFT',
					'table' => 'users',
					'as' => 'u',
					'on' => '(t.last_poster=u.username)',
				),
				array(
					'type' => 'LEFT',
					'table' => 'users',
					'as' => 'up',
					'on' => '(t.poster=up.username)',
				),
			);

			$topic_count = 0;
			$ps = $this->db->join('topics', 't', $join, 'u.id AS uid, u.group_id, up.id AS up_id, up.group_id AS up_group_id, u.use_gravatar, u.email, t.id, t.poster, t.subject, t.question, t.posted, t.last_post, t.last_post_id, t.last_poster, t.num_views, t.num_replies, t.closed, t.sticky, t.moved_to', $topic_ids, 't.id IN ('.implode(',', $markers).')', 't.sticky DESC, t.'.$sort_by.', t.id DESC');
			foreach ($ps as $cur_topic)
			{
				$url_subject = \url\url::replace($cur_topic['subject']); // Preg match is slow!

				if ($this->config['o_censoring'] == '1')
					$cur_topic['subject'] = $this->registry->get('\message\bbcode')->censor_words($cur_topic['subject']);

				$ghost_topic = (!is_null($cur_topic['moved_to'])) ? true : false;
				$num_pages_topic = ceil(($cur_topic['num_replies'] + 1) / $this->user['disp_posts']);
				$topics[$cur_topic['id']] = array(
					'count' => ++$topic_count,
					'topic_count' => $this->functions->forum_number_format($topic_count + $start_from),
					'cur_topic' => $cur_topic,
					'topic_poster' => ($cur_topic['up_id'] > 1) ? $this->functions->colourise_group($cur_topic['poster'], $cur_topic['up_group_id'], $cur_topic['up_id']) : $this->functions->colourise_group($cur_topic['poster'], AURA_GUEST),
					'moved_to' => $cur_topic['moved_to'],
					'subject' => $cur_topic['subject'],
					'sticky' => $cur_topic['sticky'],
					'closed' => $cur_topic['closed'],
					'topic_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['topic'], array($cur_topic['id'], $url_subject)),
					'num_pages' => $num_pages_topic,
					'pagination' => $this->registry->get('\pagination')->paginate($num_pages_topic, -1, $this->rewrite->url['topic_paginate'], array($cur_topic['id'], $url_subject)),
					'new' => (!$ghost_topic && $cur_topic['last_post'] > $this->user['last_visit'] && (!isset($tracked_topics['topics'][$cur_topic['id']]) || $tracked_topics['topics'][$cur_topic['id']] < $cur_topic['last_post']) && (!isset($tracked_topics['forums'][$fid]) || $tracked_topics['forums'][$fid] < $cur_topic['last_post'])) ? '1' : '0',
				);

				if (is_null($cur_topic['moved_to']))
				{
					$topics[$cur_topic['id']]['last_post_avatar'] = $this->registry->get('\avatar')->generate($cur_topic['uid'], $cur_topic['email'], $cur_topic['use_gravatar'], array(32, 32));
					$topics[$cur_topic['id']]['last_post_link'] = $this->registry->get('\links')->aura_link($this->rewrite->url['post'], array($cur_topic['last_post_id']));
					$topics[$cur_topic['id']]['last_post'] = $this->registry->get('\aura_time')->format($cur_topic['last_post']);
					$topics[$cur_topic['id']]['last_poster'] = ($cur_topic['uid'] > 1) ? $this->functions->colourise_group($cur_topic['last_poster'], $cur_topic['group_id'], $cur_topic['uid']) : $this->functions->colourise_group($cur_topic['last_poster'], AURA_GUEST);
					$topics[$cur_topic['id']]['num_replies'] = $this->functions->forum_number_format($cur_topic['num_replies']);

					if ($this->config['o_topic_views'] == '1')
						$topics[$cur_topic['id']]['num_views'] = $this->functions->forum_number_format($cur_topic['num_views']);
				}
				else
					$topics[$cur_topic['id']]['topic_link'] = $this->registry->get('\links')->aura_link($this->rewrite->url['topic'], array($cur_topic['moved_to'], $url_subject));

				if ($topics[$cur_topic['id']]['new'] == '1')
					$topics[$cur_topic['id']]['new_link'] = $this->registry->get('\links')->aura_link($this->rewrite->url['topic_new_posts'], array($cur_topic['id'], $url_subject));

				$topics = $this->registry->get('\extensions\hooks')->fire('moderate.forum.showforum.topics', $topics);
			}
		}

		$args = $this->registry->get('\extensions\hooks')->fire('moderate.forum.showforum.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('moderate_forum.tpl');
		$this->template->output($tpl,
			array_merge(
				array(
					'index_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['index']),
					'forum_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['moderate_forum'], array($fid, \url\url::replace($cur_forum['forum_name']))),
					'pagination' => $this->registry->get('\pagination')->paginate($num_pages, $this->template->header['p'], $this->rewrite->url['moderate_forum_p'], array($fid)),
					'forum' => $cur_forum,
					'form_action' => $this->registry->get('\links')->aura_link($this->rewrite->url['moderate_forum'], array($fid)),
					'csrf_token' => $this->registry->get('\auth\csrf')->generate('moderate'),
					'aura_user' => $this->user,
					'topics' => $topics,
				),
				$args,
			)
		);		
	}

	/**
	 * Delete some topics from the forum
	 */
	protected function delete_topics($fid)
	{
		$topics = ((isset($_POST['topics']) && is_array($_POST['topics'])) ? array_map('intval', $_POST['topics']) : (isset($_POST['topics']) ? array_map('intval', explode(',', $_POST['topics'])) : array()));

		if (empty($topics))
			$this->registry->get('\handlers\message')->show($this->lang->t('No topics selected'));

		if (isset($_POST['delete_topics_comply']))
			$this->delete_topics_comply($fid, $topics);

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Moderate')),
			'active_page' => 'index',
		);

		$this->template->header = $this->registry->get('\extensions\hooks')->fire('moderate.forum.delete.header', $this->template->header);
		$args = $this->registry->get('\extensions\hooks')->fire('moderate.forum.delete.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('delete_topics.tpl');
		$this->template->output($tpl,
			array_merge(
				array(
					'form_action' => $this->registry->get('\links')->aura_link($this->rewrite->url['moderate_forum'], array($fid)),
					'csrf_token' => $this->registry->get('\auth\csrf')->generate('delete_topics'),
					'topics' => implode(',', array_map('intval', array_keys($topics))),
				),
				$args
			)
		);
	}

	/**
	 * Delete some topics properly on the forum
	 */
	protected function delete_topics_comply($fid, $topics)
	{
		$this->registry->get('\extensions\hooks')->fire('moderate.forum.deletecomply.immediate');

		$this->registry->get('\auth\csrf')->confirm('delete_topics');
		$idx = new \search\idx($this->registry);

		$data = array($fid);
		$markers = array();
		for ($i = 0; $i < count($topics); $i++)
		{
			$data[] = $topics[$i];
			$markers[] = '?';
		}

		// Verify that the topic IDs are valid
		$markers = implode(',', $markers);
		$ps = $this->db->select('topics', 1, $data, 'forum_id=? AND id IN('.$markers.')');

		if ($ps->rowCount() != count($topics))
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		unset($data[0]);

		// Verify that the posts are not by admins
		if (!$this->user['is_admin'] && $this->user['g_mod_edit_admin_posts'] == '0')
		{
			$admins = $this->cache->get('admins');
			for ($i = 0; $i < count($admins); $i++)
			{
				$markers_2[] = '?';
				$data_2[] = $admins[$i];
			}

			$select = array_merge($data_2, $data);
			$ps = $this->db->select('posts', 1, array_values($select), 'topic_id IN('.$markers.') AND poster_id IN('.implode(',', $markers_2).')');
			if ($ps->rowCount())
				$this->registry->get('\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');
		}

		foreach (array_values($data) as $tid)
			$this->registry->get('\topics\attachment')->attach_delete_thread($tid);

		// Delete the topics and any redirect topics
		$delete = array_merge($data, $data);
		if ($this->config['o_delete_full'] == '1')
			$this->db->delete('topics', 'id IN('.$markers.') OR moved_to IN('.$markers.')', array_values($delete));
		else
			$this->db->run('UPDATE '.$this->db->prefix.'topics SET deleted=1 WHERE id IN('.$markers.') OR moved_to IN('.$markers.')', array_values($delete));

		// Delete any subscriptions
		$this->db->delete('topic_subscriptions', 'topic_id IN('.$markers.')', array_values($data));

		// Create a list of the post IDs in this topic and then strip the search index
		$ps = $this->db->select('posts', 'id', array_values($data), 'topic_id IN('.$markers.')');

		$post_ids = array();
		foreach ($ps as $row)
			$post_ids[] = $row['id'];

		// We have to check that we actually have a list of post IDs since we could be deleting just a redirect topic
		if (!empty($post_ids))
			$idx->strip_search_index($post_ids);

		// Delete any posts, polls, .etc
		$this->db->delete('posts', 'topic_id IN('.$markers.')', array_values($data));
		$this->db->delete('polls', 'topic_id IN('.$markers.')', array_values($data));

		$this->registry->get('\forum\forum')->update($fid);
		$data = array(
			':id'	=>	$fid,
		);
			
		$ps = $this->db->select('forums', 'forum_name', $data, 'id=:id');
		$forum_name = \url\url::replace($ps->fetchColumn());

		$this->registry->get('\extensions\hooks')->fire('moderate.forum.deletecomply.beforeredirect');
		$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['forum'], array($fid, $forum_name)), $this->lang->t('Delete topics redirect'));
	}

	/**
	 * Archive some topics
	 */
	protected function archive_topics($fid)
	{
		$this->registry->get('\extensions\hooks')->fire('moderate.forum.archive.immediate');

		if (!$this->user['is_admin'])
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'));

		$this->registry->get('\auth\csrf')->confirm('moderate.php');

		$topics = ((isset($_POST['topics']) && is_array($_POST['topics'])) ? array_map('intval', array_keys($_POST['topics'])) : array());
		if (empty($topics))
			$this->registry->get('\handlers\message')->show($this->lang->t('No topics selected'));

		$action = (isset($_POST['archive_topics'])) ? 1 : 2;

		$data = array($action, $fid);
		$markers = array();
		for ($i = 0; $i < count($topics); $i++)
		{
			$data[] = $topics[$i];
			$markers[] = '?';
		}

		$this->db->run('UPDATE '.$this->db->prefix.'topics SET archived=? WHERE forum_id=? AND approved=1 AND deleted=0 AND id IN ('.implode(',', $markers).')', $data);

		$data = array(
			':id'	=>	$fid,
		);

		$ps = $this->db->select('forums', 'forum_name', $data, 'id=:id');
		$forum_name = \url\url::replace($ps->fetchColumn());

		if ($action)
		{
			$redirect_lang = $this->lang->t('Archive topics redirect');
			$this->registry->get('\extensions\hooks')->fire('moderate.forum.archive');
		}
		else
		{
			$redirect_lang = $this->lang->t('Unarchive topics redirect');
			$this->registry->get('\extensions\hooks')->fire('moderate.forum.unarchive');
		}

		$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['forum'], array($fid, \url\url::replace($forum_name))), $redirect_lang);		
	}

	/**
	 * Merge some topics
	 */
	protected function merge_topics($fid)
	{
		$topics = isset($_POST['topics']) && is_array($_POST['topics']) ? $_POST['topics'] : array();
		if (count($topics) < 2)
			$this->registry->get('\handlers\message')->show($this->lang->t('Not enough topics selected'));

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Moderate')),
			'active_page' => 'index',
		);

		$this->template->header = $this->registry->get('\extensions\hooks')->fire('moderate.forum.merge.header', $this->template->header);
		$args = $this->registry->get('\extensions\hooks')->fire('moderate.forum.merge.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('merge_topics.tpl');
		$this->template->output($tpl,
			array_merge(
				array(
					'form_action' => $this->registry->get('\links')->aura_link($this->rewrite->url['moderate_forum'], array($fid)),
					'csrf_token' => $this->registry->get('\auth\csrf')->generate('merge_topics'),
					'topics' => implode(',', array_map('intval', array_keys($topics))),
				),
				$args,
			)
		);
	}

	/**
	 * Move the topics within the forum
	 */
	protected function move_topics()
	{
		if (isset($_POST['move_topics']))
		{
			$topics = isset($_POST['topics']) ? $_POST['topics'] : array();
			if (empty($topics))
				$this->registry->get('\handlers\message')->show($this->lang->t('No topics selected'));

			$topics = implode(',', array_map('intval', array_keys($topics)));
			$action = 'multi';
		}
		else
		{
			$topics = isset($_GET['move_topics']) ? intval($_GET['move_topics']) : 0;
			if ($topics < 1)
				$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

			$action = 'single';
		}

		list($categories, $forums) = $this->fetch_forums();

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Moderate')),
			'active_page' => 'index',
		);

		$this->template->header = $this->registry->get('\extensions\hooks')->fire('moderate.forum.move.header', $this->template->header);
		$args = $this->registry->get('\extensions\hooks')->fire('moderate.forum.move.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('move_topics.tpl');
		$this->template->output($tpl,
			array_merge(
				array(
					'action' => $action,
					'form_action' => $this->registry->get('\links')->aura_link($this->rewrite->url['moderate_forum'], array($fid)),
					'csrf_token' => $this->registry->get('\auth\csrf')->generate('move_topics'),
					'topics' => $topics,
					'forums' => $forums,
					'categories' => $categories,
				),
				$args
			)
		);
	}

	/**
	 * Merge the topics
	 */
	protected function merge_topics_comply($fid)
	{
		$this->registry->get('\extensions\hooks')->fire('moderate.forum.mergecomply.immediate');

		$this->registry->get('\auth\csrf')->confirm('merge_topics');

		if (@preg_match('%[^0-9,]%', $_POST['topics']))
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		$topics = explode(',', $_POST['topics']);
		if (count($topics) < 2)
			$this->registry->get('\handlers\message')->show($this->lang->t('Not enough topics selected'));
				
		$data = array($fid);
		for ($i = 0; $i < count($topics); $i++)
		{
			$markers[] = '?';
			$data[] = $topics[$i];
		}

		// Verify that the topic IDs are valid (redirect links will point to the merged topic after the merge)
		$ps = $this->db->select('topics', 'id', $data, 'forum_id=? AND id IN ('.implode(',', $markers).')', 'id ASC');
		if ($ps->rowCount() != count($topics))
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		// The topic that we are merging into is the one with the smallest ID
		$merge_to_tid = $ps->fetchColumn();

		$data[0] = $merge_to_tid;
		// Make any redirect topics point to our new, merged topic
		$sql = 'UPDATE '.$this->db->prefix.'topics SET moved_to=? WHERE moved_to IN('.implode(',', $markers).')';

		// Should we create redirect topics?
		if (isset($_POST['with_redirect']))
		{
			$new_data = $data;
			$new_data[count($data)+1] = $data[0];	// Do whatever it takes to avoid a second loop =)
			unset($new_data[0]);

			$sql .= ' OR (id IN('.implode(',', $markers).') AND id !=?)';
		}
		else
			$new_data = array();

		$update = array_merge($new_data, $data);
		$this->db->run($sql, $update);

		$update = $data;

		// Merge the posts into the topic
		$this->db->run('UPDATE '.$this->db->prefix.'posts SET topic_id=? WHERE topic_id IN('.implode(',', $markers).')', $update);

		// Update any subscriptions
		unset($update[0]);
		$ps = $this->db->select('topic_subscriptions', 'DISTINCT user_id', array_values($update), 'topic_id IN('.implode(',', $markers).')');
		$ps->setFetchMode(PDO::FETCH_COLUMN, 0);
		foreach ($ps as $cur_user_id)
		{
			$insert = array(
				'topic_id' => $merge_to_tid,
				'user_id' => $cur_user_id,
			);
		
			$this->db->insert('topic_subscriptions', $insert);
		}

		$this->db->delete('topic_subscriptions', 'topic_id IN('.implode(',', $markers).')', array_values($update));

		// Without redirection the old topics are removed
		if (!isset($_POST['with_redirect']))
		{
			$update[] = $merge_to_tid;
			$this->db->delete('topics', 'id IN('.implode(',', $markers).') AND id !=?', array_values($update));
			$this->db->delete('polls', 'topic_id IN('.implode(',', $markers).') AND id !=?', array_values($update));
		}

		// Count number of replies in the topic
		$data = array(
			':id' => $merge_to_tid,
		);

		$ps = $this->db->select('posts', 'COUNT(id)', $data, 'topic_id=:id');
		$num_replies = $ps->fetchColumn() - 1;
	
		$data = array(
			':id' => $fid,
		);

		$ps = $this->db->select('forums', 'forum_name', $data, 'id=:id');
		if (!$ps->rowCount())
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'));
		else
			$forum_name = \url\url::replace($ps->fetchColumn());

		// Get last_post, last_post_id and last_poster
		$data = array(
			':id' => $merge_to_tid,
		);

		$ps = $this->db->select('posts', 'posted, id, poster', $data, 'topic_id=:id', 'id DESC LIMIT 1');
		list($last_post, $last_post_id, $last_poster) = $ps->fetch(PDO::FETCH_NUM);

		// Update topic
		$update = array(
			'num_replies' => $num_replies,
			'last_post' => $last_post,
			'last_post_id' => $last_post_id,
			'last_poster' => $last_poster,
		);
		
		$data = array(
			':id' => $merge_to_tid,
		);

		$this->db->update('topics', $update, 'id=:id', $data);
		// Update the forum FROM which the topic was moved and redirect
		$this->registry->get('\forum\forum')->update($fid);

		$this->registry->get('\extensions\hooks')->fire('moderate.forum.mergecomply.beforeredirect');
		$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['forum'], array($fid, $forum_name)), $this->lang->t('Merge topics redirect'));
	}

	/**
	 * Fetch the categories and forums which are shown in the form
	 */
	protected function fetch_forums()
	{
		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'forums',
				'as' => 'f',
				'on' => 'c.id=f.cat_id',
			),
			array(
				'type' => 'LEFT',
				'table' => 'forum_perms',
				'as' => 'fp',
				'on' => '(fp.forum_id=f.id AND fp.group_id=:gid)',
			),
		);

		$data = array(
			':gid' => $this->user['g_id'],
		);

		$ps = $this->db->join('categories', 'c', $join, 'c.id AS cid, c.cat_name, f.id AS fid, f.forum_name', $data, '(fp.post_topics IS NULL OR fp.post_topics=1) AND f.redirect_url IS NULL', 'c.disp_position, c.id, f.disp_position');
		if ($ps->rowCount() < 2)
			$this->registry->get('\handlers\message')->show($this->lang->t('Nowhere to move'));
			
		$cur_category = 0;
		$categories = $forums = array();
		foreach ($ps as $cur_forum)
		{
			if (!isset($categories[$cur_forum['cid']]))
			{
				$categories[$cur_forum['cid']] = array(
					'name' => $cur_forum['cat_name'],
					'id' => $cur_forum['cid'],
				);

				$categories = $this->registry->get('\extensions\hooks')->fire('moderate.forum.categories', $categories);
			}

			$forums[] = array(
				'category_id' => $cur_forum['cid'],
				'id' => $cur_forum['fid'],
				'name' => $cur_forum['forum_name'],
			);

			$forums = $this->registry->get('\extensions\hooks')->fire('moderate.forum.forums', $forums);
		}

		return array($categories, $forums);
	}

	/**
	 * Move topics to a forum
	 */
	protected function move_topics_to()
	{
		$this->registry->get('\extensions\hooks')->fire('moderate.forum.move.immediate');

		$this->registry->get('\auth\csrf')->confirm('move_topics');

		if (@preg_match('%[^0-9,]%', $_POST['topics']))
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		$topics = explode(',', $_POST['topics']);
		$move_to_forum = isset($_POST['move_to_forum']) ? intval($_POST['move_to_forum']) : 0;
		if (empty($topics) || $move_to_forum < 1)
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		$data = array($fid);
		for ($i = 0; $i < count($topics); $i++)
		{
			$markers[] = '?';
			$data[] = $topics[$i];
		}

		// Verify that the topic IDs are valid
		$ps = $this->db->select('topics', 1, $data, 'forum_id=? AND id IN ('.implode(',',$markers).')');

		if (!$ps->rowCount())
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		// Verify that the move to forum ID is valid
		$join = array(
			array(
				'type' => 'LEFT',
				'table' => 'forum_perms',
				'as' => 'fp',
				'on' => '(fp.group_id=:gid AND fp.forum_id=:fid)',
			),
		);

		$select = array(
			':gid' => $this->user['g_id'],
			':fid' => $move_to_forum,
			':fid2' => $move_to_forum,
		);

		$ps = $this->db->join('forums', 'f', $join, 'f.forum_name', $select, 'f.redirect_url IS NULL AND f.id=:fid2 AND (fp.post_topics IS NULL OR fp.post_topics=1)');
		if (!$ps->rowCount())
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');
		else
			$forum_name = \url\url::replace($ps->fetchColumn());

		$data[0] = $move_to_forum;

		// Delete any redirect topics if there are any (only if we moved/copied the topic back to where it was once moved from)
		$this->db->delete('topics', 'forum_id=? AND moved_to IN('.implode(',',$markers).')', $data);

		// Move the topic(s)
		$this->db->run('UPDATE '.$this->db->prefix.'topics SET forum_id=? WHERE id IN('.implode(',',$markers).')', $data);

		// Should we create redirect topics?
		if (isset($_POST['with_redirect']))
		{
			foreach ($topics as $cur_topic)
			{
				$data = array(
					':id' => $cur_topic,
				);

				// Fetch info for the redirect topic
				$ps = $this->db->select('topics', 'poster, subject, posted, last_post', $data, 'id=:id');
				$moved_to = $ps->fetch();

				// Create the redirect topic
				$insert = array(
					'poster' => $moved_to['poster'],
					'subject' => $moved_to['subject'],
					'posted' => $moved_to['posted'],
					'last_post' => $moved_to['last_post'],
					'moved_to' => $cur_topic,
					'forum_id' => $fid,
				);

				$this->db->insert('topics', $insert);

				$this->registry->get('\extensions\hooks')->fire('moderate.forum.move.redirecttopic');
			}
		}

		$this->registry->get('\forum\forum')->update($fid); // Update the forum FROM which the topic was moved
		$this->registry->get('\forum\forum')->update($move_to_forum); // Update the forum TO which the topic was moved

		$redirect_msg = (count($topics) > 1) ? $this->lang->t('Move topics redirect') : $this->lang->t('Move topic redirect');
		$this->registry->get('\extensions\hooks')->fire('moderate.forum.move.beforeredirect');
		$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['forum'], array($move_to_forum, $forum_name)), $redirect_msg);
	}
}