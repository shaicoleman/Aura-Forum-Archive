<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class index_controller extends base_controller
{
	public function execute()
	{
		$this->registry->get('\extensions\hooks')->fire('moderate.index.immediate');

		$moderate = new moderate($this->registry);
		list($fid, , ,) = $moderate->check_user();

		if (isset($_GET['open']) || isset($_POST['open']) || isset($_GET['close']) || isset($_POST['close']))
		{
			$action = (isset($_GET['open']) || isset($_POST['open'])) ? 0 : 1;

			// There could be an array of topic IDs in $_POST
			if (isset($_POST['open']) || isset($_POST['close']))
			{
				$this->registry->get('\auth\csrf')->confirm('moderate');

				$topics = isset($_POST['topics']) && is_array($_POST['topics']) ? array_map('intval', array_keys($_POST['topics'])) : array();
				if (empty($topics))
					$this->registry->get('\handlers\message')->show($this->lang->t('No topics selected'));
				
				$data = array(
					':id'	=>	$fid,
				);
				
				$ps = $this->db->select('forums', 'forum_name', $data, 'id=:id');
				if (!$ps->rowCount())
					$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'));
				else
					$forum_name = \url\url::replace($ps->fetchColumn());
				
				$data = array($action, $fid);
				for ($i = 0; $i < count($topics); $i++)
				{
					$markers[] = '?';
					$data[] = $topics[$i];
				}

				$this->db->run('UPDATE '.$this->db->prefix.'topics SET closed=? WHERE forum_id=? AND id IN('.implode(',', $markers).')', $data);

				if ($action)
				{
					$this->registry->get('\extensions\hooks')->fire('moderate.index.closetopic');
					$redirect_msg = $this->lang->t('Close topics redirect');
				}
				else
				{
					$this->registry->get('\extensions\hooks')->fire('moderate.index.opentopic');
					$redirect_msg = $this->lang->t('Open topics redirect');
				}

				$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['moderate_forum'], array($fid, $forum_name)), $redirect_msg);
			}
			else // Or just one in $_GET
			{
				$this->registry->get('\auth\csrf')->confirm('viewtopic');

				$topic_id = ($action) ? intval($_GET['close']) : intval($_GET['open']);
				if ($topic_id < 1)
					$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

				$data = array(
					':id' => $topic_id,
				);

				$ps = $this->db->select('topics', 'subject', $data, 'id=:id');
				if (!$ps->rowCount())
					$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'));
				else
					$subject = \url\url::replace($ps->fetchColumn());
				
				$update = array(
					'closed' => $action,
				);

				$data = array(
					':id' => $topic_id,
					':fid' => $fid,
				);
				
				$this->db->update('topics', $update, 'id=:id AND forum_id=:fid', $data);

				if ($action)
				{
					$this->registry->get('\extensions\hooks')->fire('moderate.index.closetopic');
					$redirect_msg = $this->lang->t('Close topic redirect');
				}
				else
				{
					$this->registry->get('\extensions\hooks')->fire('moderate.index.opentopic');
					$redirect_msg = $this->lang->t('Open topic redirect');
				}

				$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['topic'], array($topic_id, $subject)), $redirect_msg);
			}
		}
		// Stick or Unstick a topic
		else if (isset($_GET['stick']) || isset($_GET['unstick']))
		{
			$this->registry->get('\auth\csrf')->confirm('viewtopic');
			$action = (isset($_GET['unstick'])) ? 0 : 1;
			$topic_id = ($action) ? intval($_GET['stick']) : intval($_GET['unstick']);

			if ($topic_id < 1)
				$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

			$data = array(
				':id'	=>	$topic_id,
			);

			$ps = $this->db->select('topics', 'subject', $data, 'id=:id');
			if (!$ps->rowCount())
				$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'));
			else
				$subject = \url\url::replace($ps->fetchColumn());
			
			$data = array(
				':id'	=>	$topic_id,
				':fid'	=>	$fid,
			);

			$update = array(
				'sticky'	=>	$action,
			);
				
			$this->db->update('topics', $update, 'id=:id AND forum_id=:fid', $data);

			if ($action)
			{
				$this->registry->get('\extensions\hooks')->fire('moderate.index.sticktopic');
				$redirect_msg = $this->lang->t('Stick topics redirect');
			}
			else
			{
				$this->registry->get('\extensions\hooks')->fire('moderate.index.unsticktopic');
				$redirect_msg = $this->lang->t('Unstick topics redirect');
			}
	
			$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['topic'], array($topic_id, $subject)), $redirect_msg);
		}
		else if (isset($_GET['unarchive']) || isset($_GET['archive']))
		{
			$this->registry->get('\auth\csrf')->confirm('viewtopic');
			$action = (isset($_GET['unarchive'])) ? 2 : 1;
			$topic_id = ($action == '1') ? intval($_GET['archive']) : intval($_GET['unarchive']);

			if ($topic_id < 1)
				$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

			$data = array(
				':id' => $topic_id,
			);

			$ps = $this->db->select('topics', 'subject', $data, 'id=:id');
			if (!$ps->rowCount())
				$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'));
			else
				$subject = \url\url::replace($ps->fetchColumn());

			$data = array(
				':id' => $topic_id,
				':fid' => $fid,
			);

			$update = array(
				'archived' => $action,
			);

			$this->db->update('topics', $update, 'id=:id AND forum_id=:fid', $data);

			if ($action)
			{
				$redirect_msg = $this->lang->t('Archived topic redirect');
				$this->registry->get('\extensions\hooks')->fire('moderate.index.archivetopic');
			}
			else
			{
				$redirect_msg = $this->lang->t('Unarchived topic redirect');
				$this->registry->get('\extensions\hooks')->fire('moderate.index.unarchivetopic');
			}

			$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['topic'], array($topic_id, $subject)), $redirect_msg);
		}

		$this->registry->get('\extensions\hooks')->fire('moderate.index.topicactions');
	}

	public function multi_moderate()
	{
		$this->registry->get('\extensions\hooks')->fire('moderate.multimoderate.immediate');

		$moderate = new moderate($this->registry);
		list($fid, , ,) = $moderate->check_user();

		$tid = isset($_GET['id']) ? intval($_GET['id']) : '0';
		$action = isset($_POST['action']) ? intval($_POST['action']) : 0;

		if ($tid < 1)
			$this->registry->get('\handlers\message')->show($this->lang->t('No topics selected'));

		if (isset($_POST['multi_moderate_comply']))
		{
			$this->registry->get('\auth\csrf')->confirm('multi_moderate');

			$idx = new \search\idx($this->registry);
			$data = array(
				':id' => $tid,
			);

			$ps = $this->db->select('topics', 1, $data, 'id=:id AND approved=1 AND deleted=0');
			if (!$ps->rowCount())
				$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'));

			//So, what rules are we applying here?
			$data = array(
				':id' => $action
			);

			$ps = $this->db->select('multi_moderation', 'close, stick, move, archive, leave_redirect, reply_message, add_start, add_end, send_email, increment_posts, report_posts', $data, 'id=:id');
			if (!$ps->rowCount())
				$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'));
			else
				$moderation = $ps->fetch();

			$moderation = $this->registry->get('\extensions\hooks')->fire('moderate.multimoderate.moderate', $moderation);
			$replace = array('[user]'.$this->user['username'].'[/user]', $this->registry->get('\topics\title')->get_title($this->user), strip_tags($this->config['o_board_title']), strip_tags($this->config['o_board_desc']), '[email]'.$this->config['o_admin_email'].'[/email]', '[email]'.$this->config['o_webmaster_email'].'[/email]', '[email]'.$this->user['email'].'[/email]', $this->user['num_posts'], '[url]'.$this->user['url'].'[/url]', $this->user['realname']);
			$search = array('{username}', '{user_title}', '{board_title}', '{board_desc}', '{admin_email}', '{webmaster_email}', '{user_email}', '{user_posts}', '{website}', '{location}', '{real_name}');

			$data = $update = array();
			$moderation['reply_message'] = str_replace($search, $replace, $moderation['reply_message']);

			if ($moderation['close'] != '2')
				$update['closed'] = $moderation['close'];

			if ($moderation['stick'] != '2')
				$update['sticky'] = $moderation['stick'];
				
			if ($moderation['archive'] != '2')
				$update['archived'] = $moderation['archive'];

			if ($moderation['reply_message'] != '')
			{
				$insert = array(
					'poster' => $this->user['username'],
					'poster_id' => $this->user['id'],
					'poster_ip' => get_remote_address(),
					'message' => $moderation['reply_message'],
					'hide_smilies' => 0,
					'posted' => CURRENT_TIMESTAMP,
					'topic_id' => $tid,
				);

				$this->db->insert('posts', $insert);
				$new_pid = $this->db->lastInsertId($this->db->prefix.'posts');

				$idx->update_search_index('post', $new_pid, $moderation['reply_message']);
			}

			if ($moderation['move'] != '0')
			{
				$update['forum_id'] = $moderation['move'];
				if ($moderation['leave_redirect'] == '1')
				{						
					// Fetch info for the redirect topic
					$data = array(
						':id' => $tid,
					);

					$ps = $this->db->select('topics', 'poster, subject, posted, last_post, forum_id', $data, 'id=:id');
					$moved_to = $ps->fetch();

					// Create the redirect topic
					$insert = array(
						'poster' =>	$moved_to['poster'],
						'subject' => $moderation['add_start'].$moved_to['subject'].$moderation['add_end'],
						'posted' =>	$moved_to['posted'],
						'last_post' => $moved_to['last_post'],
						'moved_to' => $tid,
						'forum_id' => $moved_to['forum_id'],
					);

					$this->db->insert('topics', $insert);
				}
			}

			// We may (not) need some of this, but we might as well get it all in one query regardless
			$join = array(
				array(
					'type' => 'INNER',
					'table' => 'topics',
					'as' => 't',
					'on' => 't.first_post_id=p.id',
				),
				array(
					'type' => 'LEFT',
					'table' => 'users',
					'as' => 'u',
					'on' => 'p.poster_id=u.id',
				),
			);

			$data = array(
				':id' => $tid,
			);

			$ps = $this->db->join('posts', 'p', $join, 't.subject, p.message, p.poster_email, p.poster_id, p.poster_ip, u.username AS poster, u.email, u.id AS uid, u.language', $data, 't.id=:id LIMIT 1');
			$topic = $ps->fetch();

			$email = ((!is_null($topic['poster_email'])) ? $topic['poster_email'] : $topic['email']);
						
			if ($moderation['add_start'] != '' || $moderation['add_end'] != '')
			{
				$update['subject'] = $moderation['add_start'].$topic['subject'].$moderation['add_end'];	
				$idx->update_search_index('edit', $tid, $topic['message'], $moderation['add_start'].$topic['subject'].$moderation['add_end']);
			}

			if ($this->config['o_sfs_api'] != '' && $moderation['report_posts'] == '1')
				$this->registry->get('\stopforumspam')->report($this->config['o_sfs_api'], $topic['poster_ip'], $email, $topic['poster'], $topic['message']);

			if (!empty($update))
			{
				$data = array(
					':id'	=>	$tid,
				);

				$this->db->update('topics', $update, 'id=:id', $data);
			}
			
			$data = array(
				':id'	=>	$tid,
			);

			$ps = $this->db->select('posts', 'COUNT(id)', $data, 'topic_id=:id AND approved=1 AND deleted=0');
			$num_replies = $ps->fetchColumn() -1;
		
			// Get last_post, last_post_id and last_poster
			$data = array(
				':id'	=>	$tid,
			);

			$ps = $this->db->select('posts', 'posted, id, poster, poster_id', $data, 'topic_id=:id AND approved=1 AND deleted=0', 'id DESC LIMIT 1');
			$last_topic = $ps->fetch();
		
			// Update topic
			$update = array(
				'num_replies' => $num_replies,
				'last_post' => $last_topic['posted'],
				'last_post_id' => $last_topic['id'],
				'last_poster' => $last_topic['poster'],
			);

			$data = array(
				':id'	=>	$tid,
			);
			
			$this->db->update('topics', $update, 'id=:id', $data);
			$this->registry->get('\forum\forum')->update($fid);

			if ($moderation['move'] !== '0')
				$this->registry->get('\forum\forum')->update($moderation['move']);
			
			if ($moderation['increment_posts'] == '1')
			{
				$data = array(
					':time' => CURRENT_TIMESTAMP,
					':id' => $this->user['id'],
				);

				$this->db->run('UPDATE '.$this->db->prefix.'users SET num_posts=num_posts+1, last_post=:time WHERE id=:id', $data);

				// Promote this user to a new group if enabled
				if ($this->user['g_promote_next_group'] != 0 && $this->user['num_posts'] + 1 >= $this->user['g_promote_min_posts'])
				{
					$update = array(
						'group_id' => $this->user['g_promote_next_group'],
					);
					
					$data = array(
						':id' => $this->user['id'],
					);
					
					$this->db->update('users', $update, 'id=:id', $data);
				}
			}

			if ($moderation['send_email'] == '1' && $moderation['reply_message'] != '' && $this->user['id'] != $topic['poster_id'])
			{
				$mail = new \email\email($this->config);
				$info = array(
					'subject' => array(
						'<topic_subject>' => $topic['subject'],
					),
					'message' => array(
						'<topic_subject>' => $topic['subject'],
						'<replier>' => $this->user['username'],
						'<message>' => $moderation['reply_message'],
						'<post_url>' => $this->registry->get('\links')->aura_link($this->rewrite->url['post'], array($new_pid)),
					)
				);

				$mail_tpl = $this->registry->get('\email\parser')->parse_email('new_action', $this->user['language'], $info);
				$mail->send($email, $mail_tpl['subject'], $mail_tpl['message']);
			}

			$this->registry->get('\extensions\hooks')->fire('moderate.multimoderate.beforeredirect');
			$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['topic'], array($tid, url_friendly($topic['subject']))), $this->lang->t('multi_mod redirect'));
		}
		
		$ps = $this->db->select('multi_moderation', 'title, id');
		if (!$ps->rowCount())
			$this->registry->get('\handlers\message')->show($this->lang->t('No multi moderation'));
		else
		{
			$actions = array();
			foreach ($ps as $action)
			{
				$actions[] = array('title' => $action['title'], 'id' => $action['id']);
				$actions = $this->registry->get('\extensions\hooks')->fire('moderate.multimoderate.actions', $actions);
			}
		}

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Moderate')),
			'active_page' => 'index',
		);

		$this->template->header = $this->registry->get('\extensions\hooks')->fire('moderate.multimoderate.header', $this->template->header);
		$args = $this->registry->get('\extensions\hooks')->fire('moderate.multimoderate.render');
		$args = (is_array($args) ? $args : array());

		$csrf_token = $this->registry->get('\auth\csrf')->generate('multi_moderate');
		$tpl = $this->template->load('multi_moderate.tpl');
		$this->template->output(
			array_merge(
				array(
					'actions' => $actions,
					'csrf_token' => $csrf_token,
					'form_action' => $this->registry->get('\links')->aura_link($this->rewrite->url['moderate_multi'], array($fid, $tid, $csrf_token)),
				),
				$args
			)
		);
	}

	public function unapprove()
	{
		$this->registry->get('\extensions\hooks')->fire('moderate.unappprove.immediate');
		$moderate = new moderate($this->registry);
		list($fid, , ,) = $moderate->check_user();

		// Why on earth do I do these things? =)
		$pid = ((isset($_POST['id'])) ? intval($_POST['id']) : (isset($_GET['id']) ? intval($_GET['id']) : 0));

		if ($pid < 1)
			$this->registry->get('\handlers\message')->show($this->lang->t('No topics selected'));

		if (isset($_POST['unapprove_comply']))
		{
			$this->registry->get('\auth\csrf')->confirm('unapprove_post');

			$idx = new \search\idx($this->registry);

			//Is this a topic post?
			$data = array(
				':id' => $pid,
				':fid' => $fid,
			);

			$join = array(
				array(
					'type' => 'INNER',
					'table' => 'topics',
					'as' => 't',
					'on' => 'p.topic_id=t.id',
				),
				array(
					'type' => 'INNER',
					'table' => 'forums',
					'as' => 'f',
					'on' => 't.forum_id=f.id',
				),
			);

			$ps = $this->db->join('posts', 'p', $join, 't.id AS tid, t.subject, t.first_post_id, t.num_replies, f.id AS fid, f.forum_name', $data, 'p.id=:id AND f.id=:fid');
			if (!$ps->rowCount())
				$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'));
			else
				$cur_post = $ps->fetch();

			$is_topic_post = ($pid == $cur_post['first_post_id']) ? true : false;
			if ($is_topic_post)
			{
				$update = array(
					'approved' => 0,
				);
				
				$data = array(
					':id' => $cur_post['tid'],
				);
				
				$this->db->update('posts', $update, 'topic_id=:id', $data);
				$this->db->update('topics', $update, 'id=:id', $data); // Make sure the topic isn't displayed in the forum without any posts!

				$posts = array();
				$ps = $this->db->select('posts', 'id', $data, 'topic_id=:id');
				foreach ($ps as $cur_row)
					$posts[] = $cur_row['id'];

				// Make sure we have a list of post IDs
				if (!empty($posts))
					$idx->strip_search_index($posts);
				
				$this->registry->get('\forum\forum')->update($cur_post['fid']);
				$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['forum'], array($cur_post['fid'], \url\url::replace($cur_post['forum_name']))), $this->lang->t('Unapproved topic redirect'));
			}
			else
			{
				$update = array(
					'approved' => 0,
				);
				
				$data = array(
					':id' => $pid,
				);
				
				$this->db->update('posts', $update, 'id=:id', $data);
				$idx->strip_search_index(array($pid));
				
				$data = array(
					':id' => $cur_post['tid'],
				);
			
				// Update the topic
				$ps = $this->db->select('posts', 'posted, id, poster', $data, 'topic_id=:id AND approved=1 AND deleted=0', 'id DESC LIMIT 1');
				$topic = $ps->fetch();
		
				$update = array(
					'num_replies'	=>	($cur_post['num_replies']-1),
					'last_post'	=>	$topic['posted'],
					'last_post_id'	=>	$topic['id'],
					'last_poster'	=>	$topic['poster'],
				);

				$this->db->update('topics', $update, 'id=:id', $data);

				$this->registry->get('\forum\forum')->update($cur_post['fid']);

				$this->registry->get('\extensions\hooks')->fire('moderate.unapprove.beforeredirect');
				$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['topic'], array($cur_post['tid'], \url\url::replace($cur_post['subject']))), $this->lang->t('Unapproved post redirect'));
			}		
		}

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Moderate')),
			'active_page' => 'index',
		);

		$this->template->header = $this->registry->get('\extensions\hooks')->fire('moderate.unapprove.header', $this->template->header);
		$args = $this->registry->get('\extensions\hooks')->fire('moderate.unapprove.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('unapprove_post.tpl');
		$this->template->output($tpl,
			array(
				'form_action' => $this->registry->get('\links')->aura_link($this->rewrite->url['unapprove'], array($fid, $pid, $this->registry->get('\auth\csrf')->generate('unapprove_post'))),
			)
		);
	}
}