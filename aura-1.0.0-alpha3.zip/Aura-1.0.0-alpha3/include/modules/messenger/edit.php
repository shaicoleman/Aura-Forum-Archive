<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class edit_controller extends base_controller
{
	public function execute()
	{
		$this->registry->get('\extensions\hooks')->fire('messenger.edit.immediate');

		$this->configure_pms();

		$pid = isset($_GET['pid']) ? intval($_GET['pid']) : 0;
		if ($pid < 1)
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'));

		$cur_topic = $this->fetch_topic($pid);
		
		$can_edit_subject = $pid == $cur_topic['first_post_id'] && ($this->user['g_edit_pm_subject'] == '1' || $this->user['is_admin'] || $this->user['g_global_moderator'] == '1');

		$errors = array();
		if (isset($_POST['form_sent']))
			list($message, $username, $errors) = $this->edit_post($cur_topic, $can_edit_subject, $pid);
		else
			$username = $this->fetch_usernames($cur_topic);

		// Tell header we should use the editor
		$this->template->header = array(
			'posting' => true,
			'page_title' => array($this->config['o_board_title'], $this->lang->t('PM'), $this->lang->t('Edit message')),
			'required_fields' => array('req_subject' => $this->lang->t('Subject'), 'req_message' => $this->lang->t('Message')),
			'focus_element' => array('edit', 'req_message'),
			'active_page' => 'pm',
		);

		$this->template->header = $this->registry->get('\extensions\hooks')->fire('messenger.edit.header', $this->template->header);
		$checkboxes = array();
		if ($this->config['o_smilies'] == '1')
			$checkboxes[] = array('name' => 'hide_smilies', 'title' => $this->lang->t('Hide smilies'), 'checked' => ((isset($_POST['hide_smilies']) || $cur_topic['hide_smilies'] == '1') ? true : false));

		if ($this->user['is_admmod'])
			$checkboxes[] = array('name' => 'silent', 'checked' => (((isset($_POST['form_sent']) && isset($_POST['silent'])) || !isset($_POST['form_sent'])) ? true : false), 'title' => $this->lang->t('Silent edit'));

		$checkboxes = $this->registry->get('\extensions\hooks')->fire('messenger.edit.checkboxes', $checkboxes);
		$args = $this->registry->get('\extensions\hooks')->fire('messenger.edit.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('edit_message.tpl');
		$this->template->output($tpl,
			array_merge(
				array(
					'errors' => $errors,
					'pm_menu' => $this->registry->get('\messenger\menu')->generate('send'),
					'inbox_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['inbox']),
					'index_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['index']),
					'post_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['pms_post'], array($pid)),
					'cur_topic' => $cur_topic,
					'form_action' => $this->registry->get('\links')->aura_link($this->rewrite->url['pms_edit'], array($pid)),
					'csrf_token' => $this->registry->get('\auth\csrf')->generate('pms_edit'),
					'message' => isset($_POST['req_message']) ? $message : $cur_topic['message'],
					'subject' => isset($_POST['req_subject']) ? $_POST['req_subject'] : $cur_topic['subject'],
					'can_edit_subject' => $can_edit_subject,
					'username' => $username,
					'checkboxes' => $checkboxes,
					'quickpost_links' => array(
						'bbcode' => $this->registry->get('\links')->aura_link($this->rewrite->url['help'], array('bbcode')),
						'url' => $this->registry->get('\links')->aura_link($this->rewrite->url['help'], array('url')),
						'img' => $this->registry->get('\links')->aura_link($this->rewrite->url['help'], array('img')),
						'smilies' => $this->registry->get('\links')->aura_link($this->rewrite->url['help'], array('smilies')),
					),
				),
				$args
			)
		);
	}

	/**
	 * Fetch the topic information
	 */
	protected function fetch_topic($pid)
	{
		$data = array(
			':id' => $pid,
			':uid' => $this->user['id']
		);

		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'conversations',
				'as' => 'c',
				'on' => 'm.topic_id=c.id',
			),
			array(
				'type' => 'INNER',
				'table' => 'pms_data',
				'as' => 'cd',
				'on' => 'c.id=cd.topic_id',
			),
		);

		$ps = $this->db->join('messages', 'm', $join, 'c.subject, c.first_post_id, c.id, c.num_replies+1 AS num_replies, cd.folder_id, m.message, m.hide_smilies, m.poster_id', $data, 'm.id=:id AND cd.user_id=:uid AND cd.deleted=0');
		if (!$ps->rowCount())
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request')); // We've deleted it
		else
			$cur_topic = $ps->fetch();

		if (($this->user['g_edit_posts'] == '0' || $cur_topic['poster_id'] != $this->user['id']) && !$this->user['is_admmod'])
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'));

		if ($cur_topic['folder_id'] == 3) // Then we've archived it
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'));

		$cur_topic = $this->registry->get('\extensions\hooks')->fire('messenger.edit.topic', $cur_topic);
		return $cur_topic;
	}

	/**
	 * Configure and setup a few things before we start each action
	 */
	protected function configure_pms()
	{
		if ($this->user['g_read_board'] == '0')
			$this->registry->get('\handlers\message')->show($this->lang->t('No view'), false, '403 Forbidden');

		if ($this->user['is_guest'])
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'));

		if ($this->config['o_private_messaging'] == '0' || $this->user['g_use_pm'] == '0' || $this->user['pm_enabled'] == '0')
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'));

		$this->lang->load('pms');

		// Load the post language file
		$this->lang->load('post');

		$this->registry->get('\extensions\hooks')->fire('messenger.edit.configure');
	}

	/**
	 * Fetch a list of users in the conversation
	 */
	protected function fetch_usernames($cur_topic)
	{
		$data = array(
			':uid' => $this->user['id'],
			':tid' => $cur_topic['id'],
		);

		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'users',
				'as' => 'u',
				'on' => 'cd.user_id=u.id',
			),
			array(
				'type' => 'INNER',
				'table' => 'groups',
				'as' => 'g',
				'on' => 'u.group_id=g.g_id',
			),
		);

		$users = array();
		$ps = $this->db->join('pms_data', 'cd', $join, 'cd.user_id AS uid, u.username, u.email, u.pm_enabled, u.num_pms, u.pm_notify, g.g_use_pm, g.g_pm_limit, cd.deleted', $data, 'cd.user_id!=:uid AND cd.topic_id=:tid');
		foreach ($ps as $cur_user)
			$users[] = $cur_user['username'];

		$users = $this->registry->get('\extensions\hooks')->fire('messenger.edit.usernames', $users);
		return count($users) ? implode(', ', $users) : '';
	}

	protected function edit_post($cur_topic, $can_edit_subject, $pid)
	{
		$this->registry->get('\auth\csrf')->confirm('pms_edit');

		// If it's a topic it must contain a subject
		if ($can_edit_subject)
		{
			$data = array(
				':tid' => $cur_topic['id'],
				':uid' => $this->user['id'],
			);

			$join = array(
				array(
					'type' => 'INNER',
					'table' => 'users',
					'as' => 'u',
					'on' => 'cd.user_id=u.id',
				),
			);

			$conversation_users = $conversation_data = array();
			$ps = $this->db->join('pms_data', 'cd', $join, 'cd.user_id, cd.deleted, u.username', $data, 'cd.topic_id=:tid AND cd.user_id!=:uid');
			foreach ($ps as $user_data)
			{
				$conversation_users[utf8_strtolower($user_data['username'])] = $user_data['user_id'];
				$conversation_data[$user_data['user_id']] = $user_data['deleted'];
			}

			$conversation_data = $this->registry->get('\extensions\hooks')->fire('messenger.edit.conversationdata', $conversation_data);
			$conversation_users = $this->registry->get('\extensions\hooks')->fire('messenger.edit.conversationusers', $conversation_users);
			$subject = isset($_POST['req_subject']) ? utf8_trim($_POST['req_subject']) : '';
			$username = isset($_POST['req_username']) ? utf8_trim($_POST['req_username']) : '';

			if ($this->config['o_censoring'] == '1')
				$censored_subject = utf8_trim($this->registry->get('\message\bbcode')->censor_words($subject));

			if ($subject == '')
				$errors[] = $this->lang->t('No subject');
			else if ($this->config['o_censoring'] == '1' && $censored_subject == '')
				$errors[] = $this->lang->t('No subject after censoring');
			else if (aura_strlen($subject) > 70)
				$errors[] = $this->lang->t('Too long subject');
			else if ($this->config['p_subject_all_caps'] == '0' && is_all_uppercase($subject) && !$this->user['is_admmod'])
				$errors[] = $this->lang->t('All caps subject');

			$users = array_map('utf8_strtolower', array_map('utf8_trim', explode(',', $username)));

			if ((count($users) + 1) > $this->config['o_max_pm_receivers']) // Add one for us as we shouldn't be included
				$errors[] = $this->lang->t('Max receivers', $this->config['o_pm_max_receivers']);

			$removed_users = array_diff(array_keys($conversation_users), $users);
			if (!empty($removed_users))
			{
				foreach ($removed_users as $cur_user)
				{
					$uid = $conversation_users[utf8_strtolower($cur_user)];
					$data = array(
						':uid' => $uid,
						':tid' => $cur_topic['id'],
					);

					$this->db->delete('pms_data', 'user_id=:uid AND topic_id=:tid', $data);

					$data = array(
						':id' => $uid,
					);

					if ($conversation_data[$uid] == '1')
						continue; // If they've already deleted the message then the next part will knock their counter out

					$this->db->run('UPDATE '.$this->db->prefix.'users SET num_pms=num_pms-'.$cur_topic['num_replies'].' WHERE id=:id', $data);

					$this->registry->get('\extensions\hooks')->fire('messenger.edit.removedusers');
				}
			}

			$join = array(
				array(
					'type' => 'INNER',
					'table' => 'groups',
					'as' => 'g',
					'on' => 'u.group_id=g.g_id',
				),
			);

			$receivers = array();
			foreach ($users as $user)
			{
				if (!empty($errors))
					break;

				$data = array(
					':username' => $user,
				);

				$ps = $this->db->join('users', 'u', $join, 'u.id, u.username, u.email, u.pm_enabled, u.num_pms, u.pm_notify, g.g_use_pm, g.g_pm_limit', $data, 'u.username=:username AND u.id>1');
				if (!$ps->rowCount())
				{
					$errors[] = $this->lang->t('No user x', $user);
					continue;
				}
				else
					$cur_user = $ps->fetch();

				$cur_user = $this->registry->get('\extensions\hooks')->fire('messenger.edit.user', $cur_user);
				if (!in_array($cur_user['id'], $conversation_users))
				{
					// Check if they have the PM enabled
					if ($cur_user['pm_enabled'] == '0' || $cur_user['g_use_pm'] == '0')
						$errors[] = $this->lang->t('No PM access', $cur_user['username']);

					// Check if they've reached their max limit
					if ($cur_user['num_pms'] + $cur_topic['num_replies'] >= $cur_user['g_pm_limit'] && $cur_user['g_pm_limit'] != 0)
						$errors[] = $this->lang->t('Receiver inbox full', $cur_user['username']);

					if (!$this->user['is_admmod'])
					{
						$data = array(
							':uid' => $this->user['id'],
							':bid' => $cur_user['id'],
							':bid2' => $this->user['id'],
							':uid2' => $cur_user['id'],
						);

						$ps = $this->db->select('blocks', 1, $data, 'user_id=:uid AND block_id=:bid OR block_id=:bid2 AND user_id=:uid2');
						if ($ps->rowCount())
							$errors[] = $this->lang->t('User x has blocked', $cur_user['username']);
					}

					$receivers[$cur_user['id']] = $cur_user;
					$receivers = $this->registry->get('\extensions\hooks')->fire('messenger.edit.users.conversation', $receivers);
				}
			}
		}

		// Clean up message from POST
		$message = isset($_POST['req_message']) ? aura_linebreaks(utf8_trim($_POST['req_message'])) : '';

		// Here we use strlen() not aura_strlen() as we want to limit the post to AURA_MAX_POSTSIZE bytes, not characters
		if (strlen($message) > AURA_MAX_POSTSIZE)
			$errors[] = $this->lang->t('Too long message', forum_number_format(AURA_MAX_POSTSIZE));
		else if ($this->config['p_message_all_caps'] == '0' && is_all_uppercase($message) && !$this->user['is_admmod'])
			$errors[] = $this->lang->t('All caps message');

		// Validate BBCode syntax
		if ($this->config['p_message_bbcode'] == '1')
		{
			$parser = new \message\parser($this->registry);
			$message = $parser->preparse_bbcode($message, $errors);
		}

		if (empty($errors))
		{
			if ($message == '')
				$errors[] = $this->lang->t('No message');
			else if ($this->config['o_censoring'] == '1')
			{
				// Censor message to see if that causes problems
				$censored_message = utf8_trim(censor_words($message));

				if ($censored_message == '')
					$errors[] = $this->lang->t('No message after censoring');
			}
		}

		$hide_smilies = isset($_POST['hide_smilies']) ? '1' : '0';
			
		// Replace four-byte characters (MySQL cannot handle them)
		$message = strip_bad_multibyte_chars($message);
			
		$errors = $this->registry->get('\extensions\hooks')->fire('messenger.edit.errors', $errors);
		if (empty($errors))
		{
			if ($can_edit_subject)
			{
				$update = array(
					'subject' => $subject,
				);

				$data = array(
					':id' => $cur_topic['id'],
				);

				// Update the topic and any redirect topics
				$this->db->update('conversations', $update, 'id=:id', $data);

				$email = new \email\email($this->registry);
				foreach ($receivers as $uid => $udata)
				{
					$insert = array(
						'topic_id' => $cur_topic['id'],
						'user_id' => $uid,
					);

					$this->db->insert('pms_data', $insert);
					$data = array(
						':id' => $uid,
					);

					$this->db->run('UPDATE '.$this->db->prefix.'users SET num_pms=num_pms+'.$cur_topic['num_replies'].' WHERE id=:id', $data);
					if ($udata['pm_notify'] == '1')
					{
						$info = array(
							'message' => array(
								'<username>' => $udata['username'],
								'<replier>' => $this->user['username'],
								'<pm_title>' => $subject,
								'<message_url>' => $this->registry->get('\links')->aura_link($this->rewrite->url['pms_post'], array($pid)),
							)
						);

						$mail_tpl = $this->registry->get('\email\parser')->parse_email('pm_addition', $this->user['language'], $info);
						$email->send($udata['email'], $mail_tpl['subject'], $mail_tpl['message']);
					}

					$this->registry->get('\extensions\hooks')->fire('messenger.edit.subscriptions');
				}
			}

			$update = array(
				'message' => $message,
				'hide_smilies' => $hide_smilies,
			);
				
			if (!isset($_POST['silent']) || !$this->user['is_admmod'])
			{
				$update['edited'] = CURRENT_TIMESTAMP;
				$update['edited_by'] = $this->user['username'];
			}

			$data = array(
				':id' => $pid,
			);

			// Update the post
			$this->db->update('messages', $update, 'id=:id', $data);

			$this->registry->get('\extensions\hooks')->fire('messenger.edit.beforeredirect');
			$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['pms_post'], array($pid)), $this->lang->t('Edit redirect'));
		}

		return array($message, $username, $errors);
	}
}