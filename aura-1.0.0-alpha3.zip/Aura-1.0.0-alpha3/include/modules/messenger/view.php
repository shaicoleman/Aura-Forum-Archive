<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class view_controller extends base_controller
{
	/**
	 * Main app entry point, we want to view the topic
	 */
	public function execute()
	{
		$this->registry->get('\extensions\hooks')->fire('messenger.view.immediate');

		if ($this->user['g_read_board'] == '0')
			$this->registry->get('\handlers\message')->show($this->lang->t('No view'), false, '403 Forbidden');

		if ($this->user['is_guest'])
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'));

		if ($this->config['o_private_messaging'] == '0' || $this->user['g_use_pm'] == '0' || $this->user['pm_enabled'] == '0')
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'));

		$this->lang->load('pms');

		$tid = isset($_GET['tid']) ? intval($_GET['tid']) : 0;
		$pid = isset($_GET['pid']) ? intval($_GET['pid']) : 0;

		if ($tid < 1 && $pid < 1)
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		$this->registry->get('\extensions\hooks')->fire('messenger.view.authorised');

		if ($pid)
		{
			$data = array(
				':id'	=>	$pid,
			);

			$ps = $this->db->select('messages', 'topic_id, posted', $data, 'id=:id');
			if (!$ps->rowCount())
				$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

			list($tid, $posted) = $ps->fetch(PDO::FETCH_NUM);

			$data = array(
				':id' => $tid,
				':posted' => $posted,
			);

			// Determine on which page the post is located (depending on $this->user['disp_posts'])
			$ps = $this->db->select('messages', 'COUNT(id)', $data, 'topic_id=:id AND posted<:posted');
			$num_posts = $ps->fetchColumn() + 1;

			$_GET['p'] = ceil($num_posts / $this->user['disp_posts']);
		}

		$cur_topic = $this->fetch_topic($tid);

		// Determine the post offset (based on $_GET['p'])
		$num_pages = ceil(($cur_topic['num_replies'] + 1) / $this->user['disp_posts']);
		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('PM'), $cur_topic['subject']),
			'active_page' => 'pm',
			'p' => (!isset($_GET['p']) || $_GET['p'] <= 1 || $_GET['p'] > $num_pages) ? 1 : intval($_GET['p']),
			'posting' => true,
		);

		$start_from = $this->user['disp_posts'] * ($this->template->header['p'] - 1);

		$quickpost = false;
		if ($this->config['o_quickpost'] == '1' && $cur_topic['fid'] != '3')
		{
			$quickpost = true;
			$this->template->header['required_fields'] = array('req_message' => $this->lang->t('Message'));
		}

		$this->lang->load('topic');

		if ($this->config['o_censoring'] == '1')
			$cur_topic['subject'] = $this->registry->get('\message\bbcode')->censor_words($cur_topic['subject']);

		$this->template->header = $this->registry->get('\extensions\hooks')->fire('messenger.view.header', $this->template->header);
		$posts = $this->fetch_topic_posts($tid, $start_from, $cur_topic);

		$render = array(
			'index_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['index']),
			'inbox_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['inbox']),
			'cur_topic' => $cur_topic,
			'aura_user' => $this->user,
			'reply_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['pms_reply'], array($tid)),
			'pm_menu' => $this->registry->get('\messenger\menu')->generate($cur_topic['fid']),
			'pagination' => $this->registry->get('\pagination')->paginate($num_pages, $this->template->header['p'], $this->rewrite->url['pms_paginate'], array($tid)),
			'posts' => $posts,
			'quickpost' => $quickpost,
			'csrf_token' => $this->registry->get('\auth\csrf')->generate('pms_send'),
		);

		if ($quickpost)
		{
			$render['quickpost_links'] = array(
				'form_action' => $this->registry->get('\links')->aura_link($this->rewrite->url['pms_reply'], array($tid)),
				'bbcode' => $this->registry->get('\links')->aura_link($this->rewrite->url['help'], array('bbcode')),
				'url' => $this->registry->get('\links')->aura_link($this->rewrite->url['help'], array('url')),
				'img' => $this->registry->get('\links')->aura_link($this->rewrite->url['help'], array('img')),
				'smilies' => $this->registry->get('\links')->aura_link($this->rewrite->url['help'], array('smilies')),
			);
		}

		$render = $this->registry->get('\extensions\hooks')->fire('messenger.view.render', $render);

		$tpl = $this->template->load('pm_topic.tpl');
		$this->template->output($tpl, $render);
	}

	/**
	 * Fetches all the posts in the topic
	 */
	protected function fetch_topic_posts($tid, $start_from, $cur_topic)
	{
		$this->registry->get('\extensions\hooks')->fire('messenger.view.posts.immediate');

		$parser = new \message\parser($this->registry);

		$post_count = 0; // Keep track of post numbers
		$data = array(
			':tid'	=>	$tid,
			':start' => $start_from,
		);

		// Retrieve a list of post IDs, LIMIT is (really) expensive so we only fetch the IDs here then later fetch the remaining data
		$ps = $this->db->select('messages', 'id', $data, 'topic_id=:tid ORDER BY id LIMIT :start,'.$this->user['disp_posts']);

		$markers = $post_ids = array();
		$ps->setFetchMode(PDO::FETCH_COLUMN, 0);
		foreach ($ps as $cur_post_id)
		{
			$post_ids[] = $cur_post_id;
			$markers[] = '?';
		}

		$join = array(
			array(
				'type' => 'LEFT',
				'table' => 'users',
				'as' => 'u',
				'on' => 'u.id=p.poster_id',
			),
			array(
				'type' => 'LEFT',
				'table' => 'groups',
				'as' => 'g',
				'on' => 'g.g_id=u.group_id',
			),
			array(
				'type' => 'LEFT',
				'table' => 'online',
				'as' => 'o',
				'on' => '(o.user_id=u.id AND o.user_id!=1 AND o.idle=0)',
			),
		);

		$posts = array();
		$ps = $this->db->join('messages', 'p', $join, 'u.email, u.use_gravatar, u.title, u.url, u.location, u.signature, u.reputation, u.email_setting, u.num_posts, u.registered, u.admin_note, p.id, p.poster AS username, p.poster_id, p.message, p.hide_smilies, p.posted, p.poster_ip, p.edited, p.edited_by, g.g_id, g.g_user_title, g.g_image, o.user_id AS is_online', $post_ids, 'p.id IN ('.implode(',', $markers).')', 'p.id');
		foreach ($ps as $cur_post)
		{
			$user_avatar = '';
			$user_info = array();
			$user_contacts = array();
			$post_actions = array();
			$is_online = '';
			$signature = '';
			
			$user_title = $this->registry->get('\topics\title')->get_title($cur_post);

			if ($this->config['o_censoring'] == '1')
				$user_title = $this->registry->get('\message\bbcode')->censor_words($user_title);
			
			if ($this->config['o_avatars'] == '1' && $this->user['show_avatars'] != '0')
				$user_avatar = $this->registry->get('\avatar')->generate($cur_post['poster_id'], $cur_post['email'], $cur_post['use_gravatar']);
			
			// We only show location, register date, post count and the contact links if "Show user info" is enabled
			if ($this->config['o_show_user_info'] == '1')
			{
				if ($cur_post['location'] != '')
				{
					if ($this->config['o_censoring'] == '1')
						$cur_post['location'] = $this->registry->get('\message\bbcode')->censor_words($cur_post['location']);

					$user_info[] = array('title' => $this->lang->t('From'), 'value' => $cur_post['location']);
				}

				$user_info[] = array('title' => $this->lang->t('Registered'), 'value' => $this->registry->get('\aura_time')->format($cur_post['registered'], true));

				if ($this->config['o_show_post_count'] == '1' || $this->user['is_admmod'])
					$user_info[] = array('title' => $this->lang->t('Posts'), 'value' => $this->functions->forum_number_format($cur_post['num_posts']));

				// Now let's deal with the contact links (Email and URL)
				if ((($cur_post['email_setting'] == '0' && !$this->user['is_guest']) || $this->user['is_admmod']) && $this->user['g_send_email'] == '1')
					$user_contacts[] = array('class' => 'email', 'href' => 'mailto:'.$cur_post['email'], 'title' => $this->lang->t('Email'));
				else if ($cur_post['email_setting'] == '1' && !$this->user['is_guest'] && $this->user['g_send_email'] == '1')
					$user_contacts[] = array('class' => 'email', 'href' => $this->registry->get('\links')->aura_link($this->rewrite->url['email'], array($cur_post['poster_id'])), 'title' => $this->lang->t('Email'));

				if ($cur_post['url'] != '')
				{
					if ($this->config['o_censoring'] == '1')
						$cur_post['url'] = $this->registry->get('\message\bbcode')->censor_words($cur_post['url']);

					$user_contacts[] = array('class' => 'website', 'href' => $cur_post['url'], 'rel' => 'nofollow', 'title' => $this->lang->t('Website'));
				}
			}

			$user_contacts = $this->registry->get('\extensions\hooks')->fire('messenger.view.posts.usercontacts', $user_contacts);
			if ($this->user['is_admmod'])
			{
				$user_info[] = array('title' => $this->lang->t('IP address logged'), 'href' => $this->registry->get('\links')->aura_link($this->rewrite->url['get_host'], array($cur_post['id'])), 'label' => $cur_post['poster_ip']);

				if ($cur_post['admin_note'] != '')
					$user_info[] = array('title' => $this->lang->t('Note'), 'value' => $cur_post['admin_note']);
			}

			$user_info = $this->registry->get('\extensions\hooks')->fire('messenger.view.posts.userinfo', $user_info);
			if ($cur_post['g_image'] != '')
			{
				$image_path = ($this->config['o_image_group_dir'] != '') ? $this->config['o_image_group_path'] : AURA_ROOT.$this->config['o_image_group_path'].'/';
				$image_dir = ($this->config['o_image_group_dir'] != '') ? $this->config['o_image_group_dir'] : $this->functions->get_base_url().'/'.$this->config['o_image_group_path'].'/';
				$img_size = getimagesize($image_path.$cur_post['g_id'].'.'.$cur_post['g_image']);
				$group_image = array('src' => $image_dir.$cur_post['g_id'].'.'.$cur_post['g_image'], 'size' => $img_size[3], 'alt' => $cur_post['g_user_title']);

				$group_image = $this->registry->get('\extensions\hooks')->fire('messenger.view.posts.groupimage', $group_image);
			}
			else
				$group_image = array();

			if ($this->config['o_reputation'] == '1')
			{
				switch(true)
				{
					case $cur_post['poster_id'] == 1:
						$type = 'zero';
					break;
					case $cur_post['reputation'] > '0':
						$type = 'positive';
					break;
					case $cur_post['reputation'] < '0':
						$type = 'negative';
					break;
					default:
						$type = 'zero';
					break;
				}
				
				$reputation = array('type' => $type, 'title' => $this->lang->t('reputation', $this->functions->forum_number_format($cur_post['reputation'])));
			}

			if ($cur_topic['fid'] != '3') // If it's not archived then we can do stuff
			{
				if ($cur_post['poster_id'] == $this->user['id'] || $this->user['is_admmod'])
				{
					$post_actions[] = array('class' => 'delete', 'href' => $this->registry->get('\links')->aura_link($this->rewrite->url['pms_delete'], array($cur_post['id'])), 'title' => $this->lang->t('Delete'));

					if ($this->user['g_edit_posts'] == '1')
						$post_actions[] = array('class' => 'edit', 'href' => $this->registry->get('\links')->aura_link($this->rewrite->url['pms_edit'], array($cur_post['id'])), 'title' => $this->lang->t('Edit'));

					if ($this->user['g_post_replies'] == '1')
						$post_actions[] = array('class' => 'quote', 'href' => $this->registry->get('\links')->aura_link($this->rewrite->url['pms_quote'], array($tid, $cur_post['id'])), 'title' => $this->lang->t('Quote'));
				}
			}

			$post_actions = $this->registry->get('\extensions\hooks')->fire('messenger.view.posts.postactions', $post_actions);

			// Do signature parsing/caching
			if ($this->config['o_signatures'] == '1' && $cur_post['signature'] != '' && $this->user['show_sig'] != '0')
			{
				if (isset($signature_cache[$cur_post['poster_id']]))
					$signature = $signature_cache[$cur_post['poster_id']];
				else
				{
					$signature = $parser->parse_signature($cur_post['signature']);
					$signature_cache[$cur_post['poster_id']] = $signature;
				}
			}

			$posts[] = array(
				'id' => $cur_post['id'],
				'link' => $this->registry->get('\links')->aura_link($this->rewrite->url['pms_post'], array($cur_post['id'])),
				'posted' => $this->registry->get('\aura_time')->format($cur_post['posted']),
				'username' => $this->functions->colourise_group($cur_post['username'], $cur_post['g_id'], $cur_post['poster_id']),
				'user_title' => $user_title,
				'number' => ($start_from + (++$post_count)),
				'avatar' => $user_avatar,
				'poster_reputation' => $reputation,
				'message' => $parser->parse_message($cur_post['message'], $cur_post['hide_smilies']),
				'signature' => $signature,
				'edited' => $cur_post['edited'] ? $this->registry->get('\aura_time')->format($cur_post['edited']) : '',
				'edited_by' => $cur_post['edited_by'],
				'post_actions' => $post_actions,
				'user_info' => $user_info,
				'group_image' => $group_image,
				'user_contacts' => $user_contacts,
				'is_online' => $cur_post['is_online'],
				'poster_id' => $cur_post['poster_id'],
			);
		}

		return $posts;
	}

	/**
	 * Try to find the latest unread post in the topic and head to that
	 */
	public function unread()
	{
		$data = array(
			':uid' => $this->user['id'],
			':tid' => $tid,
			':last_visit' => $this->user['last_visit'],
		);

		$ps = $this->db->select('messages', 'MIN(id)', $data, 'poster_id!=:uid AND topic_id=:tid AND posted>:last_visit');
		$first_new_post_id = $ps->fetchColumn();

		$first_new_post_id = $this->registry->get('\extensions\hooks')->fire('messenger.view.unread', $first_new_post_id);

		if ($first_new_post_id)
		{
			header('Location: '.$this->registry->get('\links')->aura_link($this->rewrite->url['pms_post'], array($first_new_post_id)));
			exit;
		}

		// If there is no unread post, we go straight to the last post
		$this->last();
	}

	/**
	 * If action=last, we redirect to the last post
	 */
	public function last()
	{
		$data = array(
			':id' => $tid,
		);

		$ps = $this->db->select('messages', 'MAX(id)', $data, 'topic_id=:id');
		$last_post_id = $ps->fetchColumn();

		$last_post_id = $this->registry->get('\extensions\hooks')->fire('messenger.view.last', $last_post_id);

		if ($last_post_id)
		{
			header('Location: '.$this->registry->get('\links')->aura_link($this->rewrite->url['pms_post'], array($last_post_id)));
			exit;
		}
	}

	/**
	 * Fetches some information about the topic
	 */
	protected function fetch_topic($tid)
	{
		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'pms_data',
				'as' => 'cd',
				'on' => 'c.id=cd.topic_id',
			),
			array(
				'type' => 'INNER',
				'table' => 'folders',
				'as' => 'f',
				'on' => 'cd.folder_id=f.id',
			),
		);

		$data = array(
			':uid' => $this->user['id'],
			':tid' => $tid,
		);

		$ps = $this->db->join('conversations', 'c', $join, 'c.subject, c.num_replies, f.name, f.id AS fid, cd.viewed', $data, 'c.id=:tid AND cd.user_id=:uid');
		if (!$ps->rowCount())
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'), false, '404 Not Found');

		$cur_topic = $ps->fetch();

		$cur_topic = $this->registry->get('\extensions\hooks')->fire('messenger.view.fetchtopic', $cur_topic);
		$data = array(
			':tid' => $tid,
			':uid' => $this->user['id'],
		);

		$ps = $this->db->select('pms_data', 1, $data, 'topic_id=:tid AND user_id=:uid AND deleted=1');
		if ($ps->rowCount()) // Why are we still trying to view this if we've deleted it?
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'));

		$this->registry->get('\extensions\hooks')->fire('messenger.view.fetchtopic.authorised');
		if ($cur_topic['viewed'] == '0')
		{
			$update = array(
				'viewed' => 1,
			);

			$data = array(
				':tid' => $tid,
				':uid' => $this->user['id'],
			);

			$this->db->update('pms_data', $update, 'topic_id=:tid AND user_id=:uid', $data);

			$this->registry->get('\extensions\hooks')->fire('messenger.view.viewtopic');
		}

		return $cur_topic;
	}
}