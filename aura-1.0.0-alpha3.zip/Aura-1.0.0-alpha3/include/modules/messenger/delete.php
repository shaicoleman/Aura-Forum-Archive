<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class delete_controller extends base_controller
{
	/**
	 * Main class entry point- we want to delete the post
	 */
	public function execute()
	{
		$this->registry->get('\extensions\hooks')->fire('messenger.delete.immediate');
		$this->configure_pms();

		$pid = isset($_GET['pid']) ? intval($_GET['pid']) : 0;
		if ($pid < 1)
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'));

		$cur_topic = $this->fetch_topic($pid);

		$is_topic_post = ($pid == $cur_topic['first_post_id']) ? true : false;

		if ($cur_topic['poster_id'] != $this->user['id'] && !$this->user['is_admmod'])
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'));

		if ($cur_topic['folder_id'] == 3) // Then we've archived it
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'));

		$this->registry->get('\extensions\hooks')->fire('messenger.delete.authorised');

		$this->lang->load('delete');
		if (isset($_POST['form_sent']))
			$this->delete_post($is_topic_post, $cur_topic, $pid);

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('PM'), $this->lang->t('Delete message')),
			'active_page' => 'pm',
		);

		$this->template->header = $this->registry->get('\extensions\hooks')->fire('messenger.delete.header', $this->template->header);
		$parser = new \message\parser($this->registry);

		$args = $this->registry->get('\extensions\hooks')->fire('messenger.delete.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('delete_message.tpl');
		$this->template->output($tpl,
			array_merge(
				array(
					'pm_menu' => $this->registry->get('\messenger\menu')->generate(),
					'form_action' => $this->registry->get('\links')->aura_link($this->rewrite->url['pms_delete'], array($pid)),
					'message' => $parser->parse_message($cur_topic['message'], $cur_topic['hide_smilies']),
					'csrf_token' => $this->registry->get('\auth\csrf')->generate('delete_message'),
					'poster' => $cur_topic['poster'],
					'posted' => $this->registry->get('\aura_time')->format($cur_topic['posted']),
					'is_topic_post' => $is_topic_post,
				),
				$args
			)
		);
	}

	/**
	 * Fetches the topic information
	 */
	protected function fetch_topic($pid)
	{
		$data = array(
			':id' => $pid,
			':uid' => $this->user['id']
		);

		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'conversations',
				'as' => 'c',
				'on' => 'm.topic_id=c.id',
			),
			array(
				'type' => 'INNER',
				'table' => 'pms_data',
				'as' => 'cd',
				'on' => 'c.id=cd.topic_id',
			),
		);

		$ps = $this->db->join('messages', 'm', $join, 'c.subject, c.id AS tid, cd.folder_id, m.poster, m.posted, c.first_post_id, c.num_replies, m.message, m.hide_smilies, m.poster_id', $data, 'm.id=:id AND cd.user_id=:uid AND cd.deleted=0');
		if (!$ps->rowCount())
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request')); // We've deleted it
		else
			$cur_topic = $ps->fetch();

		$cur_topic = $this->registry->get('\extensions\hooks')->fire('messenger.delete.topic', $cur_topic);
		return $cur_topic;
	}

	/**
	 * Configure and setup a few things before we start each action
	 */
	protected function configure_pms()
	{
		if ($this->user['g_read_board'] == '0')
			$this->registry->get('\handlers\message')->show($this->lang->t('No view'), false, '403 Forbidden');

		if ($this->user['is_guest'])
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'));

		if ($this->config['o_private_messaging'] == '0' || $this->user['g_use_pm'] == '0' || $this->user['pm_enabled'] == '0')
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'));

		$this->lang->load('pms');

		// Load the post language file
		$this->lang->load('post');

		$this->registry->get('\extensions\hooks')->fire('messenger.delete.configure');
	}

	/**
	 * We want to actually delete the post
	 */
	protected function delete_post($is_topic_post, $cur_topic, $pid)
	{
		$this->registry->get('\auth\csrf')->confirm('delete_message');
		if ($is_topic_post)	// Then we delete the entire topic only for us (unless everyone else has already)
		{
			$this->delete_topic_post($cur_topic);

			$redirect_msg = $this->lang->t('Topic del redirect');
			$link = $this->registry->get('\links')->aura_link($this->rewrite->url['inbox']);
		}
		else // Delete this post for all users
		{
			$cur_post = $this->delete_post_full($cur_topic, $pid);

			$link = $this->registry->get('\links')->aura_link($this->rewrite->url['pms_post'], array($cur_post['id']));
			$redirect_msg = $this->lang->t('Post del redirect');
		}

		$this->registry->get('\extensions\hooks')->fire('messenger.delete.deleted.redirect');
		$this->registry->get('\handlers\redirect')->show($link, $redirect_msg);
	}

	/**
	 * Deletes the first post in a topic (only for us unless everyone else has deleted their version)
	 */
	protected function delete_topic_post($cur_topic)
	{
		$data = array(
			':tid' => $cur_topic['tid'],
			':uid' => $this->user['id'],
		);

		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'pms_data',
				'as' => 'cd',
				'on' => 'c.id=cd.topic_id',
			),
		);

		$ps = $this->db->join('conversations', 'c', $join, 1, $data, 'cd.topic_id=:tid AND cd.deleted=0 AND cd.user_id!=:uid');
		if (!$ps->rowCount()) // Then there is no one else in the conversation
		{
			$data = array(
				':id' => $cur_topic['tid'],
			);

			$this->db->delete('conversations', 'id=:id', $data);
	
			$data = array(
				':id' => $pid,
			);

			$this->db->delete('messages', 'id=:id', $data);
		}
		else
		{
			$update = array(
				'deleted' => 1,
			);

			$this->db->update('pms_data', $update, 'topic_id=:tid AND user_id=:uid', $data);
		}

		$data = array(
			':amount' => ($cur_topic['num_replies'] + 1), // Make sure we include the topic post
			':id' => $this->user['id'],
		);

		$this->db->run('UPDATE '.$this->db->prefix.'users SET num_pms=num_pms-:amount WHERE id=:id', $data);

		$this->registry->get('\extensions\hooks')->fire('messenger.delete.delete.topicpost');
	}

	/**
	 * Deletes a single post in the topic for all users
	 */
	protected function delete_post_full($cur_topic, $pid)
	{
		$data = array(
			':id' => $pid,
		);

		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'conversations',
				'as' => 'c',
				'on' => 'm.topic_id=c.id',
			),
			array(
				'type' => 'INNER',
				'table' => 'pms_data',
				'as' => 'cd',
				'on' => 'c.id=cd.topic_id',
			),
		);

		$ps = $this->db->join('messages', 'm', $join, 'cd.user_id', $data, 'm.id=:id AND cd.deleted=0');
		if (!$ps->rowCount()) // Then we're the only person left
		{
			$data = array(
				':id' => $pid,
			);

			$this->db->delete('messages', 'id=:id', $data);
			$data = array(
				':id' => $this->user['id'],
			);

			$this->db->run('UPDATE '.$this->db->prefix.'users SET num_pms=num_pms-1 WHERE id=:id', $data);
		}
		else
		{
			$ps->setFetchMode(PDO::FETCH_COLUMN, 0);
			foreach ($ps as $uid)
			{
				$data = array(
					':id' => $uid,
				);
		
				$this->db->run('UPDATE '.$this->db->prefix.'users SET num_pms=num_pms-1 WHERE id=:id', $data);
			}
					
			$data = array(
				':id' => $pid,
			);

			$this->db->delete('messages', 'id=:id', $data);
		}
				
		$data = array(
			':id' => $cur_topic['tid'],
		);
				
		$ps = $this->db->select('messages', 'poster, posted, id', $data, 'topic_id=:id', 'id DESC LIMIT 1');
		$cur_post = $ps->fetch();
		
		$data = array(
			':poster' => $cur_post['poster'],
			':posted' => $cur_post['posted'],
			':last'	 => $cur_post['id'],
			':id' => $cur_topic['tid'],
		);
					
		$this->db->run('UPDATE '.$this->db->prefix.'conversations SET num_replies=num_replies-1, poster=:poster, last_post=:posted, last_post_id=:last WHERE id=:id', $data);

		$cur_post = $this->registry->get('\extensions\hooks')->fire('messenger.delete.delete.post', $cur_post);
		return $cur_post;
	}
}