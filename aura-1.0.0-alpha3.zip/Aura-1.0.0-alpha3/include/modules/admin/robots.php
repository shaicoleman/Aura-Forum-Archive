<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class robots_controller extends base_controller
{
	/**
	 * Main class entry point
	 */
	public function execute()
	{
		$admin = new \admin\common($this->registry);

		if (!$this->user['is_admin'])
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		$admin->check_user('admin_robots');

		$this->registry->get('\auth\http_auth')->check_authentication();

		// Load the admin-robots language file
		$this->lang->load('admin_robots');

		// Add in our event handlers
		if (isset($_POST['add_test']))
			$this->add_test();
		else if (isset($_POST['update'])) // Update a robot question
			$this->edit_test();
		else if (isset($_POST['remove'])) // Remove a robot test
			$this->delete_test();

		$robots = array();
		$ps = $this->db->select('robots', 'id, question, answer', array(), '', 'id');
		foreach ($ps as $cur_test)
			$robots[] = array(
				'id' => $cur_test['id'],
				'question' => $cur_test['question'],
				'answer' => $cur_test['answer'],
			);

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Admin'), $this->lang->t('Robots')),
			'focus_element' => array('robots', 'new_question'),
			'active_page' => 'admin',
			'admin_console' => true,
		);

		$this->template->footer = array(
			'admin_console' => true,
		);

		$tpl = $this->template->load('admin/robots.tpl');
		$this->template->output($tpl,
			array(
				'admin_menu' => $admin->generate_menu('robots'),
				'form_action' => $this->registry->get('\links')->aura_link($this->rewrite->url['admin_robots']),
				'csrf_token' => $this->registry->get('\auth\csrf')->generate('admin_robots'),
				'robots' => $robots,
			)
		);
	}

	/**
	 * Add a new test
	 */
	protected function add_test()
	{
		$this->registry->get('\auth\csrf')->confirm('admin_robots');

		$question = isset($_POST['new_question']) ? utf8_trim($_POST['new_question']) : '';
		$answer = isset($_POST['new_answer']) ? utf8_trim($_POST['new_answer']) : '';

		if ($question == '' || $answer == '')
			$this->registry->get('\handlers\message')->show($this->lang->t('Must enter question message'));

		$insert = array(
			'question' => $question,
			'answer' => $answer,
		);

		$this->db->insert('robots', $insert);

		// Regenerate the robots cache
		$this->cache->generate('robots');
		$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['admin_robots']), $this->lang->t('Question added redirect'));
	}

	/**
	 * Edit a test
	 */
	protected function edit_test()
	{
		$this->registry->get('\auth\csrf')->confirm('admin_robots');

		$id = intval(key($_POST['update']));

		$question = isset($_POST['question'][$id]) ? utf8_trim($_POST['question'][$id]) : '';
		$answer = isset($_POST['answer'][$id]) ? utf8_trim($_POST['answer'][$id]) : '';

		if ($question == '' || $answer == '')
			$this->registry->get('\handlers\message')->show($this->lang->t('Must enter question message'));

		$update = array(
			'question' => $question,
			'answer' => $answer,
		);
		
		$data = array(
			':id'	=>	$id,
		);

		$this->db->update('robots', $update, 'id=:id', $data);

		// Regenerate the robots cache
		$this->cache->generate('robots');
		$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['admin_robots']), $this->lang->t('Question updated redirect'));
	}

	/**
	 * Delete a test
	 */
	protected function delete_test()
	{
		$this->registry->get('\auth\csrf')->confirm('admin_robots');

		$id = intval(key($_POST['remove']));
		$data = array(
			':id'	=>	$id,
		);

		$this->db->delete('robots', 'id=:id', $data);

		// Regenerate the robots cache
		$this->cache->generate('robots');
		$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['admin_robots']),  $this->lang->t('Question removed redirect'));
	}
}