<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class archive_controller extends base_controller
{
	public function execute()
	{
		$admin = new \admin\common($this->registry);

		if (!$this->user['is_admin'])
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		$admin->check_user('admin_archive');

		$this->registry->get('\auth\http_auth')->check_authentication();

		// Load the admin-archive language file
		$this->lang->load('admin_archive');

		$ps = $this->db->select('topics', 'COUNT(id)', array(), 'deleted=0 AND approved=1');
		$total = $ps->fetchColumn();

		$ps = $this->db->select('topics', 'COUNT(id)', array(), 'archived=1 AND deleted=0 AND approved=1');
		$archived = $ps->fetchColumn();

		if (isset($_POST['form_sent']))
			$this->update_archiving();

		$archive_rules = ($this->config['o_archive_rules'] != '') ? unserialize($this->config['o_archive_rules']) : array('closed' => 0, 'sticky' => 0, 'time' => 0, 'unit' => 'days', 'forums' => array(0));
		$percentage = ($ps->rowCount() != 0) ? round(($archived/$total)*100, 2) : 0;

		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'forums',
				'as' => 'f',
				'on' => 'c.id=f.cat_id',
			),
		);

		$categories = $forums = array();
		$ps = $this->db->join('categories', 'c', $join, 'c.id AS cid, c.cat_name, f.id AS fid, f.forum_name', array(), 'f.redirect_url IS NULL', 'c.disp_position, c.id, f.disp_position');
		foreach ($ps as $cur_forum)
		{
			if (!isset($categories[$cur_forum['cid']]))
				$categories[$cur_forum['cid']] = array(
				'name' => $cur_forum['cat_name'],
				'id' => $cur_forum['cid'],
			);
				
			$forums[] = array(
				'id' => $cur_forum['fid'],
				'selected' => ((in_array($cur_forum['fid'], $archive_rules['forums'])) ? true : false),
				'name' => $cur_forum['forum_name'],
				'category_id' => $cur_forum['cid'],
			);
		}

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Admin'), $this->lang->t('Archive')),
			'active_page' => 'admin',
			'admin_console' => true,
		);

		$this->template->footer = array(
			'admin_console' => true,
		);

		$tpl = $this->template->load('admin/archive.tpl');
		$this->template->output($tpl,
			array(
				'admin_menu' => $admin->generate_menu('archive'),
				'form_action' => $this->registry->get('\links')->aura_link($this->rewrite->url['admin_archive']),
				'csrf_token' => $this->registry->get('\auth\csrf')->generate('admin_archive'),
				'archive_lang' => $this->config['o_archiving'] == '1' ? $this->lang->t('Archive enabled') : $this->lang->t('Archive disabled'),
				'admin_options' => $this->registry->get('\links')->aura_link($this->rewrite->url['admin_options']),
				'archived' => $archived,
				'percentage' => $percentage,
				'archive_rules' => $archive_rules,
				'categories' => $categories,
				'forums' => $forums,
			)
		);
	}

	protected function update_archiving()
	{
		$this->registry->get('\auth\csrf')->confirm('admin_archive');
		$units = array('day', 'months', 'years'); // Set an array of valid time expiration strings

		$time = isset($_POST['time']) ? intval($_POST['time']) : 0;
		$unit = isset($_POST['unit']) && in_array($_POST['unit'], $units) ? utf8_trim($_POST['unit']) : 'days';
		$closed = isset($_POST['closed']) ? intval($_POST['closed']) : 0;
		$sticky = isset($_POST['sticky']) ? intval($_POST['sticky']) : 0;
		$forums = isset($_POST['forums']) && is_array($_POST['forums']) ? array_map('intval', $_POST['forums']) : array(0);

		if (in_array(0, $forums) && count($forums) > 1)
			$this->registry->get('\handlers\message')->show($this->lang->t('All forums message'));

		if ($sticky > 2 || $sticky < 0 || $closed > 2 || $closed < 0)
			$this->registry->get('\handlers\message')->show($this->lang->t('Open/close message'));
		
		if ($time < 1)
			$this->registry->get('\handlers\message')->show($this->lang->t('Invalid time value', strtolower($unit)));

		$rules = array(
			'closed' => $closed,
			'sticky' => $sticky,
			'time' => $time,
			'unit' => $unit,
			'forums' => $forums,
		);

		$topics = $this->registry->get('\topics\archive')->check_archive_rules($rules);
		$percentage = 0;
		if ($topics['count'] != 0 && $this->config['o_archiving'] == '1')
		{
			$markers = $data = array();
			for ($i = 0; $i < count($topics['topics']); $i++)
			{
				$markers[] = '?';
				$data[] = $topics['topics'][$i];
			}

			$this->db->run('UPDATE '.$this->db->prefix.'topics SET archived=1 WHERE id IN ('.implode(',', $markers).')', $data);
			$percentage = round(($topics['count']/$total)*100, 2);
		}

		$update = array(
			'conf_value' => serialize($rules),
		);

		$data = array(
			':conf_name' => 'o_archive_rules',
		);

		$this->db->update('config', $update, 'conf_name=:conf_name', $data);
		$this->cache->generate('config', array($this->config));

		$redirect_lang = ($this->config['o_archiving'] == '1') ? $this->lang->t('Archive rules updated', $topics['count'], $total, $percentage.'%') : $this->lang->t('Updated redirect');
		$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['admin_archive']), $redirect_lang);
	}
}