<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class maintenance_controller extends base_controller
{
	/**
	 * Main App entry point, we display the maintenance section
	 */
	public function execute()
	{
		$this->configure_page();

		$errors = array();
		// Configure our event handlers
		if (isset($_POST['add_user']))
			$errors = $this->add_user();
		else if (isset($_POST['prune_users']))
			$this->prune_users();
		else if (isset($_POST['confirm_merge']))
			$this->confirm_merge();
		else if (isset($_POST['prune_posts']))
			$this->prune_posts();

		// Fetch some index data which we need to use to render the page
		list ($first_id, $options, $forums, $categories) = $this->fetch_index_data();

		$tpl = $this->template->load('admin/maintenance.tpl');
		$this->template->output($tpl,
			array(
				'admin_menu' => $this->admin->generate_menu('maintenance'),
				'form_action' => $this->registry->get('\links')->aura_link($this->rewrite->url['admin_maintenance']),
				'csrf_token' => $this->registry->get('\auth\csrf')->generate(config::ADMIN_DIR.'_maintenance'),
				'options_link' => $this->registry->get('\links')->aura_link($this->rewrite->url['admin_options']),
				'first_id' => $first_id,
				'POST' => $_POST,
				'errors' => $errors,
				'options' => $options,
				'forums' => $forums,
				'categories' => $categories,
			)
		);
	}

	/**
	 * Rebuild the search index
	 */
	public function rebuild()
	{
		$this->configure_page();

		$per_page = isset($_GET['i_per_page']) ? intval($_GET['i_per_page']) : 0;
		$start_at = isset($_GET['i_start_at']) ? intval($_GET['i_start_at']) : 0;

		$this->registry->get('\auth\csrf')->confirm(config::ADMIN_DIR.'_maintenance');
	
		// Check per page is > 0
		if ($per_page < 1)
			$this->registry->get('\handlers\message')->show($this->lang->t('Posts must be integer message'));

		@set_time_limit(0);

		// If this is the first cycle of posts we empty the search index before we proceed
		if (isset($_GET['i_empty_index']))
		{
			// This is the only potentially "dangerous" thing we can do here, so we check the referer
			$this->db->truncate_table('search_matches');
			$this->db->truncate_table('search_words');

			// Reset the sequence for the search words
			$ps = $this->db->run('ALTER TABLE '.$this->db->prefix.'search_words auto_increment=1');
		}

		$redirect_url = $this->registry->get('\links')->aura_link($this->rewrite->url['admin_maintenance']);
		$idx = new \search\idx($this->registry);

		$data = array(
			':start' => $start_at,
			':limit' => $per_page,
		);

		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'topics',
				'as' => 't',
				'on' => 't.id=p.topic_id',
			),
		);

		// Fetch posts to process this cycle
		$ps = $this->db->join('posts', 'p', $join, 'p.id, p.message, t.subject, t.first_post_id', $data, 'p.id>=:start', 'p.id ASC LIMIT :limit');

		$end_at = 0;
		$posts = array();
		foreach ($ps as $cur_item)
		{
			if ($cur_item['id'] == $cur_item['first_post_id'])
				$idx->update_search_index('post', $cur_item['id'], $cur_item['message'], $cur_item['subject']);
			else
				$idx->update_search_index('post', $cur_item['id'], $cur_item['message']);

			$end_at = $cur_item['id'];
		}

		// Check if there is more work to do
		if ($end_at > 0)
		{
			$data = array(
				':id' => $end_at,
			);

			$ps = $this->db->select('posts', 'id', $data, 'id>:id', 'id ASC LIMIT 1');
			if ($ps->rowCount())
				$redirect_url = $this->registry->get('\links')->aura_link($this->rewrite->url['admin_maintenance_rebuild'], array($this->registry->get('\auth\csrf')->generate(config::ADMIN_DIR.'_maintenance'), $per_page, $ps->fetchColumn()));
		}

		$this->registry->get('\handlers\redirect')->show($redirect_url, $this->lang->t('Rebuilding search index', $per_page, $end_at));		
	}

	/**
	 * Confirm or perform a merging of two user accounts
	 */
	protected function confirm_merge()
	{
		$uid_merge = isset($_POST['to_merge']) ? intval($_POST['to_merge']) : 0;
		$uid_stay = isset($_POST['to_stay']) ? intval($_POST['to_stay']) : 0;

		if ($uid_merge == $uid_stay || $uid_merge == '1' || $uid_stay == '1')
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'));

		if (isset($_POST['merge_comply']))
		{
			@set_time_limit(0);
			$aura_groups = $this->cache->get('groups');
			$data = array(
				':id' => $uid_merge,
			);
			
			$ps = $this->db->select('users', 'username, group_id, email, num_posts', $data, 'id=:id');
			if (!$ps->rowCount())
				$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'));
			else
				$user_merge = $ps->fetch();
			
			$data = array(
				':id' => $uid_stay,
			);
			
			$ps = $this->db->select('users', 'username, group_id, email, num_posts, num_pms', $data, 'id=:id');	
			if (!$ps->rowCount())
				$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'));
			else
				$user_stay = $ps->fetch();
			
			$update = array(
				'owner'	=>	$uid_stay
			);
			
			$data = array(
				':uid'	=>	$uid_merge,
			);
			
			$this->db->update('attachments', $update, 'owner=:uid', $data);
			
			$update = array(
				'username' => $user_stay['username'],
				'email' => $user_stay['email'],
			);
			
			$data = array(
				':merge_username' => $user_merge['username'],
				':merge_email' => $user_merge['email'],
			);
			
			$this->db->update('bans', $update, 'username=:merge_username OR :merge_email', $data);
			
			$this->cache->generate('bans');
			$update = array(
				'user_id' => $uid_stay,
			);
			
			$data = array(
				':uid'	=> $uid_merge,
			);
			
			$this->db->update('blocks', $update, 'user_id=:uid', $data);

			$update = array(
				'block_id'	=> $uid_stay,
			);

			$data = array(
				':uid'	=> $uid_merge,
			);
			
			$this->db->update('blocks', $update, 'block_id=:uid', $data);
			
			$update = array(
				'poster' => $user_stay['username'],
			);
			
			$data = array(
				':uid'	=>	$user_merge['username'],
			);
			
			$this->db->update('conversations', $update, 'poster=:uid', $data);
			
			$update = array(
				'poster_id' => $uid_stay,
			);

			$data = array(
				':uid'	=>	$uid_merge,
			);

			$this->db->update('conversations', $update, 'poster_id=:uid', $data);

			$update = array(
				'last_poster' => $user_stay['username'],
			);

			$data = array(
				':uid'	=>	$user_merge['username'],
			);
			
			$this->db->update('conversations', $update, 'last_poster=:uid', $data);

			$update = array(
				'user_id'	=>	$uid_stay,
			);
			
			$data = array(
				':uid'	=>	$uid_merge,
			);
			
			$this->db->update('folders', $update, 'user_id=:uid', $data);
			
			$update = array(
				'user_id'	=>	$uid_stay,
			);
			
			$data = array(
				':uid'	=>	$uid_merge,
			);
			
			$this->db->update('folders', $update, 'user_id=:uid', $data);
			
			$update = array(
				'poster_id'	=>	$uid_stay,
				'poster'	=>	$user_stay['username'],
			);
			
			$where = array(
				':pid'	=>	$uid_merge,
			);
			
			$this->db->update('messages', $update, 'poster_id=:pid', $where);
			$update = array(
				'edited_by'	=>	$user_stay['username'],
			);
			
			$where = array(
				':edited'	=>	$user_merge['username']
			);

			$this->db->update('messages', $update, 'edited_by=:edited', $where);
			
			$data = array(
				':id'	=>	$uid_merge,
			);

			// This bit might take a while (depending on how many messages the user has)
			$num_pms = 0;
			$ps = $this->db->select('pms_data', 'topic_id', $data, 'user_id=:id');
			foreach ($ps as $pm)
			{
				$data = array(
					'user_id'	=>	$uid_stay,
					'topic_id'	=>	$pm['topic_id'],
				);

				// Check if this user has any PMs the same to avoid messing with the composite key of the table
				$ps1 = $this->db->select('pms_data', 1, $data, 'user_id=:uid AND topic_id=:tid');
				if (!$ps->roCount())
				{
					// Then we just replace the data as we're not in that conversation
					$update = array(
						'user_id'	=>	$uid_stay,
					);

					$data = array(
						':id'	=>	$pm['topic_id'],
						':uid'	=>	$uid_merge,
					);

					$this->db->update('pms_data', $update, 'user_id=:uid AND topic_id=:tid', $data);
					$data = array(
						':id'	=>	$pm['topic_id'],
					);

					$ps2 = $this->db->select('conversations', 'num_replies', $data, 'topic_id=:id');
					$num_pms = $num_pms + ($ps2->fetchColumn()+1); // Plus one for the topic post (which is not included in 'num_replies')
				}
				else
				{	// We are in that conversation, so we need to delete the old data row and leave ours
					$data = array(
						':id'	=>	$uid_merge,
						':tid'	=>	$pm['topic_id'],
					);

					$this->db->delete('pms_data', 'user_id=:id AND topic_id=:tid', $data);
				}
			}

			$update = array(
				'poster_id'	=>	$user_stay['username'],
			);
			
			$where = array(
				':edited'	=>	$user_merge['username']
			);

			$this->db->update('messages', $update, 'edited_by=:edited', $where);

			$update = array(
				'edited_by'	=>	$user_stay['username'],
			);
			
			$where = array(
				':edited'	=>	$user_merge['username']
			);
			
			$this->db->update('posts', $update, 'edited_by=:edited', $where);
			
			$update = array(
				'user_id'	=>	$uid_stay,
			);
			
			$data = array(
				':id'	=>	$uid_merge,
			);
			
			$this->db->update('forum_subscriptions', $update, 'user_id=:id', $data);
			$update = array(
				'last_poster'	=>	$user_stay['username'],
			);
			
			$data = array(
				':user'	=>	$user_merge['username'],
			);
			
			$this->db->update('forums', $update, 'last_poster=:user', $data);
			$data = array(
				':username'	=>	$user_merge['username'],
			);
			
			$this->db->delete('login_queue', 'username=:username', $data);
			
			$update = array(
				'poster_id'	=>	$uid_stay,
				'poster'	=>	$user_stay['username'],
			);
			
			$where = array(
				':pid'	=>	$uid_merge,
			);
			
			$this->db->update('posts', $update, 'poster_id=:pid', $where);
			$update = array(
				'edited_by'	=>	$user_stay['username'],
			);
			
			$where = array(
				':edited'	=>	$user_merge['username']
			);
			
			$this->db->update('posts', $update, 'edited_by=:edited', $where);
			$update = array(
				'reported_by'	=>	$uid_stay,
			);
			
			$where = array(
				':by'	=>	$uid_merge,
			);
			
			$this->db->update('reports', $update, 'reported_by=:by', $where);
			$update = array(
				'given_by'	=>	$uid_stay,
			);
			
			$where = array(
				':by'	=>	$uid_merge,
			);
			
			$this->db->update('reputation', $update, 'given_by=:by', $where);
			$update = array(
				'ident'	=>	$user_stay['username'],
			);
			
			$where = array(
				':id'	=>	$user_merge['username'],
			);
			
			$this->db->update('search_cache', $update, 'ident=:id', $where);
			$update = array(
				'poster'	=>	$user_stay['username'],
			);
			
			$where = array(
				':user'	=>	$user_merge['username'],
			);
			
			$this->db->update('topics', $update, 'poster=:user', $where);
			$update = array(
				'last_poster'	=>	$user_stay['username'],
			);
			
			$where = array(
				':poster'	=>	$user_merge['username'],
			);
			
			$this->db->update('topics', $update, 'last_poster=:poster', $where);
			$update = array(
				'user_id'	=>	$uid_stay,
			);
			
			$where = array(
				':uid'	=>	$uid_merge,
			);
			
			$this->db->update('topic_subscriptions', $update, 'user_id=:uid', $where);
			
			$update = array(
				'user_id'	=>	$uid_stay,
			);

			$this->db->update('warnings', $update, 'user_id=:uid', $where);
			
			$update = array(
				'issued_by'	=>	$uid_stay,
			);

			$this->db->update('warnings', $update, 'issued_by=:uid', $where);
			
			$data = array(
				':uid'	=>	$uid_merge,
			);
			
			$this->db->delete('online', 'user_id=:uid', $data);
			
			// If the group IDs are different we go for the newer one
			if ($user_merge['group_id'] != $user_stay['group_id'])
				$user_merge['group_id'] = $user_stay['group_id'];
			
			$new_group_mod = $aura_groups[$user_merge['group_id']]['g_moderator'];
			
			$new_password = $this->registry->get('\auth\password')->generate(12);
			$new_salt = $this->registry->get('\auth\password')->generate(16);
			
			$update = array(
				'group_id'	=>	$user_merge['group_id'],
				'num_posts'	=>	$user_stay['num_posts']+$user_merge['num_posts'],
				'password'	=>	aura_hash($new_password.$new_salt),
				'salt'		=>	$new_salt,
				'num_pms'	=>	($user_stay['num_pms']+$num_pms) // Add all the new PMs we've just received to the total we already have
			);

			$data = array(
				':id'	=>	$uid_stay,
			);

			$this->db->update('users', $update, 'id=:id', $data);

			// Sort out admin restriction stuff
			if ($user_merge['group_id'] == AURA_ADMIN && $user_stay['group_id'] != AURA_ADMIN || $aura_groups[$user_merge['group_id']]['g_admin'] == '1' && $aura_groups[$user_stay['group_id']]['g_admin'] == '1')
			{
				$data = array(
					':id'	=>	$uid_merge,
				);

				$this->db->delete('restrictions', 'admin_id=:id', $data);
			}
			else
			{
				$data = array(
					':id'	=>	$uid_stay,
				);

				$ps = $this->db->select('restrictions', 1, $data, 'admin_id=:id');
				if (!$ps->rowCount())
				{
					$update = array(
						'admin_id'	=>	$uid_stay,
					);

					$data = array(
						':id'	=>	$uid_merge,
					);

					$this->db->update('restrictions', $update, 'admin_id=:id', $data);
				}
			}

			// So if we're not an admin, are we a moderator? If not, remove them from all the forums they (might) have moderated.
			if ($user_merge['group_id'] != AURA_ADMIN && $new_group_mod != '1' || $user_merge['group_id'] != $user_stay['group_id'])
			{
				$data = array(
					':id' => $uid_merge,
				);

				$this->db->delete('moderators', 'user_id=:id', $data);

				$data = array(
					':id' => $uid_stay,
				);

				$this->db->delete('moderators', 'user_id=:id', $data);

				$this->cache->generate('moderators');
			}
			else // We are a moderator, so update things accordingly
			{
					$update = array(
						'user_id' => $uid_stay,
					);

					$data = array(
						':uid' => $uid_merge,
					);

					$this->db->update('moderators', $update, 'user_id=:uid', $data);
					$this->cache->generate('moderators');
			}

			$this->registry->get('\avatar')->delete_avatar($uid_merge);
			$email = new \email\email($this->registry);

			$info = array(
				'message' => array(
					'<username>' => $user_merge['username'],
					'<password>' => $new_password,
					'<admin>' => $this->user['username'],
					'<merged_user>' => $user_stay['username'],
				)
			);

			$mail_tpl = $this->registry->get('\email\parser')->parse_email('account_merged_full', $this->user['language'], $info);
			$email->send($user_merge['email'], $mail_tpl['subject'], $mail_tpl['message']);

			$info = array(
				'message' => array(
					'<username>' => $user_stay['username'],
					'<password>' => $new_password,
					'<admin>' => $this->user['username'],
					'<merged_user>' => $user_merge['username'],
				)
			);

			$mail_tpl = $this->registry->get('\email\parser')->parse_email('account_merged', $this->user['language'], $info);
			$email->send($user_stay['email'], $mail_tpl['subject'], $mail_tpl['message']);

			$data = array(
				':id' => $uid_merge,
			);

			//Finally, the very last thing we do is delete the old user..
			$this->db->delete('users', 'id=:id', $data);

			$this->cache->generate('stats');
			$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['admin_maintenance']), $this->lang->t('users merged redirect'));
		}

		$data = array(
			':id' => $uid_merge, 
		);

		$ps = $this->db->select('users', 'username', $data, 'id=:id');
		if ($ps->rowCount())
			$merge_user = $ps->fetchColumn();
		else
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'));

		$data = array(
			':id' => $uid_stay,
		);

		$ps = $this->db->select('users', 'username', $data, 'id=:id');
		if ($ps->rowCount())
			$stay_user = $ps->fetchColumn();
		else
			$this->registry->get('\handlers\message')->show($this->lang->t('Bad request'));

		$tpl = $this->template->load('admin/confirm_merge.tpl');
		$this->template->output($tpl,
			array(
				'admin_menu' => $this->admin->generate_menu('maintenance'),
				'form_action' => $this->registry->get('\links')->aura_link($this->rewrite->url['admin_maintenance']),
				'uid_merge' => $uid_merge,
				'uid_stay' => $uid_stay,
				'merge_user' => $merge_user,
				'stay_user' => $stay_user,
			)
		);

		exit;
	}

	/**
	 * Prunse some posts
	 */
	protected function prune_posts()
	{
		$prune_from = isset($_POST['prune_from']) ? utf8_trim($_POST['prune_from']) : '';
		$prune_sticky = isset($_POST['prune_sticky']) ? intval($_POST['prune_sticky']) : '';

		if (isset($_POST['prune_comply']))
		{
			$this->registry->get('\auth\csrf')->confirm(config::ADMIN_DIR.'_maintenance');

			$prune_days = intval($_POST['prune_days']);
			$prune_date = ($prune_days) ? CURRENT_TIMESTAMP - ($prune_days * 86400) : -1;

			@set_time_limit(0);

			if ($prune_from == 'all')
			{
				$ps = $this->db->select('forums', 'id');
				$num_forums = $ps->rowCount();

				for ($i = 0; $i < $num_forums; ++$i)
				{
					$fid = $ps->fetchColumn();

					$this->registry->get('\admin\misc')->prune($fid, $prune_sticky, $prune_date);
					$this->registry->get('\forum\forum')->update($fid);
				}
			}
			else
			{
				$prune_from = intval($prune_from);
				$this->registry->get('\admin\misc')->prune($prune_from, $prune_sticky, $prune_date);
				$this->registry->get('\forum\forum')->update($prune_from);
			}

			$join = array(
				array(
					'type' => 'LEFT',
					'table' => 'topics',
					'as' => 't2',
					'on' => 't1.moved_to=t2.id',
				),
			);

			// Locate any "orphaned redirect topics" and delete them
			$ps = $this->db->join('topics', 't1', $join, 't1.id', array(), 't2.id IS NULL AND t1.moved_to IS NOT NULL');
			$num_orphans = $ps->rowCount();

			if ($num_orphans)
			{
				for ($i = 0; $i < $num_orphans; ++$i)
				{
					$orphans[] = $ps->fetchColumn();
					$markers[] = '?';
				}

				$this->db->delete('topics', 'id IN('.implode(',', $markers).')', $orphans);
			}

			$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['admin_maintenance']), $this->lang->t('Posts pruned redirect'));
		}

		$prune_days = utf8_trim($_POST['req_prune_days']);
		if ($prune_days == '' || preg_match('%[^0-9]%', $prune_days))
			$this->registry->get('\handlers\message')->show($this->lang->t('Days must be integer message'));

		$prune_date = CURRENT_TIMESTAMP - ($prune_days * 86400);

		// Concatenate together the query for counting number of topics to prune
		$data = array(
			':prune' => $prune_date,
		);

		$sql = 'last_post<:prune AND moved_to IS NULL';

		if ($prune_sticky == '0')
			$sql .= ' AND sticky=0';

		if ($prune_from != 'all')
		{
			$prune_from = intval($prune_from);
			$sql .= ' AND forum_id=:fid';
			$data[':fid'] = $prune_from;
			
			$select = array(
				':id'	=>	$prune_from,
			);

			// Fetch the forum name (just for cosmetic reasons)
			$ps = $this->db->select('forums', 'forum_name', $select, 'id=:id');
			$forum = $ps->fetchColumn();
		}
		else
			$forum = $this->lang->t('All forums');

		$ps = $this->db->select('topics', 'COUNT(id)', $data, $sql);
		$num_topics = $ps->fetchColumn();

		if (!$num_topics)
			$this->registry->get('\handlers\message')->show($this->lang->t('No old topics message', $prune_days));

		$this->template->header['page_title'] = array($this->config['o_board_title'], $this->lang->t('Admin'), $this->lang->t('Prune'));
		$tpl = $this->template->load('admin/confirm_prune.tpl');
		$this->template->output($tpl,
			array(
				'admin_menu' => $this->admin->generate_menu('maintenance'),
				'link' => $this->registry->get('\links')->aura_link($this->rewrite->url['admin_maintenance']),
				'csrf_token' => $this->registry->get('\auth\csrf')->generate(config::ADMIN_DIR.'_maintenance'),
				'prune_days' => $prune_days,
				'prune_sticky' => $prune_sticky,
				'prune_from' => $prune_from,
				'forum' => $forum,
				'num_topics' => $this->functions->forum_number_format($num_topics),
			)
		);

		exit;
	}

	/**
	 * Prune some users
	 */
	protected function prune_users()
	{
		$this->registry->get('\auth\csrf')->confirm(config::ADMIN_DIR.'_maintenance');

		$days = isset($_POST['days']) ? intval($_POST['days']) : 0;
		$posts = isset($_POST['posts']) ? intval($_POST['posts']) : 0;
		
		$data = array($posts, (CURRENT_TIMESTAMP - ($days * 86400)));
		$sql = array();
		$prune = (isset($_POST['prune_by']) && $_POST['prune_by'] == '1') ? 'registered' : 'last_visit';
		
		if (isset($_POST['admmods_delete']) && $_POST['admmods_delete'] == '1')
		{
			$sql[] = 'group_id=?';
			$data[] = AURA_UNVERIFIED;
		}
		else
		{
			$groups = array();
			$aura_groups = $this->cache->get('groups');
			foreach ($aura_groups as $cur_group)
			{
				if ($cur_group['g_moderator'] == '1' || $cur_group['g_id'] == AURA_ADMIN)
				{
					$data[] = $cur_group['g_id'];
					$groups[] = '?';
				}
			}

			$sql[] = 'AND group_id NOT IN ('.implode(',', $groups).')';
		}

		if (isset($_POST['verified']) && $_POST['verified'] == '0')
		{
			$sql[] = 'group_id>?';
			$data[] = AURA_UNVERIFIED;
		}
		else
		{
			$sql[] = 'group_id=?';
			$data[] = AURA_UNVERIFIED;
		}

		$num_users = $this->db->delete('users', 'id>2 AND num_posts<? AND '.$prune.'<? '.implode(' AND ', $sql), $data);

		// This might have knocked some things out so we'll regenerate some caches ...
		$this->cache->generate('stats');
		$this->cache->generate('bans');
		$this->cache->generate('restrictions');

		$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['admin_maintenance']), $this->lang->t('Pruning complete message', $num_users));		
	}

	/**
	 * Adds a new user to the forum
	 */
	protected function add_user()
	{
		$this->registry->get('\auth\csrf')->confirm(config::ADMIN_DIR.'_maintenance');

		$errors = array();
		$username = isset($_POST['username']) ? utf8_trim($_POST['username']) : '';
		$random_pass = isset($_POST['random_pass']) && $_POST['random_pass'] == '1' ? 1 : 0;
		$email = isset($_POST['email']) ? strtolower(utf8_trim($_POST['email'])) : '';
		$password_salt = $this->registry->get('\auth\password')->generate(16);
		
		if ($random_pass == '1')
		{
			$password1 = $this->registry->get('\auth\password')->generate(12);
			$password2 = $password1;
		}
		else
		{
			$password1 = isset($_POST['password1']) ? utf8_trim($_POST['password1']) : '';
			$password2 = isset($_POST['password2']) ? utf8_trim($_POST['password2']) : '';
		}
		
		$this->lang->load('prof_reg');
		
		// Validate username and passwords
		$errors = $this->registry->get('\auth\register')->check_username($username, $errors);

		$errors = array_merge($errors, $this->registry->get('\auth\register')->validate_password($password1, $password2));

		// Validate email
		if (!is_valid_email($email))
			$errors[] = $this->lang->t('Invalid email');

		// Check if it's a banned email address
		if ($this->registry->get('\auth\bans')->is_banned_email($email))
		{
			if ($this->config['p_allow_banned_email'] == '0')
				$errors[] = $this->lang->t('Banned email');
		}
		
		if ($this->config['p_allow_dupe_email'] == '0')
		{
			$data = array(
				':email' => $email,
			);

			$ps = $this->db->select('users', 1, $data, 'email=:email');
			if ($ps->rowCount())
				$errors[] = $this->lang->t('Dupe email');
		}
		
		if (empty($errors))
		{
			// Insert the new user into the database. We do this now to get the last inserted ID for later user
			$initial_group_id = ($random_pass == 0) ? $this->config['o_default_user_group'] : AURA_UNVERIFIED;
			$password_hash = aura_hash($password1.$password_salt);
			
			// Add the user
			$insert = array(
				'username'	=>	$username,
				'group_id'	=>	$initial_group_id,
				'password'	=>	$password_hash,
				'salt'		=>	$password_salt,
				'email'		=>	$email,
				'email_setting'	=>	$this->config['o_default_email_setting'],
				'timezone'	=>	$this->config['o_default_timezone'],
				'dst'		=>	$this->config['o_default_dst'],
				'language'	=>	$this->config['o_default_lang'],
				'style'		=>	$this->config['o_default_style'],
				'registered'	=>	CURRENT_TIMESTAMP,
				'registration_ip'	=>	get_remote_address(),
				'last_visit'	=>	CURRENT_TIMESTAMP,
			);

			$this->db->insert('users', $insert);
			$new_uid = $this->db->lastInsertId($this->db->prefix.'users');

			if ($random_pass == '1')
			{
				$mail = new \email\email($this->registry);
				$info = array(
					'subject' => array(
						'<board_title>' => $this->config['o_board_title'],
					),
					'message' => array(
						'<base_url>' => $this->functions->get_base_url(),
						'<username>' => $username,
						'<password>' => $password1,
						'<login_url>' => $this->registry->get('\links')->aura_link($this->rewrite->url['login']),
					)
				);

				$mail_tpl = $this->registry->get('\email\parser')->parse_email('welcome', $this->user['language'], $info);
				$mail->send($email, $mail_tpl['subject'], $mail_tpl['message']);
			}

			// Regenerate the users info cache
			$this->cache->generate('stats');
			$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['admin_maintenance']), $this->lang->t('User created message'));
		}

		return $errors;
	}

	/**
	 * Fetch some data which is used on the maintenance index
	 */
	protected function fetch_index_data()
	{
		// Get the first post ID from the db
		$ps = $this->db->select('posts', 'id', array(), '', 'id ASC LIMIT 1');
		$first_id = ($ps->rowCount()) ? $ps->fetchColumn() : 0;

		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'groups',
				'as' => 'g',
				'on' => 'u.group_id=g.g_id',
			),
		);

		$options = array();
		$ps = $this->db->join('users', 'u', $join, 'u.id, u.username, g.g_title', array(), 'u.id!=1', 'u.id ASC');
		foreach ($ps as $result)
			$options[] = array('id' => $result['id'], 'username' => $result['username'], 'group_title' => $result['g_title']);

		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'forums',
				'as' => 'f',
				'on' => 'c.id=f.cat_id',
			),
		);

		$forums = $catgeories = array();
		$ps = $this->db->join('categories', 'c', $join, 'c.id AS cid, c.cat_name, f.id AS fid, f.forum_name', array(), 'f.redirect_url IS NULL', 'c.disp_position, c.id, f.disp_position');
		foreach ($ps as $cur_forum)
		{
			if (!isset($categories[$cur_forum['cid']]))
				$categories[$cur_forum['cid']] = array(
					'id' => $cur_forum['cid'],
					'name' => $cur_forum['cat_name'],
				);

			$forums[] = array(
				'category_id' => $cur_forum['cid'],
				'name' => $cur_forum['forum_name'],
				'id' => $cur_forum['fid'],
			);
		}

		return array($first_id, $options, $forums, $categories);
	}

	/**
	 * Configure a few things which we commonly use
	 */
	protected function configure_page()
	{
		$this->admin = new \admin\common($this->registry);

		if (!$this->user['is_admin'])
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		$this->admin->check_user('admin_maintenance');

		$this->registry->get('\auth\http_auth')->check_authentication();

		// Load the admin-maintenance language file
		$this->lang->load('admin_maintenance');

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Admin'), $this->lang->t('Maintenance')),
			'active_page' => 'admin',
			'admin_console' => true,
		);

		$this->template->footer = array(
			'admin_console' => true,
		);
	}
}