<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class permissions_controller extends base_controller
{
	/**
	 * Main class entry point
	 */
	public function execute()
	{
		$admin = new \admin\common($this->registry);

		if (!$this->user['is_admin'])
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		$admin->check_user('admin_permissions');

		$this->registry->get('\auth\http_auth')->check_authentication();

		// Load the admin-permissions language file
		$this->lang->load('admin_permissions');

		if (isset($_POST['form_sent']))
			$this->update_permissions();

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Admin'), $this->lang->t('Permissions')),
			'active_page' => 'admin',
			'admin_console' => true,
		);

		$this->template->footer = array(
			'admin_console' => true,
		);

		$tpl = $this->template->load('admin/permissions.tpl');
		$this->template->output($tpl,
			array(
				'admin_menu' => $admin->generate_menu('permissions'),
				'form_action' => $this->registry->get('\links')->aura_link($this->rewrite->url['admin_permissions']),
				'csrf_token' => $this->registry->get('\auth\csrf')->generate('admin_permissions'),
			)
		);
	}

	/**
	 * Here, we update all of the board permissions
	 */
	protected function update_permissions()
	{
		$this->registry->get('\auth\csrf')->confirm('admin_permissions');
		$form = isset($_POST['form']) && is_array($_POST['form']) ? array_map('intval', $_POST['form']) : array();
		foreach ($form as $key => $input)
		{
			// Make sure the input is never a negative value
			if($input < 0)
				$input = 0;

			// Only update values that have changed
			if (array_key_exists('p_'.$key, $this->config) && $this->config['p_'.$key] != $input)
			{
				$update = array(
					'conf_value' => $input,
				);
				
				$data = array(
					':conf_name' => 'p_'.$key,
				);
				
				$db->update('config', $update, 'conf_name=:conf_name', $data);
			}
		}

		// Regenerate the config cache
		$this->cache->generate('config', array($this->config));
		$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['admin_permissions']), $this->lang->t('Perms updated redirect'));
	}
}