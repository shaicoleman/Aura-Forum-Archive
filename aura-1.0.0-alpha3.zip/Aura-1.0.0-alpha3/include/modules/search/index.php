<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class index_controller extends base_controller
{
	/*
	 * Main entry point- display the searching form
	 */
	public function execute()
	{
		$this->registry->get('\extensions\hooks')->fire('search.immediate');

		$this->configure_search();
		list($categories, $forums) = $this->fetch_forums_list();

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Search')),
			'focus_element' => array('search', 'keywords'),
			'active_page' => 'search',
		);

		$this->template->header = $this->registry->get('\extensions\hooks')->fire('search.header', $this->template->header);
		$args = $this->registry->get('\extensions\hooks')->fire('search.render');
		$args = (is_array($args) ? $args : array());

		$tpl = $this->template->load('search.tpl');
		$this->template->output($tpl,
			array_merge(
				array(
					'form_action' => $this->registry->get('\links')->aura_link($this->rewrite->url['search']),
					'aura_user' => $this->user,
					'search_all_forums' => ($this->config['o_search_all_forums'] == '1' || $this->user['is_admmod']) ? true : false,
					'categories' => $categories,
					'forums' => $forums,
				),
				$args
			)
		);
	}

	/*
	 * Fetches the forums to display on the search index
	 */
	protected function fetch_forums_list()
	{
		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'forums',
				'as' => 'f',
				'on' => 'c.id=f.cat_id',
			),
			array(
				'type' => 'LEFT',
				'table' => 'forum_perms',
				'as' => 'fp',
				'on' => '(fp.forum_id=f.id AND fp.group_id=:gid)',
			),
		);

		$data = array(
			':gid' => $this->user['g_id'],
		);

		$categories = $forums = array();
		$ps = $this->db->join('categories', 'c', $join, 'c.id AS cid, c.cat_name, f.id AS fid, f.forum_name, f.password, f.redirect_url, f.parent_forum', $data, '(fp.read_forum IS NULL OR fp.read_forum=1) AND f.redirect_url IS NULL ORDER BY c.disp_position, c.id, f.disp_position');
		foreach ($ps as $cur_forum)
		{
			if ($cur_forum['password'] != '')
				if ($this->registry->get('\cookie\cookie')->check_forum_login_cookie($cur_forum['fid'], $cur_forum['password'], true) === false)
					continue;

			if (!isset($catgeories[$cur_forum['cid']])) // A new category since last iteration?
			{
				$categories[$cur_forum['cid']] = array(
					'name' => $cur_forum['cat_name'],
					'id' => $cur_forum['cid'],
				);

				$categories = $this->registry->get('\extensions\hooks')->fire('search.categories', $categories);
			}
			
			$forums[] = array(
				'parent_forum' => $cur_forum['parent_forum'],
				'category_id' => $cur_forum['cid'],
				'id' => $cur_forum['fid'],
				'name' => $cur_forum['forum_name'],
			);

			$forums = $this->registry->get('\extensions\hooks')->fire('search.forums', $forums);
		}

		return array($categories, $forums);
	}

	/*
	 * Setup and review a few things before we start
	 */
	protected function configure_search()
	{
		$this->lang->load('search');
		$this->lang->load('forum');

		if ($this->user['g_read_board'] == '0')
			$this->registry->get('\handlers\message')->show($this->lang->t('No view'), false, '403 Forbidden');
		else if ($this->user['g_search'] == '0')
			$this->registry->get('\handlers\message')->show($this->lang->t('No search permission'), false, '403 Forbidden');

		$this->registry->get('\extensions\hooks')->fire('search.configure');
	}
}