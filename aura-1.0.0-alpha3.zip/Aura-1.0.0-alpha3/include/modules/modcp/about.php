<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class about_controller extends base_controller
{
	/**
	 * Main App entry point
	 */
	public function execute()
	{
		$admin = new \admin\common($this->registry);

		if (($this->user['is_admmod'] && $this->user['g_mod_cp'] == '0' && !$this->user['is_admin']) || !$this->user['is_admmod'])
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		$this->registry->get('\auth\http_auth')->check_authentication();

		// Load the admin_about language file
		$this->lang->load('admin_about');

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Admin'), $this->lang->t('About')),
			'active_page' => 'admin',
			'admin_console' => true,
		);

		$this->template->footer = array(
			'admin_console' => true,
		);

		$tpl = $this->template->load('admin/about.tpl');
		$this->template->output($tpl,
			array(
				'admin_menu' => $admin->generate_menu('about'),
			)
		);
	}
}