<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class unapproved_controller extends base_controller
{
	public function execute()
	{
		$admin = new \admin\common($this->registry);

		if (!$this->user['is_admin'])
			$this->registry->get('\handlers\message')->show($this->lang->t('No permission'), false, '403 Forbidden');

		$this->registry->get('\auth\http_auth')->check_authentication();

		// Load the admin-posts language file
		$this->lang->load('admin_posts');

		// Setup the event handlers
		if (isset($_POST['post_id']))
			$this->handle_approval_status();

		// We fetch all the unapproved content
		$posts = $this->fetch_unapproved_content();

		$this->template->header = array(
			'page_title' => array($this->config['o_board_title'], $this->lang->t('Admin'), $this->lang->t('Posts')),
			'active_page' => 'admin',
			'admin_console' => true,
		);

		$this->template->footer = array(
			'admin_console' => true,
		);

		$tpl = $this->template->load('admin/posts.tpl');
		$this->template->output($tpl,
			array(
				'admin_menu' => $admin->generate_menu('posts'),
				'form_action' => $this->registry->get('\links')->aura_link($this->rewrite->url['admin_posts']),
				'csrf_token' => $this->registry->get('\auth\csrf')->generate('admin_posts'),
				'posts' => $posts,
			)
		);
	}

	/**
	 * Do we approve the content or delete it? Decide what we want to do ....
	 */
	protected function handle_approval_status()
	{
		$this->registry->get('\auth\csrf')->confirm('admin_posts');

		$post_id = intval(key($_POST['post_id']));
		$idx = $this->registry->get('\search\idx');
		$action = isset($_POST['action']) && is_array($_POST['action']) ? intval($_POST['action'][$post_id]) : '1';
		$data = array(
			':id' => $post_id
		);

		$join = array(
			array(
				'type' => 'LEFT',
				'table' => 'topics',
				'as' => 't',
				'on' => 'p.topic_id=t.id',
			),
			array(
				'type' => 'LEFT',
				'table' => 'forums',
				'as' => 'f',
				'on' => 't.forum_id=f.id',
			),
			array(
				'type' => 'LEFT',
				'table' => 'users',
				'as' => 'u',
				'on' => 'p.poster_id=u.id',
			),
			array(
				'type' => 'LEFT',
				'table' => 'groups',
				'as' => 'g',
				'on' => 'u.group_id=g.g_id',
			),
		);

		$ps = $this->db->join('posts', 'p', $join, 'p.posted, p.message, p.poster, p.poster_id, p.topic_id, p.poster_email, u.email, p.poster_ip, t.forum_id, t.subject, t.first_post_id, f.forum_name, u.num_posts, g.g_promote_next_group, g.g_promote_min_posts', $data, 'p.id=:id');
		$post = $ps->fetch();

		$is_topic_post = ($post_id == $post['first_post_id']) ? true : false;
		if ($action == '1')
		{
			$update = array(
				'approved' => 1,
			);
			
			$this->db->update('posts', $update, 'id=:id', $data);
			if ($is_topic_post)
			{
				$update = array(
					'approved' => 1,
				);

				$data = array(
					':id' => $post['topic_id'],
				);
				$this->db->update('topics', $update, 'id=:id', $data);

				$idx->update_search_index('post', $post_id, $post['message'], $post['subject']);

				$subscriptions = $this->registry->get('\subscriptions');
				$subscriptions->handle_forum_subscriptions($post, $post['poster'], $post['topic_id']);
			}
			else
			{
				// Just to be safe in case there has been another reply made since...
				$data = array(
					':id' => $post['topic_id']
				);

				$ps = $this->db->select('posts', 'id, poster, posted', $data, 'topic_id=:id AND approved=1 AND deleted=0', 'id DESC LIMIT 1');
				list($last_id, $poster, $posted) = $ps->fetch(PDO::FETCH_NUM);

				$data = array(
					':last_post'	=>	$posted,
					':last_post_id'	=>	$last_id,
					':poster'		=>	$poster,
					':id'			=>	$post['topic_id'],
				);

				$this->db->run('UPDATE '.$this->db->prefix.'topics SET num_replies=num_replies+1, last_post=:last_post, last_post_id=:last_post_id, last_poster=:poster WHERE id=:id', $data);
				$idx->update_search_index('post', $post_id, $post['message'], $post['subject']);

				$subscriptions = $this->registry->get('\subscriptions');
				$subscriptions->handle_topic_subscriptions($post['topic_id'], $post, $post['poster'], $post_id, $posted);
			}

			$data = array(
				':id' => $post['forum_id'],
			);

			$ps = $this->db->select('forums', 'increment_posts', $data, 'id=:id');
			$increment_posts = $ps->fetchColumn();
	
			if ($increment_posts == '1')
			{
				$data = array(
					':id'	=>	$post['poster_id'],
				);

				$this->db->run('UPDATE '.$this->db->prefix.'users SET num_posts=num_posts+1 WHERE id=:id', $data);
			
				// Promote this user to a new group if enabled
				if ($post['g_promote_next_group'] != 0 && $post['num_posts'] >= $post['g_promote_min_posts'])
				{
					$update = array(
						'group_id' => $post['g_promote_next_group'],
					);
					
					$data = array(
						':id' => $post['poster_id'],
					);
					
					$this->db->update('users', $update, 'id=:id', $data);
				}
			}

			$this->registry->get('\forum\forum')->update($post['forum_id']);
			$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['admin_posts']), $this->lang->t('Post approved redirect'));
		}
		else
		{
			if (($this->user['g_mod_sfs_report'] == '1' || $this->user['is_admin']) && $action == '3' && $this->config['o_sfs_api'] != '')
			{
				//If the user wasn't a guest we need to get the email from the users table
				$email = ($post['poster_email'] == '' && $post['poster_id'] != 1) ? $post['email'] : $post['poster_email'];

				//Reporting now made fun =)
				if (!$this->registry->get('\stopforumspam')->report($this->config['o_sfs_api'], $post['poster_ip'], $email, $post['poster'], $post['message']))
					$this->registry->get('\handlers\message')->show($this->lang->t('Unable to add spam data'));
			}

			if ($is_topic_post)
			{
				$this->registry->get('\topics\delete_topic')->delete_topic_comply($post['topic_id']);
				$this->registry->get('\forum\forum')->update($post['forum_id']);		
			}
			else
			{
				$this->registry->get('\topics\delete_post')->delete_post_comply($post_id, $post['topic_id']);
				$this->registry->get('\forum\forum')->update($post['forum_id']);
			}

			$this->registry->get('\handlers\redirect')->show($this->registry->get('\links')->aura_link($this->rewrite->url['admin_posts']), $this->lang->t('Post deleted redirect'));
		}
	}

	/**
	 * Fetch all unapproved content on the board
	 */
	protected function fetch_unapproved_content()
	{
		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'topics',
				'as' => 't',
				'on' => 'p.topic_id=t.id',
			),
			array(
				'type' => 'LEFT',
				'table' => 'forums',
				'as' => 'f',
				'on' => 't.forum_id=f.id',
			),
			array(
				'type' => 'LEFT',
				'table' => 'forum_perms',
				'as' => 'fp',
				'on' => '(fp.forum_id=f.id AND fp.group_id=:gid)',
			),
		);

		$data = array(
			':gid' => $this->user['g_id'],
		);

		$posts = array();
		$moderators = $this->cache->get('moderators');
		$parser = $this->registry->get('\message\parser');
		$ps = $this->db->join('posts', 'p', $join, 't.id AS topic_id, t.forum_id, p.poster, p.poster_id, p.posted, p.message, p.id AS pid, p.hide_smilies, t.subject, f.forum_name', $data, '(fp.read_forum IS NULL OR fp.read_forum=1) AND p.approved=0 AND p.deleted=0', 'p.posted DESC');
		foreach ($ps as $cur_post)
		{
			// Check if we can moderate this forum (if not, we shouldn't be approving posts for it!)
			if (!isset($moderators[$cur_post['forum_id']]['u'.$this->user['id']]) && !isset($moderators[$cur_post['forum_id']]['g'.$this->user['g_id']]) && !$this->user['is_admin'] && $this->user['g_global_moderator'] != 1)
				continue;

			$data = array(
				':id' => $cur_post['pid'],
			);

			$attachments = array();
			$ps1 = $this->db->select('attachments', 'id, filename, post_id, size, downloads', $data, 'post_id=:id');
			foreach ($ps1 as $cur_attach)
				$attachments[] = array('icon' => $this->registry->get('\topics\attachment')->attach_icon($this->registry->get('\topics\attachment')->attach_get_extension($cur_attach['filename'])), 'link' => $this->registry->get('\links')->aura_link($this->rewrite->url['attachment'], array($cur_attach['id'])), 'name' => $cur_attach['filename'], 'size' => $this->lang->t('Attachment size', $this->functions->file_size($cur_attach['size'])), 'downloads' => $this->lang->t('Attachment downloads', $this->functions->forum_number_format($cur_attach['downloads'])));

			$posts[] = array(
				'posted' => $this->registry->get('\aura_time')->format($cur_post['posted']),
				'poster' => ($cur_post['poster'] != '') ? array('href' => $this->registry->get('\links')->aura_link($this->rewrite->url['profile'], array($cur_post['poster_id'], \url\url::replace($cur_post['poster']))), 'poster' => $cur_post['poster']) : '',
				'message' => $parser->parse_message($cur_post['message'], $cur_post['hide_smilies']),
				'id' => $cur_post['pid'],
				'attachments' => $attachments,
				'forum' => ($cur_post['forum_name'] != '') ? array('href' => $this->registry->get('\links')->aura_link($this->rewrite->url['forum'], array($cur_post['forum_id'], \url\url::replace($cur_post['forum_name']))), 'forum_name' => $cur_post['forum_name']) : '',
				'topic' => ($cur_post['subject'] != '') ? array('href' => $this->registry->get('\links')->aura_link($this->rewrite->url['topic'], array($cur_post['topic_id'], \url\url::replace($cur_post['subject']))), 'subject' => $cur_post['subject']) : '',
				'post' => ($cur_post['pid'] != '') ? array('href' => $this->registry->get('\links')->aura_link($this->rewrite->url['post'], array($cur_post['pid'])), 'post' => $this->lang->t('Post ID', $cur_post['pid'])) : '',
			);
		}

		return $posts;
	}
}