<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */
 
if (!defined('config::SESSION'))
	exit;

class reputation_controller extends base_controller
{
	public function execute()
	{
		$this->registry->get('\extensions\hooks')->fire('reputation.immediate');

		registry::send_headers('plaintext');

		$vote = isset($_GET['vote']) ? intval($_GET['vote']) : '0';
		$id = isset($_GET['id']) ? intval($_GET['id']) : '0';

		if ($this->config['o_reputation'] == '0')
			exit($this->lang->t('reputation disabled'));

		if ($this->user['g_rep_enabled'] == '0')
			exit($this->lang->t('Group disabled'));

		if ($id < 1 || $vote == '0' || !defined('AURA_AJAX_REQUEST'))
			exit($this->lang->t('Bad request'));

		$this->registry->get('\auth\csrf')->confirm('viewtopic');

		$this->registry->get('\extensions\hooks')->fire('reputation.authorised');
		$data = array(
			':id' => $id,
		);

		$join = array(
			array(
				'type' => 'INNER',
				'table' => 'topics',
				'as' => 't',
				'on' => 'p.topic_id=t.id',
			),
			array(
				'type' => 'INNER',
				'table' => 'forums',
				'as' => 'f',
				'on' => 't.forum_id=f.id',
			),
		);

		$ps = $this->db->join('posts', 'p', $join, 'f.use_reputation, t.closed, t.archived, f.id, p.poster_id, p.reputation, p.poster', $data, 'p.id=:id');
		if (!$ps->rowCount())
			exit($this->lang->t('Bad request'));
		else
				$cur_forum = $ps->fetch();

		$cur_forum = $this->registry->get('\extensions\hooks')->fire('reputation.forum', $cur_forum);
		if ($cur_forum['archived'] == '1')
			exit($this->lang->t('archived message'));

		if ($cur_forum['use_reputation'] == '0')
			exit($this->lang->t('reputation forum disabled'));
					
		if ($cur_forum['closed'] == '1' && !$this->user['is_admmod'])
			exit($this->lang->t('topic closed'));

		if ($this->user['id'] == $cur_forum['poster_id'])
			exit($this->lang->t('no own votes'));
		
		if ($cur_forum['poster_id'] == 1)
			exit($this->lang->t('no guest votes'));		

		if ($this->user['g_rep_interval'] != '0')
		{
			$data = array(
				':id' => $this->user['id'],
				':time'	=> (CURRENT_TIMESTAMP - $this->user['g_rep_interval']),
			);

			$ps = $this->db->select('reputation', 'time_given', $data, 'given_by=:id AND time_given>:time');
			if ($ps->rowCount())
				exit($this->lang->t('Rep interval', $this->user['g_rep_interval'] - (CURRENT_TIMESTAMP - $ps->fetchColumn())));
		}

		if ($vote != '-1' && $vote != '1')
			exit($this->lang->t('Bad request'));

		if ($vote == '-1')
		{
			if ($this->config['o_rep_type'] == 2)
				exit($this->lang->t('invalid rep type'));

			$data = array(
				':uid' => $this->user['id'],
				':id' => $id,
			);

			$ps = $this->db->select('reputation', 1, $data, 'post_id=:id AND given_by=:uid AND vote=-1');
			if ($ps->rowCount())
				exit($this->lang->t('duplicate entry minus'));

			if ($this->user['g_rep_minus'] != '0')
			{
				$data = array(
					':id' => $this->user['id'],
					':time'	=> (CURRENT_TIMESTAMP - 86400),
				);

				$ps = $this->db->select('reputation', 'COUNT(id)', $data, 'given_by=:id AND vote=-1 AND time_given>:time');
				if ($ps->fetchColumn() > $this->user['g_rep_minus'])
					exit($this->lang->t('exceed negative reputation'));
			}

			$this->registry->get('\extensions\hooks')->fire('reputation.minusvote');
		}
		else
		{
			if ($this->config['o_rep_type'] == 3)
				exit($this->lang->t('invalid rep type'));

			$data = array(
				':uid' => $this->user['id'],
				':id' => $id,
			);

			$ps = $this->db->select('reputation', 1, $data, 'post_id=:id AND given_by=:uid AND vote=1');
			if ($ps->rowCount())
				exit($this->lang->t('duplicate entry positive'));

			if ($this->user['g_rep_plus'] != '0')
			{
				$data = array(
					':id'	=>	$this->user['id'],
					':time'	=>	(CURRENT_TIMESTAMP - 86400),
				);

				$ps = $this->db->select('reputation', 'COUNT(id)', $data, 'given_by=:id AND vote=1 AND time_given>:time');		
				if ($ps->fetchColumn() > $this->user['g_rep_plus'])
					exit($this->lang->t('exceed positive reputation'));
			}

			$this->registry->get('\extensions\hooks')->fire('reputation.plusvote');
		}

		// Handle any reputation abuse
		$this->handle_rep_abuse();

		// Has the user issue issued the opposite vote? If so, remove it first ...
		$opposite_rep = false;

		$data = array(
			':uid' => $this->user['id'],
			':id' => $id
		);

		$ps = $this->db->select('reputation', 1, $data, 'given_by=:uid AND post_id=:id');
		if ($ps->rowCount())
		{
			$opposite_rep = true;
			$vote_add = (($vote == '-1') ? '-1' : '+1');

			$data = array(
				':uid' => $this->user['id'],
				':id' => $id,
			);

			$this->db->delete('reputation', 'given_by=:uid AND post_id=:id', $data);
			$data = array(
				':id' => $id,
			);

			$this->db->run('UPDATE '.$this->db->prefix.'posts SET reputation=reputation'.$vote_add.' WHERE id=:id', $data);
			$data = array(
				':id' => $cur_forum['poster_id'],
			);

			$this->db->run('UPDATE '.$this->db->prefix.'users SET reputation=reputation'.$vote_add.' WHERE id=:id', $data);

			$this->registry->get('\extensions\hooks')->fire('reputation.oppositegiven');
		}

		$insert = array(
			'post_id'	=>	$id,
			'given_by'	=>	$this->user['id'], 
			'vote'		=>	(($vote == '-1') ? '-1' : '1'),
			'time_given'=>	CURRENT_TIMESTAMP,
		);

		$this->db->insert('reputation', $insert);

		$vote = (($vote == '-1') ? '-1' : '+1');

		$data = array(
			':id' => $cur_forum['poster_id'],
		);

		$this->db->run('UPDATE '.$this->db->prefix.'users SET reputation=reputation'.$vote.' WHERE id=:id', $data);

		$data = array(
			':id' => $id,
		);

		$this->db->run('UPDATE '.$this->db->prefix.'posts SET reputation=reputation'.$vote.' WHERE id=:id', $data);

		$this->db->end_transaction();

		if ($opposite_rep)
		{
			if ($vote == '-1')
				--$cur_forum['reputation'];
			else
				++$cur_forum['reputation'];		
		}

		if ($vote == '-1')
			--$cur_forum['reputation'];
		else
			++$cur_forum['reputation'];

		$this->registry->get('\extensions\hooks')->fire('reputation.beforeoutput');

		echo $cur_forum['reputation'];
	}

	protected function handle_rep_abuse()
	{
		if ($this->config['o_rep_abuse'] != 0)
		{
			$data = array(
				':id' => $this->user['id'],
				':limit' => $this->config['o_rep_abuse'],
			);
		
			$join = array(
				array(
					'type' => 'LEFT',
					'table' => 'posts',
					'as' => 'p',
					'on' => 'r.post_id=p.id',
				),
			);

			$ps = $this->db->join('reputation', 'r', $join, 'p.poster_id, r.vote, p.topic_id, r.id', $data, 'r.given_by=:id ORDER BY r.id DESC LIMIT :limit');
			if ($ps->rowCount())
			{
				$abuse = array('positive' => array(), 'negative' => array());
				foreach ($ps as $rep)
				{
					if ($rep['vote'] == '1') // It's a positive vote
					{
						if (array_key_exists($rep['poster_id'], $abuse['positive']))
							++$abuse['positive'][$rep['poster_id']];
						else
							$abuse['positive'][$rep['poster_id']] = '1';
					}
					else // We're issuing negative rep
					{
						if (array_key_exists($rep['poster_id'], $abuse['negative'])) // Have we already got a record of points issued for this user?
							++$abuse['negative'][$rep['poster_id']];
						else
							$abuse['negative'][$rep['poster_id']] = '1';
					}

					$this->registry->get('\extensions\hooks')->fire('reputation.abuse.fetch');
				}

				// Here, we need to get the user ID which is stored as the array key above, so a few filters are needed first ....
				$positive = (!empty($abuse['positive'])) ? array_search(max(array_values($abuse['positive'])), $abuse['positive']) : '0';
				$negative = (!empty($abuse['negative'])) ? array_search(max(array_values($abuse['negative'])), $abuse['negative']) : '0';
				$rep_abuse = ($positive < $negative) ? array('user' => $negative, 'votes' => $abuse['negative'][$negative], 'type' => 'negative') : array('user' => $positive, 'votes' => $abuse['positive'][$positive], 'type' => 'positive');

				if ($rep_abuse['votes'] >= $this->config['o_rep_abuse'] && $this->config['o_mailing_list'] != '')
				{
					// Bugfix: Ticket #WYU-860-98170 - Rep Abuse alerted incorrectly
					$data = array(
						':id' => $rep_abuse['user'],
					);

					$ps = $this->db->select('users', 'username', $data, 'id=:id');
					$username = $ps->fetchColumn();

					$email = new \email\email($this->config);
					$info = array(
						'message' => array(
							'<abuser>' => $this->user['username'],
							'<amount>' => $this->config['o_rep_abuse'],
							'<type>' => $rep_abuse['type'],
							'<user>' => $username,
							'<profile_url>' => $this->registry->get('\links')->aura_link($aura_url['profile_rep_received'], array($rep_abuse['user'])),
						)
					);

					$mail_tpl = $this->registry->get('\email\parser')->parse_email('rep_abuse', $this->user['language'], $info);
					$email->send($this->config['o_mailing_list'], $mail_tpl['subject'], $mail_tpl['message']);

					$this->registry->get('\extensions\hooks')->fire('reputation.abuse.notified');
				}
			}
		}
	}
}