<?php
if (!defined('INSTALL_ROOT'))
	exit;

class install
{
	/**
	 * The installation steps for the forum
	 */
	public $steps = array(
		'create_tables',
		'groups',
		'users',
		'ranks',
		'smilies',
		'tasks',
		'config',
		'folders',
		'forum',
		'topic',
		'cache',
		'languages',
		'generate_config',
	);

	/**
	 * The language strings for each respective installation step above
	 */
	public $ajax_lang = array(
		'Inserting groups',
		'Inserting users',
		'Inserting ranks',
		'Inserting smilies',
		'Inserting tasks',
		'Inserting config',
		'Inserting folders',
		'Inserting forum',
		'Inserting topic',
		'Caching database',
		'Caching languages',
		'Generating config',
	);

	/**
	 * Instantiate objects which are used during the installation
	 */
	public function __construct($registry, $data)
	{
		$this->registry = $registry;
		$this->db = $registry->db;
		$this->lang = $registry->lang;
		$this->data = $data;
		$registry->functions = $this->registry->functions = new functions($registry); // Yuck. Not nice at all :(
		$this->cache = $this->registry->cache = new \cache\cache($registry);
	}

	/**
	 * Create the database tables for the forum
	 */
	public function create_tables()
	{
		// Create all tables
		$schema = array(
				'FIELDS'			=> array(
						'id'				=> array(
								'datatype'			=> 'INT(10) UNSIGNED AUTO_INCREMENT',
								'allow_null'    	=> false
						),
						'admin_id'			=> array(
								'datatype'			=> 'INT(10)',
								'allow_null'		=> false,
								'default'			=> '0'
						),
						'restrictions'		=> array(
								'datatype'			=> 'TEXT',
								'allow_null'		=> false,
						),
				),
				'PRIMARY KEY'		=> array('id'),
		);	
		
		$this->db->create_table('restrictions', $schema);
		
		$schema = array(
				'FIELDS'			=> array(
						'id'				=> array(
								'datatype'			=> 'VARCHAR(50)',
								'allow_null'    	=> false
						),
						'title'			=> array(
								'datatype'			=> 'VARCHAR(70)',
								'allow_null'		=> false,
								'default'			=> '\'\''
						),
						'unique_name'		=> array(
								'datatype'			=> 'VARCHAR(50)',
								'allow_null'		=> false,
								'default'			=> '\'\''
						),
						'version'		=> array(
								'datatype'			=> 'VARCHAR(25)',
								'allow_null'		=> false,
								'default'			=> '\'\''
						),
						'description'		=> array(
								'datatype'			=> 'TEXT',
								'allow_null'		=> true,
						),
						'author'		=> array(
								'datatype'			=> 'VARCHAR(50)',
								'allow_null'		=> false,
								'default'			=> '\'\''
						),
						'uninstall'		=> array(
								'datatype'			=> 'TEXT',
								'allow_null'		=> true,
						),
						'uninstall_note'		=> array(
								'datatype'			=> 'TEXT',
								'allow_null'		=> true,
						),
						'enabled'		=> array(
								'datatype'			=> 'TINYINT(1)',
								'allow_null'		=> false,
								'default'			=> '0'
						),
				),
				'PRIMARY KEY'		=> array('id'),
				'UNIQUE KEYS'	=> array(
					'unique_name_idx'	=> array('unique_name')
				),
		);	

		$this->db->create_table('extensions', $schema);
		
		$schema = array(
				'FIELDS'			=> array(
						'id'				=> array(
								'datatype'			=> 'INT(10) UNSIGNED AUTO_INCREMENT',
								'allow_null'    	=> false
						),
						'owner'	=> array(
								'datatype'			=> 'INT(10)',
								'allow_null'		=> false,
								'default'		=> '0'
						),
						'post_id'	=> array(
								'datatype'			=> 'INT(10)',
								'allow_null'		=> false,
								'default'		=> '0'
						),
						'filename'	=> array(
								'datatype'			=> 'VARCHAR(255)',
								'allow_null'		=> false,
						),
						'extension'		=> array(
								'datatype'			=> 'VARCHAR(64)',
								'allow_null'		=> false,
						),
						'mime'	=> array(
								'datatype'			=> 'VARCHAR(64)',
								'allow_null'		=> false
						),
						'location'	=> array(
								'datatype'			=> 'TEXT',
								'allow_null'		=> false
						),
						'size'	=> array(
								'datatype'		=> 'INT(10)',
								'allow_null'	=> false,
								'default'		=> '0'
						),
						'downloads'	=> array(
								'datatype'			=> 'INT(10)',
								'allow_null'		=> false,
								'default'		=> '0'
						)
				),
				'PRIMARY KEY'		=> array('id'),
		);

		$this->db->create_table('attachments', $schema);

		$schema = array(
			'FIELDS'		=> array(
				'id'			=> array(
					'datatype'		=> 'INT(10) UNSIGNED AUTO_INCREMENT',
					'allow_null'	=> false
				),
				'username'		=> array(
					'datatype'		=> 'VARCHAR(200)',
					'allow_null'	=> true
				),
				'ip'			=> array(
					'datatype'		=> 'VARCHAR(255)',
					'allow_null'	=> true
				),
				'email'			=> array(
					'datatype'		=> 'VARCHAR(80)',
					'allow_null'	=> true
				),
				'message'		=> array(
					'datatype'		=> 'VARCHAR(255)',
					'allow_null'	=> true
				),
				'expire'		=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> true
				),
				'ban_creator'	=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				)
			),
			'PRIMARY KEY'	=> array('id'),
			'INDEXES'		=> array(
				'username_idx'	=> array('username(25)')
			)
		);

		$this->db->create_table('bans', $schema);

		$schema = array(
			'FIELDS'		=> array(
				'id'			=> array(
					'datatype'		=> 'INT(10) UNSIGNED AUTO_INCREMENT',
					'allow_null'	=> false
				),
				'cat_name'		=> array(
					'datatype'		=> 'VARCHAR(80)',
					'allow_null'	=> false,
					'default'		=> '\'New Category\''
				),
				'disp_position'	=> array(
					'datatype'		=> 'INT(10)',
					'allow_null'	=> false,
					'default'		=> '0'
				)
			),
			'PRIMARY KEY'	=> array('id')
		);

		$this->db->create_table('categories', $schema);


		$schema = array(
			'FIELDS'		=> array(
				'id'			=> array(
					'datatype'		=> 'INT(10) UNSIGNED AUTO_INCREMENT',
					'allow_null'	=> false
				),
				'search_for'	=> array(
					'datatype'		=> 'VARCHAR(60)',
					'allow_null'	=> false,
					'default'		=> '\'\''
				),
				'replace_with'	=> array(
					'datatype'		=> 'VARCHAR(60)',
					'allow_null'	=> false,
					'default'		=> '\'\''
				)
			),
			'PRIMARY KEY'	=> array('id')
		);

		$this->db->create_table('censoring', $schema);
		
		$schema = array(
			'FIELDS'		=> array(
				'id'			=> array(
					'datatype'		=> 'INT(10) UNSIGNED AUTO_INCREMENT',
					'allow_null'	=> false
				),
				'question'	=> array(
					'datatype'		=> 'VARCHAR(90)',
					'allow_null'	=> false,
					'default'		=> '\'\''
				),
				'answer'	=> array(
					'datatype'		=> 'VARCHAR(60)',
					'allow_null'	=> false,
					'default'		=> '\'\''
				)
			),
			'PRIMARY KEY'	=> array('id')
		);

		$this->db->create_table('robots', $schema);

		$schema = array(
			'FIELDS'		=> array(
				'conf_name'		=> array(
					'datatype'		=> 'VARCHAR(255)',
					'allow_null'	=> false,
					'default'		=> '\'\''
				),
				'conf_value'	=> array(
					'datatype'		=> 'TEXT',
					'allow_null'	=> true
				)
			),
			'PRIMARY KEY'	=> array('conf_name')
		);

		$this->db->create_table('config', $schema);


		$schema = array(
			'FIELDS'		=> array(
				'group_id'		=> array(
					'datatype'		=> 'INT(10)',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'forum_id'		=> array(
					'datatype'		=> 'INT(10)',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'read_forum'	=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '1'
				),
				'post_replies'	=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '1'
				),
				'post_topics'	=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '1'
				),
				'post_polls'	=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '1'
				),
				'upload'		=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '1'
				),
				'download'	=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '1'
				),
				'delete_files'	=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '1'
				)
			),
			'PRIMARY KEY'	=> array('group_id', 'forum_id')
		);

		$this->db->create_table('forum_perms', $schema);

		$schema = array(
			'FIELDS'		=> array(
				'id'			=> array(
					'datatype'		=> 'INT(10) UNSIGNED AUTO_INCREMENT',
					'allow_null'	=> false
				),
				'forum_name'	=> array(
					'datatype'		=> 'VARCHAR(80)',
					'allow_null'	=> false,
					'default'		=> '\'New forum\''
				),
				'forum_desc'	=> array(
					'datatype'		=> 'TEXT',
					'allow_null'	=> true
				),
				'redirect_url'	=> array(
					'datatype'		=> 'VARCHAR(100)',
					'allow_null'	=> true
				),
				'show_post_info'	=> array(
					'datatype'		=> 'INT(1) UNSIGNED',
					'allow_null'	=> false,
					'default'		=>	'1',
				),
				'num_topics'	=> array(
					'datatype'		=> 'MEDIUMINT(8) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'num_posts'		=> array(
					'datatype'		=> 'MEDIUMINT(8) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'last_post'		=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> true
				),
				'last_post_id'	=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> true
				),
				'last_poster'	=> array(
					'datatype'		=> 'VARCHAR(200)',
					'allow_null'	=> true
				),
				'last_topic'	=> array(
					'datatype'		=> 'VARCHAR(200)',
					'allow_null'	=> true
				),
				'last_topic_id'	=> array(
					'datatype'		=> 'INT(10)',
					'allow_null'	=> true
				),
				'use_reputation'	=> array(
					'datatype'		=> 'INT',
					'allow_null'	=> false,
					'default'		=> '1'
				),
				'sort_by'		=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'disp_position'	=> array(
					'datatype'		=> 'INT(10)',
					'allow_null'	=> false,
					'default'		=>	'0'
				),
				'cat_id'		=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=>	'0'
				),
				'force_approve'		=> array(
					'datatype'		=> 'TINYINT(1) UNSIGNED',
					'allow_null'	=> false,
					'default'		=>	'0'
				),
				'quickjump'		=> array(
					'datatype'		=> 'TINYINT(1) UNSIGNED',
					'allow_null'	=> false,
					'default'		=>	'1'
				),
				'protected'		=> array(
					'datatype'		=> 'TINYINT(1) UNSIGNED',
					'allow_null'	=> false,
					'default'		=>	'0'
				),
				'increment_posts'		=> array(
					'datatype'		=> 'TINYINT(1) UNSIGNED',
					'allow_null'	=> false,
					'default'		=>	'1'
				),
				'parent_forum'		=> array(
					'datatype'		=> 'TINYINT(1) UNSIGNED',
					'allow_null'	=> false,
					'default'		=>	'0'
				),
				'password'		=> array(
					'datatype'		=> 'VARCHAR(128)', // 128 characters in length for the sha512 hash
					'allow_null'	=> false,
					'default'		=>	'\'\''
				),
				'salt'		=> array(
					'datatype'		=> 'VARCHAR(16)',
					'allow_null'	=> false,
					'default'		=>	'\'\''
				),
			),
			'PRIMARY KEY'	=> array('id')
		);

		$this->db->create_table('forums', $schema);

		$schema = array(
			'FIELDS'		=> array(
				'forum_id'			=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default' 		=> 0,
				),
				'user_id'			=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default' 		=> 0,
				),
				'username'	=> array(
					'datatype'		=> 'VARCHAR(200)',
					'allow_null'	=> false,
					'default'		=> '\'\''
				),
				'group_id'			=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default' 		=> 0,
				),
				'group_title'	=> array(
					'datatype'		=> 'VARCHAR(50)',
					'allow_null'	=> false,
					'default'		=> '\'\''
				)
			)
		);

		$this->db->create_table('moderators', $schema);

		$schema = array(
			'FIELDS'		=> array(
				'g_id'						=> array(
					'datatype'		=> 'INT(10) UNSIGNED AUTO_INCREMENT',
					'allow_null'	=> false
				),
				'g_title'					=> array(
					'datatype'		=> 'VARCHAR(50)',
					'allow_null'	=> false,
					'default'		=> '\'\''
				),
				'g_user_title'				=> array(
					'datatype'		=> 'VARCHAR(50)',
					'allow_null'	=> true
				),
				'g_image'			=> array(
					'datatype'		=> 'VARCHAR(3)',
					'allow_null'	=> false,
					'default'		=> '\'\''
				),
				'g_promote_min_posts'		=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'g_promote_next_group'		=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'g_moderator'				=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'g_mod_cp'				=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'g_admin'				=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'g_global_moderator'=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '0'
				),			
				'g_mod_edit_users'			=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'g_mod_rename_users'		=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'g_mod_change_passwords'	=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'g_mod_ban_users'			=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'g_mod_warn_users'			=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'g_mod_edit_admin_posts'	=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'g_mod_promote_users'			=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'g_mod_sfs_report'			=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'g_read_board'				=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '1'
				),
				'g_view_users'				=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '1'
				),
				'g_post_replies'			=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '1'
				),
				'g_post_topics'				=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '1'
				),
				'g_post_polls'				=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '1'
				),
				'g_edit_posts'				=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '1'
				),
				'g_edit_polls'				=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '1'
				),
				'g_edit_subject'			=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '1'
				),
				'g_edit_pm_subject'			=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '1'
				),
				'g_deledit_interval'	=> array(
					'datatype'		=> 'INT(10)',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'g_delete_posts'			=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '1'
				),
				'g_delete_topics'			=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '1'
				),
				'g_post_links'				=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '1'
				),
				'g_subject_links'			=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '1'
				),
				'g_post_images'				=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '1'
				),
				'g_set_title'				=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '1'
				),
				'g_search'					=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '1'
				),
				'g_search_users'			=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '1'
				),
				'g_send_email'				=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '1'
				),
				'g_rep_enabled'				=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '1'
				),
				'g_rep_interval'			=> array(
					'datatype'		=> 'INT(10)',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'g_rep_plus'			=> array(
					'datatype'		=> 'INT(10)',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'g_rep_minus'			=> array(
					'datatype'		=> 'INT(10)',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'g_post_flood'				=> array(
					'datatype'		=> 'SMALLINT(6)',
					'allow_null'	=> false,
					'default'		=> '30'
				),
				'g_robot_test'				=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'g_search_flood'			=> array(
					'datatype'		=> 'SMALLINT(6)',
					'allow_null'	=> false,
					'default'		=> '30'
				),
				'g_email_flood'				=> array(
					'datatype'		=> 'SMALLINT(6)',
					'allow_null'	=> false,
					'default'		=> '60'
				),
				'g_report_flood'			=> array(
					'datatype'		=> 'SMALLINT(6)',
					'allow_null'	=> false,
					'default'		=> '60'
				),
				'g_colour'			=> array(
					'datatype'		=> 'VARCHAR(15)',
					'allow_null'	=> true,
				),
				'g_moderate_posts'			=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'g_pm_limit'		=> array(
					'datatype'		=> 'SMALLINT(3)',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'g_use_pm'				=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'g_pm_folder_limit'		=> array(
					'datatype'		=> 'INT(3)',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'g_attach_files'		=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'g_max_attachments'		=> array(
					'datatype'		=> 'INT(10)',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'g_max_size'			=> array(
					'datatype'		=> 'INT(10)',
					'allow_null'	=> false,
					'default'		=> '0'
				)
			),
			'PRIMARY KEY'	=> array('g_id')
		);

		$this->db->create_table('groups', $schema);

		$schema = array(
			'FIELDS'		=> array(
				'user_id'		=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '1'
				),
				'ident'			=> array(
					'datatype'		=> 'VARCHAR(200)',
					'allow_null'	=> false,
					'default'		=> '\'\''
				),
				'logged'		=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'idle'			=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'last_post'			=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> true
				),
				'last_search'		=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> true
				),
				'currently'		=> array(
					'datatype'		=> 'TEXT',
					'allow_null'	=> true
				),
			),
			'UNIQUE KEYS'	=> array(
				'user_id_ident_idx'	=> array('user_id', 'ident(25)')
			),
			'INDEXES'		=> array(
				'ident_idx'		=> array('ident(25)'),
				'logged_idx'	=> array('logged')
			)
		);

		$this->db->create_table('online', $schema);
		
		$schema = array(
			'FIELDS' => array(
				'id' => array(
					'datatype' => 'INT(10) UNSIGNED AUTO_INCREMENT',
					'allow_null' => false
				),
				'user_id' => array(
					'datatype' => 'INT(10)',
					'allow_null' => false,
					'default' => '0'
				),
				'block_id' => array(
					'datatype' => 'INT(10)',
					'allow_null' => false,
					'default' => '0'
				),
			),
			'PRIMARY KEY' => array('id')
		);
		$this->db->create_table('blocks', $schema);

		$schema = array(
			'FIELDS'		=> array(
				'id'			=> array(
					'datatype'		=> 'INT(10) UNSIGNED AUTO_INCREMENT',
					'allow_null'	=> false
				),
				'poster'		=> array(
					'datatype'		=> 'VARCHAR(200)',
					'allow_null'	=> false,
					'default'		=> '\'\''
				),
				'poster_id'		=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '1'
				),
				'poster_ip'		=> array(
					'datatype'		=> 'VARCHAR(39)',
					'allow_null'	=> true
				),
				'poster_email'	=> array(
					'datatype'		=> 'VARCHAR(80)',
					'allow_null'	=> true
				),
				'message'		=> array(
					'datatype'		=> 'MEDIUMTEXT',
					'allow_null'	=> true
				),
				'reputation'	=> array(
					'datatype'		=> 'INT',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'approved'		=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '1'
				),
				'deleted'		=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'hide_smilies'	=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'posted'		=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'edited'		=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> true
				),
				'edit_reason'		=> array(
					'datatype'		=> 'VARCHAR(50)',
					'allow_null'	=> true
				),
				'edited_by'		=> array(
					'datatype'		=> 'VARCHAR(200)',
					'allow_null'	=> true
				),
				'topic_id'		=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				)
			),
			'PRIMARY KEY'	=> array('id'),
			'INDEXES'		=> array(
				'topic_id_idx'	=> array('topic_id'),
				'multi_idx'		=> array('poster_id', 'topic_id')
			)
		);

		$this->db->create_table('posts', $schema);

		$schema = array(
			'FIELDS'		=> array(
				'id'			=> array(
					'datatype'		=> 'INT(10) UNSIGNED AUTO_INCREMENT',
					'allow_null'	=> false
				),
				'post_id'		=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'topic_id'		=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'forum_id'		=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'reported_by'	=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'created'		=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'message'		=> array(
					'datatype'		=> 'TEXT',
					'allow_null'	=> true
				),
				'zapped'		=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> true
				),
				'zapped_by'		=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> true
				)
			),
			'PRIMARY KEY'	=> array('id'),
			'INDEXES'		=> array(
				'zapped_idx'	=> array('zapped')
			)
		);

		$this->db->create_table('reports', $schema);

		$schema = array(
				'FIELDS'		=> array(
					'id'			=> array(
						'datatype'		=> 'INT(10) UNSIGNED AUTO_INCREMENT',
						'allow_null'	=> false,
					),
					'post_id'		=> array(
						'datatype'		=> 'INT UNSIGNED',
						'allow_null'	=> false,
						'default'		=> '\'0\'',
					),
					'vote'			=> array(
						'datatype'		=> 'INT(2)',
						'allow_null'	=> false,
						'default'		=> '\'0\'',
					),
					'given_by'			=> array(
						'datatype'		=> 'INT UNSIGNED',
						'allow_null'	=> false,
						'default'		=> '\'0\'',
					),
					'time_given'			=> array(
						'datatype'		=> 'INT (10) UNSIGNED',
						'allow_null'	=> false,
						'default'		=> '\'0\'',
					),
				),
				'PRIMARY KEY'	=> array('id'),
			);
		
		$this->db->create_table('reputation', $schema);
		
		$schema = array(
			'FIELDS'		=> array(
				'id'			=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'ident'			=> array(
					'datatype'		=> 'VARCHAR(200)',
					'allow_null'	=> false,
					'default'		=> '\'\''
				),
				'search_data'	=> array(
					'datatype'		=> 'MEDIUMTEXT',
					'allow_null'	=> true
				)
			),
			'PRIMARY KEY'	=> array('id'),
			'INDEXES'		=> array(
				'ident_idx'	=> array('ident(8)')
			)
		);

		$this->db->create_table('search_cache', $schema);

		$schema = array(
			'FIELDS'		=> array(
				'post_id'		=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'word_id'		=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'subject_match'	=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '0'
				)
			),
			'INDEXES'		=> array(
				'word_id_idx'	=> array('word_id'),
				'post_id_idx'	=> array('post_id')
			)
		);

		$this->db->create_table('search_matches', $schema);

		$schema = array(
			'FIELDS'		=> array(
				'id'			=> array(
					'datatype'		=> 'INT(10) UNSIGNED AUTO_INCREMENT',
					'allow_null'	=> false
				),
				'word'			=> array(
					'datatype'		=> 'VARCHAR(20)',
					'allow_null'	=> false,
					'default'		=> '\'\'',
					'collation'		=> 'bin'
				)
			),
			'PRIMARY KEY'	=> array('word'),
			'INDEXES'		=> array(
				'id_idx'	=> array('id')
			)
		);

		$this->db->create_table('search_words', $schema);

		$schema = array(
			'FIELDS'		=> array(
				'user_id'		=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'topic_id'		=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				)
			),
			'PRIMARY KEY'	=> array('user_id', 'topic_id')
		);

		$this->db->create_table('topic_subscriptions', $schema);

		$schema = array(
			'FIELDS'		=> array(
				'user_id'		=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'forum_id'		=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				)
			),
			'PRIMARY KEY'	=> array('user_id', 'forum_id')
		);

		$this->db->create_table('forum_subscriptions', $schema);
		
		$schema = array(
			'FIELDS'		=> array(
				'id'			=> array(
					'datatype'		=> 'INT(10) UNSIGNED AUTO_INCREMENT',
					'allow_null'	=> false
				),
				'poster'		=> array(
					'datatype'		=> 'VARCHAR(200)',
					'allow_null'	=> false,
					'default'		=> '\'\''
				),
				'poster_id'		=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '1'
				),
				'poster_ip'		=> array(
					'datatype'		=> 'VARCHAR(39)',
					'allow_null'	=> true
				),
				'message'		=> array(
					'datatype'		=> 'TEXT',
					'allow_null'	=> true
				),
				'hide_smilies'	=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'posted'		=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'edited'		=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> true
				),
				'edited_by'		=> array(
					'datatype'		=> 'VARCHAR(200)',
					'allow_null'	=> true
				),
				'topic_id'		=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				)
			),
			'PRIMARY KEY'	=> array('id'),
			'INDEXES'		=> array(
				'topic_id_idx'	=> array('topic_id'),
			)
		);

		$this->db->create_table('messages', $schema);

		$schema = array(
			'FIELDS'		=> array(
				'id'			=> array(
					'datatype'		=> 'INT(10) UNSIGNED AUTO_INCREMENT',
					'allow_null'	=> false
				),
				'subject'		=> array(
					'datatype'		=> 'VARCHAR(255)',
					'allow_null'	=> false,
					'default'		=> '\'\''
				),
				'first_post_id'	=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'poster'	=> array(
					'datatype'		=> 'VARCHAR(200)',
					'allow_null'	=> false,
					'default'		=> '\'\''
				),
				'poster_id'	=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'num_replies'	=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'last_post'	=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'last_post_id'	=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'last_poster'		=> array(
					'datatype'		=> 'VARCHAR(200)',
					'allow_null'	=> false,
					'default'		=> '\'\''
				),
			),
			'PRIMARY KEY'	=> array('id'),
		);

		$this->db->create_table('conversations', $schema);
		
		$schema = array(
			'FIELDS'		=> array(
				'topic_id'			=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false
				),
				'user_id'		=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'deleted'	=> array(
					'datatype'		=> 'TINYINT(1) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'viewed'	=> array(
					'datatype'		=> 'TINYINT(1) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'folder_id'	=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '2'
				),
			),
			'PRIMARY KEY'	=> array('user_id', 'topic_id'),
			'INDEXES'		=> array(
				'folder_idx'		=> array('folder_id'),
			)
		);

		$this->db->create_table('pms_data', $schema);
		
		$schema = array(
			'FIELDS'		=> array(
				'id'			=> array(
					'datatype'		=> 'INT(10) UNSIGNED AUTO_INCREMENT',
					'allow_null'	=> false
				),
				'name'		=> array(
					'datatype'		=> 'VARCHAR(100)',
					'allow_null'	=> false,
					'default'		=> '\'New Folder\''
				),
				'user_id'	=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
			),
			'PRIMARY KEY'	=> array('id'),
			'INDEXES'		=> array(
				'user_idx'		=> array('user_id'),
			)
		);

		$this->db->create_table('folders', $schema);

		$schema = array(
			'FIELDS'		=> array(
				'id'			=> array(
					'datatype'		=> 'INT(10) UNSIGNED AUTO_INCREMENT',
					'allow_null'	=> false
				),
				'poster'		=> array(
					'datatype'		=> 'VARCHAR(200)',
					'allow_null'	=> false,
					'default'		=> '\'\''
				),
				'subject'		=> array(
					'datatype'		=> 'VARCHAR(255)',
					'allow_null'	=> false,
					'default'		=> '\'\''
				),
				'question'		=> array(
					'datatype'		=> 'VARCHAR(255)',
					'allow_null'	=> false,
					'default'		=> '\'\''
				),
				'posted'		=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'first_post_id'	=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'last_post'		=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'last_post_id'	=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'last_poster'	=> array(
					'datatype'		=> 'VARCHAR(200)',
					'allow_null'	=> true
				),
				'num_views'		=> array(
					'datatype'		=> 'MEDIUMINT(8) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'num_replies'	=> array(
					'datatype'		=> 'MEDIUMINT(8) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'closed'		=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'sticky'		=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'archived'		=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'deleted'		=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'moved_to'		=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> true
				),
				'forum_id'		=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'approved'		=> array(
					'datatype'		=> 'TINYINT(1) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '1'
				)
			),
			'PRIMARY KEY'	=> array('id'),
			'INDEXES'		=> array(
				'forum_id_idx'		=> array('forum_id'),
				'moved_to_idx'		=> array('moved_to'),
				'last_post_idx'		=> array('last_post'),
				'first_post_id_idx'	=> array('first_post_id'),
				'approved_idx'	=> array('approved'),
				'deleted_idx'	=> array('deleted'),
			)
		);

		$this->db->create_table('topics', $schema);
		
		$schema = array(
			'FIELDS'		=> array(
				'id'			=> array(
					'datatype'		=> 'INT(10) UNSIGNED AUTO_INCREMENT',
					'allow_null'	=> false
				),
				'topic_id'		=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'options'		=> array(
					'datatype'		=> 'MEDIUMTEXT',
					'allow_null'	=> false,
				),
				'voters'		=> array(
					'datatype'		=> 'MEDIUMTEXT',
					'allow_null'	=> false,
				),
				'votes'		=> array(
					'datatype'		=> 'MEDIUMTEXT',
					'allow_null'	=> false,
				),
				'type'	=> array(
					'datatype'		=> 'TINYINT(1) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'posted'	=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
			),
			'PRIMARY KEY'	=> array('id'),
			'UNIQUE KEYS'	=> array(
				'topic_id_idx'	=> array('topic_id') // Speed up gathering results in viewtopic
			),
		);
		
		$this->db->create_table('polls', $schema);

		$schema = array(
			'FIELDS'		=> array(
				'id'				=> array(
					'datatype'		=> 'INT(10) UNSIGNED AUTO_INCREMENT',
					'allow_null'	=> false
				),
				'group_id'			=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '3'
				),
				'username'			=> array(
					'datatype'		=> 'VARCHAR(200)',
					'allow_null'	=> false,
					'default'		=> '\'\''
				),
				'password'			=> array(
					'datatype'		=> 'VARCHAR(128)',
					'allow_null'	=> false,
					'default'		=> '\'\''
				),
				'password_changed'	=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'salt'			=> array(
					'datatype'		=> 'VARCHAR(16)',
					'allow_null'	=> false,
					'default'		=> '\'\''
				),
				'email'				=> array(
					'datatype'		=> 'VARCHAR(80)',
					'allow_null'	=> false,
					'default'		=> '\'\''
				),
				'title'				=> array(
					'datatype'		=> 'VARCHAR(50)',
					'allow_null'	=> true
				),
				'realname'			=> array(
					'datatype'		=> 'VARCHAR(40)',
					'allow_null'	=> true
				),
				'url'				=> array(
					'datatype'		=> 'VARCHAR(100)',
					'allow_null'	=> true
				),
				'facebook'			=> array(
					'datatype'		=> 'VARCHAR(50)',
					'allow_null'	=> true
				),
				'steam'				=> array(
					'datatype'		=> 'VARCHAR(50)',
					'allow_null'	=> true
				),
				'skype'				=> array(
					'datatype'		=> 'VARCHAR(80)',
					'allow_null'	=> true
				),
				'twitter'			=> array(
					'datatype'		=> 'VARCHAR(50)',
					'allow_null'	=> true
				),
				'google'			=> array(
					'datatype'		=> 'VARCHAR(50)',
					'allow_null'	=> true
				),
				'location'			=> array(
					'datatype'		=> 'VARCHAR(30)',
					'allow_null'	=> true
				),
				'signature'			=> array(
					'datatype'		=> 'TEXT',
					'allow_null'	=> true
				),
				'disp_topics'		=> array(
					'datatype'		=> 'TINYINT(3) UNSIGNED',
					'allow_null'	=> true
				),
				'disp_posts'		=> array(
					'datatype'		=> 'TINYINT(3) UNSIGNED',
					'allow_null'	=> true
				),
				'email_setting'		=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '1'
				),
				'notify_with_post'	=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'auto_notify'		=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'pm_notify'		=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'show_smilies'		=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '1'
				),
				'show_img'			=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '1'
				),
				'show_img_sig'		=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '1'
				),
				'show_avatars'		=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '1'
				),
				'show_sig'			=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '1'
				),
				'timezone'			=> array(
					'datatype'		=> 'FLOAT',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'dst'				=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'time_format'		=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'date_format'		=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'language'			=> array(
					'datatype'		=> 'VARCHAR(5)',
					'allow_null'	=> false,
					'default'		=> '\''.installation::DEFAULT_LANG.'\'',
				),
				'style'				=> array(
					'datatype'		=> 'VARCHAR(25)',
					'allow_null'	=> false,
					'default'		=> '\''.installation::DEFAULT_STYLE.'\'',
				),
				'num_posts'			=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'num_pms'			=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'pm_enabled'		=> array(
					'datatype'		=> 'TINYINT(1) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '1'
				),
				'use_editor'		=> array(
					'datatype'		=> 'TINYINT(1) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '1'
				),
				'use_gravatar'		=> array(
					'datatype'		=> 'TINYINT(1) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'last_post'			=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> true
				),
				'last_search'		=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> true
				),
				'last_email_sent'	=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> true
				),
				'last_report_sent'	=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> true
				),
				'registered'		=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'registration_ip'	=> array(
					'datatype'		=> 'VARCHAR(39)',
					'allow_null'	=> false,
					'default'		=> '\'0.0.0.0\''
				),
				'reputation'	=> array(
					'datatype'		=> 'INT',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'last_visit'		=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'posting_ban'		=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'admin_note'		=> array(
					'datatype'		=> 'VARCHAR(30)',
					'allow_null'	=> true
				),
				'activate_string'	=> array(
					'datatype'		=> 'VARCHAR(128)',
					'allow_null'	=> true
				),
				'activate_key'		=> array(
					'datatype'		=> 'VARCHAR(8)',
					'allow_null'	=> true
				),
				'login_key'		=> array(
					'datatype'		=> 'VARCHAR(60)',
					'allow_null'	=> true
				),
			),
			'PRIMARY KEY'	=> array('id'),
			'UNIQUE KEYS'	=> array(
				'username_idx'		=> array('username(25)'),
				'login_key_idx'		=> array('login_key')
			),
			'INDEXES'		=> array(
				'registered_idx'	=> array('registered'),
				'group_id_idx'	=> array('group_id'), // Set a group id index to help speed up JOINs later
			)
		);

		$this->db->create_table('users', $schema);
		
		$schema = array(
			'FIELDS'		=> array(
				'id'			=> array(
					'datatype'		=> 'INT(10) UNSIGNED AUTO_INCREMENT',
					'allow_null'	=> false,
				),
				'subject'		=> array(
					'datatype'		=> 'VARCHAR(50)',
					'allow_null'	=> false,
					'default'		=> '\'\'',
				),
				'message'			=> array(
					'datatype'		=> 'text',
					'allow_null'	=> false,
				),
				'forum_id'			=> array(
					'datatype'		=> 'text',
					'allow_null'	=> false,
				),
				'user_id'		=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '2',
				),
			),
			'PRIMARY KEY'	=> array('id'),
		);

		$this->db->create_table('announcements', $schema);

		$schema = array
		(
			'FIELDS'	=> array(
					'id' => array(
					'datatype'		=> 'INT(10) UNSIGNED AUTO_INCREMENT',
					'allow_null'	=> false,
				),
				'last_checked'		=> array(
					'datatype'		=> 'timestamp',
					'allow_null'	=> false,
					'default'		=> 'CURRENT_TIMESTAMP'
				),
				'ip_address'		=> array(
					'datatype'		=> 'varchar(39)',
					'allow_null'	=> false,
				),
				'username'		=> array(
					'datatype'		=> 'varchar(100)',
					'allow_null'	=> false,
				),				
			),
			'PRIMARY KEY'	=> array('id'),
			'UNIQUE KEYS'	=> array(
				'ip_address_idx'	=> array('ip_address')
			),
		);
		
		$this->db->create_table('login_queue', $schema);
		
		$schema = array(
			'FIELDS'		=> array(
				'id'			=> array(
					'datatype'		=> 'INT(10) UNSIGNED AUTO_INCREMENT',
					'allow_null'	=> false,
				),
				'title'		=> array(
					'datatype'		=> 'varchar(50)',
					'allow_null'	=> false,
					'default'		=> '\'New Action\'',
				),
				'close'			=> array(
					'datatype'		=> 'TINYINT(1) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '\'2\'',
				),
				'stick'			=> array(
					'datatype'		=> 'TINYINT(1) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '\'2\'',
				),
				'move'			=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '\'0\'',
				),
				'archive'			=> array(
					'datatype'		=> 'TINYINT(1) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '\'2\'',
				),
				'leave_redirect'			=> array(
					'datatype'		=> 'TINYINT(1) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '\'0\'',
				),
				'reply_message'			=> array(
					'datatype'		=> 'mediumtext',
					'allow_null'	=> true,
				),
				'add_start'			=> array(
					'datatype'		=> 'VARCHAR(50)',
					'allow_null'	=> true,
					'default'		=> null,
				),
				'add_end'			=> array(
					'datatype'		=> 'VARCHAR(50)',
					'allow_null'	=> true,
					'default'		=> null,
				),
				'send_email'			=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '0',
				),
				'increment_posts'	=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '0',
				),
				'report_posts'	=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '0',
				),
			),
			'PRIMARY KEY'	=> array('id'),
		);

		$this->db->create_table('multi_moderation', $schema);
		
		$schema = array(
			'FIELDS'		=> array(
				'id'			=> array(
					'datatype'		=> 'INT(10) UNSIGNED AUTO_INCREMENT',
					'allow_null'	=> false
				),
				'rank'			=> array(
					'datatype'		=> 'VARCHAR(50)',
					'allow_null'	=> false,
					'default'		=> '\'\''
				),
				'min_posts'		=> array(
					'datatype'		=> 'MEDIUMINT(8) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				)
			),
			'PRIMARY KEY'	=> array('id')
		);

		$this->db->create_table('ranks', $schema);
		
		$schema = array(
			'FIELDS' => array(
				'id' => array(
					'datatype' => 'INT(10) UNSIGNED AUTO_INCREMENT',
					'allow_null' => false
				),
				'image' => array(
					'datatype' => 'VARCHAR(40)',
					'allow_null' => false,
					'default' => '\'\''
				),
				'code' => array(
					'datatype' => 'VARCHAR(20)',
					'allow_null' => false,
					'default' => '\'\''
				),
				'disp_position' => array(
					'datatype' => 'TINYINT(2) UNSIGNED',
					'allow_null' => false,
					'default' => '0'
				)
			),
			'PRIMARY KEY' => array('id')
		);
		$this->db->create_table('smilies', $schema);
		
		$schema = array(
			'FIELDS' => array(
				'id' => array(
					'datatype' => 'INT(10) UNSIGNED AUTO_INCREMENT',
					'allow_null' => false
				),
				'title' => array(
					'datatype' => 'VARCHAR(50)',
					'allow_null' => false,
					'default' => '\'New Task\''
				),
				'next_run' => array(
					'datatype' => 'INT(10) UNSIGNED',
					'allow_null' => false,
					'default' => '\'0\''
				),
				'script' => array(
					'datatype' => 'VARCHAR(30)',
					'allow_null' => false,
				),
				'minute' => array(
					'datatype' => 'VARCHAR(2)',
					'allow_null' => false,
					'default' => '\'*\''
				),
				'hour' => array(
					'datatype' => 'VARCHAR(2)',
					'allow_null' => false,
					'default' => '\'*\''
				),
				'day' => array(
					'datatype' => 'VARCHAR(2)',
					'allow_null' => false,
					'default' => '\'*\''
				),
				'month' => array(
					'datatype' => 'VARCHAR(2)',
					'allow_null' => false,
					'default' => '\'*\''
				),
				'week_day' => array(
					'datatype' => 'VARCHAR(1)',
					'allow_null' => false,
					'default' => '\'*\''
				),
				'locked' => array(
					'datatype' => 'TINYINT(1)',
					'allow_null' => false,
					'default' => '0'
				),
			),
			'PRIMARY KEY' => array('id')
		);
		$this->db->create_table('tasks', $schema);
		
		$schema = array(
			'FIELDS'		=> array(
				'id'			=> array(
					'datatype'		=> 'SERIAL',
					'allow_null'	=> false
				),
				'user_id'		=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'type_id'		=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'post_id'		=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'title'			=> array(
					'datatype'		=> 'VARCHAR(120)',
					'allow_null'	=> false,
					'default'		=> '\'\''
				),
				'points'		=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'date_issued'		=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'date_expire'		=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'issued_by'		=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'expired'		=> array(
					'datatype'		=> 'TINYINT(1)',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'note_admin'		=> array(
					'datatype'		=> 'TEXT',
					'allow_null'	=> true
				),
				'note_post'		=> array(
					'datatype'		=> 'MEDIUMTEXT',
					'allow_null'	=> true
				),
				'note_pm'		=> array(
					'datatype'		=> 'TEXT',
					'allow_null'	=> true
				)
			),
			'PRIMARY KEY'	=> array('id'),
		);

		$this->db->create_table('warnings', $schema);
			
		$schema = array(
			'FIELDS'		=> array(
				'id'			=> array(
					'datatype'		=> 'SERIAL',
					'allow_null'	=> false
				),
				'title'			=> array(
					'datatype'		=> 'VARCHAR(120)',
					'allow_null'	=> false,
					'default'		=> '\'\''
				),
				'description'		=> array(
					'datatype'		=> 'TEXT',
					'allow_null'	=> true
				),
				'points'		=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'expiration_time'	=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				)
			),
			'PRIMARY KEY'	=> array('id'),
		);

		$this->db->create_table('warning_types', $schema);
		
		$schema = array(
			'FIELDS'		=> array(
				'id'			=> array(
					'datatype'		=> 'SERIAL',
					'allow_null'	=> false
				),
				'points'		=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				),
				'message'		=> array(
					'datatype'		=> 'VARCHAR(255)',
					'allow_null'	=> false,
					'default'		=> '\'\''
				),
				'period'		=> array(
					'datatype'		=> 'INT(10) UNSIGNED',
					'allow_null'	=> false,
					'default'		=> '0'
				)
			),
			'PRIMARY KEY'	=> array('id'),
		);
		
		$this->db->create_table('warning_levels', $schema);
	}

	/**
	 * Insert the default user groups for the forum
	 */
	public function groups()
	{
		$parser = new \xml\parser;

		$parser->load(INSTALL_ROOT.'include/data/groups.xml');
		$groups = $parser->fetch_array();

		foreach ($groups['groups']['group'] as $group)
		{
			$insert = array();
			foreach ($group as $permission => $data)
			{
				if ($permission == 'data')
					continue;
				else if (isset($data['attributes']['lang'])) // We want a language string
					$data['data'] = $this->lang->t($data['data']);

				$insert[$permission] = isset($data['data']) ? $data['data'] : '';
			}

			$this->db->insert('groups', $insert);
		}
	}

	/**
	 * Insert the guest user and administrator account
	 */
	public function users()
	{
		$generator = new \auth\password($this->registry);

		$insert = array(
			'group_id'	=>	4,
			'username'	=>	$this->lang->t('Guest'),
			'password'	=>	$this->lang->t('Guest'),
			'email'		=>	$this->lang->t('Guest'),
		);

		// Insert guest and first Admin user
		$this->db->insert('users', $insert);

		$insert = array(
			'group_id'	=>	1,
			'username'	=>	$this->data['username'],
			'password'	=>	$this->data['password'],
			'salt'		=>	$this->data['password_salt'],
			'email'		=>	$this->data['email'],
			'language'	=>	installation::DEFAULT_LANG,
			'style'		=>	installation::DEFAULT_STYLE,
			'num_posts'	=>	1,
			'last_post'	=>	CURRENT_TIMESTAMP,
			'registered'=>	CURRENT_TIMESTAMP,
			'registration_ip'	=>	get_remote_address(),
			'last_visit'	=>	CURRENT_TIMESTAMP,
			'password_changed' => CURRENT_TIMESTAMP,
			'pm_enabled'	=>	1,
			'use_gravatar'	=>	1, // Set gravatar enabled (we don't know if file uploads are enabled yet, and there is definitely no avatar)
			'login_key' => $generator->generate(60),
		);

		$this->db->insert('users', $insert);
	}

	/**
	 * Insert default ranks
	 */
	public function ranks()
	{
		$parser = new \xml\parser;

		$parser->load(INSTALL_ROOT.'include/data/ranks.xml');
		$ranks = $parser->fetch_array();

		foreach ($ranks['ranks']['rank'] as $rank)
		{
			$insert = array();
			foreach ($rank as $name => $data)
			{
				if ($name == 'data')
					continue;
				else if (isset($data['attributes']['lang'])) // We want a language string
					$data['data'] = $this->lang->t($data['data']);

				$insert[$name] = isset($data['data']) ? $data['data'] : '';
			}

			$this->db->insert('ranks', $insert);
		}
	}

	/**
	 * Insert the default emoticons
	 */
	public function smilies()
	{
		$parser = new \xml\parser;

		$parser->load(INSTALL_ROOT.'include/data/smilies.xml');
		$smilies = $parser->fetch_array();

		$i = 1;
		foreach ($smilies['smilies']['smiley'] as $smiley)
		{
			$insert = array();
			foreach ($smiley as $code => $image)
			{
				if ($code == 'data')
					continue;

				$insert[$code] = $image['data'];
			}

			$insert['disp_position'] = ++$i;
			$this->db->insert('smilies', $insert);
		}
	}

	/**
	 * Add the default tasks
	 */
	public function tasks()
	{
		$parser = new \xml\parser;

		$parser->load(INSTALL_ROOT.'include/data/tasks.xml');
		$tasks = $parser->fetch_array();

		$insert = array();
		foreach ($tasks['tasks']['task'] as $name => $data)
		{
			if ($name == 'data')
				continue;
			else if (isset($data['attributes']['lang'])) // We want a language string
				$data['data'] = $this->lang->t($data['data']);
			else if (isset($data['attributes']['time']))
				$data['data'] = strtotime($data['data']);

			$insert[$name] = $data['data'];
		}

		$this->db->insert('tasks', $insert);
	}

	/**
	 * Add the default forum configuration
	 */
	public function config()
	{
		$avatars = in_array(strtolower(@ini_get('file_uploads')), array('on', 'true', '1')) ? 1 : 0; // Enable/disable avatars depending on file_uploads setting in PHP configuration

		// Take an educated guess at the correct path, and replace backslashes with forward slashes in case we're using a Windows server.
		$current_path = str_replace('\\', '/', realpath(AURA_ROOT));

		if (!function_exists('exec') || strtoupper(substr(PHP_OS, 0, 3)) === 'WIN')
			$task_type = 0;
		else
		{
			$task_type = 1;
			exec('echo -e "`crontab -l`\n0 0 1 * * '.$current_path.'/cron.php'.'" | crontab -');
		}

		// Insert config data
		$aura_config = array(
			'o_cur_version'				=> installation::AURA_VERSION,
			'o_board_title'				=> $this->data['title'],
			'o_board_desc'				=> $this->data['description'],
			'o_cookie_name'				=> $this->data['cookie_name'],
			'o_cookie_seed'				=> $this->data['cookie_seed'],
			'o_cookie_secure'			=> (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') ? '1' : '0',
			'o_task_type'				=> $task_type,
			'o_attachments'				=> $avatars,
			'o_http_authentication'		=> (PHP_SAPI == 'cgi-fcgi') ? 0 : 1, // iIf we use cgi-fcgi, then this doesn't work
			'o_admin_notes'				=> $this->lang->t('Admin notes'),
			'o_attachments_dir'			=> $current_path.'/attachments/',
			'o_default_lang'			=> $this->data['default_lang'],
			'o_default_style'			=> $this->data['default_style'],
			'o_delete_full'				=> $this->data['delete_posts'],
			'o_gzip'					=> $this->data['gzip'],
			'o_mailing_list'			=> $this->data['email'],
			'o_avatar_upload'			=> ($avatars && $this->data['use_avatars'] == '1') ? 1 : 0,
			'o_image_dir'				=> $this->data['base_url'].'/assets/images/',
			'o_js_dir'					=> $this->data['base_url'].'/assets/js/',
			'o_email_name'				=> $this->data['email_title'],
			'o_base_url'				=> $this->data['base_url'],
			'o_admin_email'				=> $this->data['email'],
			'o_webmaster_email'			=> $this->data['email'],
			'o_smtp_host'				=> null,
			'o_smtp_user'				=> null,
			'o_smtp_pass'				=> null,
			'o_regs_allow'				=> $this->data['allow_regs'],
			'o_announcement_message'	=> $this->lang->t('Announcement'),
			'o_rules_message'			=> $this->lang->t('Rules'),
			'o_maintenance_message'		=> $this->lang->t('Maintenance message'),
			'o_password_min_length'		=> installation::MIN_PASSWORD_LENGTH,
			'o_password_length'			=> installation::PASSWORD_GENERATION_LENGTH,
			'o_password_min_digits'		=> installation::PASSWORD_MIN_DIGITS,
			'o_password_min_uppercase'	=> installation::PASSWORD_MIN_UPPERCASE,
			'o_password_min_symbols'	=> installation::PASSWORD_MIN_SYMBOLS,
			'o_password_expires'		=> installation::PASSWORD_EXPIRATION_DATE,
		);

		$parser = new \xml\parser;

		$parser->load(INSTALL_ROOT.'include/data/config.xml');
		$config = $parser->fetch_array();

		foreach ($config['config'] as $item => $data)
		{
			if ($item == 'data')
				continue;

			$aura_config[$item] = isset($data['data']) ? $data['data'] : '';
		}

		foreach ($aura_config as $conf_name => $conf_value)
		{
			$insert = array(
				'conf_name'	=>	$conf_name,
				'conf_value'	=>	$conf_value,
			);

			$this->db->insert('config', $insert);
		}
	}

	/**
	 * Insert the default private messaging folders
	 */
	public function folders()
	{
		$folders = array($this->lang->t('New'), $this->lang->t('Inbox'), $this->lang->t('Archived'));
		foreach ($folders as $folder)
		{
			$insert = array(
				'name'	=>	$folder,
				'user_id' => 1,
			);

			$this->db->insert('folders', $insert);
		}
	}

	/**
	 * Insert the default forum
	 */
	public function forum()
	{
		$insert = array(
			'cat_name'	=>	$this->lang->t('Test category'),
			'disp_position'	=>	1,
		);

		$this->db->insert('categories', $insert);

		$insert = array(
			'forum_name'	=>	$this->lang->t('Test forum'),
			'forum_desc'	=>	$this->lang->t('This is just a test forum'),
			'num_topics'	=>	1,
			'num_posts'		=>	1,
			'last_post'		=>	CURRENT_TIMESTAMP,
			'last_post_id'	=>	1,
			'last_topic'	=>	$this->lang->t('Test post', installation::AURA_VERSION),
			'last_topic_id'	=>	1,
			'last_poster'	=>	$this->data['username'],
			'disp_position'	=>	1,
			'cat_id'		=>	1,
			'quickjump'		=>	1,
		);

		$this->db->insert('forums', $insert);
	}

	/**
	 * Insert the default topic
	 */
	public function topic()
	{
		$insert = array(
			'poster'	=>	$this->data['username'],
			'subject'	=>	$this->lang->t('Test post', installation::AURA_VERSION),
			'posted'	=>	CURRENT_TIMESTAMP,
			'first_post_id'		=>	1,
			'last_post'		=>	CURRENT_TIMESTAMP,
			'last_post_id'	=>	1,
			'last_poster'	=>	$this->data['username'],
			'forum_id'		=>	1,
		);

		$this->db->insert('topics', $insert);

		$insert = array(
			'poster'	=>	$this->data['username'],
			'poster_id'	=>	2,
			'poster_ip'	=>	get_remote_address(),
			'message'	=>	$this->lang->t('Message', installation::AURA_DOCUMENTATION, installation::AURA_RESOURCES, installation::AURA_SUPPORT_CENTRE),
			'posted'	=>	CURRENT_TIMESTAMP,
			'topic_id'	=>	1,
		);

		$this->db->insert('posts', $insert);

		$idx = new \search\idx($this->registry);

		define('AURA_SEARCH_MIN_WORD', installation::AURA_SEARCH_MIN_WORD);
		define('AURA_SEARCH_MAX_WORD', installation::AURA_SEARCH_MAX_WORD);

		$idx->update_search_index('post', 1, $this->lang->t('Message', installation::AURA_DOCUMENTATION, installation::AURA_RESOURCES, installation::AURA_SUPPORT_CENTRE), $this->lang->t('Test post', installation::AURA_VERSION));
	}

	/**
	 * Generate the cache files
	 */
	public function cache()
	{
		$this->cache->generate('style', array(array('o_style_path' => ''), array('style' => '')));
		$this->cache->generate('groups');
		$this->cache->generate('bans');
		$this->cache->generate('ranks');
		$this->cache->generate('robots');
		$this->cache->generate('forums');
		$this->cache->generate('smilies');
		$this->cache->generate('censoring');
		//$this->cache->generate('stopwords');
		$this->cache->generate('stats');
		$this->cache->generate('announcements');
		$this->cache->generate('admins');
		$this->cache->generate('perms');
		$this->cache->generate('restrictions');
		$this->cache->generate('updates', array($this->lang));
		$this->cache->generate('tasks');
		$this->cache->generate('locales');
		$this->cache->generate('moderators');
		$this->cache->generate('extensions');
	}

	/**
	 * Generate the language caches
	 */
	public function languages()
	{
		$files = array_diff(scandir(realpath(AURA_ROOT.'include/i18n/'.installation::DEFAULT_LANG.'/')), array('.', '..'));
		foreach ($files as $file)
		{
			if (substr($file, -3) == '.po')
				$this->lang->load(str_replace('.po', '', $file));
		}
	}

	/**
	 * Write the configuration file
	 */
	public function generate_config()
	{
		$session_id = sha1(random_key(50));
		

		if (!defined('AURA_AJAX_REQUEST'))
		{
			header('Content-Type: text/x-delimtext; name="config.php"');
			header('Content-disposition: attachment; filename=config.php');

			exit(generate_config_file($session_id, $this->data['admin_dir'], $this->data['config']));
		}

		// Generate the config.php file data
		$file = generate_config_file($session_id, $this->data['admin_dir'], $this->data['config']);

		// Attempt to write config.php and let us know if it fails
		$written = false;
		if (forum_is_writable(AURA_ROOT.'include'))
		{
			$fh = @fopen(AURA_ROOT.'include/config.php', 'wb');
			if ($fh)
			{
				fwrite($fh, $file);
				fclose($fh);

				@chmod(AURA_ROOT.'include/config.php', 0644);
				$written = true;
			}
		}

		if (!$written)
			return 'failed';
	}
}