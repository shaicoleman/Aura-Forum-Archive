<?php
class registry extends stdClass
{
	protected $vars = array();
	private static $classes;

	public function &__set($index, $value)
	{
		$this->vars[$index] = $value;
		return $value;
	}

	public function &__get($index)
	{
		return $this->vars[$index];
	}

	public static function send_headers($type = 'html')
	{
		// Send no-cache headers
		header('Expires: Thu, 21 Jul 1977 07:30:00 GMT'); // When yours truly first set eyes on this world! :)
		header('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT');
		header('Cache-Control: post-check=0, pre-check=0', false);
		header('Pragma: no-cache'); // For HTTP/1.0 compatibility

		// Send the Content-type header in case the web server is setup to send something else
		if ($type == 'html')
			header('Content-type: text/html; charset=utf-8');
		else
			header('Content-type: text/plain; charset=utf-8');

		// Prevent site from being embedded in a frame
		header('X-Frame-Options: deny');
		header('X-Powered-By: Aura');
	}

	public static function get($class)
	{
		if (!isset(self::$classes[$class]))
			self::$classes[$class] = new $class(self::$instance);

		return self::$classes[$class];
	}
}