<?php
/**
 * Copyright (C) 2019 Aura (https://www.get-aura.org)
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

class registry
{
	private static $instance;
	private static $classes;
	protected $vars = array();

	public static $aura_start;
	public static $buffering = true;

	public function &__set($index, $value)
	{
		$this->vars[$index] = $value;
		return $value;
	}

	public function &__get($index)
	{
		return $this->vars[$index];
	}

	public static function construct()
	{
		if (!self::$instance)
			self::$instance = new self();

		return self::$instance;
	}

	public function configure()
	{
		// Block prefetch requests
		if (isset($_SERVER['HTTP_X_MOZ']) && $_SERVER['HTTP_X_MOZ'] == 'prefetch')
		{
			header('HTTP/1.1 403 Prefetching Forbidden');

			// Send no-cache headers
			header('Expires: Thu, 21 Jul 1977 07:30:00 GMT'); // When yours truly first set eyes on this world! :)
			header('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT');
			header('Cache-Control: post-check=0, pre-check=0', false);
			header('Pragma: no-cache'); // For HTTP/1.0 compatibility
			exit;
		}

		// Attempt to load the configuration file config.php
		if (file_exists(AURA_ROOT.'include/config.php'))
			require AURA_ROOT.'include/config.php';

		if (!defined('config::SESSION'))
		{
			// Make an educated guess regarding base_url
			$base_url  = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') ? 'https://' : 'http://';	// protocol
			$base_url .= preg_replace('%:(80|443)$%', '', $_SERVER['HTTP_HOST']);							// host[:port]
			$base_url .= str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));							// path

			header('Location: '.$base_url.'/install/');
			exit;
		}

		// Load the Twig Templating Engine
		require AURA_ROOT.'include/lib/Twig/Autoloader.php';

		// Register Twig autoloader
		Twig_Autoloader::register();

		// Load UTF-8 functions
		require AURA_ROOT.'include/lib/utf8/utf8.php';

		// Load the functions script
		require AURA_ROOT.'include/functions.php';

		// Strip out "bad" UTF-8 characters
		$_GET = remove_bad_characters($_GET);
		$_POST = remove_bad_characters($_POST);
		$_COOKIE = remove_bad_characters($_COOKIE);

		// Record the start time (will be used to calculate the generation time for the page)
		registry::$aura_start = microtime(true);

		// Force POSIX locale (to prevent functions such as strtolower() from messing up UTF-8 strings)
		setlocale(LC_CTYPE, 'C');

		// Register the autoloader for non-existing classes
		spl_autoload_register('autoloader');

		$this->functions = new functions(self::$instance);

		// We don't have any config settings at this point, so for now it's a watered down version of it
		$handler = new \errors\handler;
		set_error_handler(array($handler, 'handle'));
		set_exception_handler(array($handler, 'handle'));

		// Make sure PHP reports no errors apart from parse errors (this is handled by the error handler from this point on)
		//error_reporting(E_PARSE);

		// Load database class and connect
		$db_type = '\database\\'.config::$db['type'];
		$this->db = new $db_type(config::$db);

		// Start a transaction
		$this->db->start_transaction();

		$this->cache = new \cache\cache(self::$instance);
		$this->config = $this->cache->get('config', array('o_default_user_group' => AURA_MEMBER));

		// Load all the extensions
		$this->hooks = new \extensions\hooks(self::$instance);

		// Check whether we should be using https
		if ($this->config['o_force_ssl'] == '1' && get_current_protocol() == 'http')
		{
			header('Location: '.str_replace('http://', 'https://', get_current_url()));
			exit;
		}

		// Load URL rewriting functions
		$url_pack = '\url\packs\\'.$this->config['o_url_type'];
		$this->rewrite = new $url_pack();

		// Enable output buffering
		if (self::$buffering)
		{
			// Should we use gzip output compression?
			if ($this->config['o_gzip'] && extension_loaded('zlib'))
				ob_start('ob_gzhandler');
			else
				ob_start();
		}

		// Define standard date/time formats
		$this->config['o_time_formats'] = explode(',', $this->config['o_time_formats']);
		$this->config['o_date_formats'] = explode(',', $this->config['o_date_formats']);

		// Reload the functions.php with the necessary requirements
		$this->functions = new functions(self::$instance);

		// Fix the request URI (both IIS6 & IIS7 break it)
		if (!isset($_SERVER['REQUEST_URI']) || (isset($_SERVER['QUERY_STRING']) && !empty($_SERVER['QUERY_STRING']) && strpos($_SERVER['REQUEST_URI'], '?') === false))
		{
			// Workaround for a bug in IIS7
			if (isset($_SERVER['HTTP_X_ORIGINAL_URL']))
				$_SERVER['REQUEST_URI'] = $_SERVER['HTTP_X_ORIGINAL_URL'];
			else if ($this->config['o_url_type'] == 'standard') // IIS6 also doesn't set REQUEST_URI ....
			{
				$requested_page = str_replace(array('%26', '%3D', '%2F', '%3F'), array('&', '=', '/', '?'), rawurlencode($_SERVER['PHP_SELF']));
				$_SERVER['REQUEST_URI'] = $requested_page.(isset($_SERVER['QUERY_STRING']) && !empty($_SERVER['QUERY_STRING']) ? '?'.$_SERVER['QUERY_STRING'] : '');
			}
		}

		// If query string is not set properly, create one and set $_GET manually
		if ((!isset($_SERVER['QUERY_STRING']) || empty($_SERVER['QUERY_STRING'])) && strpos($_SERVER['REQUEST_URI'], '?') !== false)
		{
			$_SERVER['QUERY_STRING'] = parse_url('http://'.$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI']);
			$_SERVER['QUERY_STRING'] = isset($_SERVER['QUERY_STRING']['query']) ? $_SERVER['QUERY_STRING']['query'] : '';
			parse_str($_SERVER['QUERY_STRING'], $_GET);
		}

		// We determine the path to the script, since we need to separate the path from the data to be rewritten
		$path_to_script = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
		if (substr($path_to_script, -1) != '/')
			$path_to_script = $path_to_script.'/';

		// We create our own request URI with the path removed and only the parts to rewrite included
		$request_uri = substr(urldecode($_SERVER['REQUEST_URI']), (strlen($path_to_script)));

		$rewritten_url = '';
		$url_parts = array();
		foreach ($this->rewrite->rules as $rule => $rewrite_to)
		{
			if (preg_match($rule, $request_uri))
			{ 
				$rewritten_url = preg_replace($rule, $rewrite_to, $request_uri);
				$url_parts = explode('?', $rewritten_url);

				// If there is a query string
				if (isset($url_parts[1]))
				{
					$query_string = explode('&', $url_parts[1]);

					// Set $_GET properly for all of the variables
					foreach ($query_string as $cur_param)
					{
						$param_data = explode('=', $cur_param);

						// Sometimes, parameters don't set a value (eg: script.php?foo), so we set them to null
						$param_data[1] = isset($param_data[1]) ? $param_data[1] : null;

						$_GET[$param_data[0]] = urldecode($param_data[1]);
					}
				}
				break;
			}
		}

		// We change $_SERVER['REQUEST_URI'] so that it reflects the file we're actually loading
		$_SERVER['REQUEST_URI'] = $_SERVER['SCRIPT_NAME'].((isset($url_parts[1])) ? '?'.$url_parts[1] : '');

		// Instantiate the styles handler
		$styles = new styles(self::$instance);

		// Check/update/set cookie and fetch user info
		$this->user = self::get('\auth\user')->check_cookie();

		// Set the default style
		styles::set_style($this->user['style']);

		$this->style = $this->cache->get('style', array($this->config, $this->user), true, true);
		$this->template = new template(self::$instance);

		// Reload cache with the template argument
		$this->cache = new \cache\cache(self::$instance);

		$this->lang = new lang(self::$instance);
		$this->lang->set_language($this->user['language']);

		$this->lang->load('common');

		// Reload the functions.php with the necessary requirements
		$this->functions = new functions(self::$instance);

		// If we don't know what to rewrite to, we show a not found messsage
		if (empty($rewritten_url) && $request_uri && (count($_GET) == '0' && $request_uri != 'index.php'))
			self::get('\handlers\message')->show($this->lang->t('Not found', $request_uri), false, '404 Not Found');

		// Now we have the arguments we need for the proper error handler
		$handler = new \errors\handler(self::$instance);
		
		// Reload the template class with the correct arguments
		$this->template = new template(self::$instance);

		register_shutdown_function(array($handler, 'handle'));
		set_error_handler(array($handler, 'handle'));
		set_exception_handler(array($handler, 'handle'));

		// Load the task manager
		$this->tasks = new \tasks\scheduler(self::$instance);

		if ($this->config['o_task_type'] == '0')
			$this->tasks->run_tasks();

		// Check if we are to display a maintenance message
		if ($this->config['o_maintenance'] && $this->user['g_id'] != AURA_ADMIN && !defined('AURA_TURN_OFF_MAINT'))
			$this->get('\handlers\maintenance')->show();

		// Check if current user is banned
		$this->bans = $this->cache->get('bans');
		$this->functions = new functions(self::$instance);
		self::get('\auth\bans')->check_bans();

		// Update online list
		if (($this->config['o_url_type'] == 'standard' || strstr($_SERVER['PHP_SELF'], 'index.php') || strstr($_SERVER['PHP_SELF'], '/index.php')) && !defined('AURA_CRON_MANAGER'))
			$this->online = self::get('\online')->update_users_online();

		// Load the extensions manager and fire up our first hook
		$this->extensions = new \extensions\manager(self::$instance);
		$this->extensions->load_extensions();

		$this->hooks->fire('registry.startup');
	}

	public static function send_headers($type = 'html')
	{
		// Send no-cache headers
		header('Expires: Thu, 21 Jul 1977 07:30:00 GMT'); // When yours truly first set eyes on this world! :)
		header('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT');
		header('Cache-Control: post-check=0, pre-check=0', false);
		header('Pragma: no-cache'); // For HTTP/1.0 compatibility

		// Send the Content-type header in case the web server is setup to send something else
		if ($type == 'html')
			header('Content-type: text/html; charset=utf-8');
		else
			header('Content-type: text/plain; charset=utf-8');

		// Prevent site from being embedded in a frame
		header('X-Frame-Options: '.(defined('AURA_XFRAME_OPTIONS') ? AURA_XFRAME_OPTIONS : 'deny'));
		header('X-Powered-By: Aura');
	}

	public static function get($class)
	{
		if (!isset(self::$classes[$class]))
			self::$classes[$class] = new $class(self::$instance);

		return self::$classes[$class];
	}

	// Since we've already started buffering, we need to actually destroy the output buffering here
	public static function disable_buffering()
	{
		ob_end_clean();
	}
}