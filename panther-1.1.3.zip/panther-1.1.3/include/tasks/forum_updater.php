<?php
/**
 * Copyright (C) 2015 Panther (https://www.pantherforum.org)
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

class task_forum_updater
{
		public function __construct($db, $panther_config, $cache)
		{
			$this->config = $panther_config;
			$this->db = $db;
			$this->cache = $cache;
		}

		public function run()
		{
			global $lang, $panther_bans, $panther_url, $panther_user, $panther_forums;

			require PANTHER_ROOT.'include/updater.php';
			$updater = new automatic_updater($this->config, $lang, $this->cache, $this->db, $panther_bans, $panther_url, $panther_user, $panther_forums);

			$updater->start();
		}
}