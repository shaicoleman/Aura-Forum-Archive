<?php
class language_handler
{
	protected $translations = array();
	protected static $lang_dir = 'lang';
	protected static $default_lang = 'en';
	protected $lang = 'en';
	protected $loaded_resources = array();

	public function __construct($cache)
	{
		self::set_default_language('en');
		$this->cache = $cache;
	}

	public static function get_language_list()
	{
		static $list = null;

		if (!isset($list))
		{
			$list = array();
			foreach (glob(PANTHER_ROOT.self::$lang_dir.'/*', GLOB_ONLYDIR) as $dir)
			{
				$dirs = explode('/', $dir);
				$list[] = end($dirs);
			}
		}

		return $list;
	}

	public static function language_exists($lang)
	{
		return in_array($lang, self::get_language_list());
	}

	public static function set_default_language($lang)
	{
		if (self::language_exists($lang))
			self::$default_lang = $lang;
		else
			throw new Exception('Language '.$lang.' cannot be found');
	}

	public function set_language($lang)
	{
		if ($this->language_exists($lang))
			$this->lang = $lang;
		else
			throw new Exception('Language '.$lang.' cannot be found');
	}

	public function load($resource)
	{
		// Make sure we don't load it twice
		if (in_array($resource, $this->loaded_resources))
			return;

		$this->loaded_resources[] = $resource;

		$trans_cache = $this->cache->get('language', array($this->lang, $resource, self::$lang_dir), true, true); 
		if (self::$default_lang != $this->lang) // If this isn't the default language then load that too, and we'll use it for fallback
		{
			$def_trans_cache = $this->cache->get('language', array(self::$default_lang, $resource, self::$lang_dir), true, true);
			$trans_cache = array_merge($def_trans_cache, $trans_cache);
		}

		// Store the loaded values for usage
		$this->translations = array_merge($this->translations, $trans_cache);
	}

	public function t($str)
	{
		if (isset($this->translations[$str]))
		{
			$args = func_get_args();
			$args[0] = $this->translations[$args[0]];
			return call_user_func_array('sprintf', $args);
		}

		return $str;
	}
}