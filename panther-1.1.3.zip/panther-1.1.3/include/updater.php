<?php
/**
 * Copyright (C) 2015 Panther (https://www.pantherforum.org)
 * based on code by WordPress copyright (C) 2011-2016 WordPress
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

if (!defined('PANTHER'))
	exit;

class panther_updater
{
	protected $update_lang = false;
	public function __construct($panther_config, $lang, $cache, $db)
	{
		$this->config = $panther_config;
		$this->lang = $lang;
		$this->cache = $cache;
		$this->db = $db;
	}

	protected function lock_upgrader()
	{
		if ($this->cache->exists('upgrade_lock'))
		{
			// Grab the timeout and see if it expired
			$timeout = $this->cache->get('upgrade_lock');

			if ($timeout < CURRENT_TIMESTAMP)
				$this->cache->delete('upgrade_lock');
			else
				return false;
		}
		else
			$this->cache->generate('upgrade_lock');

		return true;
	}

	protected function unlock_upgrader()
	{
		$this->cache->delete('upgrade_lock');
	}

	protected function should_upgrade($version)
	{
		$current_branch = implode('.', array_slice(preg_split('/[.-]/', $this->config['o_cur_version']), 0, 2));
		$new_branch = implode('.', array_slice(preg_split('/[.-]/', $version), 0, 2));
		$developer_release = (bool) strpos($this->config['o_cur_version'], '-');

		$upgrade_developer = true;
		$upgrade_minor = true;
		$upgrade_major = false;

		// If we've disabled updates, or we only want to install ones the admin has downloaded
		if ($this->config['o_update_type'] == '0' || $this->config['o_update_type'] == '1')
			$upgrade_minor = $upgrade_major = $upgrade_developer = false;

		// If we're on the same version, abort
		if ($this->config['o_cur_version'] == $version)
			return false;

		// We definitely don't want to downgrade
		if (version_compare($this->config['o_cur_version'], $version, '>'))
			return false;

		// If we're running a developer release
		if ($developer_release)
		{
			if ($upgrade_developer)
				return true;

			return false;
		}

		// If we're upgrading to the same branch
		if ($current_branch == $new_branch)
		{
			if ($upgrade_minor)
				return true;

			return false;
		}

		// If this is a major upgrade to a new branch of the forum
		if (version_compare($new_branch, $current_branch, '>'))
		{
			if ($upgrade_major)
				return true;

			return false;
		}

		// And if we're still here, abort
		return false;
	}

	public function run($package = '', $manual = false)
	{
		$info = $this->db->get_version();
		$this->updates = $this->cache->generate('updates', array($this->lang), true);

		if ($this->updates['failed'])
			return $this->lang->t('Upgrade check failed message');
		else if (substr($this->updates['package_url'], 0, 29) !== 'https://www.pantherforum.org/')
			return $this->lang->t('Upgrade check failed message');
		else if (version_compare(PHP_VERSION, $this->updates['php_version'], '<'))
			return $this->lang->t('PHP version not supported', PHP_VERSION, $this->updates['version'], $this->updates['php_version']);
		else if (!in_array($info['name'], $this->updates['drivers']))
			return $this->lang->t('Discontinued driver', $info['type'], $this->updates['version']);
		else if (version_compare($info['version'], $this->updates['mysql_version'], '<'))
			return $this->lang->t('MySQL version not supported', $info['version'], $this->updates['version'], $this->updates['mysql_version']);
		else if ($this->config['o_default_lang'] !== $this->updates['default_lang'])
			$this->update_lang = true; // We'll need to update the default language since it's changed
		else if (!$this->should_upgrade($this->updates['version']))
			return $this->lang->t('No upgrade needed');

		// Prevent another instance of the upgrader running
		$lock = $this->lock_upgrader();

		if (!$lock)
			return $this->lang->t('Multiple upgrade error');

		// And prevent standard users accessing the forum while we upgrade as well
		if ($this->config['o_maintenance'] != '1')
		{
			$this->maintenance_mode();
			$this->cache->generate('config', array($this->config));
		}

		// We only want to do this based on the update setting - or if we're manually updating
		if ($this->config['o_update_type'] == '2' || $this->config['o_update_type'] == '3' || $manual)
		{
			$package = ($package != '') ? $package : $this->updates['package_url'];
			$package = $this->download_package($package);
			if (!$package)
			{
				$this->unlock_upgrader();
				$this->maintenance_mode(0);
				return $this->lang->t('Unable to download');
			}
		}

		// And the same here, based on the setting, or a manual update
		if ($this->config['o_update_type'] == '1' || $this->config['o_update_type'] == '3' || $manual)
		{
			$package = $this->unarchive($package, $manual);
			if (!$package)
			{
				$this->unlock_upgrader();
				$this->maintenance_mode(0);
				return $this->lang->t('Unable to open archive');
			}

			$result = $this->install_package($package, PANTHER_ROOT);
			if (is_array($result))
			{
				$this->unlock_upgrader();
				$this->maintenance_mode(0);
				return $this->lang->t('Files not writable', implode(',', $result));
			}
			else if (!$result)
			{
				$this->unlock_upgrader();
				$this->maintenance_mode(0);
				return $this->lang->t('Unable to install update');
			}

			$this->update_database();
		}

		$this->unlock_upgrader();
		$this->maintenance_mode(0);
		return true;
	}

	protected function download_package($package)
	{
		if (empty($package))
			return false;

		if (!preg_match('!^(http|https|ftp)://!i', $package) && file_exists($package))
			return $package;

		if (is_callable('curl_init'))
		{
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $package);
			curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
			$downloaded_package = curl_exec($ch);
			curl_close($ch);
		}
		else
		{
			$downloaded_package = file_get_contents($package);
			if ($downloaded_package === false)
				return false;
		}

		return $downloaded_package;
	}

	protected function unarchive($downloaded_package, $manual = false, $delete_archive = true)
	{
		$update_location = PANTHER_ROOT.'include/updates/';
		$package = $update_location.$this->updates['package'];

		// If the location already exists, delete it and re-create it
		delete_directory($update_location);

		if (!@mkdir($update_location, 0644))
			return false;

		if ($manual)
		{
			if (!@copy($downloaded_package, $package))
				return false;

			@unlink($downloaded_package);
		}
		else
		{
			if (!file_put_contents($package, $downloaded_package))
				return false;
		}

		if (function_exists('sha1_file'))
		{
			$type = 'sha1';
			$function = 'sha1_file';
		}
		else
		{
			$type = 'md5';
			$function = 'md5_file';
		}

		$checksum = file_get_contents('https://www.pantherforum.org/downloads/verify/'.$type.'/'.$this->updates['version']);
		if (!panther_hash_equals($checksum, $function($package)))
			return false;

		$package_dir = basename($package, '.zip');
		if (is_dir($update_location.$package_dir))
			delete_directory($update_location.$package_dir);

		if (!mkdir($update_location.$package_dir, 0644))
			return false;

		$zip = new ZipArchive();
		if ($zip->open($package, ZIPARCHIVE::CHECKCONS))
		{
			$zip->extractTo($update_location.$package_dir);
			$zip->close();
		}
		else
			return false;

		if ($delete_archive)
			unlink($package);

		return $update_location.$package_dir;
	}

	protected function install_package($source, $destination)
	{
		@set_time_limit(300);

		$files = array_diff(scandir($source), array('.', '..'));
		if (empty($files)) // There are no files or folders in the update package
			return false;

		if (!is_dir($destination))
			mkdir($destination);

		$cleared = $this->clear_destination($destination);
		if ($cleared !== true)
			return $cleared;

		$this->copy_dir($source, $destination);

		delete_directory($source);
		delete_directory(PANTHER_ROOT.'include/updates');
		delete_directory(PANTHER_ROOT.'install'); // Delete the new install directory

		// If the new admin directory is not named the default we need to rename it
		if (file_exists(PANTHER_ROOT.'admin') && PANTHER_ADMIN_DIR !== 'admin')
		{
			if (!@rename(PANTHER_ROOT.'admin', PANTHER_ROOT.PANTHER_ADMIN_DIR))
			{
				// If it failed, chmod it and try again
				@chmod($destination.DIRECTORY_SEPARATOR.$file, 0755);
				if (!@rename(PANTHER_ROOT.'admin', PANTHER_ROOT.PANTHER_ADMIN_DIR)) // And if we still can't, abort
					throw new Exception('Unable to rename directory \'admin\' to '.PANTHER_ADMIN_DIR);
			}
		}

		// If we have a custom styles path, then we need to update the styles in there
		if ($this->config['o_style_path'] != 'styles')
		{
			$style_root = $this->config['o_style_path'];

			$this->copy_dir(PANTHER_ROOT.'styles', $this->config['o_style_path']);
			delete_directory(PANTHER_ROOT.'styles');
		}
		else
			$style_root = PANTHER_ROOT.$this->config['o_style_path'];

		// The default style has been removed
		if (!file_exists($style_root.'/'.$this->config['o_default_style'].'.css'))
		{
			$styles = array();
			$files = array_diff(scandir($style_root), array('.', '..'));
			foreach ($files as $style)
			{
				if (substr($style, -4) == '.css')
					$styles[] = substr($style, 0, -4);
			}

			if (!empty($styles)) // No styles???
			{
				$update = array(
					'conf_value' => current($styles), // Go for the first available style
				);

				$data = array(
					':conf_name' => 'o_default_style',
				);

				$this->db->update('config', $update, 'conf_name=:conf_name', $data);
			}
		}

		// Update the avatars ...
		if ($this->config['o_avatars_path'] != 'assets/images/avatars/')
		{
			$this->copy_dir(PANTHER_ROOT.'assets/images/avatars', $this->config['o_avatars_path']);
			delete_directory(PANTHER_ROOT.'assets/images/avatars');
		}

		// Update the group images ...
		if ($this->config['o_image_group_path'] != 'assets/images/group/')
		{
			$this->copy_dir(PANTHER_ROOT.'assets/images/group', $this->config['o_image_group_path']);
			delete_directory(PANTHER_ROOT.'assets/images/group');
		}

		// Update the emoticons ...
		if ($this->config['o_smilies_path'] != 'assets/images/smilies')
		{
			$this->copy_dir(PANTHER_ROOT.'assets/images/smilies', $this->config['o_smilies_path']);
			delete_directory(PANTHER_ROOT.'assets/images/smilies');
		}

		// If we want to update the new default language
		if ($this->update_lang)
		{
			$update = array(
				'conf_value' => $this->updates['default_lang'],
			);

			$data = array(
				':conf_name' => 'o_default_lang',
			);

			$this->db->update('config', $update, 'conf_name=:conf_name', $data);
		}

		// Disable maintenance mode
		$this->maintenance_mode(0);
		return true;
	}

	protected function clear_destination($destination)
	{
		$unwritable = array();
		$destination_files = array_diff(scandir($destination), array('.', '..'));
		foreach ($destination_files as $file)
		{
			if (!is_writable($destination.$file))
			{
				$permission = (is_dir($destination.$file)) ? 0755 : 0644;
				if (!@chmod($destination.$file, $permission))
					$unwritable[] = $destination.$file;
				else if (!is_writable($destination.$file))
					$unwritable[] = $destination.$file;
			}
		}

		if (!empty($unwritable))
			return $unwritable;

		$skip_list = array(
			basename($this->config['o_attachments_dir']),
			basename($this->config['o_style_path']),
			basename(PANTHER_EXTENSIONS_DIR),
			basename(PANTHER_PLUGINS_DIR),
			basename($this->cache->cache_dir),
			'include/updates', // We certainly don't want to remove the new version!
			'include/config.php',
			$this->config['o_avatars_path'],
			$this->config['o_image_group_path'],
		);

		$this->delete_files($destination, $skip_list);
		return true;
	}

	protected function delete_files($destination, $skip_list = array())
	{
		$files = array_diff(scandir($destination), array('.', '..'));
		foreach ($files as $file)
		{
			if (in_array($file, $skip_list))
				continue;

			if (is_dir($destination.$file))
			{
				$sub_skip_list = array();
				foreach ($skip_list as $skip_file)
				{
					if (strpos($skip_file, $file.'/') === 0)
						$sub_skip_list[] = preg_replace('!^'.preg_quote($file, '!').'/!i', '', $skip_file);
				}

				$this->delete_files($destination.$file.'/', $sub_skip_list);
			}
			else
				@unlink($destination.$file);
		}

		if (file_exists($destination) && is_dir($destination))
			@rmdir($destination);
	}

	protected function copy_dir($source, $destination)
	{
		$files = array_diff(scandir($source), array('.', '..'));
		foreach ($files as $file)
		{
			if (!is_dir($source.DIRECTORY_SEPARATOR.$file))
			{
				if (!@copy($source.DIRECTORY_SEPARATOR.$file, $destination.DIRECTORY_SEPARATOR.$file))
				{
					// If it failed, chmod the file and try again
					@chmod($destination.DIRECTORY_SEPARATOR.$file, 0644);
					if (!@copy($source.DIRECTORY_SEPARATOR.$file, $destination.DIRECTORY_SEPARATOR.$file))
						throw new Exception('Unable to copy file '.$file.' when copying directory '.$source.' to '.$destination);
				}

				@chmod($destination.DIRECTORY_SEPARATOR.$file, 0644); // Chmod it to prevent it being writable in the new location
			}
			else
			{
				if (!is_dir($destination.DIRECTORY_SEPARATOR.$file))
				{
					if (!@mkdir($destination.DIRECTORY_SEPARATOR.$file, 0775))
						throw new Exception('Unable to create directory '.$destination.$file);
				}

				$this->copy_dir($source.DIRECTORY_SEPARATOR.$file, $destination.DIRECTORY_SEPARATOR.$file);
			}
		}

		return true;
	}

	protected function update_database()
	{
		$update = array(
			'conf_value' => $this->updates['version'],
		);

		$data = array(
			':conf_name' => 'o_cur_version',
		);

		$this->db->update('config', $update, 'conf_name=:conf_name', $data);

		// If the database has actually changed
		if (file_exists(PANTHER_ROOT.'include/db_update.php'))
		{
			require PANTHER_ROOT.'include/db_update.php';

			unlink(PANTHER_ROOT.'include/db_update.php');
		}

		return true;
	}

	protected function maintenance_mode($enable = 1)
	{
		$update = array(
			'conf_value' => $enable,
		);

		$data = array(
			':conf_name' => 'o_maintenance',
		);

		$this->db->update('config', $update, 'conf_name=:conf_name', $data);

		if (!$enable)
			$this->cache->clear();
	}
}

class automatic_updater extends panther_updater
{
	public function __construct($panther_config, $lang, $cache, $db, $panther_bans, $panther_url, $panther_user, $panther_forums)
	{
		$this->bans = $panther_bans;
		$this->url = $panther_url;
		$this->user = $panther_user;
		$this->forums = $panther_forums;
		$this->config = $panther_config;
		$this->lang = $lang;
		$this->cache = $cache;
		$this->db = $db;

		parent::__construct($panther_config, $lang, $cache, $db);
	}

	public function start()
	{
		// Support for the email class
		$panther_config = $this->config;
		$panther_url = $this->url;
		$panther_forums = $this->forums;
		$panther_user = $this->user;
		$panther_bans = $this->bans;
		$lang = $this->lang;
		$db = $this->db;

		require PANTHER_ROOT.'include/email.php';

		$result = $this->run();
		if ($result !== true) // We're in trouble, there was a problem
		{
			// So we send an email notification informing the admin
			$info = array(
				'subject' => array(
					'<version>' => $this->updates['version']
				),
				'message' => array(
					'<version>' => $this->updates['version'],
					'<base_url>' => get_base_url(),
					'<message>' => $result,
				)
			);

			$mail_tpl = $mailer->parse(PANTHER_ROOT.'lang/'.$this->user['language'].'/mail_templates/upgrade_failed.tpl', $info);
			$mailer->send($this->config['o_admin_email'], $mail_tpl['subject'], $mail_tpl['message']);
		}
		else // And if everything went ok, we let them know
		{
			$info = array(
				'subject' => array(
					'<version>' => $this->updates['version']
				),
				'message' => array(
					'<version>' => $this->updates['version'],
					'<base_url>' => get_base_url(),
				)
			);

			$mail_tpl = $mailer->parse(PANTHER_ROOT.'lang/'.$this->user['language'].'/mail_templates/upgrade.tpl', $info);
			$mailer->send($this->config['o_admin_email'], $mail_tpl['subject'], $mail_tpl['message']);
		}
	}
}