<?php
/**
 * Copyright (C) 2015 Panther (https://www.pantherforum.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

if (!defined('PANTHER_ROOT'))
	exit('The constant PANTHER_ROOT must be defined and point to a valid Panther installation root directory.');

// Check if we're using an AJAX request (i.e. reputation) 
if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest')
	define('PANTHER_AJAX_REQUEST', 1);

if (function_exists('date_default_timezone_set') && function_exists('date_default_timezone_get'))
	date_default_timezone_set(@date_default_timezone_get());

// Block prefetch requests
if (isset($_SERVER['HTTP_X_MOZ']) && $_SERVER['HTTP_X_MOZ'] == 'prefetch')
{
	header('HTTP/1.1 403 Prefetching Forbidden');
    
	// Send no-cache headers
	header('Expires: Thu, 21 Jul 1977 07:30:00 GMT'); // When yours truly first set eyes on this world! :)
	header('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT');
	header('Cache-Control: post-check=0, pre-check=0', false);
	header('Pragma: no-cache'); // For HTTP/1.0 compatibility
	exit;
}

// Attempt to load the configuration file config.php
if (file_exists(PANTHER_ROOT.'include/config.php'))
	require PANTHER_ROOT.'include/config.php';

require PANTHER_ROOT.'include/lib/Twig/Autoloader.php';

// Register Twig autoloader
Twig_Autoloader::register();

// Load the functions script
require PANTHER_ROOT.'include/functions.php';

// Load UTF-8 functions
require PANTHER_ROOT.'include/lib/utf8/utf8.php';

// Strip out "bad" UTF-8 characters
forum_remove_bad_characters();

// If PANTHER isn't defined, config.php is missing or corrupt
if (!defined('PANTHER'))
{
	header('Location: install/');
	exit;
}

// Record the start time (will be used to calculate the generation time for the page)
$panther_start = microtime(true);

// Force POSIX locale (to prevent functions such as strtolower() from messing up UTF-8 strings)
setlocale(LC_CTYPE, 'C');

// If the admin directory is not specified, use the default
if (!defined('PANTHER_ADMIN_DIR'))
	define('PANTHER_ADMIN_DIR', 'admin');

if (!defined('PANTHER_EXTENSIONS_DIR'))
	define('PANTHER_EXTENSIONS_DIR', PANTHER_ROOT.'extensions/');

if (!defined('PANTHER_PLUGINS_DIR'))
	define('PANTHER_PLUGINS_DIR', PANTHER_ROOT.'plugins/');

define('CURRENT_TIMESTAMP', time());

// Include the error handler
require PANTHER_ROOT.'include/errors.php';

// We don't have any config settings at this point, so for now it's a watered down version of it
$handler = new errors;
set_error_handler(array($handler, 'handle'));
set_exception_handler(array($handler, 'handle'));

// Make sure PHP reports no errors apart from parse errors (this is handled by the error handler from this point on)
error_reporting(E_PARSE);

// Define a few commonly used constants
define('PANTHER_UNVERIFIED', 0);
define('PANTHER_ADMIN', 1);
define('PANTHER_MOD', 2);
define('PANTHER_GUEST', 4);
define('PANTHER_MEMBER', 6);

// Brute force stuff
define('ATTEMPT_DELAY', 1000);
define('TIMEOUT', 5000);

// Load database class and connect
require PANTHER_ROOT.'include/database.php';
$db = new db($config);

// Start a transaction
$db->start_transaction();

require PANTHER_ROOT.'include/cache.php';
$cache = new cache($db);

$panther_config = $cache->get('config', array('o_default_user_group' => 6));

$panther_extensions = $cache->get('extensions');

// Check whether we should be using https
check_ssl_state();

// Load URL rewriting functions
if (file_exists(PANTHER_ROOT.'include/url/'.$panther_config['o_url_type'].'.php'))
	require PANTHER_ROOT.'include/url/'.$panther_config['o_url_type'].'.php';
else
	require PANTHER_ROOT.'include/url/default.php';

$panther_groups = $cache->get('groups');
$panther_forums = $cache->get('forums');

// Enable output buffering
if (!defined('PANTHER_DISABLE_BUFFERING'))
{
	// Should we use gzip output compression?
	if ($panther_config['o_gzip'] && extension_loaded('zlib'))
		ob_start('ob_gzhandler');
	else
		ob_start();
}

// Define standard date/time formats
$forum_time_formats = array($panther_config['o_time_format'], 'H:i:s', 'H:i', 'g:i:s a', 'g:i a');
$forum_date_formats = array($panther_config['o_date_format'], 'd-m-Y', 'Y-m-d', 'Y-d-m', 'm-d-Y', 'M j Y', 'jS M Y');

// Check/update/set cookie and fetch user info
$panther_user = array();
check_cookie($panther_user);

$loader = new Twig_Loader_Filesystem(PANTHER_ROOT.'include/templates');

$style_root = (($panther_config['o_style_path'] != 'styles') ? $panther_config['o_style_path'] : PANTHER_ROOT.$panther_config['o_style_path']).'/'.$panther_user['style'].'/templates/';
$loader->addPath(PANTHER_ROOT.'include/templates/', 'core');

if (file_exists($style_root)) // If the custom style doesn't use templates, then this is silly
	$loader->addPath($style_root, 'style');

$tpl_manager = new Twig_Environment($loader, 
	array(
		'cache' => $cache->cache_dir.'templates/'.$panther_user['style'],
		'debug' => ($panther_config['o_debug_mode'] == '1') ? true : false,
	)
);

require PANTHER_ROOT.'include/lang.php';
$lang = new language_handler($cache);
$lang->set_language($panther_user['language']);

$lang->load('common');

// Now we have the arguments we need for the proper error handler
$handler = new errors($panther_config, $panther_user, $panther_url, $lang);

register_shutdown_function(array($handler, 'handle'));
set_error_handler(array($handler, 'handle'));
set_exception_handler(array($handler, 'handle'));

// Load the task manager
require PANTHER_ROOT.'include/tasks.php';
$tasks = new task_scheduler($db, $panther_config, $cache);

// Check if we are to display a maintenance message
if ($panther_config['o_maintenance'] && $panther_user['g_id'] != PANTHER_ADMIN && !defined('PANTHER_TURN_OFF_MAINT') && !defined('IN_CRON'))
	maintenance_message();

$panther_bans = $cache->get('bans');

// Check if current user is banned
check_bans();

// Update online list
if (($panther_config['o_url_type'] == 'default' || strstr($_SERVER['PHP_SELF'], 'index.php') || strstr($_SERVER['PHP_SELF'], '/index.php')) && !defined('IN_CRON'))
	$online = update_users_online();

// Check to see if we logged in without a cookie being set
if ($panther_user['is_guest'] && isset($_GET['login']))
	message($lang->t('No cookie'));

($hook = get_extensions('common_after_validation')) ? eval($hook) : null;

// The maximum size of a post, in bytes, since the field is now MEDIUMTEXT this allows ~16MB but lets cap at 1MB...
if (!defined('PANTHER_MAX_POSTSIZE'))
	define('PANTHER_MAX_POSTSIZE', 1048576);

if (!defined('PANTHER_SEARCH_MIN_WORD'))
	define('PANTHER_SEARCH_MIN_WORD', 3);
if (!defined('PANTHER_SEARCH_MAX_WORD'))
	define('PANTHER_SEARCH_MAX_WORD', 20);

if (!defined('FORUM_MAX_COOKIE_SIZE'))
	define('FORUM_MAX_COOKIE_SIZE', 4048);