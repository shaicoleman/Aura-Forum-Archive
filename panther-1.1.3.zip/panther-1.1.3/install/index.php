<?php
/**
 * Copyright (C) 2015 Panther (https://www.pantherforum.org)
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

define('INSTALL_ROOT', __DIR__.'/');
require INSTALL_ROOT.'include/init.php';

$setup->run();