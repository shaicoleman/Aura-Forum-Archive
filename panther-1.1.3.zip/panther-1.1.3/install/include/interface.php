<?php
abstract class modules
{
	public function __construct()
	{
		
	}

	protected abstract function run();
}