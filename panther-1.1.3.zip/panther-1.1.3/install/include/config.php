<?php
class config
{
	// The Panther version this setup wizard installs
	const PANTHER_VERSION = '1.1.3';

	// Minimum requirements
	const MIN_PHP_VERSION = '5.3.0';
	const MIN_MEMORY_LIMIT = '128M';

	// Some default settings for the board
	const DEFAULT_LANG = 'en';
	const DEFAULT_STYLE = 'pantherone';

	// Some settings relevant for searching
	const PANTHER_SEARCH_MIN_WORD = 3;
	const PANTHER_SEARCH_MAX_WORD = 20;

	// Full list of database drivers supported by this version
	public static $drivers = array(
		'mysql' => 'MySQL',
	);

	// Minimum versions of each database driver supported
	public static $versions = array(
		'mysql' => '5.0.15',
	);

	// List of MySQL database engines supported by this version
	public static $engines = array(
		'innodb' => 'InnoDB',
		'myisam' => 'MyISAM',
	);
	
	// Whether to use persistent connections by default
	const PERSISTENT_CONNECTIONS = false;

	// The default table prefix to install with
	const DEFAULT_TABLE_PREFIX = 'panther_';

	// The default cookie name
	const DEFAULT_COOKIE_NAME = 'panther_cookie_';

	// Support links (after install)
	const PANTHER_SUPPORT_CENTRE = 'https://www.pantherforum.org/support/';
	const PANTHER_DOCUMENTATION = 'https://www.pantherforum.org/docs/';
	const PANTHER_RESOURCES = 'https://www.pantherforum.org/resources/';
	const PANTHER_FORUMS = 'https://www.pantherforum.org/forums/';
}