<?php
if (!defined('INSTALL_ROOT'))
	exit;

class module_license extends installer
{
	function run()
	{
		$this->template->data = array(
			'license' => file_get_contents(PANTHER_ROOT.'LICENSE.md'),
		);

		$this->template->render('license');
	}
}