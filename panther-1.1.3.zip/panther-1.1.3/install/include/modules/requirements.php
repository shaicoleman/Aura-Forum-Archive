<?php
if (!defined('INSTALL_ROOT'))
	exit;

class module_requirements extends installer
{
	function run()
	{
		$files_passed = 0; // Not tested
		$errors = array();
		$misc_passed = 1;
		$extensions_passed = 1; // Extensions passed
		$functions_passed = 1;
		$extensions = get_loaded_extensions();

		$requirements = array(
			array(
				'output_name' => 'DOM XML Handling',
				'extension_name' => 'libxml2',
				'test' => 'dom', 
				'fatal' => true,
			),
			array(
				'output_name' => 'JSON',
				'extension_name' => 'json',
				'test' => 'json',
				'fatal' => true,
			),
		);

		$files = array(
			$this->cache->cache_dir,
			PANTHER_ROOT.'assets/images/avatars/',
		);

		$functions = array(
			array(
				'name' => 'file_get_contents',
				'fatal' => false,
			),
			array(
				'name' => 'getimagesize',
				'fatal' => true,
			),
			array(
				'name' => 'fopen',
				'fatal' => false,
			),
		);

		$misc = array(
			array(
				'name' => 'sha512 Hash',
				'test' => 'sha512',
				'fatal' => true,
			),
			array(
				'name' => 'PDO',
				'test' => 'PDO',
				'fatal' => true,
			),
			array(
				'name' => 'cURL',
				'test' => 'curl_init',
				'fatal' => false,
			),
			array(
				'name' => 'file_uploads',
				'test' => 'file_uploads',
				'fatal' => false,
			),
			array(
				'name' => 'allow_url_fopen',
				'test' => 'allow_url_fopen',
				'fatal' => false,
			),
		);

		$checked_extensions = array();
		foreach ($requirements as $extension)
		{
			if (!in_array($extension['test'], $extensions))
			{
				if (!$extension['fatal'])
				{
					$extension['passed'] = false;
					$extensions_passed = 0; // Use a warning rather than preventing install
				}
				else
					$extensions_passed = -1;
			}
			else
				$extension['passed'] = true;

			$checked_extensions[] = $extension;
		}

		if ($extensions_passed != -1)
		{
			$files_passed = -1;
			foreach ($files as $file)
			{
				if (!forum_is_writable($file))
					$errors[] = $this->lang->t('Location not writable', $file);
			}

			if (empty($errors))
				$files_passed = 1;
		}

		$checked_functions = array();
		if ($extensions_passed != -1 && $files_passed != -1)
		{
			foreach ($functions as $function)
			{
				if (!function_exists($function['name']))
				{
					if (!$function['fatal'])
					{
						$function['passed'] = false;
						$functions_passed = 0;
					}
					else
						$functions_passed = -1;
				}
				else
					$function['passed'] = true;

				$checked_functions[] = $function;
			}
		}

		$items = array();
		foreach ($misc as $item)
		{
			switch($item['test'])
			{
				case 'sha512':
					if (in_array('sha512', hash_algos()))
					{
						$item['passed'] = true;
						$items[] = $item;
						continue 2;
					}
				break;
				case 'PDO':
					if (class_exists('PDO'))
					{
						$item['passed'] = true;
						$items[] = $item;
						continue 2;
					}
				break;
				case 'curl_init':
					if (is_callable('curl_init'))
					{
						$item['passed'] = true;
						$items[] = $item;
						continue 2;
					}
				break;
				case 'file_uploads':
					if (in_array(strtolower(@ini_get('file_uploads')), array('on', 'true', '1')))
					{
						$item['passed'] = true;
						$items[] = $item;
						continue 2;
					}
				break;
				case 'allow_url_fopen':
					if (@ini_get('allow_url_fopen') == '1' || strtolower(@ini_get('allow_url_fopen')) == 'on')
					{
						$item['passed'] = true;
						$items[] = $item;
						continue 2;
					}
				break;
			}

			if (!$item['fatal'])
			{
				$item['passed'] = false;
				$misc_passed = 0;
			}
			else
				$misc_passed = -1;

			$items[] = $item;
		}

		$this->template->data = array(
			'errors' => $errors,
			'files_passed' => $files_passed,
			'misc_passed' => $misc_passed,
			'functions_passed' => $functions_passed,
			'extensions_passed' => $extensions_passed,
			'extensions' => $checked_extensions,
			'functions' => $checked_functions,
			'items' => $items,
			'memory_limit' => return_bytes(@ini_get('memory_limit')),
			'recommended' => return_bytes(config::MIN_MEMORY_LIMIT),
		);

		$this->template->render('requirements');
	}
}