<?php
if (!defined('INSTALL_ROOT'))
	exit;

class module_welcome extends installer
{
	function run()
	{
		$this->cache->clear();

		$this->template->data = array(
			'drivers' => config::$drivers,
			'versions' => config::$versions,
		);

		$this->template->render('welcome');
	}
}