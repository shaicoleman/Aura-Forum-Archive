<?php
if (!defined('INSTALL_ROOT'))
	exit;

class module_settings extends installer
{
	function run()
	{
		$errors = array();
		if (isset($_POST['form_sent']))
		{
			$csrf_token = isset($_POST['csrf_token']) ? panther_trim($_POST['csrf_token']) : '';
			if (!panther_hash_equals(self::$data['csrf_token'], $csrf_token))
				throw new exception($this->lang('Invalid csrf token'));

			$settings = array(
				'title' => isset($_POST['title']) ? panther_trim($_POST['title']) : '',
				'description' => isset($_POST['description']) ? panther_trim($_POST['description']) : '',
				'base_url' => isset($_POST['base_url']) ? panther_trim($_POST['base_url']) : '',
				'default_lang' => isset($_POST['default_lang']) ? panther_trim($_POST['default_lang']) : '',
				'default_style' => isset($_POST['default_style']) ? panther_trim($_POST['default_style']) : '',
				'email_title' => isset($_POST['email_name']) ? panther_trim($_POST['email_name']) : '',
			);

			// Make sure base_url doesn't end with a slash
			if (substr($settings['base_url'], -1) == '/')
				$settings['base_url'] = substr($settings['base_url'], 0, -1);

			if ($settings['title'] == '')
				$errors[] = $this->lang->t('No board title');

			if (!language_handler::language_exists($settings['default_lang']))
				$errors[] = $this->lang->t('Error default language');

			$styles = forum_list_styles();
			if (!in_array($settings['default_style'], $styles))
				$errors[] = $this->lang->t('Error default style');

			if ($settings['email_title'] == '')
				$errors[] = $this->lang->t('No email name');

			if (empty($errors))
			{
				installer::add_progress(9);
				self::$data = array_merge($settings, self::$data);

				header('Location: '.self::$base_url.'install/?act=advanced');
				exit;
			}
		}

		$this->template->data = array(
			'errors' => $errors,
			'languages' => language_handler::get_language_list(),
			'default_lang' => config::DEFAULT_LANG,
			'default_style' => config::DEFAULT_STYLE,
			'styles' => forum_list_styles(),
		);

		$this->template->render('settings');
	}
}