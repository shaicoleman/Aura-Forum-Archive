<?php
if (!defined('INSTALL_ROOT'))
	exit;

class module_install extends installer
{
	function run()
	{
		require INSTALL_ROOT.'include/install.php';
		$this->install = new install($this->db, $this->lang, self::$data);

		if (isset($_GET['do']) && isset($_GET['csrf_token']) && (defined('PANTHER_AJAX_REQUEST') || $_GET['do'] == end($this->install->steps)))
		{
			$do = isset($_GET['do']) ? panther_trim($_GET['do']) : current($install->steps);
			if (!panther_hash_equals(self::$data['csrf_token'], $_GET['csrf_token']))
				exit($this->lang->t('Invalid csrf token'));

			$this->db->start_transaction();

			$next = $this->install_step($do);
			if ($next === false)
				exit('Unable to find current installation step!');
			else
				echo $next;

			$this->db->end_transaction();
			exit;
		}

		$this->template->data = array(
			'first_step' => current($this->install->steps),
			'last_step' => end($this->install->steps),
		);

		$this->template->render('install');
	}

	protected function install_step($action)
	{
		if (!method_exists($this->install, $action) && $action != '')
			throw new Exception('Invalid installation action.');

		$steps = array_values($this->install->steps);
		if (is_callable(array($this->install, $action)))
			$response = call_user_func(array($this->install, $action));

		$current_step = array_search($action, $steps);

		// This should never happen if it's using valid steps
		if ($current_step === false)
			return false;

		if ($response == 'failed') // Then we're on the last check and writing the config failed
			return 'failed';

		if (!isset($steps[++$current_step]))
			return 'finish';

		return $steps[$current_step].'||'.$this->install->ajax_lang[($current_step-1)];
	}
}