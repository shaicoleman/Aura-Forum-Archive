<?php
if (!defined('INSTALL_ROOT'))
	exit;

session_start();
session_regenerate_id();
define('PANTHER_ROOT', __DIR__.'/../../');

require INSTALL_ROOT.'include/config.php';
require INSTALL_ROOT.'include/functions.php';
require INSTALL_ROOT.'include/interface.php';
require INSTALL_ROOT.'include/installer.php';

// Send the Content-type header in case the web server is setup to send something else
header('Content-type: text/html; charset=utf-8');

// Load the functions script
require PANTHER_ROOT.'include/functions.php';

// Load UTF-8 functions
require PANTHER_ROOT.'include/lib/utf8/utf8.php';

// Strip out "bad" UTF-8 characters
forum_remove_bad_characters();

// Force POSIX locale (to prevent functions such as strtolower() from messing up UTF-8 strings)
setlocale(LC_CTYPE, 'C');

if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest')
	define('PANTHER_AJAX_REQUEST', 1);

if (function_exists('date_default_timezone_set') && function_exists('date_default_timezone_get'))
	date_default_timezone_set(@date_default_timezone_get());

// Has Panther already been installed?
if (file_exists(PANTHER_ROOT.'include/config.php'))
	include PANTHER_ROOT.'include/config.php';

// If the installation is not corrupt, then abort
if (defined('PANTHER'))
{
	header('Location: '.guess_base_url());
	exit;
}

// ... Otherwise define it here as we need it for various other things ...
define('PANTHER', 1);
define('CURRENT_TIMESTAMP', time());

// Setup the error handler
define('PANTHER_ADMIN_DIR', 'admin');
require PANTHER_ROOT.'include/errors.php';

$handler = new errors;

set_error_handler(array($handler, 'handle'));
set_exception_handler(array($handler, 'handle'));
register_shutdown_function(array($handler, 'handle'));

// We want no errors reported, they're handled by the error handler
error_reporting(E_PARSE);

// Load the cache
require PANTHER_ROOT.'include/cache.php';
$cache = new cache(null);

require PANTHER_ROOT.'include/lang.php';
$lang = new language_handler($cache);

if (isset($_POST['change_language']))
{
	$install_lang = isset($_POST['language']) && preg_match('/^[a-z]{2}$/', $_POST['language']) ? panther_trim($_POST['language']) : config::DEFAULT_LANG;
	$_SESSION['language'] = $install_lang;
}
else
	$install_lang = (isset($_SESSION['language'])) ? $_SESSION['language'] : config::DEFAULT_LANG;

$lang->set_language($install_lang);
$lang->load('install');

require INSTALL_ROOT.'include/template.php';

$tpl = new template($cache, $lang);

$setup = new installer($tpl, $cache, $install_lang, $lang);

// Yuck, global variable support =(
$db = $setup->db;

$panther_config = array(
	'o_style_path' => 'styles',
	'o_show_queries' => '0',
);