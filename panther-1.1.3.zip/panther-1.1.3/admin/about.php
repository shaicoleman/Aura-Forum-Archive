<?php
/**
 * Copyright (C) 2015 Panther (https://www.pantherforum.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

define('ADMIN_INDEX', 1);

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', __DIR__.'/../');
	require PANTHER_ROOT.'include/common.php';
}

require PANTHER_ROOT.'include/common_admin.php';

if (($panther_user['is_admmod'] && $panther_user['g_mod_cp'] == '0' && !$panther_user['is_admin']) || !$panther_user['is_admmod'])
	message($lang->t('No permission'), false, '403 Forbidden');

check_authentication();

// Load the admin_about language file
$lang->load('admin_about');

$page_title = array($panther_config['o_board_title'], $lang->t('Admin'), $lang->t('About'));
define('PANTHER_ACTIVE_PAGE', 'admin');
require PANTHER_ROOT.'header.php';

generate_admin_menu('about');

$tpl = load_template('admin_about.tpl');
echo $tpl->render(
	array(
		'lang' => $lang,
		'panther_config' => $panther_config,
	)
);

require PANTHER_ROOT.'footer.php';