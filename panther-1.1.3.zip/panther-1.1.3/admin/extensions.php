<?php
/**
 * Copyright (C) 2015 Panther (https://www.pantherforum.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', __DIR__.'/../');
	require PANTHER_ROOT.'include/common.php';
}

require PANTHER_ROOT.'include/common_admin.php';

if (!$panther_user['is_admin'])
	message($lang->t('No permission'), false, '403 Forbidden');

// Load the admin-extensions language file
$lang->load('admin_extensions');

check_authentication();

if ($panther_user['id'] != '2')
{
	if (!is_null($admins[$panther_user['id']]['admin_addons']))
	{
		if ($admins[$panther_user['id']]['admin_addons'] == '0')
			message($lang->t('No permission'));
	}
}

$errors = array();
$action = isset($_GET['action']) ? $_GET['action'] : '';

if (isset($_POST['upload']))
{
	confirm_referrer(PANTHER_ADMIN_DIR.'/addons.php');
	if (!isset($_FILES['req_file']))
		message($lang->t('No file'));

	$uploaded_file = $_FILES['req_file'];

	// Make sure the upload went smooth
	if (isset($uploaded_file['error']))
	{
		switch ($uploaded_file['error'])
		{
			case 1:	// UPLOAD_ERR_INI_SIZE
			case 2:	// UPLOAD_ERR_FORM_SIZE
				message($lang->t('Too large ini'));
			break;
			case 3:	// UPLOAD_ERR_PARTIAL
				message($lang->t('Partial upload'));
			break;
			case 4:	// UPLOAD_ERR_NO_FILE
				message($lang->t('No file'));
			break;
			case 6:	// UPLOAD_ERR_NO_TMP_DIR
				message($lang->t('No tmp directory'));
			break;
			default:
				// No error occured, but was something actually uploaded?
				if ($uploaded_file['size'] == 0)
					message($lang->t('No file'));
			break;
		}
	}

	if (!is_uploaded_file($uploaded_file['tmp_name']))
		$errors[] = $lang->t('Unknown failure');

	$filename = $uploaded_file['name'];
	if (!preg_match('/^[a-z0-9-]+\.(xml)$/i', $uploaded_file['name']))
		$errors[] = $lang->t('Bad type');
	elseif (file_exists(PANTHER_EXTENSIONS_DIR.$filename)) // Make sure there is no file already under this name
		$errors[] = $lang->t('Extension exists', $filename);
	else if (!@move_uploaded_file($uploaded_file['tmp_name'], PANTHER_EXTENSIONS_DIR.$filename)) // Move the file to the extensions directory.
		$errors[] = $lang->t('Move failed');
	else if (!empty($errors))
		@unlink(PANTHER_EXTENSIONS_DIR.$filename);

	if (empty($errors))
	{
		@chmod(PANTHER_EXTENSIONS_DIR.$filename, 0644);		
		redirect(panther_link($panther_url['admin_addons']), $lang->t('Extension uploaded'));
	}
}

if ($action == 'enable' || $action == 'disable')
{
	$file = isset($_GET['file']) ? panther_trim($_GET['file']) : '';
	$data = array(
		':id' => $file,
	);

	$ps = $db->select('extensions', 'title, enabled, author, description, version', $data, 'id=:id');
	if (!$ps->rowCount())
		message($lang->t('Bad request'));

	$update = array(
		'enabled' => ($action == 'enable') ? '1' : '0',
	);

	$db->update('extensions', $update, 'id=:id', $data);
	
	$cache->generate('extensions');
	redirect(panther_link($panther_url['admin_addons']), ($action == 'enable' ? $lang->t('Extension enabled') : $lang->t('Extension disabled')));
}
else if ($action == 'install')
{
	$file = isset($_GET['file']) ? panther_trim($_GET['file']) : '';

	if (!file_exists(PANTHER_EXTENSIONS_DIR.$file.'.xml'))
		message($lang->t('Bad request'));

	$data = array(
		':id' => $file,
	);

	$ps = $db->select('extensions', 1, $data, 'id=:id');
	if ($ps->rowCount())
		message($lang->t('Already installed'));

	$content = file_get_contents(PANTHER_EXTENSIONS_DIR.$file.'.xml');
	$extension = xml_to_array($content);
	$errors = validate_xml($extension, $errors);
	$extension = $extension['extension'];

	$warnings = array();
	if (isset($_POST['form_sent']))
	{
		$enable = isset($_POST['enable']) ? '1' : '0';
		confirm_referrer(PANTHER_ADMIN_DIR.'/addons.php');

		if (empty($errors))
		{
			$insert = array(
				'id' => $file,
				'title' => $extension['title'],
				'version' => $extension['version'],
				'description' => $extension['description'],
				'author' => $extension['author'],
				'uninstall_note' => (isset($extension['uninstall_note']) ? $extension['uninstall_note'] : ''),
				'uninstall' => (isset($extension['uninstall']) ? $extension['uninstall'] : ''),
				'enabled' => $enable,
			);

			$db->insert('extensions', $insert);
			$extension_id = $db->lastInsertId($db->prefix.'extensions');

			foreach ($extension['hooks']['hook'] as $hook)
			{
				$insert = array(
					'extension_id' => $file,
					'hook' => $hook['attributes']['id'],
					'code' => panther_trim($hook['content']),
				);

				$db->insert('extension_code', $insert);
			}

			if (isset($extension['install']))
				eval($extension['install']);

			$cache->generate('extensions');
			redirect(panther_link($panther_url['admin_addons']), $lang->t('Extension installed'));
		}
	}

	$versions = explode(',', $extension['supported_versions']);
	if (!in_array($panther_config['o_cur_version'], $versions))
		$warnings[] = $lang->t('Version warning', $panther_config['o_cur_version'], $extension['supported_versions']);

	$id = sha1($content); // Make sure this extension is 'panther approved'
	$content = @file_get_contents('https://www.pantherforum.org/resources/extensions/check/'.$id);
	if (!$content || !panther_hash_equals($content, $id))
		$warnings[] = $lang->t('Extension not approved');

	$page_title = array($panther_config['o_board_title'], $lang->t('Admin'), $lang->t('Extensions'));
	define('PANTHER_ACTIVE_PAGE', 'admin');
	require PANTHER_ROOT.'header.php';
	generate_admin_menu('extensions');

	$tpl = load_template('install_extension.tpl');
	echo $tpl->render(
		array(
			'lang' => $lang,
			'form_action' => panther_link($panther_url['install_extension'],  array($file)),
			'csrf_token' => generate_csrf_token(PANTHER_ADMIN_DIR.'/addons.php'),
			'extension' => $extension,
			'warnings' => $warnings,
			'errors' => $errors,
		)
	);
}
else if ($action == 'uninstall')
{
	$file = isset($_GET['file']) ? panther_trim($_GET['file']) : '';
	if (!file_exists(PANTHER_EXTENSIONS_DIR.$file.'.xml'))
		message($lang->t('Bad request'));

	$data = array(
		':id' => $file,
	);

	$ps = $db->select('extensions', 'uninstall_note, uninstall', $data, 'id=:id');
	if (!$ps->rowCount())
		message($lang->t('Bad request'));
	
	$extension = $ps->fetch();

	if (isset($_POST['form_sent']))
	{
		$data = array(
			'id' => $file,
		);

		$db->delete('extensions', 'id=:id', $data);
		$db->delete('extension_code', 'extension_id=:id', $data);

		eval($extension['uninstall']);

		$cache->generate('extensions');
		redirect(panther_link($panther_url['admin_addons']), $lang->t('Extension uninstalled'));
	}

	$page_title = array($panther_config['o_board_title'], $lang->t('Admin'), $lang->t('Extensions'));
	define('PANTHER_ACTIVE_PAGE', 'admin');
	require PANTHER_ROOT.'header.php';
	generate_admin_menu('extensions');

	$tpl = load_template('uninstall_extension.tpl');
	echo $tpl->render(
		array(
			'extension' => $extension,
			'lang' => $lang,
			'form_action' => panther_link($panther_url['uninstall_extension'],  array($file)),
			'csrf_token' => generate_csrf_token(PANTHER_ADMIN_DIR.'/addons.php'),
		)
	);
}
else
{
	$extension_files = array();
	$files = array_diff(scandir(PANTHER_EXTENSIONS_DIR), array('.', '..'));
	foreach ($files as $entry)
	{
		if (substr($entry, -4) == '.xml')
			$extension_files[$entry] = array(
				'title' => substr($entry, 0, -4),
				'file' => $entry,
				'install_link' => panther_link($panther_url['install_extension'], array(substr($entry, 0, -4))),
			);
	}

	$extensions = array();
	$ps = $db->select('extensions', 'id, title, enabled');
	foreach ($ps as $cur_extension)
	{
		if (file_exists(PANTHER_EXTENSIONS_DIR.$cur_extension['id'].'.xml'))
			unset($extension_files[$cur_extension['id'].'.xml']);

		$extensions[] = array(
			'id' => $cur_extension['id'],
			'title' => $cur_extension['title'],
			'enabled' => $cur_extension['enabled'],
			'enable_link' => ($cur_extension['enabled']) ? panther_link($panther_url['disable_extension'],  array($cur_extension['id'])) : panther_link($panther_url['enable_extension'],  array($cur_extension['id'])),
			'uninstall_link' => panther_link($panther_url['uninstall_extension'], array($cur_extension['id'])),
		);
	}

	$page_title = array($panther_config['o_board_title'], $lang->t('Admin'), $lang->t('Extensions'));
	define('PANTHER_ACTIVE_PAGE', 'admin');
	require PANTHER_ROOT.'header.php';
	generate_admin_menu('extensions');

	$tpl = load_template('admin_extensions.tpl');
	echo $tpl->render(
		array(
			'lang' => $lang,
			'form_action' => panther_link($panther_url['admin_addons']),
			'csrf_token' => generate_csrf_token(PANTHER_ADMIN_DIR.'/addons.php'),
			'extensions' => $extensions,
			'extension_files' => $extension_files,
			'errors' => $errors,
		)
	);
}

require PANTHER_ROOT.'footer.php';