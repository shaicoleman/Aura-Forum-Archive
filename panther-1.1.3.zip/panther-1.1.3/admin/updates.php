<?php
/**
 * Copyright (C) 2015 Panther (https://www.pantherforum.org)
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', __DIR__.'/../');
	require PANTHER_ROOT.'include/common.php';
}

require PANTHER_ROOT.'include/common_admin.php';

if (!$panther_user['is_admin'] || $panther_config['o_update_type'] == '0')
	message($lang->t('No permission'), false, '403 Forbidden');

if ($panther_user['id'] != '2')
{
	if (!is_null($admins[$panther_user['id']]['admin_updates']))
	{
		if ($admins[$panther_user['id']]['admin_updates'] == '0')
			message($lang->t('No permission'), false, '403 Forbidden');
	}
}

check_authentication();

// Load the admin-update language file
$lang->load('admin_update');

$errors = array();
if (isset($_POST['form_sent']))
{
	confirm_referrer(PANTHER_ADMIN_DIR.'/updates.php');

	require PANTHER_ROOT.'include/updates.php';
	$updater = new panther_updater($panther_config, $lang, $cache, $db);

	$uploaded_file = $_FILES['package'];

	// Make sure the upload went smooth
	if (isset($uploaded_file['error']))
	{
		switch ($uploaded_file['error'])
		{
			case 1: // UPLOAD_ERR_INI_SIZE
			case 2: // UPLOAD_ERR_FORM_SIZE
				message($lang->t('Too large ini'));
				break;

			case 3: // UPLOAD_ERR_PARTIAL
				message($lang->t('Partial upload'));
				break;

			case 4: // UPLOAD_ERR_NO_FILE
				message($lang->t('No file'));
				break;

			case 6: // UPLOAD_ERR_NO_TMP_DIR
				message($lang->t('No tmp directory'));
				break;

			default:
				// No error occured, but was something actually uploaded?
				if ($uploaded_file['size'] == 0)
					message($lang->t('No file'));
				break;
		}
	}

	if (is_uploaded_file($uploaded_file['tmp_name']))
	{
		if (substr($uploaded_file['name'], -4) !== '.zip')
			message($lang->t('Invalid package'));

		// Move the file to the updates directory
		if (!@move_uploaded_file($uploaded_file['tmp_name'], $cache->cache_dir.$uploaded_file['name']))
			message($lang->t('Move failed', $panther_config['o_admin_email']));

		@chmod($cache->cache_dir.$uploaded_file['name'], 0644);
		// Verify this is indeed a valid zip file
		$zip = new ZipArchive;
		if (!$zip->open($cache->cache_dir.$uploaded_file['name'], ZIPARCHIVE::CHECKCONS))
		{
			@unlink($cache->cache_dir.$uploaded_file['name']);
			message($lang->t('Invalid package'));
		}
	}

	// Start the updater
	$result = $updater->run($cache->cache_dir.$uploaded_file['name'], true);

	// An error occurred?
	if ($result !== true)
	{
		@unlink($cache->cache_dir.$uploaded_file['name']);
		message($result);
	}
	else
		redirect(panther_link($panther_url['about_panther']), $lang->t('Forum updated'));
}

$page_title = array($panther_config['o_board_title'], $lang->t('Admin'), $lang->t('Update'));
define('PANTHER_ACTIVE_PAGE', 'admin');
require PANTHER_ROOT.'header.php';

generate_admin_menu('updates');

$tpl = load_template('admin_updates.tpl');
echo $tpl->render(
	array(
		'lang' => $lang,
		'form_action' => panther_link($panther_url['admin_updates']),
		'csrf_token' => generate_csrf_token(PANTHER_ADMIN_DIR.'/updates.php'),
	)
);

require PANTHER_ROOT.'footer.php';