<?php
/**
 * Copyright (C) 2015 Panther (https://www.pantherforum.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', __DIR__.'/');
	require PANTHER_ROOT.'include/common.php';
}

if ($panther_user['g_read_board'] == '0')
	message($lang->t('No view'), false, '403 Forbidden');

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($id < 1)
	message($lang->t('Bad request'), false, '404 Not found');
	
// Fetch some info about the topic and/or the forum
$join = array(
	array(
		'type' => 'INNER',
		'table' => 'forums',
		'as' => 'f',
		'on' => 'f.id=t.forum_id',
	),
	array(
		'type' => 'LEFT',
		'table' => 'forum_perms',
		'as' => 'fp',
		'on' => '(fp.forum_id=f.id AND fp.group_id=:gid)',
	),
);

$data = array(
	':gid' => $panther_user['g_id'],
	':tid' => $id,
);

$ps = $db->join('topics', 't', $join, 'f.id AS fid, f.forum_name, f.redirect_url, f.password, t.poster, t.subject, t.approved, f.moderators', $data, '(fp.read_forum IS NULL OR fp.read_forum=1) AND t.id=:tid');
if (!$ps->rowCount())
	message($lang->t('Bad request'), false, '404 Not found');
	
$cur_posting = $ps->fetch();

$mods_array = ($cur_posting['moderators'] != '') ? unserialize($cur_posting['moderators']) : array();
$is_admmod = ($panther_user['is_admin'] || ($panther_user['g_moderator'] == '1' && $panther_user['g_global_moderator'] ||  array_key_exists($panther_user['username'], $mods_array))) ? true : false;

if ($panther_config['o_polls'] == '0' || (!$is_admmod && ($panther_user['g_post_polls'] == '0' || $cur_posting['poster'] != $panther_user['username'])))
	message($lang->t('No permission'), false, '403 Forbidden');

if ($cur_posting['redirect_url'] != '')
	message($lang->t('Bad request'));

if ($cur_posting['password'] != '')
		check_forum_login_cookie($cur_posting['fid'], $cur_posting['password']);

$lang->load('poll');
$lang->load('post');

$errors = array();
if (isset($_POST['form_sent']))
{
	$question = isset($_POST['req_question']) ? panther_trim($_POST['req_question']) : '';
	$options = isset($_POST['options']) && is_array($_POST['options']) ? array_map('panther_trim', $_POST['options']) : array();
	$type = isset($_POST['type']) ? 2 : 1;

	if ($question == '')
		$errors[] = $lang->t('No question');
	else if (panther_strlen($question) > 70)
		$errors[] = $lang->t('Too long question');
	else if ($panther_config['p_subject_all_caps'] == '0' && is_all_uppercase($question) && !$panther_user['is_admmod'])
		$errors[] = $lang->t('All caps question');

	if (empty($options))
		$errors[] = $lang->t('No options');

	$option_data = array();
	for ($i = 0; $i <= $panther_config['o_max_poll_fields']; $i++)
	{
		if (!empty($errors))
			break;

		if (panther_strlen($options[$i]) > 55)
			$errors[] = $lang->t('Too long option');
		else if ($panther_config['p_subject_all_caps'] == '0' && is_all_uppercase($options[$i]) && !$panther_user['is_admmod'])
			$errors[] = $lang->t('All caps option');
		else if ($options[$i] != '')
			$option_data[] = $options[$i];
	}

	if (count($option_data) < 2)
		$errors[] = $lang->t('Low options');

	// Did everything go according to plan?
	if (empty($errors) && !isset($_POST['preview']))
	{
		$update = array(
			'question' => $question,
		);

		$data = array(
			':id' => $id,
		);

		$db->update('topics', $update, 'id=:id', $data);
		$insert = array(
			'topic_id' => $id,
			'options' => serialize($option_data),
			'type' => $type,
			'voters' => '', // Support for MySQL 5.7.9 strict standards mode
			'votes' => '',
		);

		$db->insert('polls', $insert);
		$new_pid = $db->lastInsertId($db->prefix.'polls');

		($hook = get_extensions('add_poll_before_redirect')) ? eval($hook) : null;

		// Make sure we actually have a topic to go back to
		if ($cur_posting['approved'] == '0')
			redirect(panther_link($panther_url['forum'], array($cur_posting['fid'], url_friendly($cur_posting['forum_name']))), $lang->t('Topic moderation redirect'));
		else
			redirect(panther_link($panther_url['topic'], array($id, url_friendly($cur_posting['subject']))), $lang->t('Post redirect'));
	}
}

$cur_index = 1; 
$required_fields = array('req_question' => $lang->t('Question'), 'req_subject' => $lang->t('Subject'), 'req_message' => $lang->t('Message'));
$focus_element = array('post');

if (!$panther_user['is_guest'])
	$focus_element[] = 'req_question';
else
{
	$required_fields['req_username'] = $lang->t('Guest name');
	$focus_element[] = 'req_question';
}

$inputs = array();
for ($i = 0; $i <= $panther_config['o_max_poll_fields'] ; $i++)
{
	// Make sure this is indeed a valid option
	if (isset($option_data[$i]) && $option_data[$i] != '')
	{
		if (isset($_POST['preview']))
			$inputs[] = array('id' => $i, 'option' => $option_data[$i]);
	}
	else
		$inputs[] = array('id' => $i, 'option' => ((isset($options[$i])) ? $options[$i] : ''));
}

$page_title = array($panther_config['o_board_title'], $lang->t('Post new topic'));
define('PANTHER_ACTIVE_PAGE', 'index');
require PANTHER_ROOT.'header.php';

($hook = get_extensions('add_poll_before_display')) ? eval($hook) : null;

$tpl = load_template('add_poll.tpl');
echo $tpl->render(
	array(
		'lang' => $lang,
		'errors' => $errors,
		'preview' => (isset($_POST['preview'])) ? true : false,
		'inputs' => $inputs,
		'question' => (isset($_POST['req_question'])) ? $question : '',
		'index_link' => panther_link($panther_url['index']),
		'cur_posting' => $cur_posting,
		'forum_link' => panther_link($panther_url['forum'], array($cur_posting['fid'], url_friendly($cur_posting['forum_name']))),
		'form_action' => panther_link($panther_url['poll_add'], array($id)),
		'type' => isset($_POST['type']) ? true : false,
	)
);

require PANTHER_ROOT.'footer.php';