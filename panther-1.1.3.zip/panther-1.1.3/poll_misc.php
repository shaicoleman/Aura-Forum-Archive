<?php
/**
 * Copyright (C) 2015 Panther (https://www.pantherforum.org)
 * based on code by FluxBB copyright (C) 2008-2012 FluxBB
 * License: http://www.gnu.org/licenses/gpl.html GPL version 3 or higher
 */

if (!defined('PANTHER'))
{
	define('PANTHER_ROOT', __DIR__.'/');
	require PANTHER_ROOT.'include/common.php';
}

if ($panther_user['g_read_board'] == '0')
	message($lang->t('No view'), false, '403 Forbidden');

$id = ((isset($_GET['edit'])) ? intval($_GET['edit']) : (isset($_GET['delete']) ? intval($_GET['delete']) : 0));
$id = (($id != 0) ? $id : (isset($_GET['reset']) ? intval($_GET['reset']) : 0));

if ($id < 1)
	message($lang->t('Bad request'));
	
$lang->load('poll');

$join = array(
	array(
		'type' => 'INNER',
		'table' => 'forums',
		'as' => 'f',
		'on' => 'f.id=t.forum_id',
	),
	array(
		'type' => 'INNER',
		'table' => 'polls',
		'as' => 'p',
		'on' => 't.id=p.topic_id',
	),
	array(
		'type' => 'LEFT',
		'table' => 'forum_perms',
		'as' => 'fp',
		'on' => '(fp.forum_id=f.id AND fp.group_id=:gid)',
	),
);

$data = array(
	':gid' => $panther_user['g_id'],
	':tid' => $id,
);

// Fetch some info about the topic and the forum
$ps = $db->join('topics', 't', $join, 'f.forum_name, f.moderators, f.password, f.redirect_url, f.id AS fid, t.archived, t.closed, t.subject, t.poster, t.question, p.type, p.options, p.votes, p.id AS pid', $data, '(fp.read_forum IS NULL OR fp.read_forum=1) AND t.question!=\'\' AND t.id=:tid');
if (!$ps->rowCount())
	message($lang->t('Bad request'));
	
$cur_topic = $ps->fetch();
	
// Is this a redirect forum? In that case, abort!
if ($cur_topic['redirect_url'] != '' || $cur_topic['question'] == '')
	message($lang->t('Bad request'));

if ($cur_topic['password'] != '')
		check_forum_login_cookie($id, $cur_topic['password']);

$mods_array = ($cur_topic['moderators'] != '') ? unserialize($cur_topic['moderators']) : array();
$is_admmod = ($panther_user['is_admin'] || ($panther_user['g_moderator'] == '1' && $panther_user['g_global_moderator'] ||  array_key_exists($panther_user['username'], $mods_array))) ? true : false;

$choices = $options = ($cur_topic['options'] != '') ? unserialize($cur_topic['options']) : array();

if ($cur_topic['archived'] == '1')
	message($lang->t('No permission'));

if (isset($_GET['edit']))
{
	// Do we have permission to edit this poll?
	if (($cur_topic['poster'] != $panther_user['username'] || $panther_user['g_edit_polls'] == '0' || $cur_topic['closed'] == '1') && !$is_admmod)
		message($lang->t('No permission'));

	$errors = array();
	if (isset($_POST['form_sent']))
	{
		confirm_referrer('poll_misc.php');

		$question = isset($_POST['req_question']) ? panther_trim($_POST['req_question']) : '';
		$options = isset($_POST['options']) && is_array($_POST['options']) ? array_map('panther_trim', $_POST['options']) : array();

		if ($question == '')
			$errors[] = $lang->t('No question');
		else if (panther_strlen($question) > 70)
			$errors[] = $lang->t('Too long question');
		else if ($panther_config['p_subject_all_caps'] == '0' && is_all_uppercase($question) && !$panther_user['is_admmod'])
			$errors[] = $lang->t('All caps question');

		if (empty($options))
			$errors[] = $lang->t('No options');

		$option_data = array();
		for ($i = 0; $i <= $panther_config['o_max_poll_fields']; $i++)
		{
			if (!empty($errors))
				break;

			if (panther_strlen($options[$i]) > 55)
				$errors[] = $lang->t('Too long option');
			else if ($panther_config['p_subject_all_caps'] == '0' && is_all_uppercase($options[$i]) && !$panther_user['is_admmod'])
				$errors[] = $lang->t('All caps option');
			else if ($options[$i] != '')
				$option_data[] = $options[$i];
		}

		if (count($options) < 2)
			$errors[] = $lang->t('Low options');

		($hook = get_extensions('edit_poll_after_validation')) ? eval($hook) : null;

		if (empty($errors))
		{
			$votes_array = array();
			// Here, we need to check if any options have been removed/updated/changed position, and if so update the options (and their respective votes)
			$votes = ($cur_topic['votes'] != '') ? unserialize($cur_topic['votes']) : array();
			foreach ($votes as $key => $amount)
				$votes_array[utf8_strtolower($choices[$key])] = $key;

			$fixed_keys = array();
			$options_array = array_filter($options);
			foreach ($options_array as $key => $option)
			{
				if (isset($votes_array[utf8_strtolower($option)]))
				{
					$real_key = $votes_array[utf8_strtolower($option)];
					if ($real_key !== $key)
					{
						if (isset($option_data[$real_key]))
						{
							$new_option = $option_data[$real_key];
							if (isset($votes_array[utf8_strtolower($new_option)]))
							{
								$new_key = $votes_array[utf8_strtolower($new_option)];
								if ($new_key !== $real_key && !in_array($key, $fixed_keys))
								{
									$option_data[$real_key] = $new_option;
									$option_data[$key] = $option_data[$key];

									$new_vote = $votes[$key];
									$votes[$key] = $votes[$real_key];
									$votes[$real_key] = $new_vote;

									$fixed_keys[] = $real_key; // Add this to the fixed keys, so we don't reverse it later
								}
							}
							else
							{
								$votes[$key] = $votes[$real_key];
								unset($votes[$real_key]);
							}
						}
					}
				}
			}

			// Now we need to search for votes that belong to answers that have just been removed
			foreach ($votes as $key => $num_votes)
			{
				if (!isset($option_data[$key]))
					unset($votes[$key]);
			}

			$update = array(
				'question' => $question,
			);

			$data = array(
				':id' => $id,
			);

			$db->update('topics', $update, 'id=:id', $data);
			$update = array(
				'options' => serialize($option_data),
				'votes' => serialize($votes),
			);

			$data = array(
				':id' => $cur_topic['pid'],
			);
			
			$db->update('polls', $update, 'id=:id', $data);
			redirect(panther_link($panther_url['topic'], array($id, url_friendly($cur_topic['subject']))), $lang->t('Poll updated redirect'));
		}
	}

	$fields = array();
	for ($i = 0; $i <= $panther_config['o_max_poll_fields']; $i++)
		$fields[] = ((isset($options[$i])) ? $options[$i] : '');
	
	$lang->load('post');
	
	($hook = get_extensions('edit_poll_before_header')) ? eval($hook) : null;

	$page_title = array($panther_config['o_board_title'], $cur_topic['forum_name'], $cur_topic['subject'], $lang->t('Edit poll'));
	define('PANTHER_ACTIVE_PAGE', 'index');
	require PANTHER_ROOT.'header.php';
	
	$tpl = load_template('edit_poll.tpl');
	echo $tpl->render(
		array(
			'lang' => $lang,
			'form_action' => panther_link($panther_url['poll_edit'], array($id)),
			'csrf_token' => generate_csrf_token(),
			'cur_topic' => $cur_topic,
			'options' => $fields,
			'errors' => $errors,
		)
	);
}
else if (isset($_GET['delete']))
{
	// Do we have permission to delete this poll?
	if (($cur_topic['poster'] != $panther_user['username'] || $panther_user['g_edit_polls'] == '0' || $cur_topic['closed'] == '1') && !$is_admmod)
		message($lang->t('No permission'));

	if (isset($_POST['form_sent']))
	{
		confirm_referrer('poll_misc.php');
		$data = array(
			':id'	=>	$cur_topic['pid'],
		);

		$db->delete('polls', 'id=:id', $data);
		$update = array(
			'question' => '',
		);

		$data = array(
			':id' => $id,
		);

		$db->update('topics', $update, 'id=:id', $data);
		
		($hook = get_extensions('delete_poll_after_deletion')) ? eval($hook) : null;
		redirect(panther_link($panther_url['topic'], array($id, url_friendly($cur_topic['subject']))), $lang->t('Poll deleted redirect'));
	}
	
	($hook = get_extensions('delete_poll_before_header')) ? eval($hook) : null;

	$page_title = array($panther_config['o_board_title'], $lang->t('Delete poll'));
	define('PANTHER_ACTIVE_PAGE', 'index');
	require PANTHER_ROOT.'header.php';
	
	$tpl = load_template('delete_poll.tpl');
	echo $tpl->render(
		array(
			'lang' => $lang,
			'form_action' => panther_link($panther_url['poll_delete'], array($id)),
			'csrf_token' => generate_csrf_token(),
		)
	);
}
else if (isset($_GET['reset']))
{
	if (!$is_admmod)
		message($lang->t('No permission'));

	if (isset($_POST['form_sent']))
	{
		confirm_referrer('poll_misc.php');

		$update = array(
			'voters' => '',
			'votes' => '',
		);

		$data = array(
			':id' => $cur_topic['pid'],
		);

		$db->update('polls', $update, 'id=:id', $data);
		redirect(panther_link($panther_url['topic'], array($id, url_friendly($cur_topic['subject']))), $lang->t('Poll reset redirect'));
	}

	$page_title = array($panther_config['o_board_title'], $lang->t('Reset poll'));
	define('PANTHER_ACTIVE_PAGE', 'index');
	require PANTHER_ROOT.'header.php';
	
	($hook = get_extensions('reset_poll_before_display')) ? eval($hook) : null;
	
	$tpl = load_template('reset_poll.tpl');
	echo $tpl->render(
		array(
			'lang' => $lang,
			'form_action' => panther_link($panther_url['poll_reset'], array($id)),
			'csrf_token' => generate_csrf_token(),
		)
	);
}
else
	message($lang->t('Bad request'));

require PANTHER_ROOT.'footer.php';