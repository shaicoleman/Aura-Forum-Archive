<?php

$lang_reputation = array(
    
    //reputation.php
    'reputation type' => 'Reputation Type',
    'given by' => 'Given By',
    'given to' => 'Given To',
    'date given' => 'Date Given',
    'post topic' => 'Post/Topic',
    'remove reputation' => 'Remove Reputation',
    'exceed positive reputation' => 'You have already used all of your positive votes today.',
    'exceed negative reputation' => 'You have already used all of your negative votes today.',
    'reputation forum disabled' => 'Reputation is disabled in this forum',
    'no guest votes' => 'Reputation cannot be given to guests.',
    'no own votes' => 'Reputation cannot be given to yourself.',
    'archived message' => 'This topic has been archived. No additional reputation can be given.',
    
    // TOCHANGE/EDIT
    'Group Disabled' => 'The board administrator has disabled your user group\'s use of the reputation system.',
    'added reputation interval' => 'To prevent reputation abuse, please wait another %s seconds before altering reputation again.',
    'taken reputation interval' => 'To prevent reputation abuse, please wait another %s seconds before altering reputation again.',
    'duplicate entry minus' => 'You have already removed reputation from this post',
    'duplicate entry positive' => 'You have already given reputation to this post',
    
    //Misc/general
    'Reputation' => 'Reputation',
    'reputation disabled' => 'Reputation has been disabled by the board administrator.',
    'invalid rep type' => 'This reputation type has been disabled by the board administrator.'
    
);