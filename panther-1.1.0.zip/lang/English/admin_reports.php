<?php

// Language definitions used in admin_reports.php
$lang_admin_reports = array(
    
    'Report zapped redirect' => 'Report marked as read. Redirecting …',
    'New reports head' => 'New reports',
    'Deleted user' => 'Deleted user',
    'Deleted' => 'Deleted',
    'Post ID' => 'Post #%s',
    'Report subhead' => 'Reported %s',
    'Reported by' => 'Reported by <a href="%s">%s</a>',
    'Reason' => 'Reason',
    'Zap' => 'Mark as read',
    'No new reports' => 'There are no new reports.',
    'Last 10 head' => '10 last read reports',
    'NA' => 'N/A',
    'Zapped subhead' => 'Marked as read %s by',
    'No zapped reports' => 'There are no read reports.'
    
);